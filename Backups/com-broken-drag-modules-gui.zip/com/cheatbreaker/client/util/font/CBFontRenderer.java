package com.cheatbreaker.client.util.font;

import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author Robert Kjellberg
 * @since 2017/07/14
 */
public class CBFontRenderer extends CBFont {
    private final int[] colorCode = new int[32];
    protected CBFont.CharData[] boldChars = new CBFont.CharData[256];
    protected CBFont.CharData[] italicChars = new CBFont.CharData[256];
    protected CBFont.CharData[] boldItalicChars = new CBFont.CharData[256];
    protected DynamicTexture texBold;
    protected DynamicTexture texItalic;
    protected DynamicTexture texItalicBold;
    protected Random fontRandom = new Random();

    public CBFontRenderer(final ResourceLocation font, float size) {
        super(font, size);
        setupMinecraftColorCodes();
        setupBoldItalicIDs();
    }

    public float drawStringWithShadow(String text, final double x, final double y, final int color) {
        final float shadowWidth = drawString(text, x + 0.5, y + 0.5, color, true);
        return Math.max(shadowWidth, drawString(text, x, y, color, false));
    }

    public float drawString(final String text, final float x, final float y, final int color) {
        return drawString(text, x, y, color, false);
    }

    public float drawCenteredString(final String text, final float x, final float y, final int color) {
        return drawString(text, x - (float) getStringWidth(text) / 2, y, color);
    }

    public float drawCenteredStringWithShadow(final String text, final float x, final float y, final int color) {
        return drawStringWithShadow(text, x - (float) getStringWidth(text) / 2, y, color);
    }

    public float drawCenteredStringWithShadow(final String text, final double x, final double y, final int color) {
        return drawStringWithShadow(text, x - (float) getStringWidth(text) / 2, y, color);
    }

    public float drawString(String text, double x, double y, int color, boolean shadow) {
        x -= 1;

        if (text == null) {
            return 0.0F;
        }

        if (color == 553648127) {
            color = 16777215;
        }

        if ((color & 0xFC000000) == 0) {
            color |= -16777216;
        }

        if (shadow) {
            color = (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
        }

        CBFont.CharData[] currentData = this.charData;
        float alpha = (color >> 24 & 0xFF) / 255.0F;
        boolean randomCase = false;
        boolean bold = false;
        boolean italic = false;
        boolean strikethrough = false;
        boolean underline = false;
        x *= 2.0D;
        y = (y - 3.0D) * 2.0D;

        GL11.glPushMatrix();
        GL11.glScaled(0.5D, 0.5D, 0.5D);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F,
                (color & 0xFF) / 255.0F, alpha);
        int size = text.length();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex.getGlTextureId());

        for (int i = 0; i < size; i++) {
            char character = text.charAt(i);

            if (character == '§') {
                int colorIndex = 21;

                try {
                    colorIndex = "0123456789abcdefklmnor".indexOf(text.charAt(i + 1));
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (colorIndex < 16) {
                    bold = false;
                    italic = false;
                    randomCase = false;
                    underline = false;
                    strikethrough = false;
                    GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex.getGlTextureId());
                    currentData = this.charData;

                    if (colorIndex < 0) {
                        colorIndex = 15;
                    }

                    if (shadow) {
                        colorIndex += 16;
                    }

                    int code = this.colorCode[colorIndex];
                    GL11.glColor4f((code >> 16 & 0xFF) / 255.0F, (code >> 8 & 0xFF) / 255.0F,
                            (code & 0xFF) / 255.0F, alpha);
                } else if (colorIndex == 16) {
                    randomCase = true;
                } else if (colorIndex == 17) {
                    bold = true;

                    if (italic) {
                        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texItalicBold.getGlTextureId());
                        currentData = this.boldItalicChars;
                    } else {
                        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texBold.getGlTextureId());
                        currentData = this.boldChars;
                    }
                } else if (colorIndex == 18) {
                    strikethrough = true;
                } else if (colorIndex == 19) {
                    underline = true;
                } else if (colorIndex == 20) {
                    italic = true;

                    if (bold) {
                        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texItalicBold.getGlTextureId());
                        currentData = this.boldItalicChars;
                    } else {
                        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texItalic.getGlTextureId());
                        currentData = this.italicChars;
                    }
                } else {
                    bold = false;
                    italic = false;
                    randomCase = false;
                    underline = false;
                    strikethrough = false;
                    GL11.glColor4f((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F,
                            (color & 0xFF) / 255.0F, alpha);
                    GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex.getGlTextureId());
                    currentData = this.charData;
                }

                i++;
            } else if (character < currentData.length) {
                GL11.glBegin(GL11.GL_TRIANGLES);

                if (randomCase) {
                    char c;
                    do {
                        c = (char) this.fontRandom.nextInt(currentData.length);
                    }
                    while (currentData[character].width != currentData[c].width);
                    character = c;
                }

                drawChar(currentData, character, (float) x, (float) y);
                GL11.glEnd();

                if (strikethrough) {
                    drawLine(x, y + (float) currentData[character].height / 2, x + currentData[character].width - 8.0D,
                            y + (float) currentData[character].height / 2);
                }

                if (underline) {
                    drawLine(x, y + currentData[character].height - 2.0D,
                            x + currentData[character].width - 8.0D, y + currentData[character].height - 2.0D
                    );
                }

                x += currentData[character].width - 8 + this.charOffset;
            }
        }

        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_DONT_CARE);
        GL11.glPopMatrix();

        return (float) x / 2.0F;
    }

    public int getStringWidth(final String text) {
        if (text == null)
            return 0;
        int width = 0;
        CBFont.CharData[] currentData = this.charData;
        final int size = text.length();

        for (int i = 0; i < size; i++) {
            final char character = text.charAt(i);
            if (character == '\u00a7') {
                i++;
            } else if (character < currentData.length) {
                width += currentData[character].width - 8 + this.charOffset;
            }
        }

        return width / 2;
    }

    public void setFont(final Font font) {
        super.setFont(font);
        setupBoldItalicIDs();
    }

    public void setAntiAlias(final boolean antiAlias) {
        super.setAntiAlias(antiAlias);
        setupBoldItalicIDs();
    }

    public void setFractionalMetrics(final boolean fractionalMetrics) {
        super.setFractionalMetrics(fractionalMetrics);
        setupBoldItalicIDs();
    }

    private void setupBoldItalicIDs() {
        this.texBold = setupTexture(this.font.deriveFont(Font.BOLD), this.antiAlias, this.fractionalMetrics, this.boldChars);
        this.texItalic = setupTexture(this.font.deriveFont(Font.ITALIC), this.antiAlias, this.fractionalMetrics, this.italicChars);

    }

    private void drawLine(final double x, final double y, final double x1, final double y1) {
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glLineWidth(1.0F);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2d(x, y);
        GL11.glVertex2d(x1, y1);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    public List<String> wrapWords(final String text, final double width) {
        final List<String> finalWords = new ArrayList<>();
        if (getStringWidth(text) > width) {
            final String[] words = text.split(" ");
            StringBuilder currentWord = new StringBuilder();
            char lastColorCode = 65535;

            for (final String word : words) {
                for (int i = 0; i < word.toCharArray().length; i++) {
                    final char c = word.toCharArray()[i];

                    if ((c == '\u00a7') && (i < word.toCharArray().length - 1)) {
                        lastColorCode = word.toCharArray()[(i + 1)];
                    }
                }
                if (getStringWidth(currentWord + word + " ") < width) {
                    currentWord.append(word).append(" ");
                } else {
                    finalWords.add(currentWord.toString());
                    currentWord = new StringBuilder('\u00a7' + lastColorCode + word + " ");
                }
            }
            if (currentWord.length() > 0)
                if (getStringWidth(currentWord.toString()) < width) {
                    finalWords.add('\u00a7' + lastColorCode + currentWord.toString() + " ");
                } else {
                    finalWords.addAll(formatString(currentWord.toString(), width));
                }
        } else {
            finalWords.add(text);
        }

        return finalWords;
    }

    public List<String> formatString(final String string, final double width) {
        final List<String> finalWords = new ArrayList<>();
        StringBuilder currentWord = new StringBuilder();
        char lastColorCode = 65535;
        final char[] chars = string.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            final char c = chars[i];

            if ((c == '\u00a7') && (i < chars.length - 1)) {
                lastColorCode = chars[(i + 1)];
            }

            if (getStringWidth(currentWord.toString() + c) < width) {
                currentWord.append(c);
            } else {
                finalWords.add(currentWord.toString());
                currentWord = new StringBuilder('\u00a7' + lastColorCode + String.valueOf(c));
            }
        }

        if (currentWord.length() > 0) {
            finalWords.add(currentWord.toString());
        }

        return finalWords;
    }

    private void setupMinecraftColorCodes() {
        for (int index = 0; index < 32; index++) {
            final int noClue = (index >> 3 & 0x1) * 85;
            int red = (index >> 2 & 0x1) * 170 + noClue;
            int green = (index >> 1 & 0x1) * 170 + noClue;
            int blue = (index & 0x1) * 170 + noClue;

            if (index == 6) {
                red += 85;
            }

            if (index >= 16) {
                red /= 4;
                green /= 4;
                blue /= 4;
            }

            this.colorCode[index] = ((red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF);
        }
    }
}