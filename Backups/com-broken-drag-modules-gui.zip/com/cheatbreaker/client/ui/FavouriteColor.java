package com.cheatbreaker.client.ui;

public class FavouriteColor {
}
