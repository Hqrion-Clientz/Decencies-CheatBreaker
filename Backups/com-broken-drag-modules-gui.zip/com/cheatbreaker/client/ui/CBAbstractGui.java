package com.cheatbreaker.client.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;

public abstract class CBAbstractGui extends GuiScreen {

    protected ScaledResolution resolution;
    protected float scaledWidth;
    protected float scaledHeight;

    @Override
    public void setWorldAndResolution(final Minecraft mc, final int displayWidth, final int displayHeight) {
        this.mc = mc;
        this.fontRendererObj = mc.fontRenderer;
        this.width = displayWidth;
        this.height = displayHeight;
        this.buttonList.clear();
        this.resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        final float scaleFactor = this.getScaleFactor();
        this.scaledWidth = width / scaleFactor;
        this.scaledHeight = height / scaleFactor;
        this.initGui();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        final float scaleFactor = this.getScaleFactor();
        GL11.glPushMatrix();
        GL11.glScalef(scaleFactor, scaleFactor, scaleFactor);
        drawMenu(mouseX / scaleFactor, mouseY / scaleFactor);
        GL11.glPopMatrix();
    }


    protected abstract void drawMenu(float mouseX, float mouseY);

    protected abstract void mouseClicked(float mouseX, float mouseY, int mouseButton);

    protected abstract void mouseReleased(float mouseX, float mouseY, int mouseButton);

    protected float getScaleFactor() {
        float n;
        switch (resolution.getScaleFactor()) {
            case 1: {
                n = 0.5f;
                break;
            }
            case 3: {
                n = 1.5f;
                break;
            }
            case 4: {
                n = 2.0f;
                break;
            }
            default: {
                n = 1.0f;
                break;
            }
        }
        return 1.0f / n;
    }


}
