package com.cheatbreaker.client.config;

public enum SettingType {
    STRING,
    STRING_ARRAY,
    FLOAT,
    INTEGER,
    DOUBLE,
    BOOLEAN
}
