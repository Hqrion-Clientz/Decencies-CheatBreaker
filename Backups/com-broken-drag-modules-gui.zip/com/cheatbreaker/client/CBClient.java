package com.cheatbreaker.client;

import com.cheatbreaker.client.audio.CBAudioDevice;
import com.cheatbreaker.client.config.CBConfigManager;
import com.cheatbreaker.client.config.CBGlobalSettings;
import com.cheatbreaker.client.config.CBProfile;
import com.cheatbreaker.client.event.EventBus;
import com.cheatbreaker.client.event.type.CBKeyboardEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.ModuleManager;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CBClient {

    // we cannot use a one line getter because it will initiate an overflow.
    @Getter
    public static CBClient instance;
    @Getter
    public List<CBProfile> profiles;
    @Getter
    public CBProfile activeProfile;
    @Getter
    public CBGlobalSettings globalSettings;
    @Getter
    public ModuleManager moduleManager;
    @Getter
    public CBConfigManager configManager;
    @Getter
    public EventBus eventBus;

    public List<ResourceLocation> presetLocations;

    public long startTime;

    private static List<CBAudioDevice> audioDevices;

    private static AudioFormat universalAudioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 16000.0F, 16, 1, 2, 16000.0F, false);

    public CBClient() {
        audioDevices = new ArrayList<>();
        presetLocations = new ArrayList<>();
        profiles = new ArrayList<>();
        startTime = System.currentTimeMillis();
        System.out.println("[CB] Starting CheatBreaker setup");
        createDefaultConfigPresets();
        System.out.println("[CB] Created default configuration presets");
        instance = this;
        initAudioDevices();
        globalSettings = new CBGlobalSettings();
        System.out.println("[CB] Created settings");
        eventBus = new EventBus();
        System.out.println("[CB] Created EventBus");
        moduleManager = new ModuleManager();
        System.out.println("[CB] Created Mod Manager");
    }

    public void initialize() {
        loadProfiles();
        System.out.println("[CB] Loaded " + profiles.size() + " custom profiles");
        (configManager = new CBConfigManager()).read();

        eventBus.addEvent(CBKeyboardEvent.class, (e) -> {
            if (e.getKeyboardKey() == Keyboard.KEY_H) {
                for (CBModule module : moduleManager.modules) {
                    module.setState(!module.isEnabled());
                }
            }
        });
    }

    private void createDefaultConfigPresets() {
        final File file = CBConfigManager.profilesDir;
        if (file.exists() || file.mkdirs()) {
            for (final ResourceLocation resourceLocation : this.presetLocations) {
                final File file2 = new File(file, resourceLocation.getResourcePath().replaceAll("([a-zA-Z0-9/]+)/", ""));
                if (!file2.exists()) {
                    try {
                        final InputStream stream = Minecraft.getMinecraft().getResourceManager().getResource(resourceLocation).getInputStream();
                        Files.copy(stream, file2.toPath());
                        stream.close();
                    }
                    catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }

    private void loadProfiles() {
        profiles.add(new CBProfile("default", false));
        File dir = CBConfigManager.profilesDir;
        File[] files;
        if (dir.exists() && dir.isDirectory() && (files = dir.listFiles()) != null) {
            for (File file : files) {
                if (file.getName().endsWith(".cfg")) {
                    profiles.add(new CBProfile(file.getName().replace(".cfg", ""), true));
                }
            }
        }
    }

    private String getNewProfileName(String base) {
        File dir = CBConfigManager.profilesDir;
        if (dir.exists() || dir.mkdirs()) {
            if (new File(dir + File.separator + base + ".cfg").exists()) {
                return getNewProfileName(base + "1");
            }
        }
        return base;
    }

    public void createNewProfile() {
        if (activeProfile == profiles.get(0)) {
            CBProfile profile = new CBProfile(getNewProfileName("Profile 1"), true);
            activeProfile = profile;
            profiles.add(profile);
            configManager.write();
        }
    }

    private void initAudioDevices() {
        Mixer.Info[] mixers = AudioSystem.getMixerInfo();
        for (Mixer.Info info : mixers) {
            Mixer mixer = AudioSystem.getMixer(info);
            try {
                mixer.getLine(new DataLine.Info(TargetDataLine.class, universalAudioFormat));
                if (info != null) {
                    System.out.println("[CB] Added mic option : " + info.getName());
                    audioDevices.add(new CBAudioDevice(info.getDescription(), info.getName()));
                }
            } catch (IllegalArgumentException | LineUnavailableException ignored) {
                // the device was not a microphone.
            }
        }
    }

    public static String[] getAudioDeviceList() {
        String[] audioDevices = new String[CBClient.audioDevices.size()];
        int var1 = 0;
        for(Iterator<CBAudioDevice> var2 = CBClient.audioDevices.iterator(); var2.hasNext(); ++var1) {
            CBAudioDevice var3 = var2.next();
            audioDevices[var1] = var3.getDescriptor();
        }
        return audioDevices;
    }

    public static String getAudioDevice(String descriptor) {
        Iterator<CBAudioDevice> var1 = audioDevices.iterator();
        if (!var1.hasNext()) {
            return descriptor;
        } else {
            CBAudioDevice var2;
            for(var2 = var1.next(); !var2.getDescriptor().equals(descriptor); var2 = var1.next()) {
                if (!var1.hasNext()) {
                    return descriptor;
                }
            }

            return var2.getDescriptor();
        }
    }

    public static List<CBAudioDevice> getAudioDevices() {
        return audioDevices;
    }

//
//    public boolean checkSomeSecondBOolean() {
//        final Iterator<CBModule> iterator = moduleManager.staffModules.iterator();
//        while (iterator.hasNext()) {
//            if (iterator.next().isStaffEnabledModule()) {
//                return true;
//            }
//        }
//        return false;
//    }

}
