package com.cheatbreaker.client.module;

import com.cheatbreaker.client.module.type.FPSModule;

import java.util.ArrayList;
import java.util.Collection;

public class ModuleManager {

    public Collection<CBModule> modules;

    public ModuleManager() {
        modules = new ArrayList<>();
        modules.add(new FPSModule());
    }

}
