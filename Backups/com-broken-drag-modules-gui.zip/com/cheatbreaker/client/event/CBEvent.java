package com.cheatbreaker.client.event;

public abstract class CBEvent {
}
