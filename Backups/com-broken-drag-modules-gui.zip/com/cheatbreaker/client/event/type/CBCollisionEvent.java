package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;
import net.minecraft.util.AxisAlignedBB;

import java.util.List;

public class CBCollisionEvent extends CBEvent {

    private final List<AxisAlignedBB> boundingBoxes;
    private final int x, y, z;

    public CBCollisionEvent(List<AxisAlignedBB> boundingBoxes, int x, int y, int z) {
        this.boundingBoxes = boundingBoxes;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public List<AxisAlignedBB> getBoundingBoxes() {
        return boundingBoxes;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }
}
