package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;
import net.minecraft.client.multiplayer.WorldClient;

public class CBLoadWorldEvent extends CBEvent {

    private final WorldClient world;

    public CBLoadWorldEvent(WorldClient world) {
        this.world = world;
    }

    public WorldClient getWorld() {
        return world;
    }
}
