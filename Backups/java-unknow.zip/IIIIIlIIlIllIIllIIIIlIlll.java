// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIlIllIIllIIIIlIlll extends IlIlllIllIIIIIIIlllIlIlII
{
    public IIIIIlIIlIllIIllIIIIlIlll() {
        super(3, 3, new lIlIlIlIlIllllIlllIIIlIlI[] { new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIlIIIIIllIlIlIIllIlIIIl, 0, 32767), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI), new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI) }, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIIIlllIllIIIIllIllIIIII, 0, 0));
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        if (!super.lIIIIlIIllIIlIIlIIIlIIllI(ilIlllIlIlIIlIlIIlIIllIl, iiiiiIllIlIIIIlIlllIllllI)) {
            return false;
        }
        lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = null;
        for (int n = 0; n < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl() && lIlIlIlIlIllllIlllIIIlIlI == null; ++n) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(n);
            if (liIlIlIllIIlIIIlIIIlllIII != null && liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIlIIIIIllIlIlIIllIlIIIl) {
                lIlIlIlIlIllllIlllIIIlIlI = liIlIlIllIIlIIIlIIIlllIII;
            }
        }
        if (lIlIlIlIlIllllIlllIIIlIlI == null) {
            return false;
        }
        final IIIlIIIIlIllIlIllIlllIlll liiiIlIIllIIlIIlIIIlIIllI = IIlIlIllIlIIllIllIllIIIll.IlIlIIIIIllIlIlIIllIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, iiiiiIllIlIIIIlIlllIllllI);
        return liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl < 4;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl) {
        lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = null;
        for (int n = 0; n < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl() && lIlIlIlIlIllllIlllIIIlIlI == null; ++n) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(n);
            if (liIlIlIllIIlIIIlIIIlllIII != null && liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIlIIIIIllIlIlIIllIlIIIl) {
                lIlIlIlIlIllllIlllIIIlIlI = liIlIlIllIIlIIIlIIIlllIII;
            }
        }
        final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = lIlIlIlIlIllllIlllIIIlIlI.llIIlllIIIIlllIllIlIlllIl();
        llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl = 1;
        if (llIIlllIIIIlllIllIlIlllIl.lllIIIIIlIllIlIIIllllllII() == null) {
            llIIlllIIIIlllIllIlIlllIl.IIIIllIlIIIllIlllIlllllIl(new IlIIIllIIlIIlllIllllIIIIl());
        }
        llIIlllIIIIlllIllIlIlllIl.lllIIIIIlIllIlIIIllllllII().lIIIIlIIllIIlIIlIIIlIIllI("map_is_scaling", true);
        return llIIlllIIIIlllIllIlIlllIl;
    }
}
