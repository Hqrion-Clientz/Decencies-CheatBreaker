import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelPromise;
import io.netty.channel.ChannelHandlerContext;
import javax.crypto.SecretKey;
import io.netty.channel.ChannelOutboundHandlerAdapter;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIIllIIIllIlIIIllll extends ChannelOutboundHandlerAdapter
{
    private long lIIIIlIIllIIlIIlIIIlIIllI;
    private long lIIIIIIIIIlIllIIllIlIIlIl;
    private long IlllIIIlIlllIllIlIIlllIlI;
    private final byte[] IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIlIIIIllIIIllIlIIIllll(final SecretKey secretKey) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 1L;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 0L;
        this.IIIIllIlIIIllIlllIlllllIl = "ZB9hEJy5l+u8QARAlX9T0w".getBytes();
        final byte[] encoded = secretKey.getEncoded();
        for (int length = encoded.length, i = 0; i < length; ++i) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = (this.lIIIIlIIllIIlIIlIIIlIIllI + (encoded[i] & 0xFF)) % 65521L;
            this.lIIIIIIIIIlIllIIllIlIIlIl = (this.lIIIIIIIIIlIllIIllIlIIlIl + this.lIIIIlIIllIIlIIlIIIlIIllI) % 65521L;
        }
    }
    
    public void write(final ChannelHandlerContext channelHandlerContext, final Object o, final ChannelPromise channelPromise) {
        final ByteBuf byteBuf = (ByteBuf)o;
        while (byteBuf.readableBytes() > 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = (this.lIIIIlIIllIIlIIlIIIlIIllI + (byteBuf.readByte() & 0xFF)) % 65521L;
            this.lIIIIIIIIIlIllIIllIlIIlIl = (this.lIIIIIIIIIlIllIIllIlIIlIl + this.lIIIIlIIllIIlIIlIIIlIIllI) % 65521L;
        }
        byteBuf.readerIndex(0);
        final byte[] iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        for (int length = iiiIllIlIIIllIlllIlllllIl.length, i = 0; i < length; ++i) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = (this.lIIIIlIIllIIlIIlIIIlIIllI + (iiiIllIlIIIllIlllIlllllIl[i] & 0xFF)) % 65521L;
            this.lIIIIIIIIIlIllIIllIlIIlIl = (this.lIIIIIIIIIlIllIIllIlIIlIl + this.lIIIIlIIllIIlIIlIIIlIIllI) % 65521L;
        }
        this.IlllIIIlIlllIllIlIIlllIlI = (this.lIIIIIIIIIlIllIIllIlIIlIl << 16 | this.lIIIIlIIllIIlIIlIIIlIIllI);
        super.write(channelHandlerContext, o, channelPromise);
    }
    
    public long lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
}
