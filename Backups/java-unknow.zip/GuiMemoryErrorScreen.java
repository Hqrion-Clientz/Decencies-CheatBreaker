// 
// Decompiled by Procyon v0.5.36
// 

public class GuiMemoryErrorScreen extends GuiScreen
{
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 120 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.toMenu", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + 160, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 120 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.quit", new Object[0])));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new GuiMainMenu());
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
            this.lllIIIIIlIllIlIIIllllllII.shutdown();
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, "Out of memory!", this.lIIIIIllllIIIIlIlIIIIlIlI / 2, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 20, 16777215);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "Minecraft has run out of memory.", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 0, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "This could be caused by a bug in the game or by the", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 18, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "Java Virtual Machine not being allocated enough", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 27, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "memory.", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 36, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "To prevent level corruption, the current game has quit.", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 54, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "We've tried to free up enough memory to let you go back to", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 63, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "the main menu and back to playing, but this may not have worked.", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 72, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "Please restart the game if you see this message again.", this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 140, this.IIIIIIlIlIlIllllllIlllIlI / 4 - 60 + 60 + 81, 10526880);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
}
