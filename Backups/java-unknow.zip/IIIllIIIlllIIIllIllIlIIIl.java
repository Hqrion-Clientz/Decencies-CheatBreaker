// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIlllIIIllIllIlIIIl extends lIlIlIlIIIllIIllllIIlIlIl
{
    private static final EnumMinimapOptions[] lIIIIIIIIIlIllIIllIlIIlIl;
    private final GuiScreen IlllIIIlIlllIllIlIIlllIlI;
    private final IllllIIlIllIIIlIlllIlIIIl IIIIllIlIIIllIlllIlllllIl;
    protected String lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIllIIIlllIIIllIllIlIIIl(final GuiScreen illlIIIlIlllIllIlIIlllIlI, final IllllIIlIllIIIlIlllIlIIIl iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "Radar Options";
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void s_() {
        int n = 0;
        this.lIIIIlIIllIIlIIlIIIlIIllI = IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("options.minimap.waypoints.title");
        for (int i = 0; i < IIIllIIIlllIIIllIllIlIIIl.lIIIIIIIIIlIllIIllIlIIlIl.length; ++i) {
            final EnumMinimapOptions enumMinimapOptions = IIIllIIIlllIIIllIllIlIIIl.lIIIIIIIIIlIllIIllIlIIlIl[i];
            if (enumMinimapOptions.lIIIIlIIllIIlIIlIIIlIIllI()) {
                float liiiiiiiiIlIllIIllIlIIlIl = this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(enumMinimapOptions);
                if (liiiiiiiiIlIllIIllIlIIlIl < 0.0f) {
                    liiiiiiiiIlIllIIllIlIIlIl = 10001;
                }
                this.lIIlIlIllIIlIIIlIIIlllIII().add(new llIIIllIIIlIllIlIlIllllll(enumMinimapOptions.IIIIllIlIIIllIlllIlllllIl(), this.IlIlllIIIIllIllllIllIIlIl() / 2 - 155 + n % 2 * 160, this.llIIlllIIIIlllIllIlIlllIl() / 6 + 24 * (n >> 1), enumMinimapOptions, (liiiiiiiiIlIllIIllIlIIlIl - 50) / 9951, this.IIIIllIlIIIllIlllIlllllIl));
            }
            else {
                this.lIIlIlIllIIlIIIlIIIlllIII().add(new lIlIlIIlIlIIIlIllIlIllIIl(enumMinimapOptions.IIIIllIlIIIllIlllIlllllIl(), this.IlIlllIIIIllIllllIllIIlIl() / 2 - 155 + n % 2 * 160, this.llIIlllIIIIlllIllIlIlllIl() / 6 + 24 * (n >> 1), enumMinimapOptions, this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(enumMinimapOptions)));
            }
            ++n;
        }
        this.lIIlIlIllIIlIIIlIIIlllIII().add(new lIIlIIIIlIIIIIllIIIIlIIll(200, this.IlIlllIIIIllIllllIllIIlIl() / 2 - 100, this.llIIlllIIIIlllIllIlIlllIl() / 6 + 168, IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("gui.done")));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI < 100 && liIlIIIIlIIIIIllIIIIlIIll instanceof lIlIlIIlIlIIIlIllIlIllIIl) {
                this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(((lIlIlIIlIlIIIlIllIlIllIIl)liIlIIIIlIIIIIllIIIIlIIll).lIIIIlIIllIIlIIlIIIlIIllI(), 1);
                liIlIIIIlIIIIIllIIIIlIIll.IllIIIIIIIlIlIllllIIllIII = this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(EnumMinimapOptions.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI));
            }
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 200) {
                this.IlllIllIlIIIIlIIlIIllIIIl().displayGuiScreen(this.IlllIIIlIlllIllIlIIlllIlI);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        super.resetSize();
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI, this.IlIlllIIIIllIllllIllIIlIl() / 2, 20, 16777215);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = new EnumMinimapOptions[] { EnumMinimapOptions.IllIlIlIllllIlIIllllIIlll, EnumMinimapOptions.IllIIlIIlllllIllIIIlllIII };
    }
}
