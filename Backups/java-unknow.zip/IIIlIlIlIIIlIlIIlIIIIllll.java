// 
// Decompiled by Procyon v0.5.36
// 

final class IIIlIlIlIIIlIlIIlIIIIllll extends IIIlllllIIIIllIlIIlIIlIIl
{
    private final IIIlllllIIIIllIlIIlIIlIIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIlIlIIIlIlIIlIIIIllll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new IIIlllllIIIIllIlIIlIIlIIl();
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final lIIlllIIIlIllIIlIllIllIlI illIIIIIIIlIlIllllIIllIII = llIllIIlllllIlIIIIllIIIll.IllIIIIIIIlIlIllllIIllIII(iiIlIIlIllllIlIIIIlIlIlIl.IllIIIIIIIlIlIllllIIllIII());
        final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI = iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
        final double n = iiIlIIlIllllIlIIIIlIlIlIl.lIIIIIIIIIlIllIIllIlIIlIl() + illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() * (72.0f * 0.015625f);
        final double n2 = iiIlIIlIllllIlIIIIlIlIlIl.IlllIIIlIlllIllIlIIlllIlI() + illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl() * (3.0846775f * 0.3647059f);
        final double n3 = iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIlIIIllIlllIlllllIl() + illIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI() * (2.6666667f * 0.421875f);
        final int n4 = iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl() + illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
        final int n5 = iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl() + illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl();
        final int n6 = iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII() + illIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI();
        final IIlllllllIlllIIllllIIlIll block = liiiIlIIllIIlIIlIIIlIIllI.getBlock(n4, n5, n6);
        double n7;
        if (lIllllIIIlllIIllllIIlIIIl.IlllIIIlIlllIllIlIIlllIlI(block)) {
            n7 = 0.0;
        }
        else {
            if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air || !lIllllIIIlllIIllllIIlIIIl.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI.getBlock(n4, n5 - 1, n6))) {
                return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIllllIlIIIIlIlIlIl, lIlIlIlIlIllllIlllIIIlIlI);
            }
            n7 = -1;
        }
        final lllIllIIIllllIlIlllllllll liiiIlIIllIIlIIlIIIlIIllI2 = lllIllIIIllllIlIlllllllll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n, n2 + n7, n3, ((IlIlIIIIIlIIIllIllIIlIlll)lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()).lIIIIllIIlIlIllIIIlIllIlI);
        if (lIlIlIlIlIllllIlllIIIlIlI.IlIIlIIIIlIIIIllllIIlIllI()) {
            liiiIlIIllIIlIIlIIIlIIllI2.setSection(lIlIlIlIlIllllIlllIIIlIlI.IIIIIIlIlIlIllllllIlllIlI());
        }
        liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2);
        lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(1);
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl) {
        iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI(1000, iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl(), iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl(), iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII(), 0);
    }
}
