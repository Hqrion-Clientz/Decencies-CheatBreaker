import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllllIIllIIIIlIllIIIIl extends IIlllllllIlllIIllllIIlIll
{
    private IlllIllIIIIlllIllIIIIIlII lIIIIlllIIlIlllllIlIllIII;
    private IlllIllIIIIlllIllIIIIIlII lIIIlllIlIlllIIIIIIIIIlII;
    
    protected IIIlllllIIllIIIIlIllIIIIl() {
        super(Material.IlllIIIlIlllIllIlIIlllIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 20.5f * 0.04573171f, 1.0f);
        this.IlllIIIlIlllIllIlIIlllIlI(255);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 0, n2 + 0, n3 + 0, n + 1, n2 + 1, n3 + 1);
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return (n == 1) ? ((n2 > 0) ? this.lIIIIlllIIlIlllllIlIllIII : this.lIIIlllIlIlllIIIIIIIIIlII) : IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl.IIIIllIlIIIllIlllIlllllIl(n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (!this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3) && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n, n2 + 1, n3)) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            if (illlIIIlIlllIllIlIIlllIlI > 0) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlIIIlIlllIllIlIIlllIlI - 1, 2);
            }
            else if (!this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            }
        }
        else {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 7, 2);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Entity entity, final float n4) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll && iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() < n4 - 0.104166664f * 4.8f) {
            if (!(entity instanceof lIllIIIIlIIlIllIIIlIlIlll) && !iiiiiIllIlIIIIlIlllIllllI.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing")) {
                return;
            }
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
        }
    }
    
    private boolean IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        for (int n4 = 0, i = n - n4; i <= n + n4; ++i) {
            for (int j = n3 - n4; j <= n3 + n4; ++j) {
                final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(i, n2 + 1, j);
                if (block == IllllllIllIIlllIllIIlIIll.IllllllllIlIIIIIIIIllIIII || block == IllllllIllIIlllIllIIlIIll.lllIllIlIllIlIllIIIIIIlll || block == IllllllIllIIlllIllIIlIIll.lIIlIIIllIIlllIlllIlIIlll || block == IllllllIllIIlllIllIIlIIll.IlllIIIllIlIlIIIllIIIlIlI || block == IllllllIllIIlllIllIIlIIll.IIIlIIIIllIIIlIIIIIlllllI) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        for (int i = n - 4; i <= n + 4; ++i) {
            for (int j = n2; j <= n2 + 1; ++j) {
                for (int k = n3 - 4; k <= n3 + 4; ++k) {
                    if (iiiiiIllIlIIIIlIlllIllllI.getBlock(i, j, k).IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(0, random, n2);
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.lIIIIlllIIlIlllllIlIllIII = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_wet");
        this.lIIIlllIlIlllIIIIIIIIIlII = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_dry");
    }
}
