import com.google.common.collect.Lists;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllllIIIlIIIIIlIIIIIl extends llllIlIlIIlIIllllllllllll
{
    private final List lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIllllIIIlIIIIIlIIIIIl(final Minecraft minecraft, final int n, final int n2, final int n3, final int n4, final int n5, final lllIlIIIIlIIlIlIIlIlIlIll... array) {
        super(minecraft, n, n2, n3, n4, n5);
        this.lIIIIlIIllIIlIIlIIIlIIllI = Lists.newArrayList();
        this.IlIlllIIIIllIllllIllIIlIl = false;
        for (int i = 0; i < array.length; i += 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.add(new IIlIIllllllIlIIIIlIlIIIlI(this.lIIIIlIIllIIlIIlIIIlIIllI(minecraft, n / 2 - 155, 0, array[i]), this.lIIIIlIIllIIlIIlIIIlIIllI(minecraft, n / 2 - 155 + 160, 0, (i < array.length - 1) ? array[i + 1] : null)));
        }
    }
    
    private lIIlIIIIlIIIIIllIIIIlIIll lIIIIlIIllIIlIIlIIIlIIllI(final Minecraft minecraft, final int n, final int n2, final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll) {
        if (lllIlIIIIlIIlIlIIlIlIlIll == null) {
            return null;
        }
        final int illlIIIlIlllIllIlIIlllIlI = lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI();
        return lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI() ? new IllIIllIIllIlIllllIlIllII(illlIIIlIlllIllIlIIlllIlI, n, n2, lllIlIIIIlIIlIlIIlIlIlIll) : new llIllIlIlIIIllllIlIlIlIIl(illlIIIlIlllIllIlIIlllIlI, n, n2, lllIlIIIIlIIlIlIIlIlIlIll, minecraft.gameSettings.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll));
    }
    
    public IIlIIllllllIlIIIIlIlIIIlI IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.get(n);
    }
    
    @Override
    protected int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.size();
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return 400;
    }
    
    @Override
    protected int IIIIllIlIIIllIlllIlllllIl() {
        return super.IIIIllIlIIIllIlllIlllllIl() + 32;
    }
}
