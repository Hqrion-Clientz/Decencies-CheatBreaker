// 
// Decompiled by Procyon v0.5.36
// 

class IIlIIIlllllIIIlIIIIIIIIIl extends lIIIlIlIIIIlIllllIlIlIIII
{
    final /* synthetic */ IlIllllIllllllllIIIlIIlII lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIIlllllIIIlIIIIIIIIIl(final IlIllllIllllllllIIIlIIlII liiiIlIIllIIlIIlIIIlIIllI, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        super(n, n2, n3, IlIllllIllllllllIIIlIIlII.lIIIIIIIIIlIllIIllIlIIlIl, 112, 220);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.cancel", new Object[0]), n, n2);
    }
}
