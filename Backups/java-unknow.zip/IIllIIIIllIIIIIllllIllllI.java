// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIllIIIIIllllIllllI
{
    private final String lIIIIlIIllIIlIIlIIIlIIllI;
    private final String lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    
    public IIllIIIIllIIIIIllllIllllI(final String liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
