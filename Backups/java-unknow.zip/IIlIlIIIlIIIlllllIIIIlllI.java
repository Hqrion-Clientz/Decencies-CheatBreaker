import com.google.gson.JsonObject;
import java.util.Date;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIlIIIlllllIIIIlllI extends lIlIIIIIIllIIllIlllIIIlII
{
    public IIlIlIIIlIIIlllllIIIIlllI(final String s) {
        this(s, null, null, null, null);
    }
    
    public IIlIlIIIlIIIlllllIIIIlllI(final String s, final Date date, final String s2, final Date date2, final String s3) {
        super(s, date, s2, date2, s3);
    }
    
    public IIlIlIIIlIIIlllllIIIIlllI(final JsonObject jsonObject) {
        super(lIIIIIIIIIlIllIIllIlIIlIl(jsonObject), jsonObject);
    }
    
    private static String lIIIIIIIIIlIllIIllIlIIlIl(final JsonObject jsonObject) {
        return jsonObject.has("ip") ? jsonObject.get("ip").getAsString() : null;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject) {
        if (this.IIIIllIlIIIllIlllIlllllIl() != null) {
            jsonObject.addProperty("ip", (String)this.IIIIllIlIIIllIlllIlllllIl());
            super.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject);
        }
    }
}
