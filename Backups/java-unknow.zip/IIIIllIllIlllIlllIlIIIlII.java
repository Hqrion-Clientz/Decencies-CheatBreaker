import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIllIlllIlllIlIIIlII extends IIlllllllIlllIIllllIIlIll
{
    public IIIIllIllIlllIlllIlIIIlII() {
        super(Material.lllIIIIIlIllIlIIIllllllII);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IIIIllIlIIIllIlllIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 29;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return 10;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        return (n4 == 2 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI()) || (n4 == 3 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI()) || (n4 == 4 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) || (n4 == 5 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI());
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI();
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final int n8) {
        int n9 = 0;
        if (n4 == 2 && iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, true)) {
            n9 = 2;
        }
        if (n4 == 3 && iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, true)) {
            n9 = 0;
        }
        if (n4 == 4 && iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, true)) {
            n9 = 1;
        }
        if (n4 == 5 && iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, true)) {
            n9 = 3;
        }
        return n9;
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, false, n4, false, -1, 0);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (illlllllIlllIIllllIIlIll != this && this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            final int n4 = illlIIIlIlllIllIlIIlllIlI & 0x3;
            boolean b = false;
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && n4 == 3) {
                b = true;
            }
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && n4 == 1) {
                b = true;
            }
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() && n4 == 0) {
                b = true;
            }
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI() && n4 == 2) {
                b = true;
            }
            if (b) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 0);
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b, int n4, final boolean b2, final int n5, final int n6) {
        final int n7 = n4 & 0x3;
        final boolean b3 = (n4 & 0x4) == 0x4;
        final boolean b4 = (n4 & 0x8) == 0x8;
        boolean b5 = !b;
        boolean b6 = false;
        final boolean b7 = !IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3);
        final int n8 = llIllIlIIIlllllIllllllIIl.lIIIIlIIllIIlIIlIIIlIIllI[n7];
        final int n9 = llIllIlIIIlllllIllllllIIl.lIIIIIIIIIlIllIIllIlIIlIl[n7];
        int n10 = 0;
        final int[] array = new int[42];
        int i = 1;
        while (i < 42) {
            final int n11 = n + n8 * i;
            final int n12 = n3 + n9 * i;
            final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n11, n2, n12);
            if (block == IllllllIllIIlllIllIIlIIll.IlllIIllllllllIlIlIlllllI) {
                if ((iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n11, n2, n12) & 0x3) == llIllIlIIIlllllIllllllIIl.IlIlIIIlllIIIlIlllIlIllIl[n7]) {
                    n10 = i;
                    break;
                }
                break;
            }
            else {
                if (block != IllllllIllIIlllIllIIlIIll.lIllIIIIIlIllIllllIlIllII && i != n5) {
                    array[i] = -1;
                    b5 = false;
                }
                else {
                    final int n13 = (i == n5) ? n6 : iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n11, n2, n12);
                    final boolean b8 = (n13 & 0x8) != 0x8;
                    final boolean b9 = (n13 & 0x1) == 0x1;
                    b5 &= ((n13 & 0x2) == 0x2 == b7);
                    b6 |= (b8 && b9);
                    array[i] = n13;
                    if (i == n5) {
                        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI));
                        b5 &= b8;
                    }
                }
                ++i;
            }
        }
        final boolean b10 = b5 & n10 > 1;
        final boolean b11 = b6 & b10;
        final int n14 = (b10 ? 4 : 0) | (b11 ? 8 : 0);
        n4 = (n7 | n14);
        if (n10 > 0) {
            final int n15 = n + n8 * n10;
            final int n16 = n3 + n9 * n10;
            final int n17 = llIllIlIIIlllllIllllllIIl.IlIlIIIlllIIIlIlllIlIllIl[n7];
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n15, n2, n16, n17 | n14, 3);
            this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n15, n2, n16, n17);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n15, n2, n16, b10, b11, b3, b4);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, b10, b11, b3, b4);
        if (!b) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 3);
            if (b2) {
                this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n7);
            }
        }
        if (b3 != b10) {
            for (int j = 1; j < n10; ++j) {
                final int n18 = n + n8 * j;
                final int n19 = n3 + n9 * j;
                final int n20 = array[j];
                if (n20 >= 0) {
                    int n21;
                    if (b10) {
                        n21 = (n20 | 0x4);
                    }
                    else {
                        n21 = (n20 & 0xFFFFFFFB);
                    }
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n18, n2, n19, n21, 3);
                }
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, false, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), true, -1, 0);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b, final boolean b2, final boolean b3, final boolean b4) {
        if (b2 && !b4) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 1.414634108543396 * 0.35344828530596806, n2 + 0.1048780512199879 * 0.9534883499145508, n3 + 2.232558250427246 * 0.22395832220920314, "random.click", 0.25925925f * 1.5428572f, 0.76666665f * 0.78260875f);
        }
        else if (!b2 && b4) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 1.980000096774106 * 0.2525252401828766, n2 + 0.27450981736183167 * 0.3642856964499375, n3 + 0.4300000153779989 * 1.1627906560897827, "random.click", 0.47887325f * 0.8352941f, 0.8333333f * 0.6f);
        }
        else if (b && !b3) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 2.083333379899463 * 0.23999999463558197, n2 + 9.0 * 0.011111111111111112, n3 + 0.06349206349206349 * 7.875, "random.click", 27.0f * 0.0148148155f, 0.025641026f * 27.3f);
        }
        else if (!b && b3) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 2.153846263885498 * 0.23214284528274987, n2 + 13.666666984558105 * 0.007317073000534035, n3 + 4.333333492279053 * 0.11538461115233307, "random.bowhit", 0.062068965f * 6.4444447f, 1.6875f * 0.7111111f / (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() * (0.86206895f * 0.23200001f) + 3.2666667f * 0.2755102f));
        }
    }
    
    private void IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this);
        if (n4 == 3) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
        }
        else if (n4 == 1) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
        }
        else if (n4 == 0) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
        }
        else if (n4 == 2) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
        }
    }
    
    private boolean IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!this.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 0);
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            return false;
        }
        return true;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final int n4 = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x3;
        final float n5 = 0.3888889f * 0.48214284f;
        if (n4 == 3) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 1.0857143f * 0.18421052f, 0.23076923f * 2.1666667f - n5, n5 * 2.0f, 0.21276596f * 3.76f, 0.44117647f * 1.1333333f + n5);
        }
        else if (n4 == 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f - n5 * 2.0f, 0.07234043f * 2.764706f, 1.0f * 0.5f - n5, 1.0f, 3.625f * 0.22068965f, 1.060241f * 0.4715909f + n5);
        }
        else if (n4 == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.54f * 0.9259259f - n5, 0.18709677f * 1.0689656f, 0.0f, 1.7272727f * 0.28947368f + n5, 6.88f * 0.11627907f, n5 * 2.0f);
        }
        else if (n4 == 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(2.6785715f * 0.18666667f - n5, 0.16410257f * 1.21875f, 1.0f - n5 * 2.0f, 2.5882354f * 0.19318181f + n5, 0.17078653f * 4.6842103f, 1.0f);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        final boolean b = (n4 & 0x4) == 0x4;
        final boolean b2 = (n4 & 0x8) == 0x8;
        if (b || b2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, true, n4, false, -1, 0);
        }
        if (b2) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this);
            final int n5 = n4 & 0x3;
            if (n5 == 3) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
            }
            else if (n5 == 1) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
            }
            else if (n5 == 0) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
            }
            else if (n5 == 2) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
            }
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, n4);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return ((liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x8) == 0x8) ? 15 : 0;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        if ((illlIIIlIlllIllIlIIlllIlI & 0x8) != 0x8) {
            return 0;
        }
        final int n5 = illlIIIlIlllIllIlIIlllIlI & 0x3;
        return (n5 == 2 && n4 == 2) ? 15 : ((n5 == 0 && n4 == 3) ? 15 : ((n5 == 1 && n4 == 4) ? 15 : ((n5 == 3 && n4 == 5) ? 15 : 0)));
    }
    
    @Override
    public boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return true;
    }
}
