import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIlllIlIllIIIIlllIIlI extends lIlIlIlIIIllIIllllIIlIlIl
{
    private final GuiScreen IIIIllIlIIIllIlllIlllllIl;
    protected final IlIIIlIlIIlllllllllIlIIII lIIIIlIIllIIlIIlIIIlIIllI;
    protected String lIIIIIIIIIlIllIIllIlIIlIl;
    private lIIlIIllIIlllIlIlllIIIIll IIIIllIIllIIIIllIllIIIlIl;
    private lIIlIIIIlIIIIIllIIIIlIIll IlIlIIIlllIIIlIlllIlIllIl;
    private lIIlIIIIlIIIIIllIIIIlIIll IIIllIllIlIlllllllIlIlIII;
    private String IllIIIIIIIlIlIllllIIllIII;
    protected String IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIIIlllIlIllIIIIlllIIlI(final GuiScreen iiiIllIlIIIllIlllIlllllIl, final IlIIIlIlIIlllllllllIlIIII liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = "Select Mobs";
        this.IllIIIIIIIlIlIllllIIllIII = null;
        this.IlllIIIlIlllIllIlIIlllIlI = null;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void s_() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("options.minimap.mobs.title");
        (this.IIIIllIIllIIIIllIllIIIlIl = new lIIlIIllIIlllIlIlllIIIIll(this)).IIIIllIlIIIllIlllIlllllIl(7, 8);
        this.lIIlIlIllIIlIIIlIIIlllIII().add(this.IlIlIIIlllIIIlIlllIlIllIl = new lIIlIIIIlIIIIIllIIIIlIIll(-1, this.IlIlllIIIIllIllllIllIIlIl() / 2 - 154, this.llIIlllIIIIlllIllIlIlllIl() - 28, 100, 20, IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("options.minimap.mobs.enable")));
        this.lIIlIlIllIIlIIIlIIIlllIII().add(this.IIIllIllIlIlllllllIlIlIII = new lIIlIIIIlIIIIIllIIIIlIIll(-2, this.IlIlllIIIIllIllllIllIIlIl() / 2 - 50, this.llIIlllIIIIlllIllIlIlllIl() - 28, 100, 20, IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("options.minimap.mobs.disable")));
        this.lIIlIlIllIIlIIIlIIIlllIII().add(new lIIlIIIIlIIIIIllIIIIlIIll(65336, this.IlIlllIIIIllIllllIllIIlIl() / 2 + 4 + 50, this.llIIlllIIIIlllIllIlIlllIl() - 28, 100, 20, IIIlIIlIIIlIIIIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI("gui.done")));
        final boolean b = this.IlllIIIlIlllIllIlIIlllIlI != null;
        this.IlIlIIIlllIIIlIlllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl = b;
        this.IIIllIllIlIlllllllIlIlIII.IlllIllIlIIIIlIIlIIllIIIl = b;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == -1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, true);
            }
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == -2) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, false);
            }
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 65336) {
                this.IlllIllIlIIIIlIIlIIllIIIl().displayGuiScreen(this.IIIIllIlIIIllIlllIlllllIl);
            }
        }
    }
    
    protected void setSection(final String illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        final llIllIlIIlIIllIIIIlIlllII liiiIlIIllIIlIIlIIIlIIllI = llIllIlIIlIIllIIIIlIlllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            return liiiIlIIllIIlIIlIIIlIIllI.IlIlllIllIlIllIlllIlllIll;
        }
        final lllIIIlIIlIIllllllllIlIIl liiiIlIIllIIlIIlIIIlIIllI2 = lllIllIllllllllIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
        return liiiIlIIllIIlIIlIIIlIIllI2 != null && liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final boolean b) {
        for (final llIllIlIIlIIllIIIIlIlllII llIllIlIIlIIllIIIIlIlllII : llIllIlIIlIIllIIIIlIlllII.values()) {
            if (llIllIlIIlIIllIIIIlIlllII.lIlIllIlIlIIIllllIlIllIll.equals(s)) {
                llIllIlIIlIIllIIIIlIlllII.IlIlllIllIlIllIlllIlllIll = b;
            }
        }
        for (final lllIIIlIIlIIllllllllIlIIl lllIIIlIIlIIllllllllIlIIl : lllIllIllllllllIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (lllIIIlIIlIIllllllllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI.equals(s)) {
                lllIIIlIIlIIllllllllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl = b;
            }
        }
    }
    
    protected void IlIlIIIlllIIIlIlllIlIllIl() {
        final llIllIlIIlIIllIIIIlIlllII liiiIlIIllIIlIIlIIIlIIllI = llIllIlIIlIIllIIIIlIlllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, !liiiIlIIllIIlIIlIIIlIIllI.IlIlllIllIlIllIlllIlllIll);
        }
        else {
            final lllIIIlIIlIIllllllllIlIIl liiiIlIIllIIlIIlIIIlIIllI2 = lllIllIllllllllIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
            if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, !liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        super.resetSize();
        this.IllIIIIIIIlIlIllllIIllIII = null;
        this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlllIIIllIllIlIIIIIIlII(), this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlIlllIIIIllIllllIllIIlIl() / 2, 20, 16777215);
        final boolean b = this.IlllIIIlIlllIllIlIIlllIlI != null;
        this.IlIlIIIlllIIIlIlllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl = (b && !this.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI));
        this.IIIllIllIlIlllllllIlIlIII.IlllIllIlIIIIlIIlIIllIIIl = (b && this.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI));
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        if (this.IllIIIIIIIlIlIllllIIllIII != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, n, n2);
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2) {
        if (s != null) {
            final int n3 = n + 12;
            final int n4 = n2 - 12;
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n3 - 3), (float)(n4 - 3), (float)(n3 + this.IIIlllIIIllIllIlIIIIIIlII().getStringWidth(s) + 3), (float)(n4 + 8 + 3), -1073741824, -1073741824);
            this.IIIlllIIIllIllIlIIIIIIlII().drawStringWithShadow(s, (float)n3, (float)n4, -1);
        }
    }
    
    static String lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIlllIlIllIIIIlllIIlI iiiiiIlllIlIllIIIIlllIIlI, final String illIIIIIIIlIlIllllIIllIII) {
        return iiiiiIlllIlIllIIIIlllIIlI.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
    }
}
