import java.io.InputStream;
import javazoom.jl.player.AudioDevice;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import javazoom.jl.decoder.JavaLayerHook;
import javazoom.jl.decoder.JavaLayerUtils;
import java.util.List;
import javazoom.jl.player.Player;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIlIIIlIlllllIIIlll
{
    private static final String lIIIIlIIllIIlIIlIIIlIIllI = "https://dash-api.com/api/v3/allData.php";
    private static Player lIIIIIIIIIlIllIIllIlIIlIl;
    private static boolean IlllIIIlIlllIllIlIIlllIlI;
    private static IIIllIllIlIlllllllIlIlIII IIIIllIlIIIllIlllIlllllIl;
    
    public static List lIIIIlIIllIIlIIlIIIlIIllI() {
        JavaLayerUtils.setHook((JavaLayerHook)new IIlllllIIIlIlllIllIIlIlll());
        final ArrayList<IlllIllIlIIIIlIIlIIllIIIl> list = new ArrayList<IlllIllIlIIIIlIIlIIllIIIl>();
        try {
            final JsonObject asJsonObject = new JsonParser().parse(lIIIIlIIllIIlIIlIIIlIIllI("https://dash-api.com/api/v3/allData.php")).getAsJsonObject();
            if (asJsonObject.has("stations")) {
                final Iterator iterator = asJsonObject.getAsJsonArray("stations").iterator();
                while (iterator.hasNext()) {
                    final JsonObject asJsonObject2 = iterator.next().getAsJsonObject();
                    list.add(new IlllIllIlIIIIlIIlIIllIIIl(asJsonObject2.get("name").getAsString(), asJsonObject2.get("square_logo_url").getAsString(), asJsonObject2.get("genre").getAsString(), asJsonObject2.get("current_song_url").getAsString(), asJsonObject2.get("stream_url").getAsString()));
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final String spec) {
        try {
            return new BufferedReader(new InputStreamReader(new URL(spec).openConnection().getInputStream())).readLine();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl.close();
            IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl = null;
        }
        IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI = false;
    }
    
    public static boolean IlllIIIlIlllIllIlIIlllIlI() {
        return IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl != null;
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl(final String spec) {
        if (IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI) {
            return;
        }
        IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI = true;
        if (IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl.close();
            IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl = null;
            return;
        }
        IIIllIllIlIlllllllIlIlIII iiiIllIlIIIllIlllIlllllIl;
        final Player liiiiiiiiIlIllIIllIlIIlIl;
        final InputStream inputStream;
        new Thread(() -> {
            try {
                new URL(spec).openStream();
                // new(javazoom.jl.player.Player.class)
                iiiIllIlIIIllIlllIlllllIl = new IIIllIllIlIlllllllIlIlIII();
                new Player(inputStream, (AudioDevice)(IIIllIIIlIIIlIlllllIIIlll.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl));
                (IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl).play();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }
    
    public static IIIllIllIlIlllllllIlIlIII IIIIllIlIIIllIlllIlllllIl() {
        return IIIllIIIlIIIlIlllllIIIlll.IIIIllIlIIIllIlllIlllllIl;
    }
    
    static {
        IIIllIIIlIIIlIlllllIIIlll.IIIIllIlIIIllIlllIlllllIl = new IIIllIllIlIlllllllIlIlIII();
    }
}
