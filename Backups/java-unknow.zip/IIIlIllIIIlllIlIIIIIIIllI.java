import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllIIIlllIlIIIIIIIllI implements Callable
{
    final /* synthetic */ Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIllIIIlllIlIIIIIIIllI(final Minecraft liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        final String liiiIlIIllIIlIIlIIIlIIllI = lllIlIIIIlIlIlIllIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI();
        return liiiIlIIllIIlIIlIIIlIIllI.equals("vanilla") ? ((Minecraft.class.getSigners() == null) ? "Very likely; Jar signature invalidated" : "Probably not. Jar signature remains and client brand is untouched.") : ("Definitely; Client brand changed to '" + liiiIlIIllIIlIIlIIIlIIllI + "'");
    }
}
