// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIlIlIIlIlIIlIIllIl implements IIlIIlIIllIllllllllIllIII
{
    private lIlIlIlIlIllllIlllIIIlIlI[] lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private IIIllIlIIIllIlIIIIlIlllII IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIlllIlIlIIlIlIIlIIllIl(final IIIllIlIIIllIlIIIIlIlllII illlIIIlIlllIllIlIIlllIlI, final int liiiiiiiiIlIllIIllIlIIlIl, final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new lIlIlIlIlIllllIlllIIIlIlI[liiiiiiiiIlIllIIllIlIIlIl * n];
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.length;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIlIlIllIIlIIIlIIIlllIII(final int n) {
        return (n >= this.IIIIllIIllIIIIllIllIIIlIl()) ? null : this.lIIIIlIIllIIlIIlIIIlIIllI[n];
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        if (n >= 0 && n < this.lIIIIIIIIIlIllIIllIlIIlIl) {
            return this.lIIlIlIllIIlIIIlIIIlllIII(n + n2 * this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        return null;
    }
    
    @Override
    public String IIIlIIlIlIIIlllIIlIllllll() {
        return "container.crafting";
    }
    
    @Override
    public boolean lIIlIIllIIIIIlIllIIIIllII() {
        return false;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI IIIlllIIIllIllIlIIIIIIlII(final int n) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[n] != null) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[n];
            this.lIIIIlIIllIIlIIlIIIlIIllI[n] = null;
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        return null;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[n] == null) {
            return null;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[n].lIIIIIIIIIlIllIIllIlIIlIl <= n2) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[n];
            this.lIIIIlIIllIIlIIlIIIlIIllI[n] = null;
            this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI[n].lIIIIlIIllIIlIIlIIIlIIllI(n2);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[n].lIIIIIIIIIlIllIIllIlIIlIl == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI[n] = null;
        }
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI[n] = lIlIlIlIlIllllIlllIIIlIlI;
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public int IllIlIIIIlllIIllIIlllIIlI() {
        return 64;
    }
    
    @Override
    public void lIllIllIlIIllIllIlIlIIlIl() {
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return true;
    }
    
    @Override
    public void sendHorseInteraction() {
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return true;
    }
}
