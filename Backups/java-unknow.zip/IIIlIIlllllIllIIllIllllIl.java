// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIIlllllIllIIllIllllIl extends llIllIIllIllIIlIIIIllIIII implements lllllIllIlIIllIIIlllllIIl
{
    private final IllIIIlIIIllIIIlIIIllIIll IllIIIIIIIlIlIllllIIllIII;
    final /* synthetic */ lllIIIlIlIIIlllIlIIllIllI lIIIIlIIllIIlIIlIIIlIIllI;
    
    private IIIlIIlllllIllIIllIllllIl(final lllIIIlIlIIIlllIlIIllIllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        super(liiiIlIIllIIlIIlIIIlIIllI, null);
        this.IllIIIIIIIlIlIllllIIllIII = new IllIIIlIIIllIIIlIIIllIIll(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public IllIIIlIIIllIIIlIIIllIIll lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIIIIIIlIllIIllIlIIlIl();
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
}
