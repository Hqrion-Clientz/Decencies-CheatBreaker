import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIIIIIIIlIlIlIIlIll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "summon";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.summon.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length < 1) {
            throw new IIllllIlIlIIlllIlIIllIIll("commands.summon.usage", new Object[0]);
        }
        final String s = array[0];
        double liiiIlIIllIIlIIlIIIlIIllI = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI + 3.291666826078055 * 0.15189872682094574;
        double liiiIlIIllIIlIIlIIIlIIllI2 = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl;
        double liiiIlIIllIIlIIlIIIlIIllI3 = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().IlllIIIlIlllIllIlIIlllIlI + 0.5053763389587402 * 0.9893617121652006;
        if (array.length >= 4) {
            liiiIlIIllIIlIIlIIIlIIllI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI, array[1]);
            liiiIlIIllIIlIIlIIIlIIllI2 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI2, array[2]);
            liiiIlIIllIIlIIlIIIlIIllI3 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI3, array[3]);
        }
        final IIIIIIllIlIIIIlIlllIllllI lllIlIIllllIIIIlIllIlIIII = lIlllllIIIIIIllIlIIlIlIII.lllIlIIllllIIIIlIllIlIIII();
        if (!lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl((int)liiiIlIIllIIlIIlIIIlIIllI, (int)liiiIlIIllIIlIIlIIIlIIllI2, (int)liiiIlIIllIIlIIlIIIlIIllI3)) {
            IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.summon.outOfWorld", new Object[0]);
        }
        else {
            IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
            boolean b = false;
            if (array.length >= 5) {
                final IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI4 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array, 4);
                try {
                    final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI5 = lIlllIllllIlIlllIIIIllIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI4.IlllIIIlIlllIllIlIIlllIlI());
                    if (!(liiiIlIIllIIlIIlIIIlIIllI5 instanceof IlIIIllIIlIIlllIllllIIIIl)) {
                        IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.summon.tagError", "Not a valid tag");
                        return;
                    }
                    ilIIIllIIlIIlllIllllIIIIl = (IlIIIllIIlIIlllIllllIIIIl)liiiIlIIllIIlIIlIIIlIIllI5;
                    b = true;
                }
                catch (IIIlIlIlIIlIIllllIIlIIIlI iiIlIlIlIIlIIllllIIlIIIlI) {
                    IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.summon.tagError", iiIlIlIlIIlIIllllIIlIIIlI.getMessage());
                    return;
                }
            }
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("id", s);
            final Entity liiiIlIIllIIlIIlIIIlIIllI6 = llIlllIlIllllIIIllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl, lllIlIIllllIIIIlIllIlIIII);
            if (liiiIlIIllIIlIIlIIIlIIllI6 == null) {
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.summon.failed", new Object[0]);
            }
            else {
                liiiIlIIllIIlIIlIIIlIIllI6.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI6.IllllIllllIlIIIlIIIllllll, liiiIlIIllIIlIIlIIIlIIllI6.IllIIlllIllIlIllIlIIIIIII);
                if (!b && liiiIlIIllIIlIIlIIIlIIllI6 instanceof IlllIIIllIlIIlIllIIlIlllI) {
                    ((IlllIIIllIlIIlIllIIlIlllI)liiiIlIIllIIlIIlIIIlIIllI6).lIIIIlIIllIIlIIlIIIlIIllI((lIIIlllIlIIlIIlIIIIllllII)null);
                }
                lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI6);
                Entity entity = liiiIlIIllIIlIIlIIIlIIllI6;
                Entity liiiIlIIllIIlIIlIIIlIIllI7;
                for (IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII = ilIIIllIIlIIlllIllllIIIIl; entity != null && liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl("Riding", 10); entity = liiiIlIIllIIlIIlIIIlIIllI7, liIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII.lIIlIlIllIIlIIIlIIIlllIII("Riding")) {
                    liiiIlIIllIIlIIlIIIlIIllI7 = llIlllIlIllllIIIllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII.lIIlIlIllIIlIIIlIIIlllIII("Riding"), lllIlIIllllIIIIlIllIlIIII);
                    if (liiiIlIIllIIlIIlIIIlIIllI7 != null) {
                        liiiIlIIllIIlIIlIIIlIIllI7.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI7.IllllIllllIlIIIlIIIllllll, liiiIlIIllIIlIIlIIIlIIllI7.IllIIlllIllIlIllIlIIIIIII);
                        lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI7);
                        entity.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI7);
                    }
                }
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.summon.success", new Object[0]);
            }
        }
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl()) : null;
    }
    
    protected String[] IIIIllIlIIIllIlllIlllllIl() {
        return llIlllIlIllllIIIllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl().toArray(new String[0]);
    }
}
