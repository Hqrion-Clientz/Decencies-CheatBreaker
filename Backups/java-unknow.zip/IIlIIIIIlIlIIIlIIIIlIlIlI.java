// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIlIlIIIlIIIIlIlIlI extends Throwable
{
    private static final long lIIIIlIIllIIlIIlIIIlIIllI = 7330519489840500997L;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIIIIIlIlIIIlIIIIlIlIlI(final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
