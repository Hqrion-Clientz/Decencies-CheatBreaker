import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIllIIllIlIlIlIIIIII extends lllllIIIIllIIlIlIlIIllllI
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlllIllIIllIlIlIlIIIIII() {
    }
    
    public IIIlllIllIIllIlIlIlIIIIII(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Mob", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Mob");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        if (lllIlIlllIlIIllllllIIIlll != null) {
            ((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll).lIIIIIIIIIlIllIIllIlIIlIl = this;
        }
    }
    
    public static IIIlllIllIIllIlIlIlIIIIII lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -4, -1, 0, 11, 8, 16, n4);
        return (lllllIIIIllIIlIlIlIIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIIlllIllIIllIlIlIlIIIIII(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 10, 7, 15, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, iiIllllIIllllIIIIIlllllIl, lIIlIIlllIIllIlIllllIllll.IlllIIIlIlllIllIlIIlllIlI, 4, 1, 0);
        final int n = 6;
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, n, 1, 1, n, 14, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, n, 1, 9, n, 14, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, n, 1, 8, n, 2, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, n, 14, 8, n, 14, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 1, 1, 2, 1, 4, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 1, 1, 9, 1, 4, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 1, 1, 1, 1, 3, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 1, 1, 9, 1, 3, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 3, 1, 8, 7, 1, 12, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 1, 9, 6, 1, 11, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl, false);
        for (int i = 3; i < 14; i += 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, i, 0, 4, i, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 10, 3, i, 10, 4, i, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, false);
        }
        for (int j = 2; j < 9; j += 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, j, 3, 15, j, 4, 15, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl, false);
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIlIIIlIIIlllllllllllIlIl, 3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 1, 5, 6, 1, 7, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 2, 6, 6, 2, 7, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 3, 7, 6, 3, 7, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        for (int k = 4; k <= 6; ++k) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIIIlIIIlllllllllllIlIl, liiiIlIIllIIlIIlIIIlIIllI, k, 1, 4, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIIIlIIIlllllllllllIlIl, liiiIlIIllIIlIIlIIIlIIllI, k, 2, 5, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIIIlIIIlllllllllllIlIl, liiiIlIIllIIlIIlIIIlIIllI, k, 3, 6, iiIllllIIllllIIIIIlllllIl);
        }
        int n2 = 2;
        int n3 = 0;
        int n4 = 3;
        int n5 = 1;
        switch (this.IlIlIIIlllIIIlIlllIlIllIl) {
            case 0: {
                n2 = 0;
                n3 = 2;
                break;
            }
            case 1: {
                n2 = 1;
                n3 = 3;
                n4 = 0;
                n5 = 2;
                break;
            }
            case 3: {
                n2 = 3;
                n3 = 1;
                n4 = 0;
                n5 = 2;
                break;
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n2 + ((random.nextFloat() > 49.5f * 0.018181818f) ? 4 : 0), 4, 3, 8, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n2 + ((random.nextFloat() > 1.1866666f * 0.75842696f) ? 4 : 0), 5, 3, 8, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n2 + ((random.nextFloat() > 1.0109589f * 0.8902439f) ? 4 : 0), 6, 3, 8, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n3 + ((random.nextFloat() > 0.6593407f * 1.3649999f) ? 4 : 0), 4, 3, 12, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n3 + ((random.nextFloat() > 0.8619718f * 1.0441177f) ? 4 : 0), 5, 3, 12, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n3 + ((random.nextFloat() > 2.1818182f * 0.41249996f) ? 4 : 0), 6, 3, 12, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n4 + ((random.nextFloat() > 1.9317073f * 0.4659091f) ? 4 : 0), 3, 3, 9, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n4 + ((random.nextFloat() > 1.2681818f * 0.7096774f) ? 4 : 0), 3, 3, 10, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n4 + ((random.nextFloat() > 0.8557376f * 1.0517242f) ? 4 : 0), 3, 3, 11, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n5 + ((random.nextFloat() > 1.2857143f * 0.7f) ? 4 : 0), 7, 3, 9, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n5 + ((random.nextFloat() > 3.3749998f * 0.26666668f) ? 4 : 0), 7, 3, 10, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll, n5 + ((random.nextFloat() > 0.098437496f * 9.142858f) ? 4 : 0), 7, 3, 11, iiIllllIIllllIIIIIlllllIl);
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI) {
            final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(3);
            final int liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI(5, 6);
            final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(5, 6);
            if (iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl)) {
                this.lIIIIlIIllIIlIIlIIIlIIllI = true;
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl, IllllllIllIIlllIllIIlIIll.llIIIllIIllllIlIlIlIlIIll, 0, 2);
                final llIIllllllllIllIIIllIIlIl llIIllllllllIllIIIllIIlIl = (llIIllllllllIllIIIllIIlIl)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl);
                if (llIIllllllllIllIIIllIIlIl != null) {
                    llIIllllllllIllIIIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI("Silverfish");
                }
            }
        }
        return true;
    }
}
