import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlllllIIllIIlIIIlIIIl extends llIlIIIlIIlIlllIIlIIIIIll
{
    private UUID lIIIIlIIllIIlIIlIIIlIIllI;
    private List lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlIlllllIIllIIlIIIlIIIl() {
    }
    
    public IIIlIlllllIIllIIlIIIlIIIl(final UUID liiiIlIIllIIlIIlIIIlIIllI, final List liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        final Iterator<String> iterator;
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, list -> {
            liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(list.size());
            list.iterator();
            while (iterator.hasNext()) {
                liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next());
            }
        });
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIIllIIIIIlIIIIIlII.IlllIIIlIlllIllIlIIlllIlI();
        final ArrayList<String> list;
        int i = 0;
        final int n;
        this.lIIIIIIIIIlIllIIllIlIIlIl = (List)liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(() -> {
            liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI();
            list = new ArrayList<String>();
            while (i < n) {
                list.add(liiiIlIIIllIIIIIlIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl());
                ++i;
            }
            return list;
        });
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIlIIIlIlIllIIllllII illllIIlIIIlIlIllIIllllII) {
        ((llllIIlIIllIIIlllIlIIIllI)illllIIlIIIlIlIllIIllllII).lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public UUID lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public List IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
