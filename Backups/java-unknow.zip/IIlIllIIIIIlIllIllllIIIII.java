// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIIIlIllIllllIIIII extends IIlIlllIlIllIllIlIllIllIl
{
    public IIlIllIIIIIlIllIllllIIIII() {
        super(DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI);
    }
}
