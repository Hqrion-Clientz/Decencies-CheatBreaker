// 
// Decompiled by Procyon v0.5.36
// 

public interface DELETE_ME_B extends DELETE_ME_A
{
    IIIIIIllIlIIIIlIlllIllllI lIIIIlIIllIIlIIlIIIlIIllI();
}
