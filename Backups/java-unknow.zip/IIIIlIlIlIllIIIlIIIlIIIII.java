import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.BufferedImage;
import java.io.File;
import org.apache.commons.io.FilenameUtils;
import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIlIllIIIlIIIlIIIII
{
    private static ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIIIIIIlllIllIlIlIlII illlIIIIIIlllIllIlIlIlII, final UUID uuid) {
        final String h_ = illlIIIIIIlllIllIlIlIlII.h_();
        if (h_ != null && !h_.isEmpty()) {
            final String string = "http://s.optifine.net/capes/" + h_ + ".png";
            final ResourceLocation resourceLocation = new ResourceLocation("capeof/" + FilenameUtils.getBaseName(string));
            final TextureManager llIlIlIllIlIIlIlllIllIIlI = Minecraft.getMinecraft().llIlIlIllIlIIlIlllIllIIlI();
            final llllIIlIllllllIlllIlIIIll liiiiiiiiIlIllIIllIlIIlIl = llIlIlIllIlIIlIlllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(resourceLocation);
            if (liiiiiiiiIlIllIIllIlIIlIl != null && liiiiiiiiIlIllIIllIlIIlIl instanceof IIlIlIllIIllllllIIIllIllI) {
                final IIlIlIllIIllllllIIIllIllI ilIlIllIIllllllIIIllIllI = (IIlIlIllIIllllllIIIllIllI)liiiiiiiiIlIllIIllIlIIlIl;
                if (ilIlIllIIllllllIIIllIllI.lIIIIlIIllIIlIIlIIIlIIllI != null) {
                    if (ilIlIllIIllllllIIIllIllI.lIIIIlIIllIIlIIlIIIlIIllI && CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI(uuid) == null) {
                        illlIIIIIIlllIllIlIlIlII.lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation);
                    }
                    return;
                }
            }
            final IIlIlIllIIllllllIIIllIllI ilIlIllIIllllllIIIllIllI2 = new IIlIlIllIIllllllIIIllIllI(null, string, null, new IIIIIIIIIllIlIlIlIllIIlll(illlIIIIIIlllIllIlIlIlII, resourceLocation));
            ilIlIllIIllllllIIIllIllI2.lIIIIIIIIIlIllIIllIlIIlIl = true;
            llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation, ilIlIllIIllllllIIIllIllI2);
        }
    }
    
    public static BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage bufferedImage) {
        int width = 64;
        int height = 32;
        for (int width2 = bufferedImage.getWidth(), height2 = bufferedImage.getHeight(); width < width2 || height < height2; width *= 2, height *= 2) {}
        final BufferedImage bufferedImage2 = new BufferedImage(width, height, 2);
        final Graphics graphics = bufferedImage2.getGraphics();
        graphics.drawImage(bufferedImage, 0, 0, null);
        graphics.dispose();
        return bufferedImage2;
    }
    
    static {
        IIIIlIlIlIllIIIlIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("client/defaults/cb.png");
    }
}
