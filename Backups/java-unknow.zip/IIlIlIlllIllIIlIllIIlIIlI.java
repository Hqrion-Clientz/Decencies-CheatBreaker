import java.io.File;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlllIllIIlIllIIlIIlI extends lllIllIllIlIllIlIIllllIIl
{
    private final int IIIlllIIIllIllIlIIIIIIlII;
    public final List lIIIIlIIllIIlIIlIIIlIIllI;
    private final ResourceLocation llIlIIIlIIIIlIlllIlIIIIll;
    
    public IIlIlIlllIllIIlIllIIlIIlI(final float n, final int n2, final int n3, final int n4, final int n5) {
        super(n, n2, n3, n4, n5);
        this.llIlIIIlIIIIlIlllIlIIIIll = new ResourceLocation("client/icons/plus-64.png");
        this.IIIlllIIIllIllIlIIIIIIlII = -12418828;
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + 2, (double)8, -657931);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
        this.IlllIllIlIIIIlIIlIIllIIIl = 15;
        for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
            final IIlIlllllIIIlIIllIllIlIlI ilIlllllIIIlIIllIllIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
            ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 4 + i * 18, this.IlIlIIIlllIIIlIlllIlIllIl - 12, 18);
            ilIlllllIIIlIIllIllIlIlI.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
            this.IlllIllIlIIIIlIIlIIllIIIl += ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        final boolean b = n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 10 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl + 3 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        GL11.glColor4f(b ? 0.0f : (0.22590362f * 1.1066667f), b ? (1.4117647f * 0.56666666f) : (1.3333334f * 0.1875f), b ? 0.0f : (0.14423077f * 1.7333333f), 1.7058823f * 0.38103446f);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIIIlIIIIlIlllIlIIIIll, 3.4435484f * 1.0163934f, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 15), this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 0.6506024f * 9.990741f);
        final String string = (b ? "(COPIES CURRENT PROFILE) " : "") + "ADD NEW PROFILE";
        CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(string, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17 - CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl(string)), this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 64.28571f * 0.11666667f, b ? 2130738944 : 2130706432);
        this.IlllIllIlIIIIlIIlIIllIIIl += 10;
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        for (final IIlIlllllIIIlIIllIllIlIlI ilIlllllIIIlIIllIllIlIlI : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
                return;
            }
        }
        if (n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 20 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 7 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            Minecraft.getMinecraft().displayGuiScreen(new llIIIlIlIIlIlIIlIllIllIll(lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI, this, this.IIIlllIIIllIllIlIIIIIIlII, this.lIIIIIIIIIlIllIIllIlIIlIl));
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll) {
        return true;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll) {
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        final File file2;
        final File[] array;
        int length;
        int i = 0;
        File file3;
        final Iterator<CBCustomProfile> iterator;
        CBCustomProfile CBCustomProfile;
        CBCustomProfile CBCustomProfile2 = null;
        final Iterator<CBCustomProfile> iterator2;
        new Thread(() -> {
            this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
            new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles");
            if (file2.exists()) {
                file2.listFiles();
                for (length = array.length; i < length; ++i) {
                    file3 = array[i];
                    if (file3.getName().endsWith(".cfg")) {
                        CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl.iterator();
                        while (iterator.hasNext()) {
                            CBCustomProfile = iterator.next();
                            if (file3.getName().equals(CBCustomProfile.lIIIIlIIllIIlIIlIIIlIIllI() + ".cfg")) {
                                CBCustomProfile2 = CBCustomProfile;
                            }
                        }
                        if (CBCustomProfile2 == null) {
                            CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl.add(new CBCustomProfile(file3.getName().replace(".cfg", ""), false));
                        }
                    }
                }
            }
            CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator2.hasNext()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.add(new IIlIlllllIIIlIIllIllIlIlI(this, this.IIIlllIIIllIllIlIIIIIIlII, iterator2.next(), this.lIIIIIIIIIlIllIIllIlIIlIl));
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.sort((ilIlllllIIIlIIllIllIlIlI, ilIlllllIIIlIIllIllIlIlI2) -> {
                if (ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI().toLowerCase().equalsIgnoreCase("default")) {
                    return false ? 1 : 0;
                }
                else if (ilIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI < ilIlllllIIIlIIllIllIlIlI2.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI) {
                    return -1;
                }
                else {
                    return true ? 1 : 0;
                }
            });
        }).start();
    }
}
