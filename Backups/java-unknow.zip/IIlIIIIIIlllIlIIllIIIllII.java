import java.util.Iterator;
import com.google.common.collect.Maps;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIlllIlIIllIIIllII extends IIllIlllIIlllllIlllIIIlIl
{
    private Map lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIIIIIlllIlIIllIIIllII() {
    }
    
    public IIlIIIIIIlllIlIIllIIIllII(final Map liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        final int liiiIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI();
        this.lIIIIlIIllIIlIIlIIIlIIllI = Maps.newHashMap();
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI; ++i) {
            final lIIIlIlIlIIlIIllIIIIIllll liiiIlIIllIIlIIlIIIlIIllI2 = lIIlIIIllIlIIllIIllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32767));
            final int liiiIlIIllIIlIIlIIIlIIllI3 = lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.put(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.size());
        for (final Map.Entry<lIIIlIlIlIIlIIllIIIIIllll, V> entry : this.lIIIIlIIllIIlIIlIIIlIIllI.entrySet()) {
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey().IIIIllIIllIIIIllIllIIIlIl);
            lIlIllllllllIlIIIllIIllII.lIIIIIIIIIlIllIIllIlIIlIl((int)entry.getValue());
        }
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return String.format("count=%d", this.lIIIIlIIllIIlIIlIIIlIIllI.size());
    }
    
    public Map IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
