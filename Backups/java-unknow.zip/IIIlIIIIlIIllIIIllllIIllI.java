import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIlIIllIIIllllIIllI extends lllllIIIIllIIlIlIlIIllllI
{
    private static final IIIlllIlllIlIlIIlllIlllll[] lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlIIIIlIIllIIIllllIIllI() {
    }
    
    public IIIlIIIIlIIllIIIllllIIllI(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIlIIllIIlIIlIIIlIIllI(random);
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Chest", this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Chest");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, 1, 1);
    }
    
    public static IIIlIIIIlIIllIIIllllIIllI lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -1, -1, 0, 5, 5, 7, n4);
        return (lllllIIIIllIIlIlIlIIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIIlIIIIlIIllIIIllllIIllI(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl)) {
            return false;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 4, 4, 6, true, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, iiIllllIIllllIIIIIlllllIl, this.IIIIllIlIIIllIlllIlllllIl, 1, 1, 0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, iiIllllIIllllIIIIIlllllIl, lIIlIIlllIIllIlIllllIllll.lIIIIlIIllIIlIIlIIIlIIllI, 1, 1, 6);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 3, 1, 2, 3, 1, 4, IllllllIllIIlllIllIIlIIll.lIIIlIlIIllIIlllIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIlIlIIllIIlllIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, 5, 3, 1, 1, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, 5, 3, 1, 5, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, 5, 3, 2, 2, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, 5, 3, 2, 4, iiIllllIIllllIIIIIlllllIl);
        for (int i = 2; i <= 4; ++i) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, 5, 2, 1, i, iiIllllIIllllIIIIIlllllIl);
        }
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl && iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI(3, 3), this.lIIIIlIIllIIlIIlIIIlIIllI(2), this.lIIIIIIIIIlIllIIllIlIIlIl(3, 3))) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = true;
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 3, 2, 3, IIIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIIIIlIIllIIIllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI, IIlIlIllIlIIllIllIllIIIll.IlIIIIlIlIllIIlIIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(random)), 2 + random.nextInt(2));
        }
        return true;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new IIIlllIlllIlIlIIlllIlllll[] { new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IlllIIllIlllllIIIlIllIIII, 0, 1, 1, 10), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIIIIllIIlIlIllIIIlIllIlI, 0, 1, 3, 3), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IlllIllIlIIIIlIIlIIllIIIl, 0, 1, 5, 10), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IlIlllIIIIllIllllIllIIlIl, 0, 1, 3, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IIlIlllllIIIlIIllIllIlIlI, 0, 4, 9, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IlIIIIllIIIIIlllIIlIIlllI, 0, 1, 3, 15), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IIIIllIIllIIIIllIllIIIlIl, 0, 1, 3, 15), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIIIIIIIIIlIllIIllIlIIlIl, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.llIIlllIIIIlllIllIlIlllIl, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IllllllIllllIIlllIllllllI, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIIlIIIIIIIIllIIllIIlllIl, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIlIlIIIlIIllllllllIIlllI, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IlIlllIllIlIllIlllIlllIll, 0, 1, 1, 5), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIIIIIIlIIllllllIIIlIlIIl, 0, 1, 1, 1), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.IllIIIIllllllIlllllIlIlll, 0, 1, 1, 1), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.llIllllIIIIIlIllIlIIIllIl, 0, 1, 1, 1), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.llIlllIIllIlllIlIlIlIIIll, 0, 1, 1, 1), new IIIlllIlllIlIlIIlllIlllll(IIlIlIllIlIIllIllIllIIIll.lIlIlIIllIlIIIIIlllIllIII, 0, 1, 1, 1) };
    }
}
