// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIlIIlIIllIllllIIIll extends IIIlIlIIllIlIlIIllIIlllll
{
    private static final ResourceLocation llIlIIIlIIIIlIlllIlIIIIll;
    private static final ResourceLocation IIIlIIllllIIllllllIlIIIll;
    private static final ResourceLocation lllIIIIIlIllIlIIIllllllII;
    private llIIIllllIlIIllIlIIlIIIlI lIIIIIllllIIIIlIlIIIIlIlI;
    private IlIIlIIIllllIIlIlIIIlIlll IIIIIIlIlIlIllllllIlllIlI;
    protected llIIIllllIlIIllIlIIlIIIlI lIIIIllIIlIlIllIIIlIllIlI;
    protected llIIIllllIlIIllIlIIlIIIlI IlllIllIlIIIIlIIlIIllIIIl;
    protected llIIIllllIlIIllIlIIlIIIlI IlIlllIIIIllIllllIllIIlIl;
    protected llIIIllllIlIIllIlIIlIIIlI llIIlllIIIIlllIllIlIlllIl;
    private int IllIllIIIlIIlllIIIllIllII;
    
    public IIIlllIlIIlIIllIllllIIIll() {
        super(new IllllllIlIllIIlIlIlIlIIll(), 2.6f * 0.1923077f, 1.0f);
        this.IllIllIIIlIIlllIIIllIllII = 1;
        this.lIIIIIllllIIIIlIlIIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IIIIIIlIlIlIllllllIlllIlI = new IlIIlIIIllllIIlIlIIIlIlll();
    }
    
    @Override
    protected void IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIllIllIlIlllllllIlIlIII = new IllllllIlIllIIlIlIlIlIIll(1.0f, true);
        this.IllIIIIIIIlIlIllllIIllIII = new IllllllIlIllIIlIlIlIlIIll(0.5967742f * 0.8378378f, true);
        this.lIIIIllIIlIlIllIIIlIllIlI = this.IIIllIllIlIlllllllIlIlIII;
        this.IlllIllIlIIIIlIIlIIllIIIl = this.IllIIIIIIIlIlIllllIIllIII;
        this.IlIlllIIIIllIllllIllIIlIl = new IlIIlIIIllllIIlIlIIIlIlll(1.0f, 0.0f, true);
        this.llIIlllIIIIlllIllIlIlllIl = new IlIIlIIIllllIIlIlIIIlIlll(0.3653846f * 1.3684211f, 0.0f, true);
    }
    
    protected int lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll, final int n, final float n2) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIIIIlIllIIIIlIIIIlll);
        return super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll, n, n2);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIIIIlIllIIIIlIIIIlll);
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll, n, n2, n3, n4, n5);
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll) {
        return (ilIIIIIIlIllIIIIlIIIIlll instanceof IllIIIIIIIIllIIllIllllIIl) ? IIIlllIlIIlIIllIllllIIIll.llIlIIIlIIIIlIlllIlIIIIll : (ilIIIIIIlIllIIIIlIIIIlll.IllIIIIIllllIlllIIlIIllIl() ? IIIlllIlIIlIIllIllllIIIll.lllIIIIIlIllIlIIIllllllII : IIIlllIlIIlIIllIllllIIIll.IIIlIIllllIIllllllIlIIIll);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll, final float n) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIIIIlIllIIIIlIIIIlll);
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll, n);
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll) {
        if (ilIIIIIIlIllIIIIlIIIIlll.IllIIIIIllllIlllIIlIIllIl()) {
            if (this.IllIllIIIlIIlllIIIllIllII != this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI()) {
                this.IIIIIIlIlIlIllllllIlllIlI = new IlIIlIIIllllIIlIlIIIlIlll();
                this.IllIllIIIlIIlllIIIllIllII = this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
                this.IlIlllIIIIllIllllIllIIlIl = new IlIIlIIIllllIIlIlIIIlIlll(1.0f, 0.0f, true);
                this.llIIlllIIIIlllIllIlIlllIl = new IlIIlIIIllllIIlIlIIIlIlll(1.5f * 0.33333334f, 0.0f, true);
            }
            this.lIIlIlIllIIlIIIlIIIlllIII = this.IIIIIIlIlIlIllllllIlllIlI;
            this.IIIllIllIlIlllllllIlIlIII = this.IlIlllIIIIllIllllIllIIlIl;
            this.IllIIIIIIIlIlIllllIIllIII = this.llIIlllIIIIlllIllIlIlllIl;
        }
        else {
            this.lIIlIlIllIIlIIIlIIIlllIII = this.lIIIIIllllIIIIlIlIIIIlIlI;
            this.IIIllIllIlIlllllllIlIlIII = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.IllIIIIIIIlIlIllllIIllIII = this.IlllIllIlIIIIlIIlIIllIIIl;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = (llIIIllllIlIIllIlIIlIIIlI)this.lIIlIlIllIIlIIIlIIIlllIII;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll, final float n, float n2, final float n3) {
        if (ilIIIIIIlIllIIIIlIIIIlll.IlIllIllllIIIlIIIllIIIllI()) {
            n2 += (float)(Math.cos(ilIIIIIIlIllIIIIlIIIIlll.IIIlIllIlllIlIllIllllllll * (0.9677419066429138 * 3.358333433419469)) * (0.7479982848236056 * 4.199999809265137) * (0.15410959256435797 * 1.6222221851348877));
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll, n, n2, n3);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)illlIIIllIlIIlIllIIlIlllI, n);
    }
    
    @Override
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)illlIIIllIlIIlIllIIlIlllI);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)illlIIIllIlIIlIllIIlIlllI, n, n2, n3, n4, n5);
    }
    
    @Override
    protected int lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)illlIIIllIlIIlIllIIlIlllI, n, n2);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entityLivingBase, n, n2);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entityLivingBase, n);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n, final float n2, final float n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entityLivingBase, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIIIlIllIIIIlIIIIlll)entity, n, n2, n3, n4, n5);
    }
    
    static {
        llIlIIIlIIIIlIlllIlIIIIll = new ResourceLocation("textures/entity/zombie_pigman.png");
        IIIlIIllllIIllllllIlIIIll = new ResourceLocation("textures/entity/zombie/zombie.png");
        lllIIIIIlIllIlIIIllllllII = new ResourceLocation("textures/entity/zombie/zombie_villager.png");
    }
}
