// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllIlIIIIIllIIlIllIII
{
    public Class lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public int IIIIllIlIIIllIlllIlllllIl;
    public boolean IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIlIllIlIIIIIllIIlIllIII(final Class liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int iiiIllIlIIIllIlllIlllllIl, final boolean iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public IIIlIllIlIIIIIllIIlIllIII(final Class clazz, final int n, final int n2) {
        this(clazz, n, n2, false);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return this.IIIIllIlIIIllIlllIlllllIl == 0 || this.IlllIIIlIlllIllIlIIlllIlI < this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIlIIIllIlllIlllllIl == 0 || this.IlllIIIlIlllIllIlIIlllIlI < this.IIIIllIlIIIllIlllIlllllIl;
    }
}
