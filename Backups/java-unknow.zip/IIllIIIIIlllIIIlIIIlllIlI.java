import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIIlllIIIlIIIlllIlI extends lIIllllIIlIIlllIlIIllIIIl
{
    public IIllIIIIIlllIIIlIIIlllIlI(final boolean b) {
        super(b);
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        final int n4 = random.nextInt(4) + 6;
        final int n5 = 1 + random.nextInt(2);
        final int n6 = n4 - n5;
        final int n7 = 2 + random.nextInt(2);
        int n8 = 1;
        if (n2 < 1 || n2 + n4 + 1 > 256) {
            return false;
        }
        for (int n9 = n2; n9 <= n2 + 1 + n4 && n8 != 0; ++n9) {
            int n10;
            if (n9 - n2 < n5) {
                n10 = 0;
            }
            else {
                n10 = n7;
            }
            for (int n11 = n - n10; n11 <= n + n10 && n8 != 0; ++n11) {
                for (int n12 = n3 - n10; n12 <= n3 + n10 && n8 != 0; ++n12) {
                    if (n9 >= 0 && n9 < 256) {
                        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n11, n9, n12);
                        if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air && block.IlIlIIIlllIIIlIlllIlIllIl() != Material.IlllIllIlIIIIlIIlIIllIIIl) {
                            n8 = 0;
                        }
                    }
                    else {
                        n8 = 0;
                    }
                }
            }
        }
        if (n8 == 0) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3);
        if ((block2 == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI || block2 == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl || block2 == IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl) && n2 < 256 - n4 - 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            int nextInt = random.nextInt(2);
            int n13 = 1;
            int n14 = 0;
            for (int i = 0; i <= n6; ++i) {
                final int n15 = n2 + n4 - i;
                for (int j = n - nextInt; j <= n + nextInt; ++j) {
                    final int a = j - n;
                    for (int k = n3 - nextInt; k <= n3 + nextInt; ++k) {
                        final int a2 = k - n3;
                        if ((Math.abs(a) != nextInt || Math.abs(a2) != nextInt || nextInt <= 0) && !iiiiiIllIlIIIIlIlllIllllI.getBlock(j, n15, k).lIIIIlIIllIIlIIlIIIlIIllI()) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, j, n15, k, IllllllIllIIlllIllIIlIIll.IllIllIIIlIIlllIIIllIllII, 1);
                        }
                    }
                }
                if (nextInt >= n13) {
                    nextInt = n14;
                    n14 = 1;
                    if (++n13 > n7) {
                        n13 = n7;
                    }
                }
                else {
                    ++nextInt;
                }
            }
            for (int nextInt2 = random.nextInt(3), l = 0; l < n4 - nextInt2; ++l) {
                final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + l, n3);
                if (block3.IlIlIIIlllIIIlIlllIlIllIl() == Material.air || block3.IlIlIIIlllIIIlIlllIlIllIl() == Material.IlllIllIlIIIIlIIlIIllIIIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 + l, n3, IllllllIllIIlllIllIIlIIll.lIIIIIllllIIIIlIlIIIIlIlI, 1);
                }
            }
            return true;
        }
        return false;
    }
}
