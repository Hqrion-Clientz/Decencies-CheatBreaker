import java.util.Iterator;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiIngameMenu extends GuiScreen
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private lIIlIIIIlIIIIIllIIIIlIIll IlllIIIlIlllIllIlIIlllIlI;
    private final ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private final ResourceLocation IIIIllIIllIIIIllIllIIIlIl;
    private final ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
    private final lIlIlIIIlIIllllllllIIlllI IIIllIllIlIlllllllIlIlIII;
    private long IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    private lIlIlIIIlIIllllllllIIlllI IlllIllIlIIIIlIIlIIllIIIl;
    
    public GuiIngameMenu() {
        this.IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("client/logo_white.png");
        this.IIIIllIIllIIIIllIllIIIlIl = new ResourceLocation("client/logo_255_outer.png");
        this.IlIlIIIlllIIIlIlllIlIllIl = new ResourceLocation("client/logo_108_inner.png");
        this.IIIllIllIlIlllllllIlIlIII = new lIlIlIIIlIIllllllllIIlllI(4000L);
        this.lIIIIllIIlIlIllIIIlIllIlI = false;
        this.IlllIllIlIIIIlIIlIIllIIIl = new lIlIlIIIlIIllllllllIIlllI(1500L);
    }
    
    @Override
    public void s_() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 0;
        this.IllIllIIIlIIlllIIIllIllII.clear();
        final int n = -16;
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 120 + n, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.returnToMenu", new Object[0])));
        if (!this.lllIIIIIlIllIlIIIllllllII.IllllIllllIlIIIlIIIllllll()) {
            this.IllIllIIIlIIlllIIIllIllII.get(0).IllIIIIIIIlIlIllllIIllIII = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.disconnect", new Object[0]);
        }
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(4, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 24 + n, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.returnToGame", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96 + n, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.options", new Object[0])));
        final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll = new lIIlIIIIlIIIIIllIIIIlIIll(7, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 2, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96 + n, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.shareToLan", new Object[0]));
        liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl = (this.lllIIIIIlIllIlIIIllllllII.isSingleplayer() && !this.lllIIIIIlIllIlIIIllllllII.IlIlIIIlllllIIIlIlIlIllII().getPublic());
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(5, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 48 + n, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.achievements", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(6, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 2, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 48 + n, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.stats", new Object[0])));
        if (!liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            this.IllIllIIIlIIlllIIIllIllII.add(this.IlllIIIlIlllIllIlIIlllIlI = new lIIlIIIIlIIIIIllIIIIlIIll(10, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 2, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96 + n, 98, 20, "Mods"));
            this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(16, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 72 + n, 200, 20, "Server List"));
        }
        else {
            this.IllIllIIIlIIlllIIIllIllII.add(liIlIIIIlIIIIIllIIIIlIIll);
            this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(16, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 72 + n, 98, 20, "Server List"));
            this.IllIllIIIlIIlllIIIllIllII.add(this.IlllIIIlIlllIllIlIIlllIlI = new lIIlIIIIlIIIIIllIIIIlIIll(10, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 2, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 72 + n, 98, 20, "Mods"));
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2) {
        try {
            if (!this.IIIllIllIlIlllllllIlIlIII.IIIIllIlIIIllIlllIlllllIl()) {
                this.IIIllIllIlIlllllllIlIlIII.lIIIIIIIIIlIllIIllIlIIlIl();
                this.IIIllIllIlIlllllllIlIlIII.IlllIIIlIlllIllIlIIlllIlI();
            }
            final float n3 = 18;
            final double n4 = n / 2 - n3;
            final double n5 = (this.IllIllIIIlIIlllIIIllIllII.size() > 2) ? (this.IllIllIIIlIIlllIIIllIllII.get(1).IIIllIllIlIlllllllIlIlIII - n3 - 32) : ((double)(-100));
            GL11.glPushMatrix();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glTranslatef((float)n4, (float)n5, 1.0f);
            GL11.glTranslatef(n3, n3, n3);
            GL11.glRotatef(180 * this.IIIllIllIlIlllllllIlIlIII.IllIIIIIIIlIlIllllIIllIII(), 0.0f, 0.0f, 1.0f);
            GL11.glTranslatef(-n3, -n3, -n3);
            lIlIIIlllIllllIlllIIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl, n3, 0.0f, 0.0f);
            GL11.glPopMatrix();
            lIlIIIlllIllllIlllIIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlIIIlllIIIlIlllIlIllIl, n3, (float)n4, (float)n5);
        }
        catch (Exception ex) {}
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        this.lIIIIllIIlIlIllIIIlIllIlI = false;
        switch (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI) {
            case 16: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlllIlIllIllllllllllIlIlI(this));
                break;
            }
            case 0: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IllIIlIIllIIlIIIIlllIlIlI(this, this.lllIIIIIlIllIlIIIllllllII.gameSettings));
                break;
            }
            case 1: {
                if (CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI().IIIllIllIlIlllllllIlIlIII()) {
                    this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlIlIIIlllllIIIlIlIlIllII(this));
                    break;
                }
                liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl = false;
                this.lllIIIIIlIllIlIIIllllllII.theWorld.v_();
                this.lllIIIIIlIllIlIIIllllllII.loadWorld(null);
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new GuiMainMenu());
                break;
            }
            case 4: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
                this.lllIIIIIlIllIlIIIllllllII.setIngameFocus();
                break;
            }
            case 5: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlllIIIIllIlIIIlllIIIIllI(this, this.lllIIIIIlIllIlIIIllllllII.thePlayer.IIIlIIlIlIIIlllIIlIllllll()));
                break;
            }
            case 6: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlIIIlllIIIlIlIlllIIlllII(this, this.lllIIIIIlIllIlIIIllllllII.thePlayer.IIIlIIlIlIIIlllIIlIllllll()));
                break;
            }
            case 7: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IIIIIlIlIIIlllIIIIlIlIIll(this));
                break;
            }
            case 10: {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new lIIlIlIIlIlIlIIlIlIlllIIl());
                break;
            }
        }
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        ++this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        final int n4 = 600;
        final int n5 = 356;
        final double n6 = Math.min(this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI) / (n4 * (double)9);
        final int n7 = (int)(n4 * n6);
        final int n8 = (int)(n5 * n6);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI);
        boolean b = false;
        final Iterator<CBMojangServiceEntry> iterator = CheatBreaker.getInstance().IlllIIIlIlllIllIlIIlllIlI.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().lIIIIlIIllIIlIIlIIIlIIllI() == lIIIIlllIlIlllIIIlllllIlI.lIIIIIIIIIlIllIIllIlIIlIl) {
                b = true;
            }
        }
        if (b) {
            if (!this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl()) {
                this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            this.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI();
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 128), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 100), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 142), 1862270976);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 128), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 100), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 142), new Color(1.0f, 0.2f * 0.75f, 10.6f * 0.014150944f, 1.4142857f * 0.45959595f * this.IlllIllIlIIIIlIIlIIllIIIl.IllIIIIIIIlIlIllllIIllIII()).getRGB());
            CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl("Some login services might be offline".toUpperCase(), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 130), -1);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
}
