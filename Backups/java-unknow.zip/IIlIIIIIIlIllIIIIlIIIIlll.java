import java.util.Calendar;
import java.util.List;
import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIlIllIIIIlIIIIlll extends IlIlIIllIlIIlIllIIIIllllI
{
    protected static final llIIllIlllllIIIlIIIIlIlll llIIIlllllIlllIIllIlIIlII;
    private static final UUID lIIIlIlIIIlIlIlllIlIlllII;
    private static final IllIIlIIllIlllIIIIIllllII llIlIlIIIIIIIlllIIIllIlll;
    private final IIIIlIIIIIIlIIIIlIIllIIII IllIIIIIIlIlIlllllllIIllI;
    private int IlIIlllIIlIlIIIlIlllllIll;
    private boolean lIllIllIIlIlIIIIllIllllll;
    private float llllllIIIIIlllllIllIlIllI;
    private float IlllIIllllllllIlIlIlllllI;
    
    public IIlIIIIIIlIllIIIIlIIIIlll(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IllIIIIIIlIlIlllllllIIllI = new IIIIlIIIIIIlIIIIlIIllIIII(this);
        this.lIllIllIIlIlIIIIllIllllll = false;
        this.llllllIIIIIlllllIllIlIllI = -1;
        this.IllIlIlIllllIlIIllllIIlll().lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0, new IIllIIIIllIlIIlIllIIIlllI(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(2, new lIlIIIIIIIIllIlIIlIIIIlII(this, lIllIIIIlIIlIllIIIlIlIlll.class, 1.0, false));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(4, new lIlIIIIIIIIllIlIIlIIIIlII(this, IlIllIlIlIlIIllIIIlIlIllI.class, 1.0, true));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(5, new IIlIIIIlIlllIIlIIIIlIlIll(this, 1.0));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(6, new lIIlIllllIIlIlllIlIIIlllI(this, 1.0, false));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(7, new IllIIllIIlIlIlIllIlIIIlll(this, 1.0));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(8, new IlIIllIllIllIlllIlIlllIIl(this, lIllIIIIlIIlIllIIIlIlIlll.class, 8));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(8, new IllIIIlIllIIIIlllIlllIIIl(this));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, new lIIIIIIllIllllllllIllIIlI(this, true));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(2, new lllIIIllIIllIlllIIlllIlll(this, lIllIIIIlIIlIllIIIlIlIlll.class, 0, true));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(2, new lllIIIllIIllIlllIIlllIlll(this, IlIllIlIlIlIIllIIIlIlIllI.class, 0, false));
        this.IIIIllIIllIIIIllIllIIIlIl(0.010752688f * 55.800003f, 0.071052626f * 25.333334f);
    }
    
    @Override
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIIIIIIlIllIIllIlIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(40);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).lIIIIlIIllIIlIIlIIIlIIllI(0.2773529515562381 * 0.8292682766914368);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIIllIIIIllIllIIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(3);
        this.IlllIlIlllIlIlllIIlllIlIl().lIIIIIIIIIlIllIIllIlIIlIl(IIlIIIIIIlIllIIIIlIIIIlll.llIIIlllllIlllIIllIlIIlII).lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * (0.151162788271904 * 0.6615384820121283));
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(12, (Object)0);
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(13, (Object)0);
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(14, (Object)0);
    }
    
    @Override
    public int IlIIlllIIlIlIIIlIlllllIll() {
        int n = super.IlIIlllIIlIlIIIlIlllllIll() + 2;
        if (n > 20) {
            n = 20;
        }
        return n;
    }
    
    @Override
    protected boolean IIllIllIlIIlllllIlIIIlIll() {
        return true;
    }
    
    public boolean IIIlIllIIIlllIIlIIllIlIII() {
        return this.lIllIllIIlIlIIIIllIllllll;
    }
    
    public void sendClickBlockToController(final boolean lIllIllIIlIlIIIIllIllllll) {
        if (this.lIllIllIIlIlIIIIllIllllll != lIllIllIIlIlIIIIllIllllll) {
            this.lIllIllIIlIlIIIIllIllllll = lIllIllIIlIlIIIIllIllllll;
            if (lIllIllIIlIlIIIIllIllllll) {
                this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(1, this.IllIIIIIIlIlIlllllllIIllI);
            }
            else {
                this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIlIlIlllllllIIllI);
            }
        }
    }
    
    @Override
    public boolean l_() {
        return this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(12) == 1;
    }
    
    @Override
    protected int IIIIllIIllIIIIllIllIIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        if (this.l_()) {
            this.IIIllIllIlIlllllllIlIlIII *= (int)(9.2105255f * 0.27142859f);
        }
        return super.IIIIllIIllIIIIllIllIIIlIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(final boolean b) {
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl(12, (byte)(byte)(b ? 1 : 0));
        if (this.lIIlllIIlIlllllllllIIIIIl != null && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl);
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(IIlIIIIIIlIllIIIIlIIIIlll.llIlIlIIIIIIIlllIIIllIlll);
            if (b) {
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIIIIlIllIIIIlIIIIlll.llIlIlIIIIIIIlllIIIllIlll);
            }
        }
        this.IlIlllIIIIllIllllIllIIlIl(b);
    }
    
    public boolean IllIIIIIllllIlllIIlIIllIl() {
        return this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(13) == 1;
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final boolean b) {
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl(13, (byte)(byte)(b ? 1 : 0));
    }
    
    @Override
    public void i_() {
        if (this.lIIlllIIlIlllllllllIIIIIl.IlIlllIIIIllIllllIllIIlIl() && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && !this.l_()) {
            final float liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(1.0f);
            if (liiiiiiiiIlIllIIllIlIIlIl > 0.022222223f * 22.5f && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 30 < (liiiiiiiiIlIllIIllIlIIlIl - 1.6666666f * 0.24000001f) * 2.0f && this.lIIlllIIlIlllllllllIIIIIl.IllIIIIIIIlIlIllllIIllIII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll))) {
                boolean b = true;
                final lIlIlIlIlIllllIlllIIIlIlI illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(4);
                if (illlIIIlIlllIllIlIIlllIlI != null) {
                    if (illlIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl()) {
                        illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIIIllIIlIlIllIIIlIllIlI() + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(2));
                        if (illlIIIlIlllIllIlIIlllIlI.lIIIIllIIlIlIllIIIlIllIlI() >= illlIIIlIlllIllIlIIlllIlI.IlIlllIIIIllIllllIllIIlIl()) {
                            this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI);
                            this.lIIIIlIIllIIlIIlIIIlIIllI(4, null);
                        }
                    }
                    b = false;
                }
                if (b) {
                    this.IIIIllIIllIIIIllIllIIIlIl(8);
                }
            }
        }
        if (this.llllIIIIIlIlIlIlIllIIIIII() && this.IllllIllllIlIIIlIIIllllll() != null && this.IlIIlIIIIlIIIIllllIIlIllI instanceof lIllllIIIIlIlIlllllllIIII) {
            ((IlllIIIllIlIIlIllIIlIlllI)this.IlIIlIIIIlIIIIllllIIlIllI).IllIlIlIllllIlIIllllIIlll().lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIlIllllIlIIllllIIlll().IIIIllIlIIIllIlllIlllllIl(), 2.029411757590449 * 0.739130437374115);
        }
        super.i_();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (!super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, n)) {
            return false;
        }
        EntityLivingBase illllIllllIlIIIlIIIllllll = this.IllllIllllIlIIIlIIIllllll();
        if (illllIllllIlIIIlIIIllllll == null && this.IIIlIIllllIIllllllIlIIIll() instanceof EntityLivingBase) {
            illllIllllIlIIIlIIIllllll = (EntityLivingBase)this.IIIlIIllllIIllllllIlIIIll();
        }
        if (illllIllllIlIIIlIIIllllll == null && lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl() instanceof EntityLivingBase) {
            illllIllllIlIIIlIIIllllll = (EntityLivingBase)lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl();
        }
        if (illllIllllIlIIIlIIIllllll != null && this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIIIIlIllIIIIlIIIIlll.llIIIlllllIlllIIllIlIIlII).IIIIllIIllIIIIllIllIIIlIl()) {
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
            final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll = new IIlIIIIIIlIllIIIIlIIIIlll(this.lIIlllIIlIlllllllllIIIIIl);
            for (int i = 0; i < 50; ++i) {
                final int n2 = illlIIIlIlllIllIlIIlllIlI + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 7, 40) * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, -1, 1);
                final int n3 = illlIIIlIlllIllIlIIlllIlI2 + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 7, 40) * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, -1, 1);
                final int n4 = illlIIIlIlllIllIlIIlllIlI3 + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 7, 40) * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, -1, 1);
                if (IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, n2, n3 - 1, n4) && this.lIIlllIIlIlllllllllIIIIIl.IlllIllIlIIIIlIIlIIllIIIl(n2, n3, n4) < 10) {
                    ilIIIIIIlIllIIIIlIIIIlll.IlllIIIlIlllIllIlIIlllIlI(n2, n3, n4);
                    if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIIIIlIllIIIIlIIIIlll.lllIlIIllllIIIIlIllIlIIII) && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll, ilIIIIIIlIllIIIIlIIIIlll.lllIlIIllllIIIIlIllIlIIII).isEmpty() && !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(ilIIIIIIlIllIIIIlIIIIlll.lllIlIIllllIIIIlIllIlIIII)) {
                        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll);
                        ilIIIIIIlIllIIIIlIIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(illllIllllIlIIIlIIIllllll);
                        ilIIIIIIlIllIIIIlIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI((lIIIlllIlIIlIIlIIIIllllII)null);
                        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIIIIlIllIIIIlIIIIlll.llIIIlllllIlllIIllIlIIlII).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Zombie reinforcement caller charge", -0.07016129089591096 * 0.7126436829566956, 0));
                        ilIIIIIIlIllIIIIlIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIIIIlIllIIIIlIIIIlll.llIIIlllllIlllIIllIlIIlII).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Zombie reinforcement callee charge", -0.05471698293199149 * 0.9137930870056152, 0));
                        break;
                    }
                }
            }
        }
        return true;
    }
    
    @Override
    public void x_() {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.IlIllIllllIIIlIIIllIIIllI()) {
            this.IlIIlllIIlIlIIIlIlllllIll -= this.llIllllIIIIIlIllIlIIIllIl();
            if (this.IlIIlllIIlIlIIIlIlllllIll <= 0) {
                this.llllIIllIIlIIllIIIllIlIlI();
            }
        }
        super.x_();
    }
    
    @Override
    public boolean lIIlIlIllIIlIIIlIIIlllIII(final Entity entity) {
        final boolean liIlIlIllIIlIIIlIIIlllIII = super.lIIlIlIllIIlIIIlIIIlllIII(entity);
        if (liIlIlIllIIlIIIlIIIlllIII) {
            final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI();
            if (this.IllIIIllIlIIlIllIIIllllIl() == null && this.IIllllIllllIIIlIIllllIlll() && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < liiiIlIIllIIlIIlIIIlIIllI * (1.1904762f * 0.252f)) {
                entity.IIIIllIIllIIIIllIllIIIlIl(2 * liiiIlIIllIIlIIlIIIlIIllI);
            }
        }
        return liIlIlIllIIlIIIlIIIlllIII;
    }
    
    @Override
    protected String llllIlIlIlllllIllIIllIIIl() {
        return "mob.zombie.say";
    }
    
    @Override
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "mob.zombie.hurt";
    }
    
    @Override
    protected String IllIIIIIIlIlIlllllllIIllI() {
        return "mob.zombie.death";
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("mob.zombie.step", 1.75f * 0.08571429f, 1.0f);
    }
    
    @Override
    protected lIIlllIIIlIllllllIlIlIIII lllIIlIIllIllIIllIIlIIIIl() {
        return IIlIlIllIlIIllIllIllIIIll.IIllllllIlIIIIlllIlIlIlll;
    }
    
    @Override
    public lIIIllIIlllIlIIIIIIllIllI IlIIIIlIlllIllIlIlIIlIlIl() {
        return lIIIllIIlllIlIIIIIIllIllI.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    protected void IIIlIIllllIIllllllIlIIIll(final int n) {
        switch (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(3)) {
            case 0: {
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.IlllIllIlIIIIlIIlIIllIIIl, 1);
                break;
            }
            case 1: {
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.IlllIlIlllIlIlllIIlllIlIl, 1);
                break;
            }
            case 2: {
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.IlIIIIlIlllIllIlIlIIlIlIl, 1);
                break;
            }
        }
    }
    
    @Override
    protected void lIIIlIlIIllIIlllIIIlIIllI() {
        super.lIIIlIlIIllIIlllIIIlIIllI();
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < ((this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl) ? (0.026250001f * 1.9047619f) : (0.003142857f * 3.1818182f))) {
            if (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(3) == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIlllIIIIlllIllIlIlllIl));
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIIIlIIllIIlIIlIIIlIIllI));
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        if (this.l_()) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("IsBaby", true);
        }
        if (this.IllIIIIIllllIlllIIlIIllIl()) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("IsVillager", true);
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ConversionTime", this.IlIllIllllIIIlIIIllIIIllI() ? this.IlIIlllIIlIlIIIlIlllllIll : -1);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CanBreakDoors", this.IIIlIllIIIlllIIlIIllIlIII());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        if (ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("IsBaby")) {
            this.lIIIIllIIlIlIllIIIlIllIlI(true);
        }
        if (ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("IsVillager")) {
            this.IlllIllIlIIIIlIIlIIllIIIl(true);
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("ConversionTime", 99) && ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("ConversionTime") > -1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("ConversionTime"));
        }
        this.sendClickBlockToController(ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("CanBreakDoors"));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(entityLivingBase);
        if ((this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IlllIIIlIlllIllIlIIlllIlI || this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl) && entityLivingBase instanceof IlIllIlIlIlIIllIIIlIlIllI) {
            if (this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll != lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl && this.IlIlllIIIIlIllIlllIlIIIll.nextBoolean()) {
                return;
            }
            final IIlIIIIIIlIllIIIIlIIIIlll ilIIIIIIlIllIIIIlIIIIlll = new IIlIIIIIIlIllIIIIlIIIIlll(this.lIIlllIIlIlllllllllIIIIIl);
            ilIIIIIIlIllIIIIlIIIIlll.IlllIllIlIIIIlIIlIIllIIIl(entityLivingBase);
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(entityLivingBase);
            ilIIIIIIlIllIIIIlIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI((lIIIlllIlIIlIIlIIIIllllII)null);
            ilIIIIIIlIllIIIIlIIIIlll.IlllIllIlIIIIlIIlIIllIIIl(true);
            if (entityLivingBase.l_()) {
                ilIIIIIIlIllIIIIlIIIIlll.lIIIIllIIlIlIllIIIlIllIlI(true);
            }
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIIlIllIIIIlIIIIlll);
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(null, 1016, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
        }
    }
    
    @Override
    public lIIIlllIlIIlIIlIIIIllllII lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlllIlIIlIIlIIIIllllII liiIlllIlIIlIIlIIIIllllII) {
        lIIIlllIlIIlIIlIIIIllllII liiiIlIIllIIlIIlIIIlIIllI = super.lIIIIlIIllIIlIIlIIIlIIllI(liiIlllIlIIlIIlIIIIllllII);
        final float liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        this.IIIllIllIlIlllllllIlIlIII(this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 0.5222222f * 1.0531915f * liiiIlIIllIIlIIlIIIlIIllI2);
        if (liiiIlIIllIIlIIlIIIlIIllI == null) {
            liiiIlIIllIIlIIlIIIlIIllI = new IllIlIIIIIIlIIlIllIIllIII(this, this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat() < 18.0f * 0.0027777778f, this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat() < 0.074074075f * 0.675f, null);
        }
        if (liiiIlIIllIIlIIlIIIlIIllI instanceof IllIlIIIIIIlIIlIllIIllIII) {
            final IllIlIIIIIIlIIlIllIIllIII illIlIIIIIIlIIlIllIIllIII = (IllIlIIIIIIlIIlIllIIllIII)liiiIlIIllIIlIIlIIIlIIllI;
            if (illIlIIIIIIlIIlIllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl) {
                this.IlllIllIlIIIIlIIlIIllIIIl(true);
            }
            if (illIlIIIIIIlIIlIllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI) {
                this.lIIIIllIIlIlIllIIIlIllIlI(true);
                if (this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat() < 0.6170212626457214 * 0.08103448459070167) {
                    final List liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllllIIIIlIlIlllllllIIII.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(5, 3, 5), lllIIIlllllllIlIIIlIllIIl.lIIIIIIIIIlIllIIllIlIIlIl);
                    if (!liiiIlIIllIIlIIlIIIlIIllI3.isEmpty()) {
                        final lIllllIIIIlIlIlllllllIIII lIllllIIIIlIlIlllllllIIII = liiiIlIIllIIlIIlIIIlIIllI3.get(0);
                        lIllllIIIIlIlIlllllllIIII.lIIIIllIIlIlIllIIIlIllIlI(true);
                        this.lIIIIlIIllIIlIIlIIIlIIllI((Entity)lIllllIIIIlIlIlllllllIIII);
                    }
                }
                else if (this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat() < 0.09836065769195557 * 0.5083333232336577) {
                    final lIllllIIIIlIlIlllllllIIII lIllllIIIIlIlIlllllllIIII2 = new lIllllIIIIlIlIlllllllIIII(this.lIIlllIIlIlllllllllIIIIIl);
                    lIllllIIIIlIlIlllllllIIII2.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, 0.0f);
                    lIllllIIIIlIlIlllllllIIII2.lIIIIlIIllIIlIIlIIIlIIllI((lIIIlllIlIIlIIlIIIIllllII)null);
                    lIllllIIIIlIlIlllllllIIII2.lIIIIllIIlIlIllIIIlIllIlI(true);
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllllIIIIlIlIlllllllIIII2);
                    this.lIIIIlIIllIIlIIlIIIlIIllI((Entity)lIllllIIIIlIlIlllllllIIII2);
                }
            }
        }
        this.sendClickBlockToController(this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < liiiIlIIllIIlIIlIIIlIIllI2 * (0.45555556f * 0.2195122f));
        this.lIIIlIlIIllIIlllIIIlIIllI();
        this.lIIIlIIlIIIIIllIIlIlIlIII();
        if (this.IlllIIIlIlllIllIlIIlllIlI(4) == null) {
            final Calendar illllIllllIlIIIlIIIllllll = this.lIIlllIIlIlllllllllIIIIIl.IllllIllllIlIIIlIIIllllll();
            if (illllIllllIlIIIlIIIllllll.get(2) + 1 == 10 && illllIllllIlIIIlIIIllllll.get(5) == 31 && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 11.5f * 0.02173913f) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(4, new lIlIlIlIlIllllIlllIIIlIlI((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 1.0f * 0.1f) ? IllllllIllIIlllIllIIlIIll.llIIlllIlIIlIIIIIlIllllll : IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll));
                this.IlllIllIlIIIIlIIlIIllIIIl[4] = 0.0f;
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IlllIIIlIlllIllIlIIlllIlI).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Random spawn bonus", this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * (7.666666507720947 * 0.006521739362825298), 0));
        final double n = this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * (0.3030303120613098 * 4.949999852478508) * this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        if (n > 1.0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIIIIIIlIllIIllIlIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Random zombie-spawn bonus", n, 2));
        }
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < liiiIlIIllIIlIIlIIIlIIllI2 * (0.80597013f * 0.06203704f)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIIIIlIllIIIIlIIIIlll.llIIIlllllIlllIIllIlIIlII).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Leader zombie bonus", this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * (0.5263158082962036 * 0.4749999830126769) + 0.625 * 0.8, 0));
            this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII("Leader zombie bonus", this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * 3 + 1.0, 2));
            this.sendClickBlockToController(true);
        }
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiiiIlIIllIlIlIllIIIIll = lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll();
        if (liiiiiIlIIllIlIlIllIIIIll != null && liiiiiIlIIllIlIlIllIIIIll.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIIIIlIIllllllIIIlIlIIl && liiiiiIlIIllIlIlIllIIIIll.IlllIllIlIIIIlIIlIIllIIIl() == 0 && this.IllIIIIIllllIlllIIlIIllIl() && this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IllIllIIIlIIlllIIIllIllII)) {
            if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = liiiiiIlIIllIlIlIllIIIIll;
                --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            }
            if (liiiiiIlIIllIlIlIllIIIIll.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
                lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, null);
            }
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll.nextInt(2401) + 3600);
            }
            return true;
        }
        return false;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int ilIIlllIIlIlIIIlIlllllIll) {
        this.IlIIlllIIlIlIIIlIlllllIll = ilIIlllIIlIlIIIlIlllllIll;
        this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl(14, 1);
        this.llIlIIIlIIIIlIlllIlIIIIll(IIIlIlIIIIIIIlllllIlIllIl.IllIllIIIlIIlllIIIllIllII.IllIIlllIllIlIllIlIIIIIII);
        this.lIIIIlIIllIIlIIlIIIlIIllI(new llIlIlIIlIlIllllIIlIIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IIIllIllIlIlllllllIlIlIII.IllIIlllIllIlIllIlIIIIIII, ilIIlllIIlIlIIIlIlllllIll, Math.min(this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI() - 1, 0)));
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)16);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        if (b == 16) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + 0.6999999833106999 * 0.7142857313156128, this.IllIlIIIIlllIIllIIlllIIlI + 9.75 * 0.05128205128205128, this.IllIlIlIllllIlIIllllIIlll + 0.05000000074505806 * 9.99999985098839, "mob.zombie.remedy", 1.0f + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat(), this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (2.8f * 0.25f) + 0.07159091f * 4.1904764f, false);
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(b);
        }
    }
    
    @Override
    protected boolean IlIlIIIlllIlIllIlIIIlllIl() {
        return !this.IlIllIllllIIIlIIIllIIIllI();
    }
    
    public boolean IlIllIllllIIIlIIIllIIIllI() {
        return this.lIIIlllIlIlllIIIIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(14) == 1;
    }
    
    protected void llllIIllIIlIIllIIIllIlIlI() {
        final IlIllIlIlIlIIllIIIlIlIllI ilIllIlIlIlIIllIIIlIlIllI = new IlIllIlIlIlIIllIIIlIlIllI(this.lIIlllIIlIlllllllllIIIIIl);
        ilIllIlIlIlIIllIIIlIlIllI.IlllIllIlIIIIlIIlIIllIIIl(this);
        ilIllIlIlIlIIllIIIlIlIllI.lIIIIlIIllIIlIIlIIIlIIllI((lIIIlllIlIIlIIlIIIIllllII)null);
        ilIllIlIlIlIIllIIIlIlIllI.llllIIllIIlIIllIIIllIlIlI();
        if (this.l_()) {
            ilIllIlIlIlIIllIIIlIlIllI.updateDebugProfilerName(-24000);
        }
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIllIlIlIlIIllIIIlIlIllI);
        ilIllIlIlIlIIllIIIlIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(new llIlIlIIlIlIllllIIlIIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IlIlllIIIIllIllllIllIIlIl.IllIIlllIllIlIllIlIIIIIII, 200, 0));
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(null, 1017, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
    }
    
    protected int llIllllIIIIIlIllIlIIIllIl() {
        int n = 1;
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 0.11392405f * 0.08777778f) {
            for (int n2 = 0, n3 = (int)this.IIIlIIlIlIIIlllIIlIllllll - 4; n3 < (int)this.IIIlIIlIlIIIlllIIlIllllll + 4 && n2 < 14; ++n3) {
                for (int n4 = (int)this.IllIlIIIIlllIIllIIlllIIlI - 4; n4 < (int)this.IllIlIIIIlllIIllIIlllIIlI + 4 && n2 < 14; ++n4) {
                    for (int n5 = (int)this.IllIlIlIllllIlIIllllIIlll - 4; n5 < (int)this.IllIlIlIllllIlIIllllIIlll + 4 && n2 < 14; ++n5) {
                        final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(n3, n4, n5);
                        if (block == IllllllIllIIlllIllIIlIIll.IlIlIIIIIllIlIlIIllIlIIIl || block == IllllllIllIIlllIllIIlIIll.IllIlIlIllllIlIIllllIIlll) {
                            if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 0.28076926f * 1.0684931f) {
                                ++n;
                            }
                            ++n2;
                        }
                    }
                }
            }
        }
        return n;
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final boolean b) {
        this.IIIIllIlIIIllIlllIlllllIl(b ? (0.62068963f * 0.8055556f) : 1.0f);
    }
    
    @Override
    protected final void IIIIllIIllIIIIllIllIIIlIl(final float llllllIIIIIlllllIllIlIllI, final float illlIIllllllllIlIlIlllllI) {
        final boolean b = this.llllllIIIIIlllllIllIlIllI > 0.0f && this.IlllIIllllllllIlIlIlllllI > 0.0f;
        this.llllllIIIIIlllllIllIlIllI = llllllIIIIIlllllIllIlIllI;
        this.IlllIIllllllllIlIlIlllllI = illlIIllllllllIlIlIlllllI;
        if (!b) {
            this.IIIIllIlIIIllIlllIlllllIl(1.0f);
        }
    }
    
    protected final void IIIIllIlIIIllIlllIlllllIl(final float n) {
        super.IIIIllIIllIIIIllIllIIIlIl(this.llllllIIIIIlllllIllIlIllI * n, this.IlllIIllllllllIlIlIlllllI * n);
    }
    
    static {
        llIIIlllllIlllIIllIlIIlII = new IIlIllllllIlIlIlIllIllIlI("zombie.spawnReinforcements", 0.0, 0.0, 1.0).lIIIIlIIllIIlIIlIIIlIIllI("Spawn Reinforcements Chance");
        lIIIlIlIIIlIlIlllIlIlllII = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
        llIlIlIIIIIIIlllIIIllIlll = new IllIIlIIllIlllIIIIIllllII(IIlIIIIIIlIllIIIIlIIIIlll.lIIIlIlIIIlIlIlllIlIlllII, "Baby speed boost", 4.294117450714111 * 0.11643836148842414, 1);
    }
}
