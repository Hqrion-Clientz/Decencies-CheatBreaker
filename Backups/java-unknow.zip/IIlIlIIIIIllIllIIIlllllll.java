import com.google.gson.JsonArray;
import com.google.gson.JsonParseException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIIIllIllIIIlllllll
{
    public static float lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject, final String s, final float n) {
        final JsonElement value = jsonObject.get(s);
        return (value == null) ? n : value.getAsFloat();
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject, final String s, final boolean b) {
        final JsonElement value = jsonObject.get(s);
        return (value == null) ? b : value.getAsBoolean();
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject, final String s) {
        return lIIIIlIIllIIlIIlIIIlIIllI(jsonObject, s, null);
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject, final String s, final String s2) {
        final JsonElement value = jsonObject.get(s);
        return (value == null) ? s2 : value.getAsString();
    }
    
    public static float[] lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final int n) {
        return lIIIIlIIllIIlIIlIIIlIIllI(jsonElement, n, (float[])null);
    }
    
    public static float[] lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final int i, final float[] array) {
        if (jsonElement == null) {
            return array;
        }
        final JsonArray asJsonArray = jsonElement.getAsJsonArray();
        if (asJsonArray.size() != i) {
            throw new JsonParseException("Wrong array length: " + asJsonArray.size() + ", should be: " + i + ", array: " + asJsonArray);
        }
        final float[] array2 = new float[asJsonArray.size()];
        for (int j = 0; j < array2.length; ++j) {
            array2[j] = asJsonArray.get(j).getAsFloat();
        }
        return array2;
    }
    
    public static int[] lIIIIIIIIIlIllIIllIlIIlIl(final JsonElement jsonElement, final int n) {
        return lIIIIlIIllIIlIIlIIIlIIllI(jsonElement, n, (int[])null);
    }
    
    public static int[] lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final int i, final int[] array) {
        if (jsonElement == null) {
            return array;
        }
        final JsonArray asJsonArray = jsonElement.getAsJsonArray();
        if (asJsonArray.size() != i) {
            throw new JsonParseException("Wrong array length: " + asJsonArray.size() + ", should be: " + i + ", array: " + asJsonArray);
        }
        final int[] array2 = new int[asJsonArray.size()];
        for (int j = 0; j < array2.length; ++j) {
            array2[j] = asJsonArray.get(j).getAsInt();
        }
        return array2;
    }
}
