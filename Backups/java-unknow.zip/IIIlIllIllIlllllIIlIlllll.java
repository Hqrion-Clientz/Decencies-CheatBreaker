import com.google.common.collect.Maps;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIlIllIllIlllllIIlIlllll
{
    lIIIIlIIllIIlIIlIIIlIIllI("LEGACY", 0, "LEGACY", 0, "legacy"), 
    lIIIIIIIIIlIllIIllIlIIlIl("MOJANG", 1, "MOJANG", 1, "mojang");
    
    private static final Map IlllIIIlIlllIllIlIIlllIlI;
    private final String IIIIllIlIIIllIlllIlllllIl;
    private static final IIIlIllIllIlllllIIlIlllll[] IIIIllIIllIIIIllIllIIIlIl;
    
    private IIIlIllIllIlllllIIlIlllll(final String name, final int ordinal, final String s, final int n, final String iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public static IIIlIllIllIlllllIIlIlllll lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return IIIlIllIllIlllllIIlIlllll.IlllIIIlIlllIllIlIIlllIlI.get(s.toLowerCase());
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = Maps.newHashMap();
        IIIIllIIllIIIIllIllIIIlIl = new IIIlIllIllIlllllIIlIlllll[] { IIIlIllIllIlllllIIlIlllll.lIIIIlIIllIIlIIlIIIlIIllI, IIIlIllIllIlllllIIlIlllll.lIIIIIIIIIlIllIIllIlIIlIl };
        for (final IIIlIllIllIlllllIIlIlllll iiIlIllIllIlllllIIlIlllll : values()) {
            IIIlIllIllIlllllIIlIlllll.IlllIIIlIlllIllIlIIlllIlI.put(iiIlIllIllIlllllIIlIlllll.IIIIllIlIIIllIlllIlllllIl, iiIlIllIllIlllllIIlIlllll);
        }
    }
}
