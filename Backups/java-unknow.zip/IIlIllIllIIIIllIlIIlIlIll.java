// 
// Decompiled by Procyon v0.5.36
// 

public interface IIlIllIllIIIIllIlIIlIlIll extends IllllIIlIIIlIlIllIIllllII
{
    void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlIllIlIIIIIlllIIlll p0);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IIllIlIIIlIlIIllllIIlllIl p0);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIlIIIIIIlIllIIIlIlIII p0);
}
