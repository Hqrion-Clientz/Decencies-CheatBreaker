import java.beans.ConstructorProperties;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlIlIIIlllIIlIllllll extends CBEvent
{
    private final float lIIIIlIIllIIlIIlIIIlIIllI;
    
    public float lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @ConstructorProperties({ "partialTicks" })
    public IIIlIIlIlIIIlllIIlIllllll(final float liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
}
