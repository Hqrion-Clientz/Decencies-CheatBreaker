import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIllIIlIlIIlIIllIIIIl extends llIIIlIIIlllIllIIIIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private llIlllIIllIIllllIlIllIlIl IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIlIIllIIlIlIIlIIllIIIIl() {
        super(new llIlllIIllIIllllIlIllIlIl(), 2.0454545f * 0.24444444f);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl = (llIlllIIllIIllllIlIllIlIl)super.lIIlIlIllIIlIIIlIIIlllIII);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIIllIlllIlIIllIIIllII liiiiIllIlllIlIIllIIIllII, final float n) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(liiiiIllIlllIlIIllIIIllII, n);
        final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll, 1);
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() instanceof llIllIlIlIIIIlIIIIllIllll) {
            GL11.glPushMatrix();
            this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI(1.025f * 0.06097561f);
            if (RenderBlocks.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()).IlIlllIIIIllIllllIllIIlIl())) {
                final float n2 = 0.015384615f * 40.625f;
                GL11.glTranslatef(0.0f, 0.05f * -6.875f, 0.0f);
                GL11.glRotatef((float)90, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(n2, -n2, n2);
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl.itemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(liiiiIllIlllIlIIllIIIllII, lIlIlIlIlIllllIlllIIIlIlI, 0);
            GL11.glPopMatrix();
        }
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIIllIlllIlIIllIIIllII liiiiIllIlllIlIIllIIIllII) {
        return IIIlIIllIIlIlIIlIIllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIIIIllIlllIlIIllIIIllII)entityLivingBase, n);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((lIIIIIllIlllIlIIllIIIllII)entity);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/snowman.png");
    }
}
