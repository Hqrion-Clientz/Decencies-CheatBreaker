import java.util.HashMap;
import java.nio.channels.SelectableChannel;
import java.nio.ByteBuffer;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.net.ServerSocket;
import java.nio.channels.ClosedByInterruptException;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.io.IOException;
import java.net.SocketAddress;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.List;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.net.InetSocketAddress;
import java.util.Collection;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIlIIIIIIIIlIlllIllIIIlll extends lIIIlIlIllIlIIIlIIIlIlIIl implements Runnable
{
    public static int lIIIIlIIllIIlIIlIIIlIIllI;
    private final Collection IIIIllIlIIIllIlllIlllllIl;
    private final InetSocketAddress IIIIllIIllIIIIllIllIIIlIl;
    private ServerSocketChannel IlIlIIIlllIIIlIlllIlIllIl;
    private Selector IIIllIllIlIlllllllIlIlIII;
    private List IllIIIIIIIlIlIllllIIllIII;
    private Thread lIIIIllIIlIlIllIIIlIllIlI;
    private final AtomicBoolean IlllIllIlIIIIlIIlIIllIIIl;
    protected List lIIIIIIIIIlIllIIllIlIIlIl;
    private List IlIlllIIIIllIllllIllIIlIl;
    private BlockingQueue llIIlllIIIIlllIllIlIlllIl;
    private int lIIlIlIllIIlIIIlIIIlllIII;
    private final AtomicInteger IIIlllIIIllIllIlIIIIIIlII;
    private lIllllIIlIIIllIllIlllllIl llIlIIIlIIIIlIlllIlIIIIll;
    static final /* synthetic */ boolean IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIIIIIIIlIlllIllIIIlll() {
        this(new InetSocketAddress(80), IIlIIIIIIIIlIlllIllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI, null);
    }
    
    public IIlIIIIIIIIlIlllIllIIIlll(final InetSocketAddress inetSocketAddress) {
        this(inetSocketAddress, IIlIIIIIIIIlIlllIllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI, null);
    }
    
    public IIlIIIIIIIIlIlllIllIIIlll(final InetSocketAddress inetSocketAddress, final int n) {
        this(inetSocketAddress, n, null);
    }
    
    public IIlIIIIIIIIlIlllIllIIIlll(final InetSocketAddress inetSocketAddress, final List list) {
        this(inetSocketAddress, IIlIIIIIIIIlIlllIllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI, list);
    }
    
    public IIlIIIIIIIIlIlllIllIIIlll(final InetSocketAddress inetSocketAddress, final int n, final List list) {
        this(inetSocketAddress, n, list, new HashSet());
    }
    
    public IIlIIIIIIIIlIlllIllIIIlll(final InetSocketAddress iiiIllIIllIIIIllIllIIIlIl, final int initialCapacity, final List illIIIIIIIlIlIllllIIllIII, final Collection iiiIllIlIIIllIlllIlllllIl) {
        this.IlllIllIlIIIIlIIlIIllIIIl = new AtomicBoolean(false);
        this.lIIlIlIllIIlIIIlIIIlllIII = 0;
        this.IIIlllIIIllIllIlIIIIIIlII = new AtomicInteger(0);
        this.llIlIIIlIIIIlIlllIlIIIIll = new llIlIIlIIlllIIlllIlIIIlll();
        if (iiiIllIIllIIIIllIllIIIlIl == null || initialCapacity < 1 || iiiIllIlIIIllIlllIlllllIl == null) {
            throw new IllegalArgumentException("address and connectionscontainer must not be null and you need at least 1 decoder");
        }
        if (illIIIIIIIlIlIllllIIllIII == null) {
            this.IllIIIIIIIlIlIllllIIllIII = Collections.emptyList();
        }
        else {
            this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        }
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.sendClickBlockToController(false);
        this.lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IlIlllIIIIllIllllIllIIlIl = new LinkedList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList(initialCapacity);
        this.llIIlllIIIIlllIllIlIlllIl = new LinkedBlockingQueue();
        for (int i = 0; i < initialCapacity; ++i) {
            final llIIIllIIlIIllllIIlIIIIlI llIIIllIIlIIllllIIlIIIIlI = new llIIIllIIlIIllllIIlIIIIlI(this);
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(llIIIllIIlIIllllIIlIIIIlI);
            llIIIllIIlIIllllIIlIIIIlI.start();
        }
    }
    
    public void updateTick() {
        if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
            throw new IllegalStateException(this.getClass().getName() + " can only be started once.");
        }
        new Thread(this).start();
    }
    
    public void updateDebugProfilerName(final int n) {
        if (!this.IlllIllIlIIIIlIIlIIllIIIl.compareAndSet(false, true)) {
            return;
        }
        final ArrayList<llIlIIIIIlllllllIlllIIIII> list;
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            list = (ArrayList<llIlIIIIIlllllllIlllIIIII>)new ArrayList<Object>(this.IIIIllIlIIIllIlllIlllllIl);
        }
        final Iterator<Object> iterator = list.iterator();
        while (iterator.hasNext()) {
            iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(1001);
        }
        this.llIlIIIlIIIIlIlllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI();
        synchronized (this) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                this.IIIllIllIlIlllllllIlIlIII.wakeup();
                this.lIIIIllIIlIlIllIIIlIllIlI.join(n);
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.updateDebugProfilerName(0);
    }
    
    public Collection IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public InetSocketAddress lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int getLimitFramerate() {
        int n = this.lIIIIllIIlIlIllIIIlIllIlI().getPort();
        if (n == 0 && this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            n = this.IlIlIIIlllIIIlIlllIlIllIl.socket().getLocalPort();
        }
        return n;
    }
    
    public List IlIlllIIIIllIllllIllIIlIl() {
        return Collections.unmodifiableList((List<?>)this.IllIIIIIIIlIlIllllIIllIII);
    }
    
    public void run() {
        synchronized (this) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                throw new IllegalStateException(this.getClass().getName() + " can only be started once.");
            }
            this.lIIIIllIIlIlIllIIIlIllIlI = Thread.currentThread();
            if (this.IlllIllIlIIIIlIIlIIllIIIl.get()) {
                return;
            }
        }
        this.lIIIIllIIlIlIllIIIlIllIlI.setName("WebsocketSelector" + this.lIIIIllIIlIlIllIIIlIllIlI.getId());
        try {
            (this.IlIlIIIlllIIIlIlllIlIllIl = ServerSocketChannel.open()).configureBlocking(false);
            final ServerSocket socket = this.IlIlIIIlllIIIlIlllIlIllIl.socket();
            socket.setReceiveBufferSize(IlIIlIllIlIIlllllIllIlIlI.IlllIIIlIlllIllIlIIlllIlI);
            socket.setReuseAddress(this.f_());
            socket.bind(this.IIIIllIIllIIIIllIllIIIlIl);
            this.IIIllIllIlIlllllllIlIlIII = Selector.open();
            this.IlIlIIIlllIIIlIlllIlIllIl.register(this.IIIllIllIlIlllllllIlIlIII, this.IlIlIIIlllIIIlIlllIlIllIl.validOps());
            this.d_();
            this.setIngameFocus();
        }
        catch (IOException ex) {
            this.IlllIIIlIlllIllIlIIlllIlI(null, ex);
            if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
                final Iterator<llIIIllIIlIIllllIIlIIIIlI> iterator = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
                while (iterator.hasNext()) {
                    iterator.next().interrupt();
                }
            }
            return;
        }
        try {
            int n = 5;
            int n2 = 0;
            while (!this.lIIIIllIIlIlIllIIIlIllIlI.isInterrupted() && n != 0) {
                SelectionKey selectionKey = null;
                IlIIlIllIlIIlllllIllIlIlI ilIIlIllIlIIlllllIllIlIlI = null;
                try {
                    if (this.IlllIllIlIIIIlIIlIIllIIIl.get()) {
                        n2 = 5;
                    }
                    if (this.IIIllIllIlIlllllllIlIlIII.select(n2) == 0 && this.IlllIllIlIIIIlIIlIIllIIIl.get()) {
                        --n;
                    }
                    final Iterator<SelectionKey> iterator2 = this.IIIllIllIlIlllllllIlIlIII.selectedKeys().iterator();
                    while (iterator2.hasNext()) {
                        selectionKey = iterator2.next();
                        ilIIlIllIlIIlllllIllIlIlI = null;
                        if (!selectionKey.isValid()) {
                            continue;
                        }
                        if (selectionKey.isAcceptable()) {
                            if (!this.lIIIIlIIllIIlIIlIIIlIIllI(selectionKey)) {
                                selectionKey.cancel();
                            }
                            else {
                                final SocketChannel accept = this.IlIlIIIlllIIIlIlllIlIllIl.accept();
                                if (accept == null) {
                                    continue;
                                }
                                accept.configureBlocking(false);
                                final Socket socket2 = accept.socket();
                                socket2.setTcpNoDelay(this.e_());
                                socket2.setKeepAlive(true);
                                final IlIIlIllIlIIlllllIllIlIlI liiiiiiiiIlIllIIllIlIIlIl = this.llIlIIIlIIIIlIlllIlIIIIll.lIIIIIIIIIlIllIIllIlIIlIl(this, this.IllIIIIIIIlIlIllllIIllIII);
                                liiiiiiiiIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII = accept.register(this.IIIllIllIlIlllllllIlIlIII, 1, liiiiiiiiIlIllIIllIlIIlIl);
                                try {
                                    liiiiiiiiIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII = this.llIlIIIlIIIIlIlllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(accept, liiiiiiiiIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII);
                                    iterator2.remove();
                                    this.IIIIllIlIIIllIlllIlllllIl(liiiiiiiiIlIllIIllIlIIlIl);
                                }
                                catch (IOException ex2) {
                                    if (liiiiiiiiIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII != null) {
                                        liiiiiiiiIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII.cancel();
                                    }
                                    this.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII, null, ex2);
                                }
                            }
                        }
                        else {
                            if (selectionKey.isReadable()) {
                                ilIIlIllIlIIlllllIllIlIlI = (IlIIlIllIlIIlllllIllIlIlI)selectionKey.attachment();
                                final ByteBuffer llIlIIIlIIIIlIlllIlIIIIll = this.llIlIIIlIIIIlIlllIlIIIIll();
                                if (ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII == null) {
                                    if (selectionKey != null) {
                                        selectionKey.cancel();
                                    }
                                    this.lIIIIlIIllIIlIIlIIIlIIllI(selectionKey, ilIIlIllIlIIlllllIllIlIlI, new IOException());
                                    continue;
                                }
                                try {
                                    if (IlllllIllIIIIllllllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll, ilIIlIllIlIIlllllIllIlIlI, ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII)) {
                                        if (llIlIIIlIIIIlIlllIlIIIIll.hasRemaining()) {
                                            ilIIlIllIlIIlllllIllIlIlI.IlIlIIIlllIIIlIlllIlIllIl.put(llIlIIIlIIIIlIlllIlIIIIll);
                                            this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI);
                                            iterator2.remove();
                                            if (ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII instanceof llIIIIIlIllllIIIlIlllIIIl && ((llIIIIIlIllllIIIlIlllIIIl)ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII).IlllIIIlIlllIllIlIIlllIlI()) {
                                                this.IlIlllIIIIllIllllIllIIlIl.add(ilIIlIllIlIIlllllIllIlIlI);
                                            }
                                        }
                                        else {
                                            this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll);
                                        }
                                    }
                                    else {
                                        this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll);
                                    }
                                }
                                catch (IOException ex3) {
                                    this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll);
                                    throw ex3;
                                }
                            }
                            if (!selectionKey.isWritable()) {
                                continue;
                            }
                            ilIIlIllIlIIlllllIllIlIlI = (IlIIlIllIlIIlllllIllIlIlI)selectionKey.attachment();
                            if (!IlllllIllIIIIllllllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII) || !selectionKey.isValid()) {
                                continue;
                            }
                            selectionKey.interestOps(1);
                        }
                    }
                    while (!this.IlIlllIIIIllIllllIllIIlIl.isEmpty()) {
                        ilIIlIllIlIIlllllIllIlIlI = this.IlIlllIIIIllIllllIllIIlIl.remove(0);
                        final llIIIIIlIllllIIIlIlllIIIl llIIIIIlIllllIIIlIlllIIIl = (llIIIIIlIllllIIIlIlllIIIl)ilIIlIllIlIIlllllIllIlIlI.IllIIIIIIIlIlIllllIIllIII;
                        final ByteBuffer llIlIIIlIIIIlIlllIlIIIIll2 = this.llIlIIIlIIIIlIlllIlIIIIll();
                        try {
                            if (IlllllIllIIIIllllllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll2, ilIIlIllIlIIlllllIllIlIlI, llIIIIIlIllllIIIlIlllIIIl)) {
                                this.IlIlllIIIIllIllllIllIIlIl.add(ilIIlIllIlIIlllllIllIlIlI);
                            }
                            if (llIlIIIlIIIIlIlllIlIIIIll2.hasRemaining()) {
                                ilIIlIllIlIIlllllIllIlIlI.IlIlIIIlllIIIlIlllIlIllIl.put(llIlIIIlIIIIlIlllIlIIIIll2);
                                this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI);
                            }
                            else {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll2);
                            }
                        }
                        catch (IOException ex4) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIIIlIlllIlIIIIll2);
                            throw ex4;
                        }
                    }
                }
                catch (CancelledKeyException ex9) {}
                catch (ClosedByInterruptException ex10) {
                    return;
                }
                catch (IOException ex5) {
                    if (selectionKey != null) {
                        selectionKey.cancel();
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(selectionKey, ilIIlIllIlIIlllllIllIlIlI, ex5);
                }
                catch (InterruptedException ex11) {
                    return;
                }
            }
        }
        catch (RuntimeException ex6) {
            this.IlllIIIlIlllIllIlIIlllIlI(null, ex6);
        }
        finally {
            this.c_();
            if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
                final Iterator<llIIIllIIlIIllllIIlIIIIlI> iterator3 = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
                while (iterator3.hasNext()) {
                    iterator3.next().interrupt();
                }
            }
            if (this.IIIllIllIlIlllllllIlIlIII != null) {
                try {
                    this.IIIllIllIlIlllllllIlIlIII.close();
                }
                catch (IOException ex7) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(null, ex7);
                }
            }
            if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
                try {
                    this.IlIlIIIlllIIIlIlllIlIllIl.close();
                }
                catch (IOException ex8) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(null, ex8);
                }
            }
        }
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        if (this.IIIlllIIIllIllIlIIIIIIlII.get() >= 2 * this.lIIIIIIIIIlIllIIllIlIIlIl.size() + 1) {
            return;
        }
        this.IIIlllIIIllIllIlIIIIIIlII.incrementAndGet();
        this.llIIlllIIIIlllIllIlIlllIl.put(this.llIIlllIIIIlllIllIlIlllIl());
    }
    
    protected void IIIIllIIllIIIIllIllIIIlIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
    }
    
    public ByteBuffer llIIlllIIIIlllIllIlIlllIl() {
        return ByteBuffer.allocate(IlIIlIllIlIIlllllIllIlIlI.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIllIlIIlllllIllIlIlI ilIIlIllIlIIlllllIllIlIlI) {
        if (ilIIlIllIlIIlllllIllIlIlI.lIIIIllIIlIlIllIIIlIllIlI == null) {
            ilIIlIllIlIIlllllIllIlIlI.lIIIIllIIlIlIllIIIlIllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl.get(this.lIIlIlIllIIlIIIlIIIlllIII % this.lIIIIIIIIIlIllIIllIlIIlIl.size());
            ++this.lIIlIlIllIIlIIIlIIIlllIII;
        }
        ilIIlIllIlIIlllllIllIlIlI.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI);
    }
    
    private ByteBuffer llIlIIIlIIIIlIlllIlIIIIll() {
        return this.llIIlllIIIIlllIllIlIlllIl.take();
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer byteBuffer) {
        if (this.llIIlllIIIIlllIllIlIlllIl.size() > this.IIIlllIIIllIllIlIIIIIIlII.intValue()) {
            return;
        }
        this.llIIlllIIIIlllIllIlIlllIl.put(byteBuffer);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final SelectionKey selectionKey, final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final IOException obj) {
        if (llIlIIIIIlllllllIlllIIIII != null) {
            llIlIIIIIlllllllIlllIIIII.lIIIIIIIIIlIllIIllIlIIlIl(1006, obj.getMessage());
        }
        else if (selectionKey != null) {
            final SelectableChannel channel = selectionKey.channel();
            if (channel != null && channel.isOpen()) {
                try {
                    channel.close();
                }
                catch (IOException ex) {}
                if (IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                    System.out.println("Connection closed because of " + obj);
                }
            }
        }
    }
    
    private void IlllIIIlIlllIllIlIIlllIlI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final Exception ex) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, ex);
        try {
            this.lIIIIIIIIIlIllIIllIlIIlIl();
        }
        catch (IOException ex2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(null, ex2);
        }
        catch (InterruptedException ex3) {
            Thread.currentThread().interrupt();
            this.lIIIIIIIIIlIllIIllIlIIlIl(null, ex3);
        }
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final String s) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, s);
    }
    
    @Deprecated
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final IFramedata framedata) {
        this.IIIIllIlIIIllIlllIlllllIl(llIlIIIIIlllllllIlllIIIII, framedata);
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final ByteBuffer byteBuffer) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, byteBuffer);
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final llIIlIlIIllIlIIIIIIllIIII llIIlIlIIllIlIIIIIIllIIII) {
        if (this.IIIllIllIlIlllllllIlIlIII(llIlIIIIIlllllllIlllIIIII)) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, (lllIlllIIIIIllllIlIIIIIll)llIIlIlIIllIlIIIIIIllIIII);
        }
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final int n, final String s, final boolean b) {
        this.IIIllIllIlIlllllllIlIlIII.wakeup();
        try {
            if (this.IlIlIIIlllIIIlIlllIlIllIl(llIlIIIIIlllllllIlllIIIII)) {
                this.IIIIllIlIIIllIlllIlllllIl(llIlIIIIIlllllllIlllIIIII, n, s, b);
            }
        }
        finally {
            try {
                this.IIIIllIIllIIIIllIllIIIlIl(llIlIIIIIlllllllIlllIIIII);
            }
            catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
    }
    
    protected boolean IlIlIIIlllIIIlIlllIlIllIl(final llIlIIIIIlllllllIlllIIIII obj) {
        boolean remove = false;
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            if (this.IIIIllIlIIIllIlllIlllllIl.contains(obj)) {
                remove = this.IIIIllIlIIIllIlllIlllllIl.remove(obj);
            }
            else if (IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                System.out.println("Removing connection which is not in the connections collection! Possible no handshake recieved! " + obj);
            }
        }
        if (this.IlllIllIlIIIIlIIlIIllIIIl.get() && this.IIIIllIlIIIllIlllIlllllIl.size() == 0) {
            this.lIIIIllIIlIlIllIIIlIllIlI.interrupt();
        }
        return remove;
    }
    
    @Override
    public lIlIllllIlllIllllIIlIIIII lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final IIIIlIlllIlIllIlIllllIllI iiiIlIlllIlIllIlIllllIllI, final lllIlllIIIIIllllIlIIIIIll lllIlllIIIIIllllIlIIIIIll) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIIIlllllllIlllIIIII, iiiIlIlllIlIllIlIllllIllI, lllIlllIIIIIllllIlIIIIIll);
    }
    
    protected boolean IIIllIllIlIlllllllIlIlIII(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        if (!this.IlllIllIlIIIIlIIlIIllIIIl.get()) {
            synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
                final boolean add = this.IIIIllIlIIIllIlllIlllllIl.add(llIlIIIIIlllllllIlllIIIII);
                if (!IIlIIIIIIIIlIlllIllIIIlll.IlllIIIlIlllIllIlIIlllIlI && !add) {
                    throw new AssertionError();
                }
                return add;
            }
        }
        llIlIIIIIlllllllIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(1001);
        return true;
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final Exception ex) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, ex);
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        final IlIIlIllIlIIlllllIllIlIlI ilIIlIllIlIIlllllIllIlIlI = (IlIIlIllIlIIlllllIllIlIlI)llIlIIIIIlllllllIlllIIIII;
        try {
            ilIIlIllIlIIlllllIllIlIlI.IIIllIllIlIlllllllIlIlIII.interestOps(5);
        }
        catch (CancelledKeyException ex) {
            ilIIlIllIlIIlllllIllIlIlI.IIIIllIIllIIIIllIllIIIlIl.clear();
        }
        this.IIIllIllIlIlllllllIlIlIII.wakeup();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final int n, final String s) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIIIIlllllllIlllIIIII, n, s);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final int n, final String s, final boolean b) {
        this.IlllIIIlIlllIllIlIIlllIlI(llIlIIIIIlllllllIlllIIIII, n, s, b);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final int n, final String s) {
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final int n, final String s, final boolean b) {
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final lIllllIIlIIIllIllIlllllIl llIlIIIlIIIIlIlllIlIIIIll) {
        this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    public final llIlIlllllIlIIIIlllIIIIII lIIlIlIllIIlIIIlIIIlllIII() {
        return this.llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final SelectionKey selectionKey) {
        return true;
    }
    
    private Socket IllIIIIIIIlIlIllllIIllIII(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        return ((SocketChannel)((IlIIlIllIlIIlllllIllIlIlI)llIlIIIIIlllllllIlllIIIII).IIIllIllIlIlllllllIlIlIII.channel()).socket();
    }
    
    public InetSocketAddress lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        return (InetSocketAddress)this.IllIIIIIIIlIlIllllIIllIII(llIlIIIIIlllllllIlllIIIII).getLocalSocketAddress();
    }
    
    public InetSocketAddress IlllIIIlIlllIllIlIIlllIlI(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII) {
        return (InetSocketAddress)this.IllIIIIIIIlIlIllllIIllIII(llIlIIIIIlllllllIlllIIIII).getRemoteSocketAddress();
    }
    
    public abstract void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII p0, final lllIlllIIIIIllllIlIIIIIll p1);
    
    public abstract void IIIIllIlIIIllIlllIlllllIl(final llIlIIIIIlllllllIlllIIIII p0, final int p1, final String p2, final boolean p3);
    
    public abstract void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII p0, final String p1);
    
    public abstract void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII p0, final Exception p1);
    
    public abstract void setIngameFocus();
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final ByteBuffer byteBuffer) {
    }
    
    @Deprecated
    public void IIIIllIlIIIllIlllIlllllIl(final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII, final IFramedata framedata) {
    }
    
    public void setSection(final String s) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(s, this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte[] array) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte[] array, final Collection collection) {
        if (array == null || collection == null) {
            throw new IllegalArgumentException();
        }
        final HashMap<IIIIlIlllIlIllIlIllllIllI, List> hashMap = (HashMap<IIIIlIlllIlIllIlIllllIllI, List>)new HashMap<Object, List>();
        final ByteBuffer wrap = ByteBuffer.wrap(array);
        synchronized (collection) {
            for (final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII : collection) {
                if (llIlIIIIIlllllllIlllIIIII != null) {
                    final IIIIlIlllIlIllIlIllllIllI iiIlllIIIllIllIlIIIIIIlII = llIlIIIIIlllllllIlllIIIII.IIIlllIIIllIllIlIIIIIIlII();
                    if (!hashMap.containsKey(iiIlllIIIllIllIlIIIIIIlII)) {
                        hashMap.put(iiIlllIIIllIllIlIIIIIIlII, iiIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(wrap, false));
                    }
                    try {
                        llIlIIIIIlllllllIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(hashMap.get(iiIlllIIIllIllIlIIIIIIlII));
                    }
                    catch (IlllllIlIlllllllllIllIIlI illlllIlIlllllllllIllIIlI) {}
                }
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final Collection collection) {
        if (s == null || collection == null) {
            throw new IllegalArgumentException();
        }
        final HashMap<IIIIlIlllIlIllIlIllllIllI, List> hashMap = (HashMap<IIIIlIlllIlIllIlIllllIllI, List>)new HashMap<Object, List>();
        synchronized (collection) {
            for (final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII : collection) {
                if (llIlIIIIIlllllllIlllIIIII != null) {
                    final IIIIlIlllIlIllIlIllllIllI iiIlllIIIllIllIlIIIIIIlII = llIlIIIIIlllllllIlllIIIII.IIIlllIIIllIllIlIIIIIIlII();
                    if (!hashMap.containsKey(iiIlllIIIllIllIlIIIIIIlII)) {
                        hashMap.put(iiIlllIIIllIllIlIIIIIIlII, iiIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(s, false));
                    }
                    try {
                        llIlIIIIIlllllllIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(hashMap.get(iiIlllIIIllIllIlIIIIIIlII));
                    }
                    catch (IlllllIlIlllllllllIllIIlI illlllIlIlllllllllIllIIlI) {}
                }
            }
        }
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = !IIlIIIIIIIIlIlllIllIIIlll.class.desiredAssertionStatus();
        IIlIIIIIIIIlIlllIllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI = Runtime.getRuntime().availableProcessors();
    }
}
