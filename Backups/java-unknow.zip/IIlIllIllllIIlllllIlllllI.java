// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIllllIIlllllIlllllI extends IIlllllllIlllIIllllIIlIll
{
    protected IIlIllIllllIIlllllIlllllI(final Material material) {
        super(material);
        final float n = 0.21604937f * 2.3142858f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.12643678f * 3.9545453f - n, 0.0f, 1.0652174f * 0.46938777f - n, 1.5882353f * 0.31481484f + n, 1.0f, 1.0f * 0.5f + n);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return !lIIIIllIIlIlIllIIIlIllIlI(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 0;
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.IllIIIIIIIlIlIllllIIllIII(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
        final float n = 0.1225f * 1.5306122f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 3.0f * 0.16666667f - n / 2.0f, 0.0f, 1.0f, 0.7411765f * 0.67460316f + n / 2.0f, 1.0f);
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int n) {
        final float n2 = 0.42613637f * 0.44f;
        if ((n & 0x8) != 0x0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 1.0f - n2, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, n2, 1.0f);
        }
        if (lIIIIllIIlIlIllIIIlIllIlI(n)) {
            if ((n & 0x3) == 0x0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 1.0f - n2, 1.0f, 1.0f, 1.0f);
            }
            if ((n & 0x3) == 0x1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, n2);
            }
            if ((n & 0x3) == 0x2) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f - n2, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            }
            if ((n & 0x3) == 0x3) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, n2, 1.0f, 1.0f);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        if (this.IllIIlllIllIlIllIlIIIIIII == Material.IlIlIIIlllIIIlIlllIlIllIl) {
            return true;
        }
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) ^ 0x4, 2);
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, 1003, n, n2, n3, 0);
        return true;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        if ((illlIIIlIlllIllIlIIlllIlI & 0x4) > 0 != b) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlIIIlIlllIllIlIIlllIlI ^ 0x4, 2);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(null, 1003, n, n2, n3, 0);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            int n4 = n;
            int n5 = n3;
            if ((illlIIIlIlllIllIlIIlllIlI & 0x3) == 0x0) {
                n5 = n3 + 1;
            }
            if ((illlIIIlIlllIllIlIIlllIlI & 0x3) == 0x1) {
                --n5;
            }
            if ((illlIIIlIlllIllIlIIlllIlI & 0x3) == 0x2) {
                n4 = n + 1;
            }
            if ((illlIIIlIlllIllIlIIlllIlI & 0x3) == 0x3) {
                --n4;
            }
            if (!IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n4, n2, n5))) {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 0);
            }
            final boolean iiiiiIlIlIlIllllllIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3);
            if (iiiiiIlIlIlIllllllIlllIlI || illlllllIlllIIllllIIlIll.llIlIIIllIIIIlllIlIIIIIlI()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIlIlIlIllllllIlllIlI);
            }
        }
    }
    
    @Override
    public MovingObjectPosition lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, lIllIIIIlllllIIlIllIIIIII, lIllIIIIlllllIIlIllIIIIII2);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final int n8) {
        int n9 = 0;
        if (n4 == 2) {
            n9 = 0;
        }
        if (n4 == 3) {
            n9 = 1;
        }
        if (n4 == 4) {
            n9 = 2;
        }
        if (n4 == 5) {
            n9 = 3;
        }
        if (n4 != 1 && n4 != 0 && n6 > 0.28651688f * 1.745098f) {
            n9 |= 0x8;
        }
        return n9;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, int n, final int n2, int n3, final int n4) {
        if (n4 == 0) {
            return false;
        }
        if (n4 == 1) {
            return false;
        }
        if (n4 == 2) {
            ++n3;
        }
        if (n4 == 3) {
            --n3;
        }
        if (n4 == 4) {
            ++n;
        }
        if (n4 == 5) {
            --n;
        }
        return IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3));
    }
    
    public static boolean lIIIIllIIlIlIllIIIlIllIlI(final int n) {
        return (n & 0x4) != 0x0;
    }
    
    private static boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return (illlllllIlllIIllllIIlIll.IllIIlllIllIlIllIlIIIIIII.IlllIllIlIIIIlIIlIIllIIIl() && illlllllIlllIIllllIIlIll.IlllIllIlIIIIlIIlIIllIIIl()) || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IIllIllIlIIlllllIlIIIlIll || illlllllIlllIIllllIIlIll instanceof lIlIIllIIIIIIIIllIIIIlIII || illlllllIlllIIllllIIlIll instanceof lIIIIllIIIIIllIlllllIIIIl;
    }
}
