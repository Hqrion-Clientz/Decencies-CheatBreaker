import java.io.IOException;

// 
// Decompiled by Procyon v0.5.36
// 

public class GrassColorReloadListener implements IllIllllIIlIllIlIlllllIII
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        try {
            lllIllllIIlIIIIllIlllIlll.lIIIIlIIllIIlIIlIIIlIIllI(lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIllIllIllIIIIlIlllllIlI, GrassColorReloadListener.lIIIIlIIllIIlIIlIIIlIIllI));
        }
        catch (IOException ex) {}
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/colormap/grass.png");
    }
}
