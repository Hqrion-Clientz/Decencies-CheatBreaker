// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIIIlIlIIIlIllIllll extends lllllIlIIllIIlIIlIIIllIIl
{
    public lIIIIllllIlIIIIllIllIIlIl IIIllIllIlIlllllllIlIlIII;
    public lIIIIllllIlIIIIllIllIIlIl IllIIIIIIIlIlIllllIIllIII;
    public lIIIIllllIlIIIIllIllIIlIl lIIIIllIIlIlIllIIIlIllIlI;
    public lIIIIllllIlIIIIllIllIIlIl IlllIllIlIIIIlIIlIIllIIIl;
    public lIIIIllllIlIIIIllIllIIlIl IlIlllIIIIllIllllIllIIlIl;
    public lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl;
    public lIIIIllllIlIIIIllIllIIlIl lIIlIlIllIIlIIIlIIIlllIII;
    
    public IIIllllIIIlIlIIIlIllIllll() {
        this.IIIllIllIlIlllllllIlIlIII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(0, 0).lIIIIlIIllIIlIIlIIIlIIllI(-6, -5, 0.0f, 6, 10, 0);
        this.IllIIIIIIIlIlIllllIIllIII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(16, 0).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -5, 0.0f, 6, 10, 0);
        this.lIIIIllIIlIlIllIIIlIllIlI = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(0, 10).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -4, 0.15873016f * -6.237f, 5, 8, 1);
        this.IlllIllIlIIIIlIIlIIllIIIl = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(12, 10).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -4, -0.01625f * 0.61538464f, 5, 8, 1);
        this.IlIlllIIIIllIllllIllIIlIl = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(24, 10).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -4, 0.0f, 5, 8, 0);
        this.llIIlllIIIIlllIllIlIlllIl = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(24, 10).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -4, 0.0f, 5, 8, 0);
        this.lIIlIlIllIIlIIIlIIIlllIII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIlIIllIIlIIlIIIlIIllI(12, 0).lIIIIlIIllIIlIIlIIIlIIllI(-1, -5, 0.0f, 2, 10, 0);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, -1);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 1.0f);
        this.lIIlIlIllIIlIIIlIIIlllIII.IIIllIllIlIlllllllIlIlIII = 2.2222223f * 0.70685834f;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, n6, entity);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Entity entity) {
        final float iiIllIllIlIlllllllIlIlIII = (MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * (0.053513512f * 0.37373737f)) * (1.15f * 0.08695652f) + 0.71875f * 1.7391304f) * n4;
        this.IIIllIllIlIlllllllIlIlIII.IIIllIllIlIlllllllIlIlIII = 0.64835167f * 4.845507f + iiIllIllIlIlllllllIlIlIII;
        this.IllIIIIIIIlIlIllllIIllIII.IIIllIllIlIlllllllIlIlIII = -iiIllIllIlIlllllllIlIlIII;
        this.lIIIIllIIlIlIllIIIlIllIlI.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.IlllIllIlIIIIlIIlIIllIIIl.IIIllIllIlIlllllllIlIlIII = -iiIllIllIlIlllllllIlIlIII;
        this.IlIlllIIIIllIllllIllIIlIl.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII - iiIllIllIlIlllllllIlIlIII * 2.0f * n2;
        this.llIIlllIIIIlllIllIlIlllIl.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII - iiIllIllIlIlllllllIlIlIII * 2.0f * n3;
        this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII);
        this.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII);
        this.IlIlllIIIIllIllllIllIIlIl.IlllIIIlIlllIllIlIIlllIlI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII);
        this.llIIlllIIIIlllIllIlIlllIl.IlllIIIlIlllIllIlIIlllIlI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII);
    }
}
