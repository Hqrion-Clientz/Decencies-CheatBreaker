// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIlIlllIIIIIlIllIIII extends IIllIlllIIIIllIllIllIlllI
{
    public IIIlllIlIlllIIIIIlIllIIII(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final IIIIIIllIllIIIIIIIIIlIlII iiiiiIllIllIIIIIIIIIlIlII, final String[] array) {
        super(illlllllIlllIIllllIIlIll, iiiiiIllIllIIIIIIIIIlIlII, array);
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return (IIIIIIllIllIIIIIIIIIlIlII.lIIIIllIIlIlIllIIIlIllIlI(n) == 0) ? ((IIIIIIllIllIIIIIIIIIlIlII)this.IlllIllIlIIIIlIIlIIllIIIl).lIIIlllIlIlllIIIIIIIIIlII[0] : ((IIIIIIllIllIIIIIIIIIlIlII)this.IlllIllIlIIIIlIIlIIllIIIl).lIIIIlIIllIIlIIlIIIlIIllI(true, n);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n) {
        final int liiiIllIIlIlIllIIIlIllIlI = IIIIIIllIllIIIIIIIIIlIlII.lIIIIllIIlIlIllIIIlIllIlI(lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl());
        return (liiiIllIIlIlIllIIIlIllIlI != 2 && liiiIllIIlIlIllIIIlIllIlI != 3) ? super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, n) : lllIllllIIlIIIIllIlllIlll.lIIIIlIIllIIlIIlIIIlIIllI(0.6813187003135681 * 0.7338709472819129, 1.0);
    }
}
