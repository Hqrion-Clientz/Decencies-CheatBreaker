import java.util.Iterator;
import com.google.gson.JsonElement;
import java.util.Map;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

// 
// Decompiled by Procyon v0.5.36
// 

@Deprecated
public class IIlIIIIlIlIlllllIIlllIlIl implements Runnable
{
    @Override
    public void run() {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlIlllIIIIllIllllIllIIlIl).openConnection().getInputStream()));
            for (final Map.Entry<String, V> entry : new JsonParser().parse("{\"Cosmetic\": " + bufferedReader.readLine() + "}").getAsJsonObject().entrySet()) {
                if (entry.getKey().equalsIgnoreCase("Cosmetic")) {
                    for (final JsonElement jsonElement : ((JsonElement)entry.getValue()).getAsJsonArray()) {
                        final String asString = jsonElement.getAsJsonObject().get("mc_uuid").getAsString();
                        final String asString2 = jsonElement.getAsJsonObject().get("name").getAsString();
                        final IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl = new IlIlIIIlllIIIlIlllIlIllIl(asString, asString2, jsonElement.getAsJsonObject().get("scale").getAsFloat(), false, jsonElement.getAsJsonObject().get("resourcelocation").getAsString());
                        if (asString2.equalsIgnoreCase("cape")) {
                            CheatBreaker.getInstance().lIIIIIllllIIIIlIlIIIIlIlI().add(ilIlIIIlllIIIlIlllIlIllIl);
                        }
                        else {
                            CheatBreaker.getInstance().lllIIIIIlIllIlIIIllllllII().add(ilIlIIIlllIIIlIlllIlIllIl);
                        }
                    }
                }
            }
            bufferedReader.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
