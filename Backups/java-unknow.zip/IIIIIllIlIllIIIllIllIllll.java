// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllIlIllIIIllIllIllll
{
    private IlllIIIllIlIIlIllIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI;
    private IIIIIIllIlIIIIlIlllIllllI lIIIIIIIIIlIllIIllIlIIlIl;
    private lIlIIlIlIIIIIIlIIIlllIIII IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private IlIlIlllIIllIIllIllllllII IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private lIllIIIIlllllIIlIllIIIIII lIIIIllIIlIlIllIIIlIllIlI;
    private boolean IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    private boolean llIIlllIIIIlllIllIlIlllIl;
    private boolean lIIlIlIllIIlIIIlIIIlllIII;
    
    public IIIIIllIlIllIIIllIllIllll(final IlllIIIllIlIIlIllIIlIlllI liiiIlIIllIIlIIlIIIlIIllI, final IIIIIIllIlIIIIlIlllIllllI liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIllIIlIlIllIIIlIllIlI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 0.0, 0.0);
        this.IlllIllIlIIIIlIIlIIllIIIl = true;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IIIIllIIllIIIIllIllIIIlIl = liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean llIIlllIIIIlllIllIlIlllIl) {
        this.llIIlllIIIIlllIllIlIlllIl = llIIlllIIIIlllIllIlIlllIl;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.llIIlllIIIIlllIllIlIlllIl;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean ilIlllIIIIllIllllIllIIlIl) {
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final boolean illlIllIlIIIIlIIlIIllIIIl) {
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final boolean ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final boolean liIlIlIllIIlIIIlIIIlllIII) {
        this.lIIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII;
    }
    
    public float IlllIIIlIlllIllIlIIlllIlI() {
        return (float)this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    public lIlIIlIlIIIIIIlIIIlllIIII lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
        return this.IlIlllIIIIllIllllIllIIlIl() ? this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, MathHelper.IlllIIIlIlllIllIlIIlllIlI(n), (int)n2, MathHelper.IlllIIIlIlllIllIlIIlllIlI(n3), this.IlllIIIlIlllIllIlIIlllIlI(), this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl, this.llIIlllIIIIlllIllIlIlllIl, this.lIIlIlIllIIlIIIlIIIlllIII) : null;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final double n4) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(MathHelper.IlllIIIlIlllIllIlIIlllIlI(n), (int)n2, MathHelper.IlllIIIlIlllIllIlIIlllIlI(n3)), n4);
    }
    
    public lIlIIlIlIIIIIIlIIIlllIIII lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.IlIlllIIIIllIllllIllIIlIl() ? this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, entity, this.IlllIIIlIlllIllIlIIlllIlI(), this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl, this.llIIlllIIIIlllIllIlIlllIl, this.lIIlIlIllIIlIIIlIIIlllIII) : null;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n) {
        final lIlIIlIlIIIIIIlIIIlllIIII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(entity);
        return liiiIlIIllIIlIIlIIIlIIllI != null && this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIlIlIIIIIIlIIIlllIIII illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl) {
        if (illlIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = null;
            return false;
        }
        if (!illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI)) {
            this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl) {
            this.lIIlIlIllIIlIIIlIIIlllIII();
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl() == 0) {
            return false;
        }
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        final lIllIIIIlllllIIlIllIIIIII liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI();
        this.IllIIIIIIIlIlIllllIIllIII = this.IIIllIllIlIlllllllIlIlIII;
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl = liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl;
        this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI = liiiIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI;
        return true;
    }
    
    public lIlIIlIlIIIIIIlIIIlllIIII IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl() {
        ++this.IIIllIllIlIlllllllIlIlIII;
        if (!this.IlIlIIIlllIIIlIlllIlIllIl()) {
            if (this.IlIlllIIIIllIllllIllIIlIl()) {
                this.IllIIIIIIIlIlIllllIIllIII();
            }
            if (!this.IlIlIIIlllIIIlIlllIlIllIl()) {
                final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
                if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII().lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
                }
            }
        }
    }
    
    private void IllIIIIIIIlIlIllllIIllIII() {
        final lIllIIIIlllllIIlIllIIIIII liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI();
        int iiiIllIlIIIllIlllIlllllIl = this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl();
        for (int i = this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl(); i < this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
            if (this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(i).lIIIIIIIIIlIllIIllIlIIlIl != (int)liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl) {
                iiiIllIlIIIllIlllIlllllIl = i;
                break;
            }
        }
        final float n = this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl * this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl;
        for (int j = this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl(); j < iiiIllIlIIIllIlllIlllllIl; ++j) {
            if (liiiIllIIlIlIllIIIlIllIlI.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, j)) < n) {
                this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(j + 1);
            }
        }
        final int ilIlIIIlllIIIlIlllIlIllIl = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl);
        final int n2 = (int)this.lIIIIlIIllIIlIIlIIIlIIllI.llllIIIIlIlIllIIIllllIIll + 1;
        final int n3 = ilIlIIIlllIIIlIlllIlIllIl;
        for (int k = iiiIllIlIIIllIlllIlllllIl - 1; k >= this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl(); --k) {
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIllIIlIlIllIIIlIllIlI, this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, k), ilIlIIIlllIIIlIlllIlIllIl, n2, n3)) {
                this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(k);
                break;
            }
        }
        if (this.IIIllIllIlIlllllllIlIlIII - this.IllIIIIIIIlIlIllllIIllIII > 100) {
            if (liiiIllIIlIlIllIIIlIllIlI.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIllIIlIlIllIIIlIllIlI) < 2.309210522693693 * 0.9743589758872986) {
                this.IIIllIllIlIlllllllIlIlIII();
            }
            this.IllIIIIIIIlIlIllllIIllIII = this.IIIllIllIlIlllllllIlIlIII;
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI;
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl = liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI = liiiIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI == null || this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public void IIIllIllIlIlllllllIlIlIII() {
        this.IlllIIIlIlllIllIlIIlllIlI = null;
    }
    
    private lIllIIIIlllllIIlIllIIIIII lIIIIllIIlIlIllIIIlIllIlI() {
        return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll, this.IlllIllIlIIIIlIIlIIllIIIl(), this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll);
    }
    
    private int IlllIllIlIIIIlIIlIIllIIIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlIIIIIIIIllIIllIIlllIl() && this.lIIlIlIllIIlIIIlIIIlllIII) {
            int n = (int)this.lIIIIlIIllIIlIIlIIIlIIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl;
            IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll = this.lIIIIIIIIIlIllIIllIlIIlIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll), n, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll));
            int n2 = 0;
            while (illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lIIIIllIIlIlIllIIIlIllIlI || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
                ++n;
                illlllllIlllIIllllIIlIll = this.lIIIIIIIIIlIllIIllIlIIlIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll), n, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll));
                if (++n2 > 16) {
                    return (int)this.lIIIIlIIllIIlIIlIIIlIIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl;
                }
            }
            return n;
        }
        return (int)(this.lIIIIlIIllIIlIIlIIIlIIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 1.4600000381469727 * 0.3424657444766908);
    }
    
    private boolean IlIlllIIIIllIllllIllIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlllIIlIlllllIlIllIII || (this.lIIlIlIllIIlIIIlIIIlllIII && this.llIIlllIIIIlllIllIlIlllIl()) || (this.lIIIIlIIllIIlIIlIIIlIIllI.llllIIIIIlIlIlIlIllIIIIII() && this.lIIIIlIIllIIlIIlIIIlIIllI instanceof IIlIIIIIIlIllIIIIlIIIIlll && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIIIlIIIIllllIIlIllI instanceof lIllllIIIIlIlIlllllllIIII);
    }
    
    private boolean llIIlllIIIIlllIllIlIlllIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlIIIIIIIIllIIllIIlllIl() || this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIllIlIllIlllIlllIll();
    }
    
    private void lIIlIlIllIIlIIIlIIIlllIII() {
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll), (int)(this.lIIIIlIIllIIlIIlIIIlIIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 2.0454545426836686 * 0.24444444477558136), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll))) {
            for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
                final IllllIIllIIlIllIIllIlllII liiiIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(i);
                if (this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI)) {
                    this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(i - 1);
                    return;
                }
            }
        }
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2, int n, final int n2, int n3) {
        int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI);
        int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI);
        final double n4 = lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI;
        final double n5 = lIllIIIIlllllIIlIllIIIIII2.IlllIIIlIlllIllIlIIlllIlI - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI;
        final double a = n4 * n4 + n5 * n5;
        if (a < 8.749999608844537E-9 * 1.1428571939468384) {
            return false;
        }
        final double n6 = 1.0 / Math.sqrt(a);
        final double a2 = n4 * n6;
        final double a3 = n5 * n6;
        n += 2;
        n3 += 2;
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, (int)lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI2, n, n2, n3, lIllIIIIlllllIIlIllIIIIII, a2, a3)) {
            return false;
        }
        n -= 2;
        n3 -= 2;
        final double n7 = 1.0 / Math.abs(a2);
        final double n8 = 1.0 / Math.abs(a3);
        double n9 = illlIIIlIlllIllIlIIlllIlI * 1 - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI;
        double n10 = illlIIIlIlllIllIlIIlllIlI2 * 1 - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI;
        if (a2 >= 0.0) {
            ++n9;
        }
        if (a3 >= 0.0) {
            ++n10;
        }
        double n11 = n9 / a2;
        double n12 = n10 / a3;
        final int n13 = (a2 < 0.0) ? -1 : 1;
        final int n14 = (a3 < 0.0) ? -1 : 1;
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII2.IlllIIIlIlllIllIlIIlllIlI);
        int n15 = illlIIIlIlllIllIlIIlllIlI3 - illlIIIlIlllIllIlIIlllIlI;
        int n16 = illlIIIlIlllIllIlIIlllIlI4 - illlIIIlIlllIllIlIIlllIlI2;
        while (n15 * n13 > 0 || n16 * n14 > 0) {
            if (n11 < n12) {
                n11 += n7;
                illlIIIlIlllIllIlIIlllIlI += n13;
                n15 = illlIIIlIlllIllIlIIlllIlI3 - illlIIIlIlllIllIlIIlllIlI;
            }
            else {
                n12 += n8;
                illlIIIlIlllIllIlIIlllIlI2 += n14;
                n16 = illlIIIlIlllIllIlIIlllIlI4 - illlIIIlIlllIllIlIIlllIlI2;
            }
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, (int)lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI2, n, n2, n3, lIllIIIIlllllIIlIllIIIIII, a2, a3)) {
                return false;
            }
        }
        return true;
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final double n7, final double n8) {
        final int n9 = n - n4 / 2;
        final int n10 = n3 - n6 / 2;
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl(n9, n2, n10, n4, n5, n6, lIllIIIIlllllIIlIllIIIIII, n7, n8)) {
            return false;
        }
        for (int i = n9; i < n9 + n4; ++i) {
            for (int j = n10; j < n10 + n6; ++j) {
                if ((i + 0.9058823585510254 * 0.5519480485300086 - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI) * n7 + (j + 0.11538461115233307 * 4.333333492279053 - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI) * n8 >= 0.0) {
                    final Material ilIlIIIlllIIIlIlllIlIllIl = this.lIIIIIIIIIlIllIIllIlIIlIl.getBlock(i, n2 - 1, j).IlIlIIIlllIIIlIlllIlIllIl();
                    if (ilIlIIIlllIIIlIlllIlIllIl == Material.air) {
                        return false;
                    }
                    if (ilIlIIIlllIIIlIlllIlIllIl == Material.IllIIIIIIIlIlIllllIIllIII && !this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlIIIIIIIIllIIllIIlllIl()) {
                        return false;
                    }
                    if (ilIlIIIlllIIIlIlllIlIllIl == Material.lIIIIllIIlIlIllIIIlIllIlI) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final double n7, final double n8) {
        for (int i = n; i < n + n4; ++i) {
            for (int j = n2; j < n2 + n5; ++j) {
                for (int k = n3; k < n3 + n6; ++k) {
                    if ((i + 1.0151515007019043 * 0.49253732044358495 - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI) * n7 + (k + 0.21666666838857865 * 2.307692289352417 - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI) * n8 >= 0.0 && !this.lIIIIIIIIIlIllIIllIlIIlIl.getBlock(i, j, k).lIIIIlIIllIIlIIlIIIlIIllI((lIIllIIIllIIIIllIllIIllIl)this.lIIIIIIIIIlIllIIllIlIIlIl, i, j, k)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
