import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIlIIIIIIlllIlIllII extends llIlIllIlIIllIIlIIlIlIIll
{
    public IIlIllIIlIIIIIIlllIlIllII() {
    }
    
    public IIlIllIIlIIIIIIlllIlIllII(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 1, 0, true);
        this.lIIIIIIIIIlIllIIllIlIIlIl((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, 1, true);
        this.IlllIIIlIlllIllIlIIlllIlI((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, 1, true);
    }
    
    public static IIlIllIIlIIIIIIlllIlIllII lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -1, 0, 0, 5, 7, 5, n4);
        return (llIlIllIlIIllIIlIIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIlIllIIlIIIIIIlllIlIllII(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 4, 1, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 4, 5, 4, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 0, 5, 0, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 2, 0, 4, 5, 0, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 4, 0, 5, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 2, 4, 4, 5, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 6, 0, 4, 6, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        for (int i = 0; i <= 4; ++i) {
            for (int j = 0; j <= 4; ++j) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, i, -1, j, iiIllllIIllllIIIIIlllllIl);
            }
        }
        return true;
    }
}
