import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlIlIIIIIIlllIlIIIl implements lIllIlllIIllIllllIIIlIllI
{
    private lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        for (int i = 0; i < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++i) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(i);
            if (liIlIlIllIIlIIIlIIIlllIII != null) {
                if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IllIIlllIllIlIllIlIIIIIII) {
                    ++n2;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lllIIlIIIllIIlllIlIIIllIl) {
                    ++n4;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIllIllIllllllIllIlllIlIl) {
                    ++n3;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIlIIIIIIlIIlIIlIIlIIlI) {
                    ++n;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIlIllIlIIIlllIl) {
                    ++n5;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIIllIIlIlIllIIIlIllIlI) {
                    ++n5;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIIlllIIlIlIIIlIlllllIll) {
                    ++n6;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IllllIllllIlIIIlIIIllllll) {
                    ++n6;
                }
                else if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llIIllIllIlIlIlIllllllIII) {
                    ++n6;
                }
                else {
                    if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() != IIlIlIllIlIIllIllIllIIIll.llllIlIIIIIllIIlIlllIllll) {
                        return false;
                    }
                    ++n6;
                }
            }
        }
        final int n7 = n5 + (n3 + n6);
        if (n2 > 3 || n > 1) {
            return false;
        }
        if (n2 >= 1 && n == 1 && n7 == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIlIIlllIIIIIlIlIlIIIllI);
            if (n4 > 0) {
                final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
                final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
                final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
                for (int j = 0; j < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++j) {
                    final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII2 = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(j);
                    if (liIlIlIllIIlIIIlIIIlllIII2 != null && liIlIlIllIIlIIIlIIIlllIII2.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lllIIlIIIllIIlllIlIIIllIl && liIlIlIllIIlIIIlIIIlllIII2.IIIlIIllllIIllllllIlIIIll() && liIlIlIllIIlIIIlIIIlllIII2.lllIIIIIlIllIlIIIllllllII().lIIIIIIIIIlIllIIllIlIIlIl("Explosion", 10)) {
                        illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII2.lllIIIIIlIllIlIIIllllllII().lIIlIlIllIIlIIIlIIIlllIII("Explosion"));
                    }
                }
                ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("Explosions", illIlllIlIllIIIIIIllIllll);
                ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("Flight", (byte)n2);
                ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Fireworks", ilIIIllIIlIIlllIllllIIIIl2);
                this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(ilIIIllIIlIIlllIllllIIIIl);
            }
            return true;
        }
        if (n2 == 1 && n == 0 && n4 == 0 && n3 > 0 && n6 <= 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lllIIlIIIllIIlllIlIIIllIl);
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl3 = new IlIIIllIIlIIlllIllllIIIIl();
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl4 = new IlIIIllIIlIIlllIllllIIIIl();
            byte b = 0;
            final ArrayList<Integer> list = new ArrayList<Integer>();
            for (int k = 0; k < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++k) {
                final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII3 = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(k);
                if (liIlIlIllIIlIIIlIIIlllIII3 != null) {
                    if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIllIllIllllllIllIlllIlIl) {
                        list.add(llllIllllIlIIIIIlllllIlll.IlIlllIIIIllIllllIllIIlIl[liIlIlIllIIlIIIlIIIlllIII3.IlllIllIlIIIIlIIlIIllIIIl()]);
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIlIllIlIIIlllIl) {
                        ilIIIllIIlIIlllIllllIIIIl4.lIIIIlIIllIIlIIlIIIlIIllI("Flicker", true);
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIIllIIlIlIllIIIlIllIlI) {
                        ilIIIllIIlIIlllIllllIIIIl4.lIIIIlIIllIIlIIlIIIlIIllI("Trail", true);
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIIlllIIlIlIIIlIlllllIll) {
                        b = 1;
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IllllIllllIlIIIlIIIllllll) {
                        b = 4;
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llIIllIllIlIlIlIllllllIII) {
                        b = 2;
                    }
                    else if (liIlIlIllIIlIIIlIIIlllIII3.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llllIlIIIIIllIIlIlllIllll) {
                        b = 3;
                    }
                }
            }
            final int[] array = new int[list.size()];
            for (int l = 0; l < array.length; ++l) {
                array[l] = list.get(l);
            }
            ilIIIllIIlIIlllIllllIIIIl4.lIIIIlIIllIIlIIlIIIlIIllI("Colors", array);
            ilIIIllIIlIIlllIllllIIIIl4.lIIIIlIIllIIlIIlIIIlIIllI("Type", b);
            ilIIIllIIlIIlllIllllIIIIl3.lIIIIlIIllIIlIIlIIIlIIllI("Explosion", ilIIIllIIlIIlllIllllIIIIl4);
            this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(ilIIIllIIlIIlllIllllIIIIl3);
            return true;
        }
        if (n2 != 0 || n != 0 || n4 != 1 || n3 <= 0 || n3 != n7) {
            return false;
        }
        final ArrayList<Integer> list2 = new ArrayList<Integer>();
        for (int n8 = 0; n8 < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++n8) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII4 = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(n8);
            if (liIlIlIllIIlIIIlIIIlllIII4 != null) {
                if (liIlIlIllIIlIIIlIIIlllIII4.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIllIllIllllllIllIlllIlIl) {
                    list2.add(llllIllllIlIIIIIlllllIlll.IlIlllIIIIllIllllIllIIlIl[liIlIlIllIIlIIIlIIIlllIII4.IlllIllIlIIIIlIIlIIllIIIl()]);
                }
                else if (liIlIlIllIIlIIIlIIIlllIII4.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lllIIlIIIllIIlllIlIIIllIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI = liIlIlIllIIlIIIlIIIlllIII4.llIIlllIIIIlllIllIlIlllIl();
                    this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl = 1;
                }
            }
        }
        final int[] array2 = new int[list2.size()];
        for (int index = 0; index < array2.length; ++index) {
            array2[index] = list2.get(index);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == null || !this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIllllIIllllllIlIIIll()) {
            return false;
        }
        final IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII5 = this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII().lIIlIlIllIIlIIIlIIIlllIII("Explosion");
        if (liIlIlIllIIlIIIlIIIlllIII5 == null) {
            return false;
        }
        liIlIlIllIIlIIIlIIIlllIII5.lIIIIlIIllIIlIIlIIIlIIllI("FadeColors", array2);
        return true;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return 10;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
