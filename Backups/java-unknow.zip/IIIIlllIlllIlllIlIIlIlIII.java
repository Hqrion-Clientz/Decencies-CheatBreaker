// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIlllIlllIlllIlIIlIlIII extends IIlllIIllIllIlIllIIIIIIlI implements IllIIIlIlIllIlIllllIIIllI
{
    public IIIIlllIlllIlllIlIIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    @Override
    public boolean IlllIIllIlllllIIIlIllIIII() {
        return true;
    }
    
    @Override
    public boolean IIIlllIIIllIllIlIIIIIIlII() {
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lllIlIIllllIIIIlIllIlIIII);
    }
    
    @Override
    public int lllIlIIllllIIIIlIllIlIIII() {
        return 120;
    }
    
    @Override
    protected boolean IlIlIIIlllIlIllIlIIIlllIl() {
        return true;
    }
    
    @Override
    protected int IIIIllIIllIIIIllIllIIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return 1 + this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(3);
    }
    
    @Override
    public void IlIIIIllIIIIIlllIIlIIlllI() {
        int ilIllIllIllIllIllllIIIlII = this.IlIllIllIllIllIllllIIIlII();
        super.IlIIIIllIIIIIlllIIlIIlllI();
        if (this.IlIlllIIIIlIllIlllIlIIIll() && !this.lIIlIIIIIIIIllIIllIIlllIl()) {
            --ilIllIllIllIllIllllIIIlII;
            this.IllIIIIIIIlIlIllllIIllIII(ilIllIllIllIllIllllIIIlII);
            if (this.IlIllIllIllIllIllllIIIlII() == -20) {
                this.IllIIIIIIIlIlIllllIIllIII(0);
                this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IIIIllIIllIIIIllIllIIIlIl, 2.0f);
            }
        }
        else {
            this.IllIIIIIIIlIlIllllIIllIII(300);
        }
    }
}
