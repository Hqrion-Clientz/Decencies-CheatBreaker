import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIlIllIIIIIlIIIIlII extends GuiScreen
{
    protected IlIllIlIIllIIIlIIlllllllI lIIIIlIIllIIlIIlIIIlIIllI;
    protected String lIIIIIIIIIlIllIIllIlIIlIl;
    private String IlIlIIIlllIIIlIlllIlIllIl;
    protected String IlllIIIlIlllIllIlIIlllIlI;
    protected String IIIIllIlIIIllIlllIlllllIl;
    protected int IIIIllIIllIIIIllIllIIIlIl;
    private int IIIllIllIlIlllllllIlIlIII;
    
    public IIllIlIIlIllIIIIIlIIIIlII(final IlIllIlIIllIIIlIIlllllllI liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl, final String ilIlIIIlllIIIlIlllIlIllIl, final int iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.yes", new Object[0]);
        this.IIIIllIlIIIllIlllIlllllIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.no", new Object[0]);
    }
    
    public IIllIlIIlIllIIIIIlIIIIlII(final IlIllIlIIllIIIlIIlllllllI liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl, final String ilIlIIIlllIIIlIlllIlIllIl, final String illlIIIlIlllIllIlIIlllIlI, final String iiiIllIlIIIllIlllIlllllIl, final int iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 96, this.IlllIIIlIlllIllIlIIlllIlI));
        this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + 160, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 96, this.IIIIllIlIIIllIlllIlllllIl));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0, this.IIIIllIIllIIIIllIllIIIlIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 70, 16777215);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.IlIlIIIlllIIIlIlllIlIllIl, this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 90, 16777215);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int iiIllIllIlIlllllllIlIlIII) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        final Iterator<lIIlIIIIlIIIIIllIIIIlIIll> iterator = this.IllIllIIIlIIlllIIIllIllII.iterator();
        while (iterator.hasNext()) {
            iterator.next().IlllIllIlIIIIlIIlIIllIIIl = false;
        }
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        final int iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII - 1;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        if (iiIllIllIlIlllllllIlIlIII == 0) {
            final Iterator<lIIlIIIIlIIIIIllIIIIlIIll> iterator = (Iterator<lIIlIIIIlIIIIIllIIIIlIIll>)this.IllIllIIIlIIlllIIIllIllII.iterator();
            while (iterator.hasNext()) {
                iterator.next().IlllIllIlIIIIlIIlIIllIIIl = true;
            }
        }
    }
}
