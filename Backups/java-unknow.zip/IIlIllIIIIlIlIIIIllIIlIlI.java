// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIIlIlIIIIllIIlIlI extends IIllIlllIIlllllIlllIIIlIl
{
    private long lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIllIIIIlIlIIIIllIIlIlI() {
    }
    
    public IIlIllIIIIlIlIIIIllIIlIlI(final long liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readLong();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeLong(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlllIIIlIIIIlllIlIlIlI ilIIlllIIIlIIIIlllIlIlIlI) {
        ilIIlllIIIlIIIIlllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return true;
    }
    
    public long IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlllIIIlIIIIlllIlIlIlI)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
