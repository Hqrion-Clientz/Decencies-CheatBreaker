// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllllllIIIIllllIIIIIl extends lIIlllIIIlIllllllIlIlIIII
{
    public IIIllllllllIIIIllllIIIIIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl(1);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            lIllIIIIlIIlIllIIIlIlIlll.lIlllIIIlIlIIlIIIIIIlIlII();
        }
        return (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl <= 0) ? new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlllllIIlIlIIIllllllIII) : lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    @Override
    public int IlIlIIIlllIIIlIlllIlIllIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return 32;
    }
    
    @Override
    public IlIIIIlIIIIIlIIIIIlIIIlIl IIIIllIIllIIIIllIllIIIlIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return IlIIIIlIIIIIlIIIIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        lIllIIIIlIIlIllIIIlIlIlll.IlllIIIlIlllIllIlIIlllIlI(lIlIlIlIlIllllIlllIIIlIlI, this.IlIlIIIlllIIIlIlllIlIllIl(lIlIlIlIlIllllIlllIIIlIlI));
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
}
