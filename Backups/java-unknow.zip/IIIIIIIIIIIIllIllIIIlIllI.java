// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIIIIllIllIIIlIllI extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIIIIIIIIIllIllIIIlIllI() {
    }
    
    public IIIIIIIIIIIIllIllIIIlIllI(final Entity entity, final int n) {
        this(entity, n, 0);
    }
    
    public IIIIIIIIIIIIllIllIIIlIllI(final Entity entity, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = entity.lIIIIlllIIlIlllllIlIllIII();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readByte();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readInt();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIllllIllIllIlIlIllIlllIl illllIllIllIlIlIllIlllIl) {
        illllIllIllIlIlIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllllIllIllIlIlIllIlllIl)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
