import org.apache.logging.log4j.LogManager;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.Calendar;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.opengl.GLContext;
import java.util.concurrent.Callable;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.glu.Project;
import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.util.List;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.Random;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class EntityRenderer implements IllIllllIIlIllIlIlllllIII
{
    private static final Logger lIllIllIlIIllIllIlIlIIlIl;
    private static final ResourceLocation llIlIIIllIIIIlllIlIIIIIlI;
    private static final ResourceLocation lIllIlIlllIIlIIllIIlIIlII;
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI;
    public static int lIIIIIIIIIlIllIIllIlIIlIl;
    private static int IIIlIIlIlIIIlllIIlIllllll;
    private Minecraft IllIlIIIIlllIIllIIlllIIlI;
    private float IllIlIlIllllIlIIllllIIlll;
    public ItemRenderer IlllIIIlIlllIllIlIIlllIlI;
    private final lIlIlIlIIlIIIIIlIllIlIlII IllIIlIIlllllIllIIIlllIII;
    private int lIlIlIllIIIIIIIIllllIIllI;
    private Entity IlllIIlllIIIIllIIllllIlIl;
    private llllIIllllIllIlllllIIlIlI IllllIllllIlIIIlIIIllllll;
    private llllIIllllIllIlllllIIlIlI IllIIlllIllIlIllIlIIIIIII;
    private llllIIllllIllIlllllIIlIlI IlIlIIIlllllIIIlIlIlIllII;
    private llllIIllllIllIlllllIIlIlI IIlIIllIIIllllIIlllIllIIl;
    private llllIIllllIllIlllllIIlIlI lllIlIIllllIIIIlIllIlIIII;
    private llllIIllllIllIlllllIIlIlI lIIIIlllIIlIlllllIlIllIII;
    private float lIIIlllIlIlllIIIIIIIIIlII;
    private float IIIIlIIIlllllllllIlllIlll;
    private float IlIllllIIIlIllllIIIIIllII;
    private float IlIIIIllIIIIIlllIIlIIlllI;
    private float llIlIlIllIlIIlIlllIllIIlI;
    private float llIlIlIlllIlllllIIIllIIll;
    private float IIllIlIllIlIllIIlIllIlIII;
    private float lIlIllIlIlIIIllllIlIllIll;
    private float IlIIlIIlIllIIIIllIIllIlIl;
    private float llllIIIIlIlIllIIIllllIIll;
    private float IIlIlIIlIIIlIlllllIIlIIlI;
    private float lIIIlllIIIlIIIIIlIIIIIIII;
    private float lIIlIIIIIIIIllIIllIIlllIl;
    private float IllllllIllllIIlllIllllllI;
    private float lIlIlIIIlIIllllllllIIlllI;
    private float IlIlllIllIlIllIlllIlllIll;
    private final DynamicTexture llIIIllIIllllIlIlIlIlIIll;
    private final int[] IIIIIlIllIllIlIIllIIlIllI;
    private final ResourceLocation lIIllIIllllllIIlllIlllIIl;
    private float lllIIllllIIlIlIlIlIIIlIII;
    private float IlIIllIlIlIIIllIllIIlIIII;
    private float IlIlllIIIIlIllIlllIlIIIll;
    private float IIIlIllIlllIlIllIllllllll;
    private float IllllllllIlIIIIIIIIllIIII;
    private boolean lIIlIlIIlIlIlIIlIlIlllIIl;
    private final llIllIllIllIIIIlIlllllIlI IllIIIlIIlIllIllIIllllIIl;
    public lllllIIIIIllIIlIIIIllllII IIIIllIlIIIllIlllIlllllIl;
    private static final ResourceLocation[] IIlIlllIllIlIlIIIIIlllIll;
    private static final ResourceLocation IlIIllIIIlllIIIIlIIIIlIll;
    private static final ResourceLocation lIIIIIIlIIllllllIIIlIlIIl;
    public static final int IIIIllIIllIIIIllIllIIIlIl;
    private int llIIIlIlIIlIlIIlIllIllIll;
    private double IlIIlllIlIIIlIIIlIlIlIlIl;
    private double IIIlllllIIlIlIIIllllllIII;
    private double lIlIlIIIIllIlllIlIIlllIlI;
    private long IIllllIllllIIIlIIllllIlll;
    private long llllIIIIIlIlIlIlIllIIIIII;
    private boolean IllIIIIllllllIlllllIlIlll;
    float IlIlIIIlllIIIlIlllIlIllIl;
    float IIIllIllIlIlllllllIlIlIII;
    float IllIIIIIIIlIlIllllIIllIII;
    float lIIIIllIIlIlIllIIIlIllIlI;
    private Random IIIllllIlIIlIIIlIlIlllIII;
    private int IIlIlllllIIIlIIllIllIlIlI;
    float[] IlllIllIlIIIIlIIlIIllIIIl;
    float[] IlIlllIIIIllIllllIllIIlIl;
    FloatBuffer llIIlllIIIIlllIllIlIlllIl;
    float lIIlIlIllIIlIIIlIIIlllIII;
    float IIIlllIIIllIllIlIIIIIIlII;
    float llIlIIIlIIIIlIlllIlIIIIll;
    private float IlIllIllIllIllIllllIIIlII;
    private float lllIllIllIlIllIlIIllllIIl;
    public int IIIlIIllllIIllllllIlIIIll;
    private boolean IIIIIIIllIllllIIlIIlllIII;
    private IIIIIIllIlIIIIlIlllIllllI IIIIlIllIIIIIIlIIIIIlllll;
    private boolean llllIIlIlIllIllllIIIIllll;
    public boolean lllIIIIIlIllIlIIIllllllII;
    private long IIlIlIlllIllIIlIllIIlIIlI;
    private int lIlIIllIIIlllIIllIIlIIllI;
    private int lIIIlIIIIIIlIIlIIlIIlIIlI;
    private int lIlIlIlIIlIlllIIIIIIllllI;
    private float llllIIllIIlllllIlIlIIllll;
    private float IllIlIIIIlIlllIlllllllIIl;
    public long[] lIIIIIllllIIIIlIlIIIIlIlI;
    public long[] IIIIIIlIlIlIllllllIlllIlI;
    public long[] IllIllIIIlIIlllIIIllIllII;
    public long[] IlIIlIIIIlIIIIllllIIlIllI;
    public int lIIlIIllIIIIIlIllIIIIllII;
    public long lIIlllIIlIlllllllllIIIIIl;
    private boolean IIlllllIIlIlIIlIIlllIIIII;
    private boolean IllIlIlllIIlIIIIIlIIIIIll;
    private long llllIlIlIlllllIllIIllIIIl;
    
    public EntityRenderer(final Minecraft illIlIIIIlllIIllIIlllIIlI, final llIllIllIllIIIIlIlllllIlI illIIIlIIlIllIllIIllllIIl) {
        this.IllllIllllIlIIIlIIIllllll = new llllIIllllIllIlllllIIlIlI();
        this.IllIIlllIllIlIllIlIIIIIII = new llllIIllllIllIlllllIIlIlI();
        this.IlIlIIIlllllIIIlIlIlIllII = new llllIIllllIllIlllllIIlIlI();
        this.IIlIIllIIIllllIIlllIllIIl = new llllIIllllIllIlllllIIlIlI();
        this.lllIlIIllllIIIIlIllIlIIII = new llllIIllllIllIlllllIIlIlI();
        this.lIIIIlllIIlIlllllIlIllIII = new llllIIllllIllIlllllIIlIlI();
        this.lIIIlllIlIlllIIIIIIIIIlII = 4;
        this.IIIIlIIIlllllllllIlllIlll = 4;
        this.IlIlllIllIlIllIlllIlllIll = 0.0f;
        this.IIIIIIIllIllllIIlIIlllIII = false;
        this.IIIIlIllIIIIIIlIIIIIlllll = null;
        this.llllIIlIlIllIllllIIIIllll = false;
        this.lllIIIIIlIllIlIIIllllllII = false;
        this.IIlIlIlllIllIIlIllIIlIIlI = 0L;
        this.lIlIIllIIIlllIIllIIlIIllI = 0;
        this.lIIIlIIIIIIlIIlIIlIIlIIlI = 0;
        this.lIlIlIlIIlIlllIIIIIIllllI = 0;
        this.llllIIllIIlllllIlIlIIllll = 0.0f;
        this.IllIlIIIIlIlllIlllllllIIl = 0.0f;
        this.lIIIIIllllIIIIlIlIIIIlIlI = new long[512];
        this.IIIIIIlIlIlIllllllIlllIlI = new long[512];
        this.IllIllIIIlIIlllIIIllIllII = new long[512];
        this.IlIIlIIIIlIIIIllllIIlIllI = new long[512];
        this.lIIlIIllIIIIIlIllIIIIllII = 0;
        this.lIIlllIIlIlllllllllIIIIIl = -1L;
        this.IIlllllIIlIlIIlIIlllIIIII = false;
        this.IllIlIlllIIlIIIIIlIIIIIll = false;
        this.llllIlIlIlllllIllIIllIIIl = 0L;
        this.llIIIlIlIIlIlIIlIllIllIll = EntityRenderer.IIIIllIIllIIIIllIllIIIlIl;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = 1.0;
        this.IIllllIllllIIIlIIllllIlll = Minecraft.getSystemTime();
        this.IIIllllIlIIlIIIlIlIlllIII = new Random();
        this.llIIlllIIIIlllIllIlIlllIl = GLAllocation.IIIIllIIllIIIIllIllIIIlIl(16);
        this.IllIlIIIIlllIIllIIlllIIlI = illIlIIIIlllIIllIIlllIIlI;
        this.IllIIIlIIlIllIllIIllllIIl = illIIIlIIlIllIllIIllllIIl;
        this.IllIIlIIlllllIllIIIlllIII = new lIlIlIlIIlIIIIIlIllIlIlII(illIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI());
        this.IlllIIIlIlllIllIlIIlllIlI = new ItemRenderer(illIlIIIIlllIIllIIlllIIlI);
        this.llIIIllIIllllIlIlIlIlIIll = new DynamicTexture(16, 16);
        this.lIIllIIllllllIIlllIlllIIl = illIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().getDynamicTextureLocation("lightMap", this.llIIIllIIllllIlIlIlIlIIll);
        this.IIIIIlIllIllIlIIllIIlIllI = this.llIIIllIIllllIlIlIlIlIIll.IIIIllIlIIIllIlllIlllllIl();
        this.IIIIllIlIIIllIlllIlllllIl = null;
    }
    
    public boolean isCurrentLocaleUnicode() {
        return OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII && this.IIIIllIlIIIllIlllIlllllIl != null;
    }
    
    public void tick() {
        if (this.IIIIllIlIIIllIlllIlllllIl != null) {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        this.IIIIllIlIIIllIlllIlllllIl = null;
        this.llIIIlIlIIlIlIIlIllIllIll = EntityRenderer.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public void unloadSounds() {
        if (this.IIIIllIlIIIllIlllIlllllIl != null) {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        this.IIIIllIlIIIllIlllIlllllIl = null;
        this.llIIIlIlIIlIlIIlIllIllIll = EntityRenderer.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII() && OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII) {
            if (this.IIIIllIlIIIllIlllIlllllIl != null) {
                this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            this.llIIIlIlIIlIlIIlIllIllIll = (this.llIIIlIlIIlIlIIlIllIllIll + 1) % (EntityRenderer.IIlIlllIllIlIlIIIIIlllIll.length + 1);
            if (this.llIIIlIlIIlIlIIlIllIllIll != EntityRenderer.IIIIllIIllIIIIllIllIIIlIl) {
                try {
                    EntityRenderer.lIllIllIlIIllIllIlIlIIlIl.info("Selecting effect " + EntityRenderer.IIlIlllIllIlIlIIIIIlllIll[this.llIIIlIlIIlIlIIlIllIllIll]);
                    (this.IIIIllIlIIIllIlllIlllllIl = new lllllIIIIIllIIlIIIIllllII(this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI(), this.IllIIIlIIlIllIllIIllllIIl, this.IllIlIIIIlllIIllIIlllIIlI.getFramebuffer(), EntityRenderer.IIlIlllIllIlIlIIIIIlllIll[this.llIIIlIlIIlIlIIlIllIllIll])).lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
                }
                catch (Exception ex) {
                    EntityRenderer.lIllIllIlIIllIllIlIlIIlIl.warn("Failed to load shader: " + EntityRenderer.IIlIlllIllIlIlIIIIIlllIll[this.llIIIlIlIIlIlIIlIllIllIll], (Throwable)ex);
                    this.llIIIlIlIIlIlIIlIllIllIll = EntityRenderer.IIIIllIIllIIIIllIllIIIlIl;
                }
            }
            else {
                this.IIIIllIlIIIllIlllIlllllIl = null;
                EntityRenderer.lIllIllIlIIllIllIlIlIIlIl.info("No effect selected");
            }
        }
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII() && OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII) {
            if (this.IIIIllIlIIIllIlllIlllllIl != null) {
                this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            try {
                (this.IIIIllIlIIIllIlllIlllllIl = new lllllIIIIIllIIlIIIIllllII(this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI(), this.IllIIIlIIlIllIllIIllllIIl, this.IllIlIIIIlllIIllIIlllIIlI.getFramebuffer(), EntityRenderer.IlIIllIIIlllIIIIlIIIIlIll)).lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
            }
            catch (Exception ex) {}
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII() && OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII) {
            if (this.IIIIllIlIIIllIlllIlllllIl != null) {
                this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            try {
                (this.IIIIllIlIIIllIlllIlllllIl = new lllllIIIIIllIIlIIIIllllII(this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI(), this.IllIIIlIIlIllIllIIllllIIl, this.IllIlIIIIlllIIllIIlllIIlI.getFramebuffer(), EntityRenderer.lIIIIIIlIIllllllIIIlIlIIl)).lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
            }
            catch (Exception ex) {}
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        if (this.IIIIllIlIIIllIlllIlllllIl != null) {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        if (this.llIIIlIlIIlIlIIlIllIllIll != EntityRenderer.IIIIllIIllIIIIllIllIIIlIl) {
            try {
                (this.IIIIllIlIIIllIlllIlllllIl = new lllllIIIIIllIIlIIIIllllII(this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI(), llIllIllIllIIIIlIlllllIlI, this.IllIlIIIIlllIIllIIlllIIlI.getFramebuffer(), EntityRenderer.IIlIlllIllIlIlIIIIIlllIll[this.llIIIlIlIIlIlIIlIllIllIll])).lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
            }
            catch (IOException ex) {
                EntityRenderer.lIllIllIlIIllIllIlIlIIlIl.warn("Failed to load shader: " + EntityRenderer.IIlIlllIllIlIlIIIIIlllIll[this.llIIIlIlIIlIlIIlIllIllIll], (Throwable)ex);
                this.llIIIlIlIIlIlIIlIllIllIll = EntityRenderer.IIIIllIIllIIIIllIllIIIlIl;
            }
        }
    }
    
    public void IIIllIllIlIlllllllIlIlIII() {
        if (OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII && lIIIIlllIIllllIllIlIlIllI.lIIIIIIIIIlIllIIllIlIIlIl() == null) {
            lIIIIlllIIllllIllIlIlIllI.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        this.IlIlllIIIIllIllllIllIIlIl();
        this.llIIlllIIIIlllIllIlIlllIl();
        this.IlIllIllIllIllIllllIIIlII = this.lllIllIllIlIllIlIIllllIIl;
        this.IIIIlIIIlllllllllIlllIlll = this.lIIIlllIlIlllIIIIIIIIIlII;
        this.IlIIIIllIIIIIlllIIlIIlllI = this.IlIllllIIIlIllllIIIIIllII;
        this.llIlIlIlllIlllllIIIllIIll = this.llIlIlIllIlIIlIlllIllIIlI;
        this.lIIlIIIIIIIIllIIllIIlllIl = this.lIIIlllIIIlIIIIIlIIIIIIII;
        this.lIlIlIIIlIIllllllllIIlllI = this.IllllllIllllIIlllIllllllI;
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lllIIlIlIllIIlIllIIIIIlII) {
            final float n = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI * (2.2222223f * 0.27f) + 0.8064516f * 0.248f;
            final float n2 = n * n * n * 8;
            this.IlIIlIIlIllIIIIllIIllIlIl = this.IllllIllllIlIIIlIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIllIlIllIlIllIIlIllIlIII, 0.135f * 0.37037036f * n2);
            this.llllIIIIlIlIllIIIllllIIll = this.IllIIlllIllIlIllIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIlIllIlIlIIIllllIlIllIll, 2.857143f * 0.0175f * n2);
            this.IIlIlIIlIIIlIlllllIIlIIlI = 0.0f;
            this.IIllIlIllIlIllIIlIllIlIII = 0.0f;
            this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity == null) {
            this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.thePlayer;
        }
        final float llIIlllIIIIlllIllIlIlllIl = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.llIIlllIIIIlllIllIlIlllIl(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IllIlIlIllllIlIIllllIIlll));
        final float n3 = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIIIlIlllIllIlIIlllIlI / (float)16;
        this.lllIllIllIlIllIlIIllllIIl += (llIIlllIIIIlllIllIlIlllIl * (1.0f - n3) + n3 - this.lllIllIllIlIllIlIIllllIIl) * (0.11395349f * 0.877551f);
        ++this.lIlIlIllIIIIIIIIllllIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
        this.lIIlIlIllIIlIIIlIIIlllIII();
        this.IllllllllIlIIIIIIIIllIIII = this.IIIlIllIlllIlIllIllllllll;
        if (llIIIllIIllIIIllIlllIlllI.IIIIllIlIIIllIlllIlllllIl) {
            this.IIIlIllIlllIlIllIllllllll += 0.37362638f * 0.13382353f;
            if (this.IIIlIllIlllIlIllIllllllll > 1.0f) {
                this.IIIlIllIlllIlIllIllllllll = 1.0f;
            }
            llIIIllIIllIIIllIlllIlllI.IIIIllIlIIIllIlllIlllllIl = false;
        }
        else if (this.IIIlIllIlllIlIllIllllllll > 0.0f) {
            this.IIIlIllIlllIlIllIllllllll -= 0.11875f * 0.10526316f;
        }
    }
    
    public lllllIIIIIllIIlIIIIllllII IllIIIIIIIlIlIllllIIllIII() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII && this.IIIIllIlIIIllIlllIlllllIl != null) {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        if (this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity != null && this.IllIlIIIIlllIIllIIlllIIlI.theWorld != null) {
            this.IllIlIIIIlllIIllIIlllIIlI.pointedEntity = null;
            final double n2 = this.IllIlIIIIlllIIllIIlllIIlI.playerController.IIIIllIlIIIllIlllIlllllIl();
            this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(n2, n);
            double iiiIllIlIIIllIlllIlllllIl = n2;
            final lIllIIIIlllllIIlIllIIIIII iiIlllIIIllIllIlIIIIIIlII = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IIIlllIIIllIllIlIIIIIIlII(n);
            double n3;
            if (this.IllIlIIIIlllIIllIIlllIIlI.playerController.lIIIIllIIlIlIllIIIlIllIlI()) {
                n3 = EntityRenderer.IIIlIIlIlIIIlllIIlIllllll >> 4;
                iiiIllIlIIIllIlllIlllllIl = EntityRenderer.IIIlIIlIlIIIlllIIlIllllll >> 4;
            }
            else {
                if (n2 > EntityRenderer.IIIlIIlIlIIIlllIIlIllllll >> 5) {
                    iiiIllIlIIIllIlllIlllllIl = EntityRenderer.IIIlIIlIlIIIlllIIlIllllll >> 5;
                }
                n3 = iiiIllIlIIIllIlllIlllllIl;
            }
            if (this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver != null) {
                iiiIllIlIIIllIlllIlllllIl = this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(iiIlllIIIllIllIlIIIIIIlII);
            }
            final lIllIIIIlllllIIlIllIIIIII llIIlllIIIIlllIllIlIlllIl = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.llIIlllIIIIlllIllIlIlllIl(n);
            final lIllIIIIlllllIIlIllIIIIII illlIIIlIlllIllIlIIlllIlI = iiIlllIIIllIllIlIIIIIIlII.IlllIIIlIlllIllIlIIlllIlI(llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI * n3, llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl * n3, llIIlllIIIIlllIllIlIlllIl.IlllIIIlIlllIllIlIIlllIlI * n3);
            this.IlllIIlllIIIIllIIllllIlIl = null;
            lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII = null;
            final float n4 = 1.0f;
            final List<Entity> liiiiiiiiIlIllIIllIlIIlIl = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIIIIIIlIllIIllIlIIlIl(this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity, this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI * n3, llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl * n3, llIIlllIIIIlllIllIlIlllIl.IlllIIIlIlllIllIlIIlllIlI * n3).lIIIIIIIIIlIllIIllIlIIlIl(n4, n4, n4));
            double n5 = iiiIllIlIIIllIlllIlllllIl;
            for (int i = 0; i < liiiiiiiiIlIllIIllIlIIlIl.size(); ++i) {
                final Entity illlIIlllIIIIllIIllllIlIl = liiiiiiiiIlIllIIllIlIIlIl.get(i);
                if (illlIIlllIIIIllIIllllIlIl.IIIIIlIllIllIlIIllIIlIllI()) {
                    final float ilIIllIIIlllIIIIlIIIIlIll = illlIIlllIIIIllIIllllIlIl.IlIIllIIIlllIIIIlIIIIlIll();
                    final IlIllIIlIlIllIlIllllllllI liiiiiiiiIlIllIIllIlIIlIl2 = illlIIlllIIIIllIIllllIlIl.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(ilIIllIIIlllIIIIlIIIIlIll, ilIIllIIIlllIIIIlIIIIlIll, ilIIllIIIlllIIIIlIIIIlIll);
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = liiiiiiiiIlIllIIllIlIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(iiIlllIIIllIllIlIIIIIIlII, illlIIIlIlllIllIlIIlllIlI);
                    if (liiiiiiiiIlIllIIllIlIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(iiIlllIIIllIllIlIIIIIIlII)) {
                        if (0.0 < n5 || n5 == 0.0) {
                            this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
                            lIllIIIIlllllIIlIllIIIIII = ((liiiIlIIllIIlIIlIIIlIIllI == null) ? iiIlllIIIllIllIlIIIIIIlII : liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl);
                            n5 = 0.0;
                        }
                    }
                    else if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                        final double iiiIllIlIIIllIlllIlllllIl2 = iiIlllIIIllIllIlIIIIIIlII.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl);
                        if (iiiIllIlIIIllIlllIlllllIl2 < n5 || n5 == 0.0) {
                            final boolean b = false;
                            if (illlIIlllIIIIllIIllllIlIl == this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IlIIlIIIIlIIIIllllIIlIllI && !b) {
                                if (n5 == 0.0) {
                                    this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
                                    lIllIIIIlllllIIlIllIIIIII = liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl;
                                }
                            }
                            else {
                                this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
                                lIllIIIIlllllIIlIllIIIIII = liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl;
                                n5 = iiiIllIlIIIllIlllIlllllIl2;
                            }
                        }
                    }
                }
            }
            if (this.IlllIIlllIIIIllIIllllIlIl != null && (n5 < iiiIllIlIIIllIlllIlllllIl || this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver == null)) {
                this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver = new MovingObjectPosition(this.IlllIIlllIIIIllIIllllIlIl, lIllIIIIlllllIIlIllIIIIII);
                if (this.IlllIIlllIIIIllIIllllIlIl instanceof EntityLivingBase || this.IlllIIlllIIIIllIIllllIlIl instanceof IllIIIIIllIlIlIIlllIIIIII) {
                    this.IllIlIIIIlllIIllIIlllIIlI.pointedEntity = this.IlllIIlllIIIIllIIllllIlIl;
                }
            }
        }
    }
    
    private void IlIlllIIIIllIllllIllIIlIl() {
        if (this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity instanceof IllIllIllIllllIllllIlIlll) {
            this.IlIlllIIIIlIllIlllIlIIIll = ((IllIllIllIllllIllllIlIlll)this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity).IllIIlIIlllllIllIIIlllIII();
        }
        else {
            this.IlIlllIIIIlIllIlllIlIIIll = this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.IllIIlIIlllllIllIIIlllIII();
        }
        this.IlIIllIlIlIIIllIllIIlIIII = this.lllIIllllIIlIlIlIlIIIlIII;
        this.lllIIllllIIlIlIlIlIIIlIII += (this.IlIlllIIIIlIllIlllIlIIIll - this.lllIIllllIIlIlIlIlIIIlIII) * (0.18023255f * 2.7741935f);
        if (this.lllIIllllIIlIlIlIlIIIlIII > 0.8231707f * 1.8222222f) {
            this.lllIIllllIIlIlIlIlIIIlIII = 3.9375f * 0.3809524f;
        }
        if (this.lllIIllllIIlIlIlIlIIIlIII < 0.21081081f * 0.47435898f) {
            this.lllIIllllIIlIlIlIlIIIlIII = 0.028169014f * 3.5500002f;
        }
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final boolean b) {
        if (this.IIIlIIllllIIllllllIlIIIll > 0) {
            return 90;
        }
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        float iiIlllIllIIllIllIlIIIllII = 70;
        if (b) {
            iiIlllIllIIllIllIlIIIllII = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIlllIllIIllIllIlIIIllII;
            if (lIIIllIIIllIlllllIIlIllII.IlIIlIllIllllIIlIllllIlII()) {
                iiIlllIllIIllIllIlIIIllII *= this.IlIIllIlIlIIIllIllIIlIIII + (this.lllIIllllIIlIlIlIlIIIlIII - this.IlIIllIlIlIIIllIllIIlIIII) * n;
            }
        }
        boolean b2 = false;
        if (this.IllIlIIIIlllIIllIIlllIIlI.currentScreen == null) {
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIlIlllIIlIIIIIlIIIIIll.lIIIIllIIlIlIllIIIlIllIlI() < 0) {
                b2 = Mouse.isButtonDown(this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIlIlllIIlIIIIIlIIIIIll.lIIIIllIIlIlIllIIIlIllIlI() + 100);
            }
            else {
                b2 = Keyboard.isKeyDown(this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIlIlllIIlIIIIIlIIIIIll.lIIIIllIIlIlIllIIIlIllIlI());
            }
        }
        if (b2) {
            if (!lIIIllIIIllIlllllIIlIllII.lIIIIllIIlIlIllIIIlIllIlI) {
                lIIIllIIIllIlllllIIlIllII.lIIIIllIIlIlIllIIIlIllIlI = true;
                this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lllIIlIlIllIIlIllIIIIIlII = true;
            }
            if (lIIIllIIIllIlllllIIlIllII.lIIIIllIIlIlIllIIIlIllIlI) {
                iiIlllIllIIllIllIlIIIllII /= 4;
            }
        }
        else if (lIIIllIIIllIlllllIIlIllII.lIIIIllIIlIlIllIIIlIllIlI) {
            lIIIllIIIllIlllllIIlIllII.lIIIIllIIlIlIllIIIlIllIlI = false;
            this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lllIIlIlIllIIlIllIIIIIlII = false;
            this.IllllIllllIlIIIlIIIllllll = new llllIIllllIllIlllllIIlIlI();
            this.IllIIlllIllIlIllIlIIIIIII = new llllIIllllIllIlllllIIlIlI();
        }
        if (renderViewEntity.getHealth() <= 0.0f) {
            iiIlllIllIIllIllIlIIIllII /= (1.0f - 500 / (renderViewEntity.IIlllllIIlIlIIlIIlllIIIII + n + 500)) * 2.0f + 1.0f;
        }
        if (IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.theWorld, renderViewEntity, n).IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
            iiIlllIllIIllIllIlIIIllII = iiIlllIllIIllIllIlIIIllII * 60 / 70;
        }
        return iiIlllIllIIllIllIlIIIllII + this.lIIlIIIIIIIIllIIllIIlllIl + (this.lIIIlllIIIlIIIIIlIIIIIIII - this.lIIlIIIIIIIIllIIllIIlllIl) * n;
    }
    
    private void IIIIllIIllIIIIllIllIIIlIl(final float n) {
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        final float n2 = renderViewEntity.lIlIlIlIIlIlllIIIIIIllllI - n;
        if (renderViewEntity.getHealth() <= 0.0f) {
            GL11.glRotatef(40 - 8000 / (renderViewEntity.IIlllllIIlIlIIlIIlllIIIII + n + 200), 0.0f, 0.0f, 1.0f);
        }
        if (n2 >= 0.0f) {
            final float n3 = n2 / renderViewEntity.llllIIllIIlllllIlIlIIllll;
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n3 * n3 * n3 * n3 * (4.611111f * 0.6813093f));
            final float illIlIIIIlIlllIlllllllIIl = renderViewEntity.IllIlIIIIlIlllIlllllllIIl;
            GL11.glRotatef(-illIlIIIIlIlllIlllllllIIl, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(-liiiIlIIllIIlIIlIIIlIIllI * 14, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(illIlIIIIlIlllIlllllllIIl, 0.0f, 1.0f, 0.0f);
        }
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        if (this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = (lIllIIIIlIIlIllIIIlIlIlll)this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
            final float n2 = -(lIllIIIIlIIlIllIIIlIlIlll.lIIIlllIIIlIIIIIlIIIIIIII + (lIllIIIIlIIlIllIIIlIlIlll.lIIIlllIIIlIIIIIlIIIIIIII - lIllIIIIlIIlIllIIIlIlIlll.IIlIlIIlIIIlIlllllIIlIIlI) * n);
            final float n3 = lIllIIIIlIIlIllIIIlIlIlll.IllIIIIIIlIlIlllllllIIllI + (lIllIIIIlIIlIllIIIlIlIlll.IlIIlllIIlIlIIIlIlllllIll - lIllIIIIlIIlIllIIIlIlIlll.IllIIIIIIlIlIlllllllIIllI) * n;
            final float n4 = lIllIIIIlIIlIllIIIlIlIlll.lIllIllIllllllIllIlllIlIl + (lIllIIIIlIIlIllIIIlIlIlll.IlIllIIllIIIIIllIlIIIIIIl - lIllIIIIlIIlIllIIIlIlIlll.lIllIllIllllllIllIlllIlIl) * n;
            GL11.glTranslatef(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2 * (1.9911504f * 1.5777777f)) * n3 * (0.02840909f * 17.6f), -Math.abs(MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n2 * (7.5398226f * 0.41666666f)) * n3), 0.0f);
            GL11.glRotatef(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2 * (1.25f * 2.5132742f)) * n3 * 3, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(Math.abs(MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n2 * (0.8680717f * 3.6190476f) - 0.76f * 0.2631579f) * n3) * 5, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(n4, 1.0f, 0.0f, 0.0f);
        }
    }
    
    private void IIIllIllIlIlllllllIlIlIII(final float n) {
        final llllIIIllllllIlllIIlIIlll ilIIlIIIIlIIIIllllIIlIllI = CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIIlIIIIlIIIIllllIIlIllI;
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        float n2 = renderViewEntity.lIlIllIlIlIIIllllIlIllIll - 77.0f * 0.02103896f;
        final double n3 = renderViewEntity.lIllIllIlIIllIllIlIlIIlIl + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIllIllIlIIllIllIlIlIIlIl) * n;
        final double n4 = renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI) * n - n2;
        final double n5 = renderViewEntity.lIllIlIlllIIlIIllIIlIIlII + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.lIllIlIlllIIlIIllIIlIIlII) * n;
        GL11.glRotatef(this.lIlIlIIIlIIllllllllIIlllI + (this.IllllllIllllIIlllIllllllI - this.lIlIlIIIlIIllllllllIIlllI) * n, 0.0f, 0.0f, 1.0f);
        if (renderViewEntity.isPlayerSleeping()) {
            ++n2;
            GL11.glTranslatef(0.0f, 0.8873239f * 0.33809525f, 0.0f);
            if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
                if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll)) == IllllllIllIIlllIllIIlIIll.IllIlIlIllllIlIIllllIIlll) {
                    GL11.glRotatef((float)((this.IllIlIIIIlllIIllIIlllIIlI.theWorld.IlllIIIlIlllIllIlIIlllIlI(MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll)) & 0x3) * 90), 0.0f, 1.0f, 0.0f);
                }
                GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI + (ilIIlIIIIlIIIIllllIIlIllI.lIIIIIIIIIlIllIIllIlIIlIl - ilIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI) * n + 180, 0.0f, (float)(-1), 0.0f);
                GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.IIIIllIIllIIIIllIllIIIlIl + (ilIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl - ilIIlIIIIlIIIIllllIIlIllI.IIIIllIIllIIIIllIllIIIlIl) * n, (float)(-1), 0.0f, 0.0f);
            }
        }
        else if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView > 0) {
            double n6 = this.IIIIlIIIlllllllllIlllIlll + (this.lIIIlllIlIlllIIIIIIIIIlII - this.IIIIlIIIlllllllllIlllIlll) * n;
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
                final float n7 = this.IlIIIIllIIIIIlllIIlIIlllI + (this.IlIllllIIIlIllllIIIIIllII - this.IlIIIIllIIIIIlllIIlIIlllI) * n;
                final float n8 = this.llIlIlIlllIlllllIIIllIIll + (this.llIlIlIllIlIIlIlllIllIIlI - this.llIlIlIlllIlllllIIIllIIll) * n;
                GL11.glTranslatef(0.0f, 0.0f, (float)(-n6));
                GL11.glRotatef(n8, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(n7, 0.0f, 1.0f, 0.0f);
            }
            else {
                final float liiiiiiiiIlIllIIllIlIIlIl = ilIIlIIIIlIIIIllllIIlIllI.lIIIIIIIIIlIllIIllIlIIlIl;
                float iiiIllIlIIIllIlllIlllllIl = ilIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl;
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 2) {
                    iiiIllIlIIIllIlllIlllllIl += 180;
                }
                final double n9 = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl / 180 * (1.4545455f * 2.1598449f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl / 180 * (15.315265f * 0.20512821f)) * n6;
                final double n10 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl / 180 * (1.6923077f * 1.8563957f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl / 180 * (0.97590363f * 3.219163f)) * n6;
                final double n11 = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl / 180 * (2.8235295f * 1.1126474f)) * n6;
                for (int i = 0; i < 8; ++i) {
                    final float n12 = (float)((i & 0x1) * 2 - 1);
                    final float n13 = (float)((i >> 1 & 0x1) * 2 - 1);
                    final float n14 = (float)((i >> 2 & 0x1) * 2 - 1);
                    final float n15 = n12 * (0.78431374f * 0.1275f);
                    final float n16 = n13 * (0.16857143f * 0.59322035f);
                    final float n17 = n14 * (0.0044444446f * 22.5f);
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 + n15, n4 + n16, n5 + n17), lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 - n9 + n15 + n17, n4 - n11 + n16, n5 - n10 + n17));
                    if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                        final double iiiIllIlIIIllIlllIlllllIl2 = liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4, n5));
                        if (iiiIllIlIIIllIlllIlllllIl2 < n6) {
                            n6 = iiiIllIlIIIllIlllIlllllIl2;
                        }
                    }
                }
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 2) {
                    GL11.glRotatef((float)180, 0.0f, 1.0f, 0.0f);
                }
                GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl - iiiIllIlIIIllIlllIlllllIl, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.lIIIIIIIIIlIllIIllIlIIlIl - liiiiiiiiIlIllIIllIlIIlIl, 0.0f, 1.0f, 0.0f);
                GL11.glTranslatef(0.0f, 0.0f, (float)(-n6));
                GL11.glRotatef(liiiiiiiiIlIllIIllIlIIlIl - ilIIlIIIIlIIIIllllIIlIllI.lIIIIIIIIIlIllIIllIlIIlIl, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(iiiIllIlIIIllIlllIlllllIl - ilIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl, 1.0f, 0.0f, 0.0f);
            }
        }
        else {
            GL11.glTranslatef(0.0f, 0.0f, 0.7719298f * -0.12954547f);
        }
        if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
            GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.IIIIllIIllIIIIllIllIIIlIl + (ilIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl - ilIIlIIIIlIIIIllllIIlIllI.IIIIllIIllIIIIllIllIIIlIl) * n, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(ilIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI + (ilIIlIIIIlIIIIllllIIlIllI.lIIIIIIIIIlIllIIllIlIIlIl - ilIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI) * n + 180, 0.0f, 1.0f, 0.0f);
        }
        GL11.glTranslatef(0.0f, n2, 0.0f);
        this.lIIlIlIIlIlIlIIlIlIlllIIl = this.IllIlIIIIlllIIllIIlllIIlI.renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity.lIllIllIlIIllIllIlIlIIlIl + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIllIllIlIIllIllIlIlIIlIl) * n, renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI) * n - n2, renderViewEntity.lIllIlIlllIIlIIllIIlIIlII + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.lIllIlIlllIIlIIllIIlIIlII) * n, n);
    }
    
    private void IllIIIIIIIlIlIllllIIllIII(final float n) {
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        float n2 = renderViewEntity.lIlIllIlIlIIIllllIlIllIll - 8.019f * 0.2020202f;
        final double n3 = renderViewEntity.lIllIllIlIIllIllIlIlIIlIl + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIllIllIlIIllIllIlIlIIlIl) * n;
        final double n4 = renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI) * n - n2;
        final double n5 = renderViewEntity.lIllIlIlllIIlIIllIIlIIlII + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.lIllIlIlllIIlIIllIIlIIlII) * n;
        GL11.glRotatef(this.lIlIlIIIlIIllllllllIIlllI + (this.IllllllIllllIIlllIllllllI - this.lIlIlIIIlIIllllllllIIlllI) * n, 0.0f, 0.0f, 1.0f);
        if (renderViewEntity.isPlayerSleeping()) {
            ++n2;
            GL11.glTranslatef(0.0f, 1.5576923f * 0.1925926f, 0.0f);
            if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
                if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll)) == IllllllIllIIlllIllIIlIIll.IllIlIlIllllIlIIllllIIlll) {
                    GL11.glRotatef((float)((this.IllIlIIIIlllIIllIIlllIIlI.theWorld.IlllIIIlIlllIllIlIIlllIlI(MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll)) & 0x3) * 90), 0.0f, 1.0f, 0.0f);
                }
                GL11.glRotatef(renderViewEntity.IlIlIIIlllllIIIlIlIlIllII + (renderViewEntity.IllllIllllIlIIIlIIIllllll - renderViewEntity.IlIlIIIlllllIIIlIlIlIllII) * n + 180, 0.0f, (float)(-1), 0.0f);
                GL11.glRotatef(renderViewEntity.IIlIIllIIIllllIIlllIllIIl + (renderViewEntity.IllIIlllIllIlIllIlIIIIIII - renderViewEntity.IIlIIllIIIllllIIlllIllIIl) * n, (float)(-1), 0.0f, 0.0f);
            }
        }
        else if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView > 0) {
            double n6 = this.IIIIlIIIlllllllllIlllIlll + (this.lIIIlllIlIlllIIIIIIIIIlII - this.IIIIlIIIlllllllllIlllIlll) * n;
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
                final float n7 = this.IlIIIIllIIIIIlllIIlIIlllI + (this.IlIllllIIIlIllllIIIIIllII - this.IlIIIIllIIIIIlllIIlIIlllI) * n;
                final float n8 = this.llIlIlIlllIlllllIIIllIIll + (this.llIlIlIllIlIIlIlllIllIIlI - this.llIlIlIlllIlllllIIIllIIll) * n;
                GL11.glTranslatef(0.0f, 0.0f, (float)(-n6));
                GL11.glRotatef(n8, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(n7, 0.0f, 1.0f, 0.0f);
            }
            else {
                final float illllIllllIlIIIlIIIllllll = renderViewEntity.IllllIllllIlIIIlIIIllllll;
                float illIIlllIllIlIllIlIIIIIII = renderViewEntity.IllIIlllIllIlIllIlIIIIIII;
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 2) {
                    illIIlllIllIlIllIlIIIIIII += 180;
                }
                final double n9 = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(illllIllllIlIIIlIIIllllll / 180 * (1.6857327f * 1.8636364f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(illIIlllIllIlIllIlIIIIIII / 180 * (3.0f * 1.0471976f)) * n6;
                final double n10 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(illllIllllIlIIIlIIIllllll / 180 * (8.6393795f * 0.36363637f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(illIIlllIllIlIllIlIIIIIII / 180 * (4.1887903f * 0.75f)) * n6;
                final double n11 = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(illIIlllIllIlIllIlIIIIIII / 180 * (1.3559322f * 2.3169246f)) * n6;
                for (int i = 0; i < 8; ++i) {
                    final float n12 = (float)((i & 0x1) * 2 - 1);
                    final float n13 = (float)((i >> 1 & 0x1) * 2 - 1);
                    final float n14 = (float)((i >> 2 & 0x1) * 2 - 1);
                    final float n15 = n12 * (0.026086958f * 3.8333333f);
                    final float n16 = n13 * (0.32291666f * 0.30967742f);
                    final float n17 = n14 * (43.0f * 0.0023255814f);
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 + n15, n4 + n16, n5 + n17), lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 - n9 + n15 + n17, n4 - n11 + n16, n5 - n10 + n17));
                    if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                        final double iiiIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4, n5));
                        if (iiiIllIlIIIllIlllIlllllIl < n6) {
                            n6 = iiiIllIlIIIllIlllIlllllIl;
                        }
                    }
                }
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 2) {
                    GL11.glRotatef((float)180, 0.0f, 1.0f, 0.0f);
                }
                GL11.glRotatef(renderViewEntity.IllIIlllIllIlIllIlIIIIIII - illIIlllIllIlIllIlIIIIIII, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(renderViewEntity.IllllIllllIlIIIlIIIllllll - illllIllllIlIIIlIIIllllll, 0.0f, 1.0f, 0.0f);
                GL11.glTranslatef(0.0f, 0.0f, (float)(-n6));
                GL11.glRotatef(illllIllllIlIIIlIIIllllll - renderViewEntity.IllllIllllIlIIIlIIIllllll, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(illIIlllIllIlIllIlIIIIIII - renderViewEntity.IllIIlllIllIlIllIlIIIIIII, 1.0f, 0.0f, 0.0f);
            }
        }
        else {
            GL11.glTranslatef(0.0f, 0.0f, 0.6037736f * -0.165625f);
        }
        if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIIIlIIllIIIIllllIlIlIlI) {
            GL11.glRotatef(renderViewEntity.IIlIIllIIIllllIIlllIllIIl + (renderViewEntity.IllIIlllIllIlIllIlIIIIIII - renderViewEntity.IIlIIllIIIllllIIlllIllIIl) * n, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(renderViewEntity.IlIlIIIlllllIIIlIlIlIllII + (renderViewEntity.IllllIllllIlIIIlIIIllllll - renderViewEntity.IlIlIIIlllllIIIlIlIlIllII) * n + 180, 0.0f, 1.0f, 0.0f);
        }
        GL11.glTranslatef(0.0f, n2, 0.0f);
        this.lIIlIlIIlIlIlIIlIlIlllIIl = this.IllIlIIIIlllIIllIIlllIIlI.renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity.lIllIllIlIIllIllIlIlIIlIl + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIllIllIlIIllIllIlIlIIlIl) * n, renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.llIlIIIllIIIIlllIlIIIIIlI) * n - n2, renderViewEntity.lIllIlIlllIIlIIllIIlIIlII + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.lIllIlIlllIIlIIllIIlIIlII) * n, n);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2, final boolean b) {
        this.IllIlIlIllllIlIIllllIIlll = (float)(this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIIIlIlllIllIlIIlllIlI * 16);
        if (lIIIllIIIllIlllllIIlIllII.llIlIIIlIIIIlIlllIlIIIIll()) {
            this.IllIlIlIllllIlIIllllIIlll *= 0.37424242f * 2.5384614f;
        }
        if (lIIIllIIIllIlllllIIlIllII.IIIlIIllllIIllllllIlIIIll()) {
            this.IllIlIlIllllIlIIllllIIlll *= 0.99938774f * 0.8305085f;
        }
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        final float n3 = 0.7761194f * 0.09019231f;
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
            GL11.glTranslatef(-(n2 * 2 - 1) * n3, 0.0f, 0.0f);
        }
        float n4 = this.IllIlIlIllllIlIIllllIIlll * 2.0f;
        if (n4 < 128) {
            n4 = 128;
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI == 1) {
            n4 = 256;
        }
        if (this.IlIIlllIlIIIlIIIlIlIlIlIl != 1.0) {
            GL11.glTranslatef((float)this.IIIlllllIIlIlIIIllllllIII, (float)(-this.lIlIlIIIIllIlllIlIIlllIlI), 0.0f);
            GL11.glScaled(this.IlIIlllIlIIIlIIIlIlIlIlIl, this.IlIIlllIlIIIlIIIlIlIlIlIl, 1.0);
        }
        Project.gluPerspective(this.lIIIIlIIllIIlIIlIIIlIIllI(n, true), this.IllIlIIIIlllIIllIIlllIIlI.displayWidth / (float)this.IllIlIIIIlllIIllIIlllIIlI.displayHeight, 0.0040697674f * 12.285714f, n4);
        if (this.IllIlIIIIlllIIllIIlllIIlI.playerController.lIIIIlIIllIIlIIlIIIlIIllI()) {
            GL11.glScalef(1.0f, 1.21875f * 0.5470086f, 1.0f);
        }
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
            GL11.glTranslatef((n2 * 2 - 1) * (2.3333333f * 0.042857144f), 0.0f, 0.0f);
        }
        this.IIIIllIIllIIIIllIllIIIlIl(n);
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIlIIIllIlllIlllllIl) {
            this.IlIlIIIlllIIIlIlllIlIllIl(n);
        }
        final float n5 = this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.lIIlIlIllIIlIIIlIIIlllIII + (this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.llIIlllIIIIlllIllIlIlllIl - this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.lIIlIlIllIIlIIIlIIIlllIII) * n;
        if (n5 > 0.0f) {
            int n6 = 20;
            if (this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IlIlllIIIIllIllllIllIIlIl)) {
                n6 = 7;
            }
            final float n7 = 5 / (n5 * n5 + 5) - n5 * (0.168f * 0.23809524f);
            final float n8 = n7 * n7;
            GL11.glRotatef((this.lIlIlIllIIIIIIIIllllIIllI + n) * n6, 0.0f, 1.0f, 1.0f);
            GL11.glScalef(1.0f / n8, 1.0f, 1.0f);
            GL11.glRotatef(-(this.lIlIlIllIIIIIIIIllllIIllI + n) * n6, 0.0f, 1.0f, 1.0f);
        }
        if (b) {
            this.IIIllIllIlIlllllllIlIlIII(n);
        }
        else {
            this.IllIIIIIIIlIlIllllIIllIII(n);
        }
        if (this.IIIlIIllllIIllllllIlIIIll > 0) {
            final int n9 = this.IIIlIIllllIIllllllIlIIIll - 1;
            if (n9 == 1) {
                GL11.glRotatef((float)90, 0.0f, 1.0f, 0.0f);
            }
            if (n9 == 2) {
                GL11.glRotatef((float)180, 0.0f, 1.0f, 0.0f);
            }
            if (n9 == 3) {
                GL11.glRotatef((float)(-90), 0.0f, 1.0f, 0.0f);
            }
            if (n9 == 4) {
                GL11.glRotatef((float)90, 1.0f, 0.0f, 0.0f);
            }
            if (n9 == 5) {
                GL11.glRotatef((float)(-90), 1.0f, 0.0f, 0.0f);
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2) {
        if (this.IIIlIIllllIIllllllIlIIIll <= 0) {
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            final float n3 = 0.07345679f * 0.9529412f;
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
                GL11.glTranslatef(-(n2 * 2 - 1) * n3, 0.0f, 0.0f);
            }
            if (this.IlIIlllIlIIIlIIIlIlIlIlIl != 1.0) {
                GL11.glTranslatef((float)this.IIIlllllIIlIlIIIllllllIII, (float)(-this.lIlIlIIIIllIlllIlIIlllIlI), 0.0f);
                GL11.glScaled(this.IlIIlllIlIIIlIIIlIlIlIlIl, this.IlIIlllIlIIIlIIIlIlIlIlIl, 1.0);
            }
            Project.gluPerspective(this.lIIIIlIIllIIlIIlIIIlIIllI(n, false), this.IllIlIIIIlllIIllIIlllIIlI.displayWidth / (float)this.IllIlIIIIlllIIllIIlllIIlI.displayHeight, 2.9117646f * 0.017171718f, this.IllIlIlIllllIlIIllllIIlll * 2.0f);
            if (this.IllIlIIIIlllIIllIIlllIIlI.playerController.lIIIIlIIllIIlIIlIIIlIIllI()) {
                GL11.glScalef(1.0f, 0.36923078f * 1.8055556f, 1.0f);
            }
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
                GL11.glTranslatef((n2 * 2 - 1) * (0.45294118f * 0.22077923f), 0.0f, 0.0f);
            }
            GL11.glPushMatrix();
            this.IIIIllIIllIIIIllIllIIIlIl(n);
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIlIIIllIlllIlllllIl) {
                this.IlIlIIIlllIIIlIlllIlIllIl(n);
            }
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 0 && !this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.isPlayerSleeping() && !this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl && !this.IllIlIIIIlllIIllIIlllIIlI.playerController.lIIIIlIIllIIlIIlIIIlIIllI()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n);
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n);
                this.lIIIIlIIllIIlIIlIIIlIIllI((double)n);
            }
            GL11.glPopMatrix();
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 0 && !this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.isPlayerSleeping()) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(n);
                this.IIIIllIIllIIIIllIllIIIlIl(n);
            }
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIlIIIllIlllIlllllIl) {
                this.IlIlIIIlllIIIlIlllIlIllIl(n);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI);
        GL11.glDisable(3553);
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final double n) {
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI);
        GL11.glMatrixMode(5890);
        GL11.glLoadIdentity();
        final float n2 = 0.0034179685f * 1.1428572f;
        GL11.glScalef(n2, n2, n2);
        GL11.glTranslatef((float)8, (float)8, (float)8);
        GL11.glMatrixMode(5888);
        this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().bindTexture(this.lIIllIIllllllIIlllIlllIIl);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10242, 10496);
        GL11.glTexParameteri(3553, 10243, 10496);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    private void llIIlllIIIIlllIllIlIlllIl() {
        this.IIIllIllIlIlllllllIlIlIII += (float)((Math.random() - Math.random()) * Math.random() * Math.random());
        this.lIIIIllIIlIlIllIIIlIllIlI += (float)((Math.random() - Math.random()) * Math.random() * Math.random());
        this.IIIllIllIlIlllllllIlIlIII *= (float)(0.9593406631108456 * 0.938144326210022);
        this.lIIIIllIIlIlIllIIIlIllIlI *= (float)(0.8289473268133802 * 1.085714340209961);
        this.IlIlIIIlllIIIlIlllIlIllIl += (this.IIIllIllIlIlllllllIlIlIII - this.IlIlIIIlllIIIlIlllIlIllIl) * 1.0f;
        this.IllIIIIIIIlIlIllllIIllIII += (this.lIIIIllIIlIlIllIIIlIllIlI - this.IllIIIIIIIlIlIllllIIllIII) * 1.0f;
        this.IllIIIIllllllIlllllIlIlll = true;
    }
    
    private void lIIIIllIIlIlIllIIIlIllIlI(final float n) {
        final WorldClient theWorld = this.IllIlIIIIlllIIllIIlllIIlI.theWorld;
        if (theWorld != null) {
            if (lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(theWorld, this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIIlIllIllIlIIllIIlIllI, this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lIIIIIllllIIIIlIlIIIIlIlI))) {
                this.llIIIllIIllllIlIlIlIlIIll.tick();
                this.IllIIIIllllllIlllllIlIlll = false;
                return;
            }
            for (int i = 0; i < 256; ++i) {
                float n2 = theWorld.lIIIIIllllIIIIlIlIIIIlIlI.IllIIIIIIIlIlIllllIIllIII[i / 16] * (theWorld.lIIIIIIIIIlIllIIllIlIIlIl(1.0f) * (12.349999f * 0.07692308f) + 0.22380953f * 0.22340426f);
                final float n3 = theWorld.lIIIIIllllIIIIlIlIIIIlIlI.IllIIIIIIIlIlIllllIIllIII[i % 16] * (this.IlIlIIIlllIIIlIlllIlIllIl * (8.555555f * 0.0116883125f) + 1.5714285f * 0.9545455f);
                if (theWorld.llIlIIIlIIIIlIlllIlIIIIll > 0) {
                    n2 = theWorld.lIIIIIllllIIIIlIlIIIIlIlI.IllIIIIIIIlIlIllllIIllIII[i / 16];
                }
                final float n4 = n2 * (theWorld.lIIIIIIIIIlIllIIllIlIIlIl(1.0f) * (0.20689656f * 3.1416664f) + 0.30555555f * 1.1454545f);
                final float n5 = n2 * (theWorld.lIIIIIIIIIlIllIIllIlIIlIl(1.0f) * (1.56f * 0.41666666f) + 0.11627907f * 3.0099998f);
                final float n6 = n3 * ((n3 * (2.862069f * 0.20963857f) + 0.58f * 0.6896552f) * (0.5733333f * 1.0465117f) + 0.07123288f * 5.6153846f);
                final float n7 = n3 * (n3 * n3 * (0.56666666f * 1.0588236f) + 4.5555553f * 0.08780488f);
                final float n8 = n4 + n3;
                final float n9 = n5 + n6;
                final float n10 = n2 + n7;
                float n11 = n8 * (1.0933334f * 0.8780487f) + 0.010909091f * 2.75f;
                float n12 = n9 * (3.28f * 0.29268292f) + 0.7291667f * 0.041142855f;
                float n13 = n10 * (3.25f * 0.29538462f) + 1.1857142f * 0.025301205f;
                if (this.IIIlIllIlllIlIllIllllllll > 0.0f) {
                    final float n14 = this.IllllllllIlIIIIIIIIllIIII + (this.IIIlIllIlllIlIllIllllllll - this.IllllllllIlIIIIIIIIllIIII) * n;
                    n11 = n11 * (1.0f - n14) + n11 * (0.6034483f * 1.16f) * n14;
                    n12 = n12 * (1.0f - n14) + n12 * (0.09152543f * 6.5555553f) * n14;
                    n13 = n13 * (1.0f - n14) + n13 * (1.2878788f * 0.4658824f) * n14;
                }
                if (theWorld.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI == 1) {
                    n11 = 0.7160494f * 0.30724138f + n3 * (11.75f * 0.06382979f);
                    n12 = 0.28933334f * 0.9677419f + n6 * (0.21875f * 3.4285715f);
                    n13 = 4.769231f * 0.052419353f + n7 * (1.1774193f * 0.6369863f);
                }
                if (this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lIIIIIllllIIIIlIlIIIIlIlI)) {
                    final float liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.thePlayer, n);
                    float n15 = 1.0f / n11;
                    if (n15 > 1.0f / n12) {
                        n15 = 1.0f / n12;
                    }
                    if (n15 > 1.0f / n13) {
                        n15 = 1.0f / n13;
                    }
                    n11 = n11 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI) + n11 * n15 * liiiIlIIllIIlIIlIIIlIIllI;
                    n12 = n12 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI) + n12 * n15 * liiiIlIIllIIlIIlIIIlIIllI;
                    n13 = n13 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI) + n13 * n15 * liiiIlIIllIIlIIlIIIlIIllI;
                }
                if (n11 > 1.0f) {
                    n11 = 1.0f;
                }
                if (n12 > 1.0f) {
                    n12 = 1.0f;
                }
                if (n13 > 1.0f) {
                    n13 = 1.0f;
                }
                final float liiiIlIIllIIlIIlIIIlIIllI2 = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI();
                final float n16 = 1.0f - n11;
                final float n17 = 1.0f - n12;
                final float n18 = 1.0f - n13;
                final float n19 = 1.0f - n16 * n16 * n16 * n16;
                final float n20 = 1.0f - n17 * n17 * n17 * n17;
                final float n21 = 1.0f - n18 * n18 * n18 * n18;
                final float n22 = n11 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI2) + n19 * liiiIlIIllIIlIIlIIIlIIllI2;
                final float n23 = n12 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI2) + n20 * liiiIlIIllIIlIIlIIIlIIllI2;
                final float n24 = n13 * (1.0f - liiiIlIIllIIlIIlIIIlIIllI2) + n21 * liiiIlIIllIIlIIlIIIlIIllI2;
                float n25 = n22 * (0.37818182f * 2.5384614f) + 0.027666666f * 1.0843374f;
                float n26 = n23 * (2.166857f * 0.443038f) + 4.4f * 0.0068181814f;
                float n27 = n24 * (0.45913044f * 2.090909f) + 0.0097058825f * 3.090909f;
                if (n25 > 1.0f) {
                    n25 = 1.0f;
                }
                if (n26 > 1.0f) {
                    n26 = 1.0f;
                }
                if (n27 > 1.0f) {
                    n27 = 1.0f;
                }
                if (n25 < 0.0f) {
                    n25 = 0.0f;
                }
                if (n26 < 0.0f) {
                    n26 = 0.0f;
                }
                if (n27 < 0.0f) {
                    n27 = 0.0f;
                }
                this.IIIIIlIllIllIlIIllIIlIllI[i] = (255 << 24 | (int)(n25 * 255) << 16 | (int)(n26 * 255) << 8 | (int)(n27 * 255));
            }
            this.llIIIllIIllllIlIlIlIlIIll.tick();
            this.IllIIIIllllllIlllllIlIlll = false;
        }
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final float n) {
        final int liiiiiiiiIlIllIIllIlIIlIl = lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.lIIIIIllllIIIIlIlIIIIlIlI).lIIIIIIIIIlIllIIllIlIIlIl();
        return (liiiiiiiiIlIllIIllIlIIlIl > 200) ? 1.0f : (0.7380952f * 0.9483871f + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((liiiiiiiiIlIllIIllIlIIlIl - n) * (3.3991003f * 0.92424244f) * (2.2f * 0.09090909f)) * (1.35f * 0.22222222f));
    }
    
    public void updateCameraAndRender(final float n) {
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.startSection("lightTex");
        if (!this.IIIIIIIllIllllIIlIIlllIII) {
            lllIIlIlIlIlllIIIIIIIIIIl.IlllIIIlIlllIllIlIIlllIlI();
            IIlllIlIlllIllIIIlllIIlIl.IlllIIIlIlllIllIlIIlllIlI();
            final lllIIIIIllllIIIIllIIIllll lllIIIIIllllIIIIllIIIllll = new lllIIIIIllllIIIIllIIIllll(this.IllIlIIIIlllIIllIIlllIIlI);
            this.IlllIIIlIlllIllIlIIlllIlI = lllIIIIIllllIIIIllIIIllll;
            RenderManager.instance.itemRenderer = lllIIIIIllllIIIIllIIIllll;
            if (lIIIllIIIllIlllllIIlIllII.lIlllllIlIllllIIIllllllII() == 64 && lIIIllIIIllIlllllIIlIllII.lIlIIIlIIIlllllllllllIlIl() == 32) {
                lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(true);
            }
            this.IIIIIIIllIllllIIlIIlllIII = true;
        }
        lIIIllIIIllIlllllIIlIllII.lIIlIIIllIIlllIlllIlIIlll();
        final WorldClient theWorld = this.IllIlIIIIlllIIllIIlllIIlI.theWorld;
        if (theWorld != null) {
            if (lIIIllIIIllIlllllIIlIllII.IlIllIIllIIIIIllIlIIIIIIl() != null) {
                this.IllIlIIIIlllIIllIIlllIIlI.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI("A new §eOptiFine§f version is available: §e" + ("HD_U".replace("HD_U", "HD Ultra").replace("L", "Light") + " " + lIIIllIIIllIlllllIIlIllII.IlIllIIllIIIIIllIlIIIIIIl()) + "§f"));
                lIIIllIIIllIlllllIIlIllII.IlIlIIIlllIIIlIlllIlIllIl(null);
            }
            if (lIIIllIIIllIlllllIIlIllII.IIllllllIlIIIIlllIlIlIlll()) {
                lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(false);
                this.IllIlIIIIlllIIllIIlllIIlI.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("You can install §e64-bit Java§f to increase performance", new Object[0])));
            }
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.currentScreen instanceof GuiMainMenu) {
            this.lIIIIlIIllIIlIIlIIIlIIllI((GuiMainMenu)this.IllIlIIIIlllIIllIIlllIIlI.currentScreen);
        }
        if (this.IIIIlIllIIIIIIlIIIIIlllll != theWorld) {
            lIIllIllllIllIIIIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIlIllIIIIIIlIIIIIlllll, theWorld);
            lIIIllIIIllIlllllIIlIllII.IllIIIIIIIlIlIllllIIllIII();
            this.IIlIlIlllIllIIlIllIIlIIlI = 0L;
            this.lIlIIllIIIlllIIllIIlIIllI = 0;
            this.IIIIlIllIIIIIIlIIIIIlllll = theWorld;
        }
        RenderBlocks.fancyGrass = (lIIIllIIIllIlllllIIlIllII.IlllIIlllIIIIllIIllllIlIl() || lIIIllIIIllIlllllIIlIllII.IlIlllIIIIlIllIlllIlIIIll());
        IllllllIllIIlllIllIIlIIll.IllIllIIIlIIlllIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl(lIIIllIIIllIlllllIIlIllII.lIlIlIllIIIIIIIIllllIIllI());
        if (this.IllIIIIllllllIlllllIlIlll) {
            this.lIIIIllIIlIlIllIIIlIllIlI(n);
        }
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endSection();
        final boolean active = Display.isActive();
        if (!active && this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlIlIIIIIllIlIlIIllIlIIIl && (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIIIIIlIIllIlIlIllIIIIll || !Mouse.isButtonDown(1))) {
            if (Minecraft.getSystemTime() - this.IIllllIllllIIIlIIllllIlll > 500L) {
                this.IllIlIIIIlllIIllIIlllIIlI.displayInGameMenu();
            }
        }
        else {
            this.IIllllIllllIIIlIIllllIlll = Minecraft.getSystemTime();
        }
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.startSection("mouse");
        if (this.IllIlIIIIlllIIllIIlllIIlI.inGameHasFocus && active) {
            this.IllIlIIIIlllIIllIIlllIIlI.mouseHelper.IlllIIIlIlllIllIlIIlllIlI();
            final float n2 = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI * (10.0f * 0.060000002f) + 0.21578947f * 0.9268293f;
            final float n3 = n2 * n2 * n2 * 8;
            final float n4 = this.IllIlIIIIlllIIllIIlllIIlI.mouseHelper.lIIIIlIIllIIlIIlIIIlIIllI * n3;
            final float n5 = this.IllIlIIIIlllIIllIIlllIIlI.mouseHelper.lIIIIIIIIIlIllIIllIlIIlIl * n3;
            int n6 = 1;
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIIIIIIIIlIllIIllIlIIlIl) {
                n6 = -1;
            }
            final llllIIIllllllIlllIIlIIlll ilIIlIIIIlIIIIllllIIlIllI = CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIIlIIIIlIIIIllllIIlIllI;
            if (!ilIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI) {
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lllIIlIlIllIIlIllIIIIIlII) {
                    this.IIllIlIllIlIllIIlIllIlIII += n4;
                    this.lIlIllIlIlIIIllllIlIllIll += n5;
                    final float n7 = n - this.IIlIlIIlIIIlIlllllIIlIIlI;
                    this.IIlIlIIlIIIlIlllllIIlIIlI = n;
                    this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.IIIllIllIlIlllllllIlIlIII(this.IlIIlIIlIllIIIIllIIllIlIl * n7, this.llllIIIIlIlIllIIIllllIIll * n7 * n6);
                }
                else {
                    this.IllIlIIIIlllIIllIIlllIIlI.thePlayer.IIIllIllIlIlllllllIlIlIII(n4, n5 * n6);
                }
            }
            else if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lllIIlIlIllIIlIllIIIIIlII) {
                this.IIllIlIllIlIllIIlIllIlIII += n4;
                this.lIlIllIlIlIIIllllIlIllIll += n5;
                final float n8 = n - this.IIlIlIIlIIIlIlllllIIlIIlI;
                this.IIlIlIIlIIIlIlllllIIlIIlI = n;
                ilIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIlIIlIllIIIIllIIllIlIl * n8, this.llllIIIIlIlIllIIIllllIIll * n8 * n6);
            }
            else {
                ilIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5 * n6);
            }
        }
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endSection();
        if (!this.IllIlIIIIlllIIllIIlllIIlI.skipRenderWorld) {
            EntityRenderer.lIIIIlIIllIIlIIlIIIlIIllI = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl;
            final ScaledResolution scaledResolution = new ScaledResolution(this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
            final int scaledWidth = scaledResolution.getScaledWidth();
            final int scaledHeight = scaledResolution.getScaledHeight();
            final int n9 = Mouse.getX() * scaledWidth / this.IllIlIIIIlllIIllIIlllIIlI.displayWidth;
            final int n10 = scaledHeight - Mouse.getY() * scaledHeight / this.IllIlIIIIlllIIllIIlllIIlI.displayHeight - 1;
            final int limitFramerate = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.limitFramerate;
            if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld != null) {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.startSection("level");
                if (this.IllIlIIIIlllIIllIIlllIIlI.isFramerateLimitBelowMax()) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(n, this.llllIIIIIlIlIlIlIllIIIIII + 1000000000 / limitFramerate);
                }
                else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(n, 0L);
                }
                if (OpenGlHelper.lIIlIIllIIIIIlIllIIIIllII) {
                    if (this.IIIIllIlIIIllIlllIlllllIl != null) {
                        GL11.glMatrixMode(5890);
                        GL11.glPushMatrix();
                        GL11.glLoadIdentity();
                        this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n);
                        GL11.glPopMatrix();
                    }
                    this.IllIlIIIIlllIIllIIlllIIlI.getFramebuffer().bindFramebuffer(true);
                }
                this.llllIIIIIlIlIlIlIllIIIIII = System.nanoTime();
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("gui");
                if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl || this.IllIlIIIIlllIIllIIlllIIlI.currentScreen != null) {
                    GL11.glAlphaFunc(516, 3.2f * 0.03125f);
                    final boolean fancyGraphics = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.fancyGraphics;
                    if (!lIIIllIIIllIlllllIIlIllII.IllIIIlIIlIllIllIIllllIIl()) {
                        this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.fancyGraphics = false;
                    }
                    this.IllIlIIIIlllIIllIIlllIIlI.ingameGUI.lIIIIlIIllIIlIIlIIIlIIllI(n, this.IllIlIIIIlllIIllIIlllIIlI.currentScreen != null, n9, n10);
                    this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.fancyGraphics = fancyGraphics;
                    if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllllIllllIlIIIlIIIllllll && !this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugInfo) {
                        lIIIllIIIllIlllllIIlIllII.IlllllIllIIIllIIIllIllIII();
                    }
                }
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endSection();
            }
            else {
                GL11.glViewport(0, 0, this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
                GL11.glMatrixMode(5889);
                GL11.glLoadIdentity();
                GL11.glMatrixMode(5888);
                GL11.glLoadIdentity();
                this.lIIIIllIIlIlIllIIIlIllIlI();
                this.llllIIIIIlIlIlIlIllIIIIII = System.nanoTime();
            }
            if (this.IllIlIIIIlllIIllIIlllIIlI.currentScreen != null) {
                GL11.glClear(256);
                try {
                    this.IllIlIIIIlllIIllIIlllIIlI.currentScreen.lIIIIlIIllIIlIIlIIIlIIllI(n9, n10, n);
                    IlllllIllIIIllIIIllIllIII.llIlIIIlIIIIlIlllIlIIIIll().setIngameFocus();
                }
                catch (Throwable t) {
                    final CrashReport crashReport = CrashReport.makeCrashReport(t, "Rendering screen");
                    final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Screen render details");
                    category.addCrashSectionCallable("Screen name", new llIIlIlIlllllIlIIlIIllIlI(this));
                    category.addCrashSectionCallable("Mouse location", new llIIlllllIlllIlIIllIlllll(this, n9, n10));
                    category.addCrashSectionCallable("Screen size", new IIIIlllIlllllllIllllIIlII(this, scaledResolution));
                    throw new ReportedException(crashReport);
                }
            }
        }
        this.llIlIIIlIIIIlIlllIlIIIIll();
        this.IIIlllIIIllIllIlIIIIIIlII();
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugInfo != this.IIlllllIIlIlIIlIIlllIIIII) {
            this.IllIlIlllIIlIIIIIlIIIIIll = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugProfilerChart;
            this.IIlllllIIlIlIIlIIlllIIIII = this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugInfo;
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugInfo) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.IlllIIIlIlllIllIlIIlllIlI, this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.IIIIllIlIIIllIlllIlllllIl);
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIIlllIIIIllIIllllIlIl) {
            this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.showDebugProfilerChart = true;
        }
    }
    
    public void func_152430_c(final float n) {
        this.lIIIIllIIlIlIllIIIlIllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final long n2) {
        final float n3 = (float)(int)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().lIIlIIllIIIIIlIllIIIIllII.IIIIllIlIIIllIlllIlllllIl();
        if (n3 == 100 || !(boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl()) {
            this.IlIlllIllIlIllIlllIlllIll = 0.0f;
        }
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.startSection("lightTex");
        if (this.IllIIIIllllllIlllllIlIlll) {
            this.lIIIIllIIlIlIllIIIlIllIlI(n);
        }
        GL11.glEnable(2884);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glAlphaFunc(516, 1.1f * 0.09090909f);
        if (this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity == null) {
            this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.thePlayer;
        }
        final boolean liiiIlIIllIIlIIlIIIlIIllI = CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("pick");
        this.lIIIIlIIllIIlIIlIIIlIIllI(n);
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        final RenderGlobal renderGlobal = this.IllIlIIIIlllIIllIIlllIIlI.renderGlobal;
        final EffectRenderer effectRenderer = this.IllIlIIIIlllIIllIIlllIIlI.effectRenderer;
        final double n4 = renderViewEntity.lIlIlIIIlIIllllllllIIlllI + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIlIlIIIlIIllllllllIIlllI) * n;
        final double n5 = renderViewEntity.IlIlllIllIlIllIlllIlllIll + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.IlIlllIllIlIllIlllIlllIll) * n;
        final double n6 = renderViewEntity.llIIIllIIllllIlIlIlIlIIll + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.llIIIllIIllllIlIlIlIlIIll) * n;
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("center");
        for (int i = 0; i < 2; ++i) {
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
                EntityRenderer.lIIIIIIIIIlIllIIllIlIIlIl = i;
                if (EntityRenderer.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                    GL11.glColorMask(false, true, true, false);
                }
                else {
                    GL11.glColorMask(true, false, false, false);
                }
            }
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("clear");
            GL11.glViewport(0, 0, this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
            this.IlllIllIlIIIIlIIlIIllIIIl(n);
            GL11.glClear(16640);
            GL11.glEnable(2884);
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("camera");
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, i, liiiIlIIllIIlIIlIIIlIIllI);
            IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.thePlayer, this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.thirdPersonView == 2);
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("frustrum");
            IlllIIIlIIlIIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI();
            if (!lIIIllIIIllIlllllIIlIllII.IllllllllIlIIIIIIIIllIIII() && !lIIIllIIIllIlllllIIlIllII.lIIlIlIIlIlIlIIlIlIlllIIl() && !lIIIllIIIllIlllllIIlIllII.IIlIlllIllIlIlIIIIIlllIll()) {
                GL11.glDisable(3042);
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI(-1, n);
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("sky");
                renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(n);
            }
            GL11.glEnable(2912);
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, n);
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIllIlIIIIlIIlIIllIIIl != 0) {
                GL11.glShadeModel(7425);
            }
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("culling");
            final lIIIlIIIIlIlIIlIIlIIlIIll liiIlIIIIlIlIIlIIlIIlIIll = new lIIIlIIIIlIlIIlIIlIIlIIll();
            liiIlIIIIlIlIIlIIlIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n6);
            this.IllIlIIIIlllIIllIIlllIIlI.renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIIIIlIlIIlIIlIIlIIll, n);
            if (i == 0) {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("updatechunks");
                if (this.IlIlllIllIlIllIlllIlllIll == 0.0f) {
                    while (!this.IllIlIIIIlllIIllIIlllIIlI.renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity, false) && n2 != 0L) {
                        final long n7 = n2 - System.nanoTime();
                        if (n7 < 0L) {
                            break;
                        }
                        if (n7 > 1000000000L) {
                            break;
                        }
                    }
                }
                ++this.IlIlllIllIlIllIlllIlllIll;
                if (this.IlIlllIllIlIllIlllIlllIll >= 100 / n3) {
                    this.IlIlllIllIlIllIlllIlllIll = 0.0f;
                }
            }
            if (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI < 128) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(renderGlobal, n);
            }
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("prepareterrain");
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, n);
            GL11.glEnable(2912);
            this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().bindTexture(TextureMap.locationBlocksTexture);
            llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("terrain");
            GL11.glMatrixMode(5888);
            GL11.glPushMatrix();
            renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity, 0, n);
            GL11.glShadeModel(7424);
            GL11.glAlphaFunc(516, 0.46153846f * 0.21666667f);
            if (this.IIIlIIllllIIllllllIlIIIll == 0) {
                GL11.glMatrixMode(5888);
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                llIlIlllllIIllIIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl();
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("entities");
                renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity, liiIlIIIIlIlIIlIIlIIlIIll, n);
                llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
                this.lIIIIlIIllIIlIIlIIIlIIllI((double)n);
                GL11.glMatrixMode(5888);
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                if (this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver != null && renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(Material.IllIIIIIIIlIlIllllIIllIII) && renderViewEntity instanceof lIllIIIIlIIlIllIIIlIlIlll && !this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl) {
                    final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = (lIllIIIIlIIlIllIIIlIlIlll)renderViewEntity;
                    GL11.glDisable(3008);
                    this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("outline");
                    if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl) {
                        renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver, 0, n);
                    }
                    GL11.glEnable(3008);
                }
            }
            GL11.glMatrixMode(5888);
            GL11.glPopMatrix();
            if (this.IlIIlllIlIIIlIIIlIlIlIlIl == 1.0 && renderViewEntity instanceof lIllIIIIlIIlIllIIIlIlIlll && !this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl && this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver != null && !renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(Material.IllIIIIIIIlIlIllllIIllIII)) {
                final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll2 = (lIllIIIIlIIlIllIIIlIlIlll)renderViewEntity;
                GL11.glDisable(3008);
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("outline");
                if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl) {
                    renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll2, this.IllIlIIIIlllIIllIIlllIIlI.objectMouseOver, 0, n);
                }
                GL11.glEnable(3008);
            }
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("destroyProgress");
            GL11.glEnable(3042);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 1, 1, 0);
            renderGlobal.lIIIIlIIllIIlIIlIIIlIIllI(Tessellator.instance, renderViewEntity, n);
            GL11.glDisable(3042);
            if (this.IIIlIIllllIIllllllIlIIIll == 0) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n);
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("litParticles");
                effectRenderer.lIIIIIIIIIlIllIIllIlIIlIl(renderViewEntity, n);
                llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
                this.lIIIIlIIllIIlIIlIIIlIIllI(0, n);
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("particles");
                effectRenderer.lIIIIlIIllIIlIIlIIIlIIllI(renderViewEntity, n);
                this.lIIIIlIIllIIlIIlIIIlIIllI((double)n);
            }
            GL11.glDepthMask(false);
            GL11.glEnable(2884);
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("weather");
            this.IIIIllIlIIIllIlllIlllllIl(n);
            GL11.glDepthMask(true);
            CheatBreaker.getInstance().getEventBus().callEvent(new IIIlIIlIlIIIlllIIlIllllll(n));
            GL11.glDisable(3042);
            GL11.glEnable(2884);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            GL11.glAlphaFunc(516, 1.4634147f * 0.068333335f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, n);
            GL11.glEnable(3042);
            GL11.glDepthMask(false);
            this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().bindTexture(TextureMap.locationBlocksTexture);
            IIlllllIlIIlIIIlIIllllIII.IlllIIIlIlllIllIlIIlllIlI();
            if (lIIIllIIIllIlllllIIlIllII.lIllIlIlllIIlIIllIIlIIlII()) {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("water");
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIllIlIIIIlIIlIIllIIIl != 0) {
                    GL11.glShadeModel(7425);
                }
                GL11.glEnable(3042);
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
                    if (EntityRenderer.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                        GL11.glColorMask(false, true, true, true);
                    }
                    else {
                        GL11.glColorMask(true, false, false, true);
                    }
                    renderGlobal.lIIIIIIIIIlIllIIllIlIIlIl(1, n);
                }
                else {
                    renderGlobal.lIIIIIIIIIlIllIIllIlIIlIl(1, n);
                }
                GL11.glDisable(3042);
                GL11.glShadeModel(7424);
            }
            else {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("water");
                renderGlobal.lIIIIIIIIIlIllIIllIlIIlIl(1, n);
            }
            if (CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIllllIIIIlIlIIIIlIlI.IlIlIIIlllIIIlIlllIlIllIl()) {
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.rewind();
                GL11.glGetFloat(2982, CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI);
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIllllIIIIlIlIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl.rewind();
                GL11.glGetFloat(2983, CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIllllIIIIlIlIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            if (CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.IlllIIIlIlllIllIlIIlllIlI()) {
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.rewind();
                GL11.glGetFloat(2982, CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI);
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl.rewind();
                GL11.glGetFloat(2983, CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            IIlllllIlIIlIIIlIIllllIII.IIIIllIlIIIllIlllIlllllIl();
            GL11.glDepthMask(true);
            GL11.glEnable(2884);
            GL11.glDisable(3042);
            GL11.glDisable(2912);
            if (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI >= 128 + (double)(this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIIlllIIlIlllllllllIIIIIl * 128)) {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("aboveClouds");
                this.lIIIIlIIllIIlIIlIIIlIIllI(renderGlobal, n);
            }
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("hand");
            if (this.IlIIlllIlIIIlIIIlIlIlIlIl == 1.0) {
                GL11.glClear(256);
                this.lIIIIlIIllIIlIIlIIIlIIllI(n, i);
            }
            if (!this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
                this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endSection();
                return;
            }
        }
        GL11.glColorMask(true, true, true, false);
        this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endSection();
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final RenderGlobal renderGlobal, final float n) {
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl()) {
            this.IllIlIIIIlllIIllIIlllIIlI.mcProfiler.endStartSection("clouds");
            GL11.glPushMatrix();
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, n);
            GL11.glEnable(2912);
            renderGlobal.lIIIIIIIIIlIllIIllIlIIlIl(n);
            GL11.glDisable(2912);
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, n);
            GL11.glPopMatrix();
        }
    }
    
    private void lIIlIlIllIIlIIIlIIIlllIII() {
        float illlIllIlIIIIlIIlIIllIIIl = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.IlllIllIlIIIIlIIlIIllIIIl(1.0f);
        if (!lIIIllIIIllIlllllIIlIllII.llIlIIIllIIIIlllIlIIIIIlI()) {
            illlIllIlIIIIlIIlIIllIIIl /= 2.0f;
        }
        if (illlIllIlIIIIlIIlIIllIIIl != 0.0f && lIIIllIIIllIlllllIIlIllII.lIlIllIlIlIIIllllIlIllIll()) {
            this.IIIllllIlIIlIIIlIlIlllIII.setSeed(this.lIlIlIllIIIIIIIIllllIIllI * 312987231L);
            final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
            final WorldClient theWorld = this.IllIlIIIIlllIIllIIlllIIlI.theWorld;
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll);
            final int n = 10;
            double n2 = 0.0;
            double n3 = 0.0;
            double n4 = 0.0;
            int bound = 0;
            int n5 = (int)(100 * illlIllIlIIIIlIIlIIllIIIl * illlIllIlIIIIlIIlIIllIIIl);
            if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIllIlllIIllIllllIllIIlll == 1) {
                n5 >>= 1;
            }
            else if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIllIlllIIllIllllIllIIlll == 2) {
                n5 = 0;
            }
            for (int i = 0; i < n5; ++i) {
                final int n6 = illlIIIlIlllIllIlIIlllIlI + this.IIIllllIlIIlIIIlIlIlllIII.nextInt(n) - this.IIIllllIlIIlIIIlIlIlllIII.nextInt(n);
                final int n7 = illlIIIlIlllIllIlIIlllIlI3 + this.IIIllllIlIIlIIIlIlIlllIII.nextInt(n) - this.IIIllllIlIIlIIIlIlIlllIII.nextInt(n);
                final int illIIIIIIIlIlIllllIIllIII = theWorld.IllIIIIIIIlIlIllllIIllIII(n6, n7);
                final IIlllllllIlllIIllllIIlIll block = theWorld.getBlock(n6, illIIIIIIIlIlIllllIIllIII - 1, n7);
                final IIlIIlIIllIIllIlIIIIIIIlI a_ = theWorld.a_(n6, n7);
                if (illIIIIIIIlIlIllllIIllIII <= illlIIIlIlllIllIlIIlllIlI2 + n && illIIIIIIIlIlIllllIIllIII >= illlIIIlIlllIllIlIIlllIlI2 - n && a_.IIIIllIIllIIIIllIllIIIlIl() && a_.lIIIIlIIllIIlIIlIIIlIIllI(n6, illIIIIIIIlIlIllllIIllIII, n7) >= 0.49615386f * 0.30232558f) {
                    final float nextFloat = this.IIIllllIlIIlIIIlIlIlllIII.nextFloat();
                    final float nextFloat2 = this.IIIllllIlIIlIIIlIlIlllIII.nextFloat();
                    if (block.IlIlIIIlllIIIlIlllIlIllIl() == Material.lIIIIllIIlIlIllIIIlIllIlI) {
                        this.IllIlIIIIlllIIllIIlllIIlI.effectRenderer.lIIIIlIIllIIlIIlIIIlIIllI(new IllIIIIlllllIllIIIIIIIIIl(theWorld, n6 + nextFloat, illIIIIIIIlIlIllllIIllIII + 0.4526316f * 0.22093023f - block.IllIllIIIlIIlllIIIllIllII(), n7 + nextFloat2, 0.0, 0.0, 0.0));
                    }
                    else if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                        ++bound;
                        if (this.IIIllllIlIIlIIIlIlIlllIII.nextInt(bound) == 0) {
                            n2 = n6 + nextFloat;
                            n3 = illIIIIIIIlIlIllllIIllIII + 19.0f * 0.005263158f - block.IllIllIIIlIIlllIIIllIllII();
                            n4 = n7 + nextFloat2;
                        }
                        final IIlllIlIIllIlllIIllIIIlII illlIlIIllIlllIIllIIIlII = new IIlllIlIIllIlllIIllIIIlII(theWorld, n6 + nextFloat, illIIIIIIIlIlIllllIIllIII + 6.8333335f * 0.014634146f - block.IllIllIIIlIIlllIIIllIllII(), n7 + nextFloat2);
                        lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(illlIlIIllIlllIIllIIIlII, theWorld);
                        this.IllIlIIIIlllIIllIIlllIIlI.effectRenderer.lIIIIlIIllIIlIIlIIIlIIllI(illlIlIIllIlllIIllIIIlII);
                    }
                }
            }
            if (bound > 0 && this.IIIllllIlIIlIIIlIlIlllIII.nextInt(3) < this.IIlIlllllIIIlIIllIllIlIlI++) {
                this.IIlIlllllIIIlIIllIllIlIlI = 0;
                if (n3 > renderViewEntity.IllIlIIIIlllIIllIIlllIIlI + 1.0 && theWorld.IllIIIIIIIlIlIllllIIllIII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll)) > MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI)) {
                    this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIlIIllIIlIIlIIIlIIllI(n2, n3, n4, "ambient.weather.rain", 0.88505745f * 0.11298702f, 0.62068963f * 0.8055556f, false);
                }
                else {
                    this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIlIIllIIlIIlIIIlIIllI(n2, n3, n4, "ambient.weather.rain", 0.35999998f * 0.5555556f, 1.0f, false);
                }
            }
        }
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl(final float n) {
        final float illlIllIlIIIIlIIlIIllIIIl = this.IllIlIIIIlllIIllIIlllIIlI.theWorld.IlllIllIlIIIIlIIlIIllIIIl(n);
        if (illlIllIlIIIIlIIlIIllIIIl > 0.0f) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(n);
            if (this.IlllIllIlIIIIlIIlIIllIIIl == null) {
                this.IlllIllIlIIIIlIIlIIllIIIl = new float[1024];
                this.IlIlllIIIIllIllllIllIIlIl = new float[1024];
                for (int i = 0; i < 32; ++i) {
                    for (int j = 0; j < 32; ++j) {
                        final float n2 = (float)(j - 16);
                        final float n3 = (float)(i - 16);
                        final float illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n2 * n2 + n3 * n3);
                        this.IlllIllIlIIIIlIIlIIllIIIl[i << 5 | j] = -n3 / illlIIIlIlllIllIlIIlllIlI;
                        this.IlIlllIIIIllIllllIllIIlIl[i << 5 | j] = n2 / illlIIIlIlllIllIlIIlllIlI;
                    }
                }
            }
            if (lIIIllIIIllIlllllIIlIllII.IIIlIIlIlIIIlllIIlIllllll()) {
                return;
            }
            final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
            final WorldClient theWorld = this.IllIlIIIIlllIIllIIlllIIlI.theWorld;
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIIIIlllIIllIIlllIIlI);
            final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(renderViewEntity.IllIlIlIllllIlIIllllIIlll);
            final Tessellator instance = Tessellator.instance;
            GL11.glDisable(2884);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            GL11.glEnable(3042);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            GL11.glAlphaFunc(516, 0.030666668f * 3.2608695f);
            final double n4 = renderViewEntity.lIlIlIIIlIIllllllllIIlllI + (renderViewEntity.IIIlIIlIlIIIlllIIlIllllll - renderViewEntity.lIlIlIIIlIIllllllllIIlllI) * n;
            final double n5 = renderViewEntity.IlIlllIllIlIllIlllIlllIll + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.IlIlllIllIlIllIlllIlllIll) * n;
            final double n6 = renderViewEntity.llIIIllIIllllIlIlIlIlIIll + (renderViewEntity.IllIlIlIllllIlIIllllIIlll - renderViewEntity.llIIIllIIllllIlIlIlIlIIll) * n;
            final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n5);
            int n7 = 5;
            if (lIIIllIIIllIlllllIIlIllII.llIlIIIllIIIIlllIlIIIIIlI()) {
                n7 = 10;
            }
            int n8 = -1;
            final float n9 = this.lIlIlIllIIIIIIIIllllIIllI + n;
            if (lIIIllIIIllIlllllIIlIllII.llIlIIIllIIIIlllIlIIIIIlI()) {
                n7 = 10;
            }
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            for (int k = illlIIIlIlllIllIlIIlllIlI4 - n7; k <= illlIIIlIlllIllIlIIlllIlI4 + n7; ++k) {
                for (int l = illlIIIlIlllIllIlIIlllIlI2 - n7; l <= illlIIIlIlllIllIlIIlllIlI2 + n7; ++l) {
                    final int n10 = (k - illlIIIlIlllIllIlIIlllIlI4 + 16) * 32 + l - illlIIIlIlllIllIlIIlllIlI2 + 16;
                    final float n11 = this.IlllIllIlIIIIlIIlIIllIIIl[n10] * (0.4871795f * 1.0263158f);
                    final float n12 = this.IlIlllIIIIllIllllIllIIlIl[n10] * (1.5f * 0.33333334f);
                    final IIlIIlIIllIIllIlIIIIIIIlI a_ = theWorld.a_(l, k);
                    if (a_.IIIIllIIllIIIIllIllIIIlIl() || a_.IIIIllIlIIIllIlllIlllllIl()) {
                        final int illIIIIIIIlIlIllllIIllIII = theWorld.IllIIIIIIIlIlIllllIIllIII(l, k);
                        int n13 = illlIIIlIlllIllIlIIlllIlI3 - n7;
                        int n14 = illlIIIlIlllIllIlIIlllIlI3 + n7;
                        if (n13 < illIIIIIIIlIlIllllIIllIII) {
                            n13 = illIIIIIIIlIlIllllIIllIII;
                        }
                        if (n14 < illIIIIIIIlIlIllllIIllIII) {
                            n14 = illIIIIIIIlIlIllllIIllIII;
                        }
                        final float n15 = 1.0f;
                        int n16;
                        if ((n16 = illIIIIIIIlIlIllllIIllIII) < illlIIIlIlllIllIlIIlllIlI5) {
                            n16 = illlIIIlIlllIllIlIIlllIlI5;
                        }
                        if (n13 != n14) {
                            this.IIIllllIlIIlIIIlIlIlllIII.setSeed(l * l * 3121 + l * 45238971 ^ k * k * 418711 + k * 13761);
                            if (theWorld.lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(a_.lIIIIlIIllIIlIIlIIIlIIllI(l, n13, k), illIIIIIIIlIlIllllIIllIII) >= 0.30769232f * 0.4875f) {
                                if (n8 != 0) {
                                    if (n8 >= 0) {
                                        instance.draw();
                                    }
                                    n8 = 0;
                                    this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().bindTexture(EntityRenderer.llIlIIIllIIIIlllIlIIIIIlI);
                                    instance.startDrawingQuads();
                                }
                                final float n17 = ((this.lIlIlIllIIIIIIIIllllIIllI + l * l * 3121 + l * 45238971 + k * k * 418711 + k * 13761 & 0x1F) + n) / 32 * (3 + this.IIIllllIlIIlIIIlIlIlllIII.nextFloat());
                                final double n18 = l + 0.47894737f * 1.043956f - renderViewEntity.IIIlIIlIlIIIlllIIlIllllll;
                                final double n19 = k + 0.34343436f * 1.4558823f - renderViewEntity.IllIlIlIllllIlIIllllIIlll;
                                final float n20 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n18 * n18 + n19 * n19) / n7;
                                final float n21 = 1.0f;
                                instance.lIIIIIIIIIlIllIIllIlIIlIl(theWorld.lIIIIlIIllIIlIIlIIIlIIllI(l, n16, k, 0));
                                instance.lIIIIlIIllIIlIIlIIIlIIllI(n21, n21, n21, ((1.0f - n20 * n20) * (0.028985508f * 17.25f) + 0.546875f * 0.9142857f) * illlIllIlIIIIlIIlIIllIIIl);
                                instance.lIIIIIIIIIlIllIIllIlIIlIl(-n4 * 1.0, -n5 * 1.0, -n6 * 1.0);
                                instance.addVertexWithUV(l - n11 + 0.27551020542217863 * 1.814814805984497, n13, k - n12 + 0.5 * 1.0, 0.0f * n15, n13 * n15 / 4 + n17 * n15);
                                instance.addVertexWithUV(l + n11 + 1.878787875175476 * 0.2661290327697589, n13, k + n12 + 0.48275861144065857 * 1.035714305557159, 1.0f * n15, n13 * n15 / 4 + n17 * n15);
                                instance.addVertexWithUV(l + n11 + 1.4615384340286255 * 0.3421052695971778, n14, k + n12 + 1.4307692050933838 * 0.34946237186266943, 1.0f * n15, n14 * n15 / 4 + n17 * n15);
                                instance.addVertexWithUV(l - n11 + 2.807692211143367 * 0.1780821979045868, n14, k - n12 + 0.3157894657589394 * 1.5833333730697632, 0.0f * n15, n14 * n15 / 4 + n17 * n15);
                                instance.lIIIIIIIIIlIllIIllIlIIlIl(0.0, 0.0, 0.0);
                            }
                            else {
                                if (n8 != 1) {
                                    if (n8 >= 0) {
                                        instance.draw();
                                    }
                                    n8 = 1;
                                    this.IllIlIIIIlllIIllIIlllIIlI.llIlIlIllIlIIlIlllIllIIlI().bindTexture(EntityRenderer.lIllIlIlllIIlIIllIIlIIlII);
                                    instance.startDrawingQuads();
                                }
                                final float n22 = ((this.lIlIlIllIIIIIIIIllllIIllI & 0x1FF) + n) / 512;
                                final float n23 = this.IIIllllIlIIlIIIlIlIlllIII.nextFloat() + n9 * (7.0f * 0.0014285714f) * (float)this.IIIllllIlIIlIIIlIlIlllIII.nextGaussian();
                                final float n24 = this.IIIllllIlIIlIIIlIlIlllIII.nextFloat() + n9 * (float)this.IIIllllIlIIlIIIlIlIlllIII.nextGaussian() * (4.0909092E-4f * 2.4444444f);
                                final double n25 = l + 0.43373492f * 1.1527778f - renderViewEntity.IIIlIIlIlIIIlllIIlIllllll;
                                final double n26 = k + 0.6666667f * 0.75f - renderViewEntity.IllIlIlIllllIlIIllllIIlll;
                                final float n27 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n25 * n25 + n26 * n26) / n7;
                                final float n28 = 1.0f;
                                instance.lIIIIIIIIIlIllIIllIlIIlIl((theWorld.lIIIIlIIllIIlIIlIIIlIIllI(l, n16, k, 0) * 3 + 15728880) / 4);
                                instance.lIIIIlIIllIIlIIlIIIlIIllI(n28, n28, n28, ((1.0f - n27 * n27) * (0.37349397f * 0.8032259f) + 0.8362069f * 0.5979381f) * illlIllIlIIIIlIIlIIllIIIl);
                                instance.lIIIIIIIIIlIllIIllIlIIlIl(-n4 * 1.0, -n5 * 1.0, -n6 * 1.0);
                                instance.addVertexWithUV(l - n11 + 0.34999999165534995 * 1.4285714626312256, n13, k - n12 + 0.5 * 1.0, 0.0f * n15 + n23, n13 * n15 / 4 + n22 * n15 + n24);
                                instance.addVertexWithUV(l + n11 + 1.234375 * 0.4050632911392405, n13, k + n12 + 0.4845360815525055 * 1.0319148955800082, 1.0f * n15 + n23, n13 * n15 / 4 + n22 * n15 + n24);
                                instance.addVertexWithUV(l + n11 + 0.3076923191547394 * 1.6249999394640349, n14, k + n12 + 0.07692307692307693 * 6.5, 1.0f * n15 + n23, n14 * n15 / 4 + n22 * n15 + n24);
                                instance.addVertexWithUV(l - n11 + 2.0 * 0.25, n14, k - n12 + 1.2894736528396606 * 0.38775511147428804, 0.0f * n15 + n23, n14 * n15 / 4 + n22 * n15 + n24);
                                instance.lIIIIIIIIIlIllIIllIlIIlIl(0.0, 0.0, 0.0);
                            }
                        }
                    }
                }
            }
            if (n8 >= 0) {
                instance.draw();
            }
            GL11.glEnable(2884);
            GL11.glDisable(3042);
            GL11.glAlphaFunc(516, 2.357143f * 0.042424243f);
            this.lIIIIlIIllIIlIIlIIIlIIllI((double)n);
        }
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI() {
        final ScaledResolution scaledResolution = new ScaledResolution(this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.IllIlIIIIlllIIllIIlllIIlI.displayHeight);
        GL11.glClear(256);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, scaledResolution.IlllIIIlIlllIllIlIIlllIlI(), scaledResolution.IIIIllIlIIIllIlllIlllllIl(), 0.0, (double)1000, (double)3000);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, (float)(-2000));
    }
    
    private void IlllIllIlIIIIlIIlIIllIIIl(final float n) {
        final WorldClient theWorld = this.IllIlIIIIlllIIllIIlllIIlI.theWorld;
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        final float n2 = 1.0f - (float)Math.pow(0.6136364f * 0.4074074f + 1.3529412f * 0.5543478f * this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIIIlIlllIllIlIIlllIlI / 16, 0.4047619104385376 * 0.6176470501612629);
        final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(theWorld.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity, n), theWorld, this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity, n);
        final float n3 = (float)liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI;
        final float n4 = (float)liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl;
        final float n5 = (float)liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI;
        final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(theWorld.IlIlIIIlllIIIlIlllIlIllIl(n), theWorld, n);
        this.lIIlIlIllIIlIIIlIIIlllIII = (float)liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IIIlllIIIllIllIlIIIIIIlII = (float)liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl;
        this.llIlIIIlIIIIlIlllIlIIIIll = (float)liiiIlIIllIIlIIlIIIlIIllI2.IlllIIIlIlllIllIlIIlllIlI;
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IlllIIIlIlllIllIlIIlllIlI >= 4) {
            float n6 = (float)renderViewEntity.llIIlllIIIIlllIllIlIlllIl(n).lIIIIIIIIIlIllIIllIlIIlIl((MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(theWorld.IIIIllIlIIIllIlllIlllllIl(n)) > 0.0f) ? lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(-1, 0.0, 0.0) : lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(1.0, 0.0, 0.0));
            if (n6 < 0.0f) {
                n6 = 0.0f;
            }
            if (n6 > 0.0f) {
                final float[] liiiIlIIllIIlIIlIIIlIIllI3 = theWorld.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(theWorld.IlllIIIlIlllIllIlIIlllIlI(n), n);
                if (liiiIlIIllIIlIIlIIIlIIllI3 != null) {
                    final float n7 = n6 * liiiIlIIllIIlIIlIIIlIIllI3[3];
                    this.lIIlIlIllIIlIIIlIIIlllIII = this.lIIlIlIllIIlIIIlIIIlllIII * (1.0f - n7) + liiiIlIIllIIlIIlIIIlIIllI3[0] * n7;
                    this.IIIlllIIIllIllIlIIIIIIlII = this.IIIlllIIIllIllIlIIIIIIlII * (1.0f - n7) + liiiIlIIllIIlIIlIIIlIIllI3[1] * n7;
                    this.llIlIIIlIIIIlIlllIlIIIIll = this.llIlIIIlIIIIlIlllIlIIIIll * (1.0f - n7) + liiiIlIIllIIlIIlIIIlIIllI3[2] * n7;
                }
            }
        }
        this.lIIlIlIllIIlIIIlIIIlllIII += (n3 - this.lIIlIlIllIIlIIIlIIIlllIII) * n2;
        this.IIIlllIIIllIllIlIIIIIIlII += (n4 - this.IIIlllIIIllIllIlIIIIIIlII) * n2;
        this.llIlIIIlIIIIlIlllIlIIIIll += (n5 - this.llIlIIIlIIIIlIlllIlIIIIll) * n2;
        final float illlIllIlIIIIlIIlIIllIIIl = theWorld.IlllIllIlIIIIlIIlIIllIIIl(n);
        if (illlIllIlIIIIlIIlIIllIIIl > 0.0f) {
            final float n8 = 1.0f - illlIllIlIIIIlIIlIIllIIIl * (0.54761904f * 0.9130435f);
            final float n9 = 1.0f - illlIllIlIIIIlIIlIIllIIIl * (1.6470588f * 0.24285714f);
            this.lIIlIlIllIIlIIIlIIIlllIII *= n8;
            this.IIIlllIIIllIllIlIIIIIIlII *= n8;
            this.llIlIIIlIIIIlIlllIlIIIIll *= n9;
        }
        final float illIIIIIIIlIlIllllIIllIII = theWorld.IllIIIIIIIlIlIllllIIllIII(n);
        if (illIIIIIIIlIlIllllIIllIII > 0.0f) {
            final float n10 = 1.0f - illIIIIIIIlIlIllllIIllIII * (4.0454545f * 0.123595506f);
            this.lIIlIlIllIIlIIIlIIIlllIII *= n10;
            this.IIIlllIIIllIllIlIIIIIIlII *= n10;
            this.llIlIIIlIIIIlIlllIlIIIIll *= n10;
        }
        final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI4 = IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.theWorld, renderViewEntity, n);
        if (this.lIIlIlIIlIlIlIIlIlIlllIIl) {
            final lIllIIIIlllllIIlIllIIIIII iiiIllIIllIIIIllIllIIIlIl = theWorld.IIIIllIIllIIIIllIllIIIlIl(n);
            this.lIIlIlIllIIlIIIlIIIlllIII = (float)iiiIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI;
            this.IIIlllIIIllIllIlIIIIIIlII = (float)iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl;
            this.llIlIIIlIIIIlIlllIlIIIIll = (float)iiiIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI;
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI4.IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
            final float n11 = lIIlllIlIllIIIIIlIlllIIII.lIIIIIIIIIlIllIIllIlIIlIl(renderViewEntity) * (0.53968257f * 0.3705882f);
            this.lIIlIlIllIIlIIIlIIIlllIII = 1.2105263f * 0.016521739f + n11;
            this.IIIlllIIIllIllIlIIIIIIlII = 0.02f * 1.0f + n11;
            this.llIlIIIlIIIIlIlllIlIIIIll = 1.6f * 0.125f + n11;
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI5 = lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.theWorld, this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IllIlIIIIlllIIllIIlllIIlI + 1.0, this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity.IllIlIlIllllIlIIllllIIlll);
            if (liiiIlIIllIIlIIlIIIlIIllI5 != null) {
                this.lIIlIlIllIIlIIIlIIIlllIII = (float)liiiIlIIllIIlIIlIIIlIIllI5.lIIIIlIIllIIlIIlIIIlIIllI;
                this.IIIlllIIIllIllIlIIIIIIlII = (float)liiiIlIIllIIlIIlIIIlIIllI5.lIIIIIIIIIlIllIIllIlIIlIl;
                this.llIlIIIlIIIIlIlllIlIIIIll = (float)liiiIlIIllIIlIIlIIIlIIllI5.IlllIIIlIlllIllIlIIlllIlI;
            }
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI4.IlIlIIIlllIIIlIlllIlIllIl() == Material.lIIIIllIIlIlIllIIIlIllIlI) {
            this.lIIlIlIllIIlIIIlIIIlllIII = 0.9093751f * 0.6597938f;
            this.IIIlllIIIllIllIlIIIIIIlII = 0.04782609f * 2.090909f;
            this.llIlIIIlIIIIlIlllIlIIIIll = 0.0f;
        }
        final float n12 = this.IlIllIllIllIllIllllIIIlII + (this.lllIllIllIlIllIlIIllllIIl - this.IlIllIllIllIllIllllIIIlII) * n;
        this.lIIlIlIllIIlIIIlIIIlllIII *= n12;
        this.IIIlllIIIllIllIlIIIIIIlII *= n12;
        this.llIlIIIlIIIIlIlllIlIIIIll *= n12;
        double ilIlllIIIIllIllllIllIIlIl = theWorld.lIIIIIllllIIIIlIlIIIIlIlI.IlIlllIIIIllIllllIllIIlIl();
        if (!lIIIllIIIllIlllllIIlIllII.IIlIlIIlIIIlIlllllIIlIIlI()) {
            ilIlllIIIIllIllllIllIIlIl = 1.0;
        }
        double n13 = (renderViewEntity.IlIlllIllIlIllIlllIlllIll + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.IlIlllIllIlIllIlllIlllIll) * n) * ilIlllIIIIllIllllIllIIlIl;
        if (renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lllIIIIIlIllIlIIIllllllII)) {
            final int liiiiiiiiIlIllIIllIlIIlIl = renderViewEntity.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.lllIIIIIlIllIlIIIllllllII).lIIIIIIIIIlIllIIllIlIIlIl();
            if (liiiiiiiiIlIllIIllIlIIlIl < 20) {
                n13 *= 1.0f - liiiiiiiiIlIllIIllIlIIlIl / (float)20;
            }
            else {
                n13 = 0.0;
            }
        }
        if (n13 < 1.0) {
            if (n13 < 0.0) {
                n13 = 0.0;
            }
            final double n14 = n13 * n13;
            this.lIIlIlIllIIlIIIlIIIlllIII *= (float)n14;
            this.IIIlllIIIllIllIlIIIIIIlII *= (float)n14;
            this.llIlIIIlIIIIlIlllIlIIIIll *= (float)n14;
        }
        if (this.IIIlIllIlllIlIllIllllllll > 0.0f) {
            final float n15 = this.IllllllllIlIIIIIIIIllIIII + (this.IIIlIllIlllIlIllIllllllll - this.IllllllllIlIIIIIIIIllIIII) * n;
            this.lIIlIlIllIIlIIIlIIIlllIII = this.lIIlIlIllIIlIIIlIIIlllIII * (1.0f - n15) + this.lIIlIlIllIIlIIIlIIIlllIII * (0.65f * 1.0769231f) * n15;
            this.IIIlllIIIllIllIlIIIIIIlII = this.IIIlllIIIllIllIlIIIIIIlII * (1.0f - n15) + this.IIIlllIIIllIllIlIIIIIIlII * (1.1714287f * 0.5121951f) * n15;
            this.llIlIIIlIIIIlIlllIlIIIIll = this.llIlIIIlIIIIlIlllIlIIIIll * (1.0f - n15) + this.llIlIIIlIIIIlIlllIlIIIIll * (1.4489796f * 0.41408452f) * n15;
        }
        if (renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lIIIIIllllIIIIlIlIIIIlIlI)) {
            final float liiiIlIIllIIlIIlIIIlIIllI6 = this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.thePlayer, n);
            float n16 = 1.0f / this.lIIlIlIllIIlIIIlIIIlllIII;
            if (n16 > 1.0f / this.IIIlllIIIllIllIlIIIIIIlII) {
                n16 = 1.0f / this.IIIlllIIIllIllIlIIIIIIlII;
            }
            if (n16 > 1.0f / this.llIlIIIlIIIIlIlllIlIIIIll) {
                n16 = 1.0f / this.llIlIIIlIIIIlIlllIlIIIIll;
            }
            this.lIIlIlIllIIlIIIlIIIlllIII = this.lIIlIlIllIIlIIIlIIIlllIII * (1.0f - liiiIlIIllIIlIIlIIIlIIllI6) + this.lIIlIlIllIIlIIIlIIIlllIII * n16 * liiiIlIIllIIlIIlIIIlIIllI6;
            this.IIIlllIIIllIllIlIIIIIIlII = this.IIIlllIIIllIllIlIIIIIIlII * (1.0f - liiiIlIIllIIlIIlIIIlIIllI6) + this.IIIlllIIIllIllIlIIIIIIlII * n16 * liiiIlIIllIIlIIlIIIlIIllI6;
            this.llIlIIIlIIIIlIlllIlIIIIll = this.llIlIIIlIIIIlIlllIlIIIIll * (1.0f - liiiIlIIllIIlIIlIIIlIIllI6) + this.llIlIIIlIIIIlIlllIlIIIIll * n16 * liiiIlIIllIIlIIlIIIlIIllI6;
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.IIIIllIIllIIIIllIllIIIlIl) {
            final float liIlIlIllIIlIIIlIIIlllIII = (this.lIIlIlIllIIlIIIlIIIlllIII * 30 + this.IIIlllIIIllIllIlIIIIIIlII * 59 + this.llIlIIIlIIIIlIlllIlIIIIll * 11) / 100;
            final float iiIlllIIIllIllIlIIIIIIlII = (this.lIIlIlIllIIlIIIlIIIlllIII * 30 + this.IIIlllIIIllIllIlIIIIIIlII * 70) / 100;
            final float llIlIIIlIIIIlIlllIlIIIIll = (this.lIIlIlIllIIlIIIlIIIlllIII * 30 + this.llIlIIIlIIIIlIlllIlIIIIll * 70) / 100;
            this.lIIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII;
            this.IIIlllIIIllIllIlIIIIIIlII = iiIlllIIIllIllIlIIIIIIlII;
            this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
        }
        GL11.glClearColor(this.lIIlIlIllIIlIIIlIIIlllIII, this.IIIlllIIIllIllIlIIIIIIlII, this.llIlIIIlIIIIlIlllIlIIIIll, 0.0f);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final float n2) {
        final EntityLivingBase renderViewEntity = this.IllIlIIIIlllIIllIIlllIIlI.renderViewEntity;
        boolean iiiIllIlIIIllIlllIlllllIl = false;
        this.lllIIIIIlIllIlIIIllllllII = false;
        if (renderViewEntity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            iiiIllIlIIIllIlllIlllllIl = ((lIllIIIIlIIlIllIIIlIlIlll)renderViewEntity).IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl;
        }
        if (n == 999) {
            GL11.glFog(2918, this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f));
            GL11.glFogi(2917, 9729);
            GL11.glFogf(2915, 0.0f);
            GL11.glFogf(2916, (float)8);
            if (GLContext.getCapabilities().GL_NV_fog_distance) {
                GL11.glFogi(34138, 34139);
            }
            GL11.glFogf(2915, 0.0f);
        }
        else {
            GL11.glFog(2918, this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, this.IIIlllIIIllIllIlIIIIIIlII, this.llIlIIIlIIIIlIlllIlIIIIll, 1.0f));
            GL11.glNormal3f(0.0f, (float)(-1), 0.0f);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI = IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI.theWorld, renderViewEntity, n2);
            if (renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lllIIIIIlIllIlIIIllllllII)) {
                float n3 = 5;
                final int liiiiiiiiIlIllIIllIlIIlIl = renderViewEntity.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.lllIIIIIlIllIlIIIllllllII).lIIIIIIIIIlIllIIllIlIIlIl();
                if (liiiiiiiiIlIllIIllIlIIlIl < 20) {
                    n3 = 5 + (this.IllIlIlIllllIlIIllllIIlll - 5) * (1.0f - liiiiiiiiIlIllIIllIlIIlIl / (float)20);
                }
                GL11.glFogi(2917, 9729);
                if (n < 0) {
                    GL11.glFogf(2915, 0.0f);
                    GL11.glFogf(2916, n3 * (8.25f * 0.0969697f));
                }
                else {
                    GL11.glFogf(2915, n3 * (1.5f * 0.16666667f));
                    GL11.glFogf(2916, n3);
                }
                if (lIIIllIIIllIlllllIIlIllII.llIlIIIlIIIIlIlllIlIIIIll()) {
                    GL11.glFogi(34138, 34139);
                }
            }
            else if (this.lIIlIlIIlIlIlIIlIlIlllIIl) {
                GL11.glFogi(2917, 2048);
                GL11.glFogf(2914, 1.0958904f * 0.09125f);
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
                GL11.glFogi(2917, 2048);
                if (renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.llIlIIIlIIIIlIlllIlIIIIll)) {
                    GL11.glFogf(2914, 0.25396827f * 0.19687499f);
                }
                else {
                    GL11.glFogf(2914, 0.16491228f * 0.60638297f - lIIlllIlIllIIIIIlIlllIIII.lIIIIIIIIIlIllIIllIlIIlIl(renderViewEntity) * (0.089999996f * 0.33333334f));
                }
                if (lIIIllIIIllIlllllIIlIllII.IlIIlllIlIIIlIIIlIlIlIlIl()) {
                    GL11.glFogf(2914, 0.76f * 0.02631579f);
                }
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() == Material.lIIIIllIIlIlIllIIIlIllIlI) {
                GL11.glFogi(2917, 2048);
                GL11.glFogf(2914, 2.0f);
            }
            else {
                float illIlIlIllllIlIIllllIIlll = this.IllIlIlIllllIlIIllllIIlll;
                this.lllIIIIIlIllIlIIIllllllII = true;
                if (lIIIllIIIllIlllllIIlIllII.IIlIlIIlIIIlIlllllIIlIIlI() && this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIIllllIIIIlIlIIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl() && !iiiIllIlIIIllIlllIlllllIl) {
                    double n4 = ((renderViewEntity.lIIIIlIIllIIlIIlIIIlIIllI(n2) & 0xF00000) >> 20) / (double)16 + (renderViewEntity.IlIlllIllIlIllIlllIlllIll + (renderViewEntity.IllIlIIIIlllIIllIIlllIIlI - renderViewEntity.IlIlllIllIlIllIlllIlllIll) * n2 + 4) / 32;
                    if (n4 < 1.0) {
                        if (n4 < 0.0) {
                            n4 = 0.0;
                        }
                        float n5 = 100 * (float)(n4 * n4);
                        if (n5 < 5) {
                            n5 = 5;
                        }
                        if (illIlIlIllllIlIIllllIIlll > n5) {
                            illIlIlIllllIlIIllllIIlll = n5;
                        }
                    }
                }
                GL11.glFogi(2917, 9729);
                if (n < 0) {
                    GL11.glFogf(2915, 0.0f);
                    GL11.glFogf(2916, illIlIlIllllIlIIllllIIlll);
                }
                else {
                    GL11.glFogf(2915, illIlIlIllllIlIIllllIIlll * lIIIllIIIllIlllllIIlIllII.lIIIIIllllIIIIlIlIIIIlIlI());
                    GL11.glFogf(2916, illIlIlIllllIlIIllllIIlll);
                }
                if (GLContext.getCapabilities().GL_NV_fog_distance) {
                    if (lIIIllIIIllIlllllIIlIllII.llIlIIIlIIIIlIlllIlIIIIll()) {
                        GL11.glFogi(34138, 34139);
                    }
                    if (lIIIllIIIllIlllllIIlIllII.IIIlIIllllIIllllllIlIIIll()) {
                        GL11.glFogi(34138, 34140);
                    }
                }
                if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl((int)renderViewEntity.IIIlIIlIlIIIlllIIlIllllll, (int)renderViewEntity.IllIlIlIllllIlIIllllIIlll)) {
                    final float illIlIlIllllIlIIllllIIlll2 = this.IllIlIlIllllIlIIllllIIlll;
                    GL11.glFogf(2915, illIlIlIllllIlIIllllIIlll2 * (2.45f * 0.020408163f));
                    GL11.glFogf(2916, illIlIlIllllIlIIllllIIlll2);
                }
            }
            GL11.glEnable(2903);
            GL11.glColorMaterial(1028, 4608);
        }
    }
    
    private FloatBuffer lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4) {
        this.llIIlllIIIIlllIllIlIlllIl.clear();
        this.llIIlllIIIIlllIllIlIlllIl.put(n).put(n2).put(n3).put(n4);
        this.llIIlllIIIIlllIllIlIlllIl.flip();
        return this.llIIlllIIIIlllIllIlIlllIl;
    }
    
    public lIlIlIlIIlIIIIIlIllIlIlII IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IllIIlIIlllllIllIIIlllIII;
    }
    
    private void IIIlllIIIllIllIlIIIIIIlII() {
        this.lIlIlIlIIlIlllIIIIIIllllI = 0;
        if (!lIIIllIIIllIlllllIIlIllII.IIIlllIllIlIIllIIllIlIlll()) {
            this.IIlIlIlllIllIIlIllIIlIIlI = 0L;
            this.lIlIIllIIIlllIIllIIlIIllI = 0;
        }
        else if (this.IllIlIIIIlllIIllIIlllIIlI.IlIlIIIlllllIIIlIlIlIllII() != null) {
            final IntegratedServer ilIlIIIlllllIIIlIlIlIllII = this.IllIlIIIIlllIIllIIlllIIlI.IlIlIIIlllllIIIlIlIlIllII();
            if (!this.IllIlIIIIlllIIllIIlllIIlI.IIlIlIIlIIIlIlllllIIlIIlI() && !(this.IllIlIIIIlllIIllIIlllIIlI.currentScreen instanceof lIIllllIlllIlllllIIlIIIIl)) {
                if (this.lIIIlIIIIIIlIIlIIlIIlIIlI > 0) {
                    lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI((long)this.lIIIlIIIIIIlIIlIIlIIlIIlI);
                    this.lIlIlIlIIlIlllIIIIIIllllI = this.lIIIlIIIIIIlIIlIIlIIlIIlI;
                }
                final long iIlIlIlllIllIIlIllIIlIIlI = System.nanoTime() / 1000000L;
                if (this.IIlIlIlllIllIIlIllIIlIIlI != 0L && this.lIlIIllIIIlllIIllIIlIIllI != 0) {
                    long n = iIlIlIlllIllIIlIllIIlIIlI - this.IIlIlIlllIllIIlIllIIlIIlI;
                    if (n < 0L) {
                        this.IIlIlIlllIllIIlIllIIlIIlI = iIlIlIlllIllIIlIllIIlIIlI;
                        n = 0L;
                    }
                    if (n >= 50L) {
                        this.IIlIlIlllIllIIlIllIIlIIlI = iIlIlIlllIllIIlIllIIlIIlI;
                        final int iiiiIlIllIllIlIIllIIlIllI = ilIlIIIlllllIIIlIlIlIllII.IIIIIlIllIllIlIIllIIlIllI();
                        int n2 = iiiiIlIllIllIlIIllIIlIllI - this.lIlIIllIIIlllIIllIIlIIllI;
                        if (n2 < 0) {
                            this.lIlIIllIIIlllIIllIIlIIllI = iiiiIlIllIllIlIIllIIlIllI;
                            n2 = 0;
                        }
                        if (n2 < 1 && this.lIIIlIIIIIIlIIlIIlIIlIIlI < 100) {
                            this.lIIIlIIIIIIlIIlIIlIIlIIlI += 2;
                        }
                        if (n2 > 1 && this.lIIIlIIIIIIlIIlIIlIIlIIlI > 0) {
                            --this.lIIIlIIIIIIlIIlIIlIIlIIlI;
                        }
                        this.lIlIIllIIIlllIIllIIlIIllI = iiiiIlIllIllIlIIllIIlIllI;
                    }
                }
                else {
                    this.IIlIlIlllIllIIlIllIIlIIlI = iIlIlIlllIllIIlIllIIlIIlI;
                    this.lIlIIllIIIlllIIllIIlIIllI = ilIlIIIlllllIIIlIlIlIllII.IIIIIlIllIllIlIIllIIlIllI();
                    this.IllIlIIIIlIlllIlllllllIIl = 1.0f;
                    this.llllIIllIIlllllIlIlIIllll = 50;
                }
            }
            else {
                if (this.IllIlIIIIlllIIllIIlllIIlI.currentScreen instanceof lIIllllIlllIlllllIIlIIIIl) {
                    lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(20L);
                }
                this.IIlIlIlllIllIIlIllIIlIIlI = 0L;
                this.lIlIIllIIIlllIIllIIlIIllI = 0;
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final long n, final long n2) {
        if (this.IllIlIIIIlllIIllIIlllIIlI.gameSettings.lIlIlIllIIIIIIIIllllIIllI || this.IllIlIlllIIlIIIIIlIIIIIll) {
            if (this.lIIlllIIlIlllllllllIIIIIl == -1L) {
                this.lIIlllIIlIlllllllllIIIIIl = System.nanoTime();
            }
            final long nanoTime = System.nanoTime();
            final int n3 = this.lIIlIIllIIIIIlIllIIIIllII & this.lIIIIIllllIIIIlIlIIIIlIlI.length - 1;
            this.IIIIIIlIlIlIllllllIlllIlI[n3] = n;
            this.IllIllIIIlIIlllIIIllIllII[n3] = n2;
            this.IlIIlIIIIlIIIIllllIIlIllI[n3] = this.lIlIlIlIIlIlllIIIIIIllllI;
            this.lIIIIIllllIIIIlIlIIIIlIlI[n3] = nanoTime - this.lIIlllIIlIlllllllllIIIIIl;
            ++this.lIIlIIllIIIIIlIllIIIIllII;
            this.lIIlllIIlIlllllllllIIIIIl = nanoTime;
            GL11.glClear(256);
            GL11.glMatrixMode(5889);
            GL11.glPushMatrix();
            GL11.glEnable(2903);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)this.IllIlIIIIlllIIllIIlllIIlI.displayWidth, (double)this.IllIlIIIIlllIIllIIlllIIlI.displayHeight, 0.0, (double)1000, (double)3000);
            GL11.glMatrixMode(5888);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, 0.0f, (float)(-2000));
            GL11.glLineWidth(1.0f);
            GL11.glDisable(3553);
            final Tessellator instance = Tessellator.instance;
            instance.startDrawing(1);
            for (int i = 0; i < this.lIIIIIllllIIIIlIlIIIIlIlI.length; ++i) {
                final int n4 = (i - this.lIIlIIllIIIIIlIllIIIIllII & this.lIIIIIllllIIIIlIlIIIIlIlI.length - 1) * 255 / this.lIIIIIllllIIIIlIlIIIIlIlI.length;
                final long n5 = this.lIIIIIllllIIIIlIlIIIIlIlI[i] / 200000L;
                final float n6 = (float)this.IllIlIIIIlllIIllIIlllIIlI.displayHeight;
                instance.setColorOpaque_I(-16777216 + n4 * 256);
                instance.addVertex(i + 0.64285713f * 0.7777778f, n6 - n5 + 0.12666667f * 3.9473684f, 0.0);
                instance.addVertex(i + 1.4210526f * 0.35185188f, n6 + 0.77894735f * 0.6418919f, 0.0);
                final float n7 = n6 - n5;
                final long n8 = this.IIIIIIlIlIlIllllllIlllIlI[i] / 200000L;
                instance.setColorOpaque_I(-16777216 + n4 * 65536 + n4 * 256 + n4 * 1);
                instance.addVertex(i + 0.3809524f * 1.3125f, n7 + 1.125f * 0.44444445f, 0.0);
                instance.addVertex(i + 0.55714285f * 0.8974359f, n7 + n8 + 1.3181819f * 0.37931034f, 0.0);
                final float n9 = n7 + n8;
                final long n10 = this.IllIllIIIlIIlllIIIllIllII[i] / 200000L;
                instance.setColorOpaque_I(-16777216 + n4 * 65536);
                instance.addVertex(i + 0.45454544f * 1.1f, n9 + 0.056179777f * 8.9f, 0.0);
                instance.addVertex(i + 0.8490566f * 0.5888889f, n9 + n10 + 5.0f * 0.1f, 0.0);
                final float n11 = n9 + n10;
                final long n12 = this.IlIIlIIIIlIIIIllllIIlIllI[i];
                if (n12 > 0L) {
                    final long n13 = n12 * 1000000L / 200000L;
                    instance.setColorOpaque_I(-16777216 + n4 * 1);
                    instance.addVertex(i + 0.19402985f * 2.5769231f, n11 + 3.7857144f * 0.13207547f, 0.0);
                    instance.addVertex(i + 0.8214286f * 0.6086956f, n11 + n13 + 2.4444444f * 0.20454545f, 0.0);
                }
            }
            instance.draw();
            GL11.glMatrixMode(5889);
            GL11.glPopMatrix();
            GL11.glMatrixMode(5888);
            GL11.glPopMatrix();
            GL11.glEnable(3553);
        }
    }
    
    private void llIlIIIlIIIIlIlllIlIIIIll() {
        if (this.IllIlIIIIlllIIllIIlllIIlI.theWorld != null) {
            final long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis > this.llllIlIlIlllllIllIIllIIIl + 10000L) {
                this.llllIlIlIlllllIllIIllIIIl = currentTimeMillis;
                final int glGetError = GL11.glGetError();
                if (glGetError != 0) {
                    this.IllIlIIIIlllIIllIIlllIIlI.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI("§eOpenGL Error§f: " + glGetError + " (" + GLU.gluErrorString(glGetError) + ")"));
                }
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final GuiMainMenu obj) {
        try {
            Object value = null;
            final Calendar instance = Calendar.getInstance();
            instance.setTime(new Date());
            final int value2 = instance.get(5);
            final int n = instance.get(2) + 1;
            if (value2 == 8 && n == 4) {
                value = "Happy birthday, OptiFine!";
            }
            if (value2 == 14 && n == 8) {
                value = "Happy birthday, sp614x!";
            }
            if (value == null) {
                return;
            }
            final Field[] declaredFields = GuiMainMenu.class.getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                if (declaredFields[i].getType() == String.class) {
                    declaredFields[i].setAccessible(true);
                    declaredFields[i].set(obj, value);
                    break;
                }
            }
        }
        catch (Throwable t) {}
    }
    
    static {
        lIllIllIlIIllIllIlIlIIlIl = LogManager.getLogger();
        llIlIIIllIIIIlllIlIIIIIlI = new ResourceLocation("textures/environment/rain.png");
        lIllIlIlllIIlIIllIIlIIlII = new ResourceLocation("textures/environment/snow.png");
        EntityRenderer.IIIlIIlIlIIIlllIIlIllllll = "7Hqvhj".length() * "raXIoG4y".length() * 2;
        IIlIlllIllIlIlIIIIIlllIll = new ResourceLocation[] { new ResourceLocation("shaders/post/notch.json"), new ResourceLocation("shaders/post/fxaa.json"), new ResourceLocation("shaders/post/art.json"), new ResourceLocation("shaders/post/bumpy.json"), new ResourceLocation("shaders/post/blobs2.json"), new ResourceLocation("shaders/post/pencil.json"), new ResourceLocation("shaders/post/color_convolve.json"), new ResourceLocation("shaders/post/deconverge.json"), new ResourceLocation("shaders/post/flip.json"), new ResourceLocation("shaders/post/invert.json"), new ResourceLocation("shaders/post/ntsc.json"), new ResourceLocation("shaders/post/outline.json"), new ResourceLocation("shaders/post/phosphor.json"), new ResourceLocation("shaders/post/scan_pincushion.json"), new ResourceLocation("shaders/post/sobel.json"), new ResourceLocation("shaders/post/bits.json"), new ResourceLocation("shaders/post/desaturate.json"), new ResourceLocation("shaders/post/green.json"), new ResourceLocation("shaders/post/blur.json"), new ResourceLocation("shaders/post/wobble.json"), new ResourceLocation("shaders/post/blobs.json"), new ResourceLocation("shaders/post/antialias.json") };
        IlIIllIIIlllIIIIlIIIIlIll = new ResourceLocation("shaders/post/animblur.json");
        lIIIIIIlIIllllllIIIlIlIIl = new ResourceLocation("shaders/post/motionblur.json");
        IIIIllIIllIIIIllIllIIIlIl = EntityRenderer.IIlIlllIllIlIlIIIIIlllIll.length;
    }
}
