import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllIllIlllllIIIIllIl extends llIIlIIllIIllIlIIllIIllII
{
    public llIIlIIlIIIIIIlIIllllllIl IIIIllIIllIIIIllIllIIIlIl;
    
    public IIlIlIllIllIlllllIIIIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIlIlIllIllIlllllIIIIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4);
        final ArrayList<llIIlIIlIIIIIIlIIllllllIl> list = new ArrayList<llIIlIIlIIIIIIlIIllllllIl>();
        for (final llIIlIIlIIIIIIlIIllllllIl llIIlIIlIIIIIIlIIllllllIl : llIIlIIlIIIIIIlIIllllllIl.values()) {
            this.IIIIllIIllIIIIllIllIIIlIl = llIIlIIlIIIIIIlIIllllllIl;
            this.lIIIIlIIllIIlIIlIIIlIIllI(n4);
            if (this.IlllIIIlIlllIllIlIIlllIlI()) {
                list.add(llIIlIIlIIIIIIlIIllllllIl);
            }
        }
        if (!list.isEmpty()) {
            this.IIIIllIIllIIIIllIllIIIlIl = list.get(this.IlIlllIIIIlIllIlllIlIIIll.nextInt(list.size()));
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(n4);
    }
    
    public IIlIlIllIllIlllllIIIIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final String anObject) {
        this(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4);
        for (final llIIlIIlIIIIIIlIIllllllIl iiiIllIIllIIIIllIllIIIlIl : llIIlIIlIIIIIIlIIllllllIl.values()) {
            if (iiiIllIIllIIIIllIllIIIlIl.IllIlIIIIlllIIllIIlllIIlI.equals(anObject)) {
                this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
                break;
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(n4);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Motive", this.IIIIllIIllIIIIllIllIIIlIl.IllIlIIIIlllIIllIIlllIIlI);
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        final String illlIllIlIIIIlIIlIIllIIIl = ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("Motive");
        for (final llIIlIIlIIIIIIlIIllllllIl iiiIllIIllIIIIllIllIIIlIl : llIIlIIlIIIIIIlIIllllllIl.values()) {
            if (iiiIllIIllIIIIllIllIIIlIl.IllIlIIIIlllIIllIIlllIIlI.equals(illlIllIlIIIIlIIlIIllIIIl)) {
                this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
            }
        }
        if (this.IIIIllIIllIIIIllIllIIIlIl == null) {
            this.IIIIllIIllIIIIllIllIIIlIl = llIIlIIlIIIIIIlIIllllllIl.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl.IllIlIlIllllIlIIllllIIlll;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl.IllIIlIIlllllIllIIIlllIII;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity) {
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll && ((lIllIIIIlIIlIllIIIlIlIlll)entity).IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            return;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIIllIIIlllIIIIlIIIIlIll), 0.0f);
    }
}
