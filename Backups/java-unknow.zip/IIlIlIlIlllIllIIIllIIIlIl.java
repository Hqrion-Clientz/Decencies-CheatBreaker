// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIlllIllIIIllIIIlIl extends lllIllIIIllllIlIlllllllll
{
    private int IlllIIIlIlllIllIlIIlllIlI;
    public double lIIIIlIIllIIlIIlIIIlIIllI;
    public double lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIlIlIlllIllIIIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIlIlIlIlllIllIIIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 2;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16, new Byte((byte)0));
    }
    
    @Override
    public void x_() {
        super.x_();
        if (this.IlllIIIlIlllIllIlIIlllIlI > 0) {
            --this.IlllIIIlIlllIllIlIIlllIlI;
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI <= 0) {
            final double n = 0.0;
            this.lIIIIIIIIIlIllIIllIlIIlIl = n;
            this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        }
        this.IlllIIIlIlllIllIlIIlllIlI(this.IlllIIIlIlllIllIlIIlllIlI > 0);
        if (this.IIIIllIIllIIIIllIllIIIlIl() && this.IlIlllIIIIlIllIlllIlIIIll.nextInt(4) == 0) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + 0.6222222304638523 * 1.2857142686843872, this.IllIlIlIllllIlIIllllIIlll, 0.0, 0.0, 0.0);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll);
        if (!lllIIIIIIIllIlllllIIlllll.IlllIIIlIlllIllIlIIlllIlI()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IllIIIlIIlIllIllIIllllIIl, 1), 0.0f);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final double n4, final double n5, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n6) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, illlllllIlllIIllllIIlIll, n6);
        final double n7 = this.lIIIIlIIllIIlIIlIIIlIIllI * this.lIIIIlIIllIIlIIlIIIlIIllI + this.lIIIIIIIIIlIllIIllIlIIlIl * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n7 > 4.090909004211426 * 2.4444444962489765E-5 && this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl > 7.323943858722737E-4 * 1.365384578704834) {
            final double n8 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n7);
            this.lIIIIlIIllIIlIIlIIIlIIllI /= n8;
            this.lIIIIIIIIIlIllIIllIlIIlIl /= n8;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI * this.IllIIlIIlllllIllIIIlllIII + this.lIIIIIIIIIlIllIIllIlIIlIl * this.IlllIIlllIIIIllIIllllIlIl < 0.0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI = 0.0;
                this.lIIIIIIIIIlIllIIllIlIIlIl = 0.0;
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI = this.IllIIlIIlllllIllIIIlllIII;
                this.lIIIIIIIIIlIllIIllIlIIlIl = this.IlllIIlllIIIIllIIllllIlIl;
            }
        }
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl() {
        final double n = this.lIIIIlIIllIIlIIlIIIlIIllI * this.lIIIIlIIllIIlIIlIIIlIIllI + this.lIIIIIIIIIlIllIIllIlIIlIl * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n > 2.0 * 5.0E-5) {
            final double n2 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n);
            this.lIIIIlIIllIIlIIlIIIlIIllI /= n2;
            this.lIIIIIIIIIlIllIIllIlIIlIl /= n2;
            final double n3 = 0.03846153989434242 * 1.299999951571228;
            this.IllIIlIIlllllIllIIIlllIII *= 0.3016393393254096 * 2.6521739959716797;
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.0;
            this.IlllIIlllIIIIllIIllllIlIl *= 1.4814814329147339 * 0.5400000257492074;
            this.IllIIlIIlllllIllIIIlllIII += this.lIIIIlIIllIIlIIlIIIlIIllI * n3;
            this.IlllIIlllIIIIllIIllllIlIl += this.lIIIIIIIIIlIllIIllIlIIlIl * n3;
        }
        else {
            this.IllIIlIIlllllIllIIIlllIII *= 0.04307692391531808 * 22.75;
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.0;
            this.IlllIIlllIIIIllIIllllIlIl *= 0.11807228874132343 * 8.300000190734863;
        }
        super.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    public boolean b_(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IllIIIIIIIlIlIllllIIllIII) {
            if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = liiiIlIIllIIlIIlIIIlIIllI;
                if (--lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                    lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, null);
                }
            }
            this.IlllIIIlIlllIllIlIIlllIlI += 3600;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = this.IIIlIIlIlIIIlllIIlIllllll - lIllIIIIlIIlIllIIIlIlIlll.IIIlIIlIlIIIlllIIlIllllll;
        this.lIIIIIIIIIlIllIIllIlIIlIl = this.IllIlIlIllllIlIIllllIIlll - lIllIIIIlIIlIllIIIlIlIlll.IllIlIlIllllIlIIllllIIlll;
        return true;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("PushX", this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("PushZ", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Fuel", (short)this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.lIIIIllIIlIlIllIIIlIllIlI("PushX");
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.lIIIIllIIlIlIllIIIlIllIlI("PushZ");
        this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Fuel");
    }
    
    protected boolean IIIIllIIllIIIIllIllIIIlIl() {
        return (this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16) & 0x1) != 0x0;
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final boolean b) {
        if (b) {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16) | 0x1));
        }
        else {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16) & 0xFFFFFFFE));
        }
    }
    
    @Override
    public IIlllllllIlllIIllllIIlIll IIIIllIlIIIllIlllIlllllIl() {
        return IllllllIllIIlllIllIIlIIll.IIlIlllIllIlIlIIIIIlllIll;
    }
    
    @Override
    public int lIIIIIllllIIIIlIlIIIIlIlI() {
        return 2;
    }
}
