import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

final class IIlIlIllIIlIIIIlIlllIllII implements Callable
{
    final /* synthetic */ int lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIlIllIIlIIIIlIlllIllII(final int liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return String.valueOf(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI));
    }
}
