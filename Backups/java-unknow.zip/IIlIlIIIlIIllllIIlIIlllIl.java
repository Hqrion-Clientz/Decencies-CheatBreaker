// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIlIIllllIIlIIlllIl extends lllIIllIlIIlIIlllllIIIllI
{
    public IIlIlIIIlIIllllIIlIIlllIl(final int n, final int n2) {
        super(n, n2, lIIIlIIIlIllIlllIIIIIlIlI.IlIlllIIIIllIllllIllIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI("arrowInfinite");
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return 20;
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return 50;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 1;
    }
}
