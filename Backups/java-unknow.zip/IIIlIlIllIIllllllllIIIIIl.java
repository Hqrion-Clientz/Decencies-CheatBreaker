// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIllIIllllllllIIIIIl extends lIllIIIIlIIIlllIllIIllIlI
{
    public IIIlIlIllIIllllllllIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl(0.72f * 1.2499999f, 1.7760563f * 0.73195875f);
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIllIlIlllIIlIIllIIlIIlII && this.z_() >= 0) {
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl == 1) {
                lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlIIlIlIIIlllIIlIllllll));
                return true;
            }
            if (lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlIIlIlIIIlllIIlIllllll)) && !lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, 1);
                return true;
            }
        }
        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIllIIIIlIIllIIIIIIIlll && this.z_() >= 0) {
            this.IlIllllIIIlIllllIIIIIllII();
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("largeexplode", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.llllIIIIlIlIllIIIllllIIll / 2.0f, this.IllIlIlIllllIlIIllllIIlll, 0.0, 0.0, 0.0);
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                final lIllIIIIlIIIlllIllIIllIlI lIllIIIIlIIIlllIllIIllIlI = new lIllIIIIlIIIlllIllIIllIlI(this.lIIlllIIlIlllllllllIIIIIl);
                lIllIIIIlIIIlllIllIIllIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
                lIllIIIIlIIIlllIllIIllIlI.IlllIllIlIIIIlIIlIIllIIIl(this.getHealth());
                lIllIIIIlIIIlllIllIIllIlI.lIIIlIlIIllIIlllIIIlIIllI = this.lIIIlIlIIllIIlllIIIlIIllI;
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIIlllIllIIllIlI);
                for (int i = 0; i < 5; ++i) {
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new lllIIIIIlIllllIIIlllIllIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll, new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.llIlIlIllIlIIlIlllIllIIlI)));
                }
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(1, lIllIIIIlIIlIllIIIlIlIlll);
                this.lIIIIlIIllIIlIIlIIIlIIllI("mob.sheep.shear", 1.0f, 1.0f);
            }
            return true;
        }
        return super.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public IIIlIlIllIIllllllllIIIIIl IlllIIIlIlllIllIlIIlllIlI(final lllIlIlIlIIIIIIIIlIlIlllI lllIlIlIlIIIIIIIIlIlIlllI) {
        return new IIIlIlIllIIllllllllIIIIIl(this.lIIlllIIlIlllllllllIIIIIl);
    }
}
