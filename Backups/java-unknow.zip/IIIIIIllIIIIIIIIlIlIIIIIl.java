import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIIIIIIIIlIlIIIIIl extends IIllIlIIlllIlIIlIllllllll
{
    private IIlllllllIlllIIllllIIlIll lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIIIllIIIIIIIIlIlIIIIIl(final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.IllIIIIIIIlIlIllllIIllIII) {
            return false;
        }
        final int n4 = random.nextInt(this.lIIIIIIIIIlIllIIllIlIIlIl - 2) + 2;
        final int n5 = 2;
        for (int i = n - n4; i <= n + n4; ++i) {
            for (int j = n3 - n4; j <= n3 + n4; ++j) {
                final int n6 = i - n;
                final int n7 = j - n3;
                if (n6 * n6 + n7 * n7 <= n4 * n4) {
                    for (int k = n2 - n5; k <= n2 + n5; ++k) {
                        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(i, k, j);
                        if (block == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl || block == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI) {
                            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(i, k, j, this.lIIIIlIIllIIlIIlIIIlIIllI, 0, 2);
                        }
                    }
                }
            }
        }
        return true;
    }
}
