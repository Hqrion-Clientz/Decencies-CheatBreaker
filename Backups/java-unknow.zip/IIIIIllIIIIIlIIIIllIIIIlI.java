// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllIIIIIlIIIIllIIIIlI extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private lIlIlIlIlIllllIlllIIIlIlI IIIIllIIllIIIIllIllIIIlIl;
    private float IlIlIIIlllIIIlIlllIlIllIl;
    private float IIIllIllIlIlllllllIlIlIII;
    private float IllIIIIIIIlIlIllllIIllIII;
    
    public IIIIIllIIIIIlIIIIllIIIIlI() {
    }
    
    public IIIIIllIIIIIlIIIIllIIIIlI(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final float ilIlIIIlllIIIlIlllIlIllIl, final float iiIllIllIlIlllllllIlIlIII, final float illIIIIIIIlIlIllllIIllIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = ((lIlIlIlIlIllllIlllIIIlIlI != null) ? lIlIlIlIlIllllIlllIIIlIlI.llIIlllIIIIlllIllIlIlllIl() : null);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readUnsignedByte();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readInt();
        this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.readUnsignedByte();
        this.IIIIllIIllIIIIllIllIIIlIl = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI();
        this.IlIlIIIlllIIIlIlllIlIllIl = lIlIllllllllIlIIIllIIllII.readUnsignedByte() / (float)16;
        this.IIIllIllIlIlllllllIlIlIII = lIlIllllllllIlIIIllIIllII.readUnsignedByte() / (float)16;
        this.IllIIIIIIIlIlIllllIIllIII = lIlIllllllllIlIIIllIIllII.readUnsignedByte() / (float)16;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IIIIllIlIIIllIlllIlllllIl);
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl);
        lIlIllllllllIlIIIllIIllII.writeByte((int)(this.IlIlIIIlllIIIlIlllIlIllIl * 16));
        lIlIllllllllIlIIIllIIllII.writeByte((int)(this.IIIllIllIlIlllllllIlIlIII * 16));
        lIlIllllllllIlIIIllIIllII.writeByte((int)(this.IllIIIIIIIlIlIllllIIllIII * 16));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIllllIllIllIlIlIllIlllIl illllIllIllIlIlIllIlllIl) {
        illllIllIllIlIlIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI IIIllIllIlIlllllllIlIlIII() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public float IllIIIIIIIlIlIllllIIllIII() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public float lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public float IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllllIllIllIlIlIllIlllIl)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
