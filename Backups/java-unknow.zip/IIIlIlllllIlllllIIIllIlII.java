// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIlllllIlllllIIIllIlII extends IlIIIIIlIIIIlIIIIlIlllIlI
{
    final /* synthetic */ IllllIIIlIIlllIlIIllIllll lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIlllllIlllllIIIllIlII(final IllllIIIlIIlllIlIIllIllll liiiIlIIllIIlIIlIIIlIIllI, final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        super(ilIIlIIllIllllllllIllIII, n, n2, n3);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().IllIIIIIIIlIlIllllIIllIII(lIlIlIlIlIllllIlllIIIlIlI);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return 64;
    }
}
