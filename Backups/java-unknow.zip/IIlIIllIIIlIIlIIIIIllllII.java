import org.lwjgl.input.Keyboard;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIIIlIIlIIIIIllllII extends GuiScreen
{
    private GuiScreen lIIIIlIIllIIlIIlIIIlIIllI;
    private IIIIIllIIlIlIlIIlIlIlIllI lIIIIIIIIIlIllIIllIlIIlIl;
    private final String IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIllIIIlIIlIIIIIllllII(final GuiScreen liiiIlIIllIIlIIlIIIlIIllI, final String illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void updateScreen() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.updateTick();
    }
    
    @Override
    public void s_() {
        Keyboard.enableRepeatEvents(true);
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.renameButton", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 120 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.cancel", new Object[0])));
        final String ilIlllIIIIllIllllIllIIlIl = this.lllIIIIIlIllIlIIIllllllII.getSaveLoader().IlllIIIlIlllIllIlIIlllIlI(this.IlllIIIlIlllIllIlIIlllIlI).IlIlllIIIIllIllllIllIIlIl();
        (this.lIIIIIIIIIlIllIIllIlIIlIl = new IIIIIllIIlIlIlIIlIlIlIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, 60, 200, 20)).lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIIIIIIIIIlIllIIllIlIIlIl.setSection(ilIlllIIIIllIllllIllIIlIl);
    }
    
    @Override
    public void t_() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.lIIIIlIIllIIlIIlIIIlIIllI);
            }
            else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
                this.lllIIIIIlIllIlIIIllllllII.getSaveLoader().lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().trim());
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.lIIIIlIIllIIlIIlIIIlIIllI);
            }
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        this.IllIllIIIlIIlllIIIllIllII.get(0).IlllIllIlIIIIlIIlIIllIIIl = (this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().trim().length() > 0);
        if (n == 28 || n == 156) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIllIIIlIIlllIIIllIllII.get(0));
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.renameTitle", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 20, 16777215);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.enterName", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, 47, 10526880);
        this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl();
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
}
