import java.util.Iterator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIllllIlIllllllIllll extends lIIlllIIIlIllllllIlIlIIII
{
    public IIIIlIIllllIlIllllllIllll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.lIIIIllIIlIlIllIIIlIllIlI);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3).IlIlllIIIIllIllllIllIIlIl() != 11) {
            return false;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            return true;
        }
        lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return true;
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        IIIIIIIlIlIIIIIIlllllllIl iiiiiiIlIlIIIIIIlllllllIl = IIIIIIIlIlIIIIIIlllllllIl.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        boolean b = false;
        final double n4 = 7;
        final List liiiIlIIllIIlIIlIIIlIIllI = iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(IlllIIIllIlIIlIllIIlIlllI.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n - n4, n2 - n4, n3 - n4, n + n4, n2 + n4, n3 + n4));
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            for (final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI : liiiIlIIllIIlIIlIIIlIIllI) {
                if (illlIIIllIlIIlIllIIlIlllI.lIlIIIlIIIlllllllllllIlIl() && illlIIIllIlIIlIllIIlIlllI.IIllllllIlIIIIlllIlIlIlll() == lIllIIIIlIIlIllIIIlIlIlll) {
                    if (iiiiiiIlIlIIIIIIlllllllIl == null) {
                        iiiiiiIlIlIIIIIIlllllllIl = IIIIIIIlIlIIIIIIlllllllIl.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
                    }
                    illlIIIllIlIIlIllIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiiIlIlIIIIIIlllllllIl, true);
                    b = true;
                }
            }
        }
        return b;
    }
}
