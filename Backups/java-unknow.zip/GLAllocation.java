import java.util.ArrayList;
import java.util.HashMap;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import java.util.List;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class GLAllocation
{
    private static final Map lIIIIlIIllIIlIIlIIIlIIllI;
    private static final List lIIIIIIIIIlIllIIllIlIIlIl;
    
    public static synchronized int lIIIIlIIllIIlIIlIIIlIIllI(final int i) {
        final int glGenLists = GL11.glGenLists(i);
        GLAllocation.lIIIIlIIllIIlIIlIIIlIIllI.put(glGenLists, i);
        return glGenLists;
    }
    
    public static synchronized void lIIIIIIIIIlIllIIllIlIIlIl(final int i) {
        GL11.glDeleteLists(i, (int)GLAllocation.lIIIIlIIllIIlIIlIIIlIIllI.remove(i));
    }
    
    public static synchronized void deleteTexturesAndDisplayLists() {
        for (final Map.Entry<Integer, V> entry : GLAllocation.lIIIIlIIllIIlIIlIIIlIIllI.entrySet()) {
            GL11.glDeleteLists((int)entry.getKey(), (int)entry.getValue());
        }
        GLAllocation.lIIIIlIIllIIlIIlIIIlIIllI.clear();
    }
    
    public static synchronized ByteBuffer IlllIIIlIlllIllIlIIlllIlI(final int capacity) {
        return ByteBuffer.allocateDirect(capacity).order(ByteOrder.nativeOrder());
    }
    
    public static IntBuffer IIIIllIlIIIllIlllIlllllIl(final int n) {
        return IlllIIIlIlllIllIlIIlllIlI(n << 2).asIntBuffer();
    }
    
    public static FloatBuffer IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return IlllIIIlIlllIllIlIIlllIlI(n << 2).asFloatBuffer();
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new HashMap();
        lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
    }
}
