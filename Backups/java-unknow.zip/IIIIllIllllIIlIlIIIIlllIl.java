// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIllllIIlIlIIIIlllIl
{
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    public static final int lIIIIlIIllIIlIIlIIIlIIllI = 16384;
    
    public IIIIllIllllIIlIlIIIIlllIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
        this.IIIIllIlIIIllIlllIlllllIl = -1;
        this.lIIIIIIIIIlIllIIllIlIIlIl = GLAllocation.lIIIIlIIllIIlIIlIIIlIIllI(16384);
        this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIIIIIIlIllIIllIlIIlIl + 16384;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return this.IlllIIIlIlllIllIlIIlllIlI + n < this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI(n)) {
            return -1;
        }
        final int illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.IlllIIIlIlllIllIlIIlllIlI += n;
        return illlIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        GLAllocation.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
}
