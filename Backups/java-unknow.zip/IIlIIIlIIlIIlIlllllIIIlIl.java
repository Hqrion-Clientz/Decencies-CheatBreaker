// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIlIIlIIlIlllllIIIlIl extends IIIIIllIIlIlllllIlIllllIl
{
    private llIIIIIIllIllIIllIIIlIlII lIIIlIlIIIlIlIlllIlIlllII;
    
    public IIlIIIlIIlIIlIlllllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl(1.1392405f * 0.5266667f, 0.5714286f * 1.4f);
        this.IllIlIlIllllIlIIllllIIlll().lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(1, new IIllIIIIllIlIIlIllIIIlllI(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(2, this.llIIIlllllIlllIIllIlIIlII);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(3, this.lIIIlIlIIIlIlIlllIlIlllII = new llIIIIIIllIllIIllIIIlIlII(this, 1.220689685279493 * 0.49152541160583496, IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll, true));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(4, new IIlIllIIIlIlllIllIIIIIIll(this, lIllIIIIlIIlIllIIIlIlIlll.class, 16, 0.2941176439651569 * 2.7200000286102295, 2.969302391435987 * 0.4479166567325592));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(5, new IllIllIIIIlllIIlllIllIIIl(this, 1.0, 10, 5));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(6, new llllllIIlIIllIIIllIlIllII(this, 0.532 * 2.5));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(7, new IllIlllIIIIlIIIllllIIlllI(this, 0.17500001f * 1.7142857f));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(8, new llIIIIlllIlIlIlIIIIIIllII(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(9, new lIlIIllllIlllIlIIIIIllIIl(this, 0.4483516600983919 * 1.784313678741455));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(10, new IllIIllIIlIlIlIllIlIIIlll(this, 2.615384578704834 * 0.305882357231061));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(11, new IlIIllIllIllIlllIlIlllIIl(this, lIllIIIIlIIlIllIIIlIlIlll.class, 10));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, new IIlIIIIIIIlIIllIIIIllllIl(this, lIllllIIIIlIlIlllllllIIII.class, 750, false));
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(18, (Object)0);
    }
    
    public void IlllIIIllIlIlIIIllIIIlIlI() {
        if (this.lIllIlIlllIIlIIllIIlIIlII().lIIIIlIIllIIlIIlIIIlIIllI()) {
            final double liiiiiiiiIlIllIIllIlIIlIl = this.lIllIlIlllIIlIIllIIlIIlII().lIIIIIIIIIlIllIIllIlIIlIl();
            if (liiiiiiiiIlIllIIllIlIIlIl == 0.8101266026496887 * 0.7406249813764594) {
                this.IIIIllIlIIIllIlllIlllllIl(true);
                this.lIIIIIIIIIlIllIIllIlIIlIl(false);
            }
            else if (liiiiiiiiIlIllIIllIlIIlIl == 3.9899998810887376 * 0.3333333432674408) {
                this.IIIIllIlIIIllIlllIlllllIl(false);
                this.lIIIIIIIIIlIllIIllIlIIlIl(true);
            }
            else {
                this.IIIIllIlIIIllIlllIlllllIl(false);
                this.lIIIIIIIIIlIllIIllIlIIlIl(false);
            }
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl(false);
            this.lIIIIIIIIIlIllIIllIlIIlIl(false);
        }
    }
    
    @Override
    protected boolean IlIlIIIlllIlIllIlIIIlllIl() {
        return !this.llllIIllIIlIIllIIIllIlIlI() && this.IIIlIllIlllIlIllIllllllll > 2400;
    }
    
    public boolean IIllIllIlIIlllllIlIIIlIll() {
        return true;
    }
    
    @Override
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(10);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).lIIIIlIIllIIlIIlIIIlIIllI(0.3368421186480606 * 0.890625);
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CatType", this.IlIllIllllIIIlIIIllIIIllI());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.IIIIIIlIlIlIllllllIlllIlI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("CatType"));
    }
    
    @Override
    protected String llllIlIlIlllllIllIIllIIIl() {
        return this.llllIIllIIlIIllIIIllIlIlI() ? (this.IlIIIIlllIIIlIIllllIIIlll() ? "mob.cat.purr" : ((this.IlIlllIIIIlIllIlllIlIIIll.nextInt(4) == 0) ? "mob.cat.purreow" : "mob.cat.meow")) : "";
    }
    
    @Override
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "mob.cat.hitt";
    }
    
    @Override
    protected String IllIIIIIIlIlIlllllllIIllI() {
        return "mob.cat.hitt";
    }
    
    @Override
    protected float lIIlIlIllllllIllllIIllllI() {
        return 0.1670886f * 2.3939395f;
    }
    
    @Override
    protected lIIlllIIIlIllllllIlIlIIII lllIIlIIllIllIIllIIlIIIIl() {
        return IIlIlIllIlIIllIllIllIIIll.IIIIIIIllIllllIIlIIlllIII;
    }
    
    @Override
    public boolean lIIlIlIllIIlIIIlIIIlllIII(final Entity entity) {
        return entity.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI(this), 3);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        this.llIIIlllllIlllIIllIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI(false);
        return super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, n);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
        if (this.llllIIllIIlIIllIIIllIlIlI()) {
            if (this.IIIIllIIllIIIIllIllIIIlIl((EntityLivingBase)lIllIIIIlIIlIllIIIlIlIlll) && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && !this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI)) {
                this.llIIIlllllIlllIIllIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI(!this.llIllllIIIIIlIllIlIIIllIl());
            }
        }
        else if (this.lIIIlIlIIIlIlIlllIlIlllII.IllIIIIIIIlIlIllllIIllIII() && liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll && lIllIIIIlIIlIllIIIlIlIlll.IIIIllIIllIIIIllIllIIIlIl(this) < 9) {
            if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = liiiIlIIllIIlIIlIIIlIIllI;
                --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
                lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, null);
            }
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                if (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(3) == 0) {
                    this.IlllIllIlIIIIlIIlIIllIIIl(true);
                    this.IIIIIIlIlIlIllllllIlllIlI(1 + this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(3));
                    this.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.llllIIllIIlllllIlIlIIllll().toString());
                    this.lIIIIllIIlIlIllIIIlIllIlI(true);
                    this.llIIIlllllIlllIIllIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI(true);
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)7);
                }
                else {
                    this.lIIIIllIIlIlIllIIIlIllIlI(false);
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)6);
                }
            }
            return true;
        }
        return super.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public IIlIIIlIIlIIlIlllllIIIlIl lIIIIIIIIIlIllIIllIlIIlIl(final lllIlIlIlIIIIIIIIlIlIlllI lllIlIlIlIIIIIIIIlIlIlllI) {
        final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl = new IIlIIIlIIlIIlIlllllIIIlIl(this.lIIlllIIlIlllllllllIIIIIl);
        if (this.llllIIllIIlIIllIIIllIlIlI()) {
            ilIIIlIIlIIlIlllllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI());
            ilIIIlIIlIIlIlllllIIIlIl.IlllIllIlIIIIlIIlIIllIIIl(true);
            ilIIIlIIlIIlIlllllIIIlIl.IIIIIIlIlIlIllllllIlllIlI(this.IlIllIllllIIIlIIIllIIIllI());
        }
        return ilIIIlIIlIIlIlllllIIIlIl;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll) {
        if (iiiIlIIlIIIllllIIIlllIIll == this) {
            return false;
        }
        if (!this.llllIIllIIlIIllIIIllIlIlI()) {
            return false;
        }
        if (!(iiiIlIIlIIIllllIIIlllIIll instanceof IIlIIIlIIlIIlIlllllIIIlIl)) {
            return false;
        }
        final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl = (IIlIIIlIIlIIlIlllllIIIlIl)iiiIlIIlIIIllllIIIlllIIll;
        return ilIIIlIIlIIlIlllllIIIlIl.llllIIllIIlIIllIIIllIlIlI() && (this.IlIIIIlllIIIlIIllllIIIlll() && ilIIIlIIlIIlIlllllIIIlIl.IlIIIIlllIIIlIIllllIIIlll());
    }
    
    public int IlIllIllllIIIlIIIllIIIllI() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(18);
    }
    
    public void IIIIIIlIlIlIllllllIlllIlI(final int n) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(18, (byte)n);
    }
    
    @Override
    public boolean IIIlllIIIllIllIlIIIIIIlII() {
        if (this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(3) == 0) {
            return false;
        }
        if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lllIlIIllllIIIIlIllIlIIII) && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII).isEmpty() && !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(this.lllIlIIllllIIIIlIllIlIIII)) {
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
            if (illlIIIlIlllIllIlIIlllIlI2 < 63) {
                return false;
            }
            final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3);
            if (block == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI || block.IlIlIIIlllIIIlIlllIlIllIl() == Material.IlllIllIlIIIIlIIlIIllIIIl) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public String IlIlIIIlllllIIIlIlIlIllII() {
        return this.lIIIIIIlIIllIlIlIllIIIIll() ? this.lIIIllIIIIlIIllIIIIIIIlll() : (this.llllIIllIIlIIllIIIllIlIlI() ? IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI("entity.Cat.name") : super.IlIlIIIlllllIIIlIlIlIllII());
    }
    
    @Override
    public lIIIlllIlIIlIIlIIIIllllII lIIIIlIIllIIlIIlIIIlIIllI(lIIIlllIlIIlIIlIIIIllllII liiiIlIIllIIlIIlIIIlIIllI) {
        liiiIlIIllIIlIIlIIIlIIllI = super.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
        if (this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(7) == 0) {
            for (int i = 0; i < 2; ++i) {
                final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl = new IIlIIIlIIlIIlIlllllIIIlIl(this.lIIlllIIlIlllllllllIIIIIl);
                ilIIIlIIlIIlIlllllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, 0.0f);
                ilIIIlIIlIIlIlllllIIIlIl.updateDebugProfilerName(-24000);
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIlIIlIIlIlllllIIIlIl);
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
}
