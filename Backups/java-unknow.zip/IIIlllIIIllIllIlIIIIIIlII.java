// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIIIllIllIlIIIIIIlII extends CBEvent
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlllIIIllIllIlIIIIIIlII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = false;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
}
