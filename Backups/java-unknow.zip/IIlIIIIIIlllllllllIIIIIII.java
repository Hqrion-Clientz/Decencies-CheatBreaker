import java.util.HashMap;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIlllllllllIIIIIII extends lIllIIIlIllllIIIIlIlIIIlI
{
    private boolean lIIIIlllIIlIlllllIlIllIII;
    private static Map lIIIlllIlIlllIIIIIIIIIlII;
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b) {
        if (!IIlIIIIIIlllllllllIIIIIII.lIIIlllIlIlllIIIIIIIIIlII.containsKey(iiiiiIllIlIIIIlIlllIllllI)) {
            IIlIIIIIIlllllllllIIIIIII.lIIIlllIlIlllIIIIIIIIIlII.put(iiiiiIllIlIIIIlIlllIllllI, new ArrayList());
        }
        final List<lIIIllllllIIlIlIIlIllIIlI> list = IIlIIIIIIlllllllllIIIIIII.lIIIlllIlIlllIIIIIIIIIlII.get(iiiiiIllIlIIIIlIlllIllllI);
        if (b) {
            list.add(new lIIIllllllIIlIlIIlIllIIlI(n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlIIlIIIIlIIIIllllIIlIllI()));
        }
        int n4 = 0;
        for (int i = 0; i < list.size(); ++i) {
            final lIIIllllllIIlIlIIlIllIIlI liiIllllllIIlIlIIlIllIIlI = list.get(i);
            if (liiIllllllIIlIlIIlIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == n && liiIllllllIIlIlIIlIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl == n2 && liiIllllllIIlIlIIlIllIIlI.IlllIIIlIlllIllIlIIlllIlI == n3 && ++n4 >= 8) {
                return true;
            }
        }
        return false;
    }
    
    protected IIlIIIIIIlllllllllIIIIIII(final boolean liiiIlllIIlIlllllIlIllIII) {
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllllIllIIllIIllIlIIIIII)null);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return 2;
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) == 0) {
            super.IIIIllIlIIIllIlllIlllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        }
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 + 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 + 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
        }
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        if (!this.lIIIIlllIIlIlllllIlIllIII) {
            return 0;
        }
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return (illlIIIlIlllIllIlIIlllIlI == 5 && n4 == 1) ? 0 : ((illlIIIlIlllIllIlIIlllIlI == 3 && n4 == 3) ? 0 : ((illlIIIlIlllIllIlIIlllIlI == 4 && n4 == 2) ? 0 : ((illlIIIlIlllIllIlIIlllIlI == 1 && n4 == 5) ? 0 : ((illlIIIlIlllIllIlIIlllIlI == 2 && n4 == 4) ? 0 : 15))));
    }
    
    private boolean IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return (illlIIIlIlllIllIlIIlllIlI == 5 && iiiiiIllIlIIIIlIlllIllllI.IIIIllIIllIIIIllIllIIIlIl(n, n2 - 1, n3, 0)) || (illlIIIlIlllIllIlIIlllIlI == 3 && iiiiiIllIlIIIIlIlllIllllI.IIIIllIIllIIIIllIllIIIlIl(n, n2, n3 - 1, 2)) || (illlIIIlIlllIllIlIIlllIlI == 4 && iiiiiIllIlIIIIlIlllIllllI.IIIIllIIllIIIIllIllIIIlIl(n, n2, n3 + 1, 3)) || (illlIIIlIlllIllIlIIlllIlI == 1 && iiiiiIllIlIIIIlIlllIllllI.IIIIllIIllIIIIllIllIIIlIl(n - 1, n2, n3, 4)) || (illlIIIlIlllIllIlIIlllIlI == 2 && iiiiiIllIlIIIIlIlllIllllI.IIIIllIIllIIIIllIllIIIlIl(n + 1, n2, n3, 5));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        final boolean ilIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        final List<lIIIllllllIIlIlIIlIllIIlI> list = IIlIIIIIIlllllllllIIIIIII.lIIIlllIlIlllIIIIIIIIIlII.get(iiiiiIllIlIIIIlIlllIllllI);
        while (list != null && !list.isEmpty() && iiiiiIllIlIIIIlIlllIllllI.IlIIlIIIIlIIIIllllIIlIllI() - list.get(0).IIIIllIlIIIllIlllIlllllIl > 60L) {
            list.remove(0);
        }
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            if (ilIlllIIIIllIllllIllIIlIl) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.lllIllIllIlIllIlIIllllIIl, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 3);
                if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, true)) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 5.625f * 0.08888889f, n2 + 1.1290323f * 0.44285715f, n3 + 0.67741936f * 0.7380952f, "random.fizz", 0.030612243f * 16.333334f, 4.0857143f * 0.6363636f + (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() - iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat()) * (1.3837838f * 0.578125f));
                    for (int i = 0; i < 5; ++i) {
                        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("smoke", n + random.nextDouble() * (0.08235294271642914 * 7.285714149475098) + 0.07945205168062817 * 2.5172414779663086, n2 + random.nextDouble() * (0.2909090909090909 * 2.0625) + 0.17575758274155462 * 1.137930989265442, n3 + random.nextDouble() * (0.27216494310192335 * 2.204545497894287) + 0.5604395866394043 * 0.356862728415156, 0.0, 0.0, 0.0);
                    }
                }
            }
        }
        else if (!ilIlllIIIIllIllllIllIIlIl && !this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, false)) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IIIIIIIllIllllIIlIIlllIII, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 3);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll)) {
            final boolean ilIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
            if ((this.lIIIIlllIIlIlllllIlIllIII && ilIlllIIIIllIllllIllIIlIl) || (!this.lIIIIlllIIlIlllllIlIllIII && !ilIlllIIIIllIllllIllIIlIl)) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI));
            }
        }
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return (n4 == 0) ? this.IIIIllIlIIIllIlllIlllllIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4) : 0;
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIIIIllIllllIIlIIlllIII);
    }
    
    @Override
    public boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return true;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            final double n4 = n + 0.23232323f * 2.152174f + (random.nextFloat() - 1.4565217f * 0.3432836f) * (2.3999999284744287 * 0.0833333358168602);
            final double n5 = n2 + 0.4719101f * 1.4833333f + (random.nextFloat() - 1.078125f * 0.46376812f) * (12.8 * 0.015625);
            final double n6 = n3 + 0.101265825f * 4.9375f + (random.nextFloat() - 0.078947365f * 6.3333335f) * (0.17575758274155462 * 1.137930989265442);
            final double n7 = 0.04852941184204755 * 4.5333333015441895;
            final double n8 = 0.26229506731033325 * 1.0293750984245036;
            if (illlIIIlIlllIllIlIIlllIlI == 1) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4 - n8, n5 + n7, n6, 0.0, 0.0, 0.0);
            }
            else if (illlIIIlIlllIllIlIIlllIlI == 2) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4 + n8, n5 + n7, n6, 0.0, 0.0, 0.0);
            }
            else if (illlIIIlIlllIllIlIIlllIlI == 3) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4, n5 + n7, n6 - n8, 0.0, 0.0, 0.0);
            }
            else if (illlIIIlIlllIllIlIIlllIlI == 4) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4, n5 + n7, n6 + n8, 0.0, 0.0, 0.0);
            }
            else {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4, n5, n6, 0.0, 0.0, 0.0);
            }
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIIIIllIllllIIlIIlllIII);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lllIllIllIlIllIlIIllllIIl || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IIIIIIIllIllllIIlIIlllIII;
    }
    
    static {
        IIlIIIIIIlllllllllIIIIIII.lIIIlllIlIlllIIIIIIIIIlII = new HashMap();
    }
}
