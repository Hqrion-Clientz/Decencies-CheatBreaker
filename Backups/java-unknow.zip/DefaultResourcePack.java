import com.google.common.collect.ImmutableSet;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class DefaultResourcePack implements IlllIIllIIIIllllIlIIllIll
{
    public static final Set lIIIIIIIIIlIllIIllIlIIlIl;
    private final Map lIIIIlIIllIIlIIlIIIlIIllI;
    
    public DefaultResourcePack(final Map liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public InputStream func_152780_c(final ResourceLocation resourceLocation) {
        final InputStream iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl(resourceLocation);
        if (iiiIllIlIIIllIlllIlllllIl != null) {
            return iiiIllIlIIIllIlllIlllllIl;
        }
        final InputStream illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(resourceLocation);
        if (illlIIIlIlllIllIlIIlllIlI != null) {
            return illlIIIlIlllIllIlIIlllIlI;
        }
        if (CBAgentResources.existsBytes(resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI())) {
            return new ByteArrayInputStream(CBAgentResources.getBytesNative(resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI()));
        }
        throw new FileNotFoundException(resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI());
    }
    
    public InputStream IlllIIIlIlllIllIlIIlllIlI(final ResourceLocation resourceLocation) {
        final File file = this.lIIIIlIIllIIlIIlIIIlIIllI.get(resourceLocation.toString());
        return (file != null && file.isFile()) ? new FileInputStream(file) : null;
    }
    
    public InputStream IIIIllIlIIIllIlllIlllllIl(final ResourceLocation resourceLocation) {
        if (CBAgentResources.existsBytes("assets/" + resourceLocation.lIIIIIIIIIlIllIIllIlIIlIl() + "/" + resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI())) {
            return new ByteArrayInputStream(CBAgentResources.getBytesNative("assets/" + resourceLocation.lIIIIIIIIIlIllIIllIlIIlIl() + "/" + resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI()));
        }
        return DefaultResourcePack.class.getResourceAsStream("/assets/" + resourceLocation.lIIIIIIIIIlIllIIllIlIIlIl() + "/" + resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI());
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final ResourceLocation resourceLocation) {
        return this.IIIIllIlIIIllIlllIlllllIl(resourceLocation) != null || this.lIIIIlIIllIIlIIlIIIlIIllI.containsKey(resourceLocation.toString());
    }
    
    @Override
    public Set lIIIIlIIllIIlIIlIIIlIIllI() {
        return DefaultResourcePack.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public IllIlIIlIIIIIIllIllIllIIl lIIIIlIIllIIlIIlIIIlIIllI(final IMetadataSerializer metadataSerializer, final String s) {
        try {
            return IIIIllIIlIIlIIIIIIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(metadataSerializer, new FileInputStream(this.lIIIIlIIllIIlIIlIIIlIIllI.get("pack.mcmeta")), s);
        }
        catch (RuntimeException ex) {
            return null;
        }
        catch (FileNotFoundException ex2) {
            return null;
        }
    }
    
    @Override
    public BufferedImage lIIIIIIIIIlIllIIllIlIIlIl() {
        if (CBAgentResources.existsBytes("pack.png")) {
            return ImageIO.read(new ByteArrayInputStream(CBAgentResources.getBytesNative("pack.png")));
        }
        return ImageIO.read(DefaultResourcePack.class.getResourceAsStream("/" + new ResourceLocation("pack.png").lIIIIlIIllIIlIIlIIIlIIllI()));
    }
    
    @Override
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return "Default";
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = (Set)ImmutableSet.of((Object)"minecraft", (Object)"realms");
    }
}
