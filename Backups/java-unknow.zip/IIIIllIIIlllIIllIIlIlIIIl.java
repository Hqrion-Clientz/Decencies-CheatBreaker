// 
// Decompiled by Procyon v0.5.36
// 

final class IIIIllIIIlllIIllIIlIlIIIl implements lllIIlIIIllllllIIIIlIlIlI
{
    public EntityLivingBase lIIIIlIIllIIlIIlIIIlIIllI;
    public Entity lIIIIIIIIIlIllIIllIlIIlIl;
    
    private IIIIllIIIlllIIllIIlIlIIIl() {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIllIlIIlIIlllllIIIllI lllIIllIlIIlIIlllllIIIllI, final int n) {
        lllIIllIlIIlIIlllllIIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, n);
    }
    
    IIIIllIIIlllIIllIIlIlIIIl(final Object o) {
        this();
    }
}
