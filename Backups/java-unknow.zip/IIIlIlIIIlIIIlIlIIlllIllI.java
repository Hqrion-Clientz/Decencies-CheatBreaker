import java.util.Iterator;
import com.google.common.collect.Lists;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIIIlIIIlIlIIlllIllI implements llIllIllIllIIIIlIlllllIlI
{
    protected final List lIIIIlIIllIIlIIlIIIlIIllI;
    private final IMetadataSerializer lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlIlIIIlIIIlIlIIlllIllI(final IMetadataSerializer liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIllIIIIllllIlIIllIll illlIIllIIIIllllIlIIllIll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(illlIIllIIIIllllIlIIllIll);
    }
    
    @Override
    public Set lIIIIlIIllIIlIIlIIIlIIllI() {
        return null;
    }
    
    @Override
    public lIlIIIlIIIIIIlllIIlllllII lIIIIlIIllIIlIIlIIIlIIllI(final ResourceLocation resourceLocation) {
        IlllIIllIIIIllllIlIIllIll illlIIllIIIIllllIlIIllIll = null;
        final ResourceLocation illlIIIlIlllIllIlIIlllIlI = IlllIIIlIlllIllIlIIlllIlI(resourceLocation);
        for (int i = this.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1; i >= 0; --i) {
            final IlllIIllIIIIllllIlIIllIll illlIIllIIIIllllIlIIllIll2 = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
            if (illlIIllIIIIllllIlIIllIll == null && illlIIllIIIIllllIlIIllIll2.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI)) {
                illlIIllIIIIllllIlIIllIll = illlIIllIIIIllllIlIIllIll2;
            }
            if (illlIIllIIIIllllIlIIllIll2.lIIIIIIIIIlIllIIllIlIIlIl(resourceLocation)) {
                InputStream func_152780_c = null;
                if (illlIIllIIIIllllIlIIllIll != null) {
                    func_152780_c = illlIIllIIIIllllIlIIllIll.func_152780_c(illlIIIlIlllIllIlIIlllIlI);
                }
                return new lllllIIIIlIlllIllIIIlIIlI(resourceLocation, illlIIllIIIIllllIlIIllIll2.func_152780_c(resourceLocation), func_152780_c, this.lIIIIIIIIIlIllIIllIlIIlIl);
            }
        }
        final String string = "assets/minecraft/" + resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI();
        if (CBAgentResources.existsBytes(string)) {
            final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(CBAgentResources.getBytesNative(string));
            InputStream inputStream = null;
            if (CBAgentResources.existsBytes(string + ".mcmeta")) {
                inputStream = new ByteArrayInputStream(CBAgentResources.getBytesNative(string + ".mcmeta"));
            }
            return new lllllIIIIlIlllIllIIIlIIlI(resourceLocation, byteArrayInputStream, inputStream, this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        throw new FileNotFoundException(resourceLocation.toString());
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final ResourceLocation resourceLocation) {
        final ArrayList arrayList = Lists.newArrayList();
        final ResourceLocation illlIIIlIlllIllIlIIlllIlI = IlllIIIlIlllIllIlIIlllIlI(resourceLocation);
        for (final IlllIIllIIIIllllIlIIllIll illlIIllIIIIllllIlIIllIll : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (illlIIllIIIIllllIlIIllIll.lIIIIIIIIIlIllIIllIlIIlIl(resourceLocation)) {
                arrayList.add(new lllllIIIIlIlllIllIIIlIIlI(resourceLocation, illlIIllIIIIllllIlIIllIll.func_152780_c(resourceLocation), illlIIllIIIIllllIlIIllIll.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI) ? illlIIllIIIIllllIlIIllIll.func_152780_c(illlIIIlIlllIllIlIIlllIlI) : null, this.lIIIIIIIIIlIllIIllIlIIlIl));
            }
        }
        if (arrayList.isEmpty()) {
            throw new FileNotFoundException(resourceLocation.toString());
        }
        return arrayList;
    }
    
    static ResourceLocation IlllIIIlIlllIllIlIIlllIlI(final ResourceLocation resourceLocation) {
        return new ResourceLocation(resourceLocation.lIIIIIIIIIlIllIIllIlIIlIl(), resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI() + ".mcmeta");
    }
}
