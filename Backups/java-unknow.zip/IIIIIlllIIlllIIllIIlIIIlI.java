import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIIlllIIlllIIllIIlIIIlI implements Callable
{
    final /* synthetic */ int lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ int lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ IllIlIllIIIllllllIIIllIlI IlllIIIlIlllIllIlIIlllIlI;
    
    IIIIIlllIIlllIIllIIlIIIlI(final IllIlIllIIIllllllIIIllIlI illlIIIlIlllIllIlIIlllIlI, final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl) ? "True" : "False";
    }
}
