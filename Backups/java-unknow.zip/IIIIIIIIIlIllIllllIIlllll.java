import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIlIllIllllIIlllll extends lIIllllIIlIIlllIlIIllIIIl
{
    public IIIIIIIIIlIllIllllIIlllll() {
        super(false);
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, int n2, final int n3) {
        final int n4 = random.nextInt(4) + 5;
        while (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3).IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
            --n2;
        }
        int n5 = 1;
        if (n2 < 1 || n2 + n4 + 1 > 256) {
            return false;
        }
        for (int i = n2; i <= n2 + 1 + n4; ++i) {
            int n6 = 1;
            if (i == n2) {
                n6 = 0;
            }
            if (i >= n2 + 1 + n4 - 2) {
                n6 = 3;
            }
            for (int n7 = n - n6; n7 <= n + n6 && n5 != 0; ++n7) {
                for (int n8 = n3 - n6; n8 <= n3 + n6 && n5 != 0; ++n8) {
                    if (i >= 0 && i < 256) {
                        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n7, i, n8);
                        if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air && block.IlIlIIIlllIIIlIlllIlIllIl() != Material.IlllIllIlIIIIlIIlIIllIIIl) {
                            if (block != IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl && block != IllllllIllIIlllIllIIlIIll.lIIIIllIIlIlIllIIIlIllIlI) {
                                n5 = 0;
                            }
                            else if (i > n2) {
                                n5 = 0;
                            }
                        }
                    }
                    else {
                        n5 = 0;
                    }
                }
            }
        }
        if (n5 == 0) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3);
        if ((block2 == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI || block2 == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl) && n2 < 256 - n4 - 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            for (int j = n2 - 3 + n4; j <= n2 + n4; ++j) {
                final int n9 = j - (n2 + n4);
                for (int n10 = 2 - n9 / 2, k = n - n10; k <= n + n10; ++k) {
                    final int a = k - n;
                    for (int l = n3 - n10; l <= n3 + n10; ++l) {
                        final int a2 = l - n3;
                        if ((Math.abs(a) != n10 || Math.abs(a2) != n10 || (random.nextInt(2) != 0 && n9 != 0)) && !iiiiiIllIlIIIIlIlllIllllI.getBlock(k, j, l).lIIIIlIIllIIlIIlIIIlIIllI()) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, k, j, l, IllllllIllIIlllIllIIlIIll.IllIllIIIlIIlllIIIllIllII);
                        }
                    }
                }
            }
            for (int n11 = 0; n11 < n4; ++n11) {
                final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + n11, n3);
                if (block3.IlIlIIIlllIIIlIlllIlIllIl() == Material.air || block3.IlIlIIIlllIIIlIlllIlIllIl() == Material.IlllIllIlIIIIlIIlIIllIIIl || block3 == IllllllIllIIlllIllIIlIIll.lIIIIllIIlIlIllIIIlIllIlI || block3 == IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 + n11, n3, IllllllIllIIlllIllIIlIIll.lIIIIIllllIIIIlIlIIIIlIlI);
                }
            }
            for (int n12 = n2 - 3 + n4; n12 <= n2 + n4; ++n12) {
                for (int n13 = 2 - (n12 - (n2 + n4)) / 2, n14 = n - n13; n14 <= n + n13; ++n14) {
                    for (int n15 = n3 - n13; n15 <= n3 + n13; ++n15) {
                        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n14, n12, n15).IlIlIIIlllIIIlIlllIlIllIl() == Material.IlllIllIlIIIIlIIlIIllIIIl) {
                            if (random.nextInt(4) == 0 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n14 - 1, n12, n15).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n14 - 1, n12, n15, 8);
                            }
                            if (random.nextInt(4) == 0 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n14 + 1, n12, n15).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n14 + 1, n12, n15, 2);
                            }
                            if (random.nextInt(4) == 0 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n14, n12, n15 - 1).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n14, n12, n15 - 1, 1);
                            }
                            if (random.nextInt(4) == 0 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n14, n12, n15 + 1).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n14, n12, n15 + 1, 4);
                            }
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, int n2, final int n3, final int n4) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, IllllllIllIIlllIllIIlIIll.llllIIllllllIlIIlIlIIIllI, n4);
        int n5 = 4;
        while (true) {
            --n2;
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.air || n5 <= 0) {
                break;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, IllllllIllIIlllIllIIlIIll.llllIIllllllIlIIlIlIIIllI, n4);
            --n5;
        }
    }
}
