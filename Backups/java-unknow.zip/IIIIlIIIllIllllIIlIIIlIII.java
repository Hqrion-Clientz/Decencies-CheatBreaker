import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.concurrent.atomic.AtomicInteger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIllIllllIIlIIIlIII extends GuiScreen
{
    private static final AtomicInteger lIIIIlIIllIIlIIlIIIlIIllI;
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    private NetworkManager IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    private final GuiScreen IIIIllIIllIIIIllIllIIIlIl;
    private static IIIIIIllIIIIlllIllllIIlII IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIIlIIIllIllllIIlIIIlIII(final GuiScreen iiiIllIIllIIIIllIllIIIlIl, final Minecraft lllIIIIIlIllIlIIIllllllII, final ServerData serverData) {
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        final lllIIIllIlIIlIlIIlllIIIII liiiIlIIllIIlIIlIIIlIIllI = lllIIIllIlIIlIlIIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(serverData.lIIIIIIIIIlIllIIllIlIIlIl);
        lllIIIIIlIllIlIIIllllllII.loadWorld(null);
        lllIIIIIlIllIlIIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(serverData);
        this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    public IIIIlIIIllIllllIIlIIIlIII(final GuiScreen iiiIllIIllIIIIllIllIIIlIl, final Minecraft lllIIIIIlIllIlIIIllllllII, final String s, final int n) {
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        lllIIIIIlIllIlIIIllllllII.loadWorld(null);
        this.lIIIIlIIllIIlIIlIIIlIIllI(s, n);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String str, final int i) {
        IIIIlIIIllIllllIIlIIIlIII.lIIIIIIIIIlIllIIllIlIIlIl.info("Connecting to " + str + ", " + i);
        new lIllIlllllIlIIllIIlIlIlll(this, "Server Connector #" + IIIIlIIIllIllllIIlIIIlIII.lIIIIlIIllIIlIIlIIIlIIllI.incrementAndGet(), str, i).start();
    }
    
    @Override
    public void updateScreen() {
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            if (this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl()) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            else if (this.IlllIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl() != null) {
                this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl());
            }
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 2 + 50, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.cancel", new Object[0])));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
            this.IIIIllIlIIIllIlllIlllllIl = true;
            if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI("Aborted"));
            }
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.IIIIllIIllIIIIllIllIIIlIl);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("connect.connecting", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, this.IIIIIIlIlIlIllllllIlllIlI / 2 - 50, 16777215);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("connect.authorizing", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, this.IIIIIIlIlIlIllllllIlllIlI / 2 - 50, 16777215);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new AtomicInteger(0);
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
        IIIIlIIIllIllllIIlIIIlIII.IlIlIIIlllIIIlIlllIlIllIl = new IIIIIIllIIIIlllIllllIIlII();
    }
}
