// 
// Decompiled by Procyon v0.5.36
// 

class IIllIIlIllIlIIIlIIIlIIllI extends IllIIlIlIlIlllIIIIIlIIIll
{
    final /* synthetic */ lllllIllIllIllIlIlIlIllll lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIllIIlIllIlIIIlIIIlIIllI(final lllllIllIllIllIlIlIlIllll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, (byte)n);
    }
    
    @Override
    public IIIIIIllIlIIIIlIlllIllllI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl;
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll);
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll);
    }
}
