// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIlIlIIIIlIllllllIll
{
    private static IlIlIIlIlIIllIIllIlIIIIll lIIIIlIIllIIlIIlIIIlIIllI;
    private static IlIlIIlIlIIllIIllIlIIIIll lIIIIIIIIIlIllIIllIlIIlIl;
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final String s, final Object... array) {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s, array);
    }
    
    public static String lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public static boolean IlllIIIlIlllIllIlIIlllIlI(final String s) {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(s);
    }
    
    public static long lIIIIlIIllIIlIIlIIIlIIllI() {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    static {
        IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI = IlIlIIlIlIIllIIllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI();
        IIllIlIlIlIIIIlIllllllIll.lIIIIIIIIIlIllIIllIlIIlIl = new IlIlIIlIlIIllIIllIlIIIIll();
    }
}
