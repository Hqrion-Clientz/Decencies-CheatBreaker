// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIllIIllllIIllIlIlI
{
    public final int lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    public final int IlllIIIlIlllIllIlIIlllIlI;
    public final lIIIlIlIlIIlIIllIIIIIllll IIIIllIlIIIllIlllIlllllIl;
    public final lIIIlIlIlIIlIIllIIIIIllll IIIIllIIllIIIIllIllIIIlIl;
    
    public IIllIIIIllIIllllIIllIlIlI(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = lIIlIIIllIlIIllIIllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
        this.IIIIllIIllIIIIllIllIIIlIl = lIIlIIIllIlIIllIIllIllIIl.lIIIIIIIIIlIllIIllIlIIlIl(this);
    }
}
