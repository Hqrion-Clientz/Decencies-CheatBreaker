// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIllllIllIlIllllllll extends lIIlllIIIlIllllllIlIlIIII
{
    public IIIlIlIllllIllIlIllllllll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, int n, int n2, int n3, final int n4, final float n5, final float n6, final float n7) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) != IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll) {
            if (n4 == 0) {
                --n2;
            }
            if (n4 == 1) {
                ++n2;
            }
            if (n4 == 2) {
                --n3;
            }
            if (n4 == 3) {
                ++n3;
            }
            if (n4 == 4) {
                --n;
            }
            if (n4 == 5) {
                ++n;
            }
            if (!iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2, n3)) {
                return false;
            }
        }
        if (!lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, lIlIlIlIlIllllIlllIIIlIlI)) {
            return false;
        }
        if (IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII);
        }
        return true;
    }
}
