import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIIIIlIIIIIIlIllIIl extends lIIlIllIIIlllllIllIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private static final ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
    private final IllIIIllllllllIllllIIIIIl IIIllIllIlIlllllllIlIlIII;
    
    public IIIIlIlIIIIlIIIIIIlIllIIl() {
        this.IIIllIllIlIlllllllIlIlIII = new IllIIIllllllllIllllIIIIIl();
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3) {
        float n4;
        for (n4 = n2 - n; n4 < -180; n4 += 360) {}
        while (n4 >= 180) {
            n4 -= 360;
        }
        return n + n3 * n4;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llllIIIlIIIIIlIlIlllIIlll llllIIIlIIIIIlIlIlllIIlll, final double n, final double n2, final double n3, final float n4, final float n5) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        final float liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIlIIIIIlIlIlllIIlll.IlIlIIIlllllIIIlIlIlIllII, llllIIIlIIIIIlIlIlllIIlll.IllllIllllIlIIIlIIIllllll, n5);
        final float n6 = llllIIIlIIIIIlIlIlllIIlll.IIlIIllIIIllllIIlllIllIIl + (llllIIIlIIIIIlIlIlllIIlll.IllIIlllIllIlIllIlIIIIIII - llllIIIlIIIIIlIlIlllIIlll.IIlIIllIIIllllIIlllIllIIl) * n5;
        GL11.glTranslatef((float)n, (float)n2, (float)n3);
        final float n7 = 13.0f * 0.0048076925f;
        GL11.glEnable(32826);
        GL11.glScalef((float)(-1), (float)(-1), 1.0f);
        GL11.glEnable(3008);
        this.lIIIIIIIIIlIllIIllIlIIlIl(llllIIIlIIIIIlIlIlllIIlll);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIlIIIIIlIlIlllIIlll, 0.0f, 0.0f, 0.0f, liiiIlIIllIIlIIlIIIlIIllI, n6, n7);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final llllIIIlIIIIIlIlIlllIIlll llllIIIlIIIIIlIlIlllIIlll) {
        return llllIIIlIIIIIlIlIlllIIlll.isUnicode() ? IIIIlIlIIIIlIIIIIIlIllIIl.lIIIIlIIllIIlIIlIIIlIIllI : IIIIlIlIIIIlIIIIIIlIllIIl.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((llllIIIlIIIIIlIlIlllIIlll)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llllIIIlIIIIIlIlIlllIIlll)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
        IlIlIIIlllIIIlIlllIlIllIl = new ResourceLocation("textures/entity/wither/wither.png");
    }
}
