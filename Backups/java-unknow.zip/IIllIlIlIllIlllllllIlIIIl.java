import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIlIllIlllllllIlIIIl extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "clear";
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.clear.usage";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        final llIIIIIIlIlllllIIllllIlII llIIIIIIlIlllllIIllllIlII = (array.length == 0) ? IlIIIllllllIllIlllllIIllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII) : IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[0]);
        final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII = (array.length >= 2) ? IlIIIllllllIllIlllllIIllI.IlIlIIIlllIIIlIlllIlIllIl(lIlllllIIIIIIllIlIIlIlIII, array[1]) : null;
        final int n = (array.length >= 3) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[2], 0) : -1;
        if (array.length >= 2 && liIlllIIIlIllllllIlIlIIII == null) {
            throw new lIllllIllIIIllIlIlIlIIIII("commands.clear.failure", new Object[] { llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII() });
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = llIIIIIIlIlllllIIllllIlII.inventory.lIIIIlIIllIIlIIlIIIlIIllI(liIlllIIIlIllllllIlIlIIII, n);
        llIIIIIIlIlllllIIllllIlII.llIlIIIlIIIIlIlllIlIIIIll.IlllIIIlIlllIllIlIIlllIlI();
        if (!llIIIIIIlIlllllIIllllIlII.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            llIIIIIIlIlllllIIllllIlII.setIngameNotInFocus();
        }
        if (liiiIlIIllIIlIIlIIIlIIllI == 0) {
            throw new lIllllIllIIIllIlIlIlIIIII("commands.clear.failure", new Object[] { llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII() });
        }
        IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.clear.success", llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII(), liiiIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl()) : ((array.length == 2) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI()) : null);
    }
    
    protected String[] IIIIllIlIIIllIlllIlllllIl() {
        return llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 0;
    }
}
