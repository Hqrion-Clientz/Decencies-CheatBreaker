import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlIIIIlIlllllIIlIIII extends IIllIlIIlllIlIIlIllllllll
{
    private IIlllllllIlllIIllllIIlIll lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlIIlIIIIlIlllllIIlIIII(final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 64; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n4, n5, n6) && (!iiiiiIllIlIIIIlIlllIllllI.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII || n5 < 255) && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n4, n5, n6)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n6, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, 2);
            }
        }
        return true;
    }
}
