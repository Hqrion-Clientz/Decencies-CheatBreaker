import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIIIllllIIlllIllIIl extends lIIlIIIIlIIIIIllIIIIlIIll
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIllIIIllllIIlllIllIIl(final int n, final int n2, final int n3, final int n4, final int n5, final String s, final boolean liiiIlIIllIIlIIlIIIlIIllI) {
        this(n, n2, n3, n4, n5, s);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIlIIllIIIllllIIlllIllIIl(final int n, final int n2, final int n3, final int n4, final int n5, final String s) {
        super(n, n2, n3, n4, n5, s);
        this.lIIIIlIIllIIlIIlIIIlIIllI = true;
    }
    
    @Override
    public void setWorldAndResolution(final Minecraft minecraft, final int n, final int n2) {
        if (this.IlIlllIIIIllIllllIllIIlIl) {
            final FontRenderer fontRendererObj = minecraft.fontRendererObj;
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIllllIIllllllIlIIIll = (n >= this.IlIlIIIlllIIIlIlllIlIllIl && n2 >= this.IIIllIllIlIlllllllIlIlIII && n < this.IlIlIIIlllIIIlIlllIlIllIl + this.IIIIllIlIIIllIlllIlllllIl && n2 < this.IIIllIllIlIlllllllIlIlIII + this.IIIIllIIllIIIIllIllIIIlIl));
            if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)this.IlIlIIIlllIIIlIlllIlIllIl, (float)this.IIIllIllIlIlllllllIlIlIII, (float)(this.IlIlIIIlllIIIlIlllIlIllIl + this.IIIIllIlIIIllIlllIlllllIl), (float)(this.IIIllIllIlIlllllllIlIlIII + this.IIIIllIIllIIIIllIllIIIlIl), this.IIIlIIllllIIllllllIlIIIll ? -15395563 : -14540254);
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(minecraft, n, n2);
            int n3 = -3092272;
            if (!this.IlllIllIlIIIIlIIlIIllIIIl) {
                n3 = -986896;
            }
            else if (this.IIIlIIllllIIllllllIlIIIll) {
                n3 = -1;
            }
            CheatBreaker.getInstance().IIIlllIIIllIllIlIIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl(this.IllIIIIIIIlIlIllllIIllIII, (float)(this.IlIlIIIlllIIIlIlllIlIllIl + this.IIIIllIlIIIllIlllIlllllIl / 2), (float)(this.IIIllIllIlIlllllllIlIlIII + this.IIIIllIIllIIIIllIllIIIlIl / 2 - (this.lIIIIlIIllIIlIIlIIIlIIllI ? 5 : 4)), n3);
        }
    }
}
