import java.util.Arrays;
import com.google.common.collect.Iterators;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.IllegalFormatException;
import com.google.common.collect.Lists;
import java.util.regex.Pattern;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIIIlllllIIlllIIIlIl extends llIlIlIllIIIIlIlIIllllIlI
{
    private final String IIIIllIlIIIllIlllIlllllIl;
    private final Object[] IIIIllIIllIIIIllIllIIIlIl;
    private final Object IlIlIIIlllIIIlIlllIlIllIl;
    private long IIIllIllIlIlllllllIlIlIII;
    List lIIIIIIIIIlIllIIllIlIIlIl;
    public static final Pattern IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIlIIIlllllIIlllIIIlIl(final String iiiIllIlIIIllIlllIlllllIl, final Object... iiiIllIIllIIIIllIllIIIlIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = new Object();
        this.IIIllIllIlIlllllllIlIlIII = -1L;
        this.lIIIIIIIIIlIllIIllIlIIlIl = Lists.newArrayList();
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        for (final Object o : iiiIllIIllIIIIllIllIIIlIl) {
            if (o instanceof IllIllIIlIIlIlllIIllIIIlI) {
                ((IllIllIIlIIlIlllIIllIIIlI)o).lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
            }
        }
    }
    
    synchronized void IIIIllIIllIIIIllIllIIIlIl() {
        final Object ilIlIIIlllIIIlIlllIlIllIl = this.IlIlIIIlllIIIlIlllIlIllIl;
        synchronized (this.IlIlIIIlllIIIlIlllIlIllIl) {
            final long liiiIlIIllIIlIIlIIIlIIllI = IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI == this.IIIllIllIlIlllllllIlIlIII) {
                return;
            }
            this.IIIllIllIlIlllllllIlIlIII = liiiIlIIllIIlIIlIIIlIIllI;
            this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
        }
        try {
            this.lIIIIIIIIIlIllIIllIlIIlIl(IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl));
        }
        catch (IIlIllllIIIIIlllllIIllIIl ilIllllIIIIIlllllIIllIIl) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
            try {
                this.lIIIIIIIIIlIllIIllIlIIlIl(IIllIlIlIlIIIIlIllllllIll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIlIIIllIlllIlllllIl));
            }
            catch (IIlIllllIIIIIlllllIIllIIl ilIllllIIIIIlllllIIllIIl2) {
                throw ilIllllIIIIIlllllIIllIIl;
            }
        }
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final String input) {
        final Matcher matcher = IIIlIlIIIlllllIIlllIIIlIl.IlllIIIlIlllIllIlIIlllIlI.matcher(input);
        int n = 0;
        int beginIndex = 0;
        try {
            while (matcher.find(beginIndex)) {
                final int start = matcher.start();
                final int end = matcher.end();
                if (start > beginIndex) {
                    final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI = new lIlIIllIIlIIIIIlIllIllllI(String.format(input.substring(beginIndex, start), new Object[0]));
                    lIlIIllIIlIIIIIlIllIllllI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
                    this.lIIIIIIIIIlIllIIllIlIIlIl.add(lIlIIllIIlIIIIIlIllIllllI);
                }
                final String group = matcher.group(2);
                final String substring = input.substring(start, end);
                if ("%".equals(group) && "%%".equals(substring)) {
                    final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI2 = new lIlIIllIIlIIIIIlIllIllllI("%");
                    lIlIIllIIlIIIIIlIllIllllI2.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
                    this.lIIIIIIIIIlIllIIllIlIIlIl.add(lIlIIllIIlIIIIIlIllIllllI2);
                }
                else {
                    if (!"s".equals(group)) {
                        throw new IIlIllllIIIIIlllllIIllIIl(this, "Unsupported format: '" + substring + "'");
                    }
                    final String group2 = matcher.group(1);
                    this.lIIIIIIIIIlIllIIllIlIIlIl.add(this.lIIIIlIIllIIlIIlIIIlIIllI((group2 != null) ? (Integer.parseInt(group2) - 1) : n++));
                }
                beginIndex = end;
            }
            if (beginIndex < input.length()) {
                final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI3 = new lIlIIllIIlIIIIIlIllIllllI(String.format(input.substring(beginIndex), new Object[0]));
                lIlIIllIIlIIIIIlIllIllllI3.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
                this.lIIIIIIIIIlIllIIllIlIIlIl.add(lIlIIllIIlIIIIIlIllIllllI3);
            }
        }
        catch (IllegalFormatException ex) {
            throw new IIlIllllIIIIIlllllIIllIIl(this, ex);
        }
    }
    
    private IllIllIIlIIlIlllIIllIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (n >= this.IIIIllIIllIIIIllIllIIIlIl.length) {
            throw new IIlIllllIIIIIlllllIIllIIl(this, n);
        }
        final Object o = this.IIIIllIIllIIIIllIllIIIlIl[n];
        IllIllIIlIIlIlllIIllIIIlI illIllIIlIIlIlllIIllIIIlI;
        if (o instanceof IllIllIIlIIlIlllIIllIIIlI) {
            illIllIIlIIlIlllIIllIIIlI = (IllIllIIlIIlIlllIIllIIIlI)o;
        }
        else {
            illIllIIlIIlIlllIIllIIIlI = new lIlIIllIIlIIIIIlIllIllllI((o == null) ? "null" : o.toString());
            illIllIIlIIlIlllIIllIIIlI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
        }
        return illIllIIlIIlIlllIIllIIIlI;
    }
    
    @Override
    public IllIllIIlIIlIlllIIllIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlllllllIIlIIlIllIIIll ilIIlllllllIIlIIlIllIIIll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlllllllIIlIIlIllIIIll);
        for (final Object o : this.IIIIllIIllIIIIllIllIIIlIl) {
            if (o instanceof IllIllIIlIIlIlllIIllIIIlI) {
                ((IllIllIIlIIlIlllIIllIIIlI)o).lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl());
            }
        }
        if (this.IIIllIllIlIlllllllIlIlIII > -1L) {
            final Iterator<IllIllIIlIIlIlllIIllIIIlI> iterator = (Iterator<IllIllIIlIIlIlllIIllIIIlI>)this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator.hasNext()) {
                iterator.next().lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlllllllIIlIIlIllIIIll);
            }
        }
        return this;
    }
    
    @Override
    public Iterator iterator() {
        this.IIIIllIIllIIIIllIllIIIlIl();
        return Iterators.concat(llIlIlIllIIIIlIlIIllllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl), llIlIlIllIIIIlIlIIllllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI));
    }
    
    @Override
    public String IlIlIIIlllIIIlIlllIlIllIl() {
        this.IIIIllIIllIIIIllIllIIIlIl();
        final StringBuilder sb = new StringBuilder();
        final Iterator<IllIllIIlIIlIlllIIllIIIlI> iterator = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next().IlIlIIIlllIIIlIlllIlIllIl());
        }
        return sb.toString();
    }
    
    public IIIlIlIIIlllllIIlllIIIlIl IIIllIllIlIlllllllIlIlIII() {
        final Object[] array = new Object[this.IIIIllIIllIIIIllIllIIIlIl.length];
        for (int i = 0; i < this.IIIIllIIllIIIIllIllIIIlIl.length; ++i) {
            if (this.IIIIllIIllIIIIllIllIIIlIl[i] instanceof IllIllIIlIIlIlllIIllIIIlI) {
                array[i] = ((IllIllIIlIIlIlllIIllIIIlI)this.IIIIllIIllIIIIllIllIIIlIl[i]).IllIIIIIIIlIlIllllIIllIII();
            }
            else {
                array[i] = this.IIIIllIIllIIIIllIllIIIlIl[i];
            }
        }
        final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl = new IIIlIlIIIlllllIIlllIIIlIl(this.IIIIllIlIIIllIlllIlllllIl, array);
        iiIlIlIIIlllllIIlllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl().IlIlllIIIIllIllllIllIIlIl());
        final Iterator<IllIllIIlIIlIlllIIllIIIlI> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI().iterator();
        while (iterator.hasNext()) {
            iiIlIlIIIlllllIIlllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next().IllIIIIIIIlIlIllllIIllIII());
        }
        return iiIlIlIIIlllllIIlllIIIlIl;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof IIIlIlIIIlllllIIlllIIIlIl)) {
            return false;
        }
        final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl = (IIIlIlIIIlllllIIlllIIIlIl)o;
        return Arrays.equals(this.IIIIllIIllIIIIllIllIIIlIl, iiIlIlIIIlllllIIlllIIIlIl.IIIIllIIllIIIIllIllIIIlIl) && this.IIIIllIlIIIllIlllIlllllIl.equals(iiIlIlIIIlllllIIlllIIIlIl.IIIIllIlIIIllIlllIlllllIl) && super.equals(o);
    }
    
    @Override
    public int hashCode() {
        return 31 * (31 * super.hashCode() + this.IIIIllIlIIIllIlllIlllllIl.hashCode()) + Arrays.hashCode(this.IIIIllIIllIIIIllIllIIIlIl);
    }
    
    @Override
    public String toString() {
        return "TranslatableComponent{key='" + this.IIIIllIlIIIllIlllIlllllIl + '\'' + ", args=" + Arrays.toString(this.IIIIllIIllIIIIllIllIIIlIl) + ", siblings=" + this.lIIIIlIIllIIlIIlIIIlIIllI + ", style=" + this.lIIIIIIIIIlIllIIllIlIIlIl() + '}';
    }
    
    public String lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public Object[] IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = Pattern.compile("%(?:(\\d+)\\$)?([A-Za-z%]|$)");
    }
}
