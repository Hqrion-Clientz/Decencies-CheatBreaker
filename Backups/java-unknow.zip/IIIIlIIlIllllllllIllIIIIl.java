import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIlIllllllllIllIIIIl extends lIlllIIIIIIIlIIIllllIIIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private final lllIIIlIIIlIIIlIllIIIlllI IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIlIIlIllllllllIllIIIIl() {
        this.IlllIIIlIlllIllIlIIlllIlI = new lllIIIlIIIlIIIlIllIIIlllI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllllIlllllllllIIlIlIII llIllllIlllllllllIIlIlIII, final double n, final double n2, final double n3, final float n4) {
        final IIlllllllIlllIIllllIIlIll iiIllIllIlIlllllllIlIlIII = llIllllIlllllllllIIlIlIII.IIIllIllIlIlllllllIlIlIII();
        GL11.glPushMatrix();
        final float n5 = 0.59999996f * 1.1111112f;
        if (iiIllIllIlIlllllllIlIlIII == IllllllIllIIlllIllIIlIIll.IlIIllIIIlllIIIIlIIIIlIll) {
            GL11.glTranslatef((float)n + 0.02020202f * 24.75f, (float)n2 + 1.9714285f * 0.38043478f * n5, (float)n3 + 0.039473683f * 12.666667f);
            GL11.glRotatef(-(llIllllIlllllllllIIlIlIII.IIIIllIlIIIllIlllIlllllIl() * 360 / (float)16), 0.0f, 1.0f, 0.0f);
            this.IlllIIIlIlllIllIlIIlllIlI.IllIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl = true;
        }
        else {
            final int iiiIllIlIIIllIlllIlllllIl = llIllllIlllllllllIIlIlIII.IIIIllIlIIIllIlllIlllllIl();
            float n6 = 0.0f;
            if (iiiIllIlIIIllIlllIlllllIl == 2) {
                n6 = 180;
            }
            if (iiiIllIlIIIllIlllIlllllIl == 4) {
                n6 = 90;
            }
            if (iiiIllIlIIIllIlllIlllllIl == 5) {
                n6 = -90;
            }
            GL11.glTranslatef((float)n + 0.35211268f * 1.42f, (float)n2 + 3.7916667f * 0.1978022f * n5, (float)n3 + 1.1142857f * 0.44871795f);
            GL11.glRotatef(-n6, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(0.0f, -0.5882353f * 0.53125f, 0.31182796f * -1.4030173f);
            this.IlllIIIlIlllIllIlIIlllIlI.IllIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl = false;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIIIlIIlIllllllllIllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI);
        GL11.glPushMatrix();
        GL11.glScalef(n5, -n5, -n5);
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
        GL11.glPopMatrix();
        final FontRenderer liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI();
        final float n7 = 0.034397166f * 0.48453608f * n5;
        GL11.glTranslatef(0.0f, 0.14423077f * 3.4666667f * n5, 0.16f * 0.4375f * n5);
        GL11.glScalef(n7, -n7, n7);
        GL11.glNormal3f(0.0f, 0.0f, -1 * n7);
        GL11.glDepthMask(false);
        final int n8 = 0;
        for (int i = 0; i < llIllllIlllllllllIIlIlIII.IllIIIIIIIlIlIllllIIllIII.length; ++i) {
            final String str = llIllllIlllllllllIIlIlIII.IllIIIIIIIlIlIllllIIllIII[i];
            if (i == llIllllIlllllllllIIlIlIII.lIIIIllIIlIlIllIIIlIllIlI) {
                final String string = "> " + str + " <";
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(string, -liiiIlIIllIIlIIlIIIlIIllI.getStringWidth(string) / 2, i * 10 - llIllllIlllllllllIIlIlIII.IllIIIIIIIlIlIllllIIllIII.length * 5, n8);
            }
            else {
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(str, -liiiIlIIllIIlIIlIIIlIIllI.getStringWidth(str) / 2, i * 10 - llIllllIlllllllllIIlIlIII.IllIIIIIIIlIlIllllIIllIII.length * 5, n8);
            }
        }
        GL11.glDepthMask(true);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl, final double n, final double n2, final double n3, final float n4) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIllllIlllllllllIIlIlIII)illIllIlIIlllIllIIllIlIIl, n, n2, n3, n4);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/sign.png");
    }
}
