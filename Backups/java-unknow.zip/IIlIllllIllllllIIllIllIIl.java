import java.util.NoSuchElementException;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIllllIllllllIIllIllIIl extends IllIlIllllllIIIIIllIllIlI
{
    int lIIIIlIIllIIlIIlIIIlIIllI;
    int lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ int IlllIIIlIlllIllIlIIlllIlI;
    final /* synthetic */ lIIllIIlIIIIIllIlIIllIIIl IIIIllIlIIIllIlllIlllllIl;
    
    IIlIllllIllllllIIllIllIIl(final lIIllIIlIIIIIllIlIIllIIIl iiiIllIlIIIllIlllIlllllIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
    }
    
    @Override
    public boolean hasNext() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI < this.IIIIllIlIIIllIlllIlllllIl.size();
    }
    
    @Override
    public boolean hasPrevious() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI > 0;
    }
    
    @Override
    public Object next() {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        final lIIllIIlIIIIIllIlIIllIIIl iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIlIIllIIlIIlIIIlIIllI++;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        return iiiIllIlIIIllIlllIlllllIl.get(liiiiiiiiIlIllIIllIlIIlIl);
    }
    
    @Override
    public Object previous() {
        if (!this.hasPrevious()) {
            throw new NoSuchElementException();
        }
        final lIIllIIlIIIIIllIlIIllIIIl iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        final int n = this.lIIIIlIIllIIlIIlIIIlIIllI - 1;
        this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        this.lIIIIIIIIIlIllIIllIlIIlIl = n;
        return iiiIllIlIIIllIlllIlllllIl.get(n);
    }
    
    @Override
    public int nextIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int previousIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI - 1;
    }
    
    @Override
    public void add(final Object o) {
        this.IIIIllIlIIIllIlllIlllllIl.add(this.lIIIIlIIllIIlIIlIIIlIIllI++, o);
        this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
    }
    
    @Override
    public void set(final Object o) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl == -1) {
            throw new IllegalStateException();
        }
        this.IIIIllIlIIIllIlllIlllllIl.set(this.lIIIIIIIIIlIllIIllIlIIlIl, o);
    }
    
    @Override
    public void remove() {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl == -1) {
            throw new IllegalStateException();
        }
        this.IIIIllIlIIIllIlllIlllllIl.remove(this.lIIIIIIIIIlIllIIllIlIIlIl);
        if (this.lIIIIIIIIIlIllIIllIlIIlIl < this.lIIIIlIIllIIlIIlIIIlIIllI) {
            --this.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
    }
}
