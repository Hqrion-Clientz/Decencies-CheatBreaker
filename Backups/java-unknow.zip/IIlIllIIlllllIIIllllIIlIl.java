import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIlllllIIIllllIIlIl extends llIlIllIlIIllIIlIIlIlIIll
{
    public IIlIllIIlllllIIIllllIIlIl() {
    }
    
    public IIlIllIIlllllIIIllllIIlIl(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 5, 3, true);
        this.lIIIIlIIllIIlIIlIIIlIIllI((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 5, 11, true);
    }
    
    public static IIlIllIIlllllIIIllllIIlIl lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -5, -3, 0, 13, 14, 13, n4);
        return (llIlIllIlIIllIIlIIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIlIllIIlllllIIIllllIIlIl(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, 0, 12, 4, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 5, 0, 12, 13, 12, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 5, 0, 1, 12, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 11, 5, 0, 12, 12, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 5, 11, 4, 12, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 5, 11, 10, 12, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 9, 11, 7, 12, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 5, 0, 4, 12, 1, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 5, 0, 10, 12, 1, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 9, 0, 7, 12, 1, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 11, 2, 10, 12, 10, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        for (int i = 1; i <= 11; i += 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, i, 10, 0, i, 11, 0, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, i, 10, 12, i, 11, 12, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 10, i, 0, 11, i, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 12, 10, i, 12, 11, i, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, i, 13, 0, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, i, 13, 12, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, 0, 13, i, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, 12, 13, i, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, i + 1, 13, 0, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, i + 1, 13, 12, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 0, 13, i + 1, iiIllllIIllllIIIIIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 12, 13, i + 1, iiIllllIIllllIIIIIlllllIl);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 0, 13, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 0, 13, 12, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 0, 13, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, 0, 12, 13, 0, iiIllllIIllllIIIIIlllllIl);
        for (int j = 3; j <= 9; j += 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 7, j, 1, 8, j, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 11, 7, j, 11, 8, j, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, 3);
        for (int k = 0; k <= 6; ++k) {
            final int n = k + 4;
            for (int l = 5; l <= 7; ++l) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI, l, 5 + k, n, iiIllllIIllllIIIIIlllllIl);
            }
            if (n >= 5 && n <= 8) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 5, n, 7, k + 4, n, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
            }
            else if (n >= 9 && n <= 10) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 8, n, 7, k + 4, n, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
            }
            if (k >= 1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 6 + k, n, 7, 9 + k, n, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
            }
        }
        for (int n2 = 5; n2 <= 7; ++n2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI, n2, 12, 11, iiIllllIIllllIIIIIlllllIl);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 6, 7, 5, 7, 7, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 7, 6, 7, 7, 7, 7, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 13, 12, 7, 13, 12, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 5, 2, 3, 5, 3, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 5, 9, 3, 5, 10, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 5, 4, 2, 5, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 5, 2, 10, 5, 3, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 5, 9, 10, 5, 10, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 10, 5, 4, 10, 5, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, 0);
        final int liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, 1);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI3, 4, 5, 2, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI3, 4, 5, 3, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI3, 4, 5, 9, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI3, 4, 5, 10, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI2, 8, 5, 2, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI2, 8, 5, 3, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI2, 8, 5, 9, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.llIIllIllIlIlIlIllllllIII, liiiIlIIllIIlIIlIIIlIIllI2, 8, 5, 10, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 3, 4, 4, 4, 4, 8, IllllllIllIIlllIllIIlIIll.lllIIlIIllIllIIllIIlIIIIl, IllllllIllIIlllIllIIlIIll.lllIIlIIllIllIIllIIlIIIIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 4, 4, 9, 4, 8, IllllllIllIIlllIllIIlIIll.lllIIlIIllIllIIllIIlIIIIl, IllllllIllIIlllIllIIlIIll.lllIIlIIllIllIIllIIlIIIIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 3, 5, 4, 4, 5, 8, IllllllIllIIlllIllIIlIIll.IlIIlIIllIllIIIIIlllIIlll, IllllllIllIIlllIllIIlIIll.IlIIlIIllIllIIIIIlllIIlll, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 5, 4, 9, 5, 8, IllllllIllIIlllIllIIlIIll.IlIIlIIllIllIIIIIlllIIlll, IllllllIllIIlllIllIIlIIll.IlIIlIIllIllIIIIIlllIIlll, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 2, 0, 8, 2, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 4, 12, 2, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 0, 0, 8, 1, 3, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 0, 9, 8, 1, 12, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 4, 3, 1, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 0, 4, 12, 1, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        for (int n3 = 4; n3 <= 8; ++n3) {
            for (int n4 = 0; n4 <= 2; ++n4) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, n3, -1, n4, iiIllllIIllllIIIIIlllllIl);
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, n3, -1, 12 - n4, iiIllllIIllllIIIIIlllllIl);
            }
        }
        for (int n5 = 0; n5 <= 2; ++n5) {
            for (int n6 = 4; n6 <= 8; ++n6) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, n5, -1, n6, iiIllllIIllllIIIIIlllllIl);
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, 12 - n5, -1, n6, iiIllllIIllllIIIIIlllllIl);
            }
        }
        return true;
    }
}
