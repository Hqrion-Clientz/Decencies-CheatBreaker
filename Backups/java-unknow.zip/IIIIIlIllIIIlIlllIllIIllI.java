import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIIlIllIIIlIlllIllIIllI extends IIlllllllIlllIIllllIIlIll
{
    private String lIIIIlllIIlIlllllIlIllIII;
    
    protected IIIIIlIllIIIlIlllIllIIllI(final String liiiIlllIIlIlllllIlIllIII, final Material material) {
        super(material);
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IIIIllIlIIIllIlllIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.IllIIIIIIIlIlIllllIIllIII(this.IlllIllIlIIIIlIIlIIllIIIl(15));
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.IllIIIIIIIlIlIllllIIllIII(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    protected void IllIIIIIIIlIlIllllIIllIII(final int n) {
        final boolean b = this.lIIIIllIIlIlIllIIIlIllIlI(n) > 0;
        final float n2 = 0.04017857f * 1.5555556f;
        if (b) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(n2, 0.0f, n2, 1.0f - n2, 0.055443548f * 0.56363636f, 1.0f - n2);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(n2, 0.0f, n2, 1.0f - n2, 0.0088383835f * 7.071429f, 1.0f - n2);
        }
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return 20;
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return true;
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) || IIlIlllIlllIllIIIIIlIlIIl.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        boolean b = false;
        if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && !IIlIlllIlllIllIIIIIlIlIIl.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3))) {
            b = true;
        }
        if (b) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 0);
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            final int liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI(iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
            if (liiiIllIIlIlIllIIIlIllIlI > 0) {
                this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, liiiIllIIlIlIllIIIlIllIlI);
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Entity entity) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            final int liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI(iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
            if (liiiIllIIlIlIllIIIlIllIlI == 0) {
                this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, liiiIllIIlIlIllIIIlIllIlI);
            }
        }
    }
    
    protected void IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        final int ilIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        final boolean b = n4 > 0;
        final boolean b2 = ilIlllIIIIllIllllIllIIlIl > 0;
        if (n4 != ilIlllIIIIllIllllIllIIlIl) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this.IlllIllIlIIIIlIIlIIllIIIl(ilIlllIIIIllIllllIllIIlIl), 2);
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, n, n2, n3);
        }
        if (!b2 && b) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 0.35416665787084256 * 1.4117647409439087, n2 + 2.200000047683716 * 0.045454544469344736, n3 + 0.22282608637906653 * 2.2439024448394775, "random.click", 1.48f * 0.2027027f, 0.42000002f * 1.1904762f);
        }
        else if (b2 && !b) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 2.0 * 0.25, n2 + 0.017647059318516095 * 5.666666507720947, n3 + 0.10588235056524051 * 4.722222328186035, "random.click", 0.21639346f * 1.3863636f, 0.8301887f * 0.7227273f);
        }
        if (b2) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI));
        }
    }
    
    protected IlIllIIlIlIllIlIllllllllI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        final float n4 = 0.32352942f * 0.38636363f;
        return IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + n4, n2, n3 + n4, n + 1 - n4, n2 + 1.7142857313156128 * 0.14583333188460934, n3 + 1 - n4);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        if (this.lIIIIllIIlIlIllIIIlIllIlI(n4) > 0) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, n4);
    }
    
    protected void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this);
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return this.lIIIIllIIlIlIllIIIlIllIlI(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return (n4 == 1) ? this.lIIIIllIIlIlIllIIIlIllIlI(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3)) : 0;
    }
    
    @Override
    public boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return true;
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
        final float n = 0.8867925f * 0.5638298f;
        final float n2 = 2.75f * 0.045454547f;
        final float n3 = 2.7666667f * 0.18072289f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.2f * 2.5f - n, 0.1746988f * 2.862069f - n2, 3.7142856f * 0.13461539f - n3, 0.25773194f * 1.94f + n, 2.1666667f * 0.23076923f + n2, 0.6226415f * 0.8030303f + n3);
    }
    
    @Override
    public int IlllIIlllIIIIllIIllllIlIl() {
        return 1;
    }
    
    protected abstract int IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI p0, final int p1, final int p2, final int p3);
    
    protected abstract int lIIIIllIIlIlIllIIIlIllIlI(final int p0);
    
    protected abstract int IlllIllIlIIIIlIIlIIllIIIl(final int p0);
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIlIIllIIIllllIIlllIllIIl = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII);
    }
}
