// 
// Decompiled by Procyon v0.5.36
// 

public class FontMetadataSection implements IllIlIIlIIIIIIllIllIllIIl
{
    private final float[] lIIIIlIIllIIlIIlIIIlIIllI;
    private final float[] lIIIIIIIIIlIllIIllIlIIlIl;
    private final float[] IlllIIIlIlllIllIlIIlllIlI;
    
    public FontMetadataSection(final float[] liiiIlIIllIIlIIlIIIlIIllI, final float[] liiiiiiiiIlIllIIllIlIIlIl, final float[] illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
