// 
// Decompiled by Procyon v0.5.36
// 

final class IIlIIIlllIIIlllIlIIlIlllI extends IIIlllllIIIIllIlIIlIIlIIl
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIIIlllIIIlllIlIIlIlllI() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = true;
    }
    
    @Override
    protected lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final lIIlllIIIlIllIIlIllIllIlI illIIIIIIIlIlIllllIIllIII = llIllIIlllllIlIIIIllIIIll.IllIIIIIIIlIlIllllIIllIII(iiIlIIlIllllIlIIIIlIlIlIl.IllIIIIIIIlIlIllllIIllIII());
        final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI = iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
        final int n = iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl() + illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
        final int n2 = iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl() + illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl();
        final int n3 = iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII() + illIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI();
        if (liiiIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(n, n2, n3)) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll);
            if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII)) {
                lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = 0;
            }
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI.getBlock(n, n2, n3) == IllllllIllIIlllIllIIlIIll.IIlIlIIlIIIlIlllllIIlIIlI) {
            IllllllIllIIlllIllIIlIIll.IIlIlIIlIIIlIlllllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n, n2, n3, 1);
            liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI = false;
        }
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
            iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI(1000, iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl(), iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl(), iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII(), 0);
        }
        else {
            iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI(1001, iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl(), iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl(), iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII(), 0);
        }
    }
}
