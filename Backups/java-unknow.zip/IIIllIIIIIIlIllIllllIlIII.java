import com.google.common.collect.Iterables;
import com.mojang.authlib.properties.Property;
import java.util.UUID;
import com.mojang.authlib.GameProfile;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIIIIlIllIllllIlIII extends IllIllIlIIlllIllIIllIlIIl
{
    private int IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private GameProfile IlllIllIlIIIIlIIlIIllIIIl;
    
    public IIIllIIIIIIlIllIllllIlIII() {
        this.IlllIllIlIIIIlIIlIIllIIIl = null;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("SkullType", (byte)(this.IllIIIIIIIlIlIllllIIllIII & 0xFF));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Rot", (byte)(this.lIIIIllIIlIlIllIIIlIllIlI & 0xFF));
        if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
            lIIlIIIlIIlllIlIllIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl2, this.IlllIllIlIIIIlIIlIIllIIIl);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Owner", ilIIIllIIlIIlllIllllIIIIl2);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.IllIIIIIIIlIlIllllIIllIII = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("SkullType");
        this.lIIIIllIIlIlIllIIIlIllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("Rot");
        if (this.IllIIIIIIIlIlIllllIIllIII == 3) {
            if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Owner", 10)) {
                this.IlllIllIlIIIIlIIlIIllIIIl = lIIlIIIlIIlllIlIllIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("Owner"));
            }
            else if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("ExtraType", 8) && !IlIIllllIIlIIIIIIllIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("ExtraType"))) {
                this.IlllIllIlIIIIlIIlIIllIIIl = new GameProfile((UUID)null, ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("ExtraType"));
                this.setIngameNotInFocus();
            }
        }
    }
    
    public GameProfile lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    @Override
    public IIllIlllIIlllllIlllIIIlIl IllIIIIIIIlIlIllllIIllIII() {
        final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        return new IIIIlIllIIIIIIIIllIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, 4, ilIIIllIIlIIlllIllllIIIIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int illIIIIIIIlIlIllllIIllIII) {
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.IlllIllIlIIIIlIIlIIllIIIl = null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final GameProfile illlIllIlIIIIlIIlIIllIIIl) {
        this.IllIIIIIIIlIlIllllIIllIII = 3;
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        this.setIngameNotInFocus();
    }
    
    private void setIngameNotInFocus() {
        if (this.IlllIllIlIIIIlIIlIIllIIIl != null && !IlIIllllIIlIIIIIIllIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIllIlIIIIlIIlIIllIIIl.getName()) && (!this.IlllIllIlIIIIlIIlIIllIIIl.isComplete() || !this.IlllIllIlIIIIlIIlIIllIIIl.getProperties().containsKey((Object)"textures"))) {
            GameProfile illlIllIlIIIIlIIlIIllIIIl = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIlIIllllllIIIlIlIIl().lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl.getName());
            if (illlIllIlIIIIlIIlIIllIIIl != null) {
                if (Iterables.getFirst((Iterable)illlIllIlIIIIlIIlIIllIIIl.getProperties().get((Object)"textures"), (Object)null) == null) {
                    illlIllIlIIIIlIIlIIllIIIl = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IIlIlllIllIlIlIIIIIlllIll().fillProfileProperties(illlIllIlIIIIlIIlIIllIIIl, true);
                }
                this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
                this.lIllIllIlIIllIllIlIlIIlIl();
            }
        }
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public int IIIlllIIIllIllIlIIIIIIlII() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public void updateDebugProfilerName(final int liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
    }
}
