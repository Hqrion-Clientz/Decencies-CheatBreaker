// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIlIIIIlIIIIlllIlll extends IIllIlllIIlllllIlllIIIlIl
{
    private IllIllIIlIIlIlllIIllIIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIIlIIlIIIIlIIIIlllIlll() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = true;
    }
    
    public IIlIIlIIlIIIIlIIIIlllIlll(final IllIllIIlIIlIlllIIllIIIlI illIllIIlIIlIlllIIllIIIlI) {
        this(illIllIIlIIlIlllIIllIIIlI, true);
    }
    
    public IIlIIlIIlIIIIlIIIIlllIlll(final IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI, final boolean liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = true;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = IllIIlIIlIlllllIllIIlllII.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32767));
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(IllIIlIIlIlllllIllIIlllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return String.format("message='%s'", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public IllIllIIlIIlIlllIIllIIIlI IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
