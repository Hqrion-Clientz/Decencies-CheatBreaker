import java.util.ArrayList;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import java.util.List;
import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllIIllllIIIllllIllll
{
    private final UUID lIIIIlIIllIIlIIlIIIlIIllI;
    private String[] lIIIIIIIIIlIllIIllIlIIlIl;
    private final double IlllIIIlIlllIllIlIIlllIlI;
    private final double IIIIllIlIIIllIlllIlllllIl;
    private final double IIIIllIIllIIIIllIllIIIlIl;
    private static final List IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIlIllIIllllIIIllllIllll(final UUID liiiIlIIllIIlIIlIIIlIIllI, final double illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl, final double iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        final FontRenderer fontRendererObj = Minecraft.getMinecraft().fontRendererObj;
        final RenderManager instance = RenderManager.instance;
        for (final IIIlIllIIllllIIIllllIllll iiIlIllIIllllIIIllllIllll : IIIlIllIIllllIIIllllIllll.IlIlIIIlllIIIlIlllIlIllIl) {
            if (iiIlIllIIllllIIIllllIllll.IlllIIIlIlllIllIlIIlllIlI() != null) {
                if (iiIlIllIIllllIIIllllIllll.IlllIIIlIlllIllIlIIlllIlI().length <= 0) {
                    continue;
                }
                for (int i = iiIlIllIIllllIIIllllIllll.IlllIIIlIlllIllIlIIlllIlI().length - 1; i >= 0; --i) {
                    final String s = iiIlIllIIllllIIIllllIllll.IlllIIIlIlllIllIlIIlllIlI()[iiIlIllIIllllIIIllllIllll.IlllIIIlIlllIllIlIIlllIlI().length - i - 1];
                    final float n = (float)(iiIlIllIIllllIIIllllIllll.IIIIllIlIIIllIlllIlllllIl() - (float)RenderManager.lIIIIIIIIIlIllIIllIlIIlIl);
                    final float n2 = (float)(iiIlIllIIllllIIIllllIllll.IIIIllIIllIIIIllIllIIIlIl() + 1.0 + i * (0.16049382f * 1.5576924f) - (float)RenderManager.IlllIIIlIlllIllIlIIlllIlI);
                    final float n3 = (float)(iiIlIllIIllllIIIllllIllll.IlIlIIIlllIIIlIlllIlIllIl() - (float)RenderManager.IIIIllIlIIIllIlllIlllllIl);
                    final float n4 = 1.4081633f * 0.011835749f * (1.7391304f * 0.92f);
                    GL11.glPushMatrix();
                    GL11.glTranslatef(n, n2, n3);
                    GL11.glNormal3f(0.0f, 1.0f, 0.0f);
                    GL11.glRotatef(-instance.IlllIllIlIIIIlIIlIIllIIIl, 0.0f, 1.0f, 0.0f);
                    GL11.glRotatef(instance.IlIlllIIIIllIllllIllIIlIl, 1.0f, 0.0f, 0.0f);
                    GL11.glScalef(-n4, -n4, n4);
                    GL11.glDisable(2896);
                    GL11.glDepthMask(false);
                    GL11.glDisable(2929);
                    GL11.glEnable(3042);
                    OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                    final Tessellator instance2 = Tessellator.instance;
                    final int n5 = 0;
                    GL11.glDisable(3553);
                    instance2.startDrawingQuads();
                    final int n6 = fontRendererObj.getStringWidth(s) / 2;
                    instance2.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 0.6875f * 0.36363637f);
                    instance2.addVertex(-n6 - 1, -1 + n5, 0.0);
                    instance2.addVertex(-n6 - 1, 8 + n5, 0.0);
                    instance2.addVertex(n6 + 1, 8 + n5, 0.0);
                    instance2.addVertex(n6 + 1, -1 + n5, 0.0);
                    instance2.draw();
                    GL11.glEnable(3553);
                    fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(s, -fontRendererObj.getStringWidth(s) / 2, n5, 553648127);
                    GL11.glEnable(2929);
                    GL11.glDepthMask(true);
                    fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(s, -fontRendererObj.getStringWidth(s) / 2, n5, -1);
                    GL11.glEnable(2896);
                    GL11.glDisable(3042);
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    GL11.glPopMatrix();
                }
            }
        }
    }
    
    public UUID lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String[] IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String[] liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public double IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public double IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public double IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public static List IIIllIllIlIlllllllIlIlIII() {
        return IIIlIllIIllllIIIllllIllll.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    static {
        IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
    }
}
