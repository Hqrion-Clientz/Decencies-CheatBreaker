// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIlIIIIlIIIllIIIIllI extends IllIllIlIIlllIllIIllIlIIl
{
    private lIlIlIlIlIllllIlllIIIlIlI IllIIIIIIIlIlIllllIIllIII;
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("RecordItem", 10)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("RecordItem")));
        }
        else if (ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Record") > 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Record")), 1, 0));
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI() != null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("RecordItem", this.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIllIIlIIlllIllllIIIIl()));
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Record", lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI()));
        }
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI illIIIIIIIlIlIllllIIllIII) {
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.lIllIllIlIIllIllIlIlIIlIl();
    }
}
