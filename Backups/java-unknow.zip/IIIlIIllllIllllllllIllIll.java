import java.util.Map;
import java.util.HashMap;
import java.util.TimerTask;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIIllllIllllllllIllIll extends TimerTask
{
    final /* synthetic */ PlayerUsageSnooper lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIIllllIllllllllIllIll(final PlayerUsageSnooper liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void run() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl.lIlIlIllIIIIIIIIllllIIllI()) {
            final HashMap<String, Integer> hashMap;
            synchronized (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII) {
                hashMap = new HashMap<String, Integer>(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl);
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl == 0) {
                    hashMap.putAll(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI);
                }
                hashMap.put("snooper_count", PlayerUsageSnooper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI));
                hashMap.put("snooper_token", (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI);
            }
            llllIIlIllIllllllIIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl, hashMap, true);
        }
    }
}
