// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlIIIlllIIllllIIlII implements IIlIIlIIllIllllllllIllIII
{
    private lIlIlIlIlIllllIlllIIIlIlI[] lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIIIlIIIlllIIllllIIlII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new lIlIlIlIlIllllIlllIIIlIlI[1];
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return 1;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIlIlIllIIlIIIlIIIlllIII(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI[0];
    }
    
    @Override
    public String IIIlIIlIlIIIlllIIlIllllll() {
        return "Result";
    }
    
    @Override
    public boolean lIIlIIllIIIIIlIllIIIIllII() {
        return false;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[0] != null) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[0];
            this.lIIIIlIIllIIlIIlIIIlIIllI[0] = null;
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        return null;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI IIIlllIIIllIllIlIIIIIIlII(final int n) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI[0] != null) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[0];
            this.lIIIIlIIllIIlIIlIIIlIIllI[0] = null;
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        return null;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI[0] = lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    @Override
    public int IllIlIIIIlllIIllIIlllIIlI() {
        return 64;
    }
    
    @Override
    public void lIllIllIlIIllIllIlIlIIlIl() {
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return true;
    }
    
    @Override
    public void sendHorseInteraction() {
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return true;
    }
}
