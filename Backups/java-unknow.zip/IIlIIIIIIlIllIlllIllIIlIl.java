import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIlIllIlllIllIIlIl extends llIIIlIIIlllIllIIIIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private final IIIIlIIlllIIllllIIlIlllII IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIIIIIIlIllIlllIllIIlIl() {
        super(new IIIIlIIlllIIllllIIlIlllII(), 0.57894737f * 0.8636364f);
        this.IlIlIIIlllIIIlIlllIlIllIl = (IIIIlIIlllIIllllIIlIlllII)this.lIIlIlIllIIlIIIlIIIlllIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll, final double n, final double n2, final double n3, final float n4, final float n5) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIlIlllIllIlIlIllIlll, n, n2, n3, n4, n5);
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll) {
        return IIlIIIIIIlIllIlllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll, final float n, final float n2, final float n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIlIlllIllIlIlIllIlll, n, n2, n3);
        if (llIlIIlIlllIllIlIlIllIlll.IlIlIIIlllIlIllIlIIIlllIl >= 7.583333492279053 * 0.0013186812910419236) {
            final float n4 = 13;
            GL11.glRotatef(8.697184f * 0.7473684f * ((Math.abs((llIlIIlIlllIllIlIlIllIlll.llIIlllIlIIlIIIIIlIllllll - llIlIIlIlllIllIlIlIllIlll.IlIlIIIlllIlIllIlIIIlllIl * (1.0f - n3) + 6) % n4 - n4 * (0.43434343f * 1.1511629f)) - n4 * (0.012658228f * 19.75f)) / (n4 * (0.09166667f * 2.7272727f))), 0.0f, 0.0f, 1.0f);
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll, final float n) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(llIlIIlIlllIllIlIlIllIlll, n);
        if (llIlIIlIlllIllIlIlIllIlll.IllIIIIIllllIlllIIlIIllIl() != 0) {
            GL11.glEnable(32826);
            GL11.glPushMatrix();
            GL11.glRotatef(5 + 180 * this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IlIlIIIlllIIIlIlllIlIllIl / (2.0943952f * 1.5f), 1.0f, 0.0f, 0.0f);
            GL11.glTranslatef(0.9285714f * -0.74038464f, 1.548387f * 0.8072917f, 0.6904762f * -1.3577586f);
            GL11.glRotatef((float)90, 1.0f, 0.0f, 0.0f);
            final float n2 = 1.7647059f * 0.45333335f;
            GL11.glScalef(n2, -n2, n2);
            final int liiiIlIIllIIlIIlIIIlIIllI = llIlIIlIlllIllIlIlIllIlll.lIIIIlIIllIIlIIlIIIlIIllI(n);
            OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI, liiiIlIIllIIlIIlIIIlIIllI % 65536 / 1.0f, liiiIlIIllIIlIIlIIIlIIllI / 65536 / 1.0f);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(TextureMap.locationBlocksTexture);
            this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIllllIIIlIllllIIIIIllII, 0, 1.0f);
            GL11.glPopMatrix();
            GL11.glDisable(32826);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)illlIIIllIlIIlIllIIlIlllI, n, n2, n3, n4, n5);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)entityLivingBase, n);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n, final float n2, final float n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)entityLivingBase, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((llIlIIlIlllIllIlIlIllIlll)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/iron_golem.png");
    }
}
