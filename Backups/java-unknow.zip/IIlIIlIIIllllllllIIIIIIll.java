import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.RenderingHints;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIIllllllllIIIIIIll
{
    private static IlIIIllIIlllIlIlIlIlllIlI[] lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI = null;
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl() {
        IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI = null;
        IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(lIIIllIIIllIlllllIIlIllII.IlIlllIllIlIllIlllIlllIll());
        if (lIIIllIIIllIlllllIIlIllII.lIlIIllIIIlllIIllIIlIIllI()) {
            IIIIllIlIIIllIlllIlllllIl();
        }
    }
    
    public static void IlllIIIlIlllIllIlIIlllIlI() {
        if (IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI != null && lIIIllIIIllIlllllIIlIllII.lIlIIllIIIlllIIllIIlIIllI()) {
            IIIIllIlIIIllIlllIlllllIl();
        }
    }
    
    public static void IIIIllIlIIIllIlllIlllllIl() {
        if (IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            for (int i = 0; i < IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI.length; ++i) {
                IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI[i].IIIIllIlIIIllIlllIlllllIl();
            }
        }
    }
    
    public static IlIIIllIIlllIlIlIlIlllIlI[] lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIllIIIIllllIlIIllIll[] array) {
        final ArrayList list = new ArrayList();
        for (int i = 0; i < array.length; ++i) {
            final IlIIIllIIlllIlIlIlIlllIlI[] liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(array[i]);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                list.addAll(Arrays.asList(liiiIlIIllIIlIIlIIIlIIllI));
            }
        }
        return list.toArray(new IlIIIllIIlllIlIlIlIlllIlI[list.size()]);
    }
    
    public static IlIIIllIIlllIlIlIlIlllIlI[] lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIllIIIIllllIlIIllIll illlIIllIIIIllllIlIIllIll) {
        final String[] liiiIlIIllIIlIIlIIIlIIllI = lIIIlIIIllIIlIlIlIIlIIlll.lIIIIlIIllIIlIIlIIIlIIllI(illlIIllIIIIllllIlIIllIll, "mcpatcher/anim", ".properties", null);
        if (liiiIlIIllIIlIIlIIIlIIllI.length <= 0) {
            return null;
        }
        final ArrayList<IlIIIllIIlllIlIlIlIlllIlI> list = new ArrayList<IlIIIllIIlllIlIlIlIlllIlI>();
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.length; ++i) {
            final String s = liiiIlIIllIIlIIlIIIlIIllI[i];
            lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("Texture animation: " + s);
            try {
                final ResourceLocation resourceLocation = new ResourceLocation(s);
                final InputStream func_152780_c = illlIIllIIIIllllIlIIllIll.func_152780_c(resourceLocation);
                final Properties properties = new Properties();
                properties.load(func_152780_c);
                final IlIIIllIIlllIlIlIlIlllIlI liiiIlIIllIIlIIlIIIlIIllI2 = lIIIIlIIllIIlIIlIIIlIIllI(properties, resourceLocation);
                if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                    if (lIIIllIIIllIlllllIIlIllII.IIIIllIIllIIIIllIllIIIlIl(new ResourceLocation(liiiIlIIllIIlIIlIIIlIIllI2.IlIlIIIlllIIIlIlllIlIllIl())) != illlIIllIIIIllllIlIIllIll) {
                        lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("Skipped: " + s + ", target texture not loaded from same resource pack");
                    }
                    else {
                        list.add(liiiIlIIllIIlIIlIIIlIIllI2);
                    }
                }
            }
            catch (FileNotFoundException ex) {
                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("File not found: " + ex.getMessage());
            }
            catch (IOException ex2) {
                ex2.printStackTrace();
            }
        }
        return list.toArray(new IlIIIllIIlllIlIlIlIlllIlI[list.size()]);
    }
    
    public static IlIIIllIIlllIlIlIlIlllIlI lIIIIlIIllIIlIIlIIIlIIllI(final Properties properties, final ResourceLocation resourceLocation) {
        final String property = properties.getProperty("from");
        final String property2 = properties.getProperty("to");
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(properties.getProperty("x"), -1);
        final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(properties.getProperty("y"), -1);
        final int liiiIlIIllIIlIIlIIIlIIllI3 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(properties.getProperty("w"), -1);
        final int liiiIlIIllIIlIIlIIIlIIllI4 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(properties.getProperty("h"), -1);
        if (property == null || property2 == null) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("TextureAnimation: Source or target texture not specified");
            return null;
        }
        if (liiiIlIIllIIlIIlIIIlIIllI < 0 || liiiIlIIllIIlIIlIIIlIIllI2 < 0 || liiiIlIIllIIlIIlIIIlIIllI3 < 0 || liiiIlIIllIIlIIlIIIlIIllI4 < 0) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("TextureAnimation: Invalid coordinates");
            return null;
        }
        final String trim = property.trim();
        final String trim2 = property2.trim();
        final String liiiiiiiiIlIllIIllIlIIlIl = lllIIlIlIlIlllIIIIIIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI());
        final String liiiIlIIllIIlIIlIIIlIIllI5 = lllIIlIlIlIlllIIIIIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(trim, liiiiiiiiIlIllIIllIlIIlIl);
        final String liiiIlIIllIIlIIlIIIlIIllI6 = lllIIlIlIlIlllIIIIIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(trim2, liiiiiiiiIlIllIIllIlIIlIl);
        final byte[] liiiIlIIllIIlIIlIIIlIIllI7 = lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI5, liiiIlIIllIIlIIlIIIlIIllI3);
        if (liiiIlIIllIIlIIlIIIlIIllI7 == null) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("TextureAnimation: Source texture not found: " + liiiIlIIllIIlIIlIIIlIIllI6);
            return null;
        }
        final ResourceLocation obj = new ResourceLocation(liiiIlIIllIIlIIlIIIlIIllI6);
        if (!lIIIllIIIllIlllllIIlIllII.IlllIIIlIlllIllIlIIlllIlI(obj)) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("TextureAnimation: Target texture not found: " + liiiIlIIllIIlIIlIIIlIIllI6);
            return null;
        }
        final llllIIlIllllllIlllIlIIIll liiiIlIIllIIlIIlIIIlIIllI8 = lllIIlIlIlIlllIIIIIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(obj);
        if (liiiIlIIllIIlIIlIIIlIIllI8 == null) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("TextureAnimation: Target texture not found: " + obj);
            return null;
        }
        return new IlIIIllIIlllIlIlIlIlllIlI(liiiIlIIllIIlIIlIIIlIIllI5, liiiIlIIllIIlIIlIIIlIIllI7, liiiIlIIllIIlIIlIIIlIIllI6, liiiIlIIllIIlIIlIIIlIIllI8.lIIIIlIIllIIlIIlIIIlIIllI(), liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI4, properties, 1);
    }
    
    public static byte[] lIIIIlIIllIIlIIlIIIlIIllI(final String str, final int n) {
        byte[] array = lIIIIIIIIIlIllIIllIlIIlIl(str, n);
        if (array == null) {
            array = lIIIIIIIIIlIllIIllIlIIlIl("/anim" + str, n);
        }
        return array;
    }
    
    private static byte[] lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n) {
        final GameSettings lIllIllIllllllIllIlllIlIl = lIIIllIIIllIlllllIIlIllII.lIllIllIllllllIllIlllIlIl();
        try {
            final InputStream liiiIlIIllIIlIIlIIIlIIllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation(s));
            if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                return null;
            }
            BufferedImage bufferedImage = lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            liiiIlIIllIIlIIlIIIlIIllI.close();
            if (bufferedImage == null) {
                return null;
            }
            if (n > 0 && bufferedImage.getWidth() != n) {
                bufferedImage = lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage, n, (int)(n * (double)(bufferedImage.getHeight() / bufferedImage.getWidth())));
            }
            final int width = bufferedImage.getWidth();
            final int height = bufferedImage.getHeight();
            final int[] rgbArray = new int[width * height];
            final byte[] array = new byte[width * height * 4];
            bufferedImage.getRGB(0, 0, width, height, rgbArray, 0, width);
            for (int i = 0; i < rgbArray.length; ++i) {
                final int n2 = rgbArray[i] >> 24 & 0xFF;
                int n3 = rgbArray[i] >> 16 & 0xFF;
                int n4 = rgbArray[i] >> 8 & 0xFF;
                int n5 = rgbArray[i] & 0xFF;
                if (lIllIllIllllllIllIlllIlIl != null && lIllIllIllllllIllIlllIlIl.IIIIllIIllIIIIllIllIIIlIl) {
                    final int n6 = (n3 * 30 + n4 * 59 + n5 * 11) / 100;
                    final int n7 = (n3 * 30 + n4 * 70) / 100;
                    final int n8 = (n3 * 30 + n5 * 70) / 100;
                    n3 = n6;
                    n4 = n7;
                    n5 = n8;
                }
                array[i * 4 + 0] = (byte)n3;
                array[i * 4 + 1] = (byte)n4;
                array[i * 4 + 2] = (byte)n5;
                array[i * 4 + 3] = (byte)n2;
            }
            return array;
        }
        catch (FileNotFoundException ex2) {
            return null;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    private static BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final InputStream input) {
        final BufferedImage read = ImageIO.read(input);
        input.close();
        return read;
    }
    
    public static BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage bufferedImage, final int width, final int height) {
        final BufferedImage bufferedImage2 = new BufferedImage(width, height, 2);
        final Graphics2D graphics = bufferedImage2.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics.drawImage(bufferedImage, 0, 0, width, height, null);
        return bufferedImage2;
    }
    
    static {
        IIlIIlIIIllllllllIIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI = null;
    }
}
