// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIIlIIIIlIIlIIlllII
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private float lIIIIIIIIIlIllIIllIlIIlIl;
    private lIIIIllllIlIIIIllIllIIlIl IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIlIlIIlIIIIlIIlIIlllII(final int liiiIlIIllIIlIIlIIIlIIllI, final float liiiiiiiiIlIllIIllIlIIlIl, final lIIIIllllIlIIIIllIllIIlIl illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 0;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 0.0f;
        this.IlllIIIlIlllIllIlIIlllIlI = null;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public lIIIIllllIlIIIIllIllIIlIl lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIIIllllIlIIllIlIIlIIIlI llIIIllllIlIIllIlIIlIIIlI, final float n) {
        final lIIIIllllIlIIIIllIllIIlIl liiiIlIIllIIlIIlIIIlIIllI = IIlllIllIIlIlIlIlllIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(llIIIllllIlIIllIlIIlIIIlI, this.lIIIIlIIllIIlIIlIIIlIIllI);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(n);
        }
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n * this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
}
