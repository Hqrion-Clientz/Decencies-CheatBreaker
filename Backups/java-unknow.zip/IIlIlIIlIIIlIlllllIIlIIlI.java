import org.lwjgl.input.Mouse;
import java.util.concurrent.atomic.AtomicBoolean;
import com.sun.javafx.geom.Vec2d;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIlIlIIlIIIlIlllllIIlIIlI extends llllIIIIlIlIllIIIllllIIll
{
    private Vec2d IIIllIllIlIlllllllIlIlIII;
    private AtomicBoolean IllIIIIIIIlIlIllllIIllIII;
    
    public IIlIlIIlIIIlIlllllIIlIIlI() {
        this.IIIllIllIlIlllllllIlIlIII = new Vec2d();
        this.IllIIIIIIIlIlIllllIIllIII = new AtomicBoolean();
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2) {
        if (this.IllIIIIIIIlIlIllllIIllIII.get()) {
            if (!Mouse.isButtonDown(0)) {
                this.IllIIIIIIIlIlIllllIIllIII.set(false);
                return;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI((float)(n - this.IIIllIllIlIlllllllIlIlIII.x), (float)(n2 - this.IIIllIllIlIlllllllIlIlIII.y), this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
        }
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final float n, final float n2) {
        this.IIIllIllIlIlllllllIlIlIII.set((double)(n - this.lIIIIlIIllIIlIIlIIIlIIllI), (double)(n2 - this.lIIIIIIIIIlIllIIllIlIIlIl));
        this.IllIIIIIIIlIlIllllIIllIII.set(true);
    }
    
    protected void IllIIIIIIIlIlIllllIIllIII() {
        if (this.IllIIIIIIIlIlIllllIIllIII.get()) {
            this.IllIIIIIIIlIlIllllIIllIII.set(false);
        }
    }
}
