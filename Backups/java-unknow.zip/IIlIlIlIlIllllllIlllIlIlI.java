// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIlIllllllIlllIlIlI extends IIlIIlIIllIIllIlIIIIIIIlI
{
    public IIlIlIlIlIllllllIlllIlIlI(final int n) {
        super(n);
        this.IIIlllllIIlIlIIIllllllIII.lIllIllIlIIllIllIlIlIIlIl = -100;
        this.IIIlllllIIlIlIIIllllllIII.llIlIIIllIIIIlllIlIIIIIlI = -100;
        this.IIIlllllIIlIlIIIllllllIII.lIllIlIlllIIlIIllIIlIIlII = -100;
        this.IIIlllllIIlIlIIIllllllIII.IllIlIIIIlllIIllIIlllIIlI = 1;
        this.IIIlllllIIlIlIIIllllllIII.IllIIlllIllIlIllIlIIIIIII = 1;
        this.IIIlIllIlllIlIllIllllllll = IllllllIllIIlllIllIIlIIll.IIllllllIlIIIIlllIlIlIlll;
        this.lIlIlIIIIllIlllIlIIlllIlI.clear();
        this.IIllllIllllIIIlIIllllIlll.clear();
        this.llllIIIIIlIlIlIlIllIIIIII.clear();
        this.IIllllIllllIIIlIIllllIlll.add(new lIlIIIlllIIlllllIlIllIIIl(IIIlIlIllIIllllllllIIIIIl.class, 8, 4, 8));
    }
}
