import com.mojang.authlib.GameProfile;
import java.util.UUID;
import java.net.Proxy;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIlIlllllIIlllIIIlIlI
{
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return Minecraft.getMinecraft().gameSettings.lIIIIIIlIIllIlIlIllIIIIll;
    }
    
    public static Proxy lIIIIIIIIIlIllIIllIlIIlIl() {
        return Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI();
    }
    
    public static String IlllIIIlIlllIllIlIIlllIlI() {
        final Session iiiIlIIIlllllllllIlllIlll = Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll();
        return (iiiIlIIIlllllllllIlllIlll == null) ? null : iiiIlIIIlllllllllIlllIlll.getSessionID();
    }
    
    public static String IIIIllIlIIIllIlllIlllllIl() {
        final Session iiiIlIIIlllllllllIlllIlll = Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll();
        return (iiiIlIIIlllllllllIlllIlll == null) ? null : iiiIlIIIlllllllllIlllIlll.getUsername();
    }
    
    public static long IIIIllIIllIIIIllIllIIIlIl() {
        return Minecraft.getSystemTime();
    }
    
    public static String IlIlIIIlllIIIlIlllIlIllIl() {
        return Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().getSessionID();
    }
    
    public static String IIIllIllIlIlllllllIlIlIII() {
        return Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().getUsername();
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return Minecraft.getMinecraft().lIlIlIIIlIIllllllllIIlllI().fillProfileProperties(new GameProfile(UUID.fromString(s.replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5")), (String)null), false).getName();
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final llllIlllIIIIIllllIlIlIIII llllIlllIIIIIllllIlIlIIII) {
        Minecraft.getMinecraft().displayGuiScreen(llllIlllIIIIIllllIlIlIIII.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    public static String IllIIIIIIIlIlIllllIIllIII() {
        return Minecraft.getMinecraft().mcDataDir.getAbsolutePath();
    }
    
    public static int lIIIIllIIlIlIllIIIlIllIlI() {
        return IllIIlIIlIlIIllllIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public static int IlllIllIlIIIIlIIlIIllIIIl() {
        return IllIIlIIlIlIIllllIIIlIlII.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public static int IlIlllIIIIllIllllIllIIlIl() {
        return IllIIlIIlIlIIllllIIIlIlII.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
    }
}
