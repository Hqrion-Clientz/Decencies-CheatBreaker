import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIlIIllIIlIlIIlIIllI extends lIIlIllIIIlllllIllIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIIlllIlIlIlIIlIIlIIl ilIIlIIlllIlIlIlIIlIIlIIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIlIIlllIlIlIlIIlIIlIIl);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)n, (float)n2, (float)n3);
        GL11.glRotatef(ilIIlIIlllIlIlIlIIlIIlIIl.IlIlIIIlllllIIIlIlIlIllII + (ilIIlIIlllIlIlIlIIlIIlIIl.IllllIllllIlIIIlIIIllllll - ilIIlIIlllIlIlIlIIlIIlIIl.IlIlIIIlllllIIIlIlIlIllII) * n5 - 90, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(ilIIlIIlllIlIlIlIIlIIlIIl.IIlIIllIIIllllIIlllIllIIl + (ilIIlIIlllIlIlIlIIlIIlIIl.IllIIlllIllIlIllIlIIIIIII - ilIIlIIlllIlIlIlIIlIIlIIl.IIlIIllIIIllllIIlllIllIIl) * n5, 0.0f, 0.0f, 1.0f);
        final Tessellator instance = Tessellator.instance;
        final int n6 = 0;
        final float n7 = 0.0f;
        final float n8 = 0.43939397f * 1.137931f;
        final float n9 = (0 + n6 * 10) / (float)32;
        final float n10 = (5 + n6 * 10) / (float)32;
        final float n11 = 0.0f;
        final float n12 = 0.14476103f * 1.0793651f;
        final float n13 = (5 + n6 * 10) / (float)32;
        final float n14 = (10 + n6 * 10) / (float)32;
        final float n15 = 0.978022f * 0.05751404f;
        GL11.glEnable(32826);
        final float n16 = ilIIlIIlllIlIlIlIIlIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl - n5;
        if (n16 > 0.0f) {
            GL11.glRotatef(-MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n16 * 3) * n16, 0.0f, 0.0f, 1.0f);
        }
        GL11.glRotatef((float)45, 1.0f, 0.0f, 0.0f);
        GL11.glScalef(n15, n15, n15);
        GL11.glTranslatef((float)(-4), 0.0f, 0.0f);
        GL11.glNormal3f(n15, 0.0f, 0.0f);
        instance.startDrawingQuads();
        instance.addVertexWithUV(-7, -2, -2, n11, n13);
        instance.addVertexWithUV(-7, -2, 2, n12, n13);
        instance.addVertexWithUV(-7, 2, 2, n12, n14);
        instance.addVertexWithUV(-7, 2, -2, n11, n14);
        instance.draw();
        GL11.glNormal3f(-n15, 0.0f, 0.0f);
        instance.startDrawingQuads();
        instance.addVertexWithUV(-7, 2, -2, n11, n13);
        instance.addVertexWithUV(-7, 2, 2, n12, n13);
        instance.addVertexWithUV(-7, -2, 2, n12, n14);
        instance.addVertexWithUV(-7, -2, -2, n11, n14);
        instance.draw();
        for (int i = 0; i < 4; ++i) {
            GL11.glRotatef((float)90, 1.0f, 0.0f, 0.0f);
            GL11.glNormal3f(0.0f, 0.0f, n15);
            instance.startDrawingQuads();
            instance.addVertexWithUV(-8, -2, 0.0, n7, n9);
            instance.addVertexWithUV(8, -2, 0.0, n8, n9);
            instance.addVertexWithUV(8, 2, 0.0, n8, n10);
            instance.addVertexWithUV(-8, 2, 0.0, n7, n10);
            instance.draw();
        }
        GL11.glDisable(32826);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIIlllIlIlIlIIlIIlIIl ilIIlIIlllIlIlIlIIlIIlIIl) {
        return IIlIIIIlIIllIIlIlIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIIlllIlIlIlIIlIIlIIl)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIIlllIlIlIlIIlIIlIIl)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/arrow.png");
    }
}
