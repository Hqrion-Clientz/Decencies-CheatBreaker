import java.nio.ByteBuffer;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class Framebuffer
{
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public int IIIIllIlIIIllIlllIlllllIl;
    public boolean IIIIllIIllIIIIllIllIIIlIl;
    public int IlIlIIIlllIIIlIlllIlIllIl;
    public int IIIllIllIlIlllllllIlIlIII;
    public int IllIIIIIIIlIlIllllIIllIII;
    public float[] lIIIIllIIlIlIllIIIlIllIlI;
    public int IlllIllIlIIIIlIIlIIllIIIl;
    
    public Framebuffer(final int n, final int n2, final boolean iiiIllIIllIIIIllIllIIIlIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.IllIIIIIIIlIlIllllIIllIII = -1;
        (this.lIIIIllIIlIlIllIIIlIllIlI = new float[4])[0] = 1.0f;
        this.lIIIIllIIlIlIllIIIlIllIlI[1] = 1.0f;
        this.lIIIIllIIlIlIllIIIlIllIlI[2] = 1.0f;
        this.lIIIIllIIlIlIllIIIlIllIlI[3] = 0.0f;
        this.createBindFramebuffer(n, n2);
    }
    
    public void createBindFramebuffer(final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl) {
        if (!OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
            this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        }
        else {
            GL11.glEnable(2929);
            if (this.IlIlIIIlllIIIlIlllIlIllIl >= 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl);
            this.lIIIIIIIIIlIllIIllIlIIlIl();
            OpenGlHelper.IIIllIllIlIlllllllIlIlIII(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, 0);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            this.IIIIllIlIIIllIlllIlllllIl();
            this.unbindFramebuffer();
            if (this.IllIIIIIIIlIlIllllIIllIII > -1) {
                OpenGlHelper.IIIllIllIlIlllllllIlIlIII(this.IllIIIIIIIlIlIllllIIllIII);
                this.IllIIIIIIIlIlIllllIIllIII = -1;
            }
            if (this.IIIllIllIlIlllllllIlIlIII > -1) {
                lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII);
                this.IIIllIllIlIlllllllIlIlIII = -1;
            }
            if (this.IlIlIIIlllIIIlIlllIlIllIl > -1) {
                OpenGlHelper.IIIllIllIlIlllllllIlIlIII(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, 0);
                OpenGlHelper.IllIIIIIIIlIlIllllIIllIII(this.IlIlIIIlllIIIlIlllIlIllIl);
                this.IlIlIIIlllIIIlIlllIlIllIl = -1;
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        this.IlllIIIlIlllIllIlIIlllIlI = n;
        this.IIIIllIlIIIllIlllIlllllIl = n2;
        this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        this.lIIIIIIIIIlIllIIllIlIIlIl = n2;
        if (!OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        else {
            this.IlIlIIIlllIIIlIlllIlIllIl = OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl();
            this.IIIllIllIlIlllllllIlIlIII = lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
            if (this.IIIIllIIllIIIIllIllIIIlIl) {
                this.IllIIIIIIIlIlIllllIIllIII = OpenGlHelper.IlIlIIIlllIIIlIlllIlIllIl();
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(9728);
            GL11.glBindTexture(3553, this.IIIllIllIlIlllllllIlIlIII);
            GL11.glTexImage2D(3553, 0, 32856, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, 0, 6408, 5121, (ByteBuffer)null);
            OpenGlHelper.IIIllIllIlIlllllllIlIlIII(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
            OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, OpenGlHelper.IIIllIllIlIlllllllIlIlIII, 3553, this.IIIllIllIlIlllllllIlIlIII, 0);
            if (this.IIIIllIIllIIIIllIllIIIlIl) {
                OpenGlHelper.IllIIIIIIIlIlIllllIIllIII(OpenGlHelper.IlIlIIIlllIIIlIlllIlIllIl, this.IllIIIIIIIlIlIllllIIllIII);
                OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(OpenGlHelper.IlIlIIIlllIIIlIlllIlIllIl, 33190, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl);
                OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, OpenGlHelper.IllIIIIIIIlIlIllllIIllIII, OpenGlHelper.IlIlIIIlllIIIlIlllIlIllIl, this.IllIIIIIIIlIlIllllIIllIII);
            }
            this.IlIlIIIlllIIIlIlllIlIllIl();
            this.IIIIllIlIIIllIlllIlllllIl();
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int illlIllIlIIIIlIIlIIllIIIl) {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
            GL11.glBindTexture(3553, this.IIIllIllIlIlllllllIlIlIII);
            GL11.glTexParameterf(3553, 10241, (float)illlIllIlIIIIlIIlIIllIIIl);
            GL11.glTexParameterf(3553, 10240, (float)illlIllIlIIIIlIIlIIllIIIl);
            GL11.glTexParameterf(3553, 10242, (float)10496);
            GL11.glTexParameterf(3553, 10243, (float)10496);
            GL11.glBindTexture(3553, 0);
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        final int liiiIllIIlIlIllIIIlIllIlI = OpenGlHelper.lIIIIllIIlIlIllIIIlIllIlI(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl);
        if (liiiIllIIlIlIllIIIlIllIlI == OpenGlHelper.lIIIIllIIlIlIllIIIlIllIlI) {
            return;
        }
        if (liiiIllIIlIlIllIIIlIllIlI == OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT");
        }
        if (liiiIllIIlIlIllIIIlIllIlI == OpenGlHelper.IlIlllIIIIllIllllIllIIlIl) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT");
        }
        if (liiiIllIIlIlIllIIIlIllIlI == OpenGlHelper.llIIlllIIIIlllIllIlIlllIl) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER");
        }
        if (liiiIllIIlIlIllIIIlIllIlI == OpenGlHelper.lIIlIlIllIIlIIIlIIIlllIII) {
            throw new RuntimeException("GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER");
        }
        throw new RuntimeException("glCheckFramebufferStatus returned unknown status:" + liiiIllIIlIlIllIIIlIllIlI);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            GL11.glBindTexture(3553, this.IIIllIllIlIlllllllIlIlIII);
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            GL11.glBindTexture(3553, 0);
        }
    }
    
    public void bindFramebuffer(final boolean b) {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            OpenGlHelper.IIIllIllIlIlllllllIlIlIII(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
            if (b) {
                GL11.glViewport(0, 0, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
            }
        }
    }
    
    public void unbindFramebuffer() {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            OpenGlHelper.IIIllIllIlIlllllllIlIlIII(OpenGlHelper.IIIIllIIllIIIIllIllIIIlIl, 0);
        }
    }
    
    public void setFramebufferColor(final float n, final float n2, final float n3, final float n4) {
        this.lIIIIllIIlIlIllIIIlIllIlI[0] = n;
        this.lIIIIllIIlIlIllIIIlIllIlI[1] = n2;
        this.lIIIIllIIlIlIllIIIlIllIlI[2] = n3;
        this.lIIIIllIIlIlIllIIIlIllIlI[3] = n4;
    }
    
    public void framebufferRender(final int n, final int n2) {
        if (OpenGlHelper.IIIllIllIlIlllllllIlIlIII()) {
            GL11.glColorMask(true, true, true, false);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)n, (double)n2, 0.0, (double)1000, (double)3000);
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, 0.0f, (float)(-2000));
            GL11.glViewport(0, 0, n, n2);
            GL11.glEnable(3553);
            GL11.glDisable(2896);
            GL11.glDisable(3008);
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(2903);
            this.IlllIIIlIlllIllIlIIlllIlI();
            final float n3 = (float)n;
            final float n4 = (float)n2;
            final float n5 = this.IlllIIIlIlllIllIlIIlllIlI / (float)this.lIIIIlIIllIIlIIlIIIlIIllI;
            final float n6 = this.IIIIllIlIIIllIlllIlllllIl / (float)this.lIIIIIIIIIlIllIIllIlIIlIl;
            final Tessellator instance = Tessellator.instance;
            instance.startDrawingQuads();
            instance.setColorOpaque_I(-1);
            instance.addVertexWithUV(0.0, n4, 0.0, 0.0, 0.0);
            instance.addVertexWithUV(n3, n4, 0.0, n5, 0.0);
            instance.addVertexWithUV(n3, 0.0, 0.0, n5, n6);
            instance.addVertexWithUV(0.0, 0.0, 0.0, 0.0, n6);
            instance.draw();
            this.IIIIllIlIIIllIlllIlllllIl();
            GL11.glDepthMask(true);
            GL11.glColorMask(true, true, true, true);
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        this.bindFramebuffer(true);
        GL11.glClearColor(this.lIIIIllIIlIlIllIIIlIllIlI[0], this.lIIIIllIIlIlIllIIIlIllIlI[1], this.lIIIIllIIlIlIllIIIlIllIlI[2], this.lIIIIllIIlIlIllIIIlIllIlI[3]);
        int n = 16384;
        if (this.IIIIllIIllIIIIllIllIIIlIl) {
            GL11.glClearDepth(1.0);
            n |= 0x100;
        }
        GL11.glClear(n);
        this.unbindFramebuffer();
    }
}
