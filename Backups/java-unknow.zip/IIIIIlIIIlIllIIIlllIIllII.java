import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIIlIllIIIlllIIllII extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "say";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 1;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.say.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length > 0 && array[0].length() > 0) {
            llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("chat.type.announcement", new Object[] { lIlllllIIIIIIllIlIIlIlIII.IlIlIIIlllllIIIlIlIlIllII(), IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array, 0, true) }));
            return;
        }
        throw new IIllllIlIlIIlllIlIIllIIll("commands.say.usage", new Object[0]);
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length >= 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl()) : null;
    }
}
