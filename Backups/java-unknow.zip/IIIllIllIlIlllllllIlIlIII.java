import javax.sound.sampled.Control;
import javax.sound.sampled.FloatControl;
import javazoom.jl.decoder.JavaLayerException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Line;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javazoom.jl.decoder.Decoder;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.SourceDataLine;
import javazoom.jl.player.AudioDeviceBase;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIllIlIlllllllIlIlIII extends AudioDeviceBase
{
    private SourceDataLine lIIIIlIIllIIlIIlIIIlIIllI;
    private AudioFormat lIIIIIIIIIlIllIIllIlIIlIl;
    private byte[] IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIllIllIlIlllllllIlIlIII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IlllIIIlIlllIllIlIIlllIlI = new byte[4096];
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final AudioFormat liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    protected AudioFormat lIIIIlIIllIIlIIlIIIlIIllI() {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl == null) {
            final Decoder decoder = this.getDecoder();
            this.lIIIIIIIIIlIllIIllIlIIlIl = new AudioFormat((float)decoder.getOutputFrequency(), 16, decoder.getOutputChannels(), true, false);
        }
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    protected DataLine.Info lIIIIIIIIIlIllIIllIlIIlIl() {
        return new DataLine.Info(SourceDataLine.class, this.lIIIIlIIllIIlIIlIIIlIIllI());
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final AudioFormat audioFormat) {
        if (!this.isOpen()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(audioFormat);
            this.openImpl();
            this.setOpen(true);
        }
    }
    
    protected void openImpl() {
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI() {
        Throwable t = null;
        try {
            final Line line = AudioSystem.getLine(this.lIIIIIIIIIlIllIIllIlIIlIl());
            if (line instanceof SourceDataLine) {
                (this.lIIIIlIIllIIlIIlIIIlIIllI = (SourceDataLine)line).open(this.lIIIIIIIIIlIllIIllIlIIlIl);
                this.lIIIIlIIllIIlIIlIIIlIIllI.start();
                this.lIIIIlIIllIIlIIlIIIlIIllI((float)(int)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIlIIllllIIllllllIlIIIll.IIIIllIlIIIllIlllIlllllIl());
            }
        }
        catch (RuntimeException ex) {
            t = ex;
        }
        catch (LinkageError linkageError) {
            t = linkageError;
        }
        catch (LineUnavailableException ex2) {
            t = ex2;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == null) {
            throw new JavaLayerException("cannot obtain source audio line", (Throwable)t);
        }
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final AudioFormat audioFormat, final int n) {
        return (int)(n * audioFormat.getSampleRate() * audioFormat.getChannels() * audioFormat.getSampleSizeInBits() / (double)8000);
    }
    
    protected void closeImpl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.close();
        }
    }
    
    protected void writeImpl(final short[] array, final int n, final int n2) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI();
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.write(this.lIIIIlIIllIIlIIlIIIlIIllI(array, n, n2), 0, n2 * 2);
    }
    
    protected byte[] lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (this.IlllIIIlIlllIllIlIIlllIlI.length < n) {
            this.IlllIIIlIlllIllIlIIlllIlI = new byte[n + 1024];
        }
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    protected byte[] lIIIIlIIllIIlIIlIIIlIIllI(final short[] array, int n, int n2) {
        final byte[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(n2 * 2);
        int n3 = 0;
        while (n2-- > 0) {
            final short n4 = array[n++];
            liiiIlIIllIIlIIlIIIlIIllI[n3++] = (byte)n4;
            liiiIlIIllIIlIIlIIIlIIllI[n3++] = (byte)(n4 >>> 8);
        }
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    protected void flushImpl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.drain();
        }
    }
    
    public int getPosition() {
        int n = 0;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            n = (int)(this.lIIIIlIIllIIlIIlIIIlIIllI.getMicrosecondPosition() / 1000L);
        }
        return n;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        try {
            this.lIIIIIIIIIlIllIIllIlIIlIl(new AudioFormat(22050, 16, 1, true, false));
            final short[] array = new short[2205];
            this.write(array, 0, array.length);
            this.flush();
            this.close();
        }
        catch (RuntimeException obj) {
            throw new JavaLayerException("Device test failed: " + obj);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            final FloatControl floatControl = (FloatControl)this.lIIIIlIIllIIlIIlIIIlIIllI.getControl(FloatControl.Type.MASTER_GAIN);
            float value = (floatControl.getMaximum() - floatControl.getMinimum()) * (n / 100) + floatControl.getMinimum();
            if (n <= 58) {
                value = -80;
            }
            floatControl.setValue(value);
        }
    }
}
