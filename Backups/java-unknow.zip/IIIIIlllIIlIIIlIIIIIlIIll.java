import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIIlllIIlIIIlIIIIIlIIll implements Callable
{
    final /* synthetic */ IIlllllllIlllIIllllIIlIll lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ IIIIIIllIlIIIIlIlllIllllI lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIIIlllIIlIIIlIIIIIlIIll(final IIIIIIllIlIIIIlIlllIllllI liiiiiiiiIlIllIIllIlIIlIl, final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        try {
            return String.format("ID #%d (%s // %s)", IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI), this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll(), this.lIIIIlIIllIIlIIlIIIlIIllI.getClass().getCanonicalName());
        }
        catch (Throwable t) {
            return "ID #" + IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
    }
}
