import com.mojang.authlib.GameProfile;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllllIllIIlIlllIIllIl extends IIlllIIIIIIlllIllIlIlIlII
{
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private double IIIIllIIllIIIIllIllIIIlIl;
    private double IlIlIIIlllIIIlIlllIlIllIl;
    private double IIIllIllIlIlllllllIlIlIII;
    private double IllIIIIIIIlIlIllllIIllIII;
    
    public IIIlIllllIllIIlIlllIIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final GameProfile gameProfile) {
        super(iiiiiIllIlIIIIlIlllIllllI, gameProfile);
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        this.lIIllIIllllllIIlllIlllIIl = 0.0f;
        this.lllIIllllIIlIlIlIlIIIlIII = true;
        this.llllIlIIIIIllIIlIlllIllll = 0.22972974f * 1.0882353f;
        this.lIIIIIllllIIIIlIlIIIIlIlI = 10;
    }
    
    @Override
    protected void j_() {
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        return true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double iiiIllIlIIIllIlllIlllllIl, final double iiiIllIIllIIIIllIllIIIlIl, final double ilIlIIIlllIIIlIlllIlIllIl, final float n, final float n2, final int illlIIIlIlllIllIlIIlllIlI) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIllIllIlIlllllllIlIlIII = n;
        this.IllIIIIIIIlIlIllllIIllIII = n2;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void x_() {
        this.llllIlIIIIIllIIlIlllIllll = 0.0f;
        super.x_();
        this.IIllIllIlIIlllllIlIIIlIll = this.IlIlIIIlllIlIllIlIIIlllIl;
        final double n = this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl;
        final double n2 = this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII;
        float n3 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n2 * n2) * 4;
        if (n3 > 1.0f) {
            n3 = 1.0f;
        }
        this.IlIlIIIlllIlIllIlIIIlllIl += (n3 - this.IlIlIIIlllIlIllIlIIIlllIl) * (2.16f * 0.18518518f);
        this.llIIlllIlIIlIIIIIlIllllll += this.IlIlIIIlllIlIllIlIIIlllIl;
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl && this.IIlIlllllIIIlIIllIllIlIlI() && this.inventory.lIIIIlIIllIIlIIlIIIlIIllI[this.inventory.currentItem] != null) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.inventory.lIIIIlIIllIIlIIlIIIlIIllI[this.inventory.currentItem];
            this.IlllIIIlIlllIllIlIIlllIlI(this.inventory.lIIIIlIIllIIlIIlIIIlIIllI[this.inventory.currentItem], lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().IlIlIIIlllIIIlIlllIlIllIl(lIlIlIlIlIllllIlllIIIlIlI));
            this.lIIIIIIIIIlIllIIllIlIIlIl = true;
        }
        else if (this.lIIIIIIIIIlIllIIllIlIIlIl && !this.IIlIlllllIIIlIIllIllIlIlI()) {
            this.lIIIlIlIIllIIlllIIIlIIllI();
            this.lIIIIIIIIIlIllIIllIlIIlIl = false;
        }
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    @Override
    public void i_() {
        super.IllIlIIIIlllIIllIIlllIIlI();
        if (this.IlllIIIlIlllIllIlIIlllIlI > 0) {
            final double n = this.IIIlIIlIlIIIlllIIlIllllll + (this.IIIIllIlIIIllIlllIlllllIl - this.IIIlIIlIlIIIlllIIlIllllll) / this.IlllIIIlIlllIllIlIIlllIlI;
            final double n2 = this.IllIlIIIIlllIIllIIlllIIlI + (this.IIIIllIIllIIIIllIllIIIlIl - this.IllIlIIIIlllIIllIIlllIIlI) / this.IlllIIIlIlllIllIlIIlllIlI;
            final double n3 = this.IllIlIlIllllIlIIllllIIlll + (this.IlIlIIIlllIIIlIlllIlIllIl - this.IllIlIlIllllIlIIllllIIlll) / this.IlllIIIlIlllIllIlIIlllIlI;
            double n4;
            for (n4 = this.IIIllIllIlIlllllllIlIlIII - this.IllllIllllIlIIIlIIIllllll; n4 < -180; n4 += 360) {}
            while (n4 >= 180) {
                n4 -= 360;
            }
            this.IllllIllllIlIIIlIIIllllll += (float)(n4 / this.IlllIIIlIlllIllIlIIlllIlI);
            this.IllIIlllIllIlIllIlIIIIIII += (float)((this.IllIIIIIIIlIlIllllIIllIII - this.IllIIlllIllIlIllIlIIIIIII) / this.IlllIIIlIlllIllIlIIlllIlI);
            --this.IlllIIIlIlllIllIlIIlllIlI;
            this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
        }
        this.IllIIIIIIlIlIlllllllIIllI = this.IlIIlllIIlIlIIIlIlllllIll;
        float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl);
        float n5 = (float)Math.atan(-this.lIlIlIllIIIIIIIIllllIIllI * (0.36585365388274277 * 0.54666668176651)) * 15;
        if (liiiIlIIllIIlIIlIIIlIIllI > 0.07631579f * 1.3103448f) {
            liiiIlIIllIIlIIlIIIlIIllI = 0.10375f * 0.96385545f;
        }
        if (!this.lIIIIlllIIlIlllllIlIllIII || this.getHealth() <= 0.0f) {
            liiiIlIIllIIlIIlIIIlIIllI = 0.0f;
        }
        if (this.lIIIIlllIIlIlllllIlIllIII || this.getHealth() <= 0.0f) {
            n5 = 0.0f;
        }
        this.IlIIlllIIlIlIIIlIlllllIll += (liiiIlIIllIIlIIlIIIlIIllI - this.IlIIlllIIlIlIIIlIlllllIll) * (0.7764706f * 0.5151515f);
        this.IlIllIIllIIIIIllIlIIIIIIl += (n5 - this.IlIllIIllIIIIIllIlIIIIIIl) * (0.39272726f * 2.0370371f);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        if (n == 0) {
            this.inventory.lIIIIlIIllIIlIIlIIIlIIllI[this.inventory.currentItem] = lIlIlIlIlIllllIlllIIIlIlI;
        }
        else {
            this.inventory.lIIIIIIIIIlIllIIllIlIIlIl[n - 1] = lIlIlIlIlIllllIlllIIIlIlI;
        }
    }
    
    @Override
    public float lIIlIlIllIIlIIIlIIIlllIII() {
        return 3.6538463f * 0.49810526f;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIllIIlIIlIlllIIllIIIlI illIllIIlIIlIlllIIllIIIlI) {
        Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(illIllIIlIIlIlllIIllIIIlI);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final String s) {
        return false;
    }
    
    @Override
    public IlllIllllIIIIIlIlIlIIIllI IIIlllIIIllIllIlIIIIIIlII() {
        return new IlllIllllIIIIIlIlIlIIIllI(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll + 0.5104166615961327 * 0.9795918464660645), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI + 0.44776119084314664 * 1.1166666746139526), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll + 38.50000003585592 * 0.012987012974917889));
    }
}
