// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIlIIlIIlIlIIllIlIII extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private byte IIIIllIIllIIIIllIllIIIlIl;
    private byte IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIllIIIlIIlIIlIlIIllIlIII() {
    }
    
    public IIllIIIlIIlIIlIlIIllIlIII(final Entity entity) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = entity.lIIIIlllIIlIlllllIlIllIII();
        this.lIIIIIIIIIlIllIIllIlIIlIl = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll * 32);
        this.IlllIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIIIIlllIIllIIlllIIlI * 32);
        this.IIIIllIlIIIllIlllIlllllIl = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll * 32);
        this.IIIIllIIllIIIIllIllIIIlIl = (byte)(entity.IllllIllllIlIIIlIIIllllll * 256 / 360);
        this.IlIlIIIlllIIIlIlllIlIllIl = (byte)(entity.IllIIlllIllIlIllIlIIIIIII * 256 / 360);
    }
    
    public IIllIIIlIIlIIlIlIIllIlIII(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final byte iiiIllIIllIIIIllIllIIIlIl, final byte ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readInt();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readInt();
        this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.readInt();
        this.IIIIllIIllIIIIllIllIIIlIl = lIlIllllllllIlIIIllIIllII.readByte();
        this.IlIlIIIlllIIIlIlllIlIllIl = lIlIllllllllIlIIIllIIllII.readByte();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI);
        lIlIllllllllIlIIIllIIllII.writeInt(this.IIIIllIlIIIllIlllIlllllIl);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IIIIllIIllIIIIllIllIIIlIl);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public byte IIIllIllIlIlllllllIlIlIII() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public byte IllIIIIIIIlIlIllllIIllIII() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
