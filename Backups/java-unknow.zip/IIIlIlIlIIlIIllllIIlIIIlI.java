// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIlIIlIIllllIIlIIIlI extends Exception
{
    public IIIlIlIlIIlIIllllIIlIIIlI(final String message) {
        super(message);
    }
}
