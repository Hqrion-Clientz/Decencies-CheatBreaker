import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIlIIIllllIllIlIIII extends lIIlIllIIIlllllIllIlIlIlI
{
    private lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIlllIlIIIllllIllIlIIII(final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public IIlIlllIlIIIllllIllIlIIII(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII) {
        this(liIlllIIIlIllllllIlIlIIII, 0);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        final IlllIllIIIIlllIllIIIIIlII illlIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.IlIlIIIlllIIIlIlllIlIllIl);
        if (illlIIIlIlllIllIlIIlllIlI != null) {
            GL11.glPushMatrix();
            GL11.glTranslatef((float)n, (float)n2, (float)n3);
            GL11.glEnable(32826);
            GL11.glScalef(21.25f * 0.023529412f, 0.9285714f * 0.53846157f, 0.49107143f * 1.0181818f);
            this.lIIIIIIIIIlIllIIllIlIIlIl(entity);
            final Tessellator instance = Tessellator.instance;
            if (illlIIIlIlllIllIlIIlllIlI == lIIIIlIIIlIllIlllIIIIIIII.IIIIllIlIIIllIlllIlllllIl("bottle_splash")) {
                final int liiiIlIIllIIlIIlIIIlIIllI = IIlIllIIIlIIIIlIIIIllIllI.lIIIIlIIllIIlIIlIIIlIIllI(((IIlIIlIIIIIllIlIlIlIIIIIl)entity).IlIlIIIlllIIIlIlllIlIllIl(), false);
                GL11.glColor3f((liiiIlIIllIIlIIlIIIlIIllI >> 16 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI >> 8 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI & 0xFF) / (float)255);
                GL11.glPushMatrix();
                this.lIIIIlIIllIIlIIlIIIlIIllI(instance, lIIIIlIIIlIllIlllIIIIIIII.IIIIllIlIIIllIlllIlllllIl("overlay"));
                GL11.glPopMatrix();
                GL11.glColor3f(1.0f, 1.0f, 1.0f);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(instance, illlIIIlIlllIllIlIIlllIlI);
            GL11.glDisable(32826);
            GL11.glPopMatrix();
        }
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return TextureMap.locationItemsTexture;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final Tessellator tessellator, final IlllIllIIIIlllIllIIIIIlII illlIllIIIIlllIllIIIIIlII) {
        final float illlIIIlIlllIllIlIIlllIlI = illlIllIIIIlllIllIIIIIlII.IlllIIIlIlllIllIlIIlllIlI();
        final float iiiIllIlIIIllIlllIlllllIl = illlIllIIIIlllIllIIIIIlII.IIIIllIlIIIllIlllIlllllIl();
        final float iiiIllIIllIIIIllIllIIIlIl = illlIllIIIIlllIllIIIIIlII.IIIIllIIllIIIIllIllIIIlIl();
        final float ilIlIIIlllIIIlIlllIlIllIl = illlIllIIIIlllIllIIIIIlII.IlIlIIIlllIIIlIlllIlIllIl();
        final float n = 1.0f;
        final float n2 = 2.7692308f * 0.18055555f;
        final float n3 = 0.69827586f * 0.3580247f;
        GL11.glRotatef(180 - this.lIIIIIIIIIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlllIIIIllIllllIllIIlIl, 1.0f, 0.0f, 0.0f);
        tessellator.startDrawingQuads();
        tessellator.IlllIIIlIlllIllIlIIlllIlI(0.0f, 1.0f, 0.0f);
        tessellator.addVertexWithUV(0.0f - n2, 0.0f - n3, 0.0, illlIIIlIlllIllIlIIlllIlI, ilIlIIIlllIIIlIlllIlIllIl);
        tessellator.addVertexWithUV(n - n2, 0.0f - n3, 0.0, iiiIllIlIIIllIlllIlllllIl, ilIlIIIlllIIIlIlllIlIllIl);
        tessellator.addVertexWithUV(n - n2, n - n3, 0.0, iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl);
        tessellator.addVertexWithUV(0.0f - n2, n - n3, 0.0, illlIIIlIlllIllIlIIlllIlI, iiiIllIIllIIIIllIllIIIlIl);
        tessellator.draw();
    }
}
