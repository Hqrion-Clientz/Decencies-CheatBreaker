import java.util.Iterator;
import java.util.function.Consumer;
import org.lwjgl.opengl.GL11;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class CBAbstractGui extends GuiScreen
{
    private float IIIIllIlIIIllIlllIlllllIl;
    private float IIIIllIIllIIIIllIllIIIlIl;
    protected List lIIIIlIIllIIlIIlIIIlIIllI;
    protected List lIIIIIIIIIlIllIIllIlIIlIl;
    private ScaledResolution IlIlIIIlllIIIlIlllIlIllIl;
    protected int IlllIIIlIlllIllIlIIlllIlI;
    
    public CBAbstractGui() {
        this.IlllIIIlIlllIllIlIIlllIlI = 0;
    }
    
    @Override
    public void setWorldAndResolution(final Minecraft minecraft, final int liiiiIllllIIIIlIlIIIIlIlI, final int iiiiiIlIlIlIllllllIlllIlI) {
        this.lllIIIIIlIllIlIIIllllllII = minecraft;
        this.lIIlllIIlIlllllllllIIIIIl = minecraft.fontRendererObj;
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        this.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IlIlIIIlllIIIlIlllIlIllIl = new ScaledResolution(this.lllIIIIIlIllIlIIIllllllII, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
        final float iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl();
        this.IIIIllIlIIIllIlllIlllllIl = liiiiIllllIIIIlIlIIIIlIlI / iiiIllIIllIIIIllIllIIIlIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiiiIlIlIlIllllllIlllIlI / iiiIllIIllIIIIllIllIIIlIl;
        this.s_();
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final llllIIIIlIlIllIIIllllIIll... a) {
        (this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList()).addAll(Arrays.asList(a));
        this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.size();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final llllIIIIlIlIllIIIllllIIll... a) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.addAll(Arrays.asList(a));
        this.s_();
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final llllIIIIlIlIllIIIllllIIll... a) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.removeAll(Arrays.asList(a));
        this.s_();
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl(final llllIIIIlIlIllIIIllllIIll... a) {
        (this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList()).addAll(Arrays.asList(a));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        final float iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl();
        GL11.glPushMatrix();
        GL11.glScalef(iiiIllIIllIIIIllIllIIIlIl, iiiIllIIllIIIIllIllIIIlIl, iiiIllIIllIIIIllIllIIIlIl);
        this.setProgress(n / iiiIllIIllIIIIllIllIIIlIl, n2 / iiiIllIIllIIIIllIllIIIlIl);
        GL11.glPopMatrix();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        final float iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(n / iiiIllIIllIIIIllIllIIIlIl, n2 / iiiIllIIllIIIIllIllIIIlIl, n3);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        final float iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl();
        this.lIIIIIIIIIlIllIIllIlIIlIl(n / iiiIllIIllIIIIllIllIIIlIl, n2 / iiiIllIIllIIIIllIllIIIlIl, n3);
    }
    
    public abstract void setProgress(final float p0, final float p1) throws Exception;
    
    protected abstract void lIIIIlIIllIIlIIlIIIlIIllI(final float p0, final float p1, final int p2);
    
    public abstract void lIIIIIIIIIlIllIIllIlIIlIl(final float p0, final float p1, final int p2);
    
    public float IIIIllIIllIIIIllIllIIIlIl() {
        float n = 0.0f;
        switch (this.IlIlIIIlllIIIlIlllIlIllIl.getScaleFactor()) {
            case 1: {
                n = 0.5915493f * 0.84523815f;
                break;
            }
            case 2: {
                n = 1.0f;
                break;
            }
            case 3: {
                n = 0.5411765f * 2.771739f;
                break;
            }
            case 4: {
                n = 2.0f;
                break;
            }
            default: {
                n = 1.0f;
                break;
            }
        }
        return 1.0f / n;
    }
    
    public float IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public float IIIllIllIlIlllllllIlIlIII() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    protected void run() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.forEach(llllIIIIlIlIllIIIllllIIll::lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    protected void resetSize() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.forEach(llllIIIIlIlIllIIIllllIIll::lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final char c, final int n) {
        final Iterator<llllIIIIlIlIllIIIllllIIll> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI.iterator();
        while (iterator.hasNext()) {
            iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        }
    }
    
    protected void IlllIllIlIIIIlIIlIIllIIIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.forEach(llllIIIIlIlIllIIIllllIIll::IlllIIIlIlllIllIlIIlllIlI);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final llllIIIIlIlIllIIIllllIIll... a) {
        final List<llllIIIIlIlIllIIIllllIIll> list = Arrays.asList(a);
        for (final llllIIIIlIlIllIIIllllIIll llllIIIIlIlIllIIIllllIIll : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (list.contains(llllIIIIlIlIllIIIllllIIll)) {
                continue;
            }
            llllIIIIlIlIllIIIllllIIll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, this.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIIlIlIllIIIllllIIll, n, n2, new llllIIIIlIlIllIIIllllIIll[0]));
        }
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final float n, final float n2, final int n3) {
        for (final llllIIIIlIlIllIIIllllIIll llllIIIIlIlIllIIIllllIIll : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (llllIIIIlIlIllIIIllllIIll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2) && llllIIIIlIlIllIIIllllIIll.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, this.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIIlIlIllIIIllllIIll, n, n2, new llllIIIIlIlIllIIIllllIIll[0]))) {
                break;
            }
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final int n3, final llllIIIIlIlIllIIIllllIIll... a) {
        final List<llllIIIIlIlIllIIIllllIIll> list = Arrays.asList(a);
        Object o = null;
        boolean b = false;
        for (final llllIIIIlIlIllIIIllllIIll llllIIIIlIlIllIIIllllIIll : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (list.contains(llllIIIIlIlIllIIIllllIIll)) {
                continue;
            }
            if (!llllIIIIlIlIllIIIllllIIll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                continue;
            }
            if (!this.lIIIIIIIIIlIllIIllIlIIlIl.contains(llllIIIIlIlIllIIIllllIIll)) {
                o = llllIIIIlIlIllIIIllllIIll;
            }
            if (llllIIIIlIlIllIIIllllIIll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIIlIlIllIIIllllIIll, n, n2, a))) {
                b = true;
                break;
            }
        }
        if (b) {
            return;
        }
        if (o != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.lIIIIlIIllIIlIIlIIIlIIllI.remove(this.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(o)));
        }
        final Iterator iterator2 = this.lIIIIlIIllIIlIIlIIIlIIllI.iterator();
        while (iterator2.hasNext() && !iterator2.next().lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3)) {}
    }
    
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final llllIIIIlIlIllIIIllllIIll llllIIIIlIlIllIIIllllIIll, final float n, final float n2, final llllIIIIlIlIllIIIllllIIll... a) {
        final List<llllIIIIlIlIllIIIllllIIll> list = Arrays.asList(a);
        boolean b = true;
        for (int i = this.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1; i >= 0; --i) {
            final llllIIIIlIlIllIIIllllIIll llllIIIIlIlIllIIIllllIIll2 = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
            if (llllIIIIlIlIllIIIllllIIll2 == llllIIIIlIlIllIIIllllIIll) {
                break;
            }
            if (!list.contains(llllIIIIlIlIllIIIllllIIll2)) {
                if (llllIIIIlIlIllIIIllllIIll2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                    b = false;
                    break;
                }
            }
        }
        return b;
    }
    
    public List IlIlllIIIIllIllllIllIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public ScaledResolution llIIlllIIIIlllIllIlIlllIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final ScaledResolution ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
}
