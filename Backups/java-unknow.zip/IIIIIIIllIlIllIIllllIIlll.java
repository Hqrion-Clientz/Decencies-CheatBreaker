import java.io.DataInput;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIllIlIllIIllllIIlll extends IlIIllIlIIIlIllllllIlIlII
{
    private long lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIIIIIllIlIllIIllllIIlll() {
    }
    
    public IIIIIIIllIlIllIIllllIIlll(final long liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataOutput dataOutput) {
        dataOutput.writeLong(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataInput dataInput, final int n, final llllIlIIllllIllIlllllllll llllIlIIllllIllIlllllllll) {
        llllIlIIllllIllIlllllllll.lIIIIlIIllIIlIIlIIIlIIllI(64L);
        this.lIIIIIIIIIlIllIIllIlIIlIl = dataInput.readLong();
    }
    
    @Override
    public byte lIIIIlIIllIIlIIlIIIlIIllI() {
        return 4;
    }
    
    @Override
    public String toString() {
        return "" + this.lIIIIIIIIIlIllIIllIlIIlIl + "L";
    }
    
    @Override
    public lIllIIIIIlIIllIIIIlIIllII lIIIIIIIIIlIllIIllIlIIlIl() {
        return new IIIIIIIllIlIllIIllllIIlll(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    public boolean equals(final Object o) {
        return super.equals(o) && this.lIIIIIIIIIlIllIIllIlIIlIl == ((IIIIIIIllIlIllIIllllIIlll)o).lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public int hashCode() {
        return super.hashCode() ^ (int)(this.lIIIIIIIIIlIllIIllIlIIlIl ^ this.lIIIIIIIIIlIllIIllIlIIlIl >>> 32);
    }
    
    @Override
    public long IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return (int)(this.lIIIIIIIIIlIllIIllIlIIlIl & -1L);
    }
    
    @Override
    public short IlIlIIIlllIIIlIlllIlIllIl() {
        return (short)(this.lIIIIIIIIIlIllIIllIlIIlIl & 0xFFFFL);
    }
    
    @Override
    public byte IIIllIllIlIlllllllIlIlIII() {
        return (byte)(this.lIIIIIIIIIlIllIIllIlIIlIl & 0xFFL);
    }
    
    @Override
    public double IllIIIIIIIlIlIllllIIllIII() {
        return (double)this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public float lIIIIllIIlIlIllIIIlIllIlI() {
        return (float)this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
