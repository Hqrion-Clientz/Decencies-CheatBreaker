import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIllIIIlIllllIIIIIIIlIlll implements Callable
{
    final /* synthetic */ Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIllIIIlIllllIIIIIIIlIlll(final Minecraft liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.currentScreen.getClass().getCanonicalName();
    }
}
