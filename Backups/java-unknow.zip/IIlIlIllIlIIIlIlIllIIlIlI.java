import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllIlIIIlIlIllIIlIlI extends lllllIIIIllIIlIlIlIIllllI
{
    public IIlIlIllIlIIIlIlIllIIlIlI() {
    }
    
    public IIlIlIllIlIIIlIlIllIIlIlI(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIlIIllIIlIIlIIIlIIllI(random);
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl != 2 && this.IlIlIIIlllIIIlIlllIlIllIl != 3) {
            this.IlllIIIlIlllIllIlIIlllIlI((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, 1, 1);
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, 1, 1);
        }
    }
    
    public static IIlIlIllIlIIIlIlIllIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -1, -1, 0, 5, 5, 5, n4);
        return (lllllIIIIllIIlIlIlIIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIlIlIllIlIIIlIlIllIIlIlI(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl)) {
            return false;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 4, 4, 4, true, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, iiIllllIIllllIIIIIlllllIl, this.IIIIllIlIIIllIlllIlllllIl, 1, 1, 0);
        if (this.IlIlIIIlllIIIlIlllIlIllIl != 2 && this.IlIlIIIlllIIIlIlllIlIllIl != 3) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 1, 1, 4, 3, 3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 1, 1, 0, 3, 3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        return true;
    }
}
