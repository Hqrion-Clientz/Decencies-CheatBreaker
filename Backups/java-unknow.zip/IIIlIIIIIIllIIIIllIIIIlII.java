import org.lwjgl.input.Keyboard;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIIIllIIIIllIIIIlII extends GuiScreen
{
    private final GuiScreen lIIIIlIIllIIlIIlIIIlIIllI;
    private final ServerData lIIIIIIIIIlIllIIllIlIIlIl;
    private IIIIIllIIlIlIlIIlIlIlIllI IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIIIIIIllIIIIllIIIIlII(final GuiScreen liiiIlIIllIIlIIlIIIlIIllI, final ServerData liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void updateScreen() {
        this.IlllIIIlIlllIllIlIIlllIlI.updateTick();
    }
    
    @Override
    public void s_() {
        Keyboard.enableRepeatEvents(true);
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectServer.select", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 120 + 12, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.cancel", new Object[0])));
        (this.IlllIIIlIlllIllIlIIlllIlI = new IIIIIllIIlIlIlIIlIlIlIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, 116, 200, 20)).IlIlIIIlllIIIlIlllIlIllIl(128);
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IlllIIIlIlllIllIlIIlllIlI.setSection(this.lllIIIIIlIllIlIIIllllllII.gameSettings.llIlllIIllIlllIlIlIlIIIll);
        this.IllIllIIIlIIlllIIIllIllII.get(0).IlllIllIlIIIIlIIlIIllIIIl = (this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl().length() > 0 && this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl().split(":").length > 0);
    }
    
    @Override
    public void t_() {
        Keyboard.enableRepeatEvents(false);
        this.lllIIIIIlIllIlIIIllllllII.gameSettings.llIlllIIllIlllIlIlIlIIIll = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        this.lllIIIIIlIllIlIIIllllllII.gameSettings.saveOptions();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(false, 0);
            }
            else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl();
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true, 0);
            }
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        if (this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(c, n)) {
            this.IllIllIIIlIIlllIIIllIllII.get(0).IlllIllIlIIIIlIIlIIllIIIl = (this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl().length() > 0 && this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl().split(":").length > 0);
        }
        else if (n == 28 || n == 156) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIllIIIlIIlllIIIllIllII.get(0));
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectServer.direct", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 20, 16777215);
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("addServer.enterIp", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, 100, 10526880);
        this.IlllIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl();
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
}
