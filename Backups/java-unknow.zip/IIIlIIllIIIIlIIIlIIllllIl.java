import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIIllIIIIlIIIlIIllllIl implements Comparator
{
    final /* synthetic */ lIllIIllllllllllIIIllIlIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIIllIIIIlIIIlIIllllIl(final lIllIIllllllllllIIIllIlIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIllIlllIIllIllllIIIlIllI lIllIlllIIllIllllIIIlIllI, final lIllIlllIIllIllllIIIlIllI lIllIlllIIllIllllIIIlIllI2) {
        return (lIllIlllIIllIllllIIIlIllI instanceof lIlIlllIIIlIIIlIlllIIIlII && lIllIlllIIllIllllIIIlIllI2 instanceof IlIlllIllIIIIIIIlllIlIlII) ? 1 : ((lIllIlllIIllIllllIIIlIllI2 instanceof lIlIlllIIIlIIIlIlllIIIlII && lIllIlllIIllIllllIIIlIllI instanceof IlIlllIllIIIIIIIlllIlIlII) ? -1 : ((lIllIlllIIllIllllIIIlIllI2.lIIIIlIIllIIlIIlIIIlIIllI() < lIllIlllIIllIllllIIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI()) ? -1 : ((lIllIlllIIllIllllIIIlIllI2.lIIIIlIIllIIlIIlIIIlIIllI() > lIllIlllIIllIllllIIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI()) ? 1 : 0)));
    }
    
    @Override
    public int compare(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((lIllIlllIIllIllllIIIlIllI)o, (lIllIlllIIllIllllIIIlIllI)o2);
    }
}
