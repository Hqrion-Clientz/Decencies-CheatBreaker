// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIlllIIlIlIIIllIlIl
{
    private int[] lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private boolean IIIllIllIlIlllllllIlIlIII;
    
    public IIlIIIIIlllIIlIlIIIllIlIl(final int[] liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final boolean iiiIllIlIIIllIlllIlllllIl, final boolean iiiIllIIllIIIIllIllIIIlIl, final boolean ilIlIIIlllIIIlIlllIlIllIl, final boolean iiIllIllIlIlllllllIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
    
    public int[] lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIIlllIIlIlIIIllIlIl ilIIIIIlllIIlIlIIIllIlIl) {
        if (ilIIIIIlllIIlIlIIIllIlIl != null) {
            if (ilIIIIIlllIIlIlIIIllIlIl.IIIIllIIllIIIIllIllIIIlIl != this.IIIIllIIllIIIIllIllIIIlIl || ilIIIIIlllIIlIlIIIllIlIl.IIIllIllIlIlllllllIlIlIII != this.IIIllIllIlIlllllllIlIlIII || ilIIIIIlllIIlIlIIIllIlIl.IlIlIIIlllIIIlIlllIlIllIl != this.IlIlIIIlllIIIlIlllIlIllIl || ilIIIIIlllIIlIlIIIllIlIl.IIIIllIlIIIllIlllIlllllIl != this.IIIIllIlIIIllIlllIlllllIl) {
                throw new IllegalArgumentException("Incompatible vertex states");
            }
            final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl + ilIIIIIlllIIlIlIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl;
            final int[] liiiIlIIllIIlIIlIIIlIIllI = new int[liiiiiiiiIlIllIIllIlIIlIl];
            System.arraycopy(this.lIIIIlIIllIIlIIlIIIlIIllI, 0, liiiIlIIllIIlIIlIIIlIIllI, 0, this.lIIIIIIIIIlIllIIllIlIIlIl);
            System.arraycopy(ilIIIIIlllIIlIlIIIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI, 0, liiiIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, ilIIIIIlllIIlIlIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
            this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
            this.IlllIIIlIlllIllIlIIlllIlI += ilIIIIIlllIIlIlIIIllIlIl.IlllIIIlIlllIllIlIIlllIlI;
        }
    }
}
