import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIIlIllIIllIllIIlll extends IIllIIlIllIllIllIIIIIlIII implements IlllllIIIlIlllllIIlIlllIl
{
    public static final String[] lIIIIlllIIlIlllllIlIllIII;
    private static final IlllIllIIIIlllIllIIIIIlII[] lIIIlllIlIlllIIIIIIIIIlII;
    
    protected IIlIlllIIlIllIIllIllIIlll() {
        final float n = 0.09411765f * 4.25f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(2.3947368f * 0.20879121f - n, 0.0f, 0.12295082f * 4.0666666f - n, 18.5f * 0.027027028f + n, n * 2.0f, 0.65217394f * 0.76666665f + n);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
            if (iiiiiIllIlIIIIlIlllIllllI.IlllIllIlIIIIlIIlIIllIIIl(n, n2 + 1, n3) >= 9 && random.nextInt(7) == 0) {
                this.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
            }
        }
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, int n2) {
        n2 &= 0x7;
        return IIlIlllIIlIllIIllIllIIlll.lIIIlllIlIlllIIIIIIIIIlII[MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2, 0, 5)];
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        if ((illlIIIlIlllIllIlIIlllIlI & 0x8) == 0x0) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlIIIlIlllIllIlIIlllIlI | 0x8, 4);
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        final int n4 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x7;
        lIIllllIIlIIlllIlIIllIIIl liIllllIIlIIlllIlIIllIIIl = (random.nextInt(10) == 0) ? new llllIlIlIIlllIIIllIIIIIlI(true) : new IlIllIlllllllIIIIIIlllIll(true);
        int i = 0;
        int j = 0;
        int n5 = 0;
        switch (n4) {
            case 1: {
            Label_0230:
                for (i = 0; i >= -1; --i) {
                    for (j = 0; j >= -1; --j) {
                        if (this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j, 1) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j, 1) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j + 1, 1) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j + 1, 1)) {
                            liIllllIIlIIlllIlIIllIIIl = new IllllIIIllIlIIlIllIlIIIll(false, random.nextBoolean());
                            n5 = 1;
                            break Label_0230;
                        }
                    }
                }
                if (n5 == 0) {
                    j = 0;
                    i = 0;
                    liIllllIIlIIlllIlIIllIIIl = new IIllIIIIIlllIIIlIIIlllIlI(true);
                    break;
                }
                break;
            }
            case 2: {
                liIllllIIlIIlllIlIIllIIIl = new lIIlIlIIIIlIlIlIlllllIllI(true, false);
                break;
            }
            case 3: {
            Label_0404:
                for (i = 0; i >= -1; --i) {
                    for (j = 0; j >= -1; --j) {
                        if (this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j, 3) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j, 3) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j + 1, 3) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j + 1, 3)) {
                            liIllllIIlIIlllIlIIllIIIl = new IllllllllllIIlIIlIlllIIII(true, 10, 20, 3, 3);
                            n5 = 1;
                            break Label_0404;
                        }
                    }
                }
                if (n5 == 0) {
                    j = 0;
                    i = 0;
                    liIllllIIlIIlllIlIIllIIIl = new IlIllIlllllllIIIIIIlllIll(true, 4 + random.nextInt(7), 3, 3, false);
                    break;
                }
                break;
            }
            case 4: {
                liIllllIIlIIlllIlIIllIIIl = new lIIIIIIIlIlIllIlIlIIlIlIl(true);
                break;
            }
            case 5: {
            Label_0583:
                for (i = 0; i >= -1; --i) {
                    for (j = 0; j >= -1; --j) {
                        if (this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j, 5) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j, 5) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i, n2, n3 + j + 1, 5) && this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + i + 1, n2, n3 + j + 1, 5)) {
                            liIllllIIlIIlllIlIIllIIIl = new IIIllllIlllIlIlIlIIlIlIll(true);
                            n5 = 1;
                            break Label_0583;
                        }
                    }
                }
                if (n5 == 0) {
                    return;
                }
                break;
            }
        }
        final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI = IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI;
        if (n5 != 0) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i, n2, n3 + j, liiiIlIIllIIlIIlIIIlIIllI, 0, 4);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i + 1, n2, n3 + j, liiiIlIIllIIlIIlIIIlIIllI, 0, 4);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i, n2, n3 + j + 1, liiiIlIIllIIlIIlIIIlIIllI, 0, 4);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i + 1, n2, n3 + j + 1, liiiIlIIllIIlIIlIIIlIIllI, 0, 4);
        }
        else {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, liiiIlIIllIIlIIlIIIlIIllI, 0, 4);
        }
        if (!liIllllIIlIIlllIlIIllIIIl.a_(iiiiiIllIlIIIIlIlllIllllI, random, n + i, n2, n3 + j)) {
            if (n5 != 0) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i, n2, n3 + j, this, n4, 4);
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i + 1, n2, n3 + j, this, n4, 4);
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i, n2, n3 + j + 1, this, n4, 4);
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + i + 1, n2, n3 + j + 1, this, n4, 4);
            }
            else {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this, n4, 4);
            }
        }
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        return iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == this && (iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x7) == n4;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n & 0x7, 0, 5);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final IIllllIllIIllIIllIlIIIIII illllIllIIllIIllIlIIIIII, final List list) {
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 0));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 1));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 2));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 3));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 4));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 5));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        for (int i = 0; i < IIlIlllIIlIllIIllIllIIlll.lIIIlllIlIlllIIIIIIIIIlII.length; ++i) {
            IIlIlllIIlIllIIllIllIIlll.lIIIlllIlIlllIIIIIIIIIlII[i] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_" + IIlIlllIIlIllIIllIllIIlll.lIIIIlllIIlIlllllIlIllIII[i]);
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b) {
        return true;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        return iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() < 0.27941176295280457 * 1.6105263258941946;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
    }
    
    static {
        lIIIIlllIIlIlllllIlIllIII = new String[] { "oak", "spruce", "birch", "jungle", "acacia", "roofed_oak" };
        lIIIlllIlIlllIIIIIIIIIlII = new IlllIllIIIIlllIllIIIIIlII[IIlIlllIIlIllIIllIllIIlll.lIIIIlllIIlIlllllIlIllIII.length];
    }
}
