import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.Instant;
import com.google.gson.JsonElement;
import java.util.Map;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import com.google.gson.JsonParser;
import java.time.format.DateTimeFormatter;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllllIIIlIIIIIIIIIIII extends Thread
{
    private final lIlllllIlIllllIIIllllllII lIIIIlIIllIIlIIlIIIlIIllI;
    private final DateTimeFormatter lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIlllllIIIlIIIIIIIIIIII(final lIlllllIlIllllIIIllllllII liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void run() {
        try {
            for (final Map.Entry<String, V> entry : new JsonParser().parse("{\"Names\": " + new BufferedReader(new InputStreamReader(new URL("https://api.mojang.com/user/profiles/" + this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI().IlllIIIlIlllIllIlIIlllIlI().replaceAll("-", "") + "/names").openConnection().getInputStream())).readLine() + "}").getAsJsonObject().entrySet()) {
                if (entry.getKey().equalsIgnoreCase("Names")) {
                    for (final JsonElement jsonElement : ((JsonElement)entry.getValue()).getAsJsonArray()) {
                        final String asString = jsonElement.getAsJsonObject().get("name").getAsString();
                        if (jsonElement.getAsJsonObject().has("changedToAt")) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl().add(IlIllllIIlIIllIlIlllllIlI.IllIIIIIIIlIlIllllIIllIII + LocalDateTime.ofInstant(Instant.ofEpochMilli(jsonElement.getAsJsonObject().get("changedToAt").getAsLong()), ZoneId.systemDefault()).format(this.lIIIIIIIIIlIllIIllIlIIlIl) + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII + " " + asString);
                        }
                        else {
                            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl().add(asString);
                        }
                    }
                }
            }
            Collections.reverse(this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl());
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(), this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(), this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(), this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII() + this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl().size() * 10 - 10);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
