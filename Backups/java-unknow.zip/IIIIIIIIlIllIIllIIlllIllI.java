// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIlIllIIllIIlllIllI extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "kill";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 0;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.kill.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        IlIIIllllllIllIlllllIIllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII).lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIllIIlIlIllIIIlIllIlI, 2.9615386f * 1.1490053E38f);
        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.kill.success", new Object[0]));
    }
}
