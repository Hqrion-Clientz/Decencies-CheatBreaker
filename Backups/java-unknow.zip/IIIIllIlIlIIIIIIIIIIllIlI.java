// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIlIlIIIIIIIIIIllIlI extends lllIIllIlIIlIIlllllIIIllI
{
    protected IIIIllIlIlIIIIIIIIIIllIlI(final int n, final int n2) {
        super(n, n2, lIIIlIIIlIllIlllIIIIIlIlI.IllIIIIIIIlIlIllllIIllIII);
        this.lIIIIlIIllIIlIIlIIIlIIllI("digging");
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return 1 + 10 * (n - 1);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(n) + 50;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 5;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIllIIIIlIIllIIIIIIIlll || super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI);
    }
}
