// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIllllIIIIIlllllIllIl extends lIIIlIIllIlIlIIIlllllllIl
{
    public IIllIIllllIIIIIlllllIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIllIIllllIIIIIlllllIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIllIIllllllIIlllIlllIIl), 1, 0.0f);
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return 27;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 1;
    }
    
    @Override
    public IIlllllllIlllIIllllIIlIll IIIIllIlIIIllIlllIlllllIl() {
        return IllllllIllIIlllIllIIlIIll.lIIllIIllllllIIlllIlllIIl;
    }
    
    @Override
    public int IllIllIIIlIIlllIIIllIllII() {
        return 8;
    }
}
