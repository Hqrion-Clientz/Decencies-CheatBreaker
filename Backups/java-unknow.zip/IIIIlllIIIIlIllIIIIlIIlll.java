// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIIIIlIllIIIIlIIlll extends llllIIlIIIIlIIllIIIlllIIl
{
    public IIIIlllIIIIlIllIIIIlIIlll(final long n, final llllIIlIIIIlIIllIIIlllIIl liiiIlIIllIIlIIlIIIlIIllI) {
        super(n);
        super.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int[] lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        final int n5 = n - 1;
        final int n6 = n2 - 1;
        final int n7 = n3 + 2;
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n5, n6, n7, n4 + 2);
        final int[] liiiIlIIllIIlIIlIIIlIIllI2 = lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 * n4);
        for (int i = 0; i < n4; ++i) {
            for (int j = 0; j < n3; ++j) {
                final int illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI[j + 0 + (i + 1) * n7]);
                final int illlIIIlIlllIllIlIIlllIlI2 = this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI[j + 2 + (i + 1) * n7]);
                final int illlIIIlIlllIllIlIIlllIlI3 = this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 0) * n7]);
                final int illlIIIlIlllIllIlIIlllIlI4 = this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 2) * n7]);
                final int illlIIIlIlllIllIlIIlllIlI5 = this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 1) * n7]);
                if (illlIIIlIlllIllIlIIlllIlI5 == illlIIIlIlllIllIlIIlllIlI && illlIIIlIlllIllIlIIlllIlI5 == illlIIIlIlllIllIlIIlllIlI3 && illlIIIlIlllIllIlIIlllIlI5 == illlIIIlIlllIllIlIIlllIlI2 && illlIIIlIlllIllIlIIlllIlI5 == illlIIIlIlllIllIlIIlllIlI4) {
                    liiiIlIIllIIlIIlIIIlIIllI2[j + i * n3] = -1;
                }
                else {
                    liiiIlIIllIIlIIlIIIlIIllI2[j + i * n3] = IIlIIlIIllIIllIlIIIIIIIlI.lIIlIIllIIIIIlIllIIIIllII.IlIllIllIllIllIllllIIIlII;
                }
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI2;
    }
    
    private int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return (n >= 2) ? (2 + (n & 0x1)) : n;
    }
}
