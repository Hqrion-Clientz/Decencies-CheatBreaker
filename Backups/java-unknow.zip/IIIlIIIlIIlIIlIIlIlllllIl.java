import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIIIlIIlIIlIIlIlllllIl implements Callable
{
    final /* synthetic */ CrashReport lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIIIlIIlIIlIIlIlllllIl(final CrashReport liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return System.getProperty("java.version") + ", " + System.getProperty("java.vendor");
    }
}
