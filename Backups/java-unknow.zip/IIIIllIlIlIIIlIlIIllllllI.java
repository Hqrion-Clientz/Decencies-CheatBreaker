import java.util.Iterator;
import org.apache.commons.lang3.ArrayUtils;
import com.cheatbreaker.client.network.messages.Message;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIlIlIIIlIlIIllllllI
{
    public KeyBinding lIIIIlIIllIIlIIlIIIlIIllI;
    public KeyBinding lIIIIIIIIIlIllIIllIlIIlIl;
    public KeyBinding IlllIIIlIlllIllIlIIlllIlI;
    public KeyBinding IIIIllIlIIIllIlllIlllllIl;
    public KeyBinding IIIIllIIllIIIIllIllIIIlIl;
    public final List IlIlIIIlllIIIlIlllIlIllIl;
    private List llllIIIIlIlIllIIIllllIIll;
    private List IIlIlIIlIIIlIlllllIIlIIlI;
    public boolean IIIllIllIlIlllllllIlIlIII;
    public String IllIIIIIIIlIlIllllIIllIII;
    public String lIIIIllIIlIlIllIIIlIllIlI;
    public String IlllIllIlIIIIlIIlIIllIIIl;
    public String IlIlllIIIIllIllllIllIIlIl;
    public String llIIlllIIIIlllIllIlIlllIl;
    public int lIIlIlIllIIlIIIlIIIlllIII;
    public boolean IIIlllIIIllIllIlIIIIIIlII;
    private lIIlIlllIIIIlIIIllIlIIIII lIIIlllIIIlIIIIIlIIIIIIII;
    public lIIlIlllIIIIlIIIllIlIIIII llIlIIIlIIIIlIlllIlIIIIll;
    public lIIlIlllIIIIlIIIllIlIIIII IIIlIIllllIIllllllIlIIIll;
    public lIIlIlllIIIIlIIIllIlIIIII lllIIIIIlIllIlIIIllllllII;
    public lIIlIlllIIIIlIIIllIlIIIII lIIIIIllllIIIIlIlIIIIlIlI;
    public lIIlIlllIIIIlIIIllIlIIIII IIIIIIlIlIlIllllllIlllIlI;
    public lIIlIlllIIIIlIIIllIlIIIII IllIllIIIlIIlllIIIllIllII;
    private lIIlIlllIIIIlIIIllIlIIIII lIIlIIIIIIIIllIIllIIlllIl;
    public lIIlIlllIIIIlIIIllIlIIIII IlIIlIIIIlIIIIllllIIlIllI;
    public lIIlIlllIIIIlIIIllIlIIIII lIIlIIllIIIIIlIllIIIIllII;
    public lIIlIlllIIIIlIIIllIlIIIII lIIlllIIlIlllllllllIIIIIl;
    public lIIlIlllIIIIlIIIllIlIIIII lIllIllIlIIllIllIlIlIIlIl;
    private lIIlIlllIIIIlIIIllIlIIIII IllllllIllllIIlllIllllllI;
    public lIIlIlllIIIIlIIIllIlIIIII llIlIIIllIIIIlllIlIIIIIlI;
    public lIIlIlllIIIIlIIIllIlIIIII lIllIlIlllIIlIIllIIlIIlII;
    public lIIlIlllIIIIlIIIllIlIIIII IIIlIIlIlIIIlllIIlIllllll;
    private lIIlIlllIIIIlIIIllIlIIIII lIlIlIIIlIIllllllllIIlllI;
    public lIIlIlllIIIIlIIIllIlIIIII IllIlIIIIlllIIllIIlllIIlI;
    public lIIlIlllIIIIlIIIllIlIIIII IllIlIlIllllIlIIllllIIlll;
    public lIIlIlllIIIIlIIIllIlIIIII IllIIlIIlllllIllIIIlllIII;
    public lIIlIlllIIIIlIIIllIlIIIII lIlIlIllIIIIIIIIllllIIllI;
    private lIIlIlllIIIIlIIIllIlIIIII IlIlllIllIlIllIlllIlllIll;
    public lIIlIlllIIIIlIIIllIlIIIII IlllIIlllIIIIllIIllllIlIl;
    public lIIlIlllIIIIlIIIllIlIIIII IllllIllllIlIIIlIIIllllll;
    public lIIlIlllIIIIlIIIllIlIIIII IllIIlllIllIlIllIlIIIIIII;
    public lIIlIlllIIIIlIIIllIlIIIII IlIlIIIlllllIIIlIlIlIllII;
    public lIIlIlllIIIIlIIIllIlIIIII IIlIIllIIIllllIIlllIllIIl;
    public lIIlIlllIIIIlIIIllIlIIIII lllIlIIllllIIIIlIllIlIIII;
    public lIIlIlllIIIIlIIIllIlIIIII lIIIIlllIIlIlllllIlIllIII;
    private lIIlIlllIIIIlIIIllIlIIIII llIIIllIIllllIlIlIlIlIIll;
    public lIIlIlllIIIIlIIIllIlIIIII lIIIlllIlIlllIIIIIIIIIlII;
    public lIIlIlllIIIIlIIIllIlIIIII IIIIlIIIlllllllllIlllIlll;
    public lIIlIlllIIIIlIIIllIlIIIII IlIllllIIIlIllllIIIIIllII;
    public lIIlIlllIIIIlIIIllIlIIIII IlIIIIllIIIIIlllIIlIIlllI;
    public lIIlIlllIIIIlIIIllIlIIIII llIlIlIllIlIIlIlllIllIIlI;
    public lIIlIlllIIIIlIIIllIlIIIII llIlIlIlllIlllllIIIllIIll;
    private lIIlIlllIIIIlIIIllIlIIIII IIIIIlIllIllIlIIllIIlIllI;
    public lIIlIlllIIIIlIIIllIlIIIII IIllIlIllIlIllIIlIllIlIII;
    public List lIlIllIlIlIIIllllIlIllIll;
    public List IlIIlIIlIllIIIIllIIllIlIl;
    
    public IIIIllIlIlIIIlIlIIllllllI() {
        this.IIIllIllIlIlllllllIlIlIII = false;
        this.IllIIIIIIIlIlIllllIIllIII = "https://cheatbreaker.com/crash-report-upload";
        this.lIIIIllIIlIlIllIIIlIllIlI = "https://cheatbreaker.com/debug-upload";
        this.IlllIllIlIIIIlIIlIIllIIIl = "https://cheatbreaker.com/api/cosmetic/";
        this.IlIlllIIIIllIllllIllIIlIl = "https://cheatbreaker.com/api/cosmetic/all";
        this.llIIlllIIIIlllIllIlIlllIl = "https://status.mojang.com/check";
        this.lIIlIlIllIIlIIIlIIIlllIII = 60;
        this.IIIlllIIIllIllIlIIIIIIlII = true;
        this.IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
        this.lIlIllIlIlIIIllllIlIllIll = new ArrayList();
        this.IlIIlIIlIllIIIIllIIllIlIl = new ArrayList();
        final String[] illIllIIIlIIlllIIIllIllII = CheatBreaker.IllIllIIIlIIlllIIIllIllII();
        this.lIIIlllIIIlIIIIIlIIIIIIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("Audio Settings");
        if (illIllIIIlIIlllIIIllIllII.length > 0) {
            this.llIlIIIlIIIIlIlllIlIIIIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Microphone").lIIIIIIIIIlIllIIllIlIIlIl(illIllIIIlIIlllIIIllIllII[0]).lIIIIlIIllIIlIIlIIIlIIllI((Object[])illIllIIIlIIlllIIIllIllII).lIIIIlIIllIIlIIlIIIlIIllI(s -> {
                try {
                    System.out.println("[CB] Updated audio device!");
                    Message.h(CheatBreaker.IIIIllIlIIIllIlllIlllllIl(s));
                }
                catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
                return;
            });
        }
        else {
            this.llIlIIIlIIIIlIlllIlIIIIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Microphone").lIIIIIIIIIlIllIIllIlIIlIl("Unknown").lIIIIlIIllIIlIIlIIIlIIllI((Object[])new String[] { "Unknown" }).lIIIIlIIllIIlIIlIIIlIIllI(s2 -> {
                try {
                    System.out.println("[CB] Updated audio device!");
                    Message.h(CheatBreaker.IIIIllIlIIIllIlllIlllllIl(s2));
                }
                catch (UnsatisfiedLinkError unsatisfiedLinkError2) {}
                return;
            });
        }
        this.IllIllIIIlIIlllIIIllIllII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Mute CheatBreaker sounds").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IIIIIIlIlIlIllllllIlllIlI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Pin Radio Player").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IIIlIIllllIIllllllIlIIIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Radio Volume").lIIIIlIIllIIlIIlIIIlIIllI(n -> {
            if (IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI()) {
                IIIllIIIlIIIlIlllllIIIlll.IIIIllIlIIIllIlllIlllllIl().lIIIIlIIllIIlIIlIIIlIIllI((float)n);
            }
            return;
        }).lIIIIIIIIIlIllIIllIlIIlIl(85).lIIIIlIIllIIlIIlIIIlIIllI((Object)55, 100);
        this.lllIIIIIlIllIlIIIllllllII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Microphone Volume").lIIIIlIIllIIlIIlIIIlIIllI(n2 -> {
            try {
                Message.l(n2);
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError3) {}
            return;
        }).lIIIIIIIIIlIllIIllIlIIlIl(70).lIIIIlIIllIIlIIlIIIlIIllI((Object)0, 100);
        this.lIIIIIllllIIIIlIlIIIIlIlI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Speaker Volume").lIIIIlIIllIIlIIlIIIlIIllI(n3 -> {
            try {
                Message.m(20000 / (float)(20000 - Math.max(0, Math.min(19500, n3 * 195))));
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError4) {}
            return;
        }).lIIIIIIIIIlIllIIllIlIIlIl(85).lIIIIlIIllIIlIIlIIIlIIllI((Object)0, 100);
        this.lIIlIIIIIIIIllIIllIIlllIl = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("FPS Boost");
        this.IlIIlIIIIlIIIIllllIIlIllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Enable FPS Boost").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIIlIIllIIIIIlIllIIIIllII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Slow chunk loading (%)").lIIIIlIIllIIlIIlIIIlIIllI((Object)5, 100).lIIIIIIIIIlIllIIllIlIIlIl(30);
        this.lIIlllIIlIlllllllllIIIIIl = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Fullbright").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIllIllIlIIllIllIlIlIIlIl = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Enchantment Glint").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IllllllIllllIIlllIllllllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("Team View Settings");
        this.llIlIIIllIIIIlllIlIIIIIlI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Enable Team View").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IIIlIIlIlIIIlllIIlIllllll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Show off-screen marker").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIllIlIlllIIlIIllIIlIIlII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Show distance").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIlIlIIIlIIllllllllIIlllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("General Settings");
        this.IllIlIIIIlllIIllIIlllIIlI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "GUI Blur").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IllIlIlIllllIlIIllllIIlll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "World Time").lIIIIIIIIIlIllIIllIlIIlIl(-14490).lIIIIlIIllIIlIIlIIIlIIllI((Object)(-22880), -6100);
        this.IllIIlIIlllllIllIIIlllIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Look View").lIIIIIIIIIlIllIIllIlIIlIl("Third").lIIIIlIIllIIlIIlIIIlIIllI("Third", "Reverse", "First");
        this.lIlIlIllIIIIIIIIllllIIllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Snap mods to other mods (GUI)").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IlIlllIllIlIllIlllIlllIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("Render Settings");
        this.IlIlIIIlllllIIIlIlIlIllII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Show Potion info in inventory").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IllllIllllIlIIIlIIIllllll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Show chat background").lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.IlllIIlllIIIIllIIllllIlIl = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Show HUD while in debug view").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IllIIlllIllIlIllIlIIIIIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Shiny Pots").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IIlIIllIIIllllIIlllIllIIl = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Clear Glass").lIIIIIIIIIlIllIIllIlIIlIl("OFF").lIIIIlIIllIIlIIlIIIlIIllI("OFF", "REGULAR", "ALL");
        this.lllIlIIllllIIIIlIllIlIIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Red String").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.lIIIIlllIIlIlllllIlIllIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Transparent background").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.llIIIllIIllllIlIlIlIlIIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("Crosshair Settings");
        this.lIIIlllIlIlllIIIIIIIIIlII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Custom crosshair").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IIIIlIIIlllllllllIlllIlll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Outline").lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IlIllllIIIlIllllIIIIIllII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Color").lIIIIIIIIIlIllIIllIlIIlIl(-1).lIIIIlIIllIIlIIlIIIlIIllI((Object)Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.IlIIIIllIIIIIlllIIlIIlllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Thickness").lIIIIIIIIIlIllIIllIlIIlIl(2.0f).lIIIIlIIllIIlIIlIIIlIIllI((Object)1.0f, 1.8478261f * 1.3529412f);
        this.llIlIlIllIlIIlIlllIllIIlI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Size").lIIIIIIIIIlIllIIllIlIIlIl(4).lIIIIlIIllIIlIIlIIIlIIllI((Object)1.0f, 10);
        this.llIlIlIlllIlllllIIIllIIll = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Gap").lIIIIIIIIIlIllIIllIlIIlIl(4.4722223f * 0.39130434f).lIIIIlIIllIIlIIlIIIlIIllI((Object)0.0f, 1.0493827f * 7.147059f);
        this.IIIIIlIllIllIlIIllIIlIllI = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "label").lIIIIIIIIIlIllIIllIlIIlIl("Color Options");
        this.IIllIlIllIlIllIIlIllIlIII = new lIIlIlllIIIIlIIIllIlIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "Default color").lIIIIIIIIIlIllIIllIlIIlIl(-1).lIIIIlIIllIIlIIlIIIlIIllI((Object)Integer.MIN_VALUE, Integer.MAX_VALUE);
        (this.llllIIIIlIlIllIIIllllIIll = new ArrayList()).add(new String[] { "MineHQ Network", "minehq.com" });
        this.llllIIIIlIlIllIIIllllIIll.add(new String[] { "VeltPvP", "veltpvp.com" });
        (this.IIlIlIIlIIIlIlllllIIlIIlI = new ArrayList()).add("xyz.com");
        final GameSettings gameSettings = Minecraft.getMinecraft().gameSettings;
        this.IlllIIIlIlllIllIlIIlllIlI = new KeyBinding("Voice Chat", 47, "CheatBreaker Client", true);
        this.lIIIIlIIllIIlIIlIIIlIIllI = new KeyBinding("Open Menu", 54, "CheatBreaker Client", true);
        this.lIIIIIIIIIlIllIIllIlIIlIl = new KeyBinding("Open Voice Menu", 25, "CheatBreaker Client", true);
        this.IIIIllIlIIIllIlllIlllllIl = new KeyBinding("Drag to look", 56, "CheatBreaker Client", true);
        this.IIIIllIIllIIIIllIllIIIlIl = new KeyBinding("Hide name plates", 0, "CheatBreaker Client", true);
        gameSettings.lllIIlIIIllIIlllIlIIIllIl = (KeyBinding[])ArrayUtils.addAll((Object[])gameSettings.lllIIlIIIllIIlllIlIIIllIl, (Object[])new KeyBinding[] { this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl });
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return !(boolean)this.IlIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl() || (boolean)this.lIllIllIlIIllIllIlIlIIlIl.IIIIllIlIIIllIlllIlllllIl();
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        final Iterator<IllllllllIlIIIIIIIIllIIII> iterator = this.lIlIllIlIlIIIllllIlIllIll.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().lIIIIlIIllIIlIIlIIIlIIllI == n) {
                return true;
            }
        }
        return false;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        this.lIlIllIlIlIIIllllIlIllIll.removeIf(illllllllIlIIIIIIIIllIIII -> illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI == n);
    }
    
    public List lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.llllIIIIlIlIllIIIllllIIll;
    }
    
    public List IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIlIlIIlIIIlIlllllIIlIIlI;
    }
    
    public lIIlIlllIIIIlIIIllIlIIIII IIIIllIlIIIllIlllIlllllIl() {
        return this.llIIIllIIllllIlIlIlIlIIll;
    }
}
