import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.concurrent.atomic.AtomicInteger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllllIllIlIIllIIIIlIll
{
    private static final AtomicInteger lIIIIlIIllIIlIIlIIIlIIllI;
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new AtomicInteger(0);
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
    }
}
