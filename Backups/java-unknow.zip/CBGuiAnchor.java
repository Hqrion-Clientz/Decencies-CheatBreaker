// 
// Decompiled by Procyon v0.5.36
// 

public enum CBGuiAnchor
{
    LEFT_TOP("LEFT_TOP", 0, "LEFT_TOP"), 
    LEFT_MIDDLE("LEFT_MIDDLE", 1, "LEFT_MIDDLE"), 
    LEFT_BOTTOM("LEFT_BOTTOM", 2, "LEFT_BOTTOM"), 
    MIDDLE_TOP("MIDDLE_TOP", 3, "MIDDLE_TOP"), 
    MIDDLE_MIDDLE("MIDDLE_MIDDLE", 4, "MIDDLE_MIDDLE"), 
    MIDDLE_BOTTOM_LEFT("MIDDLE_BOTTOM_LEFT", 5, "MIDDLE_BOTTOM_LEFT"), 
    MIDDLE_BOTTOM_RIGHT("MIDDLE_BOTTOM_RIGHT", 6, "MIDDLE_BOTTOM_RIGHT"), 
    RIGHT_TOP("RIGHT_TOP", 7, "RIGHT_TOP"), 
    RIGHT_MIDDLE("RIGHT_MIDDLE", 8, "RIGHT_MIDDLE"), 
    RIGHT_BOTTOM("RIGHT_BOTTOM", 9, "RIGHT_BOTTOM");
    
    private final String identifier;
    
    private CBGuiAnchor(final String name, final int ordinal, final String identifier) {
        this.identifier = identifier;
    }
    
    public String getIdentifier() {
        return this.identifier;
    }
}
