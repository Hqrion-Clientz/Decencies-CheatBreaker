import com.google.common.base.Throwables;
import org.lwjgl.input.Mouse;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import java.util.Arrays;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.DataFlavor;
import java.awt.Toolkit;
import org.lwjgl.input.Keyboard;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiScreen extends IlIIIlIIlIIllIllllIlIlIll
{
    protected static IIIlIllIIlIllIIIIlIIlIlIl IIIlIIllllIIllllllIlIIIll;
    protected Minecraft lllIIIIIlIllIlIIIllllllII;
    public int lIIIIIllllIIIIlIlIIIIlIlI;
    public int IIIIIIlIlIlIllllllIlllIlI;
    protected List IllIllIIIlIIlllIIIllIllII;
    protected List IlIIlIIIIlIIIIllllIIlIllI;
    public boolean lIIlIIllIIIIIlIllIIIIllII;
    protected FontRenderer lIIlllIIlIlllllllllIIIIIl;
    private lIIlIIIIlIIIIIllIIIIlIIll lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private long IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    protected static IllllllIllllIIlllIllllllI lIllIllIlIIllIllIlIlIIlIl;
    protected static IllllllIllllIIlllIllllllI llIlIIIllIIIIlllIlIIIIIlI;
    
    public GuiScreen() {
        this.IllIllIIIlIIlllIIIllIllII = new ArrayList();
        this.IlIIlIIIIlIIIIllllIIlIllI = new ArrayList();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        for (int i = 0; i < this.IllIllIIIlIIlllIIIllIllII.size(); ++i) {
            ((lIIlIIIIlIIIIIllIIIIlIIll)this.IllIllIIIlIIlllIIIllIllII.get(i)).setWorldAndResolution(this.lllIIIIIlIllIlIIIllllllII, n, n2);
        }
        for (int j = 0; j < this.IlIIlIIIIlIIIIllllIIlIllI.size(); ++j) {
            ((lIllIlllIIIIIIIlIIlIllIll)this.IlIIlIIIIlIIIIllllIIlIllI.get(j)).setWorldAndResolution(this.lllIIIIIlIllIlIIIllllllII, n, n2);
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        this.lllIIIIIlIllIlIIIllllllII.updateScreen();
        if (Keyboard.isKeyDown(42) && n == 15) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(IlllllIllIIIllIIIllIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIIIIlIllIlIIIllllllII.currentScreen));
        }
        if (n == 1) {
            if (CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl()) {
                this.lllIIIIIlIllIlIIIllllllII.entityRenderer.unloadSounds();
            }
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
            this.lllIIIIIlIllIlIIIllllllII.setIngameFocus();
        }
    }
    
    public static String IIIIIIlIlIlIllllllIlllIlI() {
        try {
            final Transferable contents = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String)contents.getTransferData(DataFlavor.stringFlavor);
            }
        }
        catch (Exception ex) {}
        return "";
    }
    
    public static void IlllIIIlIlllIllIlIIlllIlI(final String data) {
        try {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(data), null);
        }
        catch (Exception ex) {}
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2) {
        final List liiiIlIIllIIlIIlIIIlIIllI = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIIIIlIllIlIIIllllllII.thePlayer, this.lllIIIIIlIllIlIIIllllllII.gameSettings.IIIlllIllIlIIllIIllIlIlll);
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.size(); ++i) {
            if (i == 0) {
                liiiIlIIllIIlIIlIIIlIIllI.set(i, lIlIlIlIlIllllIlllIIIlIlI.lIIlllIIlIlllllllllIIIIIl().IIIIllIIllIIIIllIllIIIlIl + liiiIlIIllIIlIIlIIIlIIllI.get(i));
            }
            else {
                liiiIlIIllIIlIIlIIIlIIllI.set(i, IlIllllIIlIIllIlIlllllIlI.IllIIIIIIIlIlIllllIIllIII + liiiIlIIllIIlIIlIIIlIIllI.get(i));
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n, n2);
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(Arrays.asList(s), n, n2);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final List list, final int n, final int n2) {
        if (!list.isEmpty()) {
            GL11.glDisable(32826);
            llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            int n3 = 0;
            final Iterator<String> iterator = list.iterator();
            while (iterator.hasNext()) {
                final int stringWidth = this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(iterator.next());
                if (stringWidth > n3) {
                    n3 = stringWidth;
                }
            }
            int n4 = n + 12;
            int n5 = n2 - 12;
            int n6 = 8;
            if (list.size() > 1) {
                n6 += 2 + (list.size() - 1) * 10;
            }
            if (n4 + n3 > this.lIIIIIllllIIIIlIlIIIIlIlI) {
                n4 -= 28 + n3;
            }
            if (n5 + n6 + 6 > this.IIIIIIlIlIlIllllllIlllIlI) {
                n5 = this.IIIIIIlIlIlIllllllIlllIlI - n6 - 6;
            }
            GuiScreen.llIlIIIlIIIIlIlllIlIIIIll = 300;
            GuiScreen.IIIlIIllllIIllllllIlIIIll.IlIlIIIlllIIIlIlllIlIllIl = 300;
            final int n7 = -267386864;
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 - 4), (float)(n4 + n3 + 3), (float)(n5 - 3), n7, n7);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 + n6 + 3), (float)(n4 + n3 + 3), (float)(n5 + n6 + 4), n7, n7);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 - 3), (float)(n4 + n3 + 3), (float)(n5 + n6 + 3), n7, n7);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 4), (float)(n5 - 3), (float)(n4 - 3), (float)(n5 + n6 + 3), n7, n7);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 + n3 + 3), (float)(n5 - 3), (float)(n4 + n3 + 4), (float)(n5 + n6 + 3), n7, n7);
            final int n8 = 1347420415;
            final int n9 = (n8 & 0xFEFEFE) >> 1 | (n8 & 0xFF000000);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 - 3 + 1), (float)(n4 - 3 + 1), (float)(n5 + n6 + 3 - 1), n8, n9);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 + n3 + 2), (float)(n5 - 3 + 1), (float)(n4 + n3 + 3), (float)(n5 + n6 + 3 - 1), n8, n9);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 - 3), (float)(n4 + n3 + 3), (float)(n5 - 3 + 1), n8, n8);
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 + n6 + 2), (float)(n4 + n3 + 3), (float)(n5 + n6 + 3), n9, n9);
            for (int i = 0; i < list.size(); ++i) {
                this.lIIlllIIlIlllllllllIIIIIl.drawStringWithShadow(list.get(i), (float)n4, (float)n5, -1);
                if (i == 0) {
                    n5 += 2;
                }
                n5 += 10;
            }
            GuiScreen.llIlIIIlIIIIlIlllIlIIIIll = 0.0f;
            GuiScreen.IIIlIIllllIIllllllIlIIIll.IlIlIIIlllIIIlIlllIlIllIl = 0.0f;
            GL11.glEnable(2896);
            GL11.glEnable(2929);
            llIlIlllllIIllIIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl();
            GL11.glEnable(32826);
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (n3 == 0) {
            for (int i = 0; i < this.IllIllIIIlIIlllIIIllIllII.size(); ++i) {
                final lIIlIIIIlIIIIIllIIIIlIIll liiiIlIIllIIlIIlIIIlIIllI = this.IllIllIIIlIIlllIIIllIllII.get(i);
                if (liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.lllIIIIIlIllIlIIIllllllII, n, n2)) {
                    (this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII());
                    this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
                }
            }
        }
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null && n3 == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.resize(n, n2);
            this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final long n4) {
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
    }
    
    public void setWorldAndResolution(final Minecraft lllIIIIIlIllIlIIIllllllII, final int liiiiIllllIIIIlIlIIIIlIlI, final int iiiiiIlIlIlIllllllIlllIlI) {
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        this.lIIlllIIlIlllllllllIIIIIl = lllIIIIIlIllIlIIIllllllII.fontRendererObj;
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        this.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.s_();
        this.IllIllIIIlIIlllIIIllIllII();
    }
    
    public void s_() {
    }
    
    public void IllIllIIIlIIlllIIIllIllII() {
        if ((boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl() && this.lllIIIIIlIllIlIIIllllllII.theWorld != null && this.lllIIIIIlIllIlIIIllllllII.thePlayer != null) {
            this.lllIIIIIlIllIlIIIllllllII.entityRenderer.IIIIllIIllIIIIllIllIIIlIl();
        }
        if (this.lllIIIIIlIllIlIIIllllllII.previousGuiScreen == null) {
            GuiScreen.lIllIllIlIIllIllIlIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl();
            GuiScreen.llIlIIIllIIIIlllIlIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        }
    }
    
    public void handleInput() {
        if (Mouse.isCreated()) {
            while (Mouse.next()) {
                this.handleMouseInput();
            }
        }
        if (Keyboard.isCreated()) {
            while (Keyboard.next()) {
                this.lIIlIIllIIIIIlIllIIIIllII();
            }
        }
    }
    
    public void handleMouseInput() {
        final int n = Mouse.getEventX() * this.lIIIIIllllIIIIlIlIIIIlIlI / this.lllIIIIIlIllIlIIIllllllII.displayWidth;
        final int n2 = this.IIIIIIlIlIlIllllllIlllIlI - Mouse.getEventY() * this.IIIIIIlIlIlIllllllIlllIlI / this.lllIIIIIlIllIlIIIllllllII.displayHeight - 1;
        final int eventButton = Mouse.getEventButton();
        if (Mouse.getEventButtonState()) {
            if (this.lllIIIIIlIllIlIIIllllllII.gameSettings.lIIIIIIlIIllIlIlIllIIIIll && this.IIIIllIlIIIllIlllIlllllIl++ > 0) {
                return;
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl = eventButton;
            this.IlllIIIlIlllIllIlIIlllIlI = Minecraft.getSystemTime();
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        else if (eventButton != -1) {
            if (this.lllIIIIIlIllIlIIIllllllII.gameSettings.lIIIIIIlIIllIlIlIllIIIIll && --this.IIIIllIlIIIllIlllIlllllIl > 0) {
                return;
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
            this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, eventButton);
        }
        else if (this.lIIIIIIIIIlIllIIllIlIIlIl != -1 && this.IlllIIIlIlllIllIlIIlllIlI > 0L) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, this.lIIIIIIIIIlIllIIllIlIIlIl, Minecraft.getSystemTime() - this.IlllIIIlIlllIllIlIIlllIlI);
        }
    }
    
    public void lIIlIIllIIIIIlIllIIIIllII() {
        if (Keyboard.getEventKeyState()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(Keyboard.getEventCharacter(), Keyboard.getEventKey());
        }
    }
    
    public void updateScreen() {
    }
    
    public void t_() {
    }
    
    public void lIIlllIIlIlllllllllIIIIIl() {
        if (CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl()) {
            try {
                if (this.lllIIIIIlIllIlIIIllllllII.entityRenderer.isCurrentLocaleUnicode()) {
                    final Iterator<IIllIlIlIlllIlIlIlIllIlII> iterator = Minecraft.getMinecraft().entityRenderer.IllIIIIIIIlIlIllllIIllIII().IlllIIIlIlllIllIlIIlllIlI().iterator();
                    while (iterator.hasNext()) {
                        final IIlIlIllIIIllIIIIIIIllIIl liiiiiiiiIlIllIIllIlIIlIl = iterator.next().lIIIIIIIIIlIllIIllIlIIlIl().lIIIIIIIIIlIllIIllIlIIlIl("Progress");
                        if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                            liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(GuiScreen.lIllIllIlIIllIllIlIlIIlIl.IllIIIIIIIlIlIllllIIllIII());
                        }
                    }
                }
                GL11.glEnable(2929);
            }
            catch (IllegalArgumentException ex) {
                Throwables.propagate((Throwable)ex);
            }
        }
    }
    
    public void lIllIllIlIIllIllIlIlIIlIl() {
        this.lIIlllIIlIlllllllllIIIIIl();
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)this.lIIIIIllllIIIIlIlIIIIlIlI, (float)this.IIIIIIlIlIlIllllllIlllIlI, GuiScreen.lIllIllIlIIllIllIlIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(true).getRGB(), GuiScreen.llIlIIIllIIIIlllIlIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl(true).getRGB());
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2) throws Exception {
        final lllllIIIIIllIIlIIIIllllII illIIIIIIIlIlIllllIIllIII = Minecraft.getMinecraft().entityRenderer.IllIIIIIIIlIlIllllIIllIII();
        try {
            if (this.lllIIIIIlIllIlIIIllllllII.entityRenderer.isCurrentLocaleUnicode()) {
                final Iterator iterator = illIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI().iterator();
                while (iterator.hasNext()) {
                    final IIlIlIllIIIllIIIIIIIllIIl liiiiiiiiIlIllIIllIlIIlIl = iterator.next().lIIIIIIIIIlIllIIllIlIIlIl().lIIIIIIIIIlIllIIllIlIIlIl("Progress");
                    if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                        liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(0.75555557f * 0.6617647f);
                    }
                }
            }
        }
        catch (IllegalArgumentException ex) {
            Throwables.propagate((Throwable)ex);
        }
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, n, n2, GuiScreen.lIllIllIlIIllIllIlIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(true).getRGB(), GuiScreen.llIlIIIllIIIIlllIlIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl(true).getRGB());
    }
    
    public void updateDebugProfilerName(final int n) {
        if (this.lllIIIIIlIllIlIIIllllllII.theWorld != null) {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)this.lIIIIIllllIIIIlIlIIIIlIlI, (float)this.IIIIIIlIlIlIllllllIlllIlI, -1072689136, -804253680);
        }
        else {
            this.IlllIIIlIlllIllIlIIlllIlI(n);
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n) {
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        final Tessellator instance = Tessellator.instance;
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiScreen.llIIlllIIIIlllIllIlIlllIl);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final float n2 = 32;
        instance.startDrawingQuads();
        instance.setColorOpaque_I(4210752);
        instance.addVertexWithUV(0.0, this.IIIIIIlIlIlIllllllIlllIlI, 0.0, 0.0, this.IIIIIIlIlIlIllllllIlllIlI / n2 + n);
        instance.addVertexWithUV(this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI, 0.0, this.lIIIIIllllIIIIlIlIIIIlIlI / n2, this.IIIIIIlIlIlIllllllIlllIlI / n2 + n);
        instance.addVertexWithUV(this.lIIIIIllllIIIIlIlIIIIlIlI, 0.0, 0.0, this.lIIIIIllllIIIIlIlIIIIlIlI / n2, n);
        instance.addVertexWithUV(0.0, 0.0, 0.0, 0.0, n);
        instance.draw();
    }
    
    public boolean isUnicode() {
        return true;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
    }
    
    public static boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return Minecraft.isRunningOnMac ? (Keyboard.isKeyDown(219) || Keyboard.isKeyDown(220)) : (Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157));
    }
    
    public static boolean lIllIlIlllIIlIIllIIlIIlII() {
        return Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54);
    }
    
    static {
        GuiScreen.IIIlIIllllIIllllllIlIIIll = new IIIlIllIIlIllIIIIlIIlIlIl();
        GuiScreen.lIllIllIlIIllIllIlIlIIlIl = new IllllllIllllIIlllIllllllI(0, -553648128);
        GuiScreen.llIlIIIllIIIIlllIlIIIIIlI = new IllllllIllllIIlllIllllllI(0, 1243487774);
    }
}
