import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIIlllllIlIlllllIIl extends lIlllllIIllIlIlIlllIIIIII
{
    public IIIIlllIIlllllIlIlllllIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return n == this.IIIllIllIlIlllllllIlIlIII && n2 == this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return 0;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
    }
    
    @Override
    public IIlllllllIlllIIllllIIlIll lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        return IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        return 255;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        return true;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3) {
        return 0;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        return false;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, final int n2, final int n3) {
        return 0;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4) {
        return 0;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final int n) {
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3) {
        return false;
    }
    
    @Override
    public IllIllIlIIlllIllIIllIlIIl IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl) {
    }
    
    @Override
    public void IlIlIIIlllIIIlIlllIlIllIl(final int n, final int n2, final int n3) {
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
    }
    
    @Override
    public void IlIlIIIlllIIIlIlllIlIllIl() {
    }
    
    @Override
    public void IIIllIllIlIlllllllIlIlIII() {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final List list, final lllIIIlllllllIlIIIlIllIIl lllIIIlllllllIlIIIlIllIIl) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final List list, final lllIIIlllllllIlIIIlIllIIl lllIIIlllllllIlIIIlIllIIl) {
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        return false;
    }
    
    @Override
    public Random lIIIIlIIllIIlIIlIIIlIIllI(final long n) {
        return new Random(this.IIIIllIIllIIIIllIllIIIlIl.IllIllIIIlIIlllIIIllIllII() + this.IIIllIllIlIlllllllIlIlIII * this.IIIllIllIlIlllllllIlIlIII * 4987142 + this.IIIllIllIlIlllllllIlIlIII * 5947611 + this.IllIIIIIIIlIlIllllIIllIII * this.IllIIIIIIIlIlIllllIIllIII * 4392871L + this.IllIIIIIIIlIlIllllIIllIII * 389711 ^ n);
    }
    
    @Override
    public boolean IllIIIIIIIlIlIllllIIllIII() {
        return true;
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final int n, final int n2) {
        return true;
    }
}
