import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIlIIlIlllIIlIIIlllI extends IllIlIIIlIlIlIIIIlIlIllll
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private IIlIIlIIllIllllllllIllIII lIIIIIIIIIlIllIIllIlIIlIl;
    private IIlIIlIIllIllllllllIllIII IlllIIIlIlllIllIlIIlllIlI;
    private lIlIIIIIlIIIIIIlIIIIIIlll IIIIllIlIIIllIlllIlllllIl;
    private float IIIIllIIllIIIIllIllIIIlIl;
    private float IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIllIIlIIlIlllIIlIIIlllI(final IIlIIlIIllIllllllllIllIII liiiiiiiiIlIllIIllIlIIlIl, final IIlIIlIIllIllllllllIllIII illlIIIlIlllIllIlIIlllIlI, final lIlIIIIIlIIIIIIlIIIIIIlll iiiIllIlIIIllIlllIlllllIl) {
        super(new IIlIIIlIIlIIlIllIllllllII(liiiiiiiiIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl));
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.lIIlIIllIIIIIlIllIIIIllII = false;
    }
    
    @Override
    protected void resize(final int n, final int n2) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI.lIIlIIllIIIIIlIllIIIIllII() ? this.IlllIIIlIlllIllIlIIlllIlI.IIIlIIlIlIIIlllIIlIllllll() : IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI.IIIlIIlIlIIIlllIIlIllllll(), new Object[0]), 8, 6, 4210752);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlIIllIIIIIlIllIIIIllII() ? this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll() : IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll(), new Object[0]), 8, this.IlIlllIIIIllIllllIllIIlIl - 96 + 2, 4210752);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2, final int n3) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IIIllIIlIIlIlllIIlIIIlllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int n4 = (this.lIIIIIllllIIIIlIlIIIIlIlI - this.IlllIllIlIIIIlIIlIIllIIIl) / 2;
        final int n5 = (this.IIIIIIlIlIlIllllllIlllIlI - this.IlIlllIIIIllIllllIllIIlIl) / 2;
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4, n5, 0, 0, this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl);
        if (this.IIIIllIlIIIllIlllIlllllIl.lIllIlIlIIlIllIllllIllIIl()) {
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 79, n5 + 17, 0, this.IlIlllIIIIllIllllIllIIlIl, 90, 54);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl.lIlIIllIIlllIlIlllIIIIllI()) {
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 7, n5 + 35, 0, this.IlIlllIIIIllIllllIllIIlIl + 54, 18, 18);
        }
        GuiInventory.lIIIIlIIllIIlIIlIIIlIIllI(n4 + 51, n5 + 60, 17, n4 + 51 - this.IIIIllIIllIIIIllIllIIIlIl, n5 + 75 - 50 - this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.IIIIllIIllIIIIllIllIIIlIl = (float)n;
        this.IlIlIIIlllIIIlIlllIlIllIl = (float)n2;
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/gui/container/horse.png");
    }
}
