import com.google.common.collect.Maps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllllllIlIllllllIlIlll extends llIlIIIlIIlIlllIIlIIIIIll
{
    private Map<UUID, ArrayList<String>> lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIllllllIlIllllllIlIlll() {
    }
    
    public IIlIllllllIlIllllllIlIlll(final Map<UUID, ArrayList<String>> liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI((this.lIIIIlIIllIIlIIlIIIlIIllI == null) ? -1 : this.lIIIIlIIllIIlIIlIIIlIIllI.size());
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            for (final Map.Entry<UUID, ArrayList<String>> entry : this.lIIIIlIIllIIlIIlIIIlIIllI.entrySet()) {
                final UUID uuid = entry.getKey();
                final List<String> list = entry.getValue();
                liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(uuid);
                liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(list.size());
                for (String s : list) {
                    liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(s);
                }
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        final int liiiIlIIllIIlIIlIIIlIIllI = liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI == -1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = null;
            return;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = Maps.newHashMap();
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI; ++i) {
            final UUID illlIIIlIlllIllIlIIlllIlI = liiiIlIIIllIIIIIlIIIIIlII.IlllIIIlIlllIllIlIIlllIlI();
            final int liiiIlIIllIIlIIlIIIlIIllI2 = liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI();
            final ArrayList<String> list = new ArrayList<>();
            for (int j = 0; j < liiiIlIIllIIlIIlIIIlIIllI2; ++j) {
                list.add(liiiIlIIIllIIIIIlIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl());
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.put(illlIIIlIlllIllIlIIlllIlI, list);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIlIIIlIlIllIIllllII illllIIlIIIlIlIllIIllllII) {
        ((llllIIlIIllIIIlllIlIIIllI)illllIIlIIIlIlIllIIllllII).lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public Map<UUID, ArrayList<String>> lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
