import java.nio.ByteBuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class Framedata implements IFramedata
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    private DELETE_ME_E lIIIIIIIIIlIllIIllIlIIlIl;
    private ByteBuffer IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private boolean IIIllIllIlIlllllllIlIlIII;
    
    public abstract void IlllIIIlIlllIllIlIIlllIlI();
    
    public Framedata(final DELETE_ME_E liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = llIllIlIllIIIlIIllIIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI();
        this.lIIIIlIIllIIlIIlIIIlIIllI = true;
        this.IIIIllIlIIIllIlllIlllllIl = false;
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.IlIlIIIlllIIIlIlllIlIllIl = false;
        this.IIIllIllIlIlllllllIlIlIII = false;
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public boolean IllIIIIIIIlIlIllllIIllIII() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public DELETE_ME_E IlllIllIlIIIIlIIlIIllIIIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public boolean lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public ByteBuffer IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IFramedata framedata) {
        final ByteBuffer iiiIllIlIIIllIlllIlllllIl = framedata.IIIIllIlIIIllIlllIlllllIl();
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = ByteBuffer.allocate(iiiIllIlIIIllIlllIlllllIl.remaining());
            iiiIllIlIIIllIlllIlllllIl.mark();
            this.IlllIIIlIlllIllIlIIlllIlI.put(iiiIllIlIIIllIlllIlllllIl);
            iiiIllIlIIIllIlllIlllllIl.reset();
        }
        else {
            iiiIllIlIIIllIlllIlllllIl.mark();
            this.IlllIIIlIlllIllIlIIlllIlI.position(this.IlllIIIlIlllIllIlIIlllIlI.limit());
            this.IlllIIIlIlllIllIlIIlllIlI.limit(this.IlllIIIlIlllIllIlIIlllIlI.capacity());
            if (iiiIllIlIIIllIlllIlllllIl.remaining() > this.IlllIIIlIlllIllIlIIlllIlI.remaining()) {
                final ByteBuffer allocate = ByteBuffer.allocate(iiiIllIlIIIllIlllIlllllIl.remaining() + this.IlllIIIlIlllIllIlIIlllIlI.capacity());
                this.IlllIIIlIlllIllIlIIlllIlI.flip();
                allocate.put(this.IlllIIIlIlllIllIlIIlllIlI);
                allocate.put(iiiIllIlIIIllIlllIlllllIl);
                this.IlllIIIlIlllIllIlIIlllIlI = allocate;
            }
            else {
                this.IlllIIIlIlllIllIlIIlllIlI.put(iiiIllIlIIIllIlllIlllllIl);
            }
            this.IlllIIIlIlllIllIlIIlllIlI.rewind();
            iiiIllIlIIIllIlllIlllllIl.reset();
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = framedata.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    @Override
    public String toString() {
        return "Framedata{ optcode:" + this.IlllIllIlIIIIlIIlIIllIIIl() + ", fin:" + this.IIIIllIIllIIIIllIllIIIlIl() + ", rsv1:" + this.IlIlIIIlllIIIlIlllIlIllIl() + ", rsv2:" + this.IIIllIllIlIlllllllIlIlIII() + ", rsv3:" + this.IllIIIIIIIlIlIllllIIllIII() + ", payloadlength:[pos:" + this.IlllIIIlIlllIllIlIIlllIlI.position() + ", len:" + this.IlllIIIlIlllIllIlIIlllIlI.remaining() + "], payload:" + ((this.IlllIIIlIlllIllIlIIlllIlI.remaining() > 1000) ? "(too big to display)" : new String(this.IlllIIIlIlllIllIlIIlllIlI.array())) + '}';
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean iiiIllIIllIIIIllIllIIIlIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final boolean ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final boolean iiIllIllIlIlllllllIlIlIII) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final boolean iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public static Framedata lIIIIlIIllIIlIIlIIIlIIllI(final DELETE_ME_E delete_ME_E) {
        if (delete_ME_E == null) {
            throw new IllegalArgumentException("Supplied opcode cannot be null");
        }
        switch (lIllIlIIllIllIllllIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI[delete_ME_E.ordinal()]) {
            case 1: {
                return new lIIlllIIlIIllIIIIlllllllI();
            }
            case 2: {
                return new llIlIlllllIllIIlIIlIIllll();
            }
            case 3: {
                return new lllllllIllIlllIIlIllllIll();
            }
            case 4: {
                return new lIIllIllllIlIIIIlIIIIIIIl();
            }
            case 5: {
                return new llIlIIlllIIlIlIlIlIlIIIIl();
            }
            case 6: {
                return new IIlIllIIIIIlIllIllllIIIII();
            }
            default: {
                throw new IllegalArgumentException("Supplied opcode is invalid");
            }
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Framedata framedata = (Framedata)o;
        return this.lIIIIlIIllIIlIIlIIIlIIllI == framedata.lIIIIlIIllIIlIIlIIIlIIllI && this.IIIIllIlIIIllIlllIlllllIl == framedata.IIIIllIlIIIllIlllIlllllIl && this.IIIIllIIllIIIIllIllIIIlIl == framedata.IIIIllIIllIIIIllIllIIIlIl && this.IlIlIIIlllIIIlIlllIlIllIl == framedata.IlIlIIIlllIIIlIlllIlIllIl && this.IIIllIllIlIlllllllIlIlIII == framedata.IIIllIllIlIlllllllIlIlIII && this.lIIIIIIIIIlIllIIllIlIIlIl == framedata.lIIIIIIIIIlIllIIllIlIIlIl && ((this.IlllIIIlIlllIllIlIIlllIlI != null) ? this.IlllIIIlIlllIllIlIIlllIlI.equals(framedata.IlllIIIlIlllIllIlIIlllIlI) : (framedata.IlllIIIlIlllIllIlIIlllIlI == null));
    }
    
    @Override
    public int hashCode() {
        return 31 * (31 * (31 * (31 * (31 * (31 * (this.lIIIIlIIllIIlIIlIIIlIIllI ? 1 : 0) + this.lIIIIIIIIIlIllIIllIlIIlIl.hashCode()) + ((this.IlllIIIlIlllIllIlIIlllIlI != null) ? this.IlllIIIlIlllIllIlIIlllIlI.hashCode() : 0)) + (this.IIIIllIlIIIllIlllIlllllIl ? 1 : 0)) + (this.IIIIllIIllIIIIllIllIIIlIl ? 1 : 0)) + (this.IlIlIIIlllIIIlIlllIlIllIl ? 1 : 0)) + (this.IIIllIllIlIlllllllIlIlIII ? 1 : 0);
    }
}
