import java.util.Iterator;
import java.util.ArrayList;
import java.util.TimerTask;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIIIlIllIlIIIlIlIIIlIII extends TimerTask
{
    private ArrayList lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ lIIIlIlIllIlIIIlIIIlIlIIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIIIlIllIlIIIlIlIIIlIII(final lIIIlIlIllIlIIIlIIIlIlIIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
    }
    
    @Override
    public void run() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
        this.lIIIIIIIIIlIllIIllIlIIlIl.addAll(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl());
        final long n = System.currentTimeMillis() - this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII * 1500;
        for (final llIlIIIIIlllllllIlllIIIII llIlIIIIIlllllllIlllIIIII : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (llIlIIIIIlllllllIlllIIIII instanceof IlIIlIllIlIIlllllIllIlIlI) {
                final IlIIlIllIlIIlllllIllIlIlI ilIIlIllIlIIlllllIllIlIlI = (IlIIlIllIlIIlllllIllIlIlI)llIlIIIIIlllllllIlllIIIII;
                if (ilIIlIllIlIIlllllIllIlIlI.IlIlIIIlllIIIlIlllIlIllIl() < n) {
                    if (IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                        System.out.println("Closing connection due to no pong received: " + llIlIIIIIlllllllIlllIIIII.toString());
                    }
                    ilIIlIllIlIIlllllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(1006, false);
                }
                else if (ilIIlIllIlIIlllllIllIlIlI.IlllIllIlIIIIlIIlIIllIIIl()) {
                    ilIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl();
                }
                else {
                    if (!IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                        continue;
                    }
                    System.out.println("Trying to ping a non open connection: " + llIlIIIIIlllllllIlllIIIII.toString());
                }
            }
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
    }
}
