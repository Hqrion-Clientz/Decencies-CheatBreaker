import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIlllIllIlIlIIIIIlllIll
{
    protected List lIIIIlIIllIIlIIlIIIlIIllI;
    List lIIIIIIIIIlIllIIllIlIIlIl;
    List IlllIIIlIlllIllIlIIlllIlI;
    List IIIIllIlIIIllIlllIlllllIl;
    List IIIIllIIllIIIIllIllIIIlIl;
    final /* synthetic */ lIIlIlIIlIlIlIIlIlIlllIIl IlIlIIIlllIIIlIlllIlIllIl;
    
    IIlIlllIllIlIlIIIIIlllIll(final lIIlIlIIlIlIlIIlIlIlllIIl ilIlIIIlllIIIlIlllIlIllIl, final List list) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        final ArrayList<IlIIIIlllIIIlIIllllIIIlll> liiiIlIIllIIlIIlIIIlIIllI = new ArrayList<IlIIIIlllIIIlIIllllIIIlll>();
        final ArrayList<CBGuiAnchor> liiiiiiiiIlIllIIllIlIIlIl = new ArrayList<CBGuiAnchor>();
        final ArrayList<Float> illlIIIlIlllIllIlIIlllIlI = new ArrayList<Float>();
        final ArrayList<Float> iiiIllIlIIIllIlllIlllllIl = new ArrayList<Float>();
        final ArrayList<Object> iiiIllIIllIIIIllIllIIIlIl = new ArrayList<Object>();
        for (final lIlIlIIIIllIlllIlIIlllIlI lIlIlIIIIllIlllIlIIlllIlI : list) {
            if (lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) {
                continue;
            }
            liiiIlIIllIIlIIlIIIlIIllI.add(lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI);
            liiiiiiiiIlIllIIllIlIIlIl.add(lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll());
            illlIIIlIlllIllIlIIlllIlI.add(lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl());
            iiiIllIlIIIllIlllIlllllIl.add(lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIllIllllIllIIlIl());
            iiiIllIIllIIIIllIllIIIlIl.add(lIlIlIIIIllIlllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl());
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
}
