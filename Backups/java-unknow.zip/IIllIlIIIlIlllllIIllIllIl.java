import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIIlIlllllIIllIllIl extends IIllIIlIllIllIllIIIIIlIII implements IlllllIIIlIlllllIIlIlllIl
{
    private final IIlllllllIlllIIllllIIlIll lIIIIlllIIlIlllllIlIllIII;
    private IlllIllIIIIlllIllIIIIIlII lIIIlllIlIlllIIIIIIIIIlII;
    
    protected IIllIlIIIlIlllllIIllIllIl(final IIlllllllIlllIIllllIIlIll liiiIlllIIlIlllllIlIllIII) {
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        final float n = 0.36057693f * 0.34666666f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(1.1066667f * 0.45180723f - n, 0.0f, 0.71428573f * 0.7f - n, 0.375f * 1.3333334f + n, 0.35227275f * 0.7096774f, 0.8684211f * 0.57575756f + n);
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllllIllIIllIIllIlIIIIII)null);
    }
    
    @Override
    protected boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
        if (iiiiiIllIlIIIIlIlllIllllI.IlllIllIlIIIIlIIlIIllIIIl(n, n2 + 1, n3) >= 9 && random.nextInt((int)(25 / this.llIIlllIIIIlllIllIlIlllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) + 1) == 0) {
            int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            if (illlIIIlIlllIllIlIIlllIlI < 7) {
                ++illlIIIlIlllIllIlIIlllIlI;
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 2);
            }
            else {
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == this.lIIIIlllIIlIlllllIlIllIII) {
                    return;
                }
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == this.lIIIIlllIIlIlllllIlIllIII) {
                    return;
                }
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == this.lIIIIlllIIlIlllllIlIllIII) {
                    return;
                }
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == this.lIIIIlllIIlIlllllIlIllIII) {
                    return;
                }
                final int nextInt = random.nextInt(4);
                int n4 = n;
                int n5 = n3;
                if (nextInt == 0) {
                    n4 = n - 1;
                }
                if (nextInt == 1) {
                    ++n4;
                }
                if (nextInt == 2) {
                    n5 = n3 - 1;
                }
                if (nextInt == 3) {
                    ++n5;
                }
                final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n4, n2 - 1, n5);
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n4, n2, n5).IllIIlllIllIlIllIlIIIIIII == Material.air && (block == IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl || block == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl || block == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI)) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n2, n5, this.lIIIIlllIIlIlllllIlIllIII);
                }
            }
        }
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        int n4 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII, 2, 5);
        if (n4 > 7) {
            n4 = 7;
        }
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 2);
    }
    
    private float llIIlllIIIIlllIllIlIlllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        float n4 = 1.0f;
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1);
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1);
        final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3);
        final IIlllllllIlllIIllllIIlIll block4 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3);
        final IIlllllllIlllIIllllIIlIll block5 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3 - 1);
        final IIlllllllIlllIIllllIIlIll block6 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3 - 1);
        final IIlllllllIlllIIllllIIlIll block7 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3 + 1);
        final IIlllllllIlllIIllllIIlIll block8 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3 + 1);
        final boolean b = block3 == this || block4 == this;
        final boolean b2 = block == this || block2 == this;
        final boolean b3 = block5 == this || block6 == this || block7 == this || block8 == this;
        for (int i = n - 1; i <= n + 1; ++i) {
            for (int j = n3 - 1; j <= n3 + 1; ++j) {
                final IIlllllllIlllIIllllIIlIll block9 = iiiiiIllIlIIIIlIlllIllllI.getBlock(i, n2 - 1, j);
                float n5 = 0.0f;
                if (block9 == IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl) {
                    n5 = 1.0f;
                    if (iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(i, n2 - 1, j) > 0) {
                        n5 = 3;
                    }
                }
                if (i != n || j != n3) {
                    n5 /= 4;
                }
                n4 += n5;
            }
        }
        if (b3 || (b && b2)) {
            n4 /= 2.0f;
        }
        return n4;
    }
    
    @Override
    public int IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        return n * 32 << 16 | 255 - n * 8 << 8 | n * 4;
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return this.IlIlIIIlllIIIlIlllIlIllIl(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
        final float n = 0.1388889f * 0.9f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(22.5f * 0.022222223f - n, 0.0f, 0.3809524f * 1.3125f - n, 0.078947365f * 6.3333335f + n, 2.2272727f * 0.1122449f, 1.725f * 0.28985506f + n);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.IllIIlIIlllllIllIIIlllIII = (liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) * 2 + 2) / (float)16;
        final float n4 = 0.008116883f * 15.4f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f * 0.5f - n4, 0.0f, 1.4333333f * 0.34883723f - n4, 0.2578125f * 1.939394f + n4, (float)this.IllIIlIIlllllIllIIIlllIII, 0.1875f * 2.6666667f + n4);
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 19;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return (liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) < 7) ? -1 : ((liIllIIIllIIIIllIllIIllIl.getBlock(n - 1, n2, n3) == this.lIIIIlllIIlIlllllIlIllIII) ? 0 : ((liIllIIIllIIIIllIllIIllIl.getBlock(n + 1, n2, n3) == this.lIIIIlllIIlIlllllIlIllIII) ? 1 : ((liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 - 1) == this.lIIIIlllIIlIlllllIlIllIII) ? 2 : ((liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 + 1) == this.lIIIIlllIIlIlllllIlIllIII) ? 3 : -1))));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final int n6) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, n5, n6);
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII = null;
            if (this.lIIIIlllIIlIlllllIlIllIII == IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll) {
                liIlllIIIlIllllllIlIlIIII = IIlIlIllIlIIllIllIllIIIll.lIIlIIIllIIlllIlllIlIIlll;
            }
            if (this.lIIIIlllIIlIlllllIlIllIII == IllllllIllIIlllIllIIlIIll.lIIIIIIlIIllIlIlIllIIIIll) {
                liIlllIIIlIllllllIlIlIIII = IIlIlIllIlIIllIllIllIIIll.lllIllIlIllIlIllIIIIIIlll;
            }
            for (int i = 0; i < 3; ++i) {
                if (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(15) <= n4) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII));
                }
            }
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return null;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        return 1;
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return (this.lIIIIlllIIlIlllllIlIllIII == IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll) ? IIlIlIllIlIIllIllIllIIIll.lIIlIIIllIIlllIlllIlIIlll : ((this.lIIIIlllIIlIlllllIlIllIII == IllllllIllIIlllIllIIlIIll.lIIIIIIlIIllIlIlIllIIIIll) ? IIlIlIllIlIIllIllIllIIIll.lllIllIlIllIlIllIIIIIIlll : lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(0));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIlIIllIIIllllIIlllIllIIl = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_disconnected");
        this.lIIIlllIlIlllIIIIIIIIIlII = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_connected");
    }
    
    public IlllIllIIIIlllIllIIIIIlII IIIIlIIIlllllllllIlllIlll() {
        return this.lIIIlllIlIlllIIIIIIIIIlII;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b) {
        return iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) != 7;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        return true;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
}
