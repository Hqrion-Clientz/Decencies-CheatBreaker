import java.util.Iterator;
import com.google.common.collect.Lists;
import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIlIlIIIlIIllIllIllI implements llIIlIlIIlllllIIIlIlIlllI
{
    private final List lIIIIlIIllIIlIIlIIIlIIllI;
    private final Random lIIIIIIIIIlIllIIllIlIIlIl;
    private final ResourceLocation IlllIIIlIlllIllIlIIlllIlI;
    private final llllIlllIllIIIIlIIllIIIIl IIIIllIlIIIllIlllIlllllIl;
    private double IIIIllIIllIIIIllIllIIIlIl;
    private double IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIlIIlIlIIIlIIllIllIllI(final ResourceLocation illlIIIlIlllIllIlIIlllIlI, final double iiiIllIIllIIIIllIllIIIlIl, final double ilIlIIIlllIIIlIlllIlIllIl, final llllIlllIllIIIIlIIllIIIIl iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Lists.newArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = new Random();
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        int n = 0;
        final Iterator<llIIlIlIIlllllIIIlIlIlllI> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI.iterator();
        while (iterator.hasNext()) {
            n += iterator.next().lIIIIlIIllIIlIIlIIIlIIllI();
        }
        return n;
    }
    
    public IllIllIIlllIllllllIIlIIll IlllIIIlIlllIllIlIIlllIlI() {
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI();
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.isEmpty() && liiiIlIIllIIlIIlIIIlIIllI != 0) {
            int nextInt = this.lIIIIIIIIIlIllIIllIlIIlIl.nextInt(liiiIlIIllIIlIIlIIIlIIllI);
            for (final llIIlIlIIlllllIIIlIlIlllI llIIlIlIIlllllIIIlIlIlllI : this.lIIIIlIIllIIlIIlIIIlIIllI) {
                nextInt -= llIIlIlIIlllllIIIlIlIlllI.lIIIIlIIllIIlIIlIIIlIIllI();
                if (nextInt < 0) {
                    final IllIllIIlllIllllllIIlIIll illIllIIlllIllllllIIlIIll = (IllIllIIlllIllllllIIlIIll)llIIlIlIIlllllIIIlIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl();
                    illIllIIlllIllllllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(illIllIIlllIllllllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl() * this.IIIIllIIllIIIIllIllIIIlIl);
                    illIllIIlllIllllllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl(illIllIIlllIllllllIIlIIll.IlllIIIlIlllIllIlIIlllIlI() * this.IlIlIIIlllIIIlIlllIlIllIl);
                    return illIllIIlllIllllllIIlIIll;
                }
            }
            return SoundHandler.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        return SoundHandler.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIIlIlIIlllllIIIlIlIlllI llIIlIlIIlllllIIIlIlIlllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(llIIlIlIIlllllIIIlIlIlllI);
    }
    
    public ResourceLocation IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public llllIlllIllIIIIlIIllIIIIl IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
}
