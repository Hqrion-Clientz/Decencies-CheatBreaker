import java.beans.ConstructorProperties;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllllIlllIIlIIlIIIIIll extends IllllIllIllIIIIIIlIllIIll
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private double IlllIIIlIlllIllIlIIlllIlI;
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeDouble(this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readDouble();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll liIlllIIlllIlIllIIlIIIIll) {
    }
    
    public IIIIllllIlllIIlIIlIIIIIll() {
    }
    
    @ConstructorProperties({ "id", "value" })
    public IIIIllllIlllIIlIIlIIIIIll(final int liiiIlIIllIIlIIlIIIlIIllI, final double illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
