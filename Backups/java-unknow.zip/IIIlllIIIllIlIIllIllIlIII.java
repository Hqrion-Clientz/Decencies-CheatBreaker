import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlllIIIllIlIIllIllIlIII implements Callable
{
    final /* synthetic */ CrashReport lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlllIIIllIlIIllIllIlIII(final CrashReport liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        final int i = 0;
        final int j = 56 * i;
        final int k = j / 1024 / 1024;
        final int l = 0;
        final int m = 56 * l;
        return i + " (" + j + " bytes; " + k + " MB) allocated, " + l + " (" + m + " bytes; " + m / 1024 / 1024 + " MB) used";
    }
}
