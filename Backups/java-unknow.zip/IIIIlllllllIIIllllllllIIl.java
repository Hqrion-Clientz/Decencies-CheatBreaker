// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllllllIIIllllllllIIl extends GuiScreen
{
    private GuiScreen lIIIIIIIIIlIllIIllIlIIlIl;
    protected String lIIIIlIIllIIlIIlIIIlIIllI;
    private GameSettings IlllIIIlIlllIllIlIIlllIlI;
    private static lllIlIIIIlIIlIlIIlIlIlIll[] IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private long IIIllIllIlIlllllllIlIlIII;
    
    public IIIIlllllllIIIllllllllIIl(final GuiScreen liiiiiiiiIlIllIIllIlIIlIl, final GameSettings illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "Performance Settings";
        this.IIIIllIIllIIIIllIllIIIlIl = 0;
        this.IlIlIIIlllIIIlIlllIlIllIl = 0;
        this.IIIllIllIlIlllllllIlIlIII = 0L;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void s_() {
        int n = 0;
        for (final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll : IIIIlllllllIIIllllllllIIl.IIIIllIlIIIllIlllIlllllIl) {
            final int n2 = this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + n % 2 * 160;
            final int n3 = this.IIIIIIlIlIlIllllllIlllIlI / 6 + 21 * (n / 2) - 10;
            if (!lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI()) {
                this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI(), n2, n3, lllIlIIIIlIIlIlIIlIlIlIll, this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll)));
            }
            else {
                this.IllIllIIIlIIlllIIIllIllII.add(new IllIIllIIllIlIllllIlIllII(lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI(), n2, n3, lllIlIIIIlIIlIlIIlIlIlIll));
            }
            ++n;
        }
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(200, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 168 + 11, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.done", new Object[0])));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI < 200 && liIlIIIIlIIIIIllIIIIlIIll instanceof llIllIlIlIIIllllIlIlIlIIl) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(((llIllIlIlIIIllllIlIlIlIIl)liIlIIIIlIIIIIllIIIIlIIll).lIIIIlIIllIIlIIlIIIlIIllI(), 1);
                liIlIIIIlIIIIIllIIIIlIIll.IllIIIIIIIlIlIllllIIllIII = this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI));
            }
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 200) {
                this.lllIIIIIlIllIlIIIllllllII.gameSettings.saveOptions();
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI != lllIlIIIIlIIlIlIIlIlIlIll.IllllllIllllIIlllIllllllI.ordinal()) {
                final ScaledResolution scaledResolution = new ScaledResolution(this.lllIIIIIlIllIlIIIllllllII, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
                this.setWorldAndResolution(this.lllIIIIIlIllIlIIIllllllII, scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl, final float n) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 20, 16777215);
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, ilIlIIIlllIIIlIlllIlIllIl, n);
        if (Math.abs(iiiIllIIllIIIIllIllIIIlIl - this.IIIIllIIllIIIIllIllIIIlIl) <= 5 && Math.abs(ilIlIIIlllIIIlIlllIlIllIl - this.IlIlIIIlllIIIlIlllIlIllIl) <= 5) {
            if (System.currentTimeMillis() >= this.IIIllIllIlIlllllllIlIlIII + 700) {
                final int n2 = this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 150;
                int n3 = this.IIIIIIlIlIlIllllllIlllIlI / 6 - 5;
                if (ilIlIIIlllIIIlIlllIlIllIl <= n3 + 98) {
                    n3 += 105;
                }
                final int n4 = n2 + 150 + 150;
                final int n5 = n3 + 84 + 10;
                final lIIlIIIIlIIIIIllIIIIlIIll liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, ilIlIIIlllIIIlIlllIlIllIl);
                if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                    final String[] liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII));
                    if (liiiIlIIllIIlIIlIIIlIIllI2 == null) {
                        return;
                    }
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)n2, (float)n3, (float)n4, (float)n5, -536870912);
                    for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI2.length; ++i) {
                        final String s = liiiIlIIllIIlIIlIIIlIIllI2[i];
                        int n6 = 14540253;
                        if (s.endsWith("!")) {
                            n6 = 16719904;
                        }
                        this.lIIlllIIlIlllllllllIIIIIl.drawStringWithShadow(s, (float)(n2 + 5), (float)(n3 + 5 + i * 11), n6);
                    }
                }
            }
        }
        else {
            this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
            this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
            this.IIIllIllIlIlllllllIlIlIII = System.currentTimeMillis();
        }
    }
    
    private String[] lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return (String[])(s.equals("Smooth FPS") ? new String[] { "Stabilizes FPS by flushing the graphic driver buffers", "  OFF - no stabilization, FPS may fluctuate", "  ON - FPS stabilization", "This option is graphics driver dependant and its effect", "is not always visible" } : (s.equals("Smooth World") ? new String[] { "Removes lag spikes caused by the internal server.", "  OFF - no stabilization, FPS may fluctuate", "  ON - FPS stabilization", "Stabilizes FPS by distributing the internal server load.", "Effective only for local worlds and single-core CPU." } : (s.equals("Load Far") ? new String[] { "Loads the world chunks at distance Far.", "Switching the render distance does not cause all chunks ", "to be loaded again.", "  OFF - world chunks loaded up to render distance", "  ON - world chunks loaded at distance Far, allows", "       fast render distance switching" } : (s.equals("Preloaded Chunks") ? new String[] { "Defines an area in which no chunks will be loaded", "  OFF - after 5m new chunks will be loaded", "  2 - after 32m  new chunks will be loaded", "  8 - after 128m new chunks will be loaded", "Higher values need more time to load all the chunks", "and may decrease the FPS." } : (s.equals("Chunk Updates") ? new String[] { "Chunk updates", " 1 - (default) slower world loading, higher FPS", " 3 - faster world loading, lower FPS", " 5 - fastest world loading, lowest FPS", "Number of chunk updates per rendered frame,", "higher values may destabilize the framerate." } : (s.equals("Dynamic Updates") ? new String[] { "Dynamic chunk updates", " OFF - (default) standard chunk updates per frame", " ON - more updates while the player is standing still", "Dynamic updates force more chunk updates while", "the player is standing still to load the world faster." } : (s.equals("Lazy Chunk Loading") ? new String[] { "Lazy Chunk Loading", " OFF - default server chunk loading", " ON - lazy server chunk loading (smoother)", "Smooths the integrated server chunk loading by", "distributing the chunks over several ticks.", "Turn it OFF if parts of the world do not load correctly.", "Effective only for local worlds and single-core CPU." } : (s.equals("Fast Math") ? new String[] { "Fast Math", " OFF - standard math (default)", " ON - faster math", "Uses optimized sin() and cos() functions which can", "better utilize the CPU cache and increase the FPS." } : (s.equals("Fast Render") ? new String[] { "Fast Render", " OFF - standard rendering (default)", " ON - faster rendering", "Uses optimized rendering algorithm which decreases", "the GPU load and may substantionally increase the FPS.", "Not compatible with shaders and some other mods!" } : null)))))))));
    }
    
    private String lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        final int index = s.indexOf(58);
        return (index < 0) ? s : s.substring(0, index);
    }
    
    private lIIlIIIIlIIIIIllIIIIlIIll lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        for (int i = 0; i < this.IllIllIIIlIIlllIIIllIllII.size(); ++i) {
            final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll = this.IllIllIIIlIIlllIIIllIllII.get(i);
            final int liiiiiiiiIlIllIIllIlIIlIl = lIlIIIllIlIlIlIIlIlllIlII.lIIIIIIIIIlIllIIllIlIIlIl(liIlIIIIlIIIIIllIIIIlIIll);
            final int illlIIIlIlllIllIlIIlllIlI = lIlIIIllIlIlIlIIlIlllIlII.IlllIIIlIlllIllIlIIlllIlI(liIlIIIIlIIIIIllIIIIlIIll);
            if (n >= liIlIIIIlIIIIIllIIIIlIIll.IlIlIIIlllIIIlIlllIlIllIl && n2 >= liIlIIIIlIIIIIllIIIIlIIll.IIIllIllIlIlllllllIlIlIII && n < liIlIIIIlIIIIIllIIIIlIIll.IlIlIIIlllIIIlIlllIlIllIl + liiiiiiiiIlIllIIllIlIIlIl && n2 < liIlIIIIlIIIIIllIIIIlIIll.IIIllIllIlIlllllllIlIlIII + illlIIIlIlllIllIlIIlllIlI) {
                return liIlIIIIlIIIIIllIIIIlIIll;
            }
        }
        return null;
    }
    
    static {
        IIIIlllllllIIIllllllllIIl.IIIIllIlIIIllIlllIlllllIl = new lllIlIIIIlIIlIlIIlIlIlIll[] { lllIlIIIIlIIlIlIIlIlIlIll.lIIIlllIIIlIIIIIlIIIIIIII, lllIlIIIIlIIlIlIIlIlIlIll.IIIIIIIllIllllIIlIIlllIII, lllIlIIIIlIIlIlIIlIlIlIll.llllIIIIlIlIllIIIllllIIll, lllIlIIIIlIIlIlIIlIlIlIll.IIlIlIIlIIIlIlllllIIlIIlI, lllIlIIIIlIIlIlIIlIlIlIll.IIIllllIlIIlIIIlIlIlllIII, lllIlIIIIlIIlIlIIlIlIlIll.IIlIlllllIIIlIIllIllIlIlI, lllIlIIIIlIIlIlIIlIlIlIll.lllIllIlIllIlIllIIIIIIlll, lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIlIIllIlIlIllIIIIll, lllIlIIIIlIIlIlIIlIlIlIll.llllIIllllllIlIIlIlIIIllI };
    }
}
