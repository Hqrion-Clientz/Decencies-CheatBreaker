// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIllIIIIllllIIIlIlIIIlIlI implements llllIIlIllllllIlllIlIIIll
{
    protected int IIIIllIlIIIllIlllIlllllIl;
    
    public IIllIIIIllllIIIlIlIIIlIlI() {
        this.IIIIllIlIIIllIlllIlllllIl = -1;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        if (this.IIIIllIlIIIllIlllIlllllIl == -1) {
            this.IIIIllIlIIIllIlllIlllllIl = lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void unloadSounds() {
        if (this.IIIIllIlIIIllIlllIlllllIl != -1) {
            lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl);
            this.IIIIllIlIIIllIlllIlllllIl = -1;
        }
    }
}
