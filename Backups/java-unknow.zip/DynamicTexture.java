import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.5.36
// 

public class DynamicTexture extends IIllIIIIllllIIIlIlIIIlIlI
{
    private final int[] lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    
    public DynamicTexture(final BufferedImage bufferedImage) {
        this(bufferedImage.getWidth(), bufferedImage.getHeight());
        bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), this.lIIIIlIIllIIlIIlIIIlIIllI, 0, bufferedImage.getWidth());
        this.tick();
    }
    
    public DynamicTexture(final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = new int[liiiiiiiiIlIllIIllIlIIlIl * illlIIIlIlllIllIlIIlllIlI];
        lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(), liiiiiiiiIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
    }
    
    public void tick() {
        lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(), this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public int[] IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
