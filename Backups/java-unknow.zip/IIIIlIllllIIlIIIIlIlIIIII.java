import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIIlIllllIIlIIIIlIlIIIII
{
    BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage p0);
    
    void lIIIIlIIllIIlIIlIIIlIIllI();
}
