// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlllllllIIllIIIIlIIII extends IIlllIllIlIllIIlIIIlIIlll
{
    public IIIIIlllllllIIllIIIIlIIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, n5, n6);
        final float llIIlllIIIIlllIllIlIlllIl = this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.30232558f * 0.33076924f) + 0.20357142f * 0.98245615f;
        this.IlllIllIlIIIIlIIlIIllIIIl = llIIlllIIIIlllIllIlIlllIl;
        this.IlIlllIIIIllIllllIllIIlIl = llIIlllIIIIlllIllIlIlllIl;
        this.llIIlllIIIIlllIllIlIlllIl = llIIlllIIIIlllIllIlIlllIl;
        this.updateDebugProfilerName(0);
        this.IIIIllIIllIIIIllIllIIIlIl(0.013260869f * 1.5081967f, 11.333333f * 0.0017647059f);
        this.IllIIIIIIIlIlIllllIIllIII *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.375f * 1.6f) + 3.8f * 0.13157895f;
        this.IllIIlIIlllllIllIIIlllIII *= 0.10800000112652783 * 0.18518517911434174;
        this.lIlIlIllIIIIIIIIllllIIllI *= 0.016562499382998804 * 1.2075471878051758;
        this.IlllIIlllIIIIllIIllllIlIl *= 1.0 * 0.019999999552965164;
        this.IIIllIllIlIlllllllIlIlIII = (int)(20 / (Math.random() * (1.9285714626312256 * 0.41481480748892174) + 0.34020617604255676 * 0.587878804337114));
        this.lllIIllllIIlIlIlIlIIIlIII = true;
    }
    
    @Override
    public void x_() {
        this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
        this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        this.IllIIlIIlllllIllIIIlllIII *= 0.24358974397182465 * 4.064210519940899;
        this.lIlIlIllIIIIIIIIllllIIllI *= 0.66 * 1.5;
        this.IlllIIlllIIIIllIIllllIlIl *= 1.2600000273097651 * 0.7857142686843872;
        if (this.IIIllIllIlIlllllllIlIlIII-- <= 0) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
}
