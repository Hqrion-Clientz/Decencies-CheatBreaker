import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllIllIllllIIlIllIlII extends IIlIIlIIllIIllIlIIIIIIIlI
{
    public IIIIIllIllIllllIIlIllIlII(final int n) {
        super(n);
        this.IIllllIllllIIIlIIllllIlll.clear();
        this.IIIlIllIlllIlIllIllllllll = IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII;
        this.IIIlllllIIlIlIIIllllllIII.lIllIllIlIIllIllIlIlIIlIl = -999;
        this.IIIlllllIIlIlIIIllllllIII.IIIlIIlIlIIIlllIIlIllllll = 2;
        this.IIIlllllIIlIlIIIllllllIII.IllIlIlIllllIlIIllllIIlll = 50;
        this.IIIlllllIIlIlIIIllllllIII.IllIIlIIlllllIllIIIlllIII = 10;
        this.IIllllIllllIIIlIIllllIlll.clear();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, n, n2);
        if (random.nextInt(1000) == 0) {
            final int n3 = n + random.nextInt(16) + 8;
            final int n4 = n2 + random.nextInt(16) + 8;
            new llIIIIIIlIlIllllIIlIlIIll().a_(iiiiiIllIlIIIIlIlllIllllI, random, n3, iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n3, n4) + 1, n4);
        }
    }
}
