// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIlIIllIlIIIIllIllIIlIIl
{
    void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll p0);
    
    IlIIIllIIlIIlllIllllIIIIl lIIIIIIIIIlIllIIllIlIIlIl(final lIllIIIIlIIlIllIIIlIlIlll p0);
    
    String[] lIIIIIIIIIlIllIIllIlIIlIl();
}
