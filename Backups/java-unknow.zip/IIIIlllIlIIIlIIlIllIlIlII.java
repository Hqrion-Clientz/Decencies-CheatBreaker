// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIIlllIlIIIlIIlIllIlIlII
{
    public static final String[] lIIIIlIIllIIlIIlIIIlIIllI = { "oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO" };
    
    void lIIIIIIIIIlIllIIllIlIIlIl();
}
