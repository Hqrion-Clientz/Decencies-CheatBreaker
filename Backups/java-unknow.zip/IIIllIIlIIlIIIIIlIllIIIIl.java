import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveAction;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIlIIlIIIIIlIllIIIIl extends RecursiveAction
{
    private static final long lIIIIlIIllIIlIIlIIIlIIllI = 1L;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final int[] IIIIllIlIIIllIlllIlllllIl;
    private final int[] IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIllIIlIIlIIIIIlIllIIIIl(final int[] iiiIllIlIIIllIlllIlllllIl, final int[] iiiIllIIllIIIIllIllIIIlIl, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected void compute() {
        final int[] iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        final int[] iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl;
        final int n = this.IlllIIIlIlllIllIlIIlllIlI - this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n < 8192) {
            IlllIlIllIlllIlIIlIlllIll.IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI);
            return;
        }
        final int n2 = this.lIIIIIIIIIlIllIIllIlIIlIl + n / 2;
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        final int n3 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        final int n4 = n / 8;
        final int liiiiiiiiIlIllIIllIlIIlIl2 = IIIIllIIllIIIIllIllIIIlIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, IIIIllIIllIIIIllIllIIIlIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl + n4, liiiiiiiiIlIllIIllIlIIlIl + 2 * n4), IIIIllIIllIIIIllIllIIIlIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n2 - n4, n2, n2 + n4), IIIIllIIllIIIIllIllIIIlIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n3 - 2 * n4, n3 - n4, n3));
        final int n5 = iiiIllIlIIIllIlllIlllllIl[liiiiiiiiIlIllIIllIlIIlIl2];
        final int n6 = iiiIllIIllIIIIllIllIIIlIl[liiiiiiiiIlIllIIllIlIIlIl2];
        int liiiiiiiiIlIllIIllIlIIlIl3;
        int n7 = liiiiiiiiIlIllIIllIlIIlIl3 = this.lIIIIIIIIIlIllIIllIlIIlIl;
        int n9;
        int n8 = n9 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        while (true) {
            final int compare;
            final int n10;
            if (liiiiiiiiIlIllIIllIlIIlIl3 <= n8 && (n10 = (((compare = Integer.compare(iiiIllIlIIIllIlllIlllllIl[liiiiiiiiIlIllIIllIlIIlIl3], n5)) == 0) ? Integer.compare(iiiIllIIllIIIIllIllIIIlIl[liiiiiiiiIlIllIIllIlIIlIl3], n6) : compare)) <= 0) {
                if (n10 == 0) {
                    IlllIllIlIIIIlIIlIIllIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n7++, liiiiiiiiIlIllIIllIlIIlIl3);
                }
                ++liiiiiiiiIlIllIIllIlIIlIl3;
            }
            else {
                int compare2;
                int n11;
                while (n8 >= liiiiiiiiIlIllIIllIlIIlIl3 && (n11 = (((compare2 = Integer.compare(iiiIllIlIIIllIlllIlllllIl[n8], n5)) == 0) ? Integer.compare(iiiIllIIllIIIIllIllIIIlIl[n8], n6) : compare2)) >= 0) {
                    if (n11 == 0) {
                        IlllIllIlIIIIlIIlIIllIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n8, n9--);
                    }
                    --n8;
                }
                if (liiiiiiiiIlIllIIllIlIIlIl3 > n8) {
                    break;
                }
                IlllIllIlIIIIlIIlIIllIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl3++, n8--);
            }
        }
        final int min = Math.min(n7 - this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl3 - n7);
        IlIlIIIlllIIIlIlllIlIllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl3 - min, min);
        final int min2 = Math.min(n9 - n8, this.IlllIIIlIlllIllIlIIlllIlI - n9 - 1);
        IlIlIIIlllIIIlIlllIlIllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl3, this.IlllIIIlIlllIllIlIIlllIlI - min2, min2);
        final int n12 = liiiiiiiiIlIllIIllIlIIlIl3 - n7;
        final int n13 = n9 - n8;
        if (n12 > 1 && n13 > 1) {
            ForkJoinTask.invokeAll(new IIIllIIlIIlIIIIIlIllIIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n12), new IIIllIIlIIlIIIIIlIllIIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - n13, this.IlllIIIlIlllIllIlIIlllIlI));
        }
        else if (n12 > 1) {
            ForkJoinTask.invokeAll(new IIIllIIlIIlIIIIIlIllIIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n12));
        }
        else {
            ForkJoinTask.invokeAll(new IIIllIIlIIlIIIIIlIllIIIIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - n13, this.IlllIIIlIlllIllIlIIlllIlI));
        }
    }
}
