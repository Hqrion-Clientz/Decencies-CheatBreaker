// 
// Decompiled by Procyon v0.5.36
// 

final class IIlIIlIIIllIlIIIlIIIlIlll implements lllIIIlllllllIlIIIlIllIIl
{
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return entity instanceof IIlIIlIIllIllllllllIllIII && entity.IlIlllIIIIlIllIlllIlIIIll();
    }
}
