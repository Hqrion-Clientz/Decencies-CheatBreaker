import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.Map;
import java.util.HashMap;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIllIIlIlIIllllIIlIl
{
    private final Entity lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private static final HashMap IlllIIIlIlllIllIlIIlllIlI;
    private final Map IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    private ReadWriteLock IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIIllIllIIlIlIIllllIIlIl(final Entity liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = true;
        this.IIIIllIlIIIllIlllIlllllIl = new HashMap();
        this.IlIlIIIlllIIIlIlllIlIllIl = new ReentrantReadWriteLock();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Object o) {
        final Integer n2 = IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.get(o.getClass());
        if (n2 == null) {
            throw new IllegalArgumentException("Unknown data type: " + o.getClass());
        }
        if (n > 31) {
            throw new IllegalArgumentException("Data value id is too big with " + n + "! (Max is " + 31 + ")");
        }
        if (this.IIIIllIlIIIllIlllIlllllIl.containsKey(n)) {
            throw new IllegalArgumentException("Duplicate id value for " + n + "!");
        }
        final IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll = new IIlIIIllllIlIllllIllIlIll(n2, n, o);
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().lock();
        this.IIIIllIlIIIllIlllIlllllIl.put(n, ilIIIllllIlIllllIllIlIll);
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().unlock();
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int i, final int n) {
        final IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll = new IIlIIIllllIlIllllIllIlIll(n, i, null);
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().lock();
        this.IIIIllIlIIIllIlllIlllllIl.put(i, ilIIIllllIlIllllIllIlIll);
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().unlock();
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
    }
    
    public byte lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return (byte)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public short lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return (short)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return (int)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public float IIIIllIlIIIllIlllIlllllIl(final int n) {
        return (float)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public String IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return (String)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        return (lIlIlIlIlIllllIlllIIIlIlI)this.IllIIIIIIIlIlIllllIIllIII(n).lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    private IIlIIIllllIlIllllIllIlIll IllIIIIIIIlIlIllllIIllIII(final int n) {
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().lock();
        IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll;
        try {
            ilIIIllllIlIllllIllIlIll = this.IIIIllIlIIIllIlllIlllllIl.get(n);
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Getting synched entity data");
            crashReport.makeCategory("Synched entity data").lIIIIlIIllIIlIIlIIIlIIllI("Data ID", n);
            throw new ReportedException(crashReport);
        }
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().unlock();
        return ilIIIllllIlIllllIllIlIll;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final Object o) {
        final IIlIIIllllIlIllllIllIlIll illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII(n);
        if (ObjectUtils.notEqual(o, illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl())) {
            illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(o);
            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl(n);
            illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(true);
            this.IIIIllIIllIIIIllIllIIIlIl = true;
        }
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final int n) {
        this.IllIIIIIIIlIlIllllIIllIII(n).IIIIllIlIIIllIlllIlllllIl = true;
        this.IIIIllIIllIIIIllIllIIIlIl = true;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final List list, final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        if (list != null) {
            final Iterator<IIlIIIllllIlIllllIllIlIll> iterator = list.iterator();
            while (iterator.hasNext()) {
                lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII, iterator.next());
            }
        }
        lIlIllllllllIlIIIllIIllII.writeByte(127);
    }
    
    public List lIIIIIIIIIlIllIIllIlIIlIl() {
        ArrayList<IIlIIIllllIlIllllIllIlIll> list = null;
        if (this.IIIIllIIllIIIIllIllIIIlIl) {
            this.IlIlIIIlllIIIlIlllIlIllIl.readLock().lock();
            for (final IIlIIIllllIlIllllIllIlIll e : this.IIIIllIlIIIllIlllIlllllIl.values()) {
                if (e.IIIIllIlIIIllIlllIlllllIl()) {
                    e.lIIIIlIIllIIlIIlIIIlIIllI(false);
                    if (list == null) {
                        list = new ArrayList<IIlIIIllllIlIllllIllIlIll>();
                    }
                    list.add(e);
                }
            }
            this.IlIlIIIlllIIIlIlllIlIllIl.readLock().unlock();
        }
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        return list;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().lock();
        final Iterator<IIlIIIllllIlIllllIllIlIll> iterator = this.IIIIllIlIIIllIlllIlllllIl.values().iterator();
        while (iterator.hasNext()) {
            lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII, iterator.next());
        }
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().unlock();
        lIlIllllllllIlIIIllIIllII.writeByte(127);
    }
    
    public List IlllIIIlIlllIllIlIIlllIlI() {
        ArrayList<IIlIIIllllIlIllllIllIlIll> list = null;
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().lock();
        for (final IIlIIIllllIlIllllIllIlIll e : this.IIIIllIlIIIllIlllIlllllIl.values()) {
            if (list == null) {
                list = new ArrayList<IIlIIIllllIlIllllIllIlIll>();
            }
            list.add(e);
        }
        this.IlIlIIIlllIIIlIlllIlIllIl.readLock().unlock();
        return list;
    }
    
    private static void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII, final IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll) {
        lIlIllllllllIlIIIllIIllII.writeByte((ilIIIllllIlIllllIllIlIll.IlllIIIlIlllIllIlIIlllIlI() << 5 | (ilIIIllllIlIllllIllIlIll.lIIIIlIIllIIlIIlIIIlIIllI() & 0x1F)) & 0xFF);
        switch (ilIIIllllIlIllllIllIlIll.IlllIIIlIlllIllIlIIlllIlI()) {
            case 0: {
                lIlIllllllllIlIIIllIIllII.writeByte((byte)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 1: {
                lIlIllllllllIlIIIllIIllII.writeShort((short)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 2: {
                lIlIllllllllIlIIIllIIllII.writeInt((int)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 3: {
                lIlIllllllllIlIIIllIIllII.writeFloat((float)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 4: {
                lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI((String)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 5: {
                lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI((lIlIlIlIlIllllIlllIIIlIlI)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                break;
            }
            case 6: {
                final IlllIllllIIIIIlIlIlIIIllI illlIllllIIIIIlIlIlIIIllI = (IlllIllllIIIIIlIlIlIIIllI)ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl();
                lIlIllllllllIlIIIllIIllII.writeInt(illlIllllIIIIIlIlIlIIIllI.lIIIIlIIllIIlIIlIIIlIIllI);
                lIlIllllllllIlIIIllIIllII.writeInt(illlIllllIIIIIlIlIlIIIllI.lIIIIIIIIIlIllIIllIlIIlIl);
                lIlIllllllllIlIIIllIIllII.writeInt(illlIllllIIIIIlIlIlIIIllI.IlllIIIlIlllIllIlIIlllIlI);
                break;
            }
        }
    }
    
    public static List lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        ArrayList<Object> list = null;
        for (byte b = lIlIllllllllIlIIIllIIllII.readByte(); b != 127; b = lIlIllllllllIlIIIllIIllII.readByte()) {
            if (list == null) {
                list = new ArrayList<Object>();
            }
            final int n = (b & 0xE0) >> 5;
            final int n2 = b & 0x1F;
            Object e = null;
            switch (n) {
                case 0: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.readByte());
                    break;
                }
                case 1: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.readShort());
                    break;
                }
                case 2: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.readInt());
                    break;
                }
                case 3: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.readFloat());
                    break;
                }
                case 4: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32767));
                    break;
                }
                case 5: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 6: {
                    e = new IIlIIIllllIlIllllIllIlIll(n, n2, new IlllIllllIIIIIlIlIlIIIllI(lIlIllllllllIlIIIllIIllII.readInt(), lIlIllllllllIlIIIllIIllII.readInt(), lIlIllllllllIlIIIllIIllII.readInt()));
                    break;
                }
            }
            list.add(e);
        }
        return list;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final List list) {
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().lock();
        for (final IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll : list) {
            final IIlIIIllllIlIllllIllIlIll ilIIIllllIlIllllIllIlIll2 = this.IIIIllIlIIIllIlllIlllllIl.get(ilIIIllllIlIllllIllIlIll.lIIIIlIIllIIlIIlIIIlIIllI());
            if (ilIIIllllIlIllllIllIlIll2 != null) {
                ilIIIllllIlIllllIllIlIll2.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllllIlIllllIllIlIll.lIIIIIIIIIlIllIIllIlIIlIl());
                this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl(ilIIIllllIlIllllIllIlIll.lIIIIlIIllIIlIIlIIIlIIllI());
            }
        }
        this.IlIlIIIlllIIIlIlllIlIllIl.writeLock().unlock();
        this.IIIIllIIllIIIIllIllIIIlIl = true;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl() {
        this.IIIIllIIllIIIIllIllIIIlIl = false;
    }
    
    static {
        (IlllIIIlIlllIllIlIIlllIlI = new HashMap()).put(Byte.class, 0);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(Short.class, 1);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(Integer.class, 2);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(Float.class, 3);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(String.class, 4);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(lIlIlIlIlIllllIlllIIIlIlI.class, 5);
        IIIIllIllIIlIlIIllllIIlIl.IlllIIIlIlllIllIlIIlllIlI.put(IlllIllllIIIIIlIlIlIIIllI.class, 6);
    }
}
