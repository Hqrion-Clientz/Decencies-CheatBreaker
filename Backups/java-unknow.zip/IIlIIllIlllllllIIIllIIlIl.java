// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlllllllIIIllIIlIl extends IIlIIlIIllIIllIlIIIIIIIlI
{
    public IIlIIllIlllllllIIIllIIlIl(final int n) {
        super(n);
        this.IIllllIllllIIIlIIllllIlll.clear();
        this.IIIlIllIlllIlIllIllllllll = IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        this.IIIlllllIIlIlIIIllllllIII.lIllIllIlIIllIllIlIlIIlIl = -999;
        this.IIIlllllIIlIlIIIllllllIII.IIIlIIlIlIIIlllIIlIllllll = 0;
        this.IIIlllllIIlIlIIIllllllIII.IllIlIlIllllIlIIllllIIlll = 0;
        this.IIIlllllIIlIlIIIllllllIII.IllIIlIIlllllIllIIIlllIII = 0;
    }
}
