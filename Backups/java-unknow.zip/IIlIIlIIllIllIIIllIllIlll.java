import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIllIllIIIllIllIlll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "gamemode";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.gamemode.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length > 0) {
            final IllIIlIIlIlIIllllIIIlIlII illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII(lIlllllIIIIIIllIlIIlIlIII, array[0]);
            final llIIIIIIlIlllllIIllllIlII llIIIIIIlIlllllIIllllIlII = (array.length >= 2) ? IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[1]) : IlIIIllllllIllIlllllIIllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII);
            llIIIIIIlIlllllIIllllIlII.lIIIIlIIllIIlIIlIIIlIIllI(illIIIIIIIlIlIllllIIllIII);
            llIIIIIIlIlllllIIllllIlII.IllllllIllllIIlllIllllllI = 0.0f;
            final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl = new IIIlIlIIIlllllIIlllIIIlIl("gameMode." + illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl(), new Object[0]);
            if (llIIIIIIlIlllllIIllllIlII != lIlllllIIIIIIllIlIIlIlIII) {
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, 1, "commands.gamemode.success.other", llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII(), iiIlIlIIIlllllIIlllIIIlIl);
            }
            else {
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, 1, "commands.gamemode.success.self", iiIlIlIIIlllllIIlllIIIlIl);
            }
            return;
        }
        throw new IIllllIlIlIIlllIlIIllIIll("commands.gamemode.usage", new Object[0]);
    }
    
    protected IllIIlIIlIlIIllllIIIlIlII IllIIIIIIIlIlIllllIIllIII(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String s) {
        return (!s.equalsIgnoreCase(IllIIlIIlIlIIllllIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl()) && !s.equalsIgnoreCase("s")) ? ((!s.equalsIgnoreCase(IllIIlIIlIlIIllllIIIlIlII.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl()) && !s.equalsIgnoreCase("c")) ? ((!s.equalsIgnoreCase(IllIIlIIlIlIIllllIIIlIlII.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl()) && !s.equalsIgnoreCase("a")) ? lIIIlIlllllIIlIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, s, 0, IllIIlIIlIlIIllllIIIlIlII.values().length - 2)) : IllIIlIIlIlIIllllIIIlIlII.IIIIllIlIIIllIlllIlllllIl) : IllIIlIIlIlIIllllIIIlIlII.IlllIIIlIlllIllIlIIlllIlI) : IllIIlIIlIlIIllllIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, "survival", "creative", "adventure") : ((array.length == 2) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl()) : null);
    }
    
    protected String[] IIIIllIlIIIllIlllIlllllIl() {
        return llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 1;
    }
}
