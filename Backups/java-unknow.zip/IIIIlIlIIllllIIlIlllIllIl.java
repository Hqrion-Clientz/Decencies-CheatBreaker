// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIIllllIIlIlllIllIl extends IIlIIlIIllIIllIlIIIIIIIlI
{
    public IIIIlIlIIllllIIlIlllIllIl(final int n) {
        super(n);
        this.IIllllIllllIIIlIIllllIlll.clear();
        this.IIIlIllIlllIlIllIllllllll = IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII;
        this.IIIlllllIIlIlIIIllllllIII.lIllIllIlIIllIllIlIlIIlIl = -999;
        this.IIIlllllIIlIlIIIllllllIII.IIIlIIlIlIIIlllIIlIllllll = 0;
        this.IIIlllllIIlIlIIIllllllIII.IllIlIlIllllIlIIllllIIlll = 0;
        this.IIIlllllIIlIlIIIllllllIII.IllIIlIIlllllIllIIIlllIII = 0;
    }
}
