import java.util.Iterator;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import gnu.trove.map.hash.TIntObjectHashMap;
import org.apache.logging.log4j.LogManager;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.BiMap;
import java.util.Map;
import gnu.trove.map.TIntObjectMap;

// 
// Decompiled by Procyon v0.5.36
// 

public enum EnumConnectionState
{
    lIIIIlIIllIIlIIlIIIlIIllI("HANDSHAKING", 0, "HANDSHAKING", 0, -1, (Object)null) {
        {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, lllllIlIIIlIlIllIlIIlIIIl.class);
        }
    }, 
    lIIIIIIIIIlIllIIllIlIIlIl("PLAY", 1, "PLAY", 1, 0, (Object)null) {
        {
            this.lIIIIIIIIIlIllIIllIlIIlIl(0, lIllIllIIIIlIIlIlllllIlll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(1, IllIlIllIlIIIIllIIllIlIlI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(2, IIlIIlIIlIIIIlIIIIlllIlll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(3, IlllIllIIlIllIIlIlllIllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(4, IIIIlllllIllIIIIlIlIlllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(5, llllIIlllIIIIIIIIlllIllll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(6, IlIIIlIIIIllllIlIIllIllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(7, lIllllIIIIlIIlIIlllIIIlll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(8, IlIIllIIIllIIlIIIllIIlIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(9, lllIIlIlIllllllllllIIllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(10, IlIlllllIIIIIlIIllIlllIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(11, lIIIIllIlllIlIlIllIlIIlIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(12, lllIlIllIIlIIIlIIIlIIIIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(13, IIIllIlIIlIlIllllIlIIllll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(14, llIIIIIlIIlIIIIllIIIlIIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(15, lllIIllIlIlllIIIlllllIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(16, IllIIlIIlIIlIIIIIlIIIlIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(17, llIIlIIIIlIllllIIllIIlllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(18, lIlllllllllIlIllIIIIIIIlI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(19, lllIIIlIllIlllIlIIllIllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(20, llIIIIIIlllIIlIlIIllIIlII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(21, IllIIIlIIlllIIIIllIlllIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(22, IlIIlllIlllIIIllIIIIIIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(23, IIIIlllIllIllllIlIlIlIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(24, IIllIIIlIIlIIlIlIIllIlIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(25, lllllIIIIlIIlIlllllllIlIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(26, IIIIllIlIIlllIlIlIlIIIIIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(27, IIllllIlIIlIIIlIIIIIlIlII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(28, lIllIIlllllllIIlIIlllIlII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(29, llIIllIIllIlIIIlIIlllIIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(30, lIlIIlIIlIIlIllIlIIIIIlIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(31, IlIllllIIllIIIIIIllllIIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(32, IIlIllIIlIIlIllIllIIIIlIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(33, lIIlllIIllIIlllllIIIIlIIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(34, IIIlllIIllllIIIIIIIIllllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(35, lIIIIllllIlIIIlIllIIlIlIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(36, lIIIllllIIIlIIIlIIIlllIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(37, IIlIlIlIIIlIIllIlIIIIlllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(38, llllIllIllllIlIIlIIIlIIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(39, lllIIlIlIIlIIllIIIIIlllll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(40, llIllIlllllIllIIIIllIlllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(41, IlllIlIlIllIlllIlIlIlIIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(42, IlllllIIlIIIIllIIIlIllIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(43, llIIIIIlllIlIlIlIIIIllllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(44, lIllIlIlIIllIlIllIllllIIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(45, lIIIlllIIIlIIllIlllllIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(46, lIllIIIlIlIIIIIllIlIIIIlI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(47, IlIIIIIIIIIlllIIllllIlIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(48, IIllIlllIlIlIIIIlIIIIllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(49, llIlllIIllllIIIllIlIlllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(50, IIlIIllIllllllIIIlllIllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(51, IIlIlIIllIlllIllIlIlIllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(52, IllIlIIllIlIIllIIllIIllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(53, IIIIlIllIIIIIIIIllIlIIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(54, IIllllllllIlllIIllllllllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(55, IIlIIIIIIlllIlIIllIIIllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(56, IllIIlllllIlllIlIllIlIIlI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(57, lIIlllIIIIlIIIIllIIlllllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(58, lllIlllIIIllllllllllIIllI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(59, llllIIlIllIlllIIlIIllIlll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(60, IIIlIIIlIlIIlIlllIllIlIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(61, lIIlIIllIIllIIIllIIIIIIII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(62, IIlIllIlllIIllllIIIllllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(63, IllIIIIllIIIIIIIIIIlIllIl.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(64, IlIlIllIIIllIIIIllIllIlII.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, lIlIIIIlIIIIlIIIIllIIlllI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, IlllIIIIIIIlIIIlIIIlllIlI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(2, IlIlllIIIlIlllllIIllIIlll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(3, IlIIllIIIIIIlIIIllIIllIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(4, lIIIIllllIIllllIllIlIIlIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(5, lIIllllllIlllIlllIIIIIlll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(6, IllIIIIIllllIlIlllllIIIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(7, lIllIIIIllllIlIlIIIIllIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(8, IIIIIllIIIIIlIIIIllIIIIlI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(9, lllIIIlIIlIIlIIllIlIlIIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(10, llIIIllIlIIIIlIllIlllIlII.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(11, IIIIIIIIIIIIllIllIIIlIllI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(12, IllllIIlllIIIlIlllllIlIII.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(13, IlIIIllIllllllIlIIIlIIlll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(14, lIIlIIlIlIlllIIllllIlIIll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(15, llIIlllllllIllIIIIlIllIII.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(16, lIIIIIIllllIIlIlIllIlIIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(17, IllIlIIlIIlIIlllIIIlIIIIl.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(18, IlIIllllIIllllIIllIllllll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(19, llIlIllIIllllllllllIIIIlI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(20, IIIlIllIlIIlIlIIIlIlIlIll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(21, IllllIIlIlllIIIlIllIlIIlI.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(22, IlIIIIIlIlllllIlIlllIIlll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(23, lIIlIlllIlIllIlIlIllllIlI.class);
        }
    }, 
    IlllIIIlIlllIllIlIIlllIlI("STATUS", 2, "STATUS", 2, 1, (Object)null) {
        {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, lIIIIIllIlIlIIIIIIIIlllII.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(0, IlIIIIIIIIIIIIIIIllIIIIll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, IIlIllIIIIlIlIIIIllIIlIlI.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(1, llllIIlIllllIllIllllllIlI.class);
        }
    }, 
    IIIIllIlIIIllIlllIlllllIl("LOGIN", 3, "LOGIN", 3, 2, (Object)null) {
        {
            this.lIIIIIIIIIlIllIIllIlIIlIl(0, IIllIIllIlllIIIIlIIIlIlll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(1, lIlIlIlllIlIlllllIIIIIIll.class);
            this.lIIIIIIIIIlIllIIllIlIIlIl(2, IlIIlIlIIllIllIlIllIIIIII.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, IlllIIllIIlIlIIlIIIlllIll.class);
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, IllIlIIllIIlIlIIIIIlIllII.class);
        }
    };
    
    private static final TIntObjectMap IIIIllIIllIIIIllIllIIIlIl;
    private static final Map IlIlIIIlllIIIlIlllIlIllIl;
    private final int IIIllIllIlIlllllllIlIlIII;
    private final BiMap IllIIIIIIIlIlIllllIIllIII;
    private final BiMap lIIIIllIIlIlIllIIIlIllIlI;
    
    private EnumConnectionState(final String name, final int ordinal, final int iiIllIllIlIlllllllIlIlIII) {
        this.IllIIIIIIIlIlIllllIIllIII = (BiMap)HashBiMap.create();
        this.lIIIIllIIlIlIllIIIlIllIlI = (BiMap)HashBiMap.create();
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
    
    protected EnumConnectionState lIIIIlIIllIIlIIlIIIlIIllI(final int i, final Class clazz) {
        if (this.IllIIIIIIIlIlIllllIIllIII.containsKey((Object)i)) {
            final String string = "Serverbound packet ID " + i + " is already assigned to " + this.IllIIIIIIIlIlIllllIIllIII.get((Object)i) + "; cannot re-assign to " + clazz;
            LogManager.getLogger().fatal(string);
            throw new IllegalArgumentException(string);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.containsValue((Object)clazz)) {
            final String string2 = "Serverbound packet " + clazz + " is already assigned to ID " + this.IllIIIIIIIlIlIllllIIllIII.inverse().get((Object)clazz) + "; cannot re-assign to " + i;
            LogManager.getLogger().fatal(string2);
            throw new IllegalArgumentException(string2);
        }
        this.IllIIIIIIIlIlIllllIIllIII.put((Object)i, (Object)clazz);
        return this;
    }
    
    protected EnumConnectionState lIIIIIIIIIlIllIIllIlIIlIl(final int i, final Class clazz) {
        if (this.lIIIIllIIlIlIllIIIlIllIlI.containsKey((Object)i)) {
            final String string = "Clientbound packet ID " + i + " is already assigned to " + this.lIIIIllIIlIlIllIIIlIllIlI.get((Object)i) + "; cannot re-assign to " + clazz;
            LogManager.getLogger().fatal(string);
            throw new IllegalArgumentException(string);
        }
        if (this.lIIIIllIIlIlIllIIIlIllIlI.containsValue((Object)clazz)) {
            final String string2 = "Clientbound packet " + clazz + " is already assigned to ID " + this.lIIIIllIIlIlIllIIIlIllIlI.inverse().get((Object)clazz) + "; cannot re-assign to " + i;
            LogManager.getLogger().fatal(string2);
            throw new IllegalArgumentException(string2);
        }
        this.lIIIIllIIlIlIllIIIlIllIlI.put((Object)i, (Object)clazz);
        return this;
    }
    
    public BiMap lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public BiMap lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public BiMap lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        return b ? this.lIIIIIIIIIlIllIIllIlIIlIl() : this.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public BiMap lIIIIIIIIIlIllIIllIlIIlIl(final boolean b) {
        return b ? this.lIIIIlIIllIIlIIlIIIlIIllI() : this.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public static EnumConnectionState lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return (EnumConnectionState)EnumConnectionState.IIIIllIIllIIIIllIllIIIlIl.get(n);
    }
    
    public static EnumConnectionState lIIIIlIIllIIlIIlIIIlIIllI(final IIllIlllIIlllllIlllIIIlIl illIlllIIlllllIlllIIIlIl) {
        return EnumConnectionState.IlIlIIIlllIIIlIlllIlIllIl.get(illIlllIIlllllIlllIIIlIl.getClass());
    }
    
    private EnumConnectionState(final String s, final int n, final String s2, final int n2, final int n3, final Object o) {
        this(s, n, n3);
    }
    
    static {
        IIIIllIIllIIIIllIllIIIlIl = (TIntObjectMap)new TIntObjectHashMap();
        IlIlIIIlllIIIlIlllIlIllIl = Maps.newHashMap();
        for (final EnumConnectionState obj : values()) {
            EnumConnectionState.IIIIllIIllIIIIllIllIIIlIl.put(obj.IlllIIIlIlllIllIlIIlllIlI(), (Object)obj);
            for (final Class obj2 : Iterables.concat((Iterable)obj.lIIIIIIIIIlIllIIllIlIIlIl().values(), (Iterable)obj.lIIIIlIIllIIlIIlIIIlIIllI().values())) {
                if (EnumConnectionState.IlIlIIIlllIIIlIlllIlIllIl.containsKey(obj2) && EnumConnectionState.IlIlIIIlllIIIlIlllIlIllIl.get(obj2) != obj) {
                    throw new Error("Packet " + obj2 + " is already assigned to protocol " + EnumConnectionState.IlIlIIIlllIIIlIlllIlIllIl.get(obj2) + " - can't reassign to " + obj);
                }
                EnumConnectionState.IlIlIIIlllIIIlIlllIlIllIl.put(obj2, obj);
            }
        }
    }
}
