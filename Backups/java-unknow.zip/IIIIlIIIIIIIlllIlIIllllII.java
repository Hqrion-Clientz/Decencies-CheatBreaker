import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIIIIIlllIlIIllllII implements Comparator
{
    private EntityLivingBase lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIlIIIIIIIlllIlIIllllII(final EntityLivingBase liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final WorldRenderer worldRenderer, final WorldRenderer worldRenderer2) {
        if (worldRenderer.llIlIIIlIIIIlIlllIlIIIIll && !worldRenderer2.llIlIIIlIIIIlIlllIlIIIIll) {
            return 1;
        }
        if (worldRenderer2.llIlIIIlIIIIlIlllIlIIIIll && !worldRenderer.llIlIIIlIIIIlIlllIlIIIIll) {
            return -1;
        }
        final double n = worldRenderer.lIIIIlIIllIIlIIlIIIlIIllI((Entity)this.lIIIIlIIllIIlIIlIIIlIIllI);
        final double n2 = worldRenderer2.lIIIIlIIllIIlIIlIIIlIIllI((Entity)this.lIIIIlIIllIIlIIlIIIlIIllI);
        return (n < n2) ? 1 : ((n > n2) ? -1 : ((worldRenderer.lIIlIIllIIIIIlIllIIIIllII < worldRenderer2.lIIlIIllIIIIIlIllIIIIllII) ? 1 : -1));
    }
    
    @Override
    public int compare(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((WorldRenderer)o, (WorldRenderer)o2);
    }
}
