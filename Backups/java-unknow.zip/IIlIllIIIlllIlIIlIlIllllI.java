// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIlllIlIIlIlIllllI
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private IIlllllllIlllIIllllIIlIll IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIllIIIlllIlIIlIlIllllI(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final IIlllllllIlllIIllllIIlIll iiiIllIlIIIllIlllIlllllIl, final int iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public IIlllllllIlllIIllllIIlIll IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof IIlIllIIIlllIlIIlIlIllllI)) {
            return false;
        }
        final IIlIllIIIlllIlIIlIlIllllI ilIllIIIlllIlIIlIlIllllI = (IIlIllIIIlllIlIIlIlIllllI)o;
        return this.lIIIIlIIllIIlIIlIIIlIIllI == ilIllIIIlllIlIIlIlIllllI.lIIIIlIIllIIlIIlIIIlIIllI && this.lIIIIIIIIIlIllIIllIlIIlIl == ilIllIIIlllIlIIlIlIllllI.lIIIIIIIIIlIllIIllIlIIlIl && this.IlllIIIlIlllIllIlIIlllIlI == ilIllIIIlllIlIIlIlIllllI.IlllIIIlIlllIllIlIIlllIlI && this.IIIIllIIllIIIIllIllIIIlIl == ilIllIIIlllIlIIlIlIllllI.IIIIllIIllIIIIllIllIIIlIl && this.IlIlIIIlllIIIlIlllIlIllIl == ilIllIIIlllIlIIlIlIllllI.IlIlIIIlllIIIlIlllIlIllIl && this.IIIIllIlIIIllIlllIlllllIl == ilIllIIIlllIlIIlIlIllllI.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public String toString() {
        return "TE(" + this.lIIIIlIIllIIlIIlIIIlIIllI + "," + this.lIIIIIIIIIlIllIIllIlIIlIl + "," + this.IlllIIIlIlllIllIlIIlllIlI + ")," + this.IIIIllIIllIIIIllIllIIIlIl + "," + this.IlIlIIIlllIIIlIlllIlIllIl + "," + this.IIIIllIlIIIllIlllIlllllIl;
    }
}
