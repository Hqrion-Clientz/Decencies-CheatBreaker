import org.apache.logging.log4j.LogManager;
import com.google.common.collect.Sets;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.opengl.GL11;
import java.util.Collection;
import com.google.common.collect.Lists;
import com.google.common.base.Splitter;
import java.util.Iterator;
import java.awt.Desktop;
import java.net.URLConnection;
import java.awt.image.BufferedImage;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStreamWriter;
import org.apache.commons.codec.binary.Base64;
import java.net.URLEncoder;
import java.net.URL;
import java.io.OutputStream;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;
import java.io.File;
import java.net.URISyntaxException;
import org.lwjgl.input.Mouse;
import org.lwjgl.input.Keyboard;
import java.util.ArrayList;
import java.net.URI;
import java.util.List;
import org.apache.logging.log4j.Logger;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiChat extends GuiScreen implements IlIllIlIIllIIIlIIlllllllI
{
    private static final Set lIIIIIIIIIlIllIIllIlIIlIl;
    private static final Logger IlllIIIlIlllIllIlIIlllIlI;
    private String IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private boolean IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private List lIIIIllIIlIlIllIIIlIllIlI;
    private URI IlllIllIlIIIIlIIlIIllIIIl;
    protected IIIIIllIIlIlIlIIlIlIlIllI lIIIIlIIllIIlIIlIIIlIIllI;
    private String IlIlllIIIIllIllllIllIIlIl;
    
    public GuiChat() {
        this.IIIIllIlIIIllIlllIlllllIl = "";
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.lIIIIllIIlIlIllIIIlIllIlI = new ArrayList();
        this.IlIlllIIIIllIllllIllIIlIl = "";
    }
    
    public GuiChat(final String ilIlllIIIIllIllllIllIIlIl) {
        this.IIIIllIlIIIllIlllIlllllIl = "";
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.lIIIIllIIlIlIllIIIlIllIlI = new ArrayList();
        this.IlIlllIIIIllIllllIllIIlIl = "";
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
    }
    
    @Override
    public void s_() {
        Keyboard.enableRepeatEvents(true);
        this.IIIIllIIllIIIIllIllIIIlIl = this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().IlllIIIlIlllIllIlIIlllIlI().size();
        (this.lIIIIlIIllIIlIIlIIIlIIllI = new IIIIIllIIlIlIlIIlIlIlIllI(this.lIIlllIIlIlllllllllIIIIIl, 4, this.IIIIIIlIlIlIllllllIlllIlI - 12, this.lIIIIIllllIIIIlIlIIIIlIlI - 4, 12)).IlIlIIIlllIIIlIlllIlIllIl(100);
        this.lIIIIlIIllIIlIIlIIIlIIllI.sendClickBlockToController(false);
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI.setSection(this.IlIlllIIIIllIllllIllIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(false);
    }
    
    @Override
    public void t_() {
        Keyboard.enableRepeatEvents(false);
        this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().IIIIllIlIIIllIlllIlllllIl();
    }
    
    @Override
    public void updateScreen() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.updateTick();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        this.lllIIIIIlIllIlIIIllllllII.updateScreen();
        this.IIIllIllIlIlllllllIlIlIII = false;
        if (n == 15) {
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        else {
            this.IlIlIIIlllIIIlIlllIlIllIl = false;
        }
        if (n == 1) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
        }
        else if (n != 28 && n != 156) {
            if (n == 200) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(-1);
            }
            else if (n == 208) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(1);
            }
            else if (n == 201) {
                this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().updateDebugProfilerName(this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIllIIlIlIllIIIlIllIlI() - 1);
            }
            else if (n == 209) {
                this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().updateDebugProfilerName(-this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIllIIlIlIllIIIlIllIlI() + 1);
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
            }
        }
        else {
            final String trim = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().trim();
            if (trim.length() > 0) {
                this.setSection(trim);
            }
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
        }
    }
    
    public void setSection(final String section) {
        this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().setSection(section);
        this.lllIIIIIlIllIlIIIllllllII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl(section);
    }
    
    @Override
    public void handleMouseInput() {
        super.handleMouseInput();
        int eventDWheel = Mouse.getEventDWheel();
        if (eventDWheel != 0) {
            if (eventDWheel > 1) {
                eventDWheel = 1;
            }
            if (eventDWheel < -1) {
                eventDWheel = -1;
            }
            if (!GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                eventDWheel *= 7;
            }
            this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().updateDebugProfilerName(eventDWheel);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (n3 == 0 && this.lllIIIIIlIllIlIIIllllllII.gameSettings.IIllllIIIIllIIlIllIIIIIlI) {
            final IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI = this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(Mouse.getX(), Mouse.getY());
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                final IIlIlllIlIllllIIIIlIlllIl illIIIIIIIlIlIllllIIllIII = liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().IllIIIIIIIlIlIllllIIllIII();
                if (illIIIIIIIlIlIllllIIllIII != null) {
                    if (lIllIlIlllIIlIIllIIlIIlII()) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl());
                    }
                    else if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IllIIIIIIlIIlIIllIllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI) {
                        try {
                            final URI illlIllIlIIIIlIIlIIllIIIl = new URI(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl());
                            if (!GuiChat.lIIIIIIIIIlIllIIllIlIIlIl.contains(illlIllIlIIIIlIIlIIllIIIl.getScheme().toLowerCase())) {
                                throw new URISyntaxException(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl(), "Unsupported protocol: " + illlIllIlIIIIlIIlIIllIIIl.getScheme().toLowerCase());
                            }
                            if (this.lllIIIIIlIllIlIIIllllllII.gameSettings.lIllIllIllllllIllIlllIlIl) {
                                this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
                                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IIlIIIIllIllllIlIIlIIlIII(this, illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl(), 0, false));
                            }
                            else {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(illlIllIlIIIIlIIlIIllIIIl);
                            }
                        }
                        catch (URISyntaxException ex) {
                            GuiChat.IlllIIIlIlllIllIlIIlllIlI.error("Can't open url for " + illIIIIIIIlIlIllllIIllIII, (Throwable)ex);
                        }
                    }
                    else if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IllIIIIIIlIIlIIllIllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(new File(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl()).toURI());
                    }
                    else if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IllIIIIIIlIIlIIllIllIIIIl.IIIIllIIllIIIIllIllIIIlIl) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI.setSection(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl());
                    }
                    else if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IllIIIIIIlIIlIIllIllIIIIl.IlllIIIlIlllIllIlIIlllIlI) {
                        this.setSection(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl());
                    }
                    else if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IllIIIIIIlIIlIIllIllIIIIl.IlIlIIIlllIIIlIlllIlIllIl) {
                        this.lIIIIIIIIIlIllIIllIlIIlIl(illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl());
                    }
                    else {
                        GuiChat.IlllIIIlIlllIllIlIIlllIlI.error("Don't know how to handle " + illIIIIIIIlIlIllllIIllIII);
                    }
                    return;
                }
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final String str) {
        if (new File(this.lllIIIIIlIllIlIIIllllllII.mcDataDir + File.separator + "screenshots" + File.separator + str).exists()) {
            GuiIngame.lIIIIIIIIIlIllIIllIlIIlIl = true;
            final File input;
            ByteArrayOutputStream output;
            final BufferedImage im;
            URL url;
            final URLConnection urlConnection;
            OutputStreamWriter outputStreamWriter;
            final String str2;
            StringBuilder sb;
            final BufferedReader bufferedReader2;
            final Object o;
            final String str3;
            final String str4;
            IIlIIIIllIllllIlIIlIIlIII ilIIIIllIllllIlIIlIIlIII;
            new Thread(() -> {
                try {
                    ImageIO.read(input);
                    output = new ByteArrayOutputStream();
                    ImageIO.write(im, "png", output);
                    url = new URL("https://api.imgur.com/3/upload");
                    new StringBuilder().append(URLEncoder.encode("image", "UTF-8") + "=" + URLEncoder.encode(Base64.encodeBase64String(output.toByteArray()), "UTF-8")).append("&").append(URLEncoder.encode("key", "UTF-8")).append("=").append(URLEncoder.encode("82876e209fa1a37", "UTF-8")).toString();
                    url.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setDoInput(true);
                    urlConnection.setRequestProperty("Authorization", "Client-ID 82876e209fa1a37");
                    urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    outputStreamWriter = new OutputStreamWriter(urlConnection.getOutputStream());
                    outputStreamWriter.write(str2);
                    outputStreamWriter.flush();
                    new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    sb = new StringBuilder();
                    while (true) {
                        bufferedReader2.readLine();
                        if (o != null) {
                            sb.append(str3).append(System.lineSeparator());
                        }
                        else {
                            break;
                        }
                    }
                    bufferedReader2.close();
                    GuiIngame.lIIIIIIIIIlIllIIllIlIIlIl = false;
                    new StringBuilder().append("https://i.imgur.com/").append(((JsonObject)new GsonBuilder().create().fromJson(sb.toString(), (Class)JsonObject.class)).get("data").getAsJsonObject().get("id").getAsString()).append(".png").toString();
                    this.IlllIllIlIIIIlIIlIIllIIIl = new URI(str4);
                    ilIIIIllIllllIlIIlIIlIII = new IIlIIIIllIllllIlIIlIIlIII(this, str4, 0, false);
                    ilIIIIllIllllIlIIlIIlIII.shutdownMinecraftApplet();
                    this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(ilIIIIllIllllIlIIlIIlIII);
                }
                catch (Exception ex) {
                    GuiIngame.lIIIIIIIIIlIllIIllIlIIlIl = false;
                    ex.printStackTrace();
                }
            }).start();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        if (n == 0) {
            if (b) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl);
            }
            this.IlllIllIlIIIIlIIlIIllIIIl = null;
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this);
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final URI uri) {
        try {
            Desktop.getDesktop().browse(uri);
        }
        catch (Throwable t) {
            GuiChat.IlllIIIlIlllIllIlIIlllIlI.error("Couldn't open link", t);
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        if (this.IlIlIIIlllIIIlIlllIlIllIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.updateDebugProfilerName(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII(), false) - this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII());
            if (this.IllIIIIIIIlIlIllllIIllIII >= this.lIIIIllIIlIlIllIIIlIllIlI.size()) {
                this.IllIIIIIIIlIlIllllIIllIII = 0;
            }
        }
        else {
            final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII(), false);
            this.lIIIIllIIlIlIllIIIlIllIlI.clear();
            this.IllIIIIIIIlIlIllllIIllIII = 0;
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().substring(0, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII()), this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().substring(liiiIlIIllIIlIIlIIIlIIllI).toLowerCase());
            if (this.lIIIIllIIlIlIllIIIlIllIlI.isEmpty()) {
                return;
            }
            this.IlIlIIIlllIIIlIlllIlIllIl = true;
            this.lIIIIlIIllIIlIIlIIIlIIllI.updateDebugProfilerName(liiiIlIIllIIlIIlIIIlIIllI - this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII());
        }
        if (this.lIIIIllIIlIlIllIIIlIllIlI.size() > 1) {
            final StringBuilder sb = new StringBuilder();
            for (final String str : this.lIIIIllIIlIlIllIIIlIllIlI) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(str);
            }
            this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(sb.toString()), 1);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(IlIllllIIlIIllIlIlllllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI.get(this.IllIIIIIIIlIlIllllIIllIII++)));
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final String s2) {
        if (s.length() >= 1) {
            this.lllIIIIIlIllIlIIIllllllII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIlIllIlIIlIlIIIlIlIlIll(s));
            this.IIIllIllIlIlllllllIlIlIII = true;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl + n;
        final int size = this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().IlllIIIlIlllIllIlIIlllIlI().size();
        if (iiiIllIIllIIIIllIllIIIlIl < 0) {
            iiiIllIIllIIIIllIllIIIlIl = 0;
        }
        if (iiiIllIIllIIIIllIllIIIlIl > size) {
            iiiIllIIllIIIIllIllIIIlIl = size;
        }
        if (iiiIllIIllIIIIllIllIIIlIl != this.IIIIllIIllIIIIllIllIIIlIl) {
            if (iiiIllIIllIIIIllIllIIIlIl == size) {
                this.IIIIllIIllIIIIllIllIIIlIl = size;
                this.lIIIIlIIllIIlIIlIIIlIIllI.setSection(this.IIIIllIlIIIllIlllIlllllIl);
            }
            else {
                if (this.IIIIllIIllIIIIllIllIIIlIl == size) {
                    this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl();
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI.setSection((String)this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().IlllIIIlIlllIllIlIIlllIlI().get(iiiIllIIllIIIIllIllIIIlIl));
                this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(2.0f, (float)(this.IIIIIIlIlIlIllllllIlllIlI - 14), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI - 2), (float)(this.IIIIIIlIlIlIllllllIlllIlI - 2), Integer.MIN_VALUE);
        this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl();
        final IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI = this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(Mouse.getX(), Mouse.getY());
        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIllIIlIlIllIIIlIllIlI() != null) {
            final IIIIIlIIlIIlIlIlIIIIIIlII liiiIllIIlIlIllIIIlIllIlI = liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIllIIlIlIllIIIlIllIlI();
            if (liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI() == llIlIllIllllllIlllllllIII.IlllIIIlIlllIllIlIIlllIlI) {
                lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI2 = null;
                try {
                    final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI3 = lIlllIllllIlIlllIIIIllIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI());
                    if (liiiIlIIllIIlIIlIIIlIIllI3 != null && liiiIlIIllIIlIIlIIIlIIllI3 instanceof IlIIIllIIlIIlllIllllIIIIl) {
                        liiiIlIIllIIlIIlIIIlIIllI2 = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI((IlIIIllIIlIIlllIllllIIIIl)liiiIlIIllIIlIIlIIIlIIllI3);
                    }
                }
                catch (IIIlIlIlIIlIIllllIIlIIIlI iiIlIlIlIIlIIllllIIlIIIlI) {}
                if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2, n, n2);
                }
                else {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "Invalid Item!", n, n2);
                }
            }
            else if (liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI() == llIlIllIllllllIlllllllIII.lIIIIlIIllIIlIIlIIIlIIllI) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(Splitter.on("\n").splitToList((CharSequence)liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl().IIIIllIlIIIllIlllIlllllIl()), n, n2);
            }
            else if (liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI() == llIlIllIllllllIlllllllIII.lIIIIIIIIIlIllIIllIlIIlIl) {
                final lIIIlIlIlIIlIIllIIIIIllll liiiIlIIllIIlIIlIIIlIIllI4 = lIIlIIIllIlIIllIIllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI());
                if (liiiIlIIllIIlIIlIIIlIIllI4 != null) {
                    final IllIllIIlIIlIlllIIllIIIlI iiiIllIIllIIIIllIllIIIlIl = liiiIlIIllIIlIIlIIIlIIllI4.IIIIllIIllIIIIllIllIIIlIl();
                    final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl = new IIIlIlIIIlllllIIlllIIIlIl("stats.tooltip.type." + (liiiIlIIllIIlIIlIIIlIIllI4.IIIIllIlIIIllIlllIlllllIl() ? "achievement" : "statistic"), new Object[0]);
                    iiIlIlIIIlllllIIlllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIIIIIIlIllIIllIlIIlIl(true);
                    final String s = (liiiIlIIllIIlIIlIIIlIIllI4 instanceof IIlllIllIlIIIIIlIlllllIIl) ? ((IIlllIllIlIIIIIlIlllllIIl)liiiIlIIllIIlIIlIIIlIIllI4).IlIlIIIlllIIIlIlllIlIllIl() : null;
                    final ArrayList arrayList = Lists.newArrayList((Object[])new String[] { iiiIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl(), iiIlIlIIIlllllIIlllIIIlIl.IIIIllIlIIIllIlllIlllllIl() });
                    if (s != null) {
                        arrayList.addAll(this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(s, 150));
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(arrayList, n, n2);
                }
                else {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "Invalid statistic/achievement!", n, n2);
                }
            }
            GL11.glDisable(2896);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String[] array) {
        if (this.IIIllIllIlIlllllllIlIlIII) {
            this.IlIlIIIlllIIIlIlllIlIllIl = false;
            this.lIIIIllIIlIlIllIIIlIllIlI.clear();
            for (final String s : array) {
                if (s.length() > 0) {
                    this.lIIIIllIIlIlIllIIIlIllIlI.add(s);
                }
            }
            final String substring = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().substring(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII(), false));
            final String[] array2 = new String[this.lIIIIllIIlIlIllIIIlIllIlI.size()];
            for (int j = 0; j < this.lIIIIllIIlIlIllIIIlIllIlI.size(); ++j) {
                array2[j] = IlIllllIIlIIllIlIlllllIlI.lIIIIlIIllIIlIIlIIIlIIllI((String)this.lIIIIllIIlIlIllIIIlIllIlI.get(j));
            }
            final String commonPrefix = StringUtils.getCommonPrefix(array2);
            if (commonPrefix.length() > 0 && !substring.equalsIgnoreCase(commonPrefix)) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.updateDebugProfilerName(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII(), false) - this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII());
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(commonPrefix);
            }
            else if (this.lIIIIllIIlIlIllIIIlIllIlI.size() > 0) {
                this.IlIlIIIlllIIIlIlllIlIllIl = true;
                this.IlIlIIIlllIIIlIlllIlIllIl();
            }
        }
    }
    
    @Override
    public boolean isUnicode() {
        return false;
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = Sets.newHashSet((Object[])new String[] { "http", "https" });
        IlllIIIlIlllIllIlIIlllIlI = LogManager.getLogger();
    }
}
