import java.awt.image.BufferedImage;
import java.lang.ref.WeakReference;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIllIlIlIlIllIIlll implements IIIIlIllllIIlIIIIlIlIIIII
{
    public final WeakReference lIIIIlIIllIIlIIlIIIlIIllI;
    public final ResourceLocation lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIIIIIIllIlIlIlIllIIlll(final IIlllIIIIIIlllIllIlIlIlII referent, final ResourceLocation liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new WeakReference((T)referent);
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage bufferedImage) {
        return IIIIlIlIlIllIIIlIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        final IIlllIIIIIIlllIllIlIlIlII illlIIIIIIlllIllIlIlIlII = (IIlllIIIIIIlllIllIlIlIlII)this.lIIIIlIIllIIlIIlIIIlIIllI.get();
        if (illlIIIIIIlllIllIlIlIlII != null) {
            illlIIIIIIlllIllIlIlIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
    }
}
