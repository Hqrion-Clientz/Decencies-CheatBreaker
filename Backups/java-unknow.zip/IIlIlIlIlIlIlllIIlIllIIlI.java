// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIlIlIlllIIlIllIIlI
{
    public final int lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    public final int IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIlIlIlIlIlllIIlIllIIlI(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public IIlIlIlIlIlIlllIIlIllIIlI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII) {
        this(MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl), MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI));
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof IIlIlIlIlIlIlllIIlIllIIlI)) {
            return false;
        }
        final IIlIlIlIlIlIlllIIlIllIIlI ilIlIlIlIlIlllIIlIllIIlI = (IIlIlIlIlIlIlllIIlIllIIlI)o;
        return ilIlIlIlIlIlllIIlIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == this.lIIIIlIIllIIlIIlIIIlIIllI && ilIlIlIlIlIlllIIlIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl == this.lIIIIIIIIIlIllIIllIlIIlIl && ilIlIlIlIlIlllIIlIllIIlI.IlllIIIlIlllIllIlIIlllIlI == this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public int hashCode() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI * 8976890 + this.lIIIIIIIIIlIllIIllIlIIlIl * 981131 + this.IlllIIIlIlllIllIlIIlllIlI;
    }
}
