import java.util.Iterator;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlllIllllIlIllllIlIl extends lIlIIllIlIlIIlIIlIlIIlIII
{
    private final Random lIIIlllIlIlllIIIIIIIIIlII;
    public final int lIIIIlllIIlIlllllIlIllIII;
    
    protected IIIlIIlllIllllIlIllllIlIl(final int liiiIlllIIlIlllllIlIllIII) {
        super(Material.IIIIllIlIIIllIlllIlllllIl);
        this.lIIIlllIlIlllIIIIIIIIIlII = new Random();
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.17857143f * 0.35f, 0.0f, 0.054012343f * 1.1571429f, 0.13392857f * 7.0f, 3.074074f * 0.28463855f, 1.4158163f * 0.6621622f);
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 22;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        if (liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 - 1) == this) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.8125f * 0.07692308f, 0.0f, 0.0f, 0.9975962f * 0.939759f, 0.9230769f * 0.9479167f, 5.3365383f * 0.17567568f);
        }
        else if (liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 + 1) == this) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.10979729f * 0.5692308f, 0.0f, 0.8f * 0.078125f, 0.0952381f * 9.84375f, 2.152174f * 0.40656564f, 1.0f);
        }
        else if (liIllIIIllIIIIllIllIIllIl.getBlock(n - 1, n2, n3) == this) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 1.05f * 0.059523813f, 12.8f * 0.07324219f, 1.5749999f * 0.5555556f, 0.8653846f * 1.0833334f);
        }
        else if (liIllIIIllIIIIllIllIIllIl.getBlock(n + 1, n2, n3) == this) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1.8113208f * 0.034505207f, 0.0f, 1.4444444f * 0.043269232f, 1.0f, 0.11170212f * 7.8333335f, 0.04255319f * 22.03125f);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1.1111112f * 0.05625f, 0.0f, 4.571429f * 0.013671874f, 1.0441177f * 0.8978873f, 0.8966049f * 0.97590363f, 0.4848485f * 1.9335938f);
        }
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        super.IIIIllIlIIIllIlllIlllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1);
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1);
        final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3);
        final IIlllllllIlllIIllllIIlIll block4 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3);
        if (block == this) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1);
        }
        if (block2 == this) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
        }
        if (block3 == this) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3);
        }
        if (block4 == this) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final EntityLivingBase entityLivingBase, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1);
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1);
        final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3);
        final IIlllllllIlllIIllllIIlIll block4 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3);
        int n4 = 0;
        final int n5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entityLivingBase.IllllIllllIlIIIlIIIllllll * 4 / 360 + 0.16666666666666666 * 3.0) & 0x3;
        if (n5 == 0) {
            n4 = 2;
        }
        if (n5 == 1) {
            n4 = 5;
        }
        if (n5 == 2) {
            n4 = 3;
        }
        if (n5 == 3) {
            n4 = 4;
        }
        if (block != this && block2 != this && block3 != this && block4 != this) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 3);
        }
        else {
            if ((block == this || block2 == this) && (n4 == 4 || n4 == 5)) {
                if (block == this) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3 - 1, n4, 3);
                }
                else {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3 + 1, n4, 3);
                }
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 3);
            }
            if ((block3 == this || block4 == this) && (n4 == 2 || n4 == 3)) {
                if (block3 == this) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n - 1, n2, n3, n4, 3);
                }
                else {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 1, n2, n3, n4, 3);
                }
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 3);
            }
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.IlIIlIIIIlIIIIllllIIlIllI()) {
            ((IIlIIlIIIIlIIlIlIIllIllll)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3)).setSection(lIlIlIlIlIllllIlllIIIlIlI.IIIIIIlIlIlIllllllIlllIlI());
        }
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1);
            final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1);
            final IIlllllllIlllIIllllIIlIll block3 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3);
            final IIlllllllIlllIIllllIIlIll block4 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3);
            int n4;
            if (block != this && block2 != this) {
                if (block3 != this && block4 != this) {
                    n4 = 3;
                    if (block.lIIIIlIIllIIlIIlIIIlIIllI() && !block2.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 3;
                    }
                    if (block2.lIIIIlIIllIIlIIlIIIlIIllI() && !block.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 2;
                    }
                    if (block3.lIIIIlIIllIIlIIlIIIlIIllI() && !block4.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 5;
                    }
                    if (block4.lIIIIlIIllIIlIIlIIIlIIllI() && !block3.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 4;
                    }
                }
                else {
                    final IIlllllllIlllIIllllIIlIll block5 = iiiiiIllIlIIIIlIlllIllllI.getBlock((block3 == this) ? (n - 1) : (n + 1), n2, n3 - 1);
                    final IIlllllllIlllIIllllIIlIll block6 = iiiiiIllIlIIIIlIlllIllllI.getBlock((block3 == this) ? (n - 1) : (n + 1), n2, n3 + 1);
                    n4 = 3;
                    int n5;
                    if (block3 == this) {
                        n5 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3);
                    }
                    else {
                        n5 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3);
                    }
                    if (n5 == 2) {
                        n4 = 2;
                    }
                    if ((block.lIIIIlIIllIIlIIlIIIlIIllI() || block5.lIIIIlIIllIIlIIlIIIlIIllI()) && !block2.lIIIIlIIllIIlIIlIIIlIIllI() && !block6.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 3;
                    }
                    if ((block2.lIIIIlIIllIIlIIlIIIlIIllI() || block6.lIIIIlIIllIIlIIlIIIlIIllI()) && !block.lIIIIlIIllIIlIIlIIIlIIllI() && !block5.lIIIIlIIllIIlIIlIIIlIIllI()) {
                        n4 = 2;
                    }
                }
            }
            else {
                final IIlllllllIlllIIllllIIlIll block7 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, (block == this) ? (n3 - 1) : (n3 + 1));
                final IIlllllllIlllIIllllIIlIll block8 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, (block == this) ? (n3 - 1) : (n3 + 1));
                n4 = 5;
                int n6;
                if (block == this) {
                    n6 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1);
                }
                else {
                    n6 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1);
                }
                if (n6 == 4) {
                    n4 = 4;
                }
                if ((block3.lIIIIlIIllIIlIIlIIIlIIllI() || block7.lIIIIlIIllIIlIIlIIIlIIllI()) && !block4.lIIIIlIIllIIlIIlIIIlIIllI() && !block8.lIIIIlIIllIIlIIlIIIlIIllI()) {
                    n4 = 5;
                }
                if ((block4.lIIIIlIIllIIlIIlIIIlIIllI() || block8.lIIIIlIIllIIlIIlIIIlIIllI()) && !block3.lIIIIlIIllIIlIIlIIIlIIllI() && !block7.lIIIIlIIllIIlIIlIIIlIIllI()) {
                    n4 = 4;
                }
            }
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, 3);
        }
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        int n4 = 0;
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == this) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == this) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == this) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == this) {
            ++n4;
        }
        return n4 <= 1 && !this.llIIlllIIIIlllIllIlIlllIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3) && !this.llIIlllIIIIlllIllIlIlllIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3) && !this.llIIlllIIIIlllIllIlIlllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1) && !this.llIIlllIIIIlllIllIlIlllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
    }
    
    private boolean llIIlllIIIIlllIllIlIlllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == this && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == this || iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == this || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == this || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == this);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
        final IIlIIlIIIIlIIlIlIIllIllll ilIIlIIIIlIIlIlIIllIllll = (IIlIIlIIIIlIIlIlIIllIllll)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        if (ilIIlIIIIlIIlIlIIllIllll != null) {
            ilIIlIIIIlIIlIlIIllIllll.freeMemory();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        final IIlIIlIIIIlIIlIlIIllIllll ilIIlIIIIlIIlIlIIllIllll = (IIlIIlIIIIlIIlIlIIllIllll)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        if (ilIIlIIIIlIIlIlIIllIllll != null) {
            for (int i = 0; i < ilIIlIIIIlIIlIlIIllIllll.IIIIllIIllIIIIllIllIIIlIl(); ++i) {
                final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIIlIIIIlIIlIlIIllIllll.lIIlIlIllIIlIIIlIIIlllIII(i);
                if (liIlIlIllIIlIIIlIIIlllIII != null) {
                    final float n5 = this.lIIIlllIlIlllIIIIIIIIIlII.nextFloat() * (1.1162791f * 0.71666664f) + 0.2967033f * 0.33703703f;
                    final float n6 = this.lIIIlllIlIlllIIIIIIIIIlII.nextFloat() * (1.0487804f * 0.76279074f) + 0.006451613f * 15.5f;
                    final float n7 = this.lIIIlllIlIlllIIIIIIIIIlII.nextFloat() * (3.76f * 0.21276596f) + 1.3181819f * 0.075862065f;
                    while (liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl > 0) {
                        int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIlllIlIlllIIIIIIIIIlII.nextInt(21) + 10;
                        if (liiiiiiiiIlIllIIllIlIIlIl > liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl) {
                            liiiiiiiiIlIllIIllIlIIlIl = liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl;
                        }
                        final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = liIlIlIllIIlIIIlIIIlllIII;
                        lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl -= liiiiiiiiIlIllIIllIlIIlIl;
                        final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl = new lllIIIIIlIllllIIIlllIllIl(iiiiiIllIlIIIIlIlllIllllI, n + n5, n2 + n6, n3 + n7, new lIlIlIlIlIllllIlllIIIlIlI(liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(), liiiiiiiiIlIllIIllIlIIlIl, liIlIlIllIIlIIIlIIIlllIII.IlllIllIlIIIIlIIlIIllIIIl()));
                        final float n8 = 0.03275862f * 1.5263158f;
                        lllIIIIIlIllllIIIlllIllIl.IllIIlIIlllllIllIIIlllIII = (float)this.lIIIlllIlIlllIIIIIIIIIlII.nextGaussian() * n8;
                        lllIIIIIlIllllIIIlllIllIl.lIlIlIllIIIIIIIIllllIIllI = (float)this.lIIIlllIlIlllIIIIIIIIIlII.nextGaussian() * n8 + 1.6216216f * 0.123333335f;
                        lllIIIIIlIllllIIIlllIllIl.IlllIIlllIIIIllIIllllIlIl = (float)this.lIIIlllIlIlllIIIIIIIIIlII.nextGaussian() * n8;
                        if (liIlIlIllIIlIIIlIIIlllIII.IIIlIIllllIIllllllIlIIIll()) {
                            lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().IIIIllIlIIIllIlllIlllllIl((IlIIIllIIlIIlllIllllIIIIl)liIlIlIllIIlIIIlIIIlllIII.lllIIIIIlIllIlIIIllllllII().lIIIIIIIIIlIllIIllIlIIlIl());
                        }
                        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl);
                    }
                }
            }
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3, illlllllIlllIIllllIIlIll);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, n4);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            return true;
        }
        final IIlIIlIIllIllllllllIllIII ilIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        if (ilIlllIIIIllIllllIllIIlIl != null) {
            lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(ilIlllIIIIllIllllIllIIlIl);
        }
        return true;
    }
    
    public IIlIIlIIllIllllllllIllIII IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII = (IIlIIlIIIIlIIlIlIIllIllll)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        if (ilIIlIIllIllllllllIllIII == null) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            return null;
        }
        if (lIIlIlIllIIlIIIlIIIlllIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == this && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2 + 1, n3).lIIIIllIIlIlIllIIIlIllIlI() || lIIlIlIllIIlIIIlIIIlllIII(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3))) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == this && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2 + 1, n3).lIIIIllIIlIlIllIIIlIllIlI() || lIIlIlIllIIlIIIlIIIlllIII(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3))) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == this && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() || lIIlIlIllIIlIIIlIIIlllIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1))) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == this && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI() || lIIlIlIllIIlIIIlIIIlllIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1))) {
            return null;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == this) {
            ilIIlIIllIllllllllIllIII = new llIIlIIIlllIlllllIlllllll("container.chestDouble", (IIlIIlIIllIllllllllIllIII)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n - 1, n2, n3), ilIIlIIllIllllllllIllIII);
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == this) {
            ilIIlIIllIllllllllIllIII = new llIIlIIIlllIlllllIlllllll("container.chestDouble", ilIIlIIllIllllllllIllIII, (IIlIIlIIllIllllllllIllIII)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n + 1, n2, n3));
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == this) {
            ilIIlIIllIllllllllIllIII = new llIIlIIIlllIlllllIlllllll("container.chestDouble", (IIlIIlIIllIllllllllIllIII)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 - 1), ilIIlIIllIllllllllIllIII);
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == this) {
            ilIIlIIllIllllllllIllIII = new llIIlIIIlllIlllllIlllllll("container.chestDouble", ilIIlIIllIllllllllIllIII, (IIlIIlIIllIllllllllIllIII)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 + 1));
        }
        return ilIIlIIllIllllllllIllIII;
    }
    
    @Override
    public IllIllIlIIlllIllIIllIlIIl lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n) {
        return new IIlIIlIIIIlIIlIlIIllIllll();
    }
    
    @Override
    public boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return this.lIIIIlllIIlIlllllIlIllIII == 1;
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        if (!this.llIlIIIllIIIIlllIlIIIIIlI()) {
            return 0;
        }
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(((IIlIIlIIIIlIIlIlIIllIllll)liIllIIIllIIIIllIllIIllIl.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3)).llIlIIIlIIIIlIlllIlIIIIll, 0, 15);
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return (n4 == 1) ? this.IIIIllIlIIIllIlllIlllllIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4) : 0;
    }
    
    private static boolean lIIlIlIllIIlIIIlIIIlllIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final Iterator<Entity> iterator = iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(IIlIIIlIIlIIlIlllllIIIlIl.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 + 1, n3, n + 1, n2 + 2, n3 + 1)).iterator();
        while (iterator.hasNext()) {
            if (((IIlIIIlIIlIIlIlllllIIIlIl)iterator.next()).llIllllIIIIIlIllIlIIIllIl()) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean lllIlIIllllIIIIlIllIlIIII() {
        return true;
    }
    
    @Override
    public int IlIlIIIlllIIIlIlllIlIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        return IIIllIlIIIllIlIIIIlIlllII.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIlIIllIIIllllIIlllIllIIl = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("planks_oak");
    }
}
