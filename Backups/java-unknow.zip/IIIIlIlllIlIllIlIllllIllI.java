import java.util.Iterator;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.nio.ByteBuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIlIlllIlIllIlIllllIllI
{
    public static int lIIIIlIIllIIlIIlIIIlIIllI;
    public static int lIIIIIIIIIlIllIIllIlIIlIl;
    protected IIIlIlIlIIIIIlIlllllIIIlI IlllIIIlIlllIllIlIIlllIlI;
    protected DELETE_ME_E IIIIllIlIIIllIlllIlllllIl;
    
    public IIIIlIlllIlIllIlIllllIllI() {
        this.IlllIIIlIlllIllIlIIlllIlI = null;
        this.IIIIllIlIIIllIlllIlllllIl = null;
    }
    
    public static ByteBuffer lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer byteBuffer) {
        final ByteBuffer allocate = ByteBuffer.allocate(byteBuffer.remaining());
        byte value = 48;
        while (byteBuffer.hasRemaining()) {
            final byte b = value;
            value = byteBuffer.get();
            allocate.put(value);
            if (b == 13 && value == 10) {
                allocate.limit(allocate.position() - 2);
                allocate.position(0);
                return allocate;
            }
        }
        byteBuffer.position(byteBuffer.position() - allocate.position());
        return null;
    }
    
    public static String lIIIIIIIIIlIllIIllIlIIlIl(final ByteBuffer byteBuffer) {
        final ByteBuffer liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(byteBuffer);
        return (liiiIlIIllIIlIIlIIIlIIllI == null) ? null : IlllllIIlIIIllIllllIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.array(), 0, liiiIlIIllIIlIIlIIIlIIllI.limit());
    }
    
    public static IIlllllIIIllllIIlIlIIllIl lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer byteBuffer, final IIIlIlIlIIIIIlIlllllIIIlI iiIlIlIlIIIIIlIlllllIIIlI) {
        final String liiiiiiiiIlIllIIllIlIIlIl = lIIIIIIIIIlIllIIllIlIIlIl(byteBuffer);
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            throw new lIIlIlIIIIIlIlllIIIIlllll(byteBuffer.capacity() + 128);
        }
        final String[] split = liiiiiiiiIlIllIIllIlIIlIl.split(" ", 3);
        if (split.length != 3) {
            throw new IlIlIlIIllIIllllIIIlllIll();
        }
        llIIIIIlIlIIlIIIIIIllIIII llIIIIIlIlIIlIIIIIIllIIII;
        if (iiIlIlIlIIIIIlIlllllIIIlI == IIIlIlIlIIIIIlIlllllIIIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (!"101".equals(split[1])) {
                throw new IlIlIlIIllIIllllIIIlllIll("Invalid status code received: " + split[1] + " Status line: " + liiiiiiiiIlIllIIllIlIIlIl);
            }
            if (!"HTTP/1.1".equalsIgnoreCase(split[0])) {
                throw new IlIlIlIIllIIllllIIIlllIll("Invalid status line received: " + split[0] + " Status line: " + liiiiiiiiIlIllIIllIlIIlIl);
            }
            llIIIIIlIlIIlIIIIIIllIIII = new llIIIIIlIlIIlIIIIIIllIIII();
            final llIIIIIlIlIIlIIIIIIllIIII llIIIIIlIlIIlIIIIIIllIIII2 = llIIIIIlIlIIlIIIIIIllIIII;
            llIIIIIlIlIIlIIIIIIllIIII2.lIIIIlIIllIIlIIlIIIlIIllI(Short.parseShort(split[1]));
            llIIIIIlIlIIlIIIIIIllIIII2.lIIIIlIIllIIlIIlIIIlIIllI(split[2]);
        }
        else {
            if (!"GET".equalsIgnoreCase(split[0])) {
                throw new IlIlIlIIllIIllllIIIlllIll("Invalid request method received: " + split[0] + " Status line: " + liiiiiiiiIlIllIIllIlIIlIl);
            }
            if (!"HTTP/1.1".equalsIgnoreCase(split[2])) {
                throw new IlIlIlIIllIIllllIIIlllIll("Invalid status line received: " + split[2] + " Status line: " + liiiiiiiiIlIllIIllIlIIlIl);
            }
            final IIllIIIIIIIlllllIIIlllIlI illIIIIIIIlllllIIIlllIlI = new IIllIIIIIIIlllllIIIlllIlI();
            illIIIIIIIlllllIIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
            llIIIIIlIlIIlIIIIIIllIIII = (llIIIIIlIlIIlIIIIIIllIIII)illIIIIIIIlllllIIIlllIlI;
        }
        String s;
        for (s = lIIIIIIIIIlIllIIllIlIIlIl(byteBuffer); s != null && s.length() > 0; s = lIIIIIIIIIlIllIIllIlIIlIl(byteBuffer)) {
            final String[] split2 = s.split(":", 2);
            if (split2.length != 2) {
                throw new IlIlIlIIllIIllllIIIlllIll("not an http header");
            }
            if (llIIIIIlIlIIlIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI(split2[0])) {
                llIIIIIlIlIIlIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(split2[0], llIIIIIlIlIIlIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl(split2[0]) + "; " + split2[1].replaceFirst("^ +", ""));
            }
            else {
                llIIIIIlIlIIlIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(split2[0], split2[1].replaceFirst("^ +", ""));
            }
        }
        if (s == null) {
            throw new lIIlIlIIIIIlIlllIIIIlllll();
        }
        return llIIIIIlIlIIlIIIIIIllIIII;
    }
    
    public abstract lIlIIIIIIIIlllllllIlIIIll lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll p0, final IllIIllIIlllIlllIllIIIIIl p1);
    
    public abstract lIlIIIIIIIIlllllllIlIIIll lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll p0);
    
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final llIIlIlIIllIlIIIIIIllIIII llIIlIlIIllIlIIIIIIllIIII) {
        return llIIlIlIIllIlIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl("Upgrade").equalsIgnoreCase("websocket") && llIIlIlIIllIlIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl("Connection").toLowerCase(Locale.ENGLISH).contains("upgrade");
    }
    
    public abstract ByteBuffer lIIIIlIIllIIlIIlIIIlIIllI(final IFramedata p0);
    
    public abstract List lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer p0, final boolean p1);
    
    public abstract List lIIIIlIIllIIlIIlIIIlIIllI(final String p0, final boolean p1);
    
    public abstract void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIllIlIIlllllIllIlIlI p0, final IFramedata p1);
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final DELETE_ME_E delete_ME_E, final ByteBuffer byteBuffer, final boolean b) {
        if (delete_ME_E != DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI && delete_ME_E != DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl) {
            throw new IllegalArgumentException("Only Opcode.BINARY or  Opcode.TEXT are allowed");
        }
        IIlIlllIlIllIllIlIllIllIl o = null;
        if (this.IIIIllIlIIIllIlllIlllllIl != null) {
            o = new IIlIllIIIIIlIllIllllIIIII();
        }
        else if ((this.IIIIllIlIIIllIlllIlllllIl = delete_ME_E) == DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI) {
            o = new lIIllIllllIlIIIIlIIIIIIIl();
        }
        else if (delete_ME_E == DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl) {
            o = new lllllllIllIlllIIlIllllIll();
        }
        o.lIIIIlIIllIIlIIlIIIlIIllI(byteBuffer);
        o.lIIIIlIIllIIlIIlIIIlIIllI(b);
        try {
            o.IlllIIIlIlllIllIlIIlllIlI();
        }
        catch (lIlllllIllllIIlIIIlllllll cause) {
            throw new IllegalArgumentException(cause);
        }
        if (b) {
            this.IIIIllIlIIIllIlllIlllllIl = null;
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl = delete_ME_E;
        }
        return Collections.singletonList(o);
    }
    
    public abstract void lIIIIlIIllIIlIIlIIIlIIllI();
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final llIIlIlIIllIlIIIIIIllIIII llIIlIlIIllIlIIIIIIllIIII, final IIIlIlIlIIIIIlIlllllIIIlI iiIlIlIlIIIIIlIlllllIIIlI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(llIIlIlIIllIlIIIIIIllIIII, iiIlIlIlIIIIIlIlllllIIIlI, true);
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final llIIlIlIIllIlIIIIIIllIIII llIIlIlIIllIlIIIIIIllIIII, final IIIlIlIlIIIIIlIlllllIIIlI iiIlIlIlIIIIIlIlllllIIIlI, final boolean b) {
        final StringBuilder sb = new StringBuilder(100);
        if (llIIlIlIIllIlIIIIIIllIIII instanceof lllIlllIIIIIllllIlIIIIIll) {
            sb.append("GET ");
            sb.append(((lllIlllIIIIIllllIlIIIIIll)llIIlIlIIllIlIIIIIIllIIII).lIIIIlIIllIIlIIlIIIlIIllI());
            sb.append(" HTTP/1.1");
        }
        else {
            if (!(llIIlIlIIllIlIIIIIIllIIII instanceof IllIIllIIlllIlllIllIIIIIl)) {
                throw new IllegalArgumentException("unknown role");
            }
            sb.append("HTTP/1.1 101 ").append(((IllIIllIIlllIlllIllIIIIIl)llIIlIlIIllIlIIIIIIllIIII).lIIIIlIIllIIlIIlIIIlIIllI());
        }
        sb.append("\r\n");
        final Iterator illlIIIlIlllIllIlIIlllIlI = llIIlIlIIllIlIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI();
        while (illlIIIlIlllIllIlIIlllIlI.hasNext()) {
            final String str = illlIIIlIlllIllIlIIlllIlI.next();
            final String liiiiiiiiIlIllIIllIlIIlIl = llIIlIlIIllIlIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl(str);
            sb.append(str);
            sb.append(": ");
            sb.append(liiiiiiiiIlIllIIllIlIIlIl);
            sb.append("\r\n");
        }
        sb.append("\r\n");
        final byte[] liiiiiiiiIlIllIIllIlIIlIl2 = IlllllIIlIIIllIllllIlIlIl.lIIIIIIIIIlIllIIllIlIIlIl(sb.toString());
        final byte[] src = (byte[])(b ? llIIlIlIIllIlIIIIIIllIIII.IIIIllIlIIIllIlllIlllllIl() : null);
        final ByteBuffer allocate = ByteBuffer.allocate(((src == null) ? 0 : src.length) + liiiiiiiiIlIllIIllIlIIlIl2.length);
        allocate.put(liiiiiiiiIlIllIIllIlIIlIl2);
        if (src != null) {
            allocate.put(src);
        }
        allocate.flip();
        return Collections.singletonList(allocate);
    }
    
    public abstract IlIIllIllIIIlIIIlIllIllII lIIIIlIIllIIlIIlIIIlIIllI(final IlIIllIllIIIlIIIlIllIllII p0);
    
    public abstract IIlllllIIIllllIIlIlIIllIl lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll p0, final lIlIllllIlllIllllIIlIIIII p1);
    
    public abstract List IlllIIIlIlllIllIlIIlllIlI(final ByteBuffer p0);
    
    public abstract IIIIIIIIIIIIIIlllIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl();
    
    public abstract IIIIlIlllIlIllIlIllllIllI IlllIIIlIlllIllIlIIlllIlI();
    
    public llIIlIlIIllIlIIIIIIllIIII IIIIllIlIIIllIlllIlllllIl(final ByteBuffer byteBuffer) {
        return lIIIIlIIllIIlIIlIIIlIIllI(byteBuffer, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (n < 0) {
            throw new lIlllllIllllIIlIIIlllllll(1002, "Negative count");
        }
        return n;
    }
    
    int lIIIIIIIIIlIllIIllIlIIlIl(final llIIlIlIIllIlIIIIIIllIIII llIIlIlIIllIlIIIIIIllIIII) {
        final String liiiiiiiiIlIllIIllIlIIlIl = llIIlIlIIllIlIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Version");
        if (liiiiiiiiIlIllIIllIlIIlIl.length() > 0) {
            try {
                return new Integer(liiiiiiiiIlIllIIllIlIIlIl.trim());
            }
            catch (NumberFormatException ex) {
                return -1;
            }
        }
        return -1;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIlIlIIIIIlIlllllIIIlI illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public IIIlIlIlIIIIIlIlllllIIIlI IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
    
    static {
        IIIIlIlllIlIllIlIllllIllI.lIIIIlIIllIIlIIlIIIlIIllI = 1000;
        IIIIlIlllIlIllIlIllllIllI.lIIIIIIIIIlIllIIllIlIIlIl = 64;
    }
}
