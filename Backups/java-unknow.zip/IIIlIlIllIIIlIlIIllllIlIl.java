// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIllIIIlIlIIllllIlIl
{
    public byte lIIIIlIIllIIlIIlIIIlIIllI;
    public byte lIIIIIIIIIlIllIIllIlIIlIl;
    public byte IlllIIIlIlllIllIlIIlllIlI;
    public byte IIIIllIlIIIllIlllIlllllIl;
    final /* synthetic */ IIIlIIIIlIllIlIllIlllIlll IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIlIlIllIIIlIlIIllllIlIl(final IIIlIIIIlIllIlIllIlllIlll iiiIllIIllIIIIllIllIIIlIl, final byte liiiIlIIllIIlIIlIIIlIIllI, final byte liiiiiiiiIlIllIIllIlIIlIl, final byte illlIIIlIlllIllIlIIlllIlI, final byte iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
}
