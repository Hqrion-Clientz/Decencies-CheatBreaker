// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIlllIIIIIlIllIIIIIIIlll
{
    public final String lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlllIIIIIlIllIIIIIIIlll(final String liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public abstract void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl p0);
    
    public abstract void IlllIIIlIlllIllIlIIlllIlI(final IlIIIllIIlIIlllIllllIIIIl p0);
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
