// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlllllIllllIllllIllI extends lIIlllIIIlIllllllIlIlIIII
{
    public IIlIlIlllllIllllIllllIllI() {
        this.lIIIIIIIIIlIllIIllIlIIlIl(1);
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI);
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    @Override
    public boolean IlIlllIIIIllIllllIllIIlIl() {
        return true;
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        if (ilIIIllIIlIIlllIllllIIIIl == null) {
            return false;
        }
        if (!ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("pages", 9)) {
            return false;
        }
        final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("pages", 8);
        for (int i = 0; i < illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
            final String ilIlIIIlllIIIlIlllIlIllIl = illlIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl(i);
            if (ilIlIIIlllIIIlIlllIlIllIl == null) {
                return false;
            }
            if (ilIlIIIlllIIIlIlllIlIllIl.length() > 256) {
                return false;
            }
        }
        return true;
    }
}
