// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllllllIIIlIIlIIIIIIl
{
    public static int lIIIIlIIllIIlIIlIIIlIIllI;
    public static int lIIIIIIIIIlIllIIllIlIIlIl;
    public static int IlllIIIlIlllIllIlIIlllIlI;
    public static int IIIIllIlIIIllIlllIlllllIl;
    public static int IIIIllIIllIIIIllIllIIIlIl;
    public static int IlIlIIIlllIIIlIlllIlIllIl;
    public static int IIIllIllIlIlllllllIlIlIII;
    public static int IllIIIIIIIlIlIllllIIllIII;
    public static int lIIIIllIIlIlIllIIIlIllIlI;
    public static int IlllIllIlIIIIlIIlIIllIIIl;
    public static int IlIlllIIIIllIllllIllIIlIl;
    public static int llIIlllIIIIlllIllIlIlllIl;
    public static int lIIlIlIllIIlIIIlIIIlllIII;
    public static int IIIlllIIIllIllIlIIIIIIlII;
    public static int llIlIIIlIIIIlIlllIlIIIIll;
    public static int IIIlIIllllIIllllllIlIIIll;
    public static int lllIIIIIlIllIlIIIllllllII;
    public static int lIIIIIllllIIIIlIlIIIIlIlI;
    public static int IIIIIIlIlIlIllllllIlllIlI;
    public static int IllIllIIIlIIlllIIIllIllII;
    public static int IlIIlIIIIlIIIIllllIIlIllI;
    public static int lIIlIIllIIIIIlIllIIIIllII;
    public static int lIIlllIIlIlllllllllIIIIIl;
    public static int lIllIllIlIIllIllIlIlIIlIl;
    public static int llIlIIIllIIIIlllIlIIIIIlI;
    public static int lIllIlIlllIIlIIllIIlIIlII;
    public static int IIIlIIlIlIIIlllIIlIllllll;
    public static Integer[] IllIlIIIIlllIIllIIlllIIlI;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:air"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:water"));
        IIIIlllllllIIIlIIlIIIIIIl.IlllIIIlIlllIllIlIIlllIlI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:flowing_water"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIIllIlIIIllIlllIlllllIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:lava"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIIllIIllIIIIllIllIIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:flowing_lava"));
        IIIIlllllllIIIlIIlIIIIIIl.IlIlIIIlllIIIlIlllIlIllIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:ice"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIllIllIlIlllllllIlIlIII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:grass"));
        IIIIlllllllIIIlIIlIIIIIIl.IllIIIIIIIlIlIllllIIllIII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:leaves"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIllIIlIlIllIIIlIllIlI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:tallgrass"));
        IIIIlllllllIIIlIIlIIIIIIl.IlllIllIlIIIIlIIlIIllIIIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:reeds"));
        IIIIlllllllIIIlIIlIIIIIIl.IlIlllIIIIllIllllIllIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:vine"));
        IIIIlllllllIIIlIIlIIIIIIl.llIIlllIIIIlllIllIlIlllIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:waterlily"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIlIlIllIIlIIIlIIIlllIII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:leaves2"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIlllIIIllIllIlIIIIIIlII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:double_plant"));
        IIIIlllllllIIIlIIlIIIIIIl.llIlIIIlIIIIlIlllIlIIIIll = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:web"));
        IIIIlllllllIIIlIIlIIIIIIl.lllIIIIIlIllIlIIIllllllII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:standing_sign"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:wooden_door"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIIIIlIlIlIllllllIlllIlI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:ladder"));
        IIIIlllllllIIIlIIlIIIIIIl.IllIllIIIlIIlllIIIllIllII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:wall_sign"));
        IIIIlllllllIIIlIIlIIIIIIl.IlIIlIIIIlIIIIllllIIlIllI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:iron_door"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIlIIllIIIIIlIllIIIIllII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:stone_button"));
        IIIIlllllllIIIlIIlIIIIIIl.lIIlllIIlIlllllllllIIIIIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:fence"));
        IIIIlllllllIIIlIIlIIIIIIl.lIllIllIlIIllIllIlIlIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:fence_gate"));
        IIIIlllllllIIIlIIlIIIIIIl.llIlIIIllIIIIlllIlIIIIIlI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:nether_brick_fence"));
        IIIIlllllllIIIlIIlIIIIIIl.lIllIlIlllIIlIIllIIlIIlII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:cobblestone_wall"));
        IIIIlllllllIIIlIIlIIIIIIl.IIIlIIlIlIIIlllIIlIllllll = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("minecraft:wooden_button"));
        IIIIlllllllIIIlIIlIIIIIIl.IllIlIIIIlllIIllIIlllIIlI = new Integer[] { IIIIlllllllIIIlIIlIIIIIIl.lllIIIIIlIllIlIIIllllllII, IIIIlllllllIIIlIIlIIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI, IIIIlllllllIIIlIIlIIIIIIl.IIIIIIlIlIlIllllllIlllIlI, IIIIlllllllIIIlIIlIIIIIIl.IllIllIIIlIIlllIIIllIllII, IIIIlllllllIIIlIIlIIIIIIl.IlIIlIIIIlIIIIllllIIlIllI, IIIIlllllllIIIlIIlIIIIIIl.lIIlIIllIIIIIlIllIIIIllII, IIIIlllllllIIIlIIlIIIIIIl.lIIlllIIlIlllllllllIIIIIl, IIIIlllllllIIIlIIlIIIIIIl.IlIlllIIIIllIllllIllIIlIl, IIIIlllllllIIIlIIlIIIIIIl.lIllIllIlIIllIllIlIlIIlIl, IIIIlllllllIIIlIIlIIIIIIl.llIlIIIllIIIIlllIlIIIIIlI, IIIIlllllllIIIlIIlIIIIIIl.lIllIlIlllIIlIIllIIlIIlII, IIIIlllllllIIIlIIlIIIIIIl.IIIlIIlIlIIIlllIIlIllllll };
    }
    
    static {
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI = 0;
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl = 9;
        IIIIlllllllIIIlIIlIIIIIIl.IlllIIIlIlllIllIlIIlllIlI = 8;
        IIIIlllllllIIIlIIlIIIIIIl.IIIIllIlIIIllIlllIlllllIl = 11;
        IIIIlllllllIIIlIIlIIIIIIl.IIIIllIIllIIIIllIllIIIlIl = 10;
        IIIIlllllllIIIlIIlIIIIIIl.IlIlIIIlllIIIlIlllIlIllIl = 79;
        IIIIlllllllIIIlIIlIIIIIIl.IIIllIllIlIlllllllIlIlIII = 2;
        IIIIlllllllIIIlIIlIIIIIIl.IllIIIIIIIlIlIllllIIllIII = 18;
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIllIIlIlIllIIIlIllIlI = 31;
        IIIIlllllllIIIlIIlIIIIIIl.IlllIllIlIIIIlIIlIIllIIIl = 83;
        IIIIlllllllIIIlIIlIIIIIIl.IlIlllIIIIllIllllIllIIlIl = 106;
        IIIIlllllllIIIlIIlIIIIIIl.llIIlllIIIIlllIllIlIlllIl = 111;
        IIIIlllllllIIIlIIlIIIIIIl.lIIlIlIllIIlIIIlIIIlllIII = 161;
        IIIIlllllllIIIlIIlIIIIIIl.IIIlllIIIllIllIlIIIIIIlII = 175;
        IIIIlllllllIIIlIIlIIIIIIl.llIlIIIlIIIIlIlllIlIIIIll = 30;
        IIIIlllllllIIIlIIlIIIIIIl.IIIlIIllllIIllllllIlIIIll = 55;
        IIIIlllllllIIIlIIlIIIIIIl.lllIIIIIlIllIlIIIllllllII = 63;
        IIIIlllllllIIIlIIlIIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI = 64;
        IIIIlllllllIIIlIIlIIIIIIl.IIIIIIlIlIlIllllllIlllIlI = 65;
        IIIIlllllllIIIlIIlIIIIIIl.IllIllIIIlIIlllIIIllIllII = 68;
        IIIIlllllllIIIlIIlIIIIIIl.IlIIlIIIIlIIIIllllIIlIllI = 71;
        IIIIlllllllIIIlIIlIIIIIIl.lIIlIIllIIIIIlIllIIIIllII = 77;
        IIIIlllllllIIIlIIlIIIIIIl.lIIlllIIlIlllllllllIIIIIl = 85;
        IIIIlllllllIIIlIIlIIIIIIl.lIllIllIlIIllIllIlIlIIlIl = 107;
        IIIIlllllllIIIlIIlIIIIIIl.llIlIIIllIIIIlllIlIIIIIlI = 113;
        IIIIlllllllIIIlIIlIIIIIIl.lIllIlIlllIIlIIllIIlIIlII = 139;
        IIIIlllllllIIIlIIlIIIIIIl.IIIlIIlIlIIIlllIIlIllllll = 143;
        IIIIlllllllIIIlIIlIIIIIIl.IllIlIIIIlllIIllIIlllIIlI = new Integer[] { IIIIlllllllIIIlIIlIIIIIIl.lllIIIIIlIllIlIIIllllllII, IIIIlllllllIIIlIIlIIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI, IIIIlllllllIIIlIIlIIIIIIl.IIIIIIlIlIlIllllllIlllIlI, IIIIlllllllIIIlIIlIIIIIIl.IllIllIIIlIIlllIIIllIllII, IIIIlllllllIIIlIIlIIIIIIl.IlIIlIIIIlIIIIllllIIlIllI, IIIIlllllllIIIlIIlIIIIIIl.lIIlIIllIIIIIlIllIIIIllII, IIIIlllllllIIIlIIlIIIIIIl.lIIlllIIlIlllllllllIIIIIl, IIIIlllllllIIIlIIlIIIIIIl.IlIlllIIIIllIllllIllIIlIl, IIIIlllllllIIIlIIlIIIIIIl.lIllIllIlIIllIllIlIlIIlIl, IIIIlllllllIIIlIIlIIIIIIl.llIlIIIllIIIIlllIlIIIIIlI, IIIIlllllllIIIlIIlIIIIIIl.lIllIlIlllIIlIIllIIlIIlII, IIIIlllllllIIIlIIlIIIIIIl.IIIlIIlIlIIIlllIIlIllllll };
    }
}
