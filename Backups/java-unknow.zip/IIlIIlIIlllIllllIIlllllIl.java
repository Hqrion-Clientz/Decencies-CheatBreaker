import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIIlIIlllIllllIIlllllIl implements Callable
{
    final /* synthetic */ Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIIlIIlllIllllIIlllllIl(final Minecraft liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.launchedVersion;
    }
}
