// 
// Decompiled by Procyon v0.5.36
// 

public class CBAgentResources
{
    @CBAgentByteArrayReference
    public static native byte[] getBytesNative(final String p0);
    
    @CBAgentBooleanReference
    public static native boolean existsBytesNative(final String p0);
    
    public static boolean existsBytes(final String s) {
        boolean existsBytesNative = false;
        try {
            existsBytesNative = existsBytesNative(s);
        }
        catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
        return existsBytesNative;
    }
}
