// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllllIIIIllIlIIlIIlIIl implements llIlIlllIIIIIIIlIlIlIIllI
{
    @Override
    public final lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(iiIlIIlIllllIlIIIIlIlIlIl, lIlIlIlIlIllllIlllIIIlIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIllllIlIIIIlIlIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIllllIlIIIIlIlIlIl, llIllIIlllllIlIIIIllIIIll.IllIIIIIIIlIlIllllIIllIII(iiIlIIlIllllIlIIIIlIlIlIl.IllIIIIIIIlIlIllllIIllIII()));
        return liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    protected lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(), lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(1), 6, llIllIIlllllIlIIIIllIIIll.IllIIIIIIIlIlIllllIIllIII(iiIlIIlIllllIlIIIIlIlIlIl.IllIIIIIIIlIlIllllIIllIII()), llIllIIlllllIlIIIIllIIIll.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIllllIlIIIIlIlIlIl));
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final lIIlllIIIlIllIIlIllIllIlI liIlllIIIlIllIIlIllIllIlI, final DELETE_ME_A delete_ME_A) {
        final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl = new lllIIIIIlIllllIIIlllIllIl(iiiiiIllIlIIIIlIlllIllllI, delete_ME_A.lIIIIIIIIIlIllIIllIlIIlIl(), delete_ME_A.IlllIIIlIlllIllIlIIlllIlI() - 2.25 * 0.13333333333333333, delete_ME_A.IIIIllIlIIIllIlllIlllllIl(), lIlIlIlIlIllllIlllIIIlIlI);
        final double n2 = iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextDouble() * (0.5 * 0.2) + 0.12903225421905518 * 1.5500000461936012;
        lllIIIIIlIllllIIIlllIllIl.IllIIlIIlllllIllIIIlllIII = liIlllIIIlIllIIlIllIllIlI.lIIIIlIIllIIlIIlIIIlIIllI() * n2;
        lllIIIIIlIllllIIIlllIllIl.lIlIlIllIIIIIIIIllllIIllI = 0.1454545476219871 * 1.375;
        lllIIIIIlIllllIIIlllIllIl.IlllIIlllIIIIllIIllllIlIl = liIlllIIIlIllIIlIllIllIlI.IlllIIIlIlllIllIlIIlllIlI() * n2;
        final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl2 = lllIIIIIlIllllIIIlllIllIl;
        lllIIIIIlIllllIIIlllIllIl2.IllIIlIIlllllIllIIIlllIII += iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextGaussian() * (8.750000082577271E-4 * 8.571428298950195) * n;
        final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl3 = lllIIIIIlIllllIIIlllIllIl;
        lllIIIIIlIllllIIIlllIllIl3.lIlIlIllIIIIIIIIllllIIllI += iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextGaussian() * (1.265625 * 0.00592592579347116) * n;
        final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl4 = lllIIIIIlIllllIIIlllIllIl;
        lllIIIIIlIllllIIIlllIllIl4.IlllIIlllIIIIllIIllllIlIl += iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextGaussian() * (0.02394230691016206 * 0.3132530152797699) * n;
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl) {
        iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI(1000, iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl(), iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl(), iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII(), 0);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIIlIllllIlIIIIlIlIlIl iiIlIIlIllllIlIIIIlIlIlIl, final lIIlllIIIlIllIIlIllIllIlI liIlllIIIlIllIIlIllIllIlI) {
        iiIlIIlIllllIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI(2000, iiIlIIlIllllIlIIIIlIlIlIl.IIIIllIIllIIIIllIllIIIlIl(), iiIlIIlIllllIlIIIIlIlIlIl.IlIlIIIlllIIIlIlllIlIllIl(), iiIlIIlIllllIlIIIIlIlIlIl.IIIllIllIlIlllllllIlIlIII(), this.lIIIIlIIllIIlIIlIIIlIIllI(liIlllIIIlIllIIlIllIllIlI));
    }
    
    private int lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllIIlIllIllIlI liIlllIIIlIllIIlIllIllIlI) {
        return liIlllIIIlIllIIlIllIllIlI.lIIIIlIIllIIlIIlIIIlIIllI() + 1 + (liIlllIIIlIllIIlIllIllIlI.IlllIIIlIlllIllIlIIlllIlI() + 1) * 3;
    }
}
