// 
// Decompiled by Procyon v0.5.36
// 

public enum CBCosmeticRarity
{
    lIIIIlIIllIIlIIlIIIlIIllI("common", 0, IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll, "Common"), 
    lIIIIIIIIIlIllIIllIlIIlIl("uncommon", 1, IlIllllIIlIIllIlIlllllIlI.llIlIIIlIIIIlIlllIlIIIIll, "Uncommon"), 
    IlllIIIlIlllIllIlIIlllIlI("rare", 2, IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl, "Rare"), 
    IIIIllIlIIIllIlllIlllllIl("epic", 3, IlIllllIIlIIllIlIlllllIlI.IIIlllIIIllIllIlIIIIIIlII, "Epic");
    
    public final IlIllllIIlIIllIlIlllllIlI IIIIllIIllIIIIllIllIIIlIl;
    public final String IlIlIIIlllIIIlIlllIlIllIl;
    
    private CBCosmeticRarity(final String name, final int ordinal, final IlIllllIIlIIllIlIlllllIlI iiiIllIIllIIIIllIllIIIlIl, final String ilIlIIIlllIIIlIlllIlIllIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
}
