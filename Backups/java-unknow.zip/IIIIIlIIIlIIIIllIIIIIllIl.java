import java.util.HashMap;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIIlIIIIllIIIIIllIl
{
    private static Map lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final llIIIllllIlIIllIlIIlIIIlI llIIIllllIlIIllIlIIlIIIlI, final IIlllIIIIIIlllIllIlIlIlII illlIIIIIIlllIllIlIlIlII, final float n, final float n2) {
        final lIIIlIllIlIlllIlIlIIllIll liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(illlIIIIIIlllIllIlIlIlII);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(llIIIllllIlIIllIlIIlIIIlI, illlIIIIIIlllIllIlIlIlII, n, n2);
        }
    }
    
    public static synchronized lIIIlIllIlIlllIlIlIIllIll lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIIIIIIlllIllIlIlIlII illlIIIIIIlllIllIlIlIlII) {
        final String h_ = illlIIIIIIlllIllIlIlIlII.h_();
        if (h_ == null) {
            return null;
        }
        lIIIlIllIlIlllIlIlIIllIll liiIlIllIlIlllIlIlIIllIll = lIIIIlIIllIIlIIlIIIlIIllI().get(h_);
        if (liiIlIllIlIlllIlIlIIllIll == null) {
            liiIlIllIlIlllIlIlIIllIll = new lIIIlIllIlIlllIlIlIIllIll();
            lIIIIlIIllIIlIIlIIIlIIllI().put(h_, liiIlIllIlIlllIlIlIIllIll);
            new lIlIlIIIllllllIIllIlIllIl("http://s.optifine.net/users/" + h_ + ".cfg", new IllIlIIlIlIlIIIllllllIllI(h_)).start();
        }
        return liiIlIllIlIlllIlIlIIllIll;
    }
    
    public static synchronized void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final lIIIlIllIlIlllIlIlIIllIll liiIlIllIlIlllIlIlIIllIll) {
        lIIIIlIIllIIlIIlIIIlIIllI().put(s, liiIlIllIlIlllIlIlIIllIll);
    }
    
    private static Map lIIIIlIIllIIlIIlIIIlIIllI() {
        if (IIIIIlIIIlIIIIllIIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI == null) {
            IIIIIlIIIlIIIIllIIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI = new HashMap();
        }
        return IIIIIlIIIlIIIIllIIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    static {
        IIIIIlIIIlIIIIllIIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI = null;
    }
}
