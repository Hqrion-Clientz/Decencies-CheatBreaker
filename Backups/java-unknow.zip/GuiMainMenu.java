import org.apache.logging.log4j.LogManager;
import org.lwjgl.util.glu.Project;
import org.lwjgl.opengl.GL11;
import java.net.URI;
import java.util.Date;
import java.util.Calendar;
import org.lwjgl.opengl.GLContext;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.commons.io.Charsets;
import java.util.ArrayList;
import java.util.Random;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiMainMenu extends GuiScreen implements IlIllIlIIllIIIlIIlllllllI
{
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    private static final Random IlllIIIlIlllIllIlIIlllIlI;
    private float IIIIllIlIIIllIlllIlllllIl;
    private String IIIIllIIllIIIIllIllIIIlIl;
    private lIIlIIIIlIIIIIllIIIIlIIll IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private DynamicTexture IllIIIIIIIlIlIllllIIllIII;
    private final Object lIIIIllIIlIlIllIIIlIllIlI;
    private String IlllIllIlIIIIlIIlIIllIIIl;
    private String IlIlllIIIIllIllllIllIIlIl;
    private String lIllIlIlllIIlIIllIIlIIlII;
    private static final ResourceLocation IIIlIIlIlIIIlllIIlIllllll;
    private static final ResourceLocation IllIlIIIIlllIIllIIlllIIlI;
    private static final ResourceLocation[] IllIlIlIllllIlIIllllIIlll;
    public static final String lIIIIlIIllIIlIIlIIIlIIllI;
    private int IllIIlIIlllllIllIIIlllIII;
    private int lIlIlIllIIIIIIIIllllIIllI;
    private int IlllIIlllIIIIllIIllllIlIl;
    private int IllllIllllIlIIIlIIIllllll;
    private int IllIIlllIllIlIllIlIIIIIII;
    private int IlIlIIIlllllIIIlIlIlIllII;
    private ResourceLocation IIlIIllIIIllllIIlllIllIIl;
    private double lllIlIIllllIIIIlIllIlIIII;
    private float lIIIIlllIIlIlllllIlIllIII;
    private ResourceLocation lIIIlllIlIlllIIIIIIIIIlII;
    private ResourceLocation IIIIlIIIlllllllllIlllIlll;
    
    public GuiMainMenu() {
        this.lIIIIllIIlIlIllIIIlIllIlI = new Object();
        this.lIIIIlllIIlIlllllIlIllIII = 0.0f;
        this.lIIIlllIlIlllIIIIIIIIIlII = new ResourceLocation("client/logo_outer.png");
        this.IIIIlIIIlllllllllIlllIlll = new ResourceLocation("client/logo_inner.png");
        this.IlIlllIIIIllIllllIllIIlIl = GuiMainMenu.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IIIIllIIllIIIIllIllIIIlIl = "missingno";
        BufferedReader bufferedReader = null;
        try {
            final ArrayList<String> list = new ArrayList<String>();
            bufferedReader = new BufferedReader(new InputStreamReader(Minecraft.getMinecraft().llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(GuiMainMenu.IIIlIIlIlIIIlllIIlIllllll).lIIIIlIIllIIlIIlIIIlIIllI(), Charsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                final String trim = line.trim();
                if (!trim.isEmpty()) {
                    list.add(trim);
                }
            }
            if (!list.isEmpty()) {
                do {
                    this.IIIIllIIllIIIIllIllIIIlIl = list.get(GuiMainMenu.IlllIIIlIlllIllIlIIlllIlI.nextInt(list.size()));
                } while (this.IIIIllIIllIIIIllIllIIIlIl.hashCode() == 125780783);
            }
        }
        catch (IOException ex) {}
        finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                }
                catch (IOException ex2) {}
            }
        }
        this.IIIIllIlIIIllIlllIlllllIl = GuiMainMenu.IlllIIIlIlllIllIlIIlllIlI.nextFloat();
        this.IlllIllIlIIIIlIIlIIllIIIl = "";
        if (!GLContext.getCapabilities().OpenGL20 && !OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl()) {
            this.IlllIllIlIIIIlIIlIIllIIIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("title.oldgl1", new Object[0]);
            this.IlIlllIIIIllIllllIllIIlIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("title.oldgl2", new Object[0]);
            this.lIllIlIlllIIlIIllIIlIIlII = "https://help.mojang.com/customer/portal/articles/325948?ref=game";
        }
    }
    
    @Override
    public void updateScreen() {
        ++this.IIIllIllIlIlllllllIlIlIII;
        this.lllIlIIllllIIIIlIllIlIIII += 1.3617020845413208 * 0.04614214356068957;
        this.lIIIIlllIIlIlllllIlIllIII = (float)((Math.sin(this.lllIlIIllllIIIIlIllIlIIII) / 2 + 0.2800000011920929 * 1.7857142781116524) * 180);
    }
    
    @Override
    public boolean isUnicode() {
        return false;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
    }
    
    @Override
    public void s_() {
        this.IllIIIIIIIlIlIllllIIllIII = new DynamicTexture(256, 256);
        this.IIlIIllIIIllllIIlllIllIIl = this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().getDynamicTextureLocation("background", this.IllIIIIIIIlIlIllllIIllIII);
        final Calendar instance = Calendar.getInstance();
        instance.setTime(new Date());
        if (instance.get(2) + 1 == 11 && instance.get(5) == 9) {
            this.IIIIllIIllIIIIllIllIIIlIl = "Happy birthday, ez!";
        }
        else if (instance.get(2) + 1 == 6 && instance.get(5) == 1) {
            this.IIIIllIIllIIIIllIllIIIlIl = "Happy birthday, Notch!";
        }
        else if (instance.get(2) + 1 == 12 && instance.get(5) == 24) {
            this.IIIIllIIllIIIIllIllIIIlIl = "Merry X-mas!";
        }
        else if (instance.get(2) + 1 == 1 && instance.get(5) == 1) {
            this.IIIIllIIllIIIIllIllIIIlIl = "Happy new year!";
        }
        else if (instance.get(2) + 1 == 10 && instance.get(5) == 31) {
            this.IIIIllIIllIIIIllIllIIIlIl = "OOoooOOOoooo! Spooky!";
        }
        final int n = this.IIIIIIlIlIlIllllllIlllIlI / 4 + 48;
        if (this.lllIIIIIlIllIlIIIllllllII.lIIlllIIlIlllllllllIIIIIl()) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(n, 24);
        }
        else {
            this.resize(n, 24);
        }
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, n + 48, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.options", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(4, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 2, n + 48, 98, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.quit", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new IllIIIIIIIIIlIIIlllIllllI(5, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 124, n + 48));
        final Object liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
        synchronized (this.lIIIIllIIlIlIllIIIlIllIlI) {
            this.lIlIlIllIIIIIIIIllllIIllI = this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(this.IlllIllIlIIIIlIIlIIllIIIl);
            this.IllIIlIIlllllIllIIIlllIII = this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(this.IlIlllIIIIllIllllIllIIlIl);
            final int max = Math.max(this.lIlIlIllIIIIIIIIllllIIllI, this.IllIIlIIlllllIllIIIlllIII);
            this.IlllIIlllIIIIllIIllllIlIl = (this.lIIIIIllllIIIIlIlIIIIlIlI - max) / 2;
            this.IllllIllllIlIIIlIIIllllll = this.IllIllIIIlIIlllIIIllIllII.get(0).IIIllIllIlIlllllllIlIlIII - 24;
            this.IllIIlllIllIlIllIlIIIIIII = this.IlllIIlllIIIIllIIllllIlIl + max;
            this.IlIlIIIlllllIIIlIlIlIllII = this.IllllIllllIlIIIlIIIllllll + 24;
        }
    }
    
    private void resize(final int n, final int n2) {
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, n, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.singleplayer", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(2, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, n + n2 * 1, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.multiplayer", new Object[0])));
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(11, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, n, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.playdemo", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(this.IlIlIIIlllIIIlIlllIlIllIl = new lIIlIIIIlIIIIIllIIIIlIIll(12, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, n + n2 * 1, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("menu.resetdemo", new Object[0])));
        if (this.lllIIIIIlIllIlIIIllllllII.getSaveLoader().IlllIIIlIlllIllIlIIlllIlI("Demo_World") == null) {
            this.IlIlIIIlllIIIlIlllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl = false;
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IllIIlIIllIIlIIIIlllIlIlI(this, this.lllIIIIIlIllIlIIIllllllII.gameSettings));
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 5) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new lIlIlllllllIIlIIIIIlllIIl(this, this.lllIIIIIlIllIlIIIllllllII.gameSettings, this.lllIIIIIlIllIlIIIllllllII.lIlIllIlIlIIIllllIlIllIll()));
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new lllIIlllIIllIlllIlIllIIll(this));
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 2) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlllIlIllIllllllllllIlIlI(this));
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 14) {
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 4) {
            this.lllIIIIIlIllIlIIIllllllII.shutdown();
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 11) {
            this.lllIIIIIlIllIlIIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI("Demo_World", "Demo_World", IlllllIllIlIIllIllllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 12) {
            final IllIlIlllIIIIIIlIIllIIIll illlIIIlIlllIllIlIIlllIlI = this.lllIIIIIlIllIlIIIllllllII.getSaveLoader().IlllIIIlIlllIllIlIIlllIlI("Demo_World");
            if (illlIIIlIlllIllIlIIlllIlI != null) {
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(lllIIlllIIllIlllIlIllIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, illlIIIlIlllIllIlIIlllIlI.IlIlllIIIIllIllllIllIIlIl(), 12));
            }
        }
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        new IlllIllllIIlllIIllIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        if (b && n == 12) {
            final ISaveFormat saveLoader = this.lllIIIIIlIllIlIIIllllllII.getSaveLoader();
            saveLoader.IIIIllIlIIIllIlllIlllllIl();
            saveLoader.IIIIllIIllIIIIllIllIIIlIl("Demo_World");
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this);
        }
        else if (n == 13) {
            if (b) {
                try {
                    final Class<?> forName = Class.forName("java.awt.Desktop");
                    forName.getMethod("browse", URI.class).invoke(forName.getMethod("getDesktop", (Class<?>[])new Class[0]).invoke(null, new Object[0]), new URI(this.lIllIlIlllIIlIIllIIlIIlII));
                }
                catch (Throwable t) {
                    GuiMainMenu.lIIIIIIIIIlIllIIllIlIIlIl.error("Couldn't open link", t);
                }
            }
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this);
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final float n3) {
        final Tessellator instance = Tessellator.instance;
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        Project.gluPerspective((float)120, 1.0f, 0.053333335f * 0.9375f, (float)10);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glRotatef((float)180, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef((float)90, 0.0f, 0.0f, 1.0f);
        GL11.glEnable(3042);
        GL11.glDisable(3008);
        GL11.glDisable(2884);
        GL11.glDepthMask(false);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        for (int n4 = 8, i = 0; i < n4 * n4; ++i) {
            GL11.glPushMatrix();
            GL11.glTranslatef((i % n4 / (float)n4 - 0.006666667f * 75.0f) / 64, (i / n4 / (float)n4 - 0.5851064f * 0.8545455f) / 64, 0.0f);
            GL11.glRotatef(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((this.IIIllIllIlIlllllllIlIlIII + n3) / 400) * 25 + 20, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(-(this.IIIllIllIlIlllllllIlIlIII + n3) * (0.055882353f * 1.7894737f), 0.0f, 1.0f, 0.0f);
            for (int j = 0; j < 6; ++j) {
                GL11.glPushMatrix();
                if (j == 1) {
                    GL11.glRotatef((float)90, 0.0f, 1.0f, 0.0f);
                }
                if (j == 2) {
                    GL11.glRotatef((float)180, 0.0f, 1.0f, 0.0f);
                }
                if (j == 3) {
                    GL11.glRotatef((float)(-90), 0.0f, 1.0f, 0.0f);
                }
                if (j == 4) {
                    GL11.glRotatef((float)90, 1.0f, 0.0f, 0.0f);
                }
                if (j == 5) {
                    GL11.glRotatef((float)(-90), 1.0f, 0.0f, 0.0f);
                }
                this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiMainMenu.IllIlIlIllllIlIIllllIIlll[j]);
                instance.startDrawingQuads();
                instance.lIIIIlIIllIIlIIlIIIlIIllI(16777215, 255 / (i + 1));
                final float n5 = 0.0f;
                instance.addVertexWithUV(-1, -1, 1.0, 0.0f + n5, 0.0f + n5);
                instance.addVertexWithUV(1.0, -1, 1.0, 1.0f - n5, 0.0f + n5);
                instance.addVertexWithUV(1.0, 1.0, 1.0, 1.0f - n5, 1.0f - n5);
                instance.addVertexWithUV(-1, 1.0, 1.0, 0.0f + n5, 1.0f - n5);
                instance.draw();
                GL11.glPopMatrix();
            }
            GL11.glPopMatrix();
            GL11.glColorMask(true, true, true, false);
        }
        instance.lIIIIIIIIIlIllIIllIlIIlIl(0.0, 0.0, 0.0);
        GL11.glColorMask(true, true, true, true);
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glDepthMask(true);
        GL11.glEnable(2884);
        GL11.glEnable(2929);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(this.IIlIIllIIIllllIIlllIllIIl);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, 256, 256);
        GL11.glEnable(3042);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        GL11.glColorMask(true, true, true, false);
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        GL11.glDisable(3008);
        for (int n2 = 3, i = 0; i < n2; ++i) {
            instance.lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 1.0f, 1.0f, 1.0f / (i + 1));
            final int liiiiIllllIIIIlIlIIIIlIlI = this.lIIIIIllllIIIIlIlIIIIlIlI;
            final int iiiiiIlIlIlIllllllIlllIlI = this.IIIIIIlIlIlIllllllIlllIlI;
            final float n3 = (i - n2 / 2) / (float)256;
            instance.addVertexWithUV(liiiiIllllIIIIlIlIIIIlIlI, iiiiiIlIlIlIllllllIlllIlI, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 0.0f + n3, 1.0);
            instance.addVertexWithUV(liiiiIllllIIIIlIlIIIIlIlI, 0.0, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 1.0f + n3, 1.0);
            instance.addVertexWithUV(0.0, 0.0, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 1.0f + n3, 0.0);
            instance.addVertexWithUV(0.0, iiiiiIlIlIlIllllllIlllIlI, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 0.0f + n3, 0.0);
        }
        instance.draw();
        GL11.glEnable(3008);
        GL11.glColorMask(true, true, true, true);
    }
    
    private void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final float n3) {
        this.lllIIIIIlIllIlIIIllllllII.getFramebuffer().unbindFramebuffer();
        GL11.glViewport(0, 0, 256, 256);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        this.lllIIIIIlIllIlIIIllllllII.getFramebuffer().bindFramebuffer(true);
        GL11.glViewport(0, 0, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        final float n4 = (this.lIIIIIllllIIIIlIlIIIIlIlI > this.IIIIIIlIlIlIllllllIlllIlI) ? (120 / (float)this.lIIIIIllllIIIIlIlIIIIlIlI) : (120 / (float)this.IIIIIIlIlIlIllllllIlllIlI);
        final float n5 = this.IIIIIIlIlIlIllllllIlllIlI * n4 / 256;
        final float n6 = this.lIIIIIllllIIIIlIlIIIIlIlI * n4 / 256;
        instance.lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 1.0f, 1.0f, 1.0f);
        final int liiiiIllllIIIIlIlIIIIlIlI = this.lIIIIIllllIIIIlIlIIIIlIlI;
        final int iiiiiIlIlIlIllllllIlllIlI = this.IIIIIIlIlIlIllllllIlllIlI;
        instance.addVertexWithUV(0.0, iiiiiIlIlIlIllllllIlllIlI, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 1.1486486f * 0.43529412f - n5, 0.4f * 1.25f + n6);
        instance.addVertexWithUV(liiiiIllllIIIIlIlIIIIlIlI, iiiiiIlIlIlIllllllIlllIlI, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 1.72f * 0.29069766f - n5, 6.6666665f * 0.075f - n6);
        instance.addVertexWithUV(liiiiIllllIIIIlIlIIIIlIlI, 0.0, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 6.125f * 0.08163265f + n5, 0.10638298f * 4.7f - n6);
        instance.addVertexWithUV(0.0, 0.0, GuiMainMenu.llIlIIIlIIIIlIlllIlIIIIll, 0.44827586f * 1.1153846f + n5, 0.77272725f * 0.64705884f + n6);
        instance.draw();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        GL11.glDisable(3008);
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        GL11.glEnable(3008);
        final Tessellator instance = Tessellator.instance;
        final int n4 = this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 274 / 2;
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)this.lIIIIIllllIIIIlIlIIIIlIlI, (float)this.IIIIIIlIlIlIllllllIlllIlI, -2130706433, 16777215);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)this.lIIIIIllllIIIIlIlIIIIlIlI, (float)this.IIIIIIlIlIlIllllllIlllIlI, 0, Integer.MIN_VALUE);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 40), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 40), 0.0f);
        final int n5 = 40;
        GL11.glTranslatef((float)n5, (float)n5, (float)n5);
        GL11.glRotatef(this.lIIIIlllIIlIlllllIlIllIII, 0.0f, 0.0f, 1.0f);
        GL11.glTranslatef((float)(-n5), (float)(-n5), (float)(-n5));
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIlllIlIlllIIIIIIIIIlII, (float)n5, 0.0f, 0.0f);
        GL11.glPopMatrix();
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIlIIIlllllllllIlllIlll, 40, (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 40), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 38));
        instance.setColorOpaque_I(-1);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 90), (float)70, 0.0f);
        GL11.glRotatef((float)(-20), 0.0f, 0.0f, 1.0f);
        final float n6 = (0.25f * 7.2f - MathHelper.IIIIllIIllIIIIllIllIIIlIl(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(Minecraft.getSystemTime() % 1000L / (float)1000 * (3.998391f * 0.78571427f) * 2.0f) * (0.09589041f * 1.0428572f))) * 100 / (this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(this.IIIIllIIllIIIIllIllIIIlIl) + 32);
        GL11.glScalef(n6, n6, n6);
        GL11.glPopMatrix();
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, "CheatBreaker 1.7.10 Dev", 2, this.IIIIIIlIlIlIllllllIlllIlI - 10, -1);
        final String s = "Copyright Mojang AB. Do not distribute!";
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, s, this.lIIIIIllllIIIIlIlIIIIlIlI - this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(s) - 2, this.IIIIIIlIlIlIllllllIlllIlI - 10, -1);
        if (this.IlllIllIlIIIIlIIlIIllIIIl != null && this.IlllIllIlIIIIlIIlIIllIIIl.length() > 0) {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.IlllIIlllIIIIllIIllllIlIl - 2), (float)(this.IllllIllllIlIIIlIIIllllll - 2), (float)(this.IllIIlllIllIlIllIlIIIIIII + 2), (float)(this.IlIlIIIlllllIIIlIlIlIllII - 1), 1428160512);
            this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, this.IlllIllIlIIIIlIIlIIllIIIl, this.IlllIIlllIIIIllIIllllIlIl, this.IllllIllllIlIIIlIIIllllll, -1);
            this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, this.IlIlllIIIIllIllllIllIIlIl, (this.lIIIIIllllIIIIlIlIIIIlIlI - this.IllIIlIIlllllIllIIIlllIII) / 2, this.IllIllIIIlIIlllIIIllIllII.get(0).IIIllIllIlIlllllllIlIlIII - 12, -1);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        final Object liiiIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
        synchronized (this.lIIIIllIIlIlIllIIIlIllIlI) {
            if (this.IlllIllIlIIIIlIIlIIllIIIl.length() > 0 && n >= this.IlllIIlllIIIIllIIllllIlIl && n <= this.IllIIlllIllIlIllIlIIIIIII && n2 >= this.IllllIllllIlIIIlIIIllllll && n2 <= this.IlIlIIIlllllIIIlIlIlIllII) {
                final IIlIIIIllIllllIlIIlIIlIII ilIIIIllIllllIlIIlIIlIII = new IIlIIIIllIllllIlIIlIIlIII(this, this.lIllIlIlllIIlIIllIIlIIlII, 13, true);
                ilIIIIllIllllIlIIlIIlIII.shutdownMinecraftApplet();
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(ilIIIIllIllllIlIIlIIlIII);
            }
        }
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
        IlllIIIlIlllIllIlIIlllIlI = new Random();
        IIIlIIlIlIIIlllIIlIllllll = new ResourceLocation("texts/splashes.txt");
        IllIlIIIIlllIIllIIlllIIlI = new ResourceLocation("textures/gui/title/minecraft.png");
        IllIlIlIllllIlIIllllIIlll = new ResourceLocation[] { new ResourceLocation("textures/gui/title/background/panorama_0.png"), new ResourceLocation("textures/gui/title/background/panorama_1.png"), new ResourceLocation("textures/gui/title/background/panorama_2.png"), new ResourceLocation("textures/gui/title/background/panorama_3.png"), new ResourceLocation("textures/gui/title/background/panorama_4.png"), new ResourceLocation("textures/gui/title/background/panorama_5.png") };
        lIIIIlIIllIIlIIlIIIlIIllI = "Please click " + IlIllllIIlIIllIlIlllllIlI.IllIllIIIlIIlllIIIllIllII + "here" + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII + " for more information.";
    }
}
