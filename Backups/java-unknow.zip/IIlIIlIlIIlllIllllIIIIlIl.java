import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIlIIlllIllllIIIIlIl extends IIlllllllIlllIIllllIIlIll
{
    private final boolean lIIIIlllIIlIlllllIlIllIII;
    
    public IIlIIlIlIIlllIllllIIIIlIl(final boolean liiiIlllIIlIlllllIlIllIII) {
        super(Material.IllIllIIIlIIlllIIIllIllII);
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        if (liiiIlllIIlIlllllIlIllIII) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f);
        }
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            if (this.lIIIIlllIIlIlllllIlIllIII && !iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, 4);
            }
            else if (!this.lIIIIlllIIlIlllllIlIllIII && iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.llIIIlllllIlllIIllIlIIlII, 0, 2);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            if (this.lIIIIlllIIlIlllllIlIllIII && !iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, 4);
            }
            else if (!this.lIIIIlllIIlIlllllIlIllIII && iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.llIIIlllllIlllIIllIlIIlII, 0, 2);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll && this.lIIIIlllIIlIlllllIlIllIII && !iiiiiIllIlIIIIlIlllIllllI.IIIIIIlIlIlIllllllIlllIlI(n, n2, n3)) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.IlIllIIIIIlIlllIIIIlllIIl, 0, 2);
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIllIIIIIlIlllIIIIlllIIl);
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIllIIIIIlIlllIIIIlllIIl);
    }
    
    @Override
    protected lIlIlIlIlIllllIlllIIIlIlI IIIllIllIlIlllllllIlIlIII(final int n) {
        return new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IlIllIIIIIlIlllIIIIlllIIl);
    }
}
