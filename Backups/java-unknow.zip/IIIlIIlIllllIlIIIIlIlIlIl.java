// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIlIIlIllllIlIIIIlIlIlIl extends DELETE_ME_C
{
    double lIIIIIIIIIlIllIIllIlIIlIl();
    
    double IlllIIIlIlllIllIlIIlllIlI();
    
    double IIIIllIlIIIllIlllIlllllIl();
    
    int IIIIllIIllIIIIllIllIIIlIl();
    
    int IlIlIIIlllIIIlIlllIlIllIl();
    
    int IIIllIllIlIlllllllIlIlIII();
    
    int IllIIIIIIIlIlIllllIIllIII();
    
    IllIllIlIIlllIllIIllIlIIl lIIIIllIIlIlIllIIIlIllIlI();
}
