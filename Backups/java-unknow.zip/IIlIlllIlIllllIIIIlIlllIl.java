// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIlIllllIIIIlIlllIl
{
    private final IllIIIIIIlIIlIIllIllIIIIl lIIIIlIIllIIlIIlIIIlIIllI;
    private final String lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIlllIlIllllIIIIlIlllIl(final IllIIIIIIlIIlIIllIllIIIIl liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public IllIIIIIIlIIlIIllIllIIIIl lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final IIlIlllIlIllllIIIIlIlllIl ilIlllIlIllllIIIIlIlllIl = (IIlIlllIlIllllIIIIlIlllIl)o;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != ilIlllIlIllllIIIIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI) {
            return false;
        }
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            if (!this.lIIIIIIIIIlIllIIllIlIIlIl.equals(ilIlllIlIllllIIIIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl)) {
                return false;
            }
        }
        else if (ilIlllIlIllllIIIIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "ClickEvent{action=" + this.lIIIIlIIllIIlIIlIIIlIIllI + ", value='" + this.lIIIIIIIIIlIllIIllIlIIlIl + '\'' + '}';
    }
    
    @Override
    public int hashCode() {
        return 31 * this.lIIIIlIIllIIlIIlIIIlIIllI.hashCode() + ((this.lIIIIIIIIIlIllIIllIlIIlIl != null) ? this.lIIIIIIIIIlIllIIllIlIIlIl.hashCode() : 0);
    }
}
