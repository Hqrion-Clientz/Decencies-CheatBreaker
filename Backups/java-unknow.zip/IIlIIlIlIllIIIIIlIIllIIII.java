import java.util.HashMap;
import java.util.List;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIlIllIIIIIlIIllIIII extends lIIlllIIIlIllllllIlIlIIII
{
    private static final Map IlllIllIlIIIIlIIlIIllIIIl;
    public final String lIIIIllIIlIlIllIIIlIllIlI;
    
    protected IIlIIlIlIllIIIIIlIIllIIII(final String liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = 1;
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlIlIIIlllIIIlIlllIlIllIl);
        IIlIIlIlIllIIIIIlIIllIIII.IlllIllIlIIIIlIIlIIllIIIl.put(liiiIllIIlIlIllIIIlIllIlI, this);
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) != IllllllIllIIlllIllIIlIIll.IllIlIIIIlIlllIlllllllIIl || iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) != 0) {
            return false;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            return true;
        }
        ((llIIIIIlIlIlIlIlllIIIIIll)IllllllIllIIlllIllIIlIIll.IllIlIIIIlIlllIlllllllIIl).lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, lIlIlIlIlIllllIlllIIIlIlI);
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(null, 1005, n, n2, n3, lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this));
        --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
        return true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final List list, final boolean b) {
        list.add(this.IlIIlIIIIlIIIIllllIIlIllI());
    }
    
    public String IlIIlIIIIlIIIIllllIIlIllI() {
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI("item.record." + this.lIIIIllIIlIlIllIIIlIllIlI + ".desc");
    }
    
    @Override
    public CBCosmeticRarity IlIlllIIIIllIllllIllIIlIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return CBCosmeticRarity.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public static IIlIIlIlIllIIIIIlIIllIIII IIIIllIlIIIllIlllIlllllIl(final String s) {
        return IIlIIlIlIllIIIIIlIIllIIII.IlllIllIlIIIIlIIlIIllIIIl.get(s);
    }
    
    static {
        IlllIllIlIIIIlIIlIIllIIIl = new HashMap();
    }
}
