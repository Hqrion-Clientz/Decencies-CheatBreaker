import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIllIlIllIlIIIIIIlI extends Entity
{
    private IIlllllllIlllIIllllIIlIll IIIIllIIllIIIIllIllIIIlIl;
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public boolean IlllIIIlIlllIllIlIIlllIlI;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private boolean IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private float lIIIIllIIlIlIllIIIlIllIlI;
    public IlIIIllIIlIIlllIllllIIIIl IIIIllIlIIIllIlllIlllllIl;
    
    public IIIllllIllIlIllIlIIIIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IlllIIIlIlllIllIlIIlllIlI = true;
        this.IllIIIIIIIlIlIllllIIllIII = 40;
        this.lIIIIllIIlIlIllIIIlIllIlI = 2.0f;
    }
    
    public IIIllllIllIlIllIlIIIIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, 0);
    }
    
    public IIIllllIllIlIllIlIIIIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double lIllIllIlIIllIllIlIlIIlIl, final double llIlIIIllIIIIlllIlIIIIIlI, final double lIllIlIlllIIlIIllIIlIIlII, final IIlllllllIlllIIllllIIlIll iiiIllIIllIIIIllIllIIIlIl, final int liiiIlIIllIIlIIlIIIlIIllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IlllIIIlIlllIllIlIIlllIlI = true;
        this.IllIIIIIIIlIlIllllIIllIII = 40;
        this.lIIIIllIIlIlIllIIIlIllIlI = 2.0f;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IIIIIIlIlIlIllllllIlllIlI = true;
        this.IIIIllIIllIIIIllIllIIIlIl(4.125f * 0.23757577f, 0.8888372f * 1.1025641f);
        this.lIlIllIlIlIIIllllIlIllIll = this.llllIIIIlIlIllIIIllllIIll / 2.0f;
        this.IlllIIIlIlllIllIlIIlllIlI(lIllIllIlIIllIllIlIlIIlIl, llIlIIIllIIIIlllIlIIIIIlI, lIllIlIlllIIlIIllIIlIIlII);
        this.IllIIlIIlllllIllIIIlllIII = 0.0;
        this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
        this.IlllIIlllIIIIllIIllllIlIl = 0.0;
        this.lIllIllIlIIllIllIlIlIIlIl = lIllIllIlIIllIllIlIlIIlIl;
        this.llIlIIIllIIIIlllIlIIIIIlI = llIlIIIllIIIIlllIlIIIIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = lIllIlIlllIIlIIllIIlIIlII;
    }
    
    @Override
    protected boolean IIIllIllIlIlllllllIlIlIII() {
        return false;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
    }
    
    @Override
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return !this.IIllIlIllIlIllIIlIllIlIII;
    }
    
    @Override
    public void x_() {
        if (this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
        else {
            this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
            this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
            this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
            ++this.lIIIIIIIIIlIllIIllIlIIlIl;
            this.lIlIlIllIIIIIIIIllllIIllI -= 0.029176469854252565 * 1.3709677457809448;
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.IllIIlIIlllllIllIIIlllIII *= 0.5522388219833374 * 1.7745945776754095;
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.8292682766914368 * 1.1817647516717145;
            this.IlllIIlllIIIIllIIllllIlIl *= 0.367499996200204 * 2.6666667461395264;
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
                final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI);
                final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
                if (this.lIIIIIIIIIlIllIIllIlIIlIl == 1) {
                    if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3) != this.IIIIllIIllIIIIllIllIIIlIl) {
                        this.IlIllllIIIlIllllIIIIIllII();
                        return;
                    }
                    this.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
                }
                if (this.lIIIIlllIIlIlllllIlIllIII) {
                    this.IllIIlIIlllllIllIIIlllIII *= 0.2100000014305115 * 3.3333332538604736;
                    this.IlllIIlllIIIIllIIllllIlIl *= 1.01694917678833 * 0.6883333051999416;
                    this.lIlIlIllIIIIIIIIllllIIllI *= -0.28947368057811035 * 1.7272727489471436;
                    if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3) != IllllllIllIIlllIllIIlIIll.lIIIlllIlIlllIIIIIIIIIlII) {
                        this.IlIllllIIIlIllllIIIIIllII();
                        if (!this.IlIlIIIlllIIIlIlllIlIllIl && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, true, 1, null, null) && !lIIIIIllIlIIIllllIlIlIIIl.IlllIllIlIIIIlIIlIIllIIIl(this.lIIlllIIlIlllllllllIIIIIl, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3) && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, this.IIIIllIIllIIIIllIllIIIlIl, this.lIIIIlIIllIIlIIlIIIlIIllI, 3)) {
                            if (this.IIIIllIIllIIIIllIllIIIlIl instanceof lIIIIIllIlIIIllllIlIlIIIl) {
                                ((lIIIIIllIlIIIllllIlIlIIIl)this.IIIIllIIllIIIIllIllIIIlIl).IIIllIllIlIlllllllIlIlIII(this.lIIlllIIlIlllllllllIIIIIl, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, this.lIIIIlIIllIIlIIlIIIlIIllI);
                            }
                            if (this.IIIIllIlIIIllIlllIlllllIl != null && this.IIIIllIIllIIIIllIllIIIlIl instanceof lIIIlIlIlIIIllIlIllIIllIl) {
                                final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
                                if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                                    final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
                                    liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
                                    for (final String s : this.IIIIllIlIIIllIlllIlllllIl.IIIIllIlIIIllIlllIlllllIl()) {
                                        final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI = this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(s);
                                        if (!s.equals("x") && !s.equals("y") && !s.equals("z")) {
                                            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(s, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
                                        }
                                    }
                                    liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
                                    liiiiiiiiIlIllIIllIlIIlIl.lIllIllIlIIllIllIlIlIIlIl();
                                }
                            }
                        }
                        else if (this.IlllIIIlIlllIllIlIIlllIlI && !this.IlIlIIIlllIIIlIlllIlIllIl) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(this.IIIIllIIllIIIIllIllIIIlIl, 1, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI)), 0.0f);
                        }
                    }
                }
                else if ((this.lIIIIIIIIIlIllIIllIlIIlIl > 100 && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && (illlIIIlIlllIllIlIIlllIlI2 < 1 || illlIIIlIlllIllIlIIlllIlI2 > 256)) || this.lIIIIIIIIIlIllIIllIlIIlIl > 600) {
                    if (this.IlllIIIlIlllIllIlIIlllIlI) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(this.IIIIllIIllIIIIllIllIIIlIl, 1, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI)), 0.0f);
                    }
                    this.IlIllllIIIlIllllIIIIIllII();
                }
            }
        }
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        if (this.IIIllIllIlIlllllllIlIlIII) {
            final int ilIlIIIlllIIIlIlllIlIllIl = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(n - 1.0f);
            if (ilIlIIIlllIIIlIlllIlIllIl > 0) {
                final ArrayList<Entity> list = new ArrayList<Entity>(this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.lllIlIIllllIIIIlIllIlIIII));
                final boolean b = this.IIIIllIIllIIIIllIllIIIlIl == IllllllIllIIlllIllIIlIIll.lllIIlIIIllIIlllIlIIIllIl;
                final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll = b ? lllIIIIIIIllIlllllIIlllll.lIIlIlIllIIlIIIlIIIlllIII : lllIIIIIIIllIlllllIIlllll.IIIlllIIIllIllIlIIIIIIlII;
                final Iterator<Entity> iterator = list.iterator();
                while (iterator.hasNext()) {
                    iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, (float)Math.min(MathHelper.IIIIllIlIIIllIlllIlllllIl(ilIlIIIlllIIIlIlllIlIllIl * this.lIIIIllIIlIlIllIIIlIllIlI), this.IllIIIIIIIlIlIllllIIllIII));
                }
                if (b && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 30.5 * 0.001639344286723215 + ilIlIIIlllIIIlIlllIlIllIl * (0.045454544469344736 * 1.100000023841858)) {
                    int n2 = this.lIIIIlIIllIIlIIlIIIlIIllI >> 2;
                    final int n3 = this.lIIIIlIIllIIlIIlIIIlIIllI & 0x3;
                    if (++n2 > 2) {
                        this.IlIlIIIlllIIIlIlllIlIllIl = true;
                    }
                    else {
                        this.lIIIIlIIllIIlIIlIIIlIIllI = (n3 | n2 << 2);
                    }
                }
            }
        }
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Tile", (byte)IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("TileID", IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Data", (byte)this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Time", (byte)this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("DropItem", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("HurtEntities", this.IIIllIllIlIlllllllIlIlIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("FallHurtAmount", this.lIIIIllIIlIlIllIIIlIllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("FallHurtMax", this.IllIIIIIIIlIlIllllIIllIII);
        if (this.IIIIllIlIIIllIlllIlllllIl != null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("TileEntityData", this.IIIIllIlIIIllIlllIlllllIl);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("TileID", 99)) {
            this.IIIIllIIllIIIIllIllIIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("TileID"));
        }
        else {
            this.IIIIllIIllIIIIllIllIIIlIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("Tile") & 0xFF);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("Data") & 0xFF);
        this.lIIIIIIIIIlIllIIllIlIIlIl = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("Time") & 0xFF);
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("HurtEntities", 99)) {
            this.IIIllIllIlIlllllllIlIlIII = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("HurtEntities");
            this.lIIIIllIIlIlIllIIIlIllIlI = ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("FallHurtAmount");
            this.IllIIIIIIIlIlIllllIIllIII = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("FallHurtMax");
        }
        else if (this.IIIIllIIllIIIIllIllIIIlIl == IllllllIllIIlllIllIIlIIll.lllIIlIIIllIIlllIlIIIllIl) {
            this.IIIllIllIlIlllllllIlIlIII = true;
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("DropItem", 99)) {
            this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("DropItem");
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("TileEntityData", 10)) {
            this.IIIIllIlIIIllIlllIlllllIl = ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("TileEntityData");
        }
        if (this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            this.IIIIllIIllIIIIllIllIIIlIl = IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII;
        }
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    public IIIIIIllIlIIIIlIlllIllllI IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIlllIIlIlllllllllIIIIIl;
    }
    
    public void sendClickBlockToController(final boolean iiIllIllIlIlllllllIlIlIII) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public boolean lIlIlIlIIlIlllIIIIIIllllI() {
        return false;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllIIIIIlllIlllIIIllIl lIlIllIIIIIlllIlllIIIllIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllIIIIIlllIlllIIIllIl);
        lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI("Immitating block ID", IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl));
        lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI("Immitating block data", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public IIlllllllIlllIIllllIIlIll IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
}
