import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonDeserializer;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIIllllIIIIIIlllIII implements JsonDeserializer, JsonSerializer
{
    public lIlIIIlIlIllllIIlIlIIlllI lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) {
        final JsonObject iiiIllIIllIIIIllIllIIIlIl = llIlllIllIllIIIlllIIIIlll.IIIIllIIllIIIIllIllIIIlIl(jsonElement, "status");
        final lIlIIIlIlIllllIIlIlIIlllI lIlIIIlIlIllllIIlIlIIlllI = new lIlIIIlIlIllllIIlIlIIlllI();
        if (iiiIllIIllIIIIllIllIIIlIl.has("description")) {
            lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI((IllIllIIlIIlIlllIIllIIIlI)jsonDeserializationContext.deserialize(iiiIllIIllIIIIllIllIIIlIl.get("description"), (Type)IllIllIIlIIlIlllIIllIIIlI.class));
        }
        if (iiiIllIIllIIIIllIllIIIlIl.has("players")) {
            lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIlIllIlIIlIIlllIIlIlI)jsonDeserializationContext.deserialize(iiiIllIIllIIIIllIllIIIlIl.get("players"), (Type)lIIlIlIllIlIIlIIlllIIlIlI.class));
        }
        if (iiiIllIIllIIIIllIllIIIlIl.has("version")) {
            lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI((lIIIlIllIIIlllllIIIIIIIlI)jsonDeserializationContext.deserialize(iiiIllIIllIIIIllIllIIIlIl.get("version"), (Type)lIIIlIllIIIlllllIIIIIIIlI.class));
        }
        if (iiiIllIIllIIIIllIllIIIlIl.has("favicon")) {
            lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI(llIlllIllIllIIIlllIIIIlll.IIIIllIIllIIIIllIllIIIlIl(iiiIllIIllIIIIllIllIIIlIl, "favicon"));
        }
        return lIlIIIlIlIllllIIlIlIIlllI;
    }
    
    public JsonElement lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllllIIlIlIIlllI lIlIIIlIlIllllIIlIlIIlllI, final Type type, final JsonSerializationContext jsonSerializationContext) {
        final JsonObject jsonObject = new JsonObject();
        if (lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI() != null) {
            jsonObject.add("description", jsonSerializationContext.serialize((Object)lIlIIIlIlIllllIIlIlIIlllI.lIIIIlIIllIIlIIlIIIlIIllI()));
        }
        if (lIlIIIlIlIllllIIlIlIIlllI.lIIIIIIIIIlIllIIllIlIIlIl() != null) {
            jsonObject.add("players", jsonSerializationContext.serialize((Object)lIlIIIlIlIllllIIlIlIIlllI.lIIIIIIIIIlIllIIllIlIIlIl()));
        }
        if (lIlIIIlIlIllllIIlIlIIlllI.IlllIIIlIlllIllIlIIlllIlI() != null) {
            jsonObject.add("version", jsonSerializationContext.serialize((Object)lIlIIIlIlIllllIIlIlIIlllI.IlllIIIlIlllIllIlIIlllIlI()));
        }
        if (lIlIIIlIlIllllIIlIlIIlllI.IIIIllIlIIIllIlllIlllllIl() != null) {
            jsonObject.addProperty("favicon", lIlIIIlIlIllllIIlIlIIlllI.IIIIllIlIIIllIlllIlllllIl());
        }
        return (JsonElement)jsonObject;
    }
    
    public JsonElement serialize(final Object o, final Type type, final JsonSerializationContext jsonSerializationContext) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((lIlIIIlIlIllllIIlIlIIlllI)o, type, jsonSerializationContext);
    }
}
