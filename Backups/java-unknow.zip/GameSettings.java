import org.apache.logging.log4j.LogManager;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import org.lwjgl.opengl.Display;
import java.util.Arrays;
import com.google.common.primitives.Ints;
import org.lwjgl.input.Mouse;
import java.util.Objects;
import org.lwjgl.input.Keyboard;
import org.apache.commons.lang3.ArrayUtils;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.io.File;
import java.lang.reflect.ParameterizedType;
import com.google.gson.Gson;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class GameSettings
{
    private static final Logger llllIlIlllIIlIlIIIIlllIII;
    private static final Gson IllIIllIIIlIlllIlIlIIlIII;
    private static final ParameterizedType IIlIlIIIIllIIIllIlIIIllll;
    private static final String[] IlIlIIIlIlIllIIIIIllllIIl;
    private static final String[] IlIIlIIlIIlllIlIIIlIllIIl;
    private static final String[] llIIIIIIllIIIllllIIllIIII;
    private static final String[] lIllIlIlIlllIIIIllIlIIIII;
    private static final String[] lllIllIllllIllIllIlllllIl;
    private static final String[] IIlllIIlIlIIIlIlIlIIlllII;
    private static final String[] lIlIIllIIlllIlIlllIIIIllI;
    public float lIIIIlIIllIIlIIlIIIlIIllI;
    public boolean lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public boolean IIIIllIlIIIllIlllIlllllIl;
    public boolean IIIIllIIllIIIIllIllIIIlIl;
    public boolean IlIlIIIlllIIIlIlllIlIllIl;
    public boolean IIIllIllIlIlllllllIlIlIII;
    public int limitFramerate;
    public boolean fancyGraphics;
    public int IlllIllIlIIIIlIIlIIllIIIl;
    public int IlIlllIIIIllIllllIllIIlIl;
    public float llIIlllIIIIlllIllIlIlllIl;
    public int lIIlIlIllIIlIIIlIIIlllIII;
    public boolean IIIlllIIIllIllIlIIIIIIlII;
    public int llIlIIIlIIIIlIlllIlIIIIll;
    public boolean IIIlIIllllIIllllllIlIIIll;
    public boolean lllIIIIIlIllIlIIIllllllII;
    public boolean lIIIIIllllIIIIlIlIIIIlIlI;
    public boolean IIIIIIlIlIlIllllllIlllIlI;
    public float IllIllIIIlIIlllIIIllIllII;
    public int IlIIlIIIIlIIIIllllIIlIllI;
    public int lIIlIIllIIIIIlIllIIIIllII;
    public float lIIlllIIlIlllllllllIIIIIl;
    public int lIllIllIlIIllIllIlIlIIlIl;
    public int llIlIIIllIIIIlllIlIIIIIlI;
    public int lIllIlIlllIIlIIllIIlIIlII;
    public int IIIlIIlIlIIIlllIIlIllllll;
    public int IllIlIIIIlllIIllIIlllIIlI;
    public int IllIlIlIllllIlIIllllIIlll;
    public int IllIIlIIlllllIllIIIlllIII;
    public boolean lIlIlIllIIIIIIIIllllIIllI;
    public boolean IlllIIlllIIIIllIIllllIlIl;
    public boolean IllllIllllIlIIIlIIIllllll;
    public boolean IllIIlllIllIlIllIlIIIIIII;
    public boolean IlIlIIIlllllIIIlIlIlIllII;
    public boolean IIlIIllIIIllllIIlllIllIIl;
    public boolean lllIlIIllllIIIIlIllIlIIII;
    public int lIIIIlllIIlIlllllIlIllIII;
    public int lIIIlllIlIlllIIIIIIIIIlII;
    public int IIIIlIIIlllllllllIlllIlll;
    public boolean IlIllllIIIlIllllIIIIIllII;
    public int IlIIIIllIIIIIlllIIlIIlllI;
    public boolean llIlIlIllIlIIlIlllIllIIlI;
    public boolean llIlIlIlllIlllllIIIllIIll;
    public boolean IIllIlIllIlIllIIlIllIlIII;
    public String lIlIllIlIlIIIllllIlIllIll;
    public boolean IlIIlIIlIllIIIIllIIllIlIl;
    public boolean llllIIIIlIlIllIIIllllIIll;
    public boolean IIlIlIIlIIIlIlllllIIlIIlI;
    public boolean lIIIlllIIIlIIIIIlIIIIIIII;
    public boolean lIIlIIIIIIIIllIIllIIlllIl;
    public boolean IllllllIllllIIlllIllllllI;
    public boolean lIlIlIIIlIIllllllllIIlllI;
    public int IlIlllIllIlIllIlllIlllIll;
    public boolean llIIIllIIllllIlIlIlIlIIll;
    public boolean IIIIIlIllIllIlIIllIIlIllI;
    public boolean lIIllIIllllllIIlllIlllIIl;
    public int lllIIllllIIlIlIlIlIIIlIII;
    public boolean IlIIllIlIlIIIllIllIIlIIII;
    public int IlIlllIIIIlIllIlllIlIIIll;
    public int IIIlIllIlllIlIllIllllllll;
    public int IllllllllIlIIIIIIIIllIIII;
    public boolean lIIlIlIIlIlIlIIlIlIlllIIl;
    public boolean IllIIIlIIlIllIllIIllllIIl;
    public boolean IIlIlllIllIlIlIIIIIlllIll;
    public boolean IlIIllIIIlllIIIIlIIIIlIll;
    public boolean lIIIIIIlIIllllllIIIlIlIIl;
    public boolean llIIIlIlIIlIlIIlIllIllIll;
    public boolean IlIIlllIlIIIlIIIlIlIlIlIl;
    public boolean IIIlllllIIlIlIIIllllllIII;
    public boolean lIlIlIIIIllIlllIlIIlllIlI;
    public boolean IIllllIllllIIIlIIllllIlll;
    public boolean llllIIIIIlIlIlIlIllIIIIII;
    public boolean IllIIIIllllllIlllllIlIlll;
    public boolean IIIllllIlIIlIIIlIlIlllIII;
    public boolean IIlIlllllIIIlIIllIllIlIlI;
    public boolean IlIllIllIllIllIllllIIIlII;
    public static final int lllIllIllIlIllIlIIllllIIl = 0;
    public static final int IIIIIIIllIllllIIlIIlllIII = 1;
    public static final int IIIIlIllIIIIIIlIIIIIlllll = 2;
    public static final int llllIIlIlIllIllllIIIIllll = 3;
    public static final int IIlIlIlllIllIIlIllIIlIIlI = 0;
    public static final int lIlIIllIIIlllIIllIIlIIllI = 1;
    public static final int lIIIlIIIIIIlIIlIIlIIlIIlI = 2;
    public static final int lIlIlIlIIlIlllIIIIIIllllI = 0;
    public static final int llllIIllIIlllllIlIlIIllll = 1;
    public static final int IllIlIIIIlIlllIlllllllIIl = 2;
    public static final String IIlllllIIlIlIIlIIlllIIIII = "Default";
    public KeyBinding IllIlIlllIIlIIIIIlIIIIIll;
    public File llllIlIlIlllllIllIIllIIIl;
    public boolean lllIIlIIllIllIIllIIlIIIIl;
    public List resourcePacks;
    public IlllIIIIllIlIIlIIIIllllII chatVisibility;
    public boolean llIIlllIlIIlIIIIIlIllllll;
    public boolean IIllllIIIIllIIlIllIIIIIlI;
    public boolean lIllIllIllllllIllIlllIlIl;
    public float IlIllIIllIIIIIllIlIIIIIIl;
    public boolean lIlllIIlllIllIlllIIllllIl;
    public boolean fullScreen;
    public boolean enableVsync;
    public boolean lIIIlIIlIIIIIllIIlIlIlIII;
    public boolean IIIlllIllIlIIllIIllIlIlll;
    public boolean IlIlIIIIIllIlIlIIllIlIIIl;
    public boolean lIIIllIIIIlIIllIIIIIIIlll;
    public boolean lIIIIIIlIIllIlIlIllIIIIll;
    public int overrideWidth;
    public int overrideHeight;
    public boolean llllIIllllllIlIIlIlIIIllI;
    public float IlllllIllIIIllIIIllIllIII;
    public float lIlllllIlIllllIIIllllllII;
    public float lIlIIIlIIIlllllllllllIlIl;
    public float IIllllllIlIIIIlllIlIlIlll;
    public boolean IlllIIllIlllllIIIlIllIIII;
    public int mipmapLevels;
    public int anisotropicFiltering;
    private Map lllIlllllIllllllIIlIlllll;
    public float llIIllIllIlIlIlIllllllIII;
    public float IlIIlIIllIllIIIIIlllIIlll;
    public float llIIIIlIlIIIllIllIIIIllII;
    public float llllIllIIIlIIIlIllIlIlIlI;
    public float llIIllllIlIlIllIlIllIlIlI;
    public int IlllIIIIlllllIlIlllllIlll;
    public boolean IIIlIllIIllllIIIllllIllll;
    public String llllIIIllllllIlllIIlIIlll;
    public int lIlllIIIlIlIIlIIIIIIlIlII;
    public int IlIllIIIIIlIlllIIIIlllIIl;
    public int llIIIlllllIlllIIllIlIIlII;
    public KeyBinding lIIIlIlIIIlIlIlllIlIlllII;
    public KeyBinding llIlIlIIIIIIIlllIIIllIlll;
    public KeyBinding IllIIIIIIlIlIlllllllIIllI;
    public KeyBinding IlIIlllIIlIlIIIlIlllllIll;
    public KeyBinding lIllIllIIlIlIIIIllIllllll;
    public KeyBinding llllllIIIIIlllllIllIlIllI;
    public KeyBinding keyBindInventory;
    public KeyBinding keyBindUseItem;
    public KeyBinding keyBindDrop;
    public KeyBinding keyBindAttack;
    public KeyBinding keyBindPickBlock;
    public KeyBinding lIIlIlIllllllIllllIIllllI;
    public KeyBinding keyBindChat;
    public KeyBinding IIIIIlllIllIIIIllIllIIIII;
    public KeyBinding keyBindCommand;
    public KeyBinding llllIlIIIIIllIIlIlllIllll;
    public KeyBinding IIIlIIIIllIIIlIIIIIlllllI;
    public KeyBinding IlllIIIllIlIlIIIllIIIlIlI;
    public KeyBinding IllIIIIIIlllIIIlIIIlIIIlI;
    public KeyBinding[] keyBindsHotbar;
    public KeyBinding[] lllIIlIIIllIIlllIlIIIllIl;
    protected Minecraft IlIIIIlIlIllIIlIIIIllllll;
    public File IIIlIllIIIlllIIlIIllIlIII;
    public lIIlIlIIllIIllllIIIlIlIlI IlIIIIlllIIIlIIllllIIIlll;
    public boolean IllIIIIIllllIlllIIlIIllIl;
    public int thirdPersonView;
    public boolean showDebugInfo;
    public boolean showDebugProfilerChart;
    public String llIlllIIllIlllIlIlIlIIIll;
    public boolean noclip;
    public boolean lllIIlIlIllIIlIllIIIIIlII;
    public boolean IlIIIlIIllIIIIllllIlIlIlI;
    public float noclipRate;
    public float lIllIlIlIIlIllIllllIllIIl;
    public float IIIlllIllIIllIllIlIIIllII;
    private float lIIlIlllIIIIlIIIllIlIIIII;
    public float lllIlIIIllIIlIIlIlIllIIlI;
    public int IIlIIlIlIlIlllIIlIIlIIlII;
    public int lIllIlllIIllIllllIllIIlll;
    public String language;
    public boolean forceUnicodeFont;
    
    public float lIIIIlIIllIIlIIlIIIlIIllI() {
        return ((boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl() && (boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl()) ? 100 : this.lIIlIlllIIIIlIIIllIlIIIII;
    }
    
    public GameSettings(final Minecraft ilIIIIlIlIllIIlIIIIllllll, final File file) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 0.24074073f * 2.0769231f;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
        this.IIIIllIlIIIllIlllIlllllIl = true;
        this.IIIllIllIlIlllllllIlIlIII = true;
        this.limitFramerate = 120;
        this.fancyGraphics = true;
        this.IlllIllIlIIIIlIIlIIllIIIl = 2;
        this.IlIlllIIIIllIllllIllIIlIl = 1;
        this.llIIlllIIIIlllIllIlIlllIl = 2.24f * 0.35714287f;
        this.lIIlIlIllIIlIIIlIIIlllIII = 0;
        this.IIIlllIIIllIllIlIIIIIIlII = false;
        this.llIlIIIlIIIIlIlllIlIIIIll = 0;
        this.IIIlIIllllIIllllllIlIIIll = false;
        this.lllIIIIIlIllIlIIIllllllII = false;
        this.lIIIIIllllIIIIlIlIIIIlIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IIIIIIlIlIlIllllllIlllIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IllIllIIIlIIlllIIIllIllII = 1.0f;
        this.IlIIlIIIIlIIIIllllIIlIllI = 0;
        this.lIIlIIllIIIIIlIllIIIIllII = 0;
        this.lIIlllIIlIlllllllllIIIIIl = 0.0f;
        this.lIllIllIlIIllIllIlIlIIlIl = 0;
        this.llIlIIIllIIIIlllIlIIIIIlI = 0;
        this.lIllIlIlllIIlIIllIIlIIlII = 0;
        this.IIIlIIlIlIIIlllIIlIllllll = 0;
        this.IllIlIIIIlllIIllIIlllIIlI = 0;
        this.IllIlIlIllllIlIIllllIIlll = 3;
        this.IllIIlIIlllllIllIIIlllIII = 4000;
        this.lIlIlIllIIIIIIIIllllIIllI = false;
        this.IlllIIlllIIIIllIIllllIlIl = false;
        this.IllllIllllIlIIIlIIIllllll = false;
        this.IllIIlllIllIlIllIlIIIIIII = true;
        this.IlIlIIIlllllIIIlIlIlIllII = true;
        this.IIlIIllIIIllllIIlllIllIIl = true;
        this.lllIlIIllllIIIIlIllIlIIII = true;
        this.lIIIIlllIIlIlllllIlIllIII = 0;
        this.lIIIlllIlIlllIIIIIIIIIlII = 1;
        this.IIIIlIIIlllllllllIlllIlll = 0;
        this.IlIllllIIIlIllllIIIIIllII = false;
        this.IlIIIIllIIIIIlllIIlIIlllI = 0;
        this.llIlIlIllIlIIlIlllIllIIlI = false;
        this.llIlIlIlllIlllllIIIllIIll = true;
        this.IIllIlIllIlIllIIlIllIlIII = false;
        this.lIlIllIlIlIIIllllIlIllIll = "Default";
        this.IlIIlIIlIllIIIIllIIllIlIl = true;
        this.llllIIIIlIlIllIIIllllIIll = true;
        this.IIlIlIIlIIIlIlllllIIlIIlI = true;
        this.lIIIlllIIIlIIIIIlIIIIIIII = true;
        this.lIIlIIIIIIIIllIIllIIlllIl = true;
        this.IllllllIllllIIlllIllllllI = true;
        this.lIlIlIIIlIIllllllllIIlllI = true;
        this.IlIlllIllIlIllIlllIlllIll = 2;
        this.llIIIllIIllllIlIlIlIlIIll = false;
        this.IIIIIlIllIllIlIIllIIlIllI = false;
        this.lIIllIIllllllIIlllIlllIIl = false;
        this.lllIIllllIIlIlIlIlIIIlIII = 2;
        this.IlIIllIlIlIIIllIllIIlIIII = true;
        this.IlIlllIIIIlIllIlllIlIIIll = 3;
        this.IIIlIllIlllIlIllIllllllll = 0;
        this.IllllllllIlIIIIIIIIllIIII = 0;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = true;
        this.IllIIIlIIlIllIllIIllllIIl = true;
        this.IIlIlllIllIlIlIIIIIlllIll = true;
        this.IlIIllIIIlllIIIIlIIIIlIll = true;
        this.lIIIIIIlIIllllllIIIlIlIIl = true;
        this.llIIIlIlIIlIlIIlIllIllIll = true;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = true;
        this.IIIlllllIIlIlIIIllllllIII = true;
        this.lIlIlIIIIllIlllIlIIlllIlI = true;
        this.IIllllIllllIIIlIIllllIlll = true;
        this.llllIIIIIlIlIlIlIllIIIIII = true;
        this.IllIIIIllllllIlllllIlIlll = true;
        this.IIIllllIlIIlIIIlIlIlllIII = true;
        this.IIlIlllllIIIlIIllIllIlIlI = true;
        this.IlIllIllIllIllIllllIIIlII = true;
        this.lllIIlIIllIllIIllIIlIIIIl = true;
        this.resourcePacks = new ArrayList();
        this.chatVisibility = IlllIIIIllIlIIlIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI;
        this.llIIlllIlIIlIIIIIlIllllll = true;
        this.IIllllIIIIllIIlIllIIIIIlI = true;
        this.lIllIllIllllllIllIlllIlIl = true;
        this.IlIllIIllIIIIIllIlIIIIIIl = 1.0f;
        this.lIlllIIlllIllIlllIIllllIl = true;
        this.enableVsync = true;
        this.IlIlIIIIIllIlIlIIllIlIIIl = true;
        this.lIIIllIIIIlIIllIIIIIIIlll = true;
        this.llllIIllllllIlIIlIlIIIllI = true;
        this.IlllllIllIIIllIIIllIllIII = 1.0f;
        this.lIlllllIlIllllIIIllllllII = 1.0f;
        this.lIlIIIlIIIlllllllllllIlIl = 2.8387096f * 0.15629001f;
        this.IIllllllIlIIIIlllIlIlIlll = 1.0f;
        this.IlllIIllIlllllIIIlIllIIII = true;
        this.mipmapLevels = 4;
        this.anisotropicFiltering = 1;
        this.lllIlllllIllllllIIlIlllll = Maps.newEnumMap((Class)llllIlllIllIIIIlIIllIIIIl.class);
        this.llIIllIllIlIlIlIllllllIII = 1.2051282f * 0.41489363f;
        this.IlIIlIIllIllIIIIIlllIIlll = 1.0f;
        this.llIIIIlIlIIIllIllIIIIllII = 1.0f;
        this.llllIllIIIlIIIlIllIlIlIlI = 0.320352f * 1.6896552f;
        this.llIIllllIlIlIllIlIllIlIlI = 0.28253862f * 1.1216216f;
        this.IlllIIIIlllllIlIlllllIlll = 1;
        this.IIIlIllIIllllIIIllllIllll = true;
        this.llllIIIllllllIlllIIlIIlll = "";
        this.lIlllIIIlIlIIlIIIIIIlIlII = 0;
        this.IlIllIIIIIlIlllIIIIlllIIl = 0;
        this.llIIIlllllIlllIIllIlIIlII = 0;
        this.lIIIlIlIIIlIlIlllIlIlllII = new KeyBinding("key.forward", 17, "key.categories.movement");
        this.llIlIlIIIIIIIlllIIIllIlll = new KeyBinding("key.left", 30, "key.categories.movement");
        this.IllIIIIIIlIlIlllllllIIllI = new KeyBinding("key.back", 31, "key.categories.movement");
        this.IlIIlllIIlIlIIIlIlllllIll = new KeyBinding("key.right", 32, "key.categories.movement");
        this.lIllIllIIlIlIIIIllIllllll = new KeyBinding("key.jump", 57, "key.categories.movement");
        this.llllllIIIIIlllllIllIlIllI = new KeyBinding("key.sneak", 42, "key.categories.movement");
        this.keyBindInventory = new KeyBinding("key.inventory", 18, "key.categories.inventory");
        this.keyBindUseItem = new KeyBinding("key.use", -99, "key.categories.gameplay");
        this.keyBindDrop = new KeyBinding("key.drop", 16, "key.categories.gameplay");
        this.keyBindAttack = new KeyBinding("key.attack", -100, "key.categories.gameplay");
        this.keyBindPickBlock = new KeyBinding("key.pickItem", -98, "key.categories.gameplay");
        this.lIIlIlIllllllIllllIIllllI = new KeyBinding("key.sprint", 29, "key.categories.gameplay");
        this.keyBindChat = new KeyBinding("key.chat", 20, "key.categories.multiplayer");
        this.IIIIIlllIllIIIIllIllIIIII = new KeyBinding("key.playerlist", 15, "key.categories.multiplayer");
        this.keyBindCommand = new KeyBinding("key.command", 53, "key.categories.multiplayer");
        this.llllIlIIIIIllIIlIlllIllll = new KeyBinding("key.screenshot", 60, "key.categories.misc");
        this.IIIlIIIIllIIIlIIIIIlllllI = new KeyBinding("key.togglePerspective", 63, "key.categories.misc");
        this.IlllIIIllIlIlIIIllIIIlIlI = new KeyBinding("key.smoothCamera", 0, "key.categories.misc");
        this.IllIIIIIIlllIIIlIIIlIIIlI = new KeyBinding("key.fullscreen", 87, "key.categories.misc");
        this.keyBindsHotbar = new KeyBinding[] { new KeyBinding("key.hotbar.1", 2, "key.categories.inventory"), new KeyBinding("key.hotbar.2", 3, "key.categories.inventory"), new KeyBinding("key.hotbar.3", 4, "key.categories.inventory"), new KeyBinding("key.hotbar.4", 5, "key.categories.inventory"), new KeyBinding("key.hotbar.5", 6, "key.categories.inventory"), new KeyBinding("key.hotbar.6", 7, "key.categories.inventory"), new KeyBinding("key.hotbar.7", 8, "key.categories.inventory"), new KeyBinding("key.hotbar.8", 9, "key.categories.inventory"), new KeyBinding("key.hotbar.9", 10, "key.categories.inventory") };
        this.lllIIlIIIllIIlllIlIIIllIl = (KeyBinding[])ArrayUtils.addAll((Object[])new KeyBinding[] { this.keyBindAttack, this.keyBindUseItem, this.lIIIlIlIIIlIlIlllIlIlllII, this.llIlIlIIIIIIIlllIIIllIlll, this.IllIIIIIIlIlIlllllllIIllI, this.IlIIlllIIlIlIIIlIlllllIll, this.lIllIllIIlIlIIIIllIllllll, this.llllllIIIIIlllllIllIlIllI, this.keyBindDrop, this.keyBindInventory, this.keyBindChat, this.IIIIIlllIllIIIIllIllIIIII, this.keyBindPickBlock, this.keyBindCommand, this.llllIlIIIIIllIIlIlllIllll, this.IIIlIIIIllIIIlIIIIIlllllI, this.IlllIIIllIlIlIIIllIIIlIlI, this.lIIlIlIllllllIllllIIllllI, this.IllIIIIIIlllIIIlIIIlIIIlI }, (Object[])this.keyBindsHotbar);
        this.IlIIIIlllIIIlIIllllIIIlll = lIIlIlIIllIIllllIIIlIlIlI.IlllIIIlIlllIllIlIIlllIlI;
        this.llIlllIIllIlllIlIlIlIIIll = "";
        this.noclipRate = 1.0f;
        this.lIllIlIlIIlIllIllllIllIIl = 1.0f;
        this.IIIlllIllIIllIllIlIIIllII = 70;
        this.language = "en_US";
        this.forceUnicodeFont = false;
        this.IlIIIIlIlIllIIlIIIIllllll = ilIIIIlIlIllIIlIIIIllllll;
        this.IIIlIllIIIlllIIlIIllIlIII = new File(file, "options.txt");
        this.llllIlIlIlllllIllIIllIIIl = new File(file, "optionsof.txt");
        this.limitFramerate = (int)lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl();
        this.IllIlIlllIIlIIIIIlIIIIIll = new KeyBinding("Zoom", 29, "key.categories.misc");
        this.lllIIlIIIllIIlllIlIIIllIl = (KeyBinding[])ArrayUtils.add((Object[])this.lllIIlIIIllIIlllIlIIIllIl, (Object)this.IllIlIlllIIlIIIIIlIIIIIll);
        lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI((float)32);
        this.IlllIIIlIlllIllIlIIlllIlI = (ilIIIIlIlIllIIlIIIIllllll.llllIIIIlIlIllIIIllllIIll() ? 12 : 8);
        this.lIIIIIIIIIlIllIIllIlIIlIl();
        lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public GameSettings() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 1.4375f * 0.3478261f;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
        this.IIIIllIlIIIllIlllIlllllIl = true;
        this.IIIllIllIlIlllllllIlIlIII = true;
        this.limitFramerate = 120;
        this.fancyGraphics = true;
        this.IlllIllIlIIIIlIIlIIllIIIl = 2;
        this.IlIlllIIIIllIllllIllIIlIl = 1;
        this.llIIlllIIIIlllIllIlIlllIl = 1.5454545f * 0.5176471f;
        this.lIIlIlIllIIlIIIlIIIlllIII = 0;
        this.IIIlllIIIllIllIlIIIIIIlII = false;
        this.llIlIIIlIIIIlIlllIlIIIIll = 0;
        this.IIIlIIllllIIllllllIlIIIll = false;
        this.lllIIIIIlIllIlIIIllllllII = false;
        this.lIIIIIllllIIIIlIlIIIIlIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IIIIIIlIlIlIllllllIlllIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IllIllIIIlIIlllIIIllIllII = 1.0f;
        this.IlIIlIIIIlIIIIllllIIlIllI = 0;
        this.lIIlIIllIIIIIlIllIIIIllII = 0;
        this.lIIlllIIlIlllllllllIIIIIl = 0.0f;
        this.lIllIllIlIIllIllIlIlIIlIl = 0;
        this.llIlIIIllIIIIlllIlIIIIIlI = 0;
        this.lIllIlIlllIIlIIllIIlIIlII = 0;
        this.IIIlIIlIlIIIlllIIlIllllll = 0;
        this.IllIlIIIIlllIIllIIlllIIlI = 0;
        this.IllIlIlIllllIlIIllllIIlll = 3;
        this.IllIIlIIlllllIllIIIlllIII = 4000;
        this.lIlIlIllIIIIIIIIllllIIllI = false;
        this.IlllIIlllIIIIllIIllllIlIl = false;
        this.IllllIllllIlIIIlIIIllllll = false;
        this.IllIIlllIllIlIllIlIIIIIII = true;
        this.IlIlIIIlllllIIIlIlIlIllII = true;
        this.IIlIIllIIIllllIIlllIllIIl = true;
        this.lllIlIIllllIIIIlIllIlIIII = true;
        this.lIIIIlllIIlIlllllIlIllIII = 0;
        this.lIIIlllIlIlllIIIIIIIIIlII = 1;
        this.IIIIlIIIlllllllllIlllIlll = 0;
        this.IlIllllIIIlIllllIIIIIllII = false;
        this.IlIIIIllIIIIIlllIIlIIlllI = 0;
        this.llIlIlIllIlIIlIlllIllIIlI = false;
        this.llIlIlIlllIlllllIIIllIIll = true;
        this.IIllIlIllIlIllIIlIllIlIII = false;
        this.lIlIllIlIlIIIllllIlIllIll = "Default";
        this.IlIIlIIlIllIIIIllIIllIlIl = true;
        this.llllIIIIlIlIllIIIllllIIll = true;
        this.IIlIlIIlIIIlIlllllIIlIIlI = true;
        this.lIIIlllIIIlIIIIIlIIIIIIII = true;
        this.lIIlIIIIIIIIllIIllIIlllIl = true;
        this.IllllllIllllIIlllIllllllI = true;
        this.lIlIlIIIlIIllllllllIIlllI = true;
        this.IlIlllIllIlIllIlllIlllIll = 2;
        this.llIIIllIIllllIlIlIlIlIIll = false;
        this.IIIIIlIllIllIlIIllIIlIllI = false;
        this.lIIllIIllllllIIlllIlllIIl = false;
        this.lllIIllllIIlIlIlIlIIIlIII = 2;
        this.IlIIllIlIlIIIllIllIIlIIII = true;
        this.IlIlllIIIIlIllIlllIlIIIll = 3;
        this.IIIlIllIlllIlIllIllllllll = 0;
        this.IllllllllIlIIIIIIIIllIIII = 0;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = true;
        this.IllIIIlIIlIllIllIIllllIIl = true;
        this.IIlIlllIllIlIlIIIIIlllIll = true;
        this.IlIIllIIIlllIIIIlIIIIlIll = true;
        this.lIIIIIIlIIllllllIIIlIlIIl = true;
        this.llIIIlIlIIlIlIIlIllIllIll = true;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = true;
        this.IIIlllllIIlIlIIIllllllIII = true;
        this.lIlIlIIIIllIlllIlIIlllIlI = true;
        this.IIllllIllllIIIlIIllllIlll = true;
        this.llllIIIIIlIlIlIlIllIIIIII = true;
        this.IllIIIIllllllIlllllIlIlll = true;
        this.IIIllllIlIIlIIIlIlIlllIII = true;
        this.IIlIlllllIIIlIIllIllIlIlI = true;
        this.IlIllIllIllIllIllllIIIlII = true;
        this.lllIIlIIllIllIIllIIlIIIIl = true;
        this.resourcePacks = new ArrayList();
        this.chatVisibility = IlllIIIIllIlIIlIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI;
        this.llIIlllIlIIlIIIIIlIllllll = true;
        this.IIllllIIIIllIIlIllIIIIIlI = true;
        this.lIllIllIllllllIllIlllIlIl = true;
        this.IlIllIIllIIIIIllIlIIIIIIl = 1.0f;
        this.lIlllIIlllIllIlllIIllllIl = true;
        this.enableVsync = true;
        this.IlIlIIIIIllIlIlIIllIlIIIl = true;
        this.lIIIllIIIIlIIllIIIIIIIlll = true;
        this.llllIIllllllIlIIlIlIIIllI = true;
        this.IlllllIllIIIllIIIllIllIII = 1.0f;
        this.lIlllllIlIllllIIIllllllII = 1.0f;
        this.lIlIIIlIIIlllllllllllIlIl = 0.60211265f * 0.7368421f;
        this.IIllllllIlIIIIlllIlIlIlll = 1.0f;
        this.IlllIIllIlllllIIIlIllIIII = true;
        this.mipmapLevels = 4;
        this.anisotropicFiltering = 1;
        this.lllIlllllIllllllIIlIlllll = Maps.newEnumMap((Class)llllIlllIllIIIIlIIllIIIIl.class);
        this.llIIllIllIlIlIlIllllllIII = 1.6f * 0.3125f;
        this.IlIIlIIllIllIIIIIlllIIlll = 1.0f;
        this.llIIIIlIlIIIllIllIIIIllII = 1.0f;
        this.llllIllIIIlIIIlIllIlIlIlI = 16.779816f * 0.032258064f;
        this.llIIllllIlIlIllIlIllIlIlI = 0.9222222f * 0.34362805f;
        this.IlllIIIIlllllIlIlllllIlll = 1;
        this.IIIlIllIIllllIIIllllIllll = true;
        this.llllIIIllllllIlllIIlIIlll = "";
        this.lIlllIIIlIlIIlIIIIIIlIlII = 0;
        this.IlIllIIIIIlIlllIIIIlllIIl = 0;
        this.llIIIlllllIlllIIllIlIIlII = 0;
        this.lIIIlIlIIIlIlIlllIlIlllII = new KeyBinding("key.forward", 17, "key.categories.movement");
        this.llIlIlIIIIIIIlllIIIllIlll = new KeyBinding("key.left", 30, "key.categories.movement");
        this.IllIIIIIIlIlIlllllllIIllI = new KeyBinding("key.back", 31, "key.categories.movement");
        this.IlIIlllIIlIlIIIlIlllllIll = new KeyBinding("key.right", 32, "key.categories.movement");
        this.lIllIllIIlIlIIIIllIllllll = new KeyBinding("key.jump", 57, "key.categories.movement");
        this.llllllIIIIIlllllIllIlIllI = new KeyBinding("key.sneak", 42, "key.categories.movement");
        this.keyBindInventory = new KeyBinding("key.inventory", 18, "key.categories.inventory");
        this.keyBindUseItem = new KeyBinding("key.use", -99, "key.categories.gameplay");
        this.keyBindDrop = new KeyBinding("key.drop", 16, "key.categories.gameplay");
        this.keyBindAttack = new KeyBinding("key.attack", -100, "key.categories.gameplay");
        this.keyBindPickBlock = new KeyBinding("key.pickItem", -98, "key.categories.gameplay");
        this.lIIlIlIllllllIllllIIllllI = new KeyBinding("key.sprint", 29, "key.categories.gameplay");
        this.keyBindChat = new KeyBinding("key.chat", 20, "key.categories.multiplayer");
        this.IIIIIlllIllIIIIllIllIIIII = new KeyBinding("key.playerlist", 15, "key.categories.multiplayer");
        this.keyBindCommand = new KeyBinding("key.command", 53, "key.categories.multiplayer");
        this.llllIlIIIIIllIIlIlllIllll = new KeyBinding("key.screenshot", 60, "key.categories.misc");
        this.IIIlIIIIllIIIlIIIIIlllllI = new KeyBinding("key.togglePerspective", 63, "key.categories.misc");
        this.IlllIIIllIlIlIIIllIIIlIlI = new KeyBinding("key.smoothCamera", 0, "key.categories.misc");
        this.IllIIIIIIlllIIIlIIIlIIIlI = new KeyBinding("key.fullscreen", 87, "key.categories.misc");
        this.keyBindsHotbar = new KeyBinding[] { new KeyBinding("key.hotbar.1", 2, "key.categories.inventory"), new KeyBinding("key.hotbar.2", 3, "key.categories.inventory"), new KeyBinding("key.hotbar.3", 4, "key.categories.inventory"), new KeyBinding("key.hotbar.4", 5, "key.categories.inventory"), new KeyBinding("key.hotbar.5", 6, "key.categories.inventory"), new KeyBinding("key.hotbar.6", 7, "key.categories.inventory"), new KeyBinding("key.hotbar.7", 8, "key.categories.inventory"), new KeyBinding("key.hotbar.8", 9, "key.categories.inventory"), new KeyBinding("key.hotbar.9", 10, "key.categories.inventory") };
        this.lllIIlIIIllIIlllIlIIIllIl = (KeyBinding[])ArrayUtils.addAll((Object[])new KeyBinding[] { this.keyBindAttack, this.keyBindUseItem, this.lIIIlIlIIIlIlIlllIlIlllII, this.llIlIlIIIIIIIlllIIIllIlll, this.IllIIIIIIlIlIlllllllIIllI, this.IlIIlllIIlIlIIIlIlllllIll, this.lIllIllIIlIlIIIIllIllllll, this.llllllIIIIIlllllIllIlIllI, this.keyBindDrop, this.keyBindInventory, this.keyBindChat, this.IIIIIlllIllIIIIllIllIIIII, this.keyBindPickBlock, this.keyBindCommand, this.llllIlIIIIIllIIlIlllIllll, this.IIIlIIIIllIIIlIIIIIlllllI, this.IlllIIIllIlIlIIIllIIIlIlI, this.lIIlIlIllllllIllllIIllllI, this.IllIIIIIIlllIIIlIIIlIIIlI }, (Object[])this.keyBindsHotbar);
        this.IlIIIIlllIIIlIIllllIIIlll = lIIlIlIIllIIllllIIIlIlIlI.IlllIIIlIlllIllIlIIlllIlI;
        this.llIlllIIllIlllIlIlIlIIIll = "";
        this.noclipRate = 1.0f;
        this.lIllIlIlIIlIllIllllIllIIl = 1.0f;
        this.IIIlllIllIIllIllIlIIIllII = 70;
        this.language = "en_US";
        this.forceUnicodeFont = false;
        this.limitFramerate = (int)lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl();
        this.IllIlIlllIIlIIIIIlIIIIIll = new KeyBinding("Zoom", 29, "key.categories.misc");
        this.lllIIlIIIllIIlllIlIIIllIl = (KeyBinding[])ArrayUtils.add((Object[])this.lllIIlIIIllIIlllIlIIIllIl, (Object)this.IllIlIlllIIlIIIIIlIIIIIll);
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return (n < 0) ? IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("key.mouseButton", n + 101) : (Objects.equals(Keyboard.getKeyName(n), "LMENU") ? "ALT" : Keyboard.getKeyName(n));
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final KeyBinding keyBinding) {
        return keyBinding.lIIIIllIIlIlIllIIIlIllIlI() != 0 && ((keyBinding.lIIIIllIIlIlIllIIIlIllIlI() < 0) ? Mouse.isButtonDown(keyBinding.lIIIIllIIlIlIllIIIlIllIlI() + 100) : Keyboard.isKeyDown(keyBinding.lIIIIllIIlIlIllIIIlIllIlI()));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final KeyBinding keyBinding, final int n) {
        keyBinding.lIIIIIIIIIlIllIIllIlIIlIl(n);
        this.saveOptions();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll, final float n) {
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllllIllllIIlllIllllllI) {
            this.lIIlllIIlIlllllllllIIIIIl = n;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlIllIlllIlIllIllllllll) {
            this.IllIllIIIlIIlllIIIllIllII = n;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI) {
            this.IIIlllIllIIllIllIlIIIllII = n;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIlIIIllIlllIlllllIl) {
            this.lIIlIlllIIIIlIIIllIlIIIII = n;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl) {
            this.limitFramerate = (int)n;
            this.enableVsync = false;
            if (this.limitFramerate <= 0) {
                this.limitFramerate = (int)lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl();
                this.enableVsync = true;
            }
            this.lIIIIllIIlIlIllIIIlIllIlI();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIIIlIIIIllllIIlIllI) {
            this.IlIllIIllIIIIIllIlIIIIIIl = n;
            this.IlIIIIlIlIllIIlIIIIllllll.ingameGUI.getChatGUI().lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIlIIlllllIllIIIlllIII) {
            this.IIllllllIlIIIIlllIlIlIlll = n;
            this.IlIIIIlIlIllIIlIIIIllllll.ingameGUI.getChatGUI().lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIllIIIIIIIIllllIIllI) {
            this.lIlIIIlIIIlllllllllllIlIl = n;
            this.IlIIIIlIlIllIIlIIIIllllll.ingameGUI.getChatGUI().lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIlIllllIlIIllllIIlll) {
            this.lIlllllIlIllllIIIllllllII = n;
            this.IlIIIIlIlIllIIlIIIIllllll.ingameGUI.getChatGUI().lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIIIIlllIIllIIlllIIlI) {
            this.IlllllIllIIIllIIIllIllIII = n;
            this.IlIIIIlIlIllIIlIIIIllllll.ingameGUI.getChatGUI().lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllIllllIlIIIlIIIllllll) {
            final int anisotropicFiltering = this.anisotropicFiltering;
            this.anisotropicFiltering = (int)n;
            if (anisotropicFiltering != n) {
                this.IlIIIIlIlIllIIlIIIIllllll.IlIIlIIlIllIIIIllIIllIlIl().lIIIIIIIIIlIllIIllIlIIlIl(this.anisotropicFiltering);
                this.IlIIIIlIlIllIIlIIIIllllll.IllIlIlIllllIlIIllllIIlll();
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIlllIIIIllIIllllIlIl) {
            final int mipmapLevels = this.mipmapLevels;
            this.mipmapLevels = (int)n;
            if (mipmapLevels != n) {
                this.IlIIIIlIlIllIIlIIIIllllll.IlIIlIIlIllIIIIllIIllIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this.mipmapLevels);
                this.IlIIIIlIlIllIIlIIIIllllll.IllIlIlIllllIlIIllllIIlll();
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl) {
            this.IlllIIIlIlllIllIlIIlllIlI = (int)n;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll, final int n) {
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllIlIllIlIllIIlIllIlIII) {
            switch (this.IlIlllIIIIllIllllIllIIlIl) {
                case 1: {
                    this.IlIlllIIIIllIllllIllIIlIl = 2;
                    if (!lIIIllIIIllIlllllIIlIllII.IIIIllIIllIIIIllIllIIIlIl()) {
                        this.IlIlllIIIIllIllllIllIIlIl = 3;
                        break;
                    }
                    break;
                }
                case 2: {
                    this.IlIlllIIIIllIllllIllIIlIl = 3;
                    break;
                }
                case 3: {
                    this.IlIlllIIIIllIllllIllIIlIl = 1;
                    break;
                }
                default: {
                    this.IlIlllIIIIllIllllIllIIlIl = 1;
                    break;
                }
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIllIlIlIIIllllIlIllIll) {
            this.llIIlllIIIIlllIllIlIlllIl += 1.150685f * 0.17380953f;
            if (this.llIIlllIIIIlllIllIlIlllIl > 3.3333333f * 0.243f) {
                this.llIIlllIIIIlllIllIlIlllIl = 0.038596492f * 5.181818f;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIlIllIIIIllIIllIlIl) {
            ++this.lIIlIlIllIIlIIIlIIIlllIII;
            if (this.lIIlIlIllIIlIIIlIIIlllIII > 3) {
                this.lIIlIlIllIIlIIIlIIIlllIII = 0;
            }
            lllIIlIlIlIlllIIIIIIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIIIlIlIllIIIllllIIll) {
            this.IIIlllIIIllIllIlIIIIIIlII = !this.IIIlllIIIllIllIlIIIIIIlII;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlIIlIIIlIlllllIIlIIlI) {
            this.llIlIIIlIIIIlIlllIlIIIIll += 2;
            if (this.llIlIIIlIIIIlIlllIlIIIIll > 8) {
                this.llIlIIIlIIIIlIlllIlIIIIll = 0;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlllIIIlIIIIIlIIIIIIII) {
            this.lllIIIIIlIllIlIIIllllllII = !this.lllIIIIIlIllIlIIIllllllII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIIIIllIllllIIlIIlllIII) {
            this.lIIIIIllllIIIIlIlIIIIlIlI = !this.lIIIIIllllIIIIlIlIIIIlIlI;
            lIIIllIIIllIlllllIIlIllII.lIIIlIlIIllIIlllIIIlIIllI();
            if (!lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII()) {
                this.lIIIIIllllIIIIlIlIIIIlIlI = false;
            }
            lIIIllIIIllIlllllIIlIllII.IllIIIIIIIlIlIllllIIllIII();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIIIIIIIIllIIllIIlllIl) {
            ++this.lIIlIIllIIIIIlIllIIIIllII;
            if (this.lIIlIIllIIIIIlIllIIIIllII > 3) {
                this.lIIlIIllIIIIIlIllIIIIllII = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIIIlIIllllllllIIlllI) {
            ++this.lIllIllIlIIllIllIlIlIIlIl;
            if (this.lIllIllIlIIllIllIlIlIIlIl > 2) {
                this.lIllIllIlIIllIllIlIlIIlIl = 0;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlllIllIlIllIlllIlllIll) {
            ++this.llIlIIIllIIIIlllIlIIIIIlI;
            if (this.llIlIIIllIIIIlllIlIIIIIlI > 2) {
                this.llIlIIIllIIIIlllIlIIIIIlI = 0;
            }
            RenderBlocks.fancyGrass = lIIIllIIIllIlllllIIlIllII.IlllIIlllIIIIllIIllllIlIl();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIllIIIIlIIllIIIIIIIlll) {
            ++this.IllIlIIIIlllIIllIIlllIIlI;
            if (this.IllIlIIIIlllIIllIIlllIIlI > 2) {
                this.IllIlIIIIlllIIllIIlllIIlI = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIIllIIllllIlIlIlIlIIll) {
            ++this.lIllIlIlllIIlIIllIIlIIlII;
            if (this.lIllIlIlllIIlIIllIIlIIlII > 3) {
                this.lIllIlIlllIIlIIllIIlIIlII = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIIlIllIllIlIIllIIlIllI) {
            ++this.IIIlIIlIlIIIlllIIlIllllll;
            if (this.IIIlIIlIlIIIlllIIlIllllll > 2) {
                this.IIIlIIlIlIIIlllIIlIllllll = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIllIIllllllIIlllIlllIIl) {
            ++this.IIIlIllIlllIlIllIllllllll;
            if (this.IIIlIllIlllIlIllIllllllll > 2) {
                this.IIIlIllIlllIlIllIllllllll = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIllllIIlIlIlIlIIIlIII) {
            ++this.IllllllllIlIIIIIIIIllIIII;
            if (this.IllllllllIlIIIIIIIIllIIII > 2) {
                this.IllllllllIlIIIIIIIIllIIII = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIllIlIlIIIllIllIIlIIII) {
            this.lIIlIlIIlIlIlIIlIlIlllIIl = !this.lIIlIlIIlIlIlIIlIlIlllIIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlllIIIIlIllIlllIlIIIll) {
            this.IllIIIlIIlIllIllIIllllIIl = !this.IllIIIlIIlIllIllIIllllIIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIllIIIlllIIIIlIIIIlIll) {
            this.IIlIlllIllIlIlIIIIIlllIll = !this.IIlIlllIllIlIlIIIIIlllIll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIlIIllllllIIIlIlIIl) {
            this.IlIIllIIIlllIIIIlIIIIlIll = !this.IlIIllIIIlllIIIIlIIIIlIll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIIlIlIIlIlIIlIllIllIll) {
            this.lIIIIIIlIIllllllIIIlIlIIl = !this.lIIIIIIlIIllllllIIIlIlIIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlllIlIIIlIIIlIlIlIlIl) {
            this.llIIIlIlIIlIlIIlIllIllIll = !this.llIIIlIlIIlIlIIlIllIllIll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIlIlIllIllllIIIIllll) {
            this.IlIIlllIlIIIlIIIlIlIlIlIl = !this.IlIIlllIlIIIlIIIlIlIlIlIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlIlllIllIIlIllIIlIIlI) {
            this.IIIlllllIIlIlIIIllllllIII = !this.IIIlllllIIlIlIIIllllllIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIIIIIIlIIlIIlIIlIIlI) {
            this.IIllllIllllIIIlIIllllIlll = !this.IIllllIllllIIIlIIllllIlll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIlIIlIlllIIIIIIllllI) {
            this.llllIIIIIlIlIlIlIllIIIIII = !this.llllIIIIIlIlIlIlIllIIIIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIIIIlIlllIlllllllIIl) {
            this.IllIIIIllllllIlllllIlIlll = !this.IllIIIIllllllIlllllIlIlll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIlIlIlllllIllIIllIIIl) {
            this.IIIllllIlIIlIIIlIlIlllIII = !this.IIIllllIlIIlIIIlIlIlllIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIlIIllIIlllIIIlIIllI) {
            this.IlIllIllIllIllIllllIIIlII = !this.IlIllIllIllIllIllllIIIlII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIlIIllIllIIllIIlIIIIl) {
            this.IIlIlllllIIIlIIllIllIlIlI = !this.IIlIlllllIIIlIIllIllIlIlI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIIllIIIlllIIllIIlIIllI) {
            this.lIlIlIIIIllIlllIlIIlllIlI = !this.lIlIlIIIIllIlllIlIIlllIlI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllllllIlIIIIIIIIllIIII) {
            this.lIlIlIllIIIIIIIIllllIIllI = !this.lIlIlIllIIIIIIIIllllIIllI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIlIIlIlIlIIlIlIlllIIl) {
            this.IllllIllllIlIIIlIIIllllll = !this.IllllIllllIlIIIlIIIllllll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIlIIlIllIllIIllllIIl) {
            this.IllIIlIIlllllIllIIIlllIII *= 10;
            if (this.IllIIlIIlllllIllIIIlllIII > 40000) {
                this.IllIIlIIlllllIllIIIlllIII = 40;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlllIllIlIlIIIIIlllIll) {
            ++this.IllIlIlIllllIlIIllllIIlll;
            if (this.IllIlIlIllllIlIIllllIIlll > 3) {
                this.IllIlIlIllllIlIIllllIIlll = 1;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlllIIlllIllIlllIIllllIl) {
            ++this.IlIlllIllIlIllIlllIlllIll;
            if (this.IlIlllIllIlIllIlllIlllIll > 3) {
                this.IlIlllIllIlIllIlllIlllIll = 1;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllllIIlIlIIIllllllIII) {
            this.IllIIlllIllIlIllIlIIIIIII = !this.IllIIlllIllIlIllIlIIIIIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIIIIllIlllIlIIlllIlI) {
            this.IlIlIIIlllllIIIlIlIlIllII = !this.IlIlIIIlllllIIIlIlIlIllII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllllIllllIIIlIIllllIlll) {
            this.IIlIIllIIIllllIIlllIllIIl = !this.IIlIIllIIIllllIIlllIllIIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIIIIlIlIlIlIllIIIIII) {
            this.lllIlIIllllIIIIlIllIlIIII = !this.lllIlIIllllIIIIlIllIlIIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIIllllllIlllllIlIlll) {
            ++this.lIIIIlllIIlIlllllIlIllIII;
            if (this.lIIIIlllIIlIlllllIlIllIII > 2) {
                this.lIIIIlllIIlIlllllIlIllIII = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIllllIlIIlIIIlIlIlllIII) {
            ++this.lIIIlllIlIlllIIIIIIIIIlII;
            if (this.lIIIlllIlIlllIIIIIIIIIlII > 5) {
                this.lIIIlllIlIlllIIIIIIIIIlII = 1;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllIllIlIIllIIllIlIlll) {}
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlllllIIIlIIllIllIlIlI) {
            this.IlIllllIIIlIllllIIIIIllII = !this.IlIllllIIIlIllllIIIIIllII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIllIllIllIllIllllIIIlII) {
            ++this.IlIIIIllIIIIIlllIIlIIlllI;
            if (this.IlIIIIllIIIIIlllIIlIIlllI > 3) {
                this.IlIIIIllIIIIIlllIIlIIlllI = 0;
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIllIllIlIllIlIIllllIIl) {
            this.llIlIlIllIlIIlIlllIllIIlI = !this.llIlIlIllIlIIlIlllIllIIlI;
            this.IlIlllIIIIllIllllIllIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIlIllIIIIIIlIIIIIlllll) {
            this.llIlIlIlllIlllllIIIllIIll = !this.llIlIlIlllIlllllIIIllIIll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIllIlIIlIllIIIllllIl) {
            final int[] array = { 0, 2, 4, 6, 8, 12, 16 };
            final int ilIIlIIIIlIIIIllllIIlIllI = this.IlIIlIIIIlIIIIllllIIlIllI;
            if (ilIIlIIIIlIIIIllllIIlIllI >= 16) {
                this.IlIIlIIIIlIIIIllllIIlIllI = 0;
            }
            else {
                this.IlIIlIIIIlIIIIllllIIlIllI = array[Ints.indexOf(array, ilIIlIIIIlIIIIllllIIlIllI) + 1];
            }
            this.IlIIlIIIIlIIIIllllIIlIllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIlIIIIlIIIIllllIIlIllI, 0, 16);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIllIIlllllIlIlIIllll) {
            this.IlllIIlllIIIIllIIllllIlIl = !this.IlllIIlllIIIIllIIllllIlIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlllllIIlIlIIlIIlllIIIII) {
            this.IIllIlIllIlIllIIlIllIlIII = !this.IIllIlIllIlIllIIlIllIlIII;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllIllIlIIlllllIlIIIlIll) {
            this.IlIIlIIlIllIIIIllIIllIlIl = !this.IlIIlIIlIllIIIIllIIllIlIl;
            lIIIllIllIIIIIlIIIIIIIIII.lIIIIIIIIIlIllIIllIlIIlIl();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIlIllIlIIIlllIl) {
            this.llllIIIIlIlIllIIIllllIIll = !this.llllIIIIlIlIllIIIllllIIll;
            lIIllIllllIllIIIIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIlllIlIIlIIIIIlIllllll) {
            this.IIlIlIIlIIIlIlllllIIlIIlI = !this.IIlIlIIlIIIlIlllllIIlIIlI;
            lIIIllIllIIIIIlIIIIIIIIII.lIIIIIIIIIlIllIIllIlIIlIl();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllllIIIIllIIlIllIIIIIlI) {
            this.lIIIlllIIIlIIIIIlIIIIIIII = !this.lIIIlllIIIlIIIIIlIIIIIIII;
            this.IlIIIIlIlIllIIlIIIIllllll.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(lIIIllIIIllIlllllIIlIllII.lIlIlIIIlIIllllllllIIlllI());
            this.IlIIIIlIlIllIIlIIIIllllll.standardGalacticFontRenderer.lIIIIlIIllIIlIIlIIIlIIllI(lIIIllIIIllIlllllIIlIllII.lIlIlIIIlIIllllllllIIlllI());
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIllIllIllllllIllIlllIlIl) {
            this.lIIlIIIIIIIIllIIllIIlllIl = !this.lIIlIIIIIIIIllIIllIIlllIl;
            lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIIIllIIlllIlllIlIIlll) {
            this.IllllllIllllIIlllIllllllI = !this.IllllllIllllIIlllIllllllI;
            lIlllllIlIlIIIIIIlllIllIl.lIIIIIIIIIlIllIIllIlIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIllIIllIIIIIllIlIIIIIIl) {
            this.lIlIlIIIlIIllllllllIIlllI = !this.lIlIlIIIlIIllllllllIIlllI;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.IlIlllIIIIllIllllIllIIlIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIIlIIIIIllIIlIlIlIII) {
            this.llIIIllIIllllIlIlIlIlIIll = !this.llIIIllIIllllIlIlIlIlIIll;
            IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIllIlIllIlIllIIIIIIlll) {
            this.IIIIIlIllIllIlIIllIIlIllI = !this.IIIIIlIllIllIlIIllIIlIllI;
            MathHelper.IIIIllIIllIIIIllIllIIIlIl = this.IIIIIlIllIllIlIIllIIlIllI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIllllllIlIIlIlIIIllI) {
            this.lIIllIIllllllIIlllIlllIIl = !this.lIIllIIllllllIIlllIlllIIl;
            if (this.lIIllIIllllllIIlllIlllIIl) {
                this.IlIIIIlIlIllIIlIIIIllllll.entityRenderer.tick();
            }
            lIIIllIIIllIlllllIIlIllII.lllIllIlIllIlIllIIIIIIlll();
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllllIllIIIllIIIllIllIII) {
            if (this.lllIIllllIIlIlIlIlIIIlIII == 1) {
                this.lllIIllllIIlIlIlIlIIIlIII = 2;
            }
            else {
                this.lllIIllllIIlIlIlIlIIIlIII = 1;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIlIIllIlIlIllIIIIll) {
            this.IIIIIIlIlIlIllllllIlllIlI = !this.IIIIIIlIlIlIllllllIlllIlI;
            lIIIllIIIllIlllllIIlIllII.lIIIlIlIIllIIlllIIIlIIllI();
            if (!lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII()) {
                this.IIIIIIlIlIlIllllllIlllIlI = false;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIlllIIlIIIIIlIIIIIll) {
            final List<String> list = Arrays.asList(lIIIllIIIllIlllllIIlIllII.IIIIIIIllIllllIIlIIlllIII());
            if (this.lIlIllIlIlIIIllllIlIllIll.equals("Default")) {
                final String lIlIllIlIlIIIllllIlIllIll = list.get(0);
                if (lIlIllIlIlIIIllllIlIllIll != null) {
                    this.lIlIllIlIlIIIllllIlIllIll = lIlIllIlIlIIIllllIlIllIll;
                }
            }
            else {
                int index = list.indexOf(this.lIlIllIlIlIIIllllIlIllIll);
                if (index < 0) {
                    this.lIlIllIlIlIIIllllIlIllIll = "Default";
                }
                else if (++index >= list.size()) {
                    this.lIlIllIlIlIIIllllIlIllIll = "Default";
                }
                else {
                    this.lIlIllIlIlIIIllllIlIllIll = list.get(index);
                }
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlllllIlIllllIIIllllllII) {
            this.IlIIllIlIlIIIllIllIIlIIII = !this.IlIIllIlIlIIIllIllIIlIIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIIIlIIIlllllllllllIlIl) {
            switch (this.IlIlllIIIIlIllIlllIlIIIll) {
                case 1: {
                    this.IlIlllIIIIlIllIlllIlIIIll = 2;
                    break;
                }
                case 3: {
                    this.IlIlllIIIIlIllIlllIlIIIll = 1;
                    break;
                }
                default: {
                    this.IlIlllIIIIlIllIlllIlIIIll = 3;
                    break;
                }
            }
            IIllIIlIIlllIIIllIIlIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIIIllIlIlIIllIlIIIl) {
            this.llllIIllllllIlIIlIlIIIllI = !this.llllIIllllllIlIIlIlIIIllI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = !this.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIIIlIIIIlIlllIlIIIIll) {
            this.IIlIIlIlIlIlllIIlIIlIIlII = (this.IIlIIlIlIlIlllIIlIIlIIlII + n & 0x3);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIIIIlIllIlIIIllllllII) {
            this.lIllIlllIIllIllllIllIIlll = (this.lIllIlllIIllIllllIllIIlll + n) % 3;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIllIllIlIlllllllIlIlIII) {
            this.IIIIllIlIIIllIlllIlllllIl = !this.IIIIllIlIIIllIlllIlllllIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlIIllllIIllllllIlIIIll) {
            this.lllIIlIIllIllIIllIIlIIIIl = !this.lllIIlIIllIllIIllIIlIIIIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIlllIllIlIllIlIIIIIII) {
            this.forceUnicodeFont = !this.forceUnicodeFont;
            this.IlIIIIlIlIllIIlIIIIllllll.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIIIlIlIllIIlIIIIllllll.lIlIllIlIlIIIllllIlIllIll().isCurrentLocaleUnicode() || this.forceUnicodeFont);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIllIIlIlIllIIIlIllIlI) {
            if (!lIIIllIIIllIlllllIIlIllII.IlIlIIIlllIIIlIlllIlIllIl()) {
                this.IIIlIIllllIIllllllIlIIIll = false;
                this.IlIlIIIlllIIIlIlllIlIllIl = false;
            }
            else if (!this.IlIlIIIlllIIIlIlllIlIllIl) {
                this.IlIlIIIlllIIIlIlllIlIllIl = true;
                this.IIIlIIllllIIllllllIlIIIll = false;
            }
            else if (!this.IIIlIIllllIIllllllIlIIIll) {
                this.IIIlIIllllIIllllllIlIIIll = true;
            }
            else {
                this.IIIlIIllllIIllllllIlIIIll = false;
                this.IlIlIIIlllIIIlIlllIlIllIl = false;
            }
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.IllIIIIIIIlIlIllllIIllIII();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlllIIIIllIllllIllIIlIl) {
            this.IIIllIllIlIlllllllIlIlIII = !this.IIIllIllIlIlllllllIlIlIII;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIIIIIlIlIllllIIllIII) {
            this.IIIIllIIllIIIIllIllIIIlIl = !this.IIIIllIIllIIIIllIllIIIlIl;
            this.IlIIIIlIlIllIIlIIIIllllll.refreshResources();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIlllIIIIlllIllIlIlllIl) {
            this.IlIIIIlllIIIlIIllllIIIlll = lIIlIlIIllIIllllIIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIIIlllIIIlIIllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI() + n & 0x3);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIlIllIIlIIIlIIIlllIII) {
            this.fancyGraphics = !this.fancyGraphics;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllIIIllIllIlIIIIIIlII) {
            this.IlllIllIlIIIIlIIlIIllIIIl = (this.IlllIllIlIIIIlIIlIIllIIIl + n) % 3;
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIllllIIIIlIlIIIIlIlI) {
            this.chatVisibility = IlllIIIIllIlIIlIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI((this.chatVisibility.lIIIIlIIllIIlIIlIIIlIIllI() + n) % 3);
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIlIIIlllllllllIlllIlll) {
            this.IlllIIIIlllllIlIlllllIlll = (this.IlllIIIIlllllIlIlllllIlll + n) % 3;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIllllIIIlIllllIIIIIllII) {
            this.IIIlIllIIllllIIIllllIllll = !this.IIIlIllIIllllIIIllllIllll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIIIllIIIIIlllIIlIIlllI) {
            this.lIlllIIIlIlIIlIIIIIIlIlII = (this.lIlllIIIlIlIIlIIIIIIlIlII + n) % 3;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIlIllIlIIlIlllIllIIlI) {
            this.IlIllIIIIIlIlllIIIIlllIIl = (this.IlIllIIIIIlIlllIIIIlllIIl + n) % 3;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIlIlllIlllllIIIllIIll) {
            this.llIIIlllllIlllIIllIlIIlII = (this.llIIIlllllIlllIIllIlIIlII + n) % 2;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIIIlIlIlIllllllIlllIlI) {
            this.llIIlllIlIIlIIIIIlIllllll = !this.llIIlllIlIIlIIIIIlIllllll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIllIIIlIIlllIIIllIllII) {
            this.IIllllIIIIllIIlIllIIIIIlI = !this.IIllllIIIIllIIlIllIIIIIlI;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIIllIIIIIlIllIIIIllII) {
            this.lIllIllIllllllIllIlllIlIl = !this.lIllIllIllllllIllIlllIlIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlllIIlIlllllllllIIIIIl) {
            this.lIlllIIlllIllIlllIIllllIl = !this.lIlllIIlllIllIlllIIllllIl;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIllIlIlllIIlIIllIIlIIlII) {
            this.lIIIllIIIIlIIllIIIIIIIlll = !this.lIIIllIIIIlIIllIIIIIIIlll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlIIlIlIIIlllIIlIllllll) {
            this.lIIIIIIlIIllIlIlIllIIIIll = !this.lIIIIIIlIIllIlIlIllIIIIll;
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIllIllIlIIllIllIlIlIIlIl) {
            this.fullScreen = !this.fullScreen;
            if (this.IlIIIIlIlIllIIlIIIIllllll.lIIIlllIlIlllIIIIIIIIIlII() != this.fullScreen) {
                this.IlIIIIlIlIllIIlIIIIllllll.toggleFullscreen();
            }
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIIIllIIIIlllIlIIIIIlI) {
            Display.setVSyncEnabled(this.enableVsync = !this.enableVsync);
        }
        this.saveOptions();
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll) {
        return (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllllIllllIIlllIllllllI) ? this.lIIlllIIlIlllllllllIIIIIl : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlIllIlllIlIllIllllllll) ? this.IllIllIIIlIIlllIIIllIllII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl) ? ((this.limitFramerate == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl() && this.enableVsync) ? 0.0f : ((float)this.limitFramerate)) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI) ? this.IIIlllIllIIllIllIlIIIllII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIlIIIllIlllIlllllIl) ? this.lIIlIlllIIIIlIIIllIlIIIII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIIllIIIIllIllIIIlIl) ? this.lllIlIIIllIIlIIlIlIllIIlI : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl) ? this.lIIIIlIIllIIlIIlIIIlIIllI : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIIIlIIIIllllIIlIllI) ? this.IlIllIIllIIIIIllIlIIIIIIl : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIlIIlllllIllIIIlllIII) ? this.IIllllllIlIIIIlllIlIlIlll : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIllIIIIIIIIllllIIllI) ? this.lIlIIIlIIIlllllllllllIlIl : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIIIIlllIIllIIlllIIlI) ? this.IlllllIllIIIllIIIllIllIII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIlIllllIlIIllllIIlll) ? this.lIlllllIlIllllIIIllllllII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl) ? ((float)this.limitFramerate) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllIllllIlIIIlIIIllllll) ? ((float)this.anisotropicFiltering) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIlllIIIIllIIllllIlIl) ? ((float)this.mipmapLevels) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl) ? ((float)this.IlllIIIlIlllIllIlIIlllIlI) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllllIIIlIlIlIllII) ? this.llIIllIllIlIlIlIllllllIII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIIllIIIllllIIlllIllIIl) ? this.IlIIlIIllIllIIIIIlllIIlll : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIlIIllllIIIIlIllIlIIII) ? this.llIIIIlIlIIIllIllIIIIllII : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlllIIlIlllllIlIllIII) ? this.llllIllIIIlIIIlIllIlIlIlI : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlllIlIlllIIIIIIIIIlII) ? this.llIIllllIlIlIllIlIllIlIlI : 0.0f))))))))))))))))))));
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll) {
        switch (IlIIIlIIIlIIIIIllllllllII.lIIIIlIIllIIlIIlIIIlIIllI[lllIlIIIIlIIlIlIIlIlIlIll.ordinal()]) {
            case 1: {
                return this.lIIIIIIIIIlIllIIllIlIIlIl;
            }
            case 2: {
                return this.IIIIllIlIIIllIlllIlllllIl;
            }
            case 3: {
                return this.IIIIllIIllIIIIllIllIIIlIl;
            }
            case 4: {
                return this.IlIlIIIlllIIIlIlllIlIllIl;
            }
            case 5: {
                return this.IIIllIllIlIlllllllIlIlIII;
            }
            case 6: {
                return this.lllIIlIIllIllIIllIIlIIIIl;
            }
            case 7: {
                return this.llIIlllIlIIlIIIIIlIllllll;
            }
            case 8: {
                return this.IIllllIIIIllIIlIllIIIIIlI;
            }
            case 9: {
                return this.lIllIllIllllllIllIlllIlIl;
            }
            case 10: {
                return this.lIlllIIlllIllIlllIIllllIl;
            }
            case 11: {
                return this.fullScreen;
            }
            case 12: {
                return this.enableVsync;
            }
            case 13: {
                return this.lIIIllIIIIlIIllIIIIIIIlll;
            }
            case 14: {
                return this.lIIIIIIlIIllIlIlIllIIIIll;
            }
            case 15: {
                return this.IIIlIllIIllllIIIllllIllll;
            }
            case 16: {
                return this.forceUnicodeFont;
            }
            default: {
                return false;
            }
        }
    }
    
    private static String lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, int n) {
        if (n < 0 || n >= array.length) {
            n = 0;
        }
        return IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(array[n], new Object[0]);
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI(final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll) {
        String s = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIlIIIllIlllIlllllIl(), new Object[0]) + ": ";
        if (s == null) {
            s = lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIlIIIllIlllIlllllIl();
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl) {
            final int i = (int)this.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIlIIlIlIIlIlIlIll);
            String str = "Tiny";
            int n = 2;
            if (i >= 4) {
                str = "Short";
                n = 4;
            }
            if (i >= 8) {
                str = "Normal";
                n = 8;
            }
            if (i >= 16) {
                str = "Far";
                n = 16;
            }
            if (i >= 32) {
                str = "Extreme";
                n = 32;
            }
            final int n2 = this.IlllIIIlIlllIllIlIIlllIlI - n;
            String string = str;
            if (n2 > 0) {
                string = str + "+";
            }
            return s + i + " " + string + "";
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIllIIlIlIllIIIlIllIlI) {
            return this.IlIlIIIlllIIIlIlllIlIllIl ? (this.IIIlIIllllIIllllllIlIIIll ? (s + "Fancy") : (s + "Fast")) : (s + "OFF");
        }
        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllIlIllIlIllIIlIllIlIII) {
            switch (this.IlIlllIIIIllIllllIllIIlIl) {
                case 1: {
                    return s + "Fast";
                }
                case 2: {
                    return s + "Fancy";
                }
                case 3: {
                    return s + "OFF";
                }
                default: {
                    return s + "OFF";
                }
            }
        }
        else {
            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIllIlIlIIIllllIlIllIll) {
                return s + this.llIIlllIIIIlllIllIlIlllIl;
            }
            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIlIllIIIIllIIllIlIl) {
                switch (this.lIIlIlIllIIlIIIlIIIlllIII) {
                    case 0: {
                        return s + "Nearest";
                    }
                    case 1: {
                        return s + "Linear";
                    }
                    case 2: {
                        return s + "Bilinear";
                    }
                    case 3: {
                        return s + "Trilinear";
                    }
                    default: {
                        return s + "Nearest";
                    }
                }
            }
            else {
                if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIIIlIlIllIIIllllIIll) {
                    return this.IIIlllIIIllIllIlIIIIIIlII ? (s + "ON") : (s + "OFF");
                }
                if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlIIlIIIlIlllllIIlIIlI) {
                    return (this.llIlIIIlIIIIlIlllIlIIIIll == 0) ? (s + "OFF") : (s + this.llIlIIIlIIIIlIlllIlIIIIll);
                }
                if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlllIIIlIIIIIlIIIIIIII) {
                    return this.lllIIIIIlIllIlIIIllllllII ? (s + "ON") : (s + "OFF");
                }
                if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIIIIllIllllIIlIIlllIII) {
                    return this.lIIIIIllllIIIIlIlIIIIlIlI ? (s + "ON") : (s + "OFF");
                }
                if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIIIIIIIIllIIllIIlllIl) {
                    switch (this.lIIlIIllIIIIIlIllIIIIllII) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        case 3: {
                            return s + "OFF";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIIIlIIllllllllIIlllI) {
                    switch (this.lIllIllIlIIllIllIlIlIIlIl) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlllIllIlIllIlllIlllIll) {
                    switch (this.llIlIIIllIIIIlllIlIIIIIlI) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIllIIIIlIIllIIIIIIIlll) {
                    switch (this.IllIlIIIIlllIIllIIlllIIlI) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIIllIIllllIlIlIlIlIIll) {
                    switch (this.lIllIlIlllIIlIIllIIlIIlII) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        case 3: {
                            return s + "OFF";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIIlIllIllIlIIllIIlIllI) {
                    switch (this.IIIlIIlIlIIIlllIIlIllllll) {
                        case 1: {
                            return s + "Fast";
                        }
                        case 2: {
                            return s + "Fancy";
                        }
                        case 3: {
                            return s + "OFF";
                        }
                        default: {
                            return s + "Default";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIllIIllllllIIlllIlllIIl) {
                    switch (this.IIIlIllIlllIlIllIllllllll) {
                        case 1: {
                            return s + "Dynamic";
                        }
                        case 2: {
                            return s + "OFF";
                        }
                        default: {
                            return s + "ON";
                        }
                    }
                }
                else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIllllIIlIlIlIlIIIlIII) {
                    switch (this.IllllllllIlIIIIIIIIllIIII) {
                        case 1: {
                            return s + "Dynamic";
                        }
                        case 2: {
                            return s + "OFF";
                        }
                        default: {
                            return s + "ON";
                        }
                    }
                }
                else {
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIllIlIlIIIllIllIIlIIII) {
                        return this.lIIlIlIIlIlIlIIlIlIlllIIl ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlllIIIIlIllIlllIlIIIll) {
                        return this.IllIIIlIIlIllIllIIllllIIl ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIllIIIlllIIIIlIIIIlIll) {
                        return this.IIlIlllIllIlIlIIIIIlllIll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIlIIllllllIIIlIlIIl) {
                        return this.IlIIllIIIlllIIIIlIIIIlIll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIIlIlIIlIlIIlIllIllIll) {
                        return this.lIIIIIIlIIllllllIIIlIlIIl ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlllIlIIIlIIIlIlIlIlIl) {
                        return this.llIIIlIlIIlIlIIlIllIllIll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIlIlIllIllllIIIIllll) {
                        return this.IlIIlllIlIIIlIIIlIlIlIlIl ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlIlllIllIIlIllIIlIIlI) {
                        return this.IIIlllllIIlIlIIIllllllIII ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIIIIIIlIIlIIlIIlIIlI) {
                        return this.IIllllIllllIIIlIIllllIlll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIlIIlIlllIIIIIIllllI) {
                        return this.llllIIIIIlIlIlIlIllIIIIII ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIIIIlIlllIlllllllIIl) {
                        return this.IllIIIIllllllIlllllIlIlll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIlIlIlllllIllIIllIIIl) {
                        return this.IIIllllIlIIlIIIlIlIlllIII ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIlIIllIIlllIIIlIIllI) {
                        return this.IlIllIllIllIllIllllIIIlII ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIlIIllIllIIllIIlIIIIl) {
                        return this.IIlIlllllIIIlIIllIllIlIlI ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIIllIIIlllIIllIIlIIllI) {
                        return this.lIlIlIIIIllIlllIlIIlllIlI ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllllllIlIIIIIIIIllIIII) {
                        return this.lIlIlIllIIIIIIIIllllIIllI ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIlIIlIlIlIIlIlIlllIIl) {
                        return this.IllllIllllIlIIIlIIIllllll ? (s + "ON") : (s + "OFF");
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIlIIlIllIllIIllllIIl) {
                        return (this.IllIIlIIlllllIllIIIlllIII <= 40) ? (s + "Default (2s)") : ((this.IllIIlIIlllllIllIIIlllIII <= 400) ? (s + "20s") : ((this.IllIIlIIlllllIllIIIlllIII <= 4000) ? (s + "3min") : (s + "30min")));
                    }
                    if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlllIllIlIlIIIIIlllIll) {
                        switch (this.IllIlIlIllllIlIIllllIIlll) {
                            case 1: {
                                return s + "Fast";
                            }
                            case 2: {
                                return s + "Fancy";
                            }
                            default: {
                                return s + "OFF";
                            }
                        }
                    }
                    else if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlllIIlllIllIlllIIllllIl) {
                        switch (this.IlIlllIllIlIllIlllIlllIll) {
                            case 1: {
                                return s + "Fast";
                            }
                            case 2: {
                                return s + "Fancy";
                            }
                            default: {
                                return s + "OFF";
                            }
                        }
                    }
                    else {
                        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllllIIlIlIIIllllllIII) {
                            return this.IllIIlllIllIlIllIlIIIIIII ? (s + "ON") : (s + "OFF");
                        }
                        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIIIIllIlllIlIIlllIlI) {
                            return this.IlIlIIIlllllIIIlIlIlIllII ? (s + "ON") : (s + "OFF");
                        }
                        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllllIllllIIIlIIllllIlll) {
                            return this.IIlIIllIIIllllIIlllIllIIl ? (s + "ON") : (s + "OFF");
                        }
                        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIIIIlIlIlIlIllIIIIII) {
                            return this.lllIlIIllllIIIIlIllIlIIII ? (s + "ON") : (s + "OFF");
                        }
                        if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIIllllllIlllllIlIlll) {
                            switch (this.lIIIIlllIIlIlllllIlIllIII) {
                                case 1: {
                                    return s + "Fast";
                                }
                                case 2: {
                                    return s + "Fancy";
                                }
                                default: {
                                    return s + "Default";
                                }
                            }
                        }
                        else {
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIllllIlIIlIIIlIlIlllIII) {
                                return s + this.lIIIlllIlIlllIIIIIIIIIlII;
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllIllIlIIllIIllIlIlll) {
                                return (this.IIIIlIIIlllllllllIlllIlll == 1) ? (s + "Smooth") : ((this.IIIIlIIIlllllllllIlllIlll == 2) ? (s + "Multi-Core") : (s + "Default"));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlIlllllIIIlIIllIllIlIlI) {
                                return this.IlIllllIIIlIllllIIIIIllII ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIllIllIllIllIllllIIIlII) {
                                return (this.IlIIIIllIIIIIlllIIlIIlllI == 1) ? (s + "Day Only") : ((this.IlIIIIllIIIIIlllIIlIIlllI == 3) ? (s + "Night Only") : (s + "Default"));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIllIllIlIllIlIIllllIIl) {
                                return this.llIlIlIllIlIIlIlllIllIIlI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIlIllIIIIIIlIIIIIlllll) {
                                return this.llIlIlIlllIlllllIIIllIIll ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIIllIlIIlIllIIIllllIl) {
                                return (this.IlIIlIIIIlIIIIllllIIlIllI == 0) ? (s + "OFF") : (s + this.IlIIlIIIIlIIIIllllIIlIllI);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIllIIlllllIlIlIIllll) {
                                return this.IlllIIlllIIIIllIIllllIlIl ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIlllllIIlIlIIlIIlllIIIII) {
                                return this.IIllIlIllIlIllIIlIllIlIII ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllIllIlIIlllllIlIIIlIll) {
                                return this.IlIIlIIlIllIIIIllIIllIlIl ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIlIllIlIIIlllIl) {
                                return this.llllIIIIlIlIllIIIllllIIll ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIlllIlIIlIIIIIlIllllll) {
                                return this.IIlIlIIlIIIlIlllllIIlIIlI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIllllIIIIllIIlIllIIIIIlI) {
                                return this.lIIIlllIIIlIIIIIlIIIIIIII ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIllIllIllllllIllIlllIlIl) {
                                return this.lIIlIIIIIIIIllIIllIIlllIl ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIlIIIllIIlllIlllIlIIlll) {
                                return this.IllllllIllllIIlllIllllllI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIllIIllIIIIIllIlIIIIIIl) {
                                return this.lIlIlIIIlIIllllllllIIlllI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlIIlIIIIIllIIlIlIlIII) {
                                return this.llIIIllIIllllIlIlIlIlIIll ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIllIlIllIlIllIIIIIIlll) {
                                return this.IIIIIlIllIllIlIIllIIlIllI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llllIIllllllIlIIlIlIIIllI) {
                                return this.lIIllIIllllllIIlllIlllIIl ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllllIllIIIllIIIllIllIII) {
                                return (this.lllIIllllIIlIlIlIlIIIlIII == 1) ? (s + "Fast") : (s + "Fancy");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIlIIllIlIlIllIIIIll) {
                                return this.IIIIIIlIlIlIllllllIlllIlI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlllllIlIllllIIIllllllII) {
                                return this.IlIIllIlIlIIIllIllIIlIIII ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIIIlIIIlllllllllllIlIl) {
                                return (this.IlIlllIIIIlIllIlllIlIIIll == 1) ? (s + "Fast") : ((this.IlIlllIIIIlIllIlllIlIIIll == 2) ? (s + "Fancy") : (s + "OFF"));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIlllIIlIIIIIlIIIIIll) {
                                return s + this.lIlIllIlIlIIIllllIlIllIll;
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIIIllIlIlIIllIlIIIl) {
                                return this.llllIIllllllIlIIlIlIIIllI ? (s + "ON") : (s + "OFF");
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl) {
                                final float liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIlIIlIlIIlIlIlIll);
                                return (liiiIlIIllIIlIIlIIIlIIllI == 0.0f) ? (s + "VSync") : ((liiiIlIIllIIlIIlIIIlIIllI == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIllIllIIIIIlllIIlll) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.framerateLimit.max", new Object[0])) : (s + (int)liiiIlIIllIIlIIlIIIlIIllI + " fps"));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI()) {
                                final float liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIlIIlIlIIlIlIlIll);
                                final float liiiiiiiiIlIllIIllIlIIlIl = lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2);
                                return (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl) ? ((liiiiiiiiIlIllIIllIlIIlIl == 0.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.sensitivity.min", new Object[0])) : ((liiiiiiiiIlIllIIllIlIIlIl == 1.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.sensitivity.max", new Object[0])) : (s + (int)(liiiiiiiiIlIllIIllIlIIlIl * 200) + "%"))) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI) ? ((liiiIlIIllIIlIIlIIIlIIllI2 == 70) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.fov.min", new Object[0])) : ((liiiIlIIllIIlIIlIIIlIIllI2 == 110) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.fov.max", new Object[0])) : (s + (int)liiiIlIIllIIlIIlIIIlIIllI2))) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl) ? ((liiiIlIIllIIlIIlIIIlIIllI2 == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIllIllIIIIIlllIIlll) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.framerateLimit.max", new Object[0])) : (s + (int)liiiIlIIllIIlIIlIIIlIIllI2 + " fps")) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIlIIIllIlllIlllllIl) ? ((liiiiiiiiIlIllIIllIlIIlIl == 0.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.gamma.min", new Object[0])) : ((liiiiiiiiIlIllIIllIlIIlIl == 1.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.gamma.max", new Object[0])) : (s + "+" + (int)(liiiiiiiiIlIllIIllIlIIlIl * 100) + "%"))) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIllIIllIIIIllIllIIIlIl) ? (s + (int)(liiiiiiiiIlIllIIllIlIIlIl * 400) + "%") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIlIIIIlIIIIllllIIlIllI) ? (s + (int)(liiiiiiiiIlIllIIllIlIIlIl * 90 + 10) + "%") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIlIlIllIIIIIIIIllllIIllI) ? (s + lIlIlIllIIIlIIlIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl) + "px") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIIlIIlllllIllIIIlllIII) ? (s + lIlIlIllIIIlIIlIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl) + "px") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllIlIlIllllIlIIllllIIlll) ? (s + lIlIlIllIIIlIIlIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl) + "px") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl) ? (s + (int)liiiIlIIllIIlIIlIIIlIIllI2 + " chunks") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IllllIllllIlIIIlIIIllllll) ? ((liiiIlIIllIIlIIlIIIlIIllI2 == 1.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.off", new Object[0])) : (s + (int)liiiIlIIllIIlIIlIIIlIIllI2)) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlllIIlllIIIIllIIllllIlIl) ? ((liiiIlIIllIIlIIlIIIlIIllI2 == 0.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.off", new Object[0])) : (s + (int)liiiIlIIllIIlIIlIIIlIIllI2)) : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIlllIlIlllIIIIIIIIIlII) ? (s + " fps") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlllIIlIlllllIlIllIII) ? (s + " Kbps") : ((lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllllIIIlIlIlIllII) ? s : ((liiiiiiiiIlIllIIllIlIIlIl == 0.0f) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.off", new Object[0])) : (s + (int)(liiiiiiiiIlIllIIllIlIIlIl * 100) + "%"))))))))))))))));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl()) {
                                return this.lIIIIIIIIIlIllIIllIlIIlIl(lllIlIIIIlIIlIlIIlIlIlIll) ? (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.on", new Object[0])) : (s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.off", new Object[0]));
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIIlllIIIIlllIllIlIlllIl) {
                                return s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIIIlllIIIlIIllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(), new Object[0]);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIIIlIIIIlIlllIlIIIIll) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.IlIlIIIlIlIllIIIIIllllIIl, this.IIlIIlIlIlIlllIIlIIlIIlII);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIllllIIIIlIlIIIIlIlI) {
                                return s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.chatVisibility.lIIIIIIIIIlIllIIllIlIIlIl(), new Object[0]);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.lllIIIIIlIllIlIIIllllllII) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.IlIIlIIlIIlllIlIIIlIllIIl, this.lIllIlllIIllIllllIllIIlll);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIlllIIIllIllIlIIIIIIlII) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.llIIIIIIllIIIllllIIllIIII, this.IlllIllIlIIIIlIIlIIllIIIl);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IIIIlIIIlllllllllIlllIlll) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.lIllIlIlIlllIIIIllIlIIIII, this.IlllIIIIlllllIlIlllllIlll);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.IlIIIIllIIIIIlllIIlIIlllI) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.lllIllIllllIllIllIlllllIl, this.lIlllIIIlIlIIlIIIIIIlIlII);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIlIllIlIIlIlllIllIIlI) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.IIlllIIlIlIIIlIlIlIIlllII, this.IlIllIIIIIlIlllIIIIlllIIl);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll == lllIlIIIIlIIlIlIIlIlIlIll.llIlIlIlllIlllllIIIllIIll) {
                                return s + lIIIIlIIllIIlIIlIIIlIIllI(GameSettings.lIlIIllIIlllIlIlllIIIIllI, this.llIIIlllllIlllIIllIlIIlII);
                            }
                            if (lllIlIIIIlIIlIlIIlIlIlIll != lllIlIIIIlIIlIlIIlIlIlIll.lIIlIlIllIIlIIIlIIIlllIII) {
                                return s;
                            }
                            if (this.fancyGraphics) {
                                return s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.graphics.fancy", new Object[0]);
                            }
                            return s + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.graphics.fast", new Object[0]);
                        }
                    }
                }
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        try {
            if (!this.IIIlIllIIIlllIIlIIllIlIII.exists()) {
                return;
            }
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(this.IIIlIllIIIlllIIlIIllIlIII));
            this.lllIlllllIllllllIIlIlllll.clear();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                try {
                    final String[] split = line.split(":");
                    if (split[0].equals("mouseSensitivity")) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("invertYMouse")) {
                        this.lIIIIIIIIIlIllIIllIlIIlIl = split[1].equals("true");
                    }
                    if (split[0].equals("fov")) {
                        this.IIIlllIllIIllIllIlIIIllII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("gamma")) {
                        this.lIIlIlllIIIIlIIIllIlIIIII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("saturation")) {
                        this.lllIlIIIllIIlIIlIlIllIIlI = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("fov")) {
                        this.IIIlllIllIIllIllIlIIIllII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]) * 40 + 70;
                    }
                    if (split[0].equals("renderDistance")) {
                        this.IlllIIIlIlllIllIlIIlllIlI = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("guiScale")) {
                        this.IIlIIlIlIlIlllIIlIIlIIlII = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("particles")) {
                        this.lIllIlllIIllIllllIllIIlll = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("bobView")) {
                        this.IIIIllIlIIIllIlllIlllllIl = split[1].equals("true");
                    }
                    if (split[0].equals("anaglyph3d")) {
                        this.IIIIllIIllIIIIllIllIIIlIl = split[1].equals("true");
                    }
                    if (split[0].equals("advancedOpengl")) {
                        this.IlIlIIIlllIIIlIlllIlIllIl = split[1].equals("true");
                    }
                    if (split[0].equals("maxFps")) {
                        this.limitFramerate = Integer.parseInt(split[1]);
                        this.enableVsync = false;
                        if (this.limitFramerate <= 0) {
                            this.limitFramerate = (int)lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl();
                            this.enableVsync = true;
                        }
                        this.lIIIIllIIlIlIllIIIlIllIlI();
                    }
                    if (split[0].equals("fboEnable")) {
                        this.IIIllIllIlIlllllllIlIlIII = split[1].equals("true");
                    }
                    if (split[0].equals("difficulty")) {
                        this.IlIIIIlllIIIlIIllllIIIlll = lIIlIlIIllIIllllIIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(Integer.parseInt(split[1]));
                    }
                    if (split[0].equals("fancyGraphics")) {
                        this.fancyGraphics = split[1].equals("true");
                    }
                    if (split[0].equals("ao")) {
                        if (split[1].equals("true")) {
                            this.IlllIllIlIIIIlIIlIIllIIIl = 2;
                        }
                        else if (split[1].equals("false")) {
                            this.IlllIllIlIIIIlIIlIIllIIIl = 0;
                        }
                        else {
                            this.IlllIllIlIIIIlIIlIIllIIIl = Integer.parseInt(split[1]);
                        }
                    }
                    if (split[0].equals("clouds")) {
                        this.lllIIlIIllIllIIllIIlIIIIl = split[1].equals("true");
                    }
                    if (split[0].equals("resourcePacks")) {
                        this.resourcePacks = (List)GameSettings.IllIIllIIIlIlllIlIlIIlIII.fromJson(line.substring(line.indexOf(58) + 1), (Type)GameSettings.IIlIlIIIIllIIIllIlIIIllll);
                        if (this.resourcePacks == null) {
                            this.resourcePacks = new ArrayList();
                        }
                    }
                    if (split[0].equals("lastServer") && split.length >= 2) {
                        this.llIlllIIllIlllIlIlIlIIIll = line.substring(line.indexOf(58) + 1);
                    }
                    if (split[0].equals("lang") && split.length >= 2) {
                        this.language = split[1];
                    }
                    if (split[0].equals("chatVisibility")) {
                        this.chatVisibility = IlllIIIIllIlIIlIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI(Integer.parseInt(split[1]));
                    }
                    if (split[0].equals("chatColors")) {
                        this.llIIlllIlIIlIIIIIlIllllll = split[1].equals("true");
                    }
                    if (split[0].equals("chatLinks")) {
                        this.IIllllIIIIllIIlIllIIIIIlI = split[1].equals("true");
                    }
                    if (split[0].equals("chatLinksPrompt")) {
                        this.lIllIllIllllllIllIlllIlIl = split[1].equals("true");
                    }
                    if (split[0].equals("chatOpacity")) {
                        this.IlIllIIllIIIIIllIlIIIIIIl = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("snooperEnabled")) {
                        this.lIlllIIlllIllIlllIIllllIl = split[1].equals("true");
                    }
                    if (split[0].equals("fullscreen")) {
                        this.fullScreen = split[1].equals("true");
                    }
                    if (split[0].equals("enableVsync")) {
                        this.enableVsync = split[1].equals("true");
                        this.lIIIIllIIlIlIllIIIlIllIlI();
                    }
                    if (split[0].equals("hideServerAddress")) {
                        this.lIIIlIIlIIIIIllIIlIlIlIII = split[1].equals("true");
                    }
                    if (split[0].equals("advancedItemTooltips")) {
                        this.IIIlllIllIlIIllIIllIlIlll = split[1].equals("true");
                    }
                    if (split[0].equals("pauseOnLostFocus")) {
                        this.IlIlIIIIIllIlIlIIllIlIIIl = split[1].equals("true");
                    }
                    if (split[0].equals("showCape")) {
                        this.lIIIllIIIIlIIllIIIIIIIlll = split[1].equals("true");
                    }
                    if (split[0].equals("touchscreen")) {
                        this.lIIIIIIlIIllIlIlIllIIIIll = split[1].equals("true");
                    }
                    if (split[0].equals("overrideHeight")) {
                        this.overrideHeight = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("overrideWidth")) {
                        this.overrideWidth = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("heldItemTooltips")) {
                        this.llllIIllllllIlIIlIlIIIllI = split[1].equals("true");
                    }
                    if (split[0].equals("chatHeightFocused")) {
                        this.IIllllllIlIIIIlllIlIlIlll = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("chatHeightUnfocused")) {
                        this.lIlIIIlIIIlllllllllllIlIl = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("chatScale")) {
                        this.IlllllIllIIIllIIIllIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("chatWidth")) {
                        this.lIlllllIlIllllIIIllllllII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("showInventoryAchievementHint")) {
                        this.IlllIIllIlllllIIIlIllIIII = split[1].equals("true");
                    }
                    if (split[0].equals("mipmapLevels")) {
                        this.mipmapLevels = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("anisotropicFiltering")) {
                        this.anisotropicFiltering = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("streamBytesPerPixel")) {
                        this.llIIllIllIlIlIlIllllllIII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("streamMicVolume")) {
                        this.IlIIlIIllIllIIIIIlllIIlll = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("streamSystemVolume")) {
                        this.llIIIIlIlIIIllIllIIIIllII = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("streamKbps")) {
                        this.llllIllIIIlIIIlIllIlIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("streamFps")) {
                        this.llIIllllIlIlIllIlIllIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]);
                    }
                    if (split[0].equals("streamCompression")) {
                        this.IlllIIIIlllllIlIlllllIlll = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("streamSendMetadata")) {
                        this.IIIlIllIIllllIIIllllIllll = split[1].equals("true");
                    }
                    if (split[0].equals("streamPreferredServer") && split.length >= 2) {
                        this.llllIIIllllllIlllIIlIIlll = line.substring(line.indexOf(58) + 1);
                    }
                    if (split[0].equals("streamChatEnabled")) {
                        this.lIlllIIIlIlIIlIIIIIIlIlII = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("streamChatUserFilter")) {
                        this.IlIllIIIIIlIlllIIIIlllIIl = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("streamMicToggleBehavior")) {
                        this.llIIIlllllIlllIIllIlIIlII = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("forceUnicodeFont")) {
                        this.forceUnicodeFont = split[1].equals("true");
                    }
                    for (final KeyBinding keyBinding : this.lllIIlIIIllIIlllIlIIIllIl) {
                        if (!keyBinding.lIIIIlIIllIIlIIlIIIlIIllI && split[0].equals("key_" + keyBinding.IIIllIllIlIlllllllIlIlIII())) {
                            final int int1 = Integer.parseInt(split[1]);
                            if (keyBinding != this.keyBindAttack || int1 == -100 || int1 == -99) {
                                keyBinding.lIIIIIIIIIlIllIIllIlIIlIl(int1);
                            }
                        }
                    }
                    for (final llllIlllIllIIIIlIIllIIIIl llllIlllIllIIIIlIIllIIIIl : llllIlllIllIIIIlIIllIIIIl.values()) {
                        if (split[0].equals("soundCategory_" + llllIlllIllIIIIlIIllIIIIl.getIdentifier())) {
                            this.lllIlllllIllllllIIlIlllll.put(llllIlllIllIIIIlIIllIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI(split[1]));
                        }
                    }
                }
                catch (Exception ex) {
                    GameSettings.llllIlIlllIIlIlIIIIlllIII.warn("Skipping bad option: " + line);
                    ex.printStackTrace();
                }
            }
            KeyBinding.lIIIIIIIIIlIllIIllIlIIlIl();
            bufferedReader.close();
        }
        catch (Exception ex2) {
            GameSettings.llllIlIlllIIlIlIIIIlllIII.error("Failed to load options", (Throwable)ex2);
        }
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return s.equals("true") ? 1.0f : (s.equals("false") ? 0.0f : Float.parseFloat(s));
    }
    
    public void saveOptions() {
        try {
            final PrintWriter printWriter = new PrintWriter(new FileWriter(this.IIIlIllIIIlllIIlIIllIlIII));
            printWriter.println("invertYMouse:" + this.lIIIIIIIIIlIllIIllIlIIlIl);
            printWriter.println("mouseSensitivity:" + this.lIIIIlIIllIIlIIlIIIlIIllI);
            printWriter.println("fov:" + (this.IIIlllIllIIllIllIlIIIllII - 70) / 40);
            printWriter.println("gamma:" + this.lIIlIlllIIIIlIIIllIlIIIII);
            printWriter.println("saturation:" + this.lllIlIIIllIIlIIlIlIllIIlI);
            printWriter.println("renderDistance:" + lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, 2, 16));
            printWriter.println("guiScale:" + this.IIlIIlIlIlIlllIIlIIlIIlII);
            printWriter.println("particles:" + this.lIllIlllIIllIllllIllIIlll);
            printWriter.println("bobView:" + this.IIIIllIlIIIllIlllIlllllIl);
            printWriter.println("anaglyph3d:" + this.IIIIllIIllIIIIllIllIIIlIl);
            printWriter.println("advancedOpengl:" + this.IlIlIIIlllIIIlIlllIlIllIl);
            printWriter.println("maxFps:" + this.limitFramerate);
            printWriter.println("fboEnable:" + this.IIIllIllIlIlllllllIlIlIII);
            printWriter.println("difficulty:" + this.IlIIIIlllIIIlIIllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI());
            printWriter.println("fancyGraphics:" + this.fancyGraphics);
            printWriter.println("ao:" + this.IlllIllIlIIIIlIIlIIllIIIl);
            printWriter.println("clouds:" + this.lllIIlIIllIllIIllIIlIIIIl);
            printWriter.println("resourcePacks:" + GameSettings.IllIIllIIIlIlllIlIlIIlIII.toJson((Object)this.resourcePacks));
            printWriter.println("lastServer:" + this.llIlllIIllIlllIlIlIlIIIll);
            printWriter.println("lang:" + this.language);
            printWriter.println("chatVisibility:" + this.chatVisibility.lIIIIlIIllIIlIIlIIIlIIllI());
            printWriter.println("chatColors:" + this.llIIlllIlIIlIIIIIlIllllll);
            printWriter.println("chatLinks:" + this.IIllllIIIIllIIlIllIIIIIlI);
            printWriter.println("chatLinksPrompt:" + this.lIllIllIllllllIllIlllIlIl);
            printWriter.println("chatOpacity:" + this.IlIllIIllIIIIIllIlIIIIIIl);
            printWriter.println("snooperEnabled:" + this.lIlllIIlllIllIlllIIllllIl);
            printWriter.println("fullscreen:" + this.fullScreen);
            printWriter.println("enableVsync:" + this.enableVsync);
            printWriter.println("hideServerAddress:" + this.lIIIlIIlIIIIIllIIlIlIlIII);
            printWriter.println("advancedItemTooltips:" + this.IIIlllIllIlIIllIIllIlIlll);
            printWriter.println("pauseOnLostFocus:" + this.IlIlIIIIIllIlIlIIllIlIIIl);
            printWriter.println("showCape:" + this.lIIIllIIIIlIIllIIIIIIIlll);
            printWriter.println("touchscreen:" + this.lIIIIIIlIIllIlIlIllIIIIll);
            printWriter.println("overrideWidth:" + this.overrideWidth);
            printWriter.println("overrideHeight:" + this.overrideHeight);
            printWriter.println("heldItemTooltips:" + this.llllIIllllllIlIIlIlIIIllI);
            printWriter.println("chatHeightFocused:" + this.IIllllllIlIIIIlllIlIlIlll);
            printWriter.println("chatHeightUnfocused:" + this.lIlIIIlIIIlllllllllllIlIl);
            printWriter.println("chatScale:" + this.IlllllIllIIIllIIIllIllIII);
            printWriter.println("chatWidth:" + this.lIlllllIlIllllIIIllllllII);
            printWriter.println("showInventoryAchievementHint:" + this.IlllIIllIlllllIIIlIllIIII);
            printWriter.println("mipmapLevels:" + this.mipmapLevels);
            printWriter.println("anisotropicFiltering:" + this.anisotropicFiltering);
            printWriter.println("streamBytesPerPixel:" + this.llIIllIllIlIlIlIllllllIII);
            printWriter.println("streamMicVolume:" + this.IlIIlIIllIllIIIIIlllIIlll);
            printWriter.println("streamSystemVolume:" + this.llIIIIlIlIIIllIllIIIIllII);
            printWriter.println("streamKbps:" + this.llllIllIIIlIIIlIllIlIlIlI);
            printWriter.println("streamFps:" + this.llIIllllIlIlIllIlIllIlIlI);
            printWriter.println("streamCompression:" + this.IlllIIIIlllllIlIlllllIlll);
            printWriter.println("streamSendMetadata:" + this.IIIlIllIIllllIIIllllIllll);
            printWriter.println("streamPreferredServer:" + this.llllIIIllllllIlllIIlIIlll);
            printWriter.println("streamChatEnabled:" + this.lIlllIIIlIlIIlIIIIIIlIlII);
            printWriter.println("streamChatUserFilter:" + this.IlIllIIIIIlIlllIIIIlllIIl);
            printWriter.println("streamMicToggleBehavior:" + this.llIIIlllllIlllIIllIlIIlII);
            printWriter.println("forceUnicodeFont:" + this.forceUnicodeFont);
            for (final KeyBinding keyBinding : this.lllIIlIIIllIIlllIlIIIllIl) {
                if (!keyBinding.lIIIIlIIllIIlIIlIIIlIIllI) {
                    printWriter.println("key_" + keyBinding.IIIllIllIlIlllllllIlIlIII() + ":" + keyBinding.lIIIIllIIlIlIllIIIlIllIlI());
                }
            }
            for (final llllIlllIllIIIIlIIllIIIIl llllIlllIllIIIIlIIllIIIIl : llllIlllIllIIIIlIIllIIIIl.values()) {
                printWriter.println("soundCategory_" + llllIlllIllIIIIlIIllIIIIl.getIdentifier() + ":" + this.lIIIIlIIllIIlIIlIIIlIIllI(llllIlllIllIIIIlIIllIIIIl));
            }
            printWriter.close();
        }
        catch (Exception ex) {
            GameSettings.llllIlIlllIIlIlIIIIlllIII.error("Failed to save options", (Throwable)ex);
        }
        this.IIIllIllIlIlllllllIlIlIII();
        this.IIIIllIlIIIllIlllIlllllIl();
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final llllIlllIllIIIIlIIllIIIIl llllIlllIllIIIIlIIllIIIIl) {
        return this.lllIlllllIllllllIIlIlllll.containsKey(llllIlllIllIIIIlIIllIIIIl) ? this.lllIlllllIllllllIIlIlllll.get(llllIlllIllIIIIlIIllIIIIl) : 1.0f;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llllIlllIllIIIIlIIllIIIIl llllIlllIllIIIIlIIllIIIIl, final float f) {
        this.IlIIIIlIlIllIIlIIIIllllll.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(llllIlllIllIIIIlIIllIIIIl, f);
        this.lllIlllllIllllllIIlIlllll.put(llllIlllIllIIIIlIIllIIIIl, f);
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        if (this.IlIIIIlIlIllIIlIIIIllllll.thePlayer != null) {
            this.IlIIIIlIlIllIIlIIIIllllll.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IllllIIlIlllIIIlIllIlIIlI(this.language, this.IlllIIIlIlllIllIlIIlllIlI, this.chatVisibility, this.llIIlllIlIIlIIIIIlIllllll, this.IlIIIIlllIIIlIIllllIIIlll, this.lIIIllIIIIlIIllIIIIIIIlll));
        }
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI >= 4 && this.lllIIlIIllIllIIllIIlIIIIl;
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        try {
            File file = this.llllIlIlIlllllIllIIllIIIl;
            if (!file.exists()) {
                file = this.IIIlIllIIIlllIIlIIllIlIII;
            }
            if (!file.exists()) {
                return;
            }
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                try {
                    final String[] split = line.split(":");
                    if (split[0].equals("ofRenderDistanceChunks") && split.length >= 2) {
                        this.IlllIIIlIlllIllIlIIlllIlI = Integer.valueOf(split[1]);
                        this.IlllIIIlIlllIllIlIIlllIlI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, 2, 32);
                    }
                    if (split[0].equals("ofFogType") && split.length >= 2) {
                        this.IlIlllIIIIllIllllIllIIlIl = Integer.valueOf(split[1]);
                        this.IlIlllIIIIllIllllIllIIlIl = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, 1, 3);
                    }
                    if (split[0].equals("ofFogStart") && split.length >= 2) {
                        this.llIIlllIIIIlllIllIlIlllIl = Float.valueOf(split[1]);
                        if (this.llIIlllIIIIlllIllIlIlllIl < 0.30864197f * 0.648f) {
                            this.llIIlllIIIIlllIllIlIlllIl = 0.06185567f * 3.2333333f;
                        }
                        if (this.llIIlllIIIIlllIllIlIlllIl > 0.11368421f * 7.125f) {
                            this.llIIlllIIIIlllIllIlIlllIl = 0.91034484f * 0.8787879f;
                        }
                    }
                    if (split[0].equals("ofMipmapType") && split.length >= 2) {
                        this.lIIlIlIllIIlIIIlIIIlllIII = Integer.valueOf(split[1]);
                        this.lIIlIlIllIIlIIIlIIIlllIII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, 0, 3);
                    }
                    if (split[0].equals("ofLoadFar") && split.length >= 2) {
                        this.IIIlllIIIllIllIlIIIIIIlII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofPreloadedChunks") && split.length >= 2) {
                        this.llIlIIIlIIIIlIlllIlIIIIll = Integer.valueOf(split[1]);
                        if (this.llIlIIIlIIIIlIlllIlIIIIll < 0) {
                            this.llIlIIIlIIIIlIlllIlIIIIll = 0;
                        }
                        if (this.llIlIIIlIIIIlIlllIlIIIIll > 8) {
                            this.llIlIIIlIIIIlIlllIlIIIIll = 8;
                        }
                    }
                    if (split[0].equals("ofOcclusionFancy") && split.length >= 2) {
                        this.IIIlIIllllIIllllllIlIIIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSmoothFps") && split.length >= 2) {
                        this.lllIIIIIlIllIlIIIllllllII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSmoothWorld") && split.length >= 2) {
                        this.lIIIIIllllIIIIlIlIIIIlIlI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAoLevel") && split.length >= 2) {
                        this.IllIllIIIlIIlllIIIllIllII = Float.valueOf(split[1]);
                        this.IllIllIIIlIIlllIIIllIllII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIllIIIlIIlllIIIllIllII, 0.0f, 1.0f);
                    }
                    if (split[0].equals("ofClouds") && split.length >= 2) {
                        this.lIIlIIllIIIIIlIllIIIIllII = Integer.valueOf(split[1]);
                        this.lIIlIIllIIIIIlIllIIIIllII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIllIIIIIlIllIIIIllII, 0, 3);
                    }
                    if (split[0].equals("ofCloudsHeight") && split.length >= 2) {
                        this.lIIlllIIlIlllllllllIIIIIl = Float.valueOf(split[1]);
                        this.lIIlllIIlIlllllllllIIIIIl = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, 0.0f, 1.0f);
                    }
                    if (split[0].equals("ofTrees") && split.length >= 2) {
                        this.lIllIllIlIIllIllIlIlIIlIl = Integer.valueOf(split[1]);
                        this.lIllIllIlIIllIllIlIlIIlIl = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIllIllIlIIllIllIlIlIIlIl, 0, 2);
                    }
                    if (split[0].equals("ofGrass") && split.length >= 2) {
                        this.llIlIIIllIIIIlllIlIIIIIlI = Integer.valueOf(split[1]);
                        this.llIlIIIllIIIIlllIlIIIIIlI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIIIllIIIIlllIlIIIIIlI, 0, 2);
                    }
                    if (split[0].equals("ofDroppedItems") && split.length >= 2) {
                        this.IllIlIIIIlllIIllIIlllIIlI = Integer.valueOf(split[1]);
                        this.IllIlIIIIlllIIllIIlllIIlI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIIIIlllIIllIIlllIIlI, 0, 2);
                    }
                    if (split[0].equals("ofRain") && split.length >= 2) {
                        this.lIllIlIlllIIlIIllIIlIIlII = Integer.valueOf(split[1]);
                        this.lIllIlIlllIIlIIllIIlIIlII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIllIlIlllIIlIIllIIlIIlII, 0, 3);
                    }
                    if (split[0].equals("ofWater") && split.length >= 2) {
                        this.IIIlIIlIlIIIlllIIlIllllll = Integer.valueOf(split[1]);
                        this.IIIlIIlIlIIIlllIIlIllllll = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, 0, 3);
                    }
                    if (split[0].equals("ofAnimatedWater") && split.length >= 2) {
                        this.IIIlIllIlllIlIllIllllllll = Integer.valueOf(split[1]);
                        this.IIIlIllIlllIlIllIllllllll = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIllIlllIlIllIllllllll, 0, 2);
                    }
                    if (split[0].equals("ofAnimatedLava") && split.length >= 2) {
                        this.IllllllllIlIIIIIIIIllIIII = Integer.valueOf(split[1]);
                        this.IllllllllIlIIIIIIIIllIIII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllllllIlIIIIIIIIllIIII, 0, 2);
                    }
                    if (split[0].equals("ofAnimatedFire") && split.length >= 2) {
                        this.lIIlIlIIlIlIlIIlIlIlllIIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedPortal") && split.length >= 2) {
                        this.IllIIIlIIlIllIllIIllllIIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedRedstone") && split.length >= 2) {
                        this.IIlIlllIllIlIlIIIIIlllIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedExplosion") && split.length >= 2) {
                        this.IlIIllIIIlllIIIIlIIIIlIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedFlame") && split.length >= 2) {
                        this.lIIIIIIlIIllllllIIIlIlIIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedSmoke") && split.length >= 2) {
                        this.llIIIlIlIIlIlIIlIllIllIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofVoidParticles") && split.length >= 2) {
                        this.IlIIlllIlIIIlIIIlIlIlIlIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofWaterParticles") && split.length >= 2) {
                        this.IIIlllllIIlIlIIIllllllIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofPortalParticles") && split.length >= 2) {
                        this.IIllllIllllIIIlIIllllIlll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofPotionParticles") && split.length >= 2) {
                        this.llllIIIIIlIlIlIlIllIIIIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofDrippingWaterLava") && split.length >= 2) {
                        this.IllIIIIllllllIlllllIlIlll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedTerrain") && split.length >= 2) {
                        this.IIIllllIlIIlIIIlIlIlllIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedTextures") && split.length >= 2) {
                        this.IlIllIllIllIllIllllIIIlII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAnimatedItems") && split.length >= 2) {
                        this.IIlIlllllIIIlIIllIllIlIlI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofRainSplash") && split.length >= 2) {
                        this.lIlIlIIIIllIlllIlIIlllIlI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofLagometer") && split.length >= 2) {
                        this.lIlIlIllIIIIIIIIllllIIllI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofShowFps") && split.length >= 2) {
                        this.IllllIllllIlIIIlIIIllllll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAutoSaveTicks") && split.length >= 2) {
                        this.IllIIlIIlllllIllIIIlllIII = Integer.valueOf(split[1]);
                        this.IllIIlIIlllllIllIIIlllIII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII, 40, 40000);
                    }
                    if (split[0].equals("ofBetterGrass") && split.length >= 2) {
                        this.IllIlIlIllllIlIIllllIIlll = Integer.valueOf(split[1]);
                        this.IllIlIlIllllIlIIllllIIlll = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIlIlIllllIlIIllllIIlll, 1, 3);
                    }
                    if (split[0].equals("ofConnectedTextures") && split.length >= 2) {
                        this.IlIlllIllIlIllIlllIlllIll = Integer.valueOf(split[1]);
                        this.IlIlllIllIlIllIlllIlllIll = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIllIlIllIlllIlllIll, 1, 3);
                    }
                    if (split[0].equals("ofWeather") && split.length >= 2) {
                        this.IllIIlllIllIlIllIlIIIIIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSky") && split.length >= 2) {
                        this.IlIlIIIlllllIIIlIlIlIllII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofStars") && split.length >= 2) {
                        this.IIlIIllIIIllllIIlllIllIIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSunMoon") && split.length >= 2) {
                        this.lllIlIIllllIIIIlIllIlIIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofVignette") && split.length >= 2) {
                        this.lIIIIlllIIlIlllllIlIllIII = Integer.valueOf(split[1]);
                        this.lIIIIlllIIlIlllllIlIllIII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII, 0, 2);
                    }
                    if (split[0].equals("ofChunkUpdates") && split.length >= 2) {
                        this.lIIIlllIlIlllIIIIIIIIIlII = Integer.valueOf(split[1]);
                        this.lIIIlllIlIlllIIIIIIIIIlII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIlllIlIlllIIIIIIIIIlII, 1, 5);
                    }
                    if (!split[0].equals("ofChunkLoading") || split.length >= 2) {}
                    if (split[0].equals("ofChunkUpdatesDynamic") && split.length >= 2) {
                        this.IlIllllIIIlIllllIIIIIllII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofTime") && split.length >= 2) {
                        this.IlIIIIllIIIIIlllIIlIIlllI = Integer.valueOf(split[1]);
                        this.IlIIIIllIIIIIlllIIlIIlllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIIIllIIIIIlllIIlIIlllI, 0, 3);
                    }
                    if (split[0].equals("ofClearWater") && split.length >= 2) {
                        this.llIlIlIllIlIIlIlllIllIIlI = Boolean.valueOf(split[1]);
                        this.IlIlllIIIIllIllllIllIIlIl();
                    }
                    if (split[0].equals("ofDepthFog") && split.length >= 2) {
                        this.llIlIlIlllIlllllIIIllIIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofAaLevel") && split.length >= 2) {
                        this.IlIIlIIIIlIIIIllllIIlIllI = Integer.valueOf(split[1]);
                        this.IlIIlIIIIlIIIIllllIIlIllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIlIIIIlIIIIllllIIlIllI, 0, 16);
                    }
                    if (split[0].equals("ofProfiler") && split.length >= 2) {
                        this.IlllIIlllIIIIllIIllllIlIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofBetterSnow") && split.length >= 2) {
                        this.IIllIlIllIlIllIIlIllIlIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSwampColors") && split.length >= 2) {
                        this.IlIIlIIlIllIIIIllIIllIlIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofRandomMobs") && split.length >= 2) {
                        this.llllIIIIlIlIllIIIllllIIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofSmoothBiomes") && split.length >= 2) {
                        this.IIlIlIIlIIIlIlllllIIlIIlI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofCustomFonts") && split.length >= 2) {
                        this.lIIIlllIIIlIIIIIlIIIIIIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofCustomColors") && split.length >= 2) {
                        this.lIIlIIIIIIIIllIIllIIlllIl = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofCustomSky") && split.length >= 2) {
                        this.IllllllIllllIIlllIllllllI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofShowCapes") && split.length >= 2) {
                        this.lIlIlIIIlIIllllllllIIlllI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofNaturalTextures") && split.length >= 2) {
                        this.llIIIllIIllllIlIlIlIlIIll = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofLazyChunkLoading") && split.length >= 2) {
                        this.IIIIIIlIlIlIllllllIlllIlI = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofDynamicFov") && split.length >= 2) {
                        this.IlIIllIlIlIIIllIllIIlIIII = Boolean.valueOf(split[1]);
                    }
                    if (split[0].equals("ofDynamicLights") && split.length >= 2) {
                        this.IlIlllIIIIlIllIlllIlIIIll = Integer.valueOf(split[1]);
                        this.IlIlllIIIIlIllIlllIlIIIll = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 1, 3);
                    }
                    if (split[0].equals("ofFullscreenMode") && split.length >= 2) {
                        this.lIlIllIlIlIIIllllIlIllIll = split[1];
                    }
                    if (split[0].equals("ofFastMath") && split.length >= 2) {
                        this.IIIIIlIllIllIlIIllIIlIllI = Boolean.valueOf(split[1]);
                        MathHelper.IIIIllIIllIIIIllIllIIIlIl = this.IIIIIlIllIllIlIIllIIlIllI;
                    }
                    if (split[0].equals("ofFastRender") && split.length >= 2) {
                        this.lIIllIIllllllIIlllIlllIIl = Boolean.valueOf(split[1]);
                    }
                    if (!split[0].equals("ofTranslucentBlocks") || split.length < 2) {
                        continue;
                    }
                    this.lllIIllllIIlIlIlIlIIIlIII = Integer.valueOf(split[1]);
                    this.lllIIllllIIlIlIlIlIIIlIII = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIllllIIlIlIlIlIIIlIII, 1, 2);
                }
                catch (Exception ex) {
                    lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("Skipping bad option: " + line);
                    ex.printStackTrace();
                }
            }
            KeyBinding.lIIIIIIIIIlIllIIllIlIIlIl();
            bufferedReader.close();
        }
        catch (Exception ex2) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Failed to load options");
            ex2.printStackTrace();
        }
    }
    
    public void IIIllIllIlIlllllllIlIlIII() {
        try {
            final PrintWriter printWriter = new PrintWriter(new FileWriter(this.llllIlIlIlllllIllIIllIIIl));
            printWriter.println("ofRenderDistanceChunks:" + this.IlllIIIlIlllIllIlIIlllIlI);
            printWriter.println("ofFogType:" + this.IlIlllIIIIllIllllIllIIlIl);
            printWriter.println("ofFogStart:" + this.llIIlllIIIIlllIllIlIlllIl);
            printWriter.println("ofMipmapType:" + this.lIIlIlIllIIlIIIlIIIlllIII);
            printWriter.println("ofLoadFar:" + this.IIIlllIIIllIllIlIIIIIIlII);
            printWriter.println("ofPreloadedChunks:" + this.llIlIIIlIIIIlIlllIlIIIIll);
            printWriter.println("ofOcclusionFancy:" + this.IIIlIIllllIIllllllIlIIIll);
            printWriter.println("ofSmoothFps:" + this.lllIIIIIlIllIlIIIllllllII);
            printWriter.println("ofSmoothWorld:" + this.lIIIIIllllIIIIlIlIIIIlIlI);
            printWriter.println("ofAoLevel:" + this.IllIllIIIlIIlllIIIllIllII);
            printWriter.println("ofClouds:" + this.lIIlIIllIIIIIlIllIIIIllII);
            printWriter.println("ofCloudsHeight:" + this.lIIlllIIlIlllllllllIIIIIl);
            printWriter.println("ofTrees:" + this.lIllIllIlIIllIllIlIlIIlIl);
            printWriter.println("ofGrass:" + this.llIlIIIllIIIIlllIlIIIIIlI);
            printWriter.println("ofDroppedItems:" + this.IllIlIIIIlllIIllIIlllIIlI);
            printWriter.println("ofRain:" + this.lIllIlIlllIIlIIllIIlIIlII);
            printWriter.println("ofWater:" + this.IIIlIIlIlIIIlllIIlIllllll);
            printWriter.println("ofAnimatedWater:" + this.IIIlIllIlllIlIllIllllllll);
            printWriter.println("ofAnimatedLava:" + this.IllllllllIlIIIIIIIIllIIII);
            printWriter.println("ofAnimatedFire:" + this.lIIlIlIIlIlIlIIlIlIlllIIl);
            printWriter.println("ofAnimatedPortal:" + this.IllIIIlIIlIllIllIIllllIIl);
            printWriter.println("ofAnimatedRedstone:" + this.IIlIlllIllIlIlIIIIIlllIll);
            printWriter.println("ofAnimatedExplosion:" + this.IlIIllIIIlllIIIIlIIIIlIll);
            printWriter.println("ofAnimatedFlame:" + this.lIIIIIIlIIllllllIIIlIlIIl);
            printWriter.println("ofAnimatedSmoke:" + this.llIIIlIlIIlIlIIlIllIllIll);
            printWriter.println("ofVoidParticles:" + this.IlIIlllIlIIIlIIIlIlIlIlIl);
            printWriter.println("ofWaterParticles:" + this.IIIlllllIIlIlIIIllllllIII);
            printWriter.println("ofPortalParticles:" + this.IIllllIllllIIIlIIllllIlll);
            printWriter.println("ofPotionParticles:" + this.llllIIIIIlIlIlIlIllIIIIII);
            printWriter.println("ofDrippingWaterLava:" + this.IllIIIIllllllIlllllIlIlll);
            printWriter.println("ofAnimatedTerrain:" + this.IIIllllIlIIlIIIlIlIlllIII);
            printWriter.println("ofAnimatedTextures:" + this.IlIllIllIllIllIllllIIIlII);
            printWriter.println("ofAnimatedItems:" + this.IIlIlllllIIIlIIllIllIlIlI);
            printWriter.println("ofRainSplash:" + this.lIlIlIIIIllIlllIlIIlllIlI);
            printWriter.println("ofLagometer:" + this.lIlIlIllIIIIIIIIllllIIllI);
            printWriter.println("ofShowFps:" + this.IllllIllllIlIIIlIIIllllll);
            printWriter.println("ofAutoSaveTicks:" + this.IllIIlIIlllllIllIIIlllIII);
            printWriter.println("ofBetterGrass:" + this.IllIlIlIllllIlIIllllIIlll);
            printWriter.println("ofConnectedTextures:" + this.IlIlllIllIlIllIlllIlllIll);
            printWriter.println("ofWeather:" + this.IllIIlllIllIlIllIlIIIIIII);
            printWriter.println("ofSky:" + this.IlIlIIIlllllIIIlIlIlIllII);
            printWriter.println("ofStars:" + this.IIlIIllIIIllllIIlllIllIIl);
            printWriter.println("ofSunMoon:" + this.lllIlIIllllIIIIlIllIlIIII);
            printWriter.println("ofVignette:" + this.lIIIIlllIIlIlllllIlIllIII);
            printWriter.println("ofChunkUpdates:" + this.lIIIlllIlIlllIIIIIIIIIlII);
            printWriter.println("ofChunkLoading:" + this.IIIIlIIIlllllllllIlllIlll);
            printWriter.println("ofChunkUpdatesDynamic:" + this.IlIllllIIIlIllllIIIIIllII);
            printWriter.println("ofTime:" + this.IlIIIIllIIIIIlllIIlIIlllI);
            printWriter.println("ofClearWater:" + this.llIlIlIllIlIIlIlllIllIIlI);
            printWriter.println("ofDepthFog:" + this.llIlIlIlllIlllllIIIllIIll);
            printWriter.println("ofAaLevel:" + this.IlIIlIIIIlIIIIllllIIlIllI);
            printWriter.println("ofProfiler:" + this.IlllIIlllIIIIllIIllllIlIl);
            printWriter.println("ofBetterSnow:" + this.IIllIlIllIlIllIIlIllIlIII);
            printWriter.println("ofSwampColors:" + this.IlIIlIIlIllIIIIllIIllIlIl);
            printWriter.println("ofRandomMobs:" + this.llllIIIIlIlIllIIIllllIIll);
            printWriter.println("ofSmoothBiomes:" + this.IIlIlIIlIIIlIlllllIIlIIlI);
            printWriter.println("ofCustomFonts:" + this.lIIIlllIIIlIIIIIlIIIIIIII);
            printWriter.println("ofCustomColors:" + this.lIIlIIIIIIIIllIIllIIlllIl);
            printWriter.println("ofCustomSky:" + this.IllllllIllllIIlllIllllllI);
            printWriter.println("ofShowCapes:" + this.lIlIlIIIlIIllllllllIIlllI);
            printWriter.println("ofNaturalTextures:" + this.llIIIllIIllllIlIlIlIlIIll);
            printWriter.println("ofLazyChunkLoading:" + this.IIIIIIlIlIlIllllllIlllIlI);
            printWriter.println("ofDynamicFov:" + this.IlIIllIlIlIIIllIllIIlIIII);
            printWriter.println("ofDynamicLights:" + this.IlIlllIIIIlIllIlllIlIIIll);
            printWriter.println("ofFullscreenMode:" + this.lIlIllIlIlIIIllllIlIllIll);
            printWriter.println("ofFastMath:" + this.IIIIIlIllIllIlIIllIIlIllI);
            printWriter.println("ofFastRender:" + this.lIIllIIllllllIIlllIlllIIl);
            printWriter.println("ofTranslucentBlocks:" + this.lllIIllllIIlIlIlIlIIIlIII);
            printWriter.close();
        }
        catch (Exception ex) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Failed to save options");
            ex.printStackTrace();
        }
    }
    
    public void IllIIIIIIIlIlIllllIIllIII() {
        this.IlllIIIlIlllIllIlIIlllIlI = 8;
        this.IIIIllIlIIIllIlllIlllllIl = true;
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.IlIlIIIlllIIIlIlllIlIllIl = false;
        this.limitFramerate = (int)lllIlIIIIlIIlIlIIlIlIlIll.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl();
        this.enableVsync = false;
        this.lIIIIllIIlIlIllIIIlIllIlI();
        this.mipmapLevels = 4;
        this.anisotropicFiltering = 1;
        this.fancyGraphics = true;
        this.IlllIllIlIIIIlIIlIIllIIIl = 2;
        this.lllIIlIIllIllIIllIIlIIIIl = true;
        this.IIIlllIllIIllIllIlIIIllII = 70;
        this.lIIlIlllIIIIlIIIllIlIIIII = 0.0f;
        this.IIlIIlIlIlIlllIIlIIlIIlII = 0;
        this.lIllIlllIIllIllllIllIIlll = 0;
        this.llllIIllllllIlIIlIlIIIllI = true;
        this.IlIlllIIIIllIllllIllIIlIl = 1;
        this.llIIlllIIIIlllIllIlIlllIl = 1.472f * 0.54347825f;
        this.lIIlIlIllIIlIIIlIIIlllIII = 0;
        this.IIIlllIIIllIllIlIIIIIIlII = false;
        this.llIlIIIlIIIIlIlllIlIIIIll = 0;
        this.IIIlIIllllIIllllllIlIIIll = false;
        this.lllIIIIIlIllIlIIIllllllII = false;
        lIIIllIIIllIlllllIIlIllII.lIIIlIlIIllIIlllIIIlIIllI();
        this.lIIIIIllllIIIIlIlIIIIlIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IIIIIIlIlIlIllllllIlllIlI = lIIIllIIIllIlllllIIlIllII.lIIIlIIlIIIIIllIIlIlIlIII();
        this.IIIIIlIllIllIlIIllIIlIllI = false;
        this.lIIllIIllllllIIlllIlllIIl = false;
        this.lllIIllllIIlIlIlIlIIIlIII = 2;
        this.IlIIllIlIlIIIllIllIIlIIII = true;
        this.IlIlllIIIIlIllIlllIlIIIll = 3;
        this.IllIllIIIlIIlllIIIllIllII = 1.0f;
        this.IlIIlIIIIlIIIIllllIIlIllI = 0;
        this.lIIlIIllIIIIIlIllIIIIllII = 0;
        this.lIIlllIIlIlllllllllIIIIIl = 0.0f;
        this.lIllIllIlIIllIllIlIlIIlIl = 0;
        this.llIlIIIllIIIIlllIlIIIIIlI = 0;
        this.lIllIlIlllIIlIIllIIlIIlII = 0;
        this.IIIlIIlIlIIIlllIIlIllllll = 0;
        this.IllIlIlIllllIlIIllllIIlll = 3;
        this.IllIIlIIlllllIllIIIlllIII = 4000;
        this.lIlIlIllIIIIIIIIllllIIllI = false;
        this.IllllIllllIlIIIlIIIllllll = false;
        this.IlllIIlllIIIIllIIllllIlIl = false;
        this.IllIIlllIllIlIllIlIIIIIII = true;
        this.IlIlIIIlllllIIIlIlIlIllII = true;
        this.IIlIIllIIIllllIIlllIllIIl = true;
        this.lllIlIIllllIIIIlIllIlIIII = true;
        this.lIIIIlllIIlIlllllIlIllIII = 0;
        this.lIIIlllIlIlllIIIIIIIIIlII = 1;
        this.IIIIlIIIlllllllllIlllIlll = 0;
        this.IlIllllIIIlIllllIIIIIllII = false;
        this.IlIIIIllIIIIIlllIIlIIlllI = 0;
        this.llIlIlIllIlIIlIlllIllIIlI = false;
        this.llIlIlIlllIlllllIIIllIIll = true;
        this.IIllIlIllIlIllIIlIllIlIII = false;
        this.lIlIllIlIlIIIllllIlIllIll = "Default";
        this.IlIIlIIlIllIIIIllIIllIlIl = true;
        this.llllIIIIlIlIllIIIllllIIll = true;
        this.IIlIlIIlIIIlIlllllIIlIIlI = true;
        this.lIIIlllIIIlIIIIIlIIIIIIII = true;
        this.lIIlIIIIIIIIllIIllIIlllIl = true;
        this.IllllllIllllIIlllIllllllI = true;
        this.lIlIlIIIlIIllllllllIIlllI = true;
        this.IlIlllIllIlIllIlllIlllIll = 2;
        this.llIIIllIIllllIlIlIlIlIIll = false;
        this.IIIlIllIlllIlIllIllllllll = 0;
        this.IllllllllIlIIIIIIIIllIIII = 0;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = true;
        this.IllIIIlIIlIllIllIIllllIIl = true;
        this.IIlIlllIllIlIlIIIIIlllIll = true;
        this.IlIIllIIIlllIIIIlIIIIlIll = true;
        this.lIIIIIIlIIllllllIIIlIlIIl = true;
        this.llIIIlIlIIlIlIIlIllIllIll = true;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = true;
        this.IIIlllllIIlIlIIIllllllIII = true;
        this.lIlIlIIIIllIlllIlIIlllIlI = true;
        this.IIllllIllllIIIlIIllllIlll = true;
        this.llllIIIIIlIlIlIlIllIIIIII = true;
        this.IllIIIIllllllIlllllIlIlll = true;
        this.IIIllllIlIIlIIIlIlIlllIII = true;
        this.IIlIlllllIIIlIIllIllIlIlI = true;
        this.IlIllIllIllIllIllllIIIlII = true;
        this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.IlIlllIIIIllIllllIllIIlIl();
        this.IlIlllIIIIllIllllIllIIlIl();
        this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.IllIIIIIIIlIlIllllIIllIII();
        this.IlIIIIlIlIllIIlIIIIllllll.refreshResources();
        this.saveOptions();
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI() {
        Display.setVSyncEnabled(this.enableVsync);
    }
    
    private void IlIlllIIIIllIllllIllIIlIl() {
        if (this.IlIIIIlIlIllIIlIIIIllllll.IllllIllllIlIIIlIIIllllll() && this.IlIIIIlIlIllIIlIIIIllllll.IlIlIIIlllllIIIlIlIlIllII() != null) {
            lIIIllIIIllIlllllIIlIllII.IlllIllIlIIIIlIIlIIllIIIl = true;
        }
        lllIlIIllIlllllllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this, this.IlIIIIlIlIllIIlIIIIllllll.theWorld);
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl() {
        if (this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal != null) {
            this.IlIIIIlIlIllIIlIIIIllllll.renderGlobal.loadRenderers();
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean ilIllIllIllIllIllllIIIlII) {
        final int n = ilIllIllIllIllIllllIIIlII ? 0 : 2;
        this.IIIlIllIlllIlIllIllllllll = n;
        this.IllllllllIlIIIIIIIIllIIII = n;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = ilIllIllIllIllIllllIIIlII;
        this.IllIIIlIIlIllIllIIllllIIl = ilIllIllIllIllIllllIIIlII;
        this.IIlIlllIllIlIlIIIIIlllIll = ilIllIllIllIllIllllIIIlII;
        this.IlIIllIIIlllIIIIlIIIIlIll = ilIllIllIllIllIllllIIIlII;
        this.lIIIIIIlIIllllllIIIlIlIIl = ilIllIllIllIllIllllIIIlII;
        this.llIIIlIlIIlIlIIlIllIllIll = ilIllIllIllIllIllllIIIlII;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = ilIllIllIllIllIllllIIIlII;
        this.IIIlllllIIlIlIIIllllllIII = ilIllIllIllIllIllllIIIlII;
        this.lIlIlIIIIllIlllIlIIlllIlI = ilIllIllIllIllIllllIIIlII;
        this.IIllllIllllIIIlIIllllIlll = ilIllIllIllIllIllllIIIlII;
        this.llllIIIIIlIlIlIlIllIIIIII = ilIllIllIllIllIllllIIIlII;
        this.lIllIlllIIllIllllIllIIlll = (ilIllIllIllIllIllllIIIlII ? 0 : 2);
        this.IllIIIIllllllIlllllIlIlll = ilIllIllIllIllIllllIIIlII;
        this.IIIllllIlIIlIIIlIlIlllIII = ilIllIllIllIllIllllIIIlII;
        this.IIlIlllllIIIlIIllIllIlIlI = ilIllIllIllIllIllllIIIlII;
        this.IlIllIllIllIllIllllIIIlII = ilIllIllIllIllIllllIIIlII;
    }
    
    static {
        llllIlIlllIIlIlIIIIlllIII = LogManager.getLogger();
        IllIIllIIIlIlllIlIlIIlIII = new Gson();
        IIlIlIIIIllIIIllIlIIIllll = new IIllIIIIlIIllIIlIIIIIllII();
        IlIlIIIlIlIllIIIIIllllIIl = new String[] { "options.guiScale.auto", "options.guiScale.small", "options.guiScale.normal", "options.guiScale.large" };
        IlIIlIIlIIlllIlIIIlIllIIl = new String[] { "options.particles.all", "options.particles.decreased", "options.particles.minimal" };
        llIIIIIIllIIIllllIIllIIII = new String[] { "options.ao.off", "options.ao.min", "options.ao.max" };
        lIllIlIlIlllIIIIllIlIIIII = new String[] { "options.stream.compression.low", "options.stream.compression.medium", "options.stream.compression.high" };
        lllIllIllllIllIllIlllllIl = new String[] { "options.stream.chat.enabled.streaming", "options.stream.chat.enabled.always", "options.stream.chat.enabled.never" };
        IIlllIIlIlIIIlIlIlIIlllII = new String[] { "options.stream.chat.userFilter.all", "options.stream.chat.userFilter.subs", "options.stream.chat.userFilter.mods" };
        lIlIIllIIlllIlIlllIIIIllI = new String[] { "options.stream.mic_toggle.mute", "options.stream.mic_toggle.talk" };
    }
}
