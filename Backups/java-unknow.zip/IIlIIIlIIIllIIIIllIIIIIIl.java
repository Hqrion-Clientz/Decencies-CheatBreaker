import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIlIIIllIIIIllIIIIIIl extends IIllIlIIlllIlIIlIllllllll
{
    private IIlllllllIlllIIllllIIlIll lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIIIlIIIllIIIIllIIIIIIl(final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI, final boolean liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3) != IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            return false;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.air && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) != IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            return false;
        }
        int n4 = 0;
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            ++n4;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl) {
            ++n4;
        }
        int n5 = 0;
        if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n - 1, n2, n3)) {
            ++n5;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n + 1, n2, n3)) {
            ++n5;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 - 1)) {
            ++n5;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 + 1)) {
            ++n5;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2 - 1, n3)) {
            ++n5;
        }
        if ((!this.lIIIIIIIIIlIllIIllIlIIlIl && n4 == 4 && n5 == 1) || n4 == 5) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this.lIIIIlIIllIIlIIlIIIlIIllI, 0, 2);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl = true;
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, random);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl = false;
        }
        return true;
    }
}
