import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIlIIIIllIIlIIlIIIIl extends IIlllllllIlllIIllllIIlIll
{
    public IIlIIIIlIIIIllIIlIIlIIIIl() {
        super(Material.IllIlIIIIlllIIllIIlllIIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return IIlIlIllIlIIllIllIllIIIll.IIlIlIlllIllIIlIllIIlIIlI;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        return 4;
    }
}
