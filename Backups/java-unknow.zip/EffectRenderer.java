import org.lwjgl.opengl.GL11;
import java.util.concurrent.Callable;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class EffectRenderer
{
    private static final ResourceLocation lIIIIIIIIIlIllIIllIlIIlIl;
    protected IIIIIIllIlIIIIlIlllIllllI lIIIIlIIllIIlIIlIIIlIIllI;
    private List[] IlllIIIlIlllIllIlIIlllIlI;
    private TextureManager IIIIllIlIIIllIlllIlllllIl;
    private Random IIIIllIIllIIIIllIllIIIlIl;
    
    public EffectRenderer(final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI, final TextureManager iiiIllIlIIIllIlllIlllllIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = new List[4];
        this.IIIIllIIllIIIIllIllIIIlIl = new Random();
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        }
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        for (int i = 0; i < 4; ++i) {
            this.IlllIIIlIlllIllIlIIlllIlI[i] = new ArrayList();
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIllIlIllIIlIIIlIIlll illlIllIlIllIIlIIIlIIlll) {
        final int illlIIIlIlllIllIlIIlllIlI = illlIllIlIllIIlIIIlIIlll.IlllIIIlIlllIllIlIIlllIlI();
        if (this.IlllIIIlIlllIllIlIIlllIlI[illlIIIlIlllIllIlIIlllIlI].size() >= 4000) {
            this.IlllIIIlIlllIllIlIIlllIlI[illlIIIlIlllIllIlIIlllIlI].remove(0);
        }
        this.IlllIIIlIlllIllIlIIlllIlI[illlIIIlIlllIllIlIIlllIlI].add(illlIllIlIllIIlIIIlIIlll);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        for (int i = 0; i < 4; ++i) {
            for (int n = i, j = 0; j < this.IlllIIIlIlllIllIlIIlllIlI[n].size(); ++j) {
                final IIlllIllIlIllIIlIIIlIIlll illlIllIlIllIIlIIIlIIlll = this.IlllIIIlIlllIllIlIIlllIlI[n].get(j);
                try {
                    illlIllIlIllIIlIIIlIIlll.x_();
                }
                catch (Throwable t) {
                    final CrashReport crashReport = CrashReport.makeCrashReport(t, "Ticking Particle");
                    final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Particle being ticked");
                    category.addCrashSectionCallable("Particle", new llIIlllllllllIlIIlIlIlIlI(this, illlIllIlIllIIlIIIlIIlll));
                    category.addCrashSectionCallable("Particle Type", new lIIlIIIllIllIIIIIlIIlllIl(this, n));
                    throw new ReportedException(crashReport);
                }
                if (illlIllIlIllIIlIIIlIIlll.IIllIlIllIlIllIIlIllIlIII) {
                    this.IlllIIIlIlllIllIlIIlllIlI[n].remove(j--);
                }
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n) {
        final float iiiIllIlIIIllIlllIlllllIl = IlIIIllIlIlIIIlIIlIIIIlIl.IIIIllIlIIIllIlllIlllllIl;
        final float ilIlIIIlllIIIlIlllIlIllIl = IlIIIllIlIlIIIlIIlIIIIlIl.IlIlIIIlllIIIlIlllIlIllIl;
        final float iiIllIllIlIlllllllIlIlIII = IlIIIllIlIlIIIlIIlIIIIlIl.IIIllIllIlIlllllllIlIlIII;
        final float illIIIIIIIlIlIllllIIllIII = IlIIIllIlIlIIIlIIlIIIIlIl.IllIIIIIIIlIlIllllIIllIII;
        final float iiiIllIIllIIIIllIllIIIlIl = IlIIIllIlIlIIIlIIlIIIIlIl.IIIIllIIllIIIIllIllIIIlIl;
        IIlllIllIlIllIIlIIIlIIlll.llIlIIIlIIIIlIlllIlIIIIll = entity.lIlIlIIIlIIllllllllIIlllI + (entity.IIIlIIlIlIIIlllIIlIllllll - entity.lIlIlIIIlIIllllllllIIlllI) * n;
        IIlllIllIlIllIIlIIIlIIlll.IIIlIIllllIIllllllIlIIIll = entity.IlIlllIllIlIllIlllIlllIll + (entity.IllIlIIIIlllIIllIIlllIIlI - entity.IlIlllIllIlIllIlllIlllIll) * n;
        IIlllIllIlIllIIlIIIlIIlll.lllIIIIIlIllIlIIIllllllII = entity.llIIIllIIllllIlIlIlIlIIll + (entity.IllIlIlIllllIlIIllllIIlll - entity.llIIIllIIllllIlIlIlIlIIll) * n;
        for (int i = 0; i < 3; ++i) {
            final int n2 = i;
            if (!this.IlllIIIlIlllIllIlIIlllIlI[n2].isEmpty()) {
                switch (n2) {
                    default: {
                        this.IIIIllIlIIIllIlllIlllllIl.bindTexture(EffectRenderer.lIIIIIIIIIlIllIIllIlIIlIl);
                        break;
                    }
                    case 1: {
                        this.IIIIllIlIIIllIlllIlllllIl.bindTexture(TextureMap.locationBlocksTexture);
                        break;
                    }
                    case 2: {
                        this.IIIIllIlIIIllIlllIlllllIl.bindTexture(TextureMap.locationItemsTexture);
                        break;
                    }
                }
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glDepthMask(false);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glAlphaFunc(516, 0.0057315235f * 0.68421054f);
                final Tessellator instance = Tessellator.instance;
                instance.startDrawingQuads();
                for (int j = 0; j < this.IlllIIIlIlllIllIlIIlllIlI[n2].size(); ++j) {
                    final IIlllIllIlIllIIlIIIlIIlll illlIllIlIllIIlIIIlIIlll = this.IlllIIIlIlllIllIlIIlllIlI[n2].get(j);
                    instance.lIIIIIIIIIlIllIIllIlIIlIl(illlIllIlIllIIlIIIlIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n));
                    try {
                        illlIllIlIllIIlIIIlIIlll.lIIIIlIIllIIlIIlIIIlIIllI(instance, n, iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, ilIlIIIlllIIIlIlllIlIllIl, iiIllIllIlIlllllllIlIlIII, illIIIIIIIlIlIllllIIllIII);
                    }
                    catch (Throwable t) {
                        final CrashReport crashReport = CrashReport.makeCrashReport(t, "Rendering Particle");
                        final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Particle being rendered");
                        category.addCrashSectionCallable("Particle", new IIIllIIlIIIIIIlIlIIllIIlI(this, illlIllIlIllIIlIIIlIIlll));
                        category.addCrashSectionCallable("Particle Type", new IllIlIlIIlIIllIlllllllllI(this, n2));
                        throw new ReportedException(crashReport);
                    }
                }
                instance.draw();
                GL11.glDisable(3042);
                GL11.glDepthMask(true);
                GL11.glAlphaFunc(516, 13.5f * 0.0074074077f);
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity, final float n) {
        final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(entity.IllllIllllIlIIIlIIIllllll * (0.33333334f * 0.052359875f));
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(entity.IllllIllllIlIIIlIIIllllll * (0.0042453953f * 4.111111f));
        final float n2 = -liiiIlIIllIIlIIlIIIlIIllI * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(entity.IllIIlllIllIlIllIlIIIIIII * (0.023613278f * 0.73913044f));
        final float n3 = liiiiiiiiIlIllIIllIlIIlIl * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(entity.IllIIlllIllIlIllIlIIIIIII * (0.2173913f * 0.08028515f));
        final float liiiiiiiiIlIllIIllIlIIlIl2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(entity.IllIIlllIllIlIllIlIIIIIII * (0.017453292f * 1.0f));
        final List list = this.IlllIIIlIlllIllIlIIlllIlI[3];
        if (!list.isEmpty()) {
            final Tessellator instance = Tessellator.instance;
            for (int i = 0; i < list.size(); ++i) {
                final IIlllIllIlIllIIlIIIlIIlll illlIllIlIllIIlIIIlIIlll = list.get(i);
                instance.lIIIIIIIIIlIllIIllIlIIlIl(illlIllIlIllIIlIIIlIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n));
                illlIllIlIllIIlIIIlIIlll.lIIIIlIIllIIlIIlIIIlIIllI(instance, n, liiiiiiiiIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl2, liiiIlIIllIIlIIlIIIlIIllI, n2, n3);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        for (int i = 0; i < 4; ++i) {
            this.IlllIIIlIlllIllIlIIlllIlI[i].clear();
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        if (illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
            for (int n5 = 4, i = 0; i < n5; ++i) {
                for (int j = 0; j < n5; ++j) {
                    for (int k = 0; k < n5; ++k) {
                        final double n6 = n + (i + 0.3333333432674408 * 1.4999999552965178) / n5;
                        final double n7 = n2 + (j + 4.285714149475098 * 0.11666667037540024) / n5;
                        final double n8 = n3 + (k + 0.72826087474823 * 0.6865671592928249) / n5;
                        this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIIlIIlIlIIIIIllllIIIl(this.lIIIIlIIllIIlIIlIIIlIIllI, n6, n7, n8, n6 - n - 1.6388888359069824 * 0.30508475562547444, n7 - n2 - 1.7333333492279053 * 0.28846153581636197, n8 - n3 - 0.25609756842175835 * 1.952380895614624, illlllllIlllIIllllIIlIll, n4).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3));
                    }
                }
            }
        }
    }
    
    public void addBlockHitEffects(final int n, final int n2, final int n3, final int n4) {
        final IIlllllllIlllIIllllIIlIll block = this.lIIIIlIIllIIlIIlIIIlIIllI.getBlock(n, n2, n3);
        if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
            final float n5 = 0.060416665f * 1.6551725f;
            double n6 = n + this.IIIIllIIllIIIIllIllIIIlIl.nextDouble() * (block.IIIIIIlIlIlIllllllIlllIlI() - block.lIIIIIllllIIIIlIlIIIIlIlI() - n5 * 2.0f) + n5 + block.lIIIIIllllIIIIlIlIIIIlIlI();
            double n7 = n2 + this.IIIIllIIllIIIIllIllIIIlIl.nextDouble() * (block.IlIIlIIIIlIIIIllllIIlIllI() - block.IllIllIIIlIIlllIIIllIllII() - n5 * 2.0f) + n5 + block.IllIllIIIlIIlllIIIllIllII();
            double n8 = n3 + this.IIIIllIIllIIIIllIllIIIlIl.nextDouble() * (block.lIIlllIIlIlllllllllIIIIIl() - block.lIIlIIllIIIIIlIllIIIIllII() - n5 * 2.0f) + n5 + block.lIIlIIllIIIIIlIllIIIIllII();
            if (n4 == 0) {
                n7 = n2 + block.IllIllIIIlIIlllIIIllIllII() - n5;
            }
            if (n4 == 1) {
                n7 = n2 + block.IlIIlIIIIlIIIIllllIIlIllI() + n5;
            }
            if (n4 == 2) {
                n8 = n3 + block.lIIlIIllIIIIIlIllIIIIllII() - n5;
            }
            if (n4 == 3) {
                n8 = n3 + block.lIIlllIIlIlllllllllIIIIIl() + n5;
            }
            if (n4 == 4) {
                n6 = n + block.lIIIIIllllIIIIlIlIIIIlIlI() - n5;
            }
            if (n4 == 5) {
                n6 = n + block.IIIIIIlIlIlIllllllIlllIlI() + n5;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIIlIIlIlIIIIIllllIIIl(this.lIIIIlIIllIIlIIlIIIlIIllI, n6, n7, n8, 0.0, 0.0, 0.0, block, this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3)).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3).IlllIIIlIlllIllIlIIlllIlI(0.21428572f * 0.93333334f).IIIIllIlIIIllIlllIlllllIl(3.173913f * 0.18904111f));
        }
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return "" + (this.IlllIIIlIlllIllIlIIlllIlI[0].size() + this.IlllIIIlIlllIllIlIIlllIlI[1].size() + this.IlllIIIlIlllIllIlIIlllIlI[2].size());
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = new ResourceLocation("textures/particle/particles.png");
    }
}
