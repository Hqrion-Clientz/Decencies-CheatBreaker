import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIllIlIIIllIlIIIIlIlllII
{
    public List lIIIIIIIIIlIllIIllIlIIlIl;
    public List IlllIIIlIlllIllIlIIlllIlI;
    public int IIIIllIlIIIllIlllIlllllIl;
    private short lIIIIlIIllIIlIIlIIIlIIllI;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private final Set IllIIIIIIIlIlIllllIIllIII;
    protected List IIIIllIIllIIIIllIllIIIlIl;
    private Set lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIIllIlIIIllIlIIIIlIlllII() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IllIIIIIIIlIlIllllIIllIII = new HashSet();
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.lIIIIllIIlIlIllIIIlIllIlI = new HashSet();
    }
    
    protected IlIIIIIlIIIIlIIIIlIlllIlI lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI) {
        ilIIIIIlIIIIlIIIIlIlllIlI.IIIllIllIlIlllllllIlIlIII = this.IlllIIIlIlllIllIlIIlllIlI.size();
        this.IlllIIIlIlllIllIlIIlllIlI.add(ilIIIIIlIIIIlIIIIlIlllIlI);
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(null);
        return ilIIIIIlIIIIlIIIIlIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllllIIIIlIllIIllIIlIIll lIllllIIIIlIllIIllIIlIIll) {
        if (this.IIIIllIIllIIIIllIllIIIlIl.contains(lIllllIIIIlIllIIllIIlIIll)) {
            throw new IllegalArgumentException("Listener already listening");
        }
        this.IIIIllIIllIIIIllIllIIIlIl.add(lIllllIIIIlIllIIllIIlIIll);
        lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lIIIIIIIIIlIllIIllIlIIlIl());
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIllllIIIIlIllIIllIIlIIll lIllllIIIIlIllIIllIIlIIll) {
        this.IIIIllIIllIIIIllIllIIIlIl.remove(lIllllIIIIlIllIIllIIlIIll);
    }
    
    public List lIIIIIIIIIlIllIIllIlIIlIl() {
        final ArrayList<lIlIlIlIlIllllIlllIIIlIlI> list = new ArrayList<lIlIlIlIlIllllIlllIIIlIlI>();
        for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++i) {
            list.add(((IlIIIIIlIIIIlIIIIlIlllIlI)this.IlllIIIlIlllIllIlIIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI());
        }
        return list;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++i) {
            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI.get(i).lIIIIlIIllIIlIIlIIIlIIllI();
            if (!lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl.get(i), liiiIlIIllIIlIIlIIIlIIllI)) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = (liiiIlIIllIIlIIlIIIlIIllI == null) ? null : liiiIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                this.lIIIIIIIIIlIllIIllIlIIlIl.set(i, lIlIlIlIlIllllIlllIIIlIlI);
                for (int j = 0; j < this.IIIIllIIllIIIIllIllIIIlIl.size(); ++j) {
                    ((lIllllIIIIlIllIIllIIlIIll)this.IIIIllIIllIIIIllIllIIIlIl.get(j)).lIIIIlIIllIIlIIlIIIlIIllI(this, i, lIlIlIlIlIllllIlllIIIlIlI);
                }
            }
        }
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n) {
        return false;
    }
    
    public IlIIIIIlIIIIlIIIIlIlllIlI lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final int n) {
        for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++i) {
            final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(i);
            if (ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIIllIllllllllIllIII, n)) {
                return ilIIIIIlIIIIlIIIIlIlllIlI;
            }
        }
        return null;
    }
    
    public IlIIIIIlIIIIlIIIIlIlllIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return this.IlllIIIlIlllIllIlIIlllIlI.get(n);
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n) {
        final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
        return (ilIIIIIlIIIIlIIIIlIlllIlI != null) ? ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI() : null;
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = null;
        final IllIlIIIIIIllIIIIIllIllIl inventory = lIllIIIIlIIlIllIIIlIlIlll.inventory;
        if (n3 == 5) {
            final int iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII;
            this.IIIllIllIlIlllllllIlIlIII = IlllIIIlIlllIllIlIIlllIlI(n2);
            if ((iiIllIllIlIlllllllIlIlIII != 1 || this.IIIllIllIlIlllllllIlIlIII != 2) && iiIllIllIlIlllllllIlIlIII != this.IIIllIllIlIlllllllIlIlIII) {
                this.IIIIllIlIIIllIlllIlllllIl();
            }
            else if (inventory.IllIIIIIIIlIlIllllIIllIII() == null) {
                this.IIIIllIlIIIllIlllIlllllIl();
            }
            else if (this.IIIllIllIlIlllllllIlIlIII == 0) {
                this.IlIlIIIlllIIIlIlllIlIllIl = lIIIIIIIIIlIllIIllIlIIlIl(n2);
                if (IIIIllIlIIIllIlllIlllllIl(this.IlIlIIIlllIIIlIlllIlIllIl)) {
                    this.IIIllIllIlIlllllllIlIlIII = 1;
                    this.IllIIIIIIIlIlIllllIIllIII.clear();
                }
                else {
                    this.IIIIllIlIIIllIlllIlllllIl();
                }
            }
            else if (this.IIIllIllIlIlllllllIlIlIII == 1) {
                final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
                if (ilIIIIIlIIIIlIIIIlIlllIlI != null && lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI, inventory.IllIIIIIIIlIlIllllIIllIII(), true) && ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(inventory.IllIIIIIIIlIlIllllIIllIII()) && inventory.IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl > this.IllIIIIIIIlIlIllllIIllIII.size() && this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI)) {
                    this.IllIIIIIIIlIlIllllIIllIII.add(ilIIIIIlIIIIlIIIIlIlllIlI);
                }
            }
            else if (this.IIIllIllIlIlllllllIlIlIII == 2) {
                if (!this.IllIIIIIIIlIlIllllIIllIII.isEmpty()) {
                    lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = inventory.IllIIIIIIIlIlIllllIIllIII().llIIlllIIIIlllIllIlIlllIl();
                    int liiiiiiiiIlIllIIllIlIIlIl = inventory.IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl;
                    for (final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI2 : this.IllIIIIIIIlIlIllllIIllIII) {
                        if (ilIIIIIlIIIIlIIIIlIlllIlI2 != null && lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI2, inventory.IllIIIIIIIlIlIllllIIllIII(), true) && ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIlIIllIIlIIlIIIlIIllI(inventory.IllIIIIIIIlIlIllllIIllIII()) && inventory.IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl >= this.IllIIIIIIIlIlIllllIIllIII.size() && this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI2)) {
                            final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl2 = llIIlllIIIIlllIllIlIlllIl.llIIlllIIIIlllIllIlIlllIl();
                            final int n4 = ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl() ? ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl : 0;
                            lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, this.IlIlIIIlllIIIlIlllIlIllIl, llIIlllIIIIlllIllIlIlllIl2, n4);
                            if (llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl > llIIlllIIIIlllIllIlIlllIl2.IIIIllIlIIIllIlllIlllllIl()) {
                                llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl = llIIlllIIIIlllIllIlIlllIl2.IIIIllIlIIIllIlllIlllllIl();
                            }
                            if (llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl > ilIIIIIlIIIIlIIIIlIlllIlI2.IIIIllIlIIIllIlllIlllllIl()) {
                                llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIIIlIIIIlIIIIlIlllIlI2.IIIIllIlIIIllIlllIlllllIl();
                            }
                            liiiiiiiiIlIllIIllIlIIlIl -= llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl - n4;
                            ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl(llIIlllIIIIlllIllIlIlllIl2);
                        }
                    }
                    llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                    if (llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
                        llIIlllIIIIlllIllIlIlllIl = null;
                    }
                    inventory.lIIIIIIIIIlIllIIllIlIIlIl(llIIlllIIIIlllIllIlIlllIl);
                }
                this.IIIIllIlIIIllIlllIlllllIl();
            }
            else {
                this.IIIIllIlIIIllIlllIlllllIl();
            }
        }
        else if (this.IIIllIllIlIlllllllIlIlIII != 0) {
            this.IIIIllIlIIIllIlllIlllllIl();
        }
        else if ((n3 == 0 || n3 == 1) && (n2 == 0 || n2 == 1)) {
            if (n == -999) {
                if (inventory.IllIIIIIIIlIlIllllIIllIII() != null && n == -999) {
                    if (n2 == 0) {
                        lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(inventory.IllIIIIIIIlIlIllllIIllIII(), true);
                        inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
                    }
                    if (n2 == 1) {
                        lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(inventory.IllIIIIIIIlIlIllllIIllIII().lIIIIlIIllIIlIIlIIIlIIllI(1), true);
                        if (inventory.IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                            inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
                        }
                    }
                }
            }
            else if (n3 == 1) {
                if (n < 0) {
                    return null;
                }
                final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI3 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
                if (ilIIIIIlIIIIlIIIIlIlllIlI3 != null && ilIIIIIlIIIIlIIIIlIlllIlI3.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll)) {
                    final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, n);
                    if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                        final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI2 = liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
                        lIlIlIlIlIllllIlllIIIlIlI = liiiIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                        if (ilIIIIIlIIIIlIIIIlIlllIlI3.lIIIIlIIllIIlIIlIIIlIIllI() != null && ilIIIIIlIIIIlIIIIlIlllIlI3.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI() == liiiIlIIllIIlIIlIIIlIIllI2) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true, lIllIIIIlIIlIllIIIlIlIlll);
                        }
                    }
                }
            }
            else {
                if (n < 0) {
                    return null;
                }
                final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI4 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
                if (ilIIIIIlIIIIlIIIIlIlllIlI4 != null) {
                    final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI3 = ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI();
                    final lIlIlIlIlIllllIlllIIIlIlI illIIIIIIIlIlIllllIIllIII = inventory.IllIIIIIIIlIlIllllIIllIII();
                    if (liiiIlIIllIIlIIlIIIlIIllI3 != null) {
                        lIlIlIlIlIllllIlllIIIlIlI = liiiIlIIllIIlIIlIIIlIIllI3.llIIlllIIIIlllIllIlIlllIl();
                    }
                    if (liiiIlIIllIIlIIlIIIlIIllI3 == null) {
                        if (illIIIIIIIlIlIllllIIllIII != null && ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(illIIIIIIIlIlIllllIIllIII)) {
                            int iiiIllIlIIIllIlllIlllllIl = (n2 == 0) ? illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl : 1;
                            if (iiiIllIlIIIllIlllIlllllIl > ilIIIIIlIIIIlIIIIlIlllIlI4.IIIIllIlIIIllIlllIlllllIl()) {
                                iiiIllIlIIIllIlllIlllllIl = ilIIIIIlIIIIlIIIIlIlllIlI4.IIIIllIlIIIllIlllIlllllIl();
                            }
                            if (illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl >= iiiIllIlIIIllIlllIlllllIl) {
                                ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIIIIIIlIllIIllIlIIlIl(illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl));
                            }
                            if (illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                                inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
                            }
                        }
                    }
                    else if (ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll)) {
                        if (illIIIIIIIlIlIllllIIllIII == null) {
                            inventory.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI((n2 == 0) ? liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl : ((liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl + 1) / 2)));
                            if (liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                                ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIIIIIIlIllIIllIlIIlIl(null);
                            }
                            ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, inventory.IllIIIIIIIlIlIllllIIllIII());
                        }
                        else if (ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(illIIIIIIIlIlIllllIIllIII)) {
                            if (liiiIlIIllIIlIIlIIIlIIllI3.lIIIIlIIllIIlIIlIIIlIIllI() == illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() && liiiIlIIllIIlIIlIIIlIIllI3.IlllIllIlIIIIlIIlIIllIIIl() == illIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl() && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3, illIIIIIIIlIlIllllIIllIII)) {
                                int n5 = (n2 == 0) ? illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl : 1;
                                if (n5 > ilIIIIIlIIIIlIIIIlIlllIlI4.IIIIllIlIIIllIlllIlllllIl() - liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl) {
                                    n5 = ilIIIIIlIIIIlIIIIlIlllIlI4.IIIIllIlIIIllIlllIlllllIl() - liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl;
                                }
                                if (n5 > illIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl() - liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl) {
                                    n5 = illIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl() - liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl;
                                }
                                illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n5);
                                if (illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                                    inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
                                }
                                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI2 = liiiIlIIllIIlIIlIIIlIIllI3;
                                lIlIlIlIlIllllIlllIIIlIlI2.lIIIIIIIIIlIllIIllIlIIlIl += n5;
                            }
                            else if (illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl <= ilIIIIIlIIIIlIIIIlIlllIlI4.IIIIllIlIIIllIlllIlllllIl()) {
                                ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIIIIIIlIllIIllIlIIlIl(illIIIIIIIlIlIllllIIllIII);
                                inventory.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI3);
                            }
                        }
                        else if (liiiIlIIllIIlIIlIIIlIIllI3.lIIIIlIIllIIlIIlIIIlIIllI() == illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI() && illIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl() > 1 && (!liiiIlIIllIIlIIlIIIlIIllI3.IIIllIllIlIlllllllIlIlIII() || liiiIlIIllIIlIIlIIIlIIllI3.IlllIllIlIIIIlIIlIIllIIIl() == illIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl()) && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3, illIIIIIIIlIlIllllIIllIII)) {
                            final int liiiiiiiiIlIllIIllIlIIlIl2 = liiiIlIIllIIlIIlIIIlIIllI3.lIIIIIIIIIlIllIIllIlIIlIl;
                            if (liiiiiiiiIlIllIIllIlIIlIl2 > 0 && liiiiiiiiIlIllIIllIlIIlIl2 + illIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl <= illIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl()) {
                                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI3 = illIIIIIIIlIlIllllIIllIII;
                                lIlIlIlIlIllllIlllIIIlIlI3.lIIIIIIIIIlIllIIllIlIIlIl += liiiiiiiiIlIllIIllIlIIlIl2;
                                if (ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl2).lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                                    ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIIIIIIlIllIIllIlIIlIl(null);
                                }
                                ilIIIIIlIIIIlIIIIlIlllIlI4.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, inventory.IllIIIIIIIlIlIllllIIllIII());
                            }
                        }
                    }
                    ilIIIIIlIIIIlIIIIlIlllIlI4.IlllIIIlIlllIllIlIIlllIlI();
                }
            }
        }
        else if (n3 == 2 && n2 >= 0 && n2 < 9) {
            final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI5 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
            if (ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll)) {
                final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = inventory.lIIlIlIllIIlIIIlIIIlllIII(n2);
                boolean b = liIlIlIllIIlIIIlIIIlllIII == null || (ilIIIIIlIIIIlIIIIlIlllIlI5.IlIlIIIlllIIIlIlllIlIllIl == inventory && ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII));
                int illlIIIlIlllIllIlIIlllIlI = -1;
                if (!b) {
                    illlIIIlIlllIllIlIIlllIlI = inventory.IlllIIIlIlllIllIlIIlllIlI();
                    b |= (illlIIIlIlllIllIlIIlllIlI > -1);
                }
                if (ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIIIIIIlIllIIllIlIIlIl() && b) {
                    final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI4 = ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI();
                    inventory.lIIIIIIIIIlIllIIllIlIIlIl(n2, liiiIlIIllIIlIIlIIIlIIllI4.llIIlllIIIIlllIllIlIlllIl());
                    if ((ilIIIIIlIIIIlIIIIlIlllIlI5.IlIlIIIlllIIIlIlllIlIllIl != inventory || !ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII)) && liIlIlIllIIlIIIlIIIlllIII != null) {
                        if (illlIIIlIlllIllIlIIlllIlI > -1) {
                            inventory.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII);
                            ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI4.lIIIIIIIIIlIllIIllIlIIlIl);
                            ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIIIIIIlIllIIllIlIIlIl(null);
                            ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, liiiIlIIllIIlIIlIIIlIIllI4);
                        }
                    }
                    else {
                        ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI4.lIIIIIIIIIlIllIIllIlIIlIl);
                        ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIIIIIIlIllIIllIlIIlIl(liIlIlIllIIlIIIlIIIlllIII);
                        ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, liiiIlIIllIIlIIlIIIlIIllI4);
                    }
                }
                else if (!ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIIIIIIlIllIIllIlIIlIl() && liIlIlIllIIlIIIlIIIlllIII != null && ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII)) {
                    inventory.lIIIIIIIIIlIllIIllIlIIlIl(n2, null);
                    ilIIIIIlIIIIlIIIIlIlllIlI5.lIIIIIIIIIlIllIIllIlIIlIl(liIlIlIllIIlIIIlIIIlllIII);
                }
            }
        }
        else if (n3 == 3 && lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl && inventory.IllIIIIIIIlIlIllllIIllIII() == null && n >= 0) {
            final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI6 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
            if (ilIIIIIlIIIIlIIIIlIlllIlI6 != null && ilIIIIIlIIIIlIIIIlIlllIlI6.lIIIIIIIIIlIllIIllIlIIlIl()) {
                final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl3 = ilIIIIIlIIIIlIIIIlIlllIlI6.lIIIIlIIllIIlIIlIIIlIIllI().llIIlllIIIIlllIllIlIlllIl();
                llIIlllIIIIlllIllIlIlllIl3.lIIIIIIIIIlIllIIllIlIIlIl = llIIlllIIIIlllIllIlIlllIl3.IIIIllIlIIIllIlllIlllllIl();
                inventory.lIIIIIIIIIlIllIIllIlIIlIl(llIIlllIIIIlllIllIlIlllIl3);
            }
        }
        else if (n3 == 4 && inventory.IllIIIIIIIlIlIllllIIllIII() == null && n >= 0) {
            final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI7 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
            if (ilIIIIIlIIIIlIIIIlIlllIlI7 != null && ilIIIIIlIIIIlIIIIlIlllIlI7.lIIIIIIIIIlIllIIllIlIIlIl() && ilIIIIIlIIIIlIIIIlIlllIlI7.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll)) {
                final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI5 = ilIIIIIlIIIIlIIIIlIlllIlI7.lIIIIlIIllIIlIIlIIIlIIllI((n2 == 0) ? 1 : ilIIIIIlIIIIlIIIIlIlllIlI7.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl);
                ilIIIIIlIIIIlIIIIlIlllIlI7.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, liiiIlIIllIIlIIlIIIlIIllI5);
                lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI5, true);
            }
        }
        else if (n3 == 6 && n >= 0) {
            final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI8 = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
            final lIlIlIlIlIllllIlllIIIlIlI illIIIIIIIlIlIllllIIllIII2 = inventory.IllIIIIIIIlIlIllllIIllIII();
            if (illIIIIIIIlIlIllllIIllIII2 != null && (ilIIIIIlIIIIlIIIIlIlllIlI8 == null || !ilIIIIIlIIIIlIIIIlIlllIlI8.lIIIIIIIIIlIllIIllIlIIlIl() || !ilIIIIIlIIIIlIIIIlIlllIlI8.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll))) {
                final int n6 = (n2 == 0) ? 0 : (this.IlllIIIlIlllIllIlIIlllIlI.size() - 1);
                final int n7 = (n2 == 0) ? 1 : -1;
                for (int i = 0; i < 2; ++i) {
                    for (int n8 = n6; n8 >= 0 && n8 < this.IlllIIIlIlllIllIlIIlllIlI.size() && illIIIIIIIlIlIllllIIllIII2.lIIIIIIIIIlIllIIllIlIIlIl < illIIIIIIIlIlIllllIIllIII2.IIIIllIlIIIllIlllIlllllIl(); n8 += n7) {
                        final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI9 = this.IlllIIIlIlllIllIlIIlllIlI.get(n8);
                        if (ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIIIIIIlIllIIllIlIIlIl() && lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI9, illIIIIIIIlIlIllllIIllIII2, true) && ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll) && this.lIIIIlIIllIIlIIlIIIlIIllI(illIIIIIIIlIlIllllIIllIII2, ilIIIIIlIIIIlIIIIlIlllIlI9) && (i != 0 || ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl != ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI().IIIIllIlIIIllIlllIlllllIl())) {
                            final int min = Math.min(illIIIIIIIlIlIllllIIllIII2.IIIIllIlIIIllIlllIlllllIl() - illIIIIIIIlIlIllllIIllIII2.lIIIIIIIIIlIllIIllIlIIlIl, ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl);
                            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI6 = ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI(min);
                            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI4 = illIIIIIIIlIlIllllIIllIII2;
                            lIlIlIlIlIllllIlllIIIlIlI4.lIIIIIIIIIlIllIIllIlIIlIl += min;
                            if (liiiIlIIllIIlIIlIIIlIIllI6.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
                                ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIIIIIIlIllIIllIlIIlIl(null);
                            }
                            ilIIIIIlIIIIlIIIIlIlllIlI9.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, liiiIlIIllIIlIIlIIIlIIllI6);
                        }
                    }
                }
            }
            this.IlllIIIlIlllIllIlIIlllIlI();
        }
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI) {
        return true;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final boolean b, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, 1, lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final IllIlIIIIIIllIIIIIllIllIl inventory = lIllIIIIlIIlIllIIIlIlIlll.inventory;
        if (inventory.IllIIIIIIIlIlIllllIIllIII() != null) {
            lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(inventory.IllIIIIIIIlIlIllllIIllIII(), false);
            inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII) {
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n).lIIIIIIIIIlIllIIllIlIIlIl(lIlIlIlIlIllllIlllIIIlIlI);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI[] array) {
        for (int i = 0; i < array.length; ++i) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(i).lIIIIIIIIIlIllIIllIlIIlIl(array[i]);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
    }
    
    public short lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIIIIIIllIIIIIllIllIl illIlIIIIIIllIIIIIllIllIl) {
        return (short)(++this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return !this.lIIIIllIIlIlIllIIIlIllIlI.contains(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final boolean b) {
        if (b) {
            this.lIIIIllIIlIlIllIIIlIllIlI.remove(lIllIIIIlIIlIllIIIlIlIlll);
        }
        else {
            this.lIIIIllIIlIlIllIIIlIllIlI.add(lIllIIIIlIIlIllIIIlIlIlll);
        }
    }
    
    public abstract boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll p0);
    
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2, final boolean b) {
        boolean b2 = false;
        int n3 = n;
        if (b) {
            n3 = n2 - 1;
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.IIIIllIIllIIIIllIllIIIlIl()) {
            while (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl > 0 && ((!b && n3 < n2) || (b && n3 >= n))) {
                final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(n3);
                final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
                if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() && (!lIlIlIlIlIllllIlllIIIlIlI.IIIllIllIlIlllllllIlIlIII() || lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl() == liiiIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl()) && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, liiiIlIIllIIlIIlIIIlIIllI)) {
                    final int liiiiiiiiIlIllIIllIlIIlIl = liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl + lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
                    if (liiiiiiiiIlIllIIllIlIIlIl <= lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl()) {
                        lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = 0;
                        liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                        ilIIIIIlIIIIlIIIIlIlllIlI.IlllIIIlIlllIllIlIIlllIlI();
                        b2 = true;
                    }
                    else if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl < lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl()) {
                        lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl -= lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl() - liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl;
                        liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl = lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl();
                        ilIIIIIlIIIIlIIIIlIlllIlI.IlllIIIlIlllIllIlIIlllIlI();
                        b2 = true;
                    }
                }
                if (b) {
                    --n3;
                }
                else {
                    ++n3;
                }
            }
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl > 0) {
            int n4;
            if (b) {
                n4 = n2 - 1;
            }
            else {
                n4 = n;
            }
            while ((!b && n4 < n2) || (b && n4 >= n)) {
                final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI2 = this.IlllIIIlIlllIllIlIIlllIlI.get(n4);
                if (ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIlIIllIIlIIlIIIlIIllI() == null) {
                    ilIIIIIlIIIIlIIIIlIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl(lIlIlIlIlIllllIlllIIIlIlI.llIIlllIIIIlllIllIlIlllIl());
                    ilIIIIIlIIIIlIIIIlIlllIlI2.IlllIIIlIlllIllIlIIlllIlI();
                    lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = 0;
                    b2 = true;
                    break;
                }
                if (b) {
                    --n4;
                }
                else {
                    ++n4;
                }
            }
        }
        return b2;
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return n >> 2 & 0x3;
    }
    
    public static int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return n & 0x3;
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return (n & 0x3) | (n2 & 0x3) << 2;
    }
    
    public static boolean IIIIllIlIIIllIlllIlllllIl(final int n) {
        return n == 0 || n == 1;
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl() {
        this.IIIllIllIlIlllllllIlIlIII = 0;
        this.IllIIIIIIIlIlIllllIIllIII.clear();
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final boolean b) {
        boolean b2 = ilIIIIIlIIIIlIIIIlIlllIlI == null || !ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        if (ilIIIIIlIIIIlIIIIlIlllIlI != null && ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl() && lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI()) && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(), lIlIlIlIlIllllIlllIIIlIlI)) {
            b2 |= (ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl + (b ? 0 : lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl) <= lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl());
        }
        return b2;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final Set set, final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n2) {
        switch (n) {
            case 0: {
                lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = MathHelper.IIIIllIlIIIllIlllIlllllIl(lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl / (float)set.size());
                break;
            }
            case 1: {
                lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = 1;
                break;
            }
        }
        lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl += n2;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI) {
        return true;
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII) {
        if (ilIIlIIllIllllllllIllIII == null) {
            return 0;
        }
        int n = 0;
        float n2 = 0.0f;
        for (int i = 0; i < ilIIlIIllIllllllllIllIII.IIIIllIIllIIIIllIllIIIlIl(); ++i) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIIlIIllIllllllllIllIII.lIIlIlIllIIlIIIlIIIlllIII(i);
            if (liIlIlIllIIlIIIlIIIlllIII != null) {
                n2 += liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl / (float)Math.min(ilIIlIIllIllllllllIllIII.IllIlIIIIlllIIllIIlllIIlI(), liIlIlIllIIlIIIlIIIlllIII.IIIIllIlIIIllIlllIlllllIl());
                ++n;
            }
        }
        return MathHelper.IIIIllIlIIIllIlllIlllllIl(n2 / ilIIlIIllIllllllllIllIII.IIIIllIIllIIIIllIllIIIlIl() * 14) + ((n > 0) ? 1 : 0);
    }
}
