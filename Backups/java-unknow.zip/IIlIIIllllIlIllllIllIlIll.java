// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIllllIlIllllIllIlIll
{
    private final int lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private Object IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIIIllllIlIllllIllIlIll(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final Object illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IIIIllIlIIIllIlllIlllllIl = true;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Object illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public Object lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
}
