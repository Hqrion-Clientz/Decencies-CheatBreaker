import java.util.Iterator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIIIIllIlIlIlIIIIIl extends llIIIIIIlllIlIIlllIIIlIII
{
    private lIlIlIlIlIllllIlllIIIlIlI IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIlIIIIIllIlIlIlIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIlIIlIIIIIllIlIlIlIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final EntityLivingBase entityLivingBase, final int n) {
        this(iiiiiIllIlIIIIlIlllIllllI, entityLivingBase, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII, 1, n));
    }
    
    public IIlIIlIIIIIllIlIlIlIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final EntityLivingBase entityLivingBase, final lIlIlIlIlIllllIlllIIIlIlI illlIIIlIlllIllIlIIlllIlI) {
        super(iiiiiIllIlIIIIlIlllIllllI, entityLivingBase);
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public IIlIIlIIIIIllIlIlIlIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final int n4) {
        this(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII, 1, n4));
    }
    
    public IIlIIlIIIIIllIlIlIlIIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final lIlIlIlIlIllllIlllIIIlIlI illlIIIlIlllIllIlIIlllIlI) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    protected float IlllIIIlIlllIllIlIIlllIlI() {
        return 42.0f * 0.0011904762f;
    }
    
    @Override
    protected float IIIIllIlIIIllIlllIlllllIl() {
        return 1.8125f * 0.27586207f;
    }
    
    @Override
    protected float IIIIllIIllIIIIllIllIIIlIl() {
        return -20;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII, 1, 0);
        }
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl() {
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII, 1, 0);
        }
        return this.IlllIIIlIlllIllIlIIlllIlI.IlllIllIlIIIIlIIlIIllIIIl();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final MovingObjectPosition movingObjectPosition) {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final List liIlIlIllIIlIIIlIIIlllIII = IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII.lIIlIlIllIIlIIIlIIIlllIII(this.IlllIIIlIlllIllIlIIlllIlI);
            if (liIlIlIllIIlIIIlIIIlllIII != null && !liIlIlIllIIlIIIlIIIlllIII.isEmpty()) {
                final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(EntityLivingBase.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(4, 2, 4));
                if (liiiIlIIllIIlIIlIIIlIIllI != null && !liiiIlIIllIIlIIlIIIlIIllI.isEmpty()) {
                    for (final EntityLivingBase entityLivingBase : liiiIlIIllIIlIIlIIIlIIllI) {
                        final double iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(entityLivingBase);
                        if (iiiIllIIllIIIIllIllIIIlIl < 16) {
                            double n = 1.0 - Math.sqrt(iiiIllIIllIIIIllIllIIIlIl) / 4;
                            if (entityLivingBase == movingObjectPosition.IIIllIllIlIlllllllIlIlIII) {
                                n = 1.0;
                            }
                            for (final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl : liIlIlIllIIlIIIlIIIlllIII) {
                                final int liiiIlIIllIIlIIlIIIlIIllI2 = llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
                                if (IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2].lIIIIIIIIIlIllIIllIlIIlIl()) {
                                    IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2].lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII(), entityLivingBase, llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI(), n);
                                }
                                else {
                                    final int n2 = (int)(n * llIlIlIIlIlIllllIIlIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl() + 0.7777777910232544 * 0.6428571319093511);
                                    if (n2 <= 20) {
                                        continue;
                                    }
                                    entityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI(new llIlIlIIlIlIllllIIlIIIlIl(liiiIlIIllIIlIIlIIIlIIllI2, n2, llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI()));
                                }
                            }
                        }
                    }
                }
            }
            this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(2002, (int)Math.round(this.IIIlIIlIlIIIlllIIlIllllll), (int)Math.round(this.IllIlIIIIlllIIllIIlllIIlI), (int)Math.round(this.IllIlIlIllllIlIIllllIIlll), this.IlIlIIIlllIIIlIlllIlIllIl());
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Potion", 10)) {
            this.IlllIIIlIlllIllIlIIlllIlI = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("Potion"));
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("potionValue"));
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Potion", this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIllIIlIIlllIllllIIIIl()));
        }
    }
}
