import org.json.JSONObject;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIllIllIIllIlllIIllIIIII
{
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final llIlIIlIIIIIlIlIIlIlllIIl llIlIIlIIIIIlIlIIlIlllIIl) {
    }
    
    default void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final llIlIIlIIIIIlIlIIlIlllIIl llIlIIlIIIIIlIlIIlIlllIIl) {
    }
    
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final String s) {
    }
    
    default void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final String s) {
    }
    
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final String s, final llIlllIIlIllllllIIllIllII llIlllIIlIllllllIIllIllII) {
    }
    
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl) {
    }
    
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final JSONObject jsonObject) {
    }
    
    default void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final Throwable t) {
    }
}
