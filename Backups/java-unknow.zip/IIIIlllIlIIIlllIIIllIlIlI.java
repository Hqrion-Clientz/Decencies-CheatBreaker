// 
// Decompiled by Procyon v0.5.36
// 

final class IIIIlllIlIIIlllIIIllIlIlI
{
    static final int[] lIIIIlIIllIIlIIlIIIlIIllI;
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new int[IIIIllIIIIIlIlIlllIIllIll.values().length];
        try {
            IIIIlllIlIIIlllIIIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI[IIIIllIIIIIlIlIlllIIllIll.lIIIIlIIllIIlIIlIIIlIIllI.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            IIIIlllIlIIIlllIIIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI[IIIIllIIIIIlIlIlllIIllIll.lIIIIIIIIIlIllIIllIlIIlIl.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            IIIIlllIlIIIlllIIIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI[IIIIllIIIIIlIlIlllIIllIll.IlllIIIlIlllIllIlIIlllIlI.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
    }
}
