import java.util.Iterator;
import java.nio.IntBuffer;
import java.util.List;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.opengl.GL11;
import java.util.function.Consumer;
import org.lwjgl.BufferUtils;
import java.util.Map;
import java.nio.FloatBuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIllIIllIllIlIIIllII extends lIllIlIlIIlIllIllllIllIIl
{
    public FloatBuffer lIIIIlIIllIIlIIlIIIlIIllI;
    public FloatBuffer lIIIIIIIIIlIllIIllIlIIlIl;
    private static Map IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlllIllIIllIllIlIIIllII(final String s) {
        super(s);
        this.lIIIIlIIllIIlIIlIIIlIIllI = BufferUtils.createFloatBuffer(16);
        this.lIIIIIIIIIlIllIIllIlIIlIl = BufferUtils.createFloatBuffer(16);
        this.IlllIIIlIlllIllIlIIlllIlI(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIllIlIIllIllIlIlIIlIl.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIllIlIIllIllIlIlIIlIl lIllIllIlIIllIllIlIlIIlIl) {
        final Minecraft minecraft = Minecraft.getMinecraft();
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(16);
        GL11.glGetInteger(2978, intBuffer);
        final float renderPartialTicks = minecraft.lIIIIlIIllIIlIIlIIIlIIllI().renderPartialTicks;
        final float n = (float)(minecraft.thePlayer.lIlIlIIIlIIllllllllIIlllI + (minecraft.thePlayer.IIIlIIlIlIIIlllIIlIllllll - minecraft.thePlayer.lIlIlIIIlIIllllllllIIlllI) * renderPartialTicks);
        final float n2 = (float)(minecraft.thePlayer.IlIlllIllIlIllIlllIlllIll + (minecraft.thePlayer.IllIlIIIIlllIIllIIlllIIlI - minecraft.thePlayer.IlIlllIllIlIllIlllIlllIll) * renderPartialTicks);
        final float n3 = (float)(minecraft.thePlayer.llIIIllIIllllIlIlIlIlIIll + (minecraft.thePlayer.IllIlIlIllllIlIIllllIIlll - minecraft.thePlayer.llIIIllIIllllIlIlIlIlIIll) * renderPartialTicks);
        final double a = (minecraft.thePlayer.IllIIlllIllIlIllIlIIIIIII + 90) * (2.0638298988342285 * 1.5222149147874773) / 180;
        final double n4 = (minecraft.thePlayer.IllllIllllIlIIIlIIIllllll + 90) * (3.0676728737717527 * 1.0240963697433472) / 180;
        final boolean b = IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI != null;
        lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII = new lIllIIIIlllllIIlIllIIIIII(Math.sin(a) * Math.cos(n4), Math.cos(a), Math.sin(a) * Math.sin(n4));
        if (minecraft.gameSettings.thirdPersonView == 2) {
            lIllIIIIlllllIIlIllIIIIII = new lIllIIIIlllllIIlIllIIIIII(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI * -1, lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl * -1, lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI * -1);
        }
        for (int i = 0; i < minecraft.theWorld.lIIIIIllllIIIIlIlIIIIlIlI().size(); ++i) {
            final Entity entity = minecraft.theWorld.lIIIIIllllIIIIlIlIIIIlIlI().get(i);
            if (entity != null && entity != minecraft.thePlayer) {
                if (entity instanceof IIlllIIIIIIlllIllIlIlIlII) {
                    final EntityClientPlayerMP entityClientPlayerMP = (EntityClientPlayerMP)entity;
                    final IlIIIIllIlIlIIIlIIIllIIlI llIlllIIllIlllIlIlIlIIIll = entityClientPlayerMP.llIlllIIllIlllIlIlIlIIIll();
                    final IIlIlIlIlIllIlIllIIllIIII liiiIlIIllIIlIIlIIIlIIllI = llIlllIIllIlllIlIlIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI(2);
                    float n5 = 0.0f;
                    if (entityClientPlayerMP.IIIIllIIllIIIIllIllIIIlIl(minecraft.thePlayer) < 100 && liiiIlIIllIIlIIlIIIlIIllI != null) {
                        n5 += minecraft.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI * (0.7051282f * 0.05318182f);
                    }
                    float n6 = (float)(entityClientPlayerMP.lIlIlIIIlIIllllllllIIlllI + (entityClientPlayerMP.IIIlIIlIlIIIlllIIlIllllll - entityClientPlayerMP.lIlIlIIIlIIllllllllIIlllI) * renderPartialTicks - n);
                    float n7 = (float)(entityClientPlayerMP.IlIlllIllIlIllIlllIlllIll + (entityClientPlayerMP.IllIlIIIIlllIIllIIlllIIlI - entityClientPlayerMP.IlIlllIllIlIllIlllIlllIll) * renderPartialTicks - n2) + entityClientPlayerMP.llllIIIIlIlIllIIIllllIIll + (entityClientPlayerMP.lIlIlIllIIIIIIIIllllIIllI() ? (0.041666668f * 7.2f) : (1.9380952f * 0.2837838f)) + n5;
                    float n8 = (float)(entityClientPlayerMP.llIIIllIIllllIlIlIlIlIIll + (entityClientPlayerMP.IllIlIlIllllIlIIllllIIlll - entityClientPlayerMP.llIIIllIIllllIlIlIlIlIIll) * renderPartialTicks - n3);
                    final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2 = new lIllIIIIlllllIIlIllIIIIII(n6, n7, n8);
                    final double liiiiiiiiIlIllIIllIlIIlIl = lIllIIIIlllllIIlIllIIIIII2.lIIIIIIIIIlIllIIllIlIIlIl();
                    final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI();
                    if (lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2) <= 1.476190447807312 * 0.013548387357273166) {
                        final double sin = Math.sin(0.8478260636329651 * 1.8321482446751198);
                        final double cos = Math.cos(0.42557342292852307 * 3.6500000953674316);
                        final lIllIIIIlllllIIlIllIIIIII illlIIIlIlllIllIlIIlllIlI = lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI2);
                        final double liiiIlIIllIIlIIlIIIlIIllI3 = illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI;
                        final double liiiiiiiiIlIllIIllIlIIlIl2 = illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl;
                        final double illlIIIlIlllIllIlIIlllIlI2 = illlIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI;
                        final double n9 = cos + liiiIlIIllIIlIIlIIIlIIllI3 * liiiIlIIllIIlIIlIIIlIIllI3 * (1.0 - cos);
                        final double n10 = liiiIlIIllIIlIIlIIIlIIllI3 * liiiiiiiiIlIllIIllIlIIlIl2 * (1.0 - cos) - illlIIIlIlllIllIlIIlllIlI2 * sin;
                        final double n11 = liiiIlIIllIIlIIlIIIlIIllI3 * illlIIIlIlllIllIlIIlllIlI2 * (1.0 - cos) + liiiiiiiiIlIllIIllIlIIlIl2 * sin;
                        final double n12 = liiiiiiiiIlIllIIllIlIIlIl2 * liiiIlIIllIIlIIlIIIlIIllI3 * (1.0 - cos) + illlIIIlIlllIllIlIIlllIlI2 * sin;
                        final double n13 = cos + liiiiiiiiIlIllIIllIlIIlIl2 * liiiiiiiiIlIllIIllIlIIlIl2 * (1.0 - cos);
                        final double n14 = liiiiiiiiIlIllIIllIlIIlIl2 * illlIIIlIlllIllIlIIlllIlI2 * (1.0 - cos) - liiiIlIIllIIlIIlIIIlIIllI3 * sin;
                        final double n15 = illlIIIlIlllIllIlIIlllIlI2 * liiiIlIIllIIlIIlIIIlIIllI3 * (1.0 - cos) - liiiiiiiiIlIllIIllIlIIlIl2 * sin;
                        final double n16 = illlIIIlIlllIllIlIIlllIlI2 * liiiiiiiiIlIllIIllIlIIlIl2 * (1.0 - cos) + liiiIlIIllIIlIIlIIIlIIllI3 * sin;
                        final double n17 = cos + illlIIIlIlllIllIlIIlllIlI2 * illlIIIlIlllIllIlIIlllIlI2 * (1.0 - cos);
                        n6 = (float)(liiiiiiiiIlIllIIllIlIIlIl * (n9 * lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI + n10 * lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl + n11 * lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI));
                        n7 = (float)(liiiiiiiiIlIllIIllIlIIlIl * (n12 * lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI + n13 * lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl + n14 * lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI));
                        n8 = (float)(liiiiiiiiIlIllIIllIlIIlIl * (n15 * lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI + n16 * lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl + n17 * lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI));
                    }
                    final FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(3);
                    GLU.gluProject(n6, n7, n8, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, intBuffer, floatBuffer);
                    final float n18 = floatBuffer.get(0) / lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().getScaleFactor();
                    final float n19 = floatBuffer.get(1) / lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().getScaleFactor();
                    GL11.glPushMatrix();
                    GL11.glTranslatef(n18, lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().getScaledHeight() - n19, 0.0f);
                    final float health = entityClientPlayerMP.getHealth();
                    String str = entityClientPlayerMP.IlIlIIIlllllIIIlIlIlIllII() + ((health != 1.0) ? (" | " + this.IlllIIIlIlllIllIlIIlllIlI(health) + health) : "");
                    if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                        final lIlIlIIllIIIlIlllllIlIIlI liiiIlIIllIIlIIlIIIlIIllI4 = llIlllIIllIlllIlIlIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI(entityClientPlayerMP.IlIlIIIlllllIIIlIlIlIllII(), liiiIlIIllIIlIIlIIIlIIllI);
                        str = str + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + " | " + this.IlllIIIlIlllIllIlIIlllIlI((float)liiiIlIIllIIlIIlIIIlIIllI4.lIIIIIIIIIlIllIIllIlIIlIl()) + liiiIlIIllIIlIIlIIIlIIllI4.lIIIIIIIIIlIllIIllIlIIlIl();
                    }
                    final float n20 = (float)minecraft.fontRendererObj.getStringWidth(IlIllllIIlIIllIlIlllllIlI.lIIIIlIIllIIlIIlIIIlIIllI(str));
                    minecraft.fontRendererObj.drawStringWithShadow(str, (float)((int)(-n20) / 2), (float)(-minecraft.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI), -1);
                    if (b && IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI.containsKey(entityClientPlayerMP.llllIIllllllIlIIlIlIIIllI().getId().toString())) {
                        final List<String> list = IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI.get(entityClientPlayerMP.llllIIllllllIlIIlIlIIIllI().getId().toString());
                        int n21 = 1;
                        for (final String s : list) {
                            ++n21;
                            minecraft.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(s, (int)(-n20) / 2, -minecraft.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI * n21, -1);
                        }
                    }
                    GL11.glPopMatrix();
                }
            }
        }
    }
    
    private IlIllllIIlIIllIlIlllllIlI IlllIIIlIlllIllIlIIlllIlI(final float n) {
        IlIllllIIlIIllIlIlllllIlI ilIllllIIlIIllIlIlllllIlI;
        if (n > 15) {
            ilIllllIIlIIllIlIlllllIlI = IlIllllIIlIIllIlIlllllIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        else if (n > 10) {
            ilIllllIIlIIllIlIlllllIlI = IlIllllIIlIIllIlIlllllIlI.llIlIIIlIIIIlIlllIlIIIIll;
        }
        else if (n > 5) {
            ilIllllIIlIIllIlIlllllIlI = IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII;
        }
        else {
            ilIllllIIlIIllIlIlllllIlI = IlIllllIIlIIllIlIlllllIlI.IIIIllIIllIIIIllIllIIIlIl;
        }
        return ilIllllIIlIIllIlIlllllIlI;
    }
    
    public static Map lIllIllIlIIllIllIlIlIIlIl() {
        return IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final Map illlIIIlIlllIllIlIIlllIlI) {
        IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    static {
        IIIlllIllIIllIllIlIIIllII.IlllIIIlIlllIllIlIIlllIlI = null;
    }
}
