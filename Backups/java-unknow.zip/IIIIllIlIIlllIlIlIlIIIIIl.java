// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIlIIlllIlIlIlIIIIIl extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private byte lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIllIlIIlllIlIlIlIIIIIl() {
    }
    
    public IIIIllIlIIlllIlIlIlIIIIIl(final Entity entity, final byte liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = entity.lIIIIlllIIlIlllllIlIllIII();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readByte();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public Entity lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public byte IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
