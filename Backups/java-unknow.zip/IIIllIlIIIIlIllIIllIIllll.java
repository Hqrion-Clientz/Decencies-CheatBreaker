// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIlIIIIlIllIIllIIllll extends lllllIlIIllIIlIIlIIIllIIl
{
    public lIIIIllllIlIIIIllIllIIlIl IIIllIllIlIlllllllIlIlIII;
    public lIIIIllllIlIIIIllIllIIlIl IllIIIIIIIlIlIllllIIllIII;
    public lIIIIllllIlIIIIllIllIIlIl lIIIIllIIlIlIllIIIlIllIlI;
    public lIIIIllllIlIIIIllIllIIlIl IlllIllIlIIIIlIIlIIllIIIl;
    public lIIIIllllIlIIIIllIllIIlIl IlIlllIIIIllIllllIllIIlIl;
    public lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl;
    public lIIIIllllIlIIIIllIllIIlIl lIIlIlIllIIlIIIlIIIlllIII;
    
    public IIIllIlIIIIlIllIIllIIllll() {
        this(0.0f);
    }
    
    public IIIllIlIIIIlIllIIllIIllll(final float n) {
        final int n2 = 4;
        (this.IIIllIllIlIlllllllIlIlIII = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 0)).lIIIIlIIllIIlIIlIIIlIIllI(-4, -8, -4, 8, 8, 8, n);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n2, 0.0f);
        (this.IllIIIIIIIlIlIllllIIllIII = new lIIIIllllIlIIIIllIllIIlIl(this, 32, 0)).lIIIIlIIllIIlIIlIIIlIIllI(-4, -8, -4, 8, 8, 8, n + 0.15789473f * 3.1666667f);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n2, 0.0f);
        (this.lIIIIllIIlIlIllIIIlIllIlI = new lIIIIllllIlIIIIllIllIIlIl(this, 16, 16)).lIIIIlIIllIIlIIlIIIlIIllI(-4, 0.0f, -2, 8, 12, 4, n);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n2, 0.0f);
        (this.IlllIllIlIIIIlIIlIIllIIIl = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 16)).lIIIIlIIllIIlIIlIIIlIIllI(-2, 0.0f, -2, 4, 6, 4, n);
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(-2, (float)(12 + n2), 4);
        (this.IlIlllIIIIllIllllIllIIlIl = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 16)).lIIIIlIIllIIlIIlIIIlIIllI(-2, 0.0f, -2, 4, 6, 4, n);
        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(2.0f, (float)(12 + n2), 4);
        (this.llIIlllIIIIlllIllIlIlllIl = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 16)).lIIIIlIIllIIlIIlIIIlIIllI(-2, 0.0f, -2, 4, 6, 4, n);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(-2, (float)(12 + n2), -4);
        (this.lIIlIlIllIIlIIIlIIIlllIII = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 16)).lIIIIlIIllIIlIIlIIIlIIllI(-2, 0.0f, -2, 4, 6, 4, n);
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(2.0f, (float)(12 + n2), -4);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, n6, entity);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Entity entity) {
        this.IIIllIllIlIlllllllIlIlIII.IIIllIllIlIlllllllIlIlIII = n4 / (53.1034f * 1.0789474f);
        this.IIIllIllIlIlllllllIlIlIII.IlIlIIIlllIIIlIlllIlIllIl = n5 / (0.3298969f * 173.67783f);
        this.IlllIllIlIIIIlIIlIIllIIIl.IlIlIIIlllIIIlIlllIlIllIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n * (4.6666665f * 0.14275715f)) * (0.5205479f * 2.6894736f) * n2;
        this.IlIlllIIIIllIllllIllIIlIl.IlIlIIIlllIIIlIlllIlIllIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n * (0.54068404f * 1.2321428f) + 1.6028534f * 1.96f) * (0.027777778f * 50.399998f) * n2;
        this.llIIlllIIIIlllIllIlIlllIl.IlIlIIIlllIIIlIlllIlIllIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n * (0.20356111f * 3.2727273f) + 16.5f * 0.19039956f) * (1.6857142f * 0.8305085f) * n2;
        this.lIIlIlIllIIlIIIlIIIlllIII.IlIlIIIlllIIIlIlllIlIllIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n * (0.39834636f * 1.6724138f)) * (0.79545456f * 1.76f) * n2;
    }
}
