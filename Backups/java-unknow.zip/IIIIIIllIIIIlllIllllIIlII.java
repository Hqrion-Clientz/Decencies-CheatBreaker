import org.apache.logging.log4j.LogManager;
import java.util.Iterator;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.EventLoopGroup;
import io.netty.bootstrap.Bootstrap;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetAddress;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.Logger;
import com.google.common.base.Splitter;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIIIIlllIllllIIlII
{
    private static final Splitter lIIIIlIIllIIlIIlIIIlIIllI;
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    private final List IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIIIllIIIIlllIllllIIlII() {
        this.IlllIIIlIlllIllIlIIlllIlI = Collections.synchronizedList(new ArrayList<Object>());
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final ServerData serverData) {
        final lllIIIllIlIIlIlIIlllIIIII liiiIlIIllIIlIIlIIIlIIllI = lllIIIllIlIIlIlIIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(serverData.lIIIIIIIIIlIllIIllIlIIlIl);
        final NetworkManager liiiIlIIllIIlIIlIIIlIIllI2 = NetworkManager.lIIIIlIIllIIlIIlIIIlIIllI(InetAddress.getByName(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI()), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
        this.IlllIIIlIlllIllIlIIlllIlI.add(liiiIlIIllIIlIIlIIIlIIllI2);
        serverData.IlIlIIIlllIIIlIlllIlIllIl = "Pinging...";
        serverData.IIIllIllIlIlllllllIlIlIII = -1L;
        serverData.IlIlllIIIIllIllllIllIIlIl = null;
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new IllIllIIllllIlIIllllIIlll(this, serverData, liiiIlIIllIIlIIlIIIlIIllI2));
        try {
            liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new lllllIlIIIlIlIllIlIIlIIIl((serverData.IllIIIIIIIlIlIllllIIllIII == -1332) ? -1332 : 5, liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(), EnumConnectionState.IlllIIIlIlllIllIlIIlllIlI), new GenericFutureListener[0]);
            liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new lIIIIIllIlIlIIIIIIIIlllII(), new GenericFutureListener[0]);
        }
        catch (Throwable t) {
            IIIIIIllIIIIlllIllllIIlII.lIIIIIIIIIlIllIIllIlIIlIl.error((Object)t);
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final ServerData serverData) {
        final lllIIIllIlIIlIlIIlllIIIII liiiIlIIllIIlIIlIIIlIIllI = lllIIIllIlIIlIlIIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(serverData.lIIIIIIIIIlIllIIllIlIIlIl);
        ((Bootstrap)((Bootstrap)((Bootstrap)new Bootstrap().group((EventLoopGroup)NetworkManager.IIIllIllIlIlllllllIlIlIII)).handler((ChannelHandler)new IllllIIIIllIllIlllIllIIll(this, liiiIlIIllIIlIIlIIIlIIllI, serverData))).channel((Class)NioSocketChannel.class)).connect(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        final List illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        synchronized (this.IlllIIIlIlllIllIlIIlllIlI) {
            final Iterator<NetworkManager> iterator = (Iterator<NetworkManager>)this.IlllIIIlIlllIllIlIIlllIlI.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkManager = iterator.next();
                if (networkManager.IIIIllIlIIIllIlllIlllllIl()) {
                    networkManager.lIIIIlIIllIIlIIlIIIlIIllI();
                }
                else {
                    iterator.remove();
                    if (networkManager.IlIlIIIlllIIIlIlllIlIllIl() == null) {
                        continue;
                    }
                    networkManager.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(networkManager.IlIlIIIlllIIIlIlllIlIllIl());
                }
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        final List illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        synchronized (this.IlllIIIlIlllIllIlIIlllIlI) {
            final Iterator<NetworkManager> iterator = (Iterator<NetworkManager>)this.IlllIIIlIlllIllIlIIlllIlI.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkManager = iterator.next();
                if (networkManager.IIIIllIlIIIllIlllIlllllIl()) {
                    iterator.remove();
                    networkManager.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI("Cancelled"));
                }
            }
        }
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = Splitter.on('\0').limit(6);
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
    }
}
