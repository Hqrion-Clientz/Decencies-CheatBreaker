// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllIllllIllIlIllllllI extends lIIlIIIIlIIIIIllIIIIlIIll
{
    private IIllIlIlllIlIlIIIllIllIll lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIllIllllIllIlIllllllI(final IIllIlIlllIlIlIIIllIllIll liiiIlIIllIIlIIlIIIlIIllI, final int n, final int n2, final int n3, final String s) {
        super(n, n2, n3, s);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIIlIllIllllIllIlIllllllI(final IIllIlIlllIlIlIIIllIllIll liiiIlIIllIIlIIlIIIlIIllI, final int n, final int n2, final int n3, final String s, final int n4, final int n5) {
        super(n, n2, n3, n4, n5, s);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return super.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII() {
        return super.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean illlIllIlIIIIlIIlIIllIIIl) {
        super.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
    }
    
    public void setSection(final String illIIIIIIIlIlIllllIIllIII) {
        super.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return super.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    public int IllIIIIIIIlIlIllllIIllIII() {
        return super.IIIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final Minecraft minecraft, final int n, final int n2) {
        if (super.IlllIIIlIlllIllIlIIlllIlI(minecraft, n, n2)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
        }
        return super.IlllIIIlIlllIllIlIIlllIlI(minecraft, n, n2);
    }
    
    @Override
    public void resize(final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(n, n2);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Minecraft minecraft, final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(n, n2);
    }
    
    public IIllIlIlllIlIlIIIllIllIll lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(b);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final boolean b) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(b);
    }
}
