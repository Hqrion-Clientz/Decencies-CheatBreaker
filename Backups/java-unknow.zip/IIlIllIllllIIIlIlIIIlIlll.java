import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIllllIIIlIlIIIlIlll extends IIllIlIIlllIlIIlIllllllll
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIllIllllIIIlIlIIIlIlll(final int liiiIlIIllIIlIIlIIIlIIllI) {
        super(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI = -1;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIlIllIllllIIIlIlIIIlIlll() {
        super(false);
        this.lIIIIlIIllIIlIIlIIIlIIllI = -1;
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        int n4 = random.nextInt(2);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI >= 0) {
            n4 = this.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        final int n5 = random.nextInt(3) + 4;
        int n6 = 1;
        if (n2 < 1 || n2 + n5 + 1 >= 256) {
            return false;
        }
        for (int i = n2; i <= n2 + 1 + n5; ++i) {
            int n7 = 3;
            if (i <= n2 + 3) {
                n7 = 0;
            }
            for (int n8 = n - n7; n8 <= n + n7 && n6 != 0; ++n8) {
                for (int n9 = n3 - n7; n9 <= n3 + n7 && n6 != 0; ++n9) {
                    if (i >= 0 && i < 256) {
                        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n8, i, n9);
                        if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air && block.IlIlIIIlllIIIlIlllIlIllIl() != Material.IlllIllIlIIIIlIIlIIllIIIl) {
                            n6 = 0;
                        }
                    }
                    else {
                        n6 = 0;
                    }
                }
            }
        }
        if (n6 == 0) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3);
        if (block2 != IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl && block2 != IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI && block2 != IllllllIllIIlllIllIIlIIll.IIllllllIlIIIIlllIlIlIlll) {
            return false;
        }
        int n10 = n2 + n5;
        if (n4 == 1) {
            n10 = n2 + n5 - 3;
        }
        for (int j = n10; j <= n2 + n5; ++j) {
            int n11 = 1;
            if (j < n2 + n5) {
                ++n11;
            }
            if (n4 == 0) {
                n11 = 3;
            }
            for (int k = n - n11; k <= n + n11; ++k) {
                for (int l = n3 - n11; l <= n3 + n11; ++l) {
                    int n12 = 5;
                    if (k == n - n11) {
                        --n12;
                    }
                    if (k == n + n11) {
                        ++n12;
                    }
                    if (l == n3 - n11) {
                        n12 -= 3;
                    }
                    if (l == n3 + n11) {
                        n12 += 3;
                    }
                    if (n4 == 0 || j < n2 + n5) {
                        if (k == n - n11 || k == n + n11) {
                            if (l == n3 - n11) {
                                continue;
                            }
                            if (l == n3 + n11) {
                                continue;
                            }
                        }
                        if (k == n - (n11 - 1) && l == n3 - n11) {
                            n12 = 1;
                        }
                        if (k == n - n11 && l == n3 - (n11 - 1)) {
                            n12 = 1;
                        }
                        if (k == n + (n11 - 1) && l == n3 - n11) {
                            n12 = 3;
                        }
                        if (k == n + n11 && l == n3 - (n11 - 1)) {
                            n12 = 3;
                        }
                        if (k == n - (n11 - 1) && l == n3 + n11) {
                            n12 = 7;
                        }
                        if (k == n - n11 && l == n3 + (n11 - 1)) {
                            n12 = 7;
                        }
                        if (k == n + (n11 - 1) && l == n3 + n11) {
                            n12 = 9;
                        }
                        if (k == n + n11 && l == n3 + (n11 - 1)) {
                            n12 = 9;
                        }
                    }
                    if (n12 == 5 && j < n2 + n5) {
                        n12 = 0;
                    }
                    if ((n12 != 0 || n2 >= n2 + n5 - 1) && !iiiiiIllIlIIIIlIlllIllllI.getBlock(k, j, l).lIIIIlIIllIIlIIlIIIlIIllI()) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, k, j, l, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIlIIlIIIIIllIIlIlIlIII) + n4), n12);
                    }
                }
            }
        }
        for (int n13 = 0; n13 < n5; ++n13) {
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + n13, n3).lIIIIlIIllIIlIIlIIIlIIllI()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 + n13, n3, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIlIIlIIIIIllIIlIlIlIII) + n4), 10);
            }
        }
        return true;
    }
}
