// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIllIlllIlIlIllllIIII extends IlllIlllllIIIllIIlllIIIlI
{
    private IlllIllIIIIlllIllIIIIIlII[] lIIIIlllIIlIlllllIlIllIII;
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, int n2) {
        if (n2 < 7) {
            if (n2 == 6) {
                n2 = 5;
            }
            return this.lIIIIlllIIlIlllllIlIllIII[n2 >> 1];
        }
        return this.lIIIIlllIIlIlllllIlIllIII[3];
    }
    
    @Override
    protected lIIlllIIIlIllllllIlIlIIII IIIIlIIIlllllllllIlllIlll() {
        return IIlIlIllIlIIllIllIllIIIll.IlllIlIlllIlIlllIIlllIlIl;
    }
    
    @Override
    protected lIIlllIIIlIllllllIlIlIIII IlIllllIIIlIllllIIIIIllII() {
        return IIlIlIllIlIIllIllIllIIIll.IlllIlIlllIlIlllIIlllIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.lIIIIlllIIlIlllllIlIllIII = new IlllIllIIIIlllIllIIIIIlII[4];
        for (int i = 0; i < this.lIIIIlllIIlIlllllIlIllIII.length; ++i) {
            this.lIIIIlllIIlIlllllIlIllIII[i] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_stage_" + i);
        }
    }
}
