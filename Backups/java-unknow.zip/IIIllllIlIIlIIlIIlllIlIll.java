import com.google.common.collect.Sets;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIlIIlIIlIIlllIlIll extends lllIllllIllllIllIIlIlllII
{
    private static final Set IlIlllIIIIllIllllIllIIlIl;
    
    protected IIIllllIlIIlIIlIIlllIlIll(final IlIIIllllIlllllIIlIlllllI ilIIIllllIlllllIIlIlllllI) {
        super(2.0f, ilIIIllllIlllllIIlIlllllI, IIIllllIlIIlIIlIIlllIlIll.IlIlllIIIIllIllllIllIIlIl);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return (illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IllllllIllllIIlllIllllllI) ? (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() == 3) : ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IlIlllIIIIlIllIlllIlIIIll && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IlIIllIlIlIIIllIllIIlIIII) ? ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.lIllIllIIlIlIIIIllIllllll && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IIlllllllIllIlIllIIIlllIl) ? ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.llIlIlIlllIlllllIIIllIIll && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.llIlIIIlIIIIlIlllIlIIIIll) ? ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IIllIlIllIlIllIIlIllIlIII && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IIIlIIllllIIllllllIlIIIll) ? ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.llIlIIIllIIIIlllIlIIIIIlI && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.lIllIllIlIIllIllIlIlIIlIl) ? ((illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IIlIlllllIIIlIIllIllIlIlI && illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.IlIllIllIllIllIllllIIIlII) ? (illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() == Material.IIIIllIIllIIIIllIllIIIlIl || illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() == Material.IlIlIIIlllIIIlIlllIlIllIl || illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() == Material.IIIllIllIlIlllllllIlIlIII) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 2)) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 1)) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 1)) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 2)) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 2)) : (this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl() >= 2));
    }
    
    @Override
    public float lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return (illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() != Material.IlIlIIIlllIIIlIlllIlIllIl && illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() != Material.IIIllIllIlIlllllllIlIlIII && illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() != Material.IIIIllIIllIIIIllIllIIIlIl) ? super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, illlllllIlllIIllllIIlIll) : this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    static {
        IlIlllIIIIllIllllIllIIlIl = Sets.newHashSet((Object[])new IIlllllllIlllIIllllIIlIll[] { IllllllIllIIlllIllIIlIIll.IIIIllIIllIIIIllIllIIIlIl, IllllllIllIIlllIllIIlIIll.lIlIllIlIlIIIllllIlIllIll, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl, IllllllIllIIlllIllIIlIIll.IIIlIIlIlIIIlllIIlIllllll, IllllllIllIIlllIllIIlIIll.lIIlIIIIIIIIllIIllIIlllIl, IllllllIllIIlllIllIIlIIll.IIIlIIllllIIllllllIlIIIll, IllllllIllIIlllIllIIlIIll.IIllIlIllIlIllIIlIllIlIII, IllllllIllIIlllIllIIlIIll.lllIIIIIlIllIlIIIllllllII, IllllllIllIIlllIllIIlIIll.llIlIlIlllIlllllIIIllIIll, IllllllIllIIlllIllIIlIIll.llIlIIIlIIIIlIlllIlIIIIll, IllllllIllIIlllIllIIlIIll.IlIIllIlIlIIIllIllIIlIIII, IllllllIllIIlllIllIIlIIll.IlIlllIIIIlIllIlllIlIIIll, IllllllIllIIlllIllIIlIIll.IIlIlIlllIllIIlIllIIlIIlI, IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl, IllllllIllIIlllIllIIlIIll.lIllIllIlIIllIllIlIlIIlIl, IllllllIllIIlllIllIIlIIll.llIlIIIllIIIIlllIlIIIIIlI, IllllllIllIIlllIllIIlIIll.IIlIlllllIIIlIIllIllIlIlI, IllllllIllIIlllIllIIlIIll.IlIllIllIllIllIllllIIIlII, IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, IllllllIllIIlllIllIIlIIll.lIlIlIllIIIIIIIIllllIIllI, IllllllIllIIlllIllIIlIIll.IllIIlIIlllllIllIIIlllIII, IllllllIllIIlllIllIIlIIll.lIIIIlllIlIlllIIIlllllIlI });
    }
}
