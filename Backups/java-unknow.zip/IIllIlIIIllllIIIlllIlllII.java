import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIllIlIIIllllIIIlllIlllII implements Callable
{
    final /* synthetic */ lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ IIIlIllIIlIllIIIIlIIlIlIl lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIllIlIIIllllIIIlllIlllII(final IIIlIllIIlIllIIIIlIIlIlIl liiiiiiiiIlIllIIllIlIIlIl, final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return String.valueOf(this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII());
    }
}
