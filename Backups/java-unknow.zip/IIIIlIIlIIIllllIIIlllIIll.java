import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIlIIlIIIllllIIIlllIIll extends lllIlIlIlIIIIIIIIlIlIlllI implements IllIIIlIlIllIlIllllIIIllI
{
    private int llIIIlllllIlllIIllIlIIlII;
    private int lIIIlIlIIIlIlIlllIlIlllII;
    private lIllIIIIlIIlIllIIIlIlIlll llIlIlIIIIIIIlllIIIllIlll;
    
    public IIIIlIIlIIIllllIIIlllIIll(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    @Override
    protected void IlllIIIllIlIlIIIllIIIlIlI() {
        if (this.z_() != 0) {
            this.llIIIlllllIlllIIllIlIIlII = 0;
        }
        super.IlllIIIllIlIlIIIllIIIlIlI();
    }
    
    @Override
    public void i_() {
        super.i_();
        if (this.z_() != 0) {
            this.llIIIlllllIlllIIllIlIIlII = 0;
        }
        if (this.llIIIlllllIlllIIllIlIIlII > 0) {
            --this.llIIIlllllIlllIIllIlIIlII;
            final String s = "heart";
            if (this.llIIIlllllIlllIIllIlIIlII % 10 == 0) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(s, this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + 2.2499999832361937 * 0.2222222238779068 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (1.2580645084381104 * 0.015897435994621643), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.5050504803657532 * 0.03960000193548212), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.6153846383094788 * 0.0324999987892807));
            }
        }
        else {
            this.lIIIlIlIIIlIlIlllIlIlllII = 0;
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n) {
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            if (n < 3) {
                this.IllllIllllIlIIIlIIIllllll = (float)(Math.atan2(entity.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll, entity.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll) * 180 / (4.130434989929199 * 0.7605960779553739)) - 90;
                this.IIIIllIlIIIllIlllIlllllIl = true;
            }
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = (lIllIIIIlIIlIllIIIlIlIlll)entity;
            if (lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll() == null || !this.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll())) {
                this.IlllIIIlIlllIllIlIIlllIlI = null;
            }
        }
        else if (entity instanceof IIIIlIIlIIIllllIIIlllIIll) {
            final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll = (IIIIlIIlIIIllllIIIlllIIll)entity;
            if (this.z_() > 0 && iiiIlIIlIIIllllIIIlllIIll.z_() < 0) {
                if (n < 2.615384567418748 * 0.9558823704719543) {
                    this.IIIIllIlIIIllIlllIlllllIl = true;
                }
            }
            else if (this.llIIIlllllIlllIIllIlIIlII > 0 && iiiIlIIlIIIllllIIIlllIIll.llIIIlllllIlllIIllIlIIlII > 0) {
                if (iiiIlIIlIIIllllIIIlllIIll.IlllIIIlIlllIllIlIIlllIlI == null) {
                    iiiIlIIlIIIllllIIIlllIIll.IlllIIIlIlllIllIlIIlllIlI = this;
                }
                if (iiiIlIIlIIIllllIIIlllIIll.IlllIIIlIlllIllIlIIlllIlI == this && n < 1.1338028245160467 * 3.08695650100708) {
                    final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll2 = iiiIlIIlIIIllllIIIlllIIll;
                    ++iiiIlIIlIIIllllIIIlllIIll2.llIIIlllllIlllIIllIlIIlII;
                    ++this.llIIIlllllIlllIIllIlIIlII;
                    ++this.lIIIlIlIIIlIlIlllIlIlllII;
                    if (this.lIIIlIlIIIlIlIlllIlIlllII % 4 == 0) {
                        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("heart", this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + 0.4354838592452887 * 1.1481481790542603 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, 0.0, 0.0, 0.0);
                    }
                    if (this.lIIIlIlIIIlIlIlllIlIlllII == 60) {
                        this.lIIIIIIIIIlIllIIllIlIIlIl((IIIIlIIlIIIllllIIIlllIIll)entity);
                    }
                }
                else {
                    this.lIIIlIlIIIlIlIlllIlIlllII = 0;
                }
            }
            else {
                this.lIIIlIlIIIlIlIlllIlIlllII = 0;
                this.IlllIIIlIlllIllIlIIlllIlI = null;
            }
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll) {
        final lllIlIlIlIIIIIIIIlIlIlllI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(iiiIlIIlIIIllllIIIlllIIll);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            if (this.llIlIlIIIIIIIlllIIIllIlll == null && iiiIlIIlIIIllllIIIlllIIll.IIIlIllIIIlllIIlIIllIlIII() != null) {
                this.llIlIlIIIIIIIlllIIIllIlll = iiiIlIIlIIIllllIIIlllIIll.IIIlIllIIIlllIIlIIllIlIII();
            }
            if (this.llIlIlIIIIIIIlllIIIllIlll != null) {
                this.llIlIlIIIIIIIlllIIIllIlll.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.lIllIllIlIIllIllIlIlIIlIl);
                if (this instanceof lIllIIIIlIIIlllIllIIllIlI) {
                    this.llIlIlIIIIIIIlllIIIllIlll.lIIIIlIIllIIlIIlIIIlIIllI(AchievementList.IllIIlllIllIlIllIlIIIIIII);
                }
            }
            this.updateDebugProfilerName(6000);
            iiiIlIIlIIIllllIIIlllIIll.updateDebugProfilerName(6000);
            this.llIIIlllllIlllIIllIlIIlII = 0;
            this.lIIIlIlIIIlIlIlllIlIlllII = 0;
            this.IlllIIIlIlllIllIlIIlllIlI = null;
            iiiIlIIlIIIllllIIIlllIIll.IlllIIIlIlllIllIlIIlllIlI = null;
            iiiIlIIlIIIllllIIIlllIIll.lIIIlIlIIIlIlIlllIlIlllII = 0;
            iiiIlIIlIIIllllIIIlllIIll.llIIIlllllIlllIIllIlIIlII = 0;
            liiiIlIIllIIlIIlIIIlIIllI.updateDebugProfilerName(-24000);
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
            for (int i = 0; i < 7; ++i) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("heart", this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + 0.3736842039615495 * 1.3380281925201416 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.020454545426836685 * 0.9777777791023254), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.2050000076368454 * 0.09756097197532654), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.6233766078948975 * 0.032083334130131556));
            }
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        this.IIIIllIIllIIIIllIllIIIlIl = 60;
        if (!this.IIllIllIlIIlllllIlIIIlIll()) {
            final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl);
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IIIIlIIlIIIllllIIIlllIIll.lIIIIlIIllIIlIIlIIIlIIllI) == null) {
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IIIIlIIlIIIllllIIIlllIIll.lIIIIIIIIIlIllIIllIlIIlIl);
            }
        }
        this.IlllIIIlIlllIllIlIIlllIlI = null;
        this.llIIIlllllIlllIIllIlIIlII = 0;
        return super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, n);
    }
    
    @Override
    public float lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        return (this.lIIlllIIlIlllllllllIIIIIl.getBlock(n, n2 - 1, n3) == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI) ? 10 : (this.lIIlllIIlIlllllllllIIIIIl.llIIlllIIIIlllIllIlIlllIl(n, n2, n3) - 0.51086956f * 0.9787234f);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("InLove", this.llIIIlllllIlllIIllIlIIlII);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.llIIIlllllIlllIIllIlIIlII = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("InLove");
    }
    
    @Override
    protected Entity IllIIIIIIIlIlIllllIIllIII() {
        if (this.IIIIllIIllIIIIllIllIIIlIl > 0) {
            return null;
        }
        final float n = 8;
        if (this.llIIIlllllIlllIIllIlIIlII > 0) {
            final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.getClass(), this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n, n, n));
            for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll = liiiIlIIllIIlIIlIIIlIIllI.get(i);
                if (iiiIlIIlIIIllllIIIlllIIll != this && iiiIlIIlIIIllllIIIlllIIll.llIIIlllllIlllIIllIlIIlII > 0) {
                    return iiiIlIIlIIIllllIIIlllIIll;
                }
            }
        }
        else if (this.z_() == 0) {
            final List liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n, n, n));
            for (int j = 0; j < liiiIlIIllIIlIIlIIIlIIllI2.size(); ++j) {
                final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = liiiIlIIllIIlIIlIIIlIIllI2.get(j);
                if (lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll() != null && this.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll())) {
                    return lIllIIIIlIIlIllIIIlIlIlll;
                }
            }
        }
        else if (this.z_() > 0) {
            final List liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.getClass(), this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n, n, n));
            for (int k = 0; k < liiiIlIIllIIlIIlIIIlIIllI3.size(); ++k) {
                final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll2 = liiiIlIIllIIlIIlIIIlIIllI3.get(k);
                if (iiiIlIIlIIIllllIIIlllIIll2 != this && iiiIlIIlIIIllllIIIlllIIll2.z_() < 0) {
                    return iiiIlIIlIIIllllIIIlllIIll2;
                }
            }
        }
        return null;
    }
    
    @Override
    public boolean IIIlllIIIllIllIlIIIIIIlII() {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
        return this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3) == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI && this.lIIlllIIlIlllllllllIIIIIl.lIIIIllIIlIlIllIIIlIllIlI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3) > 8 && super.IIIlllIIIllIllIlIIIIIIlII();
    }
    
    @Override
    public int lllIlIIllllIIIIlIllIlIIII() {
        return 120;
    }
    
    @Override
    protected boolean IlIlIIIlllIlIllIlIIIlllIl() {
        return false;
    }
    
    @Override
    protected int IIIIllIIllIIIIllIllIIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return 1 + this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(3);
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIllllIIIlIllllIIIIIllII;
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI != null && this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI) && this.z_() == 0 && this.llIIIlllllIlllIIllIlIIlII <= 0) {
            if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = liiiIlIIllIIlIIlIIIlIIllI;
                --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
                if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
                    lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem, null);
                }
            }
            this.IlIlIIIlllIIIlIlllIlIllIl(lIllIIIIlIIlIllIIIlIlIlll);
            return true;
        }
        return super.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final lIllIIIIlIIlIllIIIlIlIlll llIlIlIIIIIIIlllIIIllIlll) {
        this.llIIIlllllIlllIIllIlIIlII = 600;
        this.llIlIlIIIIIIIlllIIIllIlll = llIlIlIIIIIIIlllIIIllIlll;
        this.IlllIIIlIlllIllIlIIlllIlI = null;
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)18);
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll IIIlIllIIIlllIIlIIllIlIII() {
        return this.llIlIlIIIIIIIlllIIIllIlll;
    }
    
    public boolean IlIIIIlllIIIlIIllllIIIlll() {
        return this.llIIIlllllIlllIIllIlIIlII > 0;
    }
    
    public void IllIIIIIllllIlllIIlIIllIl() {
        this.llIIIlllllIlllIIllIlIIlII = 0;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIlIIlIIIllllIIIlllIIll iiiIlIIlIIIllllIIIlllIIll) {
        return iiiIlIIlIIIllllIIIlllIIll != this && iiiIlIIlIIIllllIIIlllIIll.getClass() == this.getClass() && (this.IlIIIIlllIIIlIIllllIIIlll() && iiiIlIIlIIIllllIIIlllIIll.IlIIIIlllIIIlIIllllIIIlll());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        if (b == 18) {
            for (int i = 0; i < 7; ++i) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("heart", this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + 3.344827651977539 * 0.14948453314310187 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (1.223880648612976 * 0.016341462725688163), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (3.0370371341705322 * 0.006585365643038918), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.48351648449897766 * 0.041363636279586426));
            }
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(b);
        }
    }
}
