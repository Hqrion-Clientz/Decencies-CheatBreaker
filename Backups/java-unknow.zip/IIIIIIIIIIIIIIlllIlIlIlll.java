// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIIIIIIIIIIIIlllIlIlIlll
{
    lIIIIlIIllIIlIIlIIIlIIllI("NONE", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("ONEWAY", 1), 
    IlllIIIlIlllIllIlIIlllIlI("TWOWAY", 2);
    
    private IIIIIIIIIIIIIIlllIlIlIlll(final String name, final int ordinal) {
    }
}
