import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlIIlIIIlllllIlllIIlII implements GenericFutureListener
{
    final /* synthetic */ NetworkManager lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ lIlIIllIIlIIIIIlIllIllllI lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ llIllIIIIlIlIIIIlIIlIllIl IlllIIIlIlllIllIlIIlllIlI;
    
    IIIIlIIlIIIlllllIlllIIlII(final llIllIIIIlIlIIIIlIIlIllIl illlIIIlIlllIllIlIIlllIlI, final NetworkManager liiiIlIIllIIlIIlIIIlIIllI, final lIlIIllIIlIIIIIlIllIllllI liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public void operationComplete(final Future future) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
}
