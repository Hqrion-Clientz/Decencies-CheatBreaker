import com.google.common.collect.Sets;
import org.apache.logging.log4j.LogManager;
import java.awt.Color;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIlIIlIIllIIllIlIIIIIIIlI
{
    private static final Logger llllIIlIlIllIllllIIIIllll;
    protected static final IlIllIlIIllIIIIlIlllIIIII lIIIIlIIllIIlIIlIIIlIIllI;
    protected static final IlIllIlIIllIIIIlIlllIIIII lIIIIIIIIIlIllIIllIlIIlIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII IlllIIIlIlllIllIlIIlllIlI;
    protected static final IlIllIlIIllIIIIlIlllIIIII IIIIllIlIIIllIlllIlllllIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII IIIIllIIllIIIIllIllIIIlIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII IlIlIIIlllIIIlIlllIlIllIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII IIIllIllIlIlllllllIlIlIII;
    protected static final IlIllIlIIllIIIIlIlllIIIII IllIIIIIIIlIlIllllIIllIII;
    protected static final IlIllIlIIllIIIIlIlllIIIII lIIIIllIIlIlIllIIIlIllIlI;
    protected static final IlIllIlIIllIIIIlIlllIIIII IlllIllIlIIIIlIIlIIllIIIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII IlIlllIIIIllIllllIllIIlIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII llIIlllIIIIlllIllIlIlllIl;
    protected static final IlIllIlIIllIIIIlIlllIIIII lIIlIlIllIIlIIIlIIIlllIII;
    private static final IIlIIlIIllIIllIlIIIIIIIlI[] IIlIlIlllIllIIlIllIIlIIlI;
    public static final Set IIIlllIIIllIllIlIIIIIIlII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI llIlIIIlIIIIlIlllIlIIIIll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIIlIIllllIIllllllIlIIIll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lllIIIIIlIllIlIIIllllllII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIIIIllllIIIIlIlIIIIlIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIIIIIlIlIlIllllllIlllIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllIllIIIlIIlllIIIllIllII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIIlIIIIlIIIIllllIIlIllI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIlIIllIIIIIlIllIIIIllII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIlllIIlIlllllllllIIIIIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIllIllIlIIllIllIlIlIIlIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI llIlIIIllIIIIlllIlIIIIIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIllIlIlllIIlIIllIIlIIlII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIIlIIlIlIIIlllIIlIllllll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllIlIIIIlllIIllIIlllIIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllIlIlIllllIlIIllllIIlll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllIIlIIlllllIllIIIlllIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIlIlIllIIIIIIIIllllIIllI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlllIIlllIIIIllIIllllIlIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllllIllllIlIIIlIIIllllll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllIIlllIllIlIllIlIIIIIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIlIIIlllllIIIlIlIlIllII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIlIIllIIIllllIIlllIllIIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lllIlIIllllIIIIlIllIlIIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIIIlllIIlIlllllIlIllIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIIlllIlIlllIIIIIIIIIlII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIIIlIIIlllllllllIlllIlll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIllllIIIlIllllIIIIIllII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIIIIllIIIIIlllIIlIIlllI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI llIlIlIllIlIIlIlllIllIIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI llIlIlIlllIlllllIIIllIIll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIllIlIllIlIllIIlIllIlIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIlIllIlIlIIIllllIlIllIll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIIlIIlIllIIIIllIIllIlIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI llllIIIIlIlIllIIIllllIIll;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IIlIlIIlIIIlIlllllIIlIIlI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIIlllIIIlIIIIIlIIIIIIII;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIIlIIIIIIIIllIIllIIlllIl;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IllllllIllllIIlllIllllllI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI lIlIlIIIlIIllllllllIIlllI;
    public static final IIlIIlIIllIIllIlIIIIIIIlI IlIlllIllIlIllIlllIlllIll;
    protected static final lIllllIIlIIlIlIlIlIlIllIl llIIIllIIllllIlIlIlIlIIll;
    protected static final lIllllIIlIIlIlIlIlIlIllIl IIIIIlIllIllIlIIllIIlIllI;
    protected static final llllIlIlIlIlIllIlllIIllII lIIllIIllllllIIlllIlllIIl;
    public String lllIIllllIIlIlIlIlIIIlIII;
    public int IlIIllIlIlIIIllIllIIlIIII;
    public int IlIlllIIIIlIllIlllIlIIIll;
    public IIlllllllIlllIIllllIIlIll IIIlIllIlllIlIllIllllllll;
    public int IllllllllIlIIIIIIIIllIIII;
    public IIlllllllIlllIIllllIIlIll lIIlIlIIlIlIlIIlIlIlllIIl;
    public int IllIIIlIIlIllIllIIllllIIl;
    public float IIlIlllIllIlIlIIIIIlllIll;
    public float IlIIllIIIlllIIIIlIIIIlIll;
    public float lIIIIIIlIIllllllIIIlIlIIl;
    public float llIIIlIlIIlIlIIlIllIllIll;
    public int IlIIlllIlIIIlIIIlIlIlIlIl;
    public IllIlIlIIIlIlIlIllIIlllII IIIlllllIIlIlIIIllllllIII;
    protected List lIlIlIIIIllIlllIlIIlllIlI;
    protected List IIllllIllllIIIlIIllllIlll;
    protected List llllIIIIIlIlIlIlIllIIIIII;
    protected List IllIIIIllllllIlllllIlIlll;
    protected boolean IIIllllIlIIlIIIlIlIlllIII;
    protected boolean IIlIlllllIIIlIIllIllIlIlI;
    public final int IlIllIllIllIllIllllIIIlII;
    protected IlIllIlllllllIIIIIIlllIll lllIllIllIlIllIlIIllllIIl;
    protected llllIlIlIIlllIIIllIIIIIlI IIIIIIIllIllllIIlIIlllIII;
    protected IIIIIIIIIlIllIllllIIlllll IIIIlIllIIIIIIlIIIIIlllll;
    
    protected IIlIIlIIllIIllIlIIIIIIIlI(final int ilIllIllIllIllIllllIIIlII) {
        this.IIIlIllIlllIlIllIllllllll = IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI;
        this.IllllllllIlIIIIIIIIllIIII = 0;
        this.lIIlIlIIlIlIlIIlIlIlllIIl = IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl;
        this.IllIIIlIIlIllIllIIllllIIl = 5169201;
        this.IIlIlllIllIlIlIIIIIlllIll = IIlIIlIIllIIllIlIIIIIIIlI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IlIIllIIIlllIIIIlIIIIlIll = IIlIIlIIllIIllIlIIIIIIIlI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl;
        this.lIIIIIIlIIllllllIIIlIlIIl = 0.20588236f * 2.4285715f;
        this.llIIIlIlIIlIlIIlIllIllIll = 0.34848484f * 1.4347826f;
        this.IlIIlllIlIIIlIIIlIlIlIlIl = 16777215;
        this.lIlIlIIIIllIlllIlIIlllIlI = new ArrayList();
        this.IIllllIllllIIIlIIllllIlll = new ArrayList();
        this.llllIIIIIlIlIlIlIllIIIIII = new ArrayList();
        this.IllIIIIllllllIlllllIlIlll = new ArrayList();
        this.IIlIlllllIIIlIIllIllIlIlI = true;
        this.lllIllIllIlIllIlIIllllIIl = new IlIllIlllllllIIIIIIlllIll(false);
        this.IIIIIIIllIllllIIlIIlllIII = new llllIlIlIIlllIIIllIIIIIlI(false);
        this.IIIIlIllIIIIIIlIIIIIlllll = new IIIIIIIIIlIllIllllIIlllll();
        this.IlIllIllIllIllIllllIIIlII = ilIllIllIllIllIllllIIIlII;
        IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI[ilIllIllIllIllIllllIIIlII] = this;
        this.IIIlllllIIlIlIIIllllllIII = this.lIIIIlIIllIIlIIlIIIlIIllI();
        this.IIllllIllllIIIlIIllllIlll.add(new lIlIIIlllIIlllllIlIllIIIl(lIllIIIIIIlIlllllIllIIlIl.class, 12, 4, 4));
        this.IIllllIllllIIIlIIllllIlll.add(new lIlIIIlllIIlllllIlIllIIIl(lIlIIIlllIIIIIlIIIlIIIlll.class, 10, 4, 4));
        this.IIllllIllllIIIlIIllllIlll.add(new lIlIIIlllIIlllllIlIllIIIl(lIllllIIIIlIlIlllllllIIII.class, 10, 4, 4));
        this.IIllllIllllIIIlIIllllIlll.add(new lIlIIIlllIIlllllIlIllIIIl(lIllIIIIlIIIlllIllIIllIlI.class, 8, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(lIIllllllllIIlllIlIIIIlIl.class, 100, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(IIlIIIIIIlIllIIIIlIIIIlll.class, 100, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(IlIllIIIllIIIIIlIlllIllII.class, 100, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(IIIIllllIlIIlllIllIlllllI.class, 100, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(lllIIlIlIIlllIIlllIllIIII.class, 100, 4, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(llIIIllllIlllIIllIIIlIIII.class, 10, 1, 4));
        this.lIlIlIIIIllIlllIlIIlllIlI.add(new lIlIIIlllIIlllllIlIllIIIl(llIIllIIIlIllIIllIlIllIIl.class, 5, 1, 1));
        this.llllIIIIIlIlIlIlIllIIIIII.add(new lIlIIIlllIIlllllIlIllIIIl(IlIllllIIIllIlIIlIlIIIlII.class, 10, 4, 4));
        this.IllIIIIllllllIlllllIlIlll.add(new lIlIIIlllIIlllllIlIllIIIl(llIlIlIlIlIIIllIIIlIllIll.class, 10, 8, 8));
    }
    
    protected IllIlIlIIIlIlIlIllIIlllII lIIIIlIIllIIlIIlIIIlIIllI() {
        return new IllIlIlIIIlIlIlIllIIlllII();
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final float liiiiiIlIIllllllIIIlIlIIl, final float llIIIlIlIIlIlIIlIllIllIll) {
        if (liiiiiIlIIllllllIIIlIlIIl > 0.43421054f * 0.23030303f && liiiiiIlIIllllllIIIlIlIIl < 0.18947369f * 1.0555556f) {
            throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
        }
        this.lIIIIIIlIIllllllIIIlIlIIl = liiiiiIlIIllllllIIIlIlIIl;
        this.llIIIlIlIIlIlIIlIllIllIll = llIIIlIlIIlIlIIlIllIllIll;
        return this;
    }
    
    protected final IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIlIIllIIIIlIlllIIIII ilIllIlIIllIIIIlIlllIIIII) {
        this.IIlIlllIllIlIlIIIIIlllIll = ilIllIlIIllIIIIlIlllIIIII.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IlIIllIIIlllIIIIlIIIIlIll = ilIllIlIIllIIIIlIlllIIIII.lIIIIIIIIIlIllIIllIlIIlIl;
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IIlIlllllIIIlIIllIllIlIlI = false;
        return this;
    }
    
    public lIIllllIIlIIlllIlIIllIIIl lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        return (random.nextInt(10) == 0) ? this.IIIIIIIllIllllIIlIIlllIII : this.lllIllIllIlIllIlIIllllIIl;
    }
    
    public IIllIlIIlllIlIIlIllllllll lIIIIIIIIIlIllIIllIlIIlIl(final Random random) {
        return new lllllIIIIIIlIIlIIIllIIlII(IllllllIllIIlllIllIIlIIll.IllIIlllIllIlIllIlIIIIIII, 1);
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final int n, final int n2, final int n3) {
        return (random.nextInt(3) > 0) ? "" : "";
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIllllIlIIlIIIlIlIlllIII = true;
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final String lllIIllllIIlIlIlIlIIIlIII) {
        this.lllIIllllIIlIlIlIlIIIlIII = lllIIllllIIlIlIlIlIIIlIII;
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final int illIIIlIIlIllIllIIllllIIl) {
        this.IllIIIlIIlIllIllIIllllIIl = illIIIlIIlIllIllIIllllIIl;
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, false);
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI IlllIIIlIlllIllIlIIlllIlI(final int ilIlllIIIIlIllIlllIlIIIll) {
        this.IlIlllIIIIlIllIlllIlIIIll = ilIlllIIIIlIllIlllIlIIIll;
        return this;
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final boolean b) {
        this.IlIIllIlIlIIIllIllIIlIIII = n;
        if (b) {
            this.IlIlllIIIIlIllIlllIlIIIll = (n & 0xFEFEFE) >> 1;
        }
        else {
            this.IlIlllIIIIlIllIlllIlIIIll = n;
        }
        return this;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(float n) {
        n /= 3;
        if (n < -1) {
            n = -1;
        }
        if (n > 1.0f) {
            n = 1.0f;
        }
        return Color.getHSBColor(0.044444446f * 14.0f - n * (0.5483871f * 0.09117647f), 0.8245614f * 0.60638297f + n * (0.35714287f * 0.28f), 1.0f).getRGB();
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllIIIlIllIlllIIl lIllIIIIlllIIIlIllIlllIIl) {
        return (lIllIIIIlllIIIlIllIlllIIl == lIllIIIIlllIIIlIllIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI) ? this.lIlIlIIIIllIlllIlIIlllIlI : ((lIllIIIIlllIIIlIllIlllIIl == lIllIIIIlllIIIlIllIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl) ? this.IIllllIllllIIIlIIllllIlll : ((lIllIIIIlllIIIlIllIlllIIl == lIllIIIIlllIIIlIllIlllIIl.IIIIllIlIIIllIlllIlllllIl) ? this.llllIIIIIlIlIlIlIllIIIIII : ((lIllIIIIlllIIIlIllIlllIIl == lIllIIIIlllIIIlIllIlllIIl.IlllIIIlIlllIllIlIIlllIlI) ? this.IllIIIIllllllIlllllIlIlll : null)));
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIllIlIIIIlIIlIIllIIIl();
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return !this.IlllIllIlIIIIlIIlIIllIIIl() && this.IIlIlllllIIIlIIllIllIlIlI;
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return this.llIIIlIlIIlIlIIlIllIllIll > 0.104477614f * 8.135715f;
    }
    
    public float IIIllIllIlIlllllllIlIlIII() {
        return 3.4f * 0.029411765f;
    }
    
    public final int IllIIIIIIIlIlIllllIIllIII() {
        return (int)(this.llIIIlIlIIlIlIIlIllIllIll * 65536);
    }
    
    public final float lIIIIllIIlIlIllIIIlIllIlI() {
        return this.llIIIlIlIIlIlIIlIllIllIll;
    }
    
    public final float lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (n2 > 64) {
            return this.lIIIIIIlIIllllllIIIlIlIIl - ((float)IIlIIlIIllIIllIlIIIIIIIlI.llIIIllIIllllIlIlIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(n * 1.0 / 8, n3 * 1.0 / 8) * 4 + n2 - 64) * (0.05f * 1.0f) / 30;
        }
        return this.lIIIIIIlIIllllllIIIlIlIIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2) {
        this.IIIlllllIIlIlIIIllllllIII.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, this, n, n2);
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        return lllIllllIIlIIIIllIlllIlll.lIIIIlIIllIIlIIlIIIlIIllI(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3), 0.0f, 1.0f), MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI(), 0.0f, 1.0f));
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3) {
        return IlllIlIIlIllIlIlllllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3), 0.0f, 1.0f), MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI(), 0.0f, 1.0f));
    }
    
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IIIllllIlIIlIIIlIlIlllIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIlllllllIlllIIllllIIlIll[] array, final byte[] array2, final int n, final int n2, final double n3) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, random, array, array2, n, n2, n3);
    }
    
    public final void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIlllllllIlllIIllllIIlIll[] array, final byte[] array2, final int n, final int n2, final double n3) {
        IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll = this.IIIlIllIlllIlIllIllllllll;
        byte b = (byte)(this.IllllllllIlIIIIIIIIllIIII & 0xFF);
        IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll2 = this.lIIlIlIIlIlIlIIlIlIlllIIl;
        int n4 = -1;
        final int n5 = (int)(n3 / 3 + 3 + random.nextDouble() * (0.2644927618484043 * 0.9452054500579834));
        final int n6 = n & 0xF;
        final int n7 = n2 & 0xF;
        final int n8 = array.length / 256;
        for (int i = 255; i >= 0; --i) {
            final int n9 = (n7 * 16 + n6) * n8 + i;
            if (i <= 0 + random.nextInt(5)) {
                array[n9] = IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII;
            }
            else {
                final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll3 = array[n9];
                if (illlllllIlllIIllllIIlIll3 != null && illlllllIlllIIllllIIlIll3.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                    if (illlllllIlllIIllllIIlIll3 == IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl) {
                        if (n4 == -1) {
                            if (n5 <= 0) {
                                illlllllIlllIIllllIIlIll = null;
                                b = 0;
                                illlllllIlllIIllllIIlIll2 = IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl;
                            }
                            else if (i >= 59 && i <= 64) {
                                illlllllIlllIIllllIIlIll = this.IIIlIllIlllIlIllIllllllll;
                                b = (byte)(this.IllllllllIlIIIIIIIIllIIII & 0xFF);
                                illlllllIlllIIllllIIlIll2 = this.lIIlIlIIlIlIlIIlIlIlllIIl;
                            }
                            if (i < 63 && (illlllllIlllIIllllIIlIll == null || illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() == Material.air)) {
                                if (this.lIIIIlIIllIIlIIlIIIlIIllI(n, i, n2) < 1.1846154f * 0.12662338f) {
                                    illlllllIlllIIllllIIlIll = IllllllIllIIlllIllIIlIIll.IIlIlIlllIllIIlIllIIlIIlI;
                                    b = 0;
                                }
                                else {
                                    illlllllIlllIIllllIIlIll = IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl;
                                    b = 0;
                                }
                            }
                            n4 = n5;
                            if (i >= 62) {
                                array[n9] = illlllllIlllIIllllIIlIll;
                                array2[n9] = b;
                            }
                            else if (i < 56 - n5) {
                                illlllllIlllIIllllIIlIll = null;
                                illlllllIlllIIllllIIlIll2 = IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl;
                                array[n9] = IllllllIllIIlllIllIIlIIll.IIIlllIIIllIllIlIIIIIIlII;
                            }
                            else {
                                array[n9] = illlllllIlllIIllllIIlIll2;
                            }
                        }
                        else if (n4 > 0) {
                            --n4;
                            array[n9] = illlllllIlllIIllllIIlIll2;
                            if (n4 == 0 && illlllllIlllIIllllIIlIll2 == IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII) {
                                n4 = random.nextInt(4) + Math.max(0, i - 63);
                                illlllllIlllIIllllIIlIll2 = IllllllIllIIlllIllIIlIIll.IIIlIIlIlIIIlllIIlIllllll;
                            }
                        }
                    }
                }
                else {
                    n4 = -1;
                }
            }
        }
    }
    
    protected IIlIIlIIllIIllIlIIIIIIIlI IlIlllIIIIllIllllIllIIlIl() {
        return new lllllllllIlIlIIIIIllIIlIl(this.IlIllIllIllIllIllllIIIlII + 128, this);
    }
    
    public Class llIIlllIIIIlllIllIlIlllIl() {
        return this.getClass();
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIlIIllIIllIlIIIIIIIlI ilIIlIIllIIllIlIIIIIIIlI) {
        return ilIIlIIllIIllIlIIIIIIIlI == this || (ilIIlIIllIIllIlIIIIIIIlI != null && this.llIIlllIIIIlllIllIlIlllIl() == ilIIlIIllIIllIlIIIIIIIlI.llIIlllIIIIlllIllIlIlllIl());
    }
    
    public llIlllIIlIIIIIIlIllllllll lIIlIlIllIIlIIIlIIIlllIII() {
        return (this.lIIIIIIlIIllllllIIIlIlIIl < 0.3050847351551056 * 0.6555555783488141) ? llIlllIIlIIIIIIlIllllllll.lIIIIIIIIIlIllIIllIlIIlIl : ((this.lIIIIIIlIIllllllIIIlIlIIl < 1.0) ? llIlllIIlIIIIIIlIllllllll.IlllIIIlIlllIllIlIIlllIlI : llIlllIIlIIIIIIlIllllllll.IIIIllIlIIIllIlllIlllllIl);
    }
    
    public static IIlIIlIIllIIllIlIIIIIIIlI[] IIIlllIIIllIllIlIIIIIIlII() {
        return IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI;
    }
    
    public static IIlIIlIIllIIllIlIIIIIIIlI IIIIllIlIIIllIlllIlllllIl(final int i) {
        if (i >= 0 && i <= IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI.length) {
            return IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI[i];
        }
        IIlIIlIIllIIllIlIIIIIIIlI.llllIIlIlIllIllllIIIIllll.warn("Biome ID is out of bounds: " + i + ", defaulting to 0 (Ocean)");
        return IIlIIlIIllIIllIlIIIIIIIlI.llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    static {
        llllIIlIlIllIllllIIIIllll = LogManager.getLogger();
        lIIIIlIIllIIlIIlIIIlIIllI = new IlIllIlIIllIIIIlIlllIIIII(0.4181818f * 0.23913044f, 1.6279069f * 0.122857146f);
        lIIIIIIIIIlIllIIllIlIIlIl = new IlIllIlIIllIIIIlIlllIIIII(-0.3809524f * 1.3125f, 0.0f);
        IlllIIIlIlllIllIlIIlllIlI = new IlIllIlIIllIIIIlIlllIIIII(-1, 0.054545455f * 1.8333334f);
        IIIIllIlIIIllIlllIlllllIl = new IlIllIlIIllIIIIlIlllIIIII(0.5769231f * -3.12f, 0.5470588f * 0.1827957f);
        IIIIllIIllIIIIllIllIIIlIl = new IlIllIlIIllIIIIlIlllIIIII(0.05625f * 2.2222223f, 0.27272728f * 0.18333334f);
        IlIlIIIlllIIIlIlllIlIllIl = new IlIllIlIIllIIIIlIlllIIIII(0.9166667f * 0.21818182f, 0.09090909f * 2.2f);
        IIIllIllIlIlllllllIlIlIII = new IlIllIlIIllIIIIlIlllIIIII(0.05163934f * 8.714286f, 0.23913045f * 1.2545455f);
        IllIIIIIIIlIlIllllIIllIII = new IlIllIlIIllIIIIlIlllIIIII(0.21276596f * 7.0499997f, 0.6984127f * 0.035795454f);
        lIIIIllIIlIlIllIIIlIllIlI = new IlIllIlIIllIIIIlIlllIIIII(1.0f, 0.8333333f * 0.6f);
        IlllIllIlIIIIlIIlIIllIIIl = new IlIllIlIIllIIIIlIlllIIIII(0.0f, 1.1612903f * 0.021527778f);
        IlIlllIIIIllIllllIllIIlIl = new IlIllIlIIllIIIIlIlllIIIII(0.52380955f * 0.19090909f, 0.81609195f * 0.9802817f);
        llIIlllIIIIlllIllIlIlllIl = new IlIllIlIIllIIIIlIlllIIIII(1.6666666f * 0.120000005f, 0.7647059f * 0.3923077f);
        lIIlIlIllIIlIIIlIIIlllIII = new IlIllIlIIllIIIIlIlllIIIII(1.054054f * -0.1897436f, 0.16666666f * 0.6f);
        IIlIlIlllIllIIlIllIIlIIlI = new IIlIIlIIllIIllIlIIIIIIIlI[256];
        IIIlllIIIllIllIlIIIIIIlII = Sets.newHashSet();
        llIlIIIlIIIIlIlllIlIIIIll = new llIIlIIlIlIlIIllIlIllIIll(0).lIIIIIIIIIlIllIIllIlIIlIl(112).lIIIIlIIllIIlIIlIIIlIIllI("Ocean").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlllIIIlIlllIllIlIIlllIlI);
        IIIlIIllllIIllllllIlIIIll = new IllIlIllllllIlIllllIIlIlI(1).lIIIIIIIIIlIllIIllIlIIlIl(9286496).lIIIIlIIllIIlIIlIIIlIIllI("Plains");
        lllIIIIIlIllIlIIIllllllII = new IIIIIllIllIllllIIlIllIlII(2).lIIIIIIIIIlIllIIllIlIIlIl(16421912).lIIIIlIIllIIlIIlIIIlIIllI("Desert").lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(2.0f, 0.0f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIIllIIIIllIllIIIlIl);
        lIIIIIllllIIIIlIlIIIIlIlI = new IlIIlIllIIIlllIIllIIIIIIl(3, false).lIIIIIIIIIlIllIIllIlIIlIl(6316128).lIIIIlIIllIIlIIlIIIlIIllI("Extreme Hills").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI(0.101538464f * 1.969697f, 0.10285714f * 2.9166667f);
        IIIIIIlIlIlIllllllIlllIlI = new IllllIllIIlllIIlllllIIIll(4, 0).lIIIIIIIIIlIllIIllIlIIlIl(353825).lIIIIlIIllIIlIIlIIIlIIllI("Forest");
        IllIllIIIlIIlllIIIllIllII = new IllIlllIIIIlllllllIIIIIII(5, 0).lIIIIIIIIIlIllIIllIlIIlIl(747097).lIIIIlIIllIIlIIlIIIlIIllI("Taiga").lIIIIlIIllIIlIIlIIIlIIllI(5159473).lIIIIlIIllIIlIIlIIIlIIllI(0.5882353f * 0.42499998f, 1.008f * 0.7936508f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlIlIIIlllIIIlIlllIlIllIl);
        IlIIlIIIIlIIIIllllIIlIllI = new llllIllIllIIIlllIIlllIIll(6).lIIIIIIIIIlIllIIllIlIIlIl(522674).lIIIIlIIllIIlIIlIIIlIIllI("Swampland").lIIIIlIIllIIlIIlIIIlIIllI(9154376).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIlIlIllIIlIIIlIIIlllIII).lIIIIlIIllIIlIIlIIIlIIllI(0.8387097f * 0.95384616f, 0.30326086f * 2.967742f);
        lIIlIIllIIIIIlIllIIIIllII = new IIIIlIlllIIlIIIlIIIIIIIIl(7).lIIIIIIIIIlIllIIllIlIIlIl(255).lIIIIlIIllIIlIIlIIIlIIllI("River").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl);
        lIIlllIIlIlllllllllIIIIIl = new IIllIllllIIlIIIIIIIIIlIlI(8).lIIIIIIIIIlIllIIllIlIIlIl(16711680).lIIIIlIIllIIlIIlIIIlIIllI("Hell").lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(2.0f, 0.0f);
        lIllIllIlIIllIllIlIlIIlIl = new llllIIlllIllllIIlIIlIlIII(9).lIIIIIIIIIlIllIIllIlIIlIl(8421631).lIIIIlIIllIIlIIlIIIlIIllI("Sky").lIIIIIIIIIlIllIIllIlIIlIl();
        llIlIIIllIIIIlllIlIIIIIlI = new llIIlIIlIlIlIIllIlIllIIll(10).lIIIIIIIIIlIllIIllIlIIlIl(9474208).lIIIIlIIllIIlIIlIIIlIIllI("FrozenOcean").IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlllIIIlIlllIllIlIIlllIlI).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.14130436f * 3.5384614f);
        lIllIlIlllIIlIIllIIlIIlII = new IIIIlIlllIIlIIIlIIIIIIIIl(11).lIIIIIIIIIlIllIIllIlIIlIl(10526975).lIIIIlIIllIIlIIlIIIlIIllI("FrozenRiver").IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.77500004f * 0.6451613f);
        IIIlIIlIlIIIlllIIlIllllll = new IlIllllIlllllIIlIIllIIIII(12, false).lIIIIIIIIIlIllIIllIlIIlIl(16777215).lIIIIlIIllIIlIIlIIIlIIllI("Ice Plains").IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.56578946f * 0.88372093f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIIllIIIIllIllIIIlIl);
        IllIlIIIIlllIIllIIlllIIlI = new IlIllllIlllllIIlIIllIIIII(13, false).lIIIIIIIIIlIllIIllIlIIlIl(10526880).lIIIIlIIllIIlIIlIIIlIIllI("Ice Mountains").IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 1.4107143f * 0.35443038f);
        IllIlIlIllllIlIIllllIIlll = new IIlIlIlIlIllllllIlllIlIlI(14).lIIIIIIIIIlIllIIllIlIIlIl(16711935).lIIIIlIIllIIlIIlIIIlIIllI("MushroomIsland").lIIIIlIIllIIlIIlIIIlIIllI(0.11904762f * 7.56f, 1.0f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.llIIlllIIIIlllIllIlIlllIl);
        IllIIlIIlllllIllIIIlllIII = new IIlIlIlIlIllllllIlllIlIlI(15).lIIIIIIIIIlIllIIllIlIIlIl(10486015).lIIIIlIIllIIlIIlIIIlIIllI("MushroomIslandShore").lIIIIlIIllIIlIIlIIIlIIllI(3.0f * 0.29999998f, 1.0f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlllIllIlIIIIlIIlIIllIIIl);
        lIlIlIllIIIIIIIIllllIIllI = new IIIIlIlIIllllIIlIlllIllIl(16).lIIIIIIIIIlIllIIllIlIIlIl(16440917).lIIIIlIIllIIlIIlIIIlIIllI("Beach").lIIIIlIIllIIlIIlIIIlIIllI(2.32f * 0.3448276f, 1.0f * 0.4f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlllIllIlIIIIlIIlIIllIIIl);
        IlllIIlllIIIIllIIllllIlIl = new IIIIIllIllIllllIIlIllIlII(17).lIIIIIIIIIlIllIIllIlIIlIl(13786898).lIIIIlIIllIIlIIlIIIlIIllI("DesertHills").lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(2.0f, 0.0f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        IllllIllllIlIIIlIIIllllll = new IllllIllIIlllIIlllllIIIll(18, 0).lIIIIIIIIIlIllIIllIlIIlIl(2250012).lIIIIlIIllIIlIIlIIIlIIllI("ForestHills").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        IllIIlllIllIlIllIlIIIIIII = new IllIlllIIIIlllllllIIIIIII(19, 0).lIIIIIIIIIlIllIIllIlIIlIl(1456435).lIIIIlIIllIIlIIlIIIlIIllI("TaigaHills").lIIIIlIIllIIlIIlIIIlIIllI(5159473).lIIIIlIIllIIlIIlIIIlIIllI(2.3846154f * 0.10483871f, 0.69230765f * 1.1555556f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        IlIlIIIlllllIIIlIlIlIllII = new IlIIlIllIIIlllIIllIIIIIIl(20, true).lIIIIIIIIIlIllIIllIlIIlIl(7501978).lIIIIlIIllIIlIIlIIIlIIllI("Extreme Hills Edge").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI()).lIIIIlIIllIIlIIlIIIlIIllI(0.08333333f * 2.4f, 0.3857143f * 0.7777778f);
        IIlIIllIIIllllIIlllIllIIl = new lIIllIllIIIllIIIIIIIIllll(21, false).lIIIIIIIIIlIllIIllIlIIlIl(5470985).lIIIIlIIllIIlIIlIIIlIIllI("Jungle").lIIIIlIIllIIlIIlIIIlIIllI(5470985).lIIIIlIIllIIlIIlIIIlIIllI(6.3333335f * 0.14999999f, 0.5333333f * 1.6875f);
        lllIlIIllllIIIIlIllIlIIII = new lIIllIllIIIllIIIIIIIIllll(22, false).lIIIIIIIIIlIllIIllIlIIlIl(2900485).lIIIIlIIllIIlIIlIIIlIIllI("JungleHills").lIIIIlIIllIIlIIlIIIlIIllI(5470985).lIIIIlIIllIIlIIlIIIlIIllI(3.9266667f * 0.24193548f, 0.13513513f * 6.6600003f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        lIIIIlllIIlIlllllIlIllIII = new lIIllIllIIIllIIIIIIIIllll(23, true).lIIIIIIIIIlIllIIllIlIIlIl(6458135).lIIIIlIIllIIlIIlIIIlIIllI("JungleEdge").lIIIIlIIllIIlIIlIIIlIIllI(5470985).lIIIIlIIllIIlIIlIIIlIIllI(2.1192307f * 0.44827586f, 0.31168833f * 2.5666666f);
        lIIIlllIlIlllIIIIIIIIIlII = new llIIlIIlIlIlIIllIlIllIIll(24).lIIIIIIIIIlIllIIllIlIIlIl(48).lIIIIlIIllIIlIIlIIIlIIllI("Deep Ocean").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl);
        IIIIlIIIlllllllllIlllIlll = new IIlIIllIlllllllIIIllIIlIl(25).lIIIIIIIIIlIllIIllIlIIlIl(10658436).lIIIIlIIllIIlIIlIIIlIIllI("Stone Beach").lIIIIlIIllIIlIIlIIIlIIllI(0.4375f * 0.45714286f, 1.75f * 0.17142858f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlIlllIIIIllIllllIllIIlIl);
        IlIllllIIIlIllllIIIIIllII = new IIIIlIlIIllllIIlIlllIllIl(26).lIIIIIIIIIlIllIIllIlIIlIl(16445632).lIIIIlIIllIIlIIlIIIlIIllI("Cold Beach").lIIIIlIIllIIlIIlIIIlIIllI(0.1328125f * 0.3764706f, 0.3f * 1.0f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI();
        IlIIIIllIIIIIlllIIlIIlllI = new IllllIllIIlllIIlllllIIIll(27, 2).lIIIIlIIllIIlIIlIIIlIIllI("Birch Forest").lIIIIIIIIIlIllIIllIlIIlIl(3175492);
        llIlIlIllIlIIlIlllIllIIlI = new IllllIllIIlllIIlllllIIIll(28, 2).lIIIIlIIllIIlIIlIIIlIIllI("Birch Forest Hills").lIIIIIIIIIlIllIIllIlIIlIl(2055986).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        llIlIlIlllIlllllIIIllIIll = new IllllIllIIlllIIlllllIIIll(29, 3).lIIIIIIIIIlIllIIllIlIIlIl(4215066).lIIIIlIIllIIlIIlIIIlIIllI("Roofed Forest");
        IIllIlIllIlIllIIlIllIlIII = new IllIlllIIIIlllllllIIIIIII(30, 0).lIIIIIIIIIlIllIIllIlIIlIl(3233098).lIIIIlIIllIIlIIlIIIlIIllI("Cold Taiga").lIIIIlIIllIIlIIlIIIlIIllI(5159473).IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(-0.5185185f * 0.96428573f, 0.6769231f * 0.59090906f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlIlIIIlllIIIlIlllIlIllIl).IlllIIIlIlllIllIlIIlllIlI(16777215);
        lIlIllIlIlIIIllllIlIllIll = new IllIlllIIIIlllllllIIIIIII(31, 0).lIIIIIIIIIlIllIIllIlIIlIl(2375478).lIIIIlIIllIIlIIlIIIlIIllI("Cold Taiga Hills").lIIIIlIIllIIlIIlIIIlIIllI(5159473).IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(0.5060241f * -0.98809516f, 0.8f * 0.5f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII).IlllIIIlIlllIllIlIIlllIlI(16777215);
        IlIIlIIlIllIIIIllIIllIlIl = new IllIlllIIIIlllllllIIIIIII(32, 1).lIIIIIIIIIlIllIIllIlIIlIl(5858897).lIIIIlIIllIIlIIlIIIlIIllI("Mega Taiga").lIIIIlIIllIIlIIlIIIlIIllI(5159473).lIIIIlIIllIIlIIlIIIlIIllI(1.2739726f * 0.23548387f, 3.4f * 0.23529412f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IlIlIIIlllIIIlIlllIlIllIl);
        llllIIIIlIlIllIIIllllIIll = new IllIlllIIIIlllllllIIIIIII(33, 1).lIIIIIIIIIlIllIIllIlIIlIl(4542270).lIIIIlIIllIIlIIlIIIlIIllI("Mega Taiga Hills").lIIIIlIIllIIlIIlIIIlIIllI(5159473).lIIIIlIIllIIlIIlIIIlIIllI(0.9115385f * 0.32911393f, 2.2f * 0.36363637f).lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIllIllIlIlllllllIlIlIII);
        IIlIlIIlIIIlIlllllIIlIIlI = new IlIIlIllIIIlllIIllIIIIIIl(34, true).lIIIIIIIIIlIllIIllIlIIlIl(5271632).lIIIIlIIllIIlIIlIIIlIIllI("Extreme Hills+").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI(0.25151515f * 0.79518074f, 2.612903f * 0.114814825f);
        lIIIlllIIIlIIIIIlIIIIIIII = new lIIIlIlIIIlIIIIlIIIIIIIlI(35).lIIIIIIIIIlIllIIllIlIIlIl(12431967).lIIIIlIIllIIlIIlIIIlIIllI("Savanna").lIIIIlIIllIIlIIlIIIlIIllI(0.39285713f * 3.0545456f, 0.0f).lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIIllIIIIllIllIIIlIl);
        lIIlIIIIIIIIllIIllIIlllIl = new lIIIlIlIIIlIIIIlIIIIIIIlI(36).lIIIIIIIIIlIllIIllIlIIlIl(10984804).lIIIIlIIllIIlIIlIIIlIIllI("Savanna Plateau").lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 0.0f).lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IllIIIIIIIlIlIllllIIllIII);
        IllllllIllllIIlllIllllllI = new lIIlIIIIIlIlIIIIlIIlIllII(37, false, false).lIIIIIIIIIlIllIIllIlIIlIl(14238997).lIIIIlIIllIIlIIlIIIlIIllI("Mesa");
        lIlIlIIIlIIllllllllIIlllI = new lIIlIIIIIlIlIIIIlIIlIllII(38, false, true).lIIIIIIIIIlIllIIllIlIIlIl(11573093).lIIIIlIIllIIlIIlIIIlIIllI("Mesa Plateau F").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IllIIIIIIIlIlIllllIIllIII);
        IlIlllIllIlIllIlllIlllIll = new lIIlIIIIIlIlIIIIlIIlIllII(39, false, false).lIIIIIIIIIlIllIIllIlIIlIl(13274213).lIIIIlIIllIIlIIlIIIlIIllI("Mesa Plateau").lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI.IllIIIIIIIlIlIllllIIllIII);
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lllIIIIIlIllIlIIIllllllII.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIIIIIlIlIlIllllllIlllIlI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IllIllIIIlIIlllIIIllIllII.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IlIIlIIIIlIIIIllllIIlIllI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIlIIllIIIllllIIlllIllIIl.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lIIIIlllIIlIlllllIlIllIII.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIllIlIllIlIllIIlIllIlIII.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lIIIlllIIIlIIIIIlIIIIIIII.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lIIlIIIIIIIIllIIllIIlllIl.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IllllllIllllIIlllIllllllI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lIlIlIIIlIIllllllllIIlllI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IlIlllIllIlIllIlllIlllIll.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IlIIIIllIIIIIlllIIlIIlllI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.llIlIlIllIlIIlIlllIllIIlI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.llIlIlIlllIlllllIIIllIIll.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IlIIlIIlIllIIIIllIIllIlIl.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.lIIIIIllllIIIIlIlIIIIlIlI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIIlIIIlIlllllIIlIIlI.IlIlllIIIIllIllllIllIIlIl();
        IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI[IIlIIlIIllIIllIlIIIIIIIlI.llllIIIIlIlIllIIIllllIIll.IlIllIllIllIllIllllIIIlII + 128] = IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI[IIlIIlIIllIIllIlIIIIIIIlI.IlIIlIIlIllIIIIllIIllIlIl.IlIllIllIllIllIllllIIIlII + 128];
        for (final IIlIIlIIllIIllIlIIIIIIIlI ilIIlIIllIIllIlIIIIIIIlI : IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIlllIllIIlIllIIlIIlI) {
            if (ilIIlIIllIIllIlIIIIIIIlI != null && ilIIlIIllIIllIlIIIIIIIlI.IlIllIllIllIllIllllIIIlII < 128) {
                IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII.add(ilIIlIIllIIllIlIIIIIIIlI);
            }
        }
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII.remove(IIlIIlIIllIIllIlIIIIIIIlI.lIIlllIIlIlllllllllIIIIIl);
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII.remove(IIlIIlIIllIIllIlIIIIIIIlI.lIllIllIlIIllIllIlIlIIlIl);
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII.remove(IIlIIlIIllIIllIlIIIIIIIlI.llIlIIIllIIIIlllIlIIIIIlI);
        IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII.remove(IIlIIlIIllIIllIlIIIIIIIlI.IlIlIIIlllllIIIlIlIlIllII);
        llIIIllIIllllIlIlIlIlIIll = new lIllllIIlIIlIlIlIlIlIllIl(new Random(1234L), 1);
        IIIIIlIllIllIlIIllIIlIllI = new lIllllIIlIIlIlIlIlIlIllIl(new Random(2345L), 1);
        lIIllIIllllllIIlllIlllIIl = new llllIlIlIlIlIllIlllIIllII();
    }
}
