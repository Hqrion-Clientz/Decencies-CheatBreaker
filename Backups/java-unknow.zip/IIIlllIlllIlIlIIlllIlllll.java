import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIlllIlIlIIlllIlllll extends IlIllIIlIIllllllIIlIllIlI
{
    private lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlllIlllIlIlIIlllIlllll(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final int n, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int n2) {
        super(n2);
        this.lIIIIlIIllIIlIIlIIIlIIllI = new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, n);
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public IIIlllIlllIlIlIIlllIlllll(final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int n) {
        super(n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final IIIlllIlllIlIlIIlllIlllll[] array, final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final int n) {
        for (int i = 0; i < n; ++i) {
            final IIIlllIlllIlIlIIlllIlllll iiIlllIlllIlIlIIlllIlllll = (IIIlllIlllIlIlIIlllIlllll)IIIIIllllIlIlllllllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(random, array);
            final int liiiiiiiiIlIllIIllIlIIlIl = iiIlllIlllIlIlIIlllIlllll.lIIIIIIIIIlIllIIllIlIIlIl + random.nextInt(iiIlllIlllIlIlIIlllIlllll.IlllIIIlIlllIllIlIIlllIlI - iiIlllIlllIlIlIIlllIlllll.lIIIIIIIIIlIllIIllIlIIlIl + 1);
            if (iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl() >= liiiiiiiiIlIllIIllIlIIlIl) {
                final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                ilIIlIIllIllllllllIllIII.lIIIIIIIIIlIllIIllIlIIlIl(random.nextInt(ilIIlIIllIllllllllIllIII.IIIIllIIllIIIIllIllIIIlIl()), llIIlllIIIIlllIllIlIlllIl);
            }
            else {
                for (int j = 0; j < liiiiiiiiIlIllIIllIlIIlIl; ++j) {
                    final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl2 = iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                    llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl = 1;
                    ilIIlIIllIllllllllIllIII.lIIIIIIIIIlIllIIllIlIIlIl(random.nextInt(ilIIlIIllIllllllllIllIII.IIIIllIIllIIIIllIllIIIlIl()), llIIlllIIIIlllIllIlIlllIl2);
                }
            }
        }
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final IIIlllIlllIlIlIIlllIlllll[] array, final IlIlIIlllIlIlllIllllllIII ilIlIIlllIlIlllIllllllIII, final int n) {
        for (int i = 0; i < n; ++i) {
            final IIIlllIlllIlIlIIlllIlllll iiIlllIlllIlIlIIlllIlllll = (IIIlllIlllIlIlIIlllIlllll)IIIIIllllIlIlllllllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(random, array);
            final int liiiiiiiiIlIllIIllIlIIlIl = iiIlllIlllIlIlIIlllIlllll.lIIIIIIIIIlIllIIllIlIIlIl + random.nextInt(iiIlllIlllIlIlIIlllIlllll.IlllIIIlIlllIllIlIIlllIlI - iiIlllIlllIlIlIIlllIlllll.lIIIIIIIIIlIllIIllIlIIlIl + 1);
            if (iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl() >= liiiiiiiiIlIllIIllIlIIlIl) {
                final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                ilIlIIlllIlIlllIllllllIII.lIIIIIIIIIlIllIIllIlIIlIl(random.nextInt(ilIlIIlllIlIlllIllllllIII.IIIIllIIllIIIIllIllIIIlIl()), llIIlllIIIIlllIllIlIlllIl);
            }
            else {
                for (int j = 0; j < liiiiiiiiIlIllIIllIlIIlIl; ++j) {
                    final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl2 = iiIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                    llIIlllIIIIlllIllIlIlllIl2.lIIIIIIIIIlIllIIllIlIIlIl = 1;
                    ilIlIIlllIlIlllIllllllIII.lIIIIIIIIIlIllIIllIlIIlIl(random.nextInt(ilIlIIlllIlIlllIllllllIII.IIIIllIIllIIIIllIllIIIlIl()), llIIlllIIIIlllIllIlIlllIl2);
                }
            }
        }
    }
    
    public static IIIlllIlllIlIlIIlllIlllll[] lIIIIlIIllIIlIIlIIIlIIllI(final IIIlllIlllIlIlIIlllIlllll[] array, final IIIlllIlllIlIlIIlllIlllll... array2) {
        final IIIlllIlllIlIlIIlllIlllll[] array3 = new IIIlllIlllIlIlIIlllIlllll[array.length + array2.length];
        int n = 0;
        for (int i = 0; i < array.length; ++i) {
            array3[n++] = array[i];
        }
        for (int length = array2.length, j = 0; j < length; ++j) {
            array3[n++] = array2[j];
        }
        return array3;
    }
}
