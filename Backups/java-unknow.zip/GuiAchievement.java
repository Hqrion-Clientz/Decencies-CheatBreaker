import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiAchievement extends IlIIIlIIlIIllIllllIlIlIll
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private Minecraft lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private String IIIIllIIllIIIIllIllIIIlIl;
    private String IlIlIIIlllIIIlIlllIlIllIl;
    private IIlllIllIlIIIIIlIlllllIIl IIIllIllIlIlllllllIlIlIII;
    private long IllIIIIIIIlIlIllllIIllIII;
    private IIIlIllIIlIllIIIIlIIlIlIl lIIIIllIIlIlIllIIIlIllIlI;
    private boolean IlllIllIlIIIIlIIlIIllIIIl;
    
    public GuiAchievement(final Minecraft liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIllIIlIlIllIIIlIllIlI = new IIIlIllIIlIllIIIIlIIlIlIl();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIllIlIIIIIlIlllllIIl iiIllIllIlIlllllllIlIlIII) {
        this.IIIIllIIllIIIIllIllIIIlIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("achievement.get", new Object[0]);
        this.IlIlIIIlllIIIlIlllIlIllIl = iiIllIllIlIlllllllIlIlIII.IIIIllIIllIIIIllIllIIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        this.IllIIIIIIIlIlIllllIIllIII = Minecraft.getSystemTime();
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.IlllIllIlIIIIlIIlIIllIIIl = false;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIlllIllIlIIIIIlIlllllIIl iiIllIllIlIlllllllIlIlIII) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiIllIllIlIlllllllIlIlIII.IIIIllIIllIIIIllIllIIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        this.IlIlIIIlllIIIlIlllIlIllIl = iiIllIllIlIlllllllIlIlIII.IlIlIIIlllIIIlIlllIlIllIl();
        this.IllIIIIIIIlIlIllllIIllIII = Minecraft.getSystemTime() + 2500L;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.IlllIllIlIIIIlIIlIIllIIIl = true;
    }
    
    private void updateScreen() {
        GL11.glViewport(0, 0, this.lIIIIIIIIIlIllIIllIlIIlIl.displayWidth, this.lIIIIIIIIIlIllIIllIlIIlIl.displayHeight);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl.displayWidth;
        this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIIIIIIlIllIIllIlIIlIl.displayHeight;
        final ScaledResolution scaledResolution = new ScaledResolution(this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl.displayWidth, this.lIIIIIIIIIlIllIIllIlIIlIl.displayHeight);
        this.IlllIIIlIlllIllIlIIlllIlI = scaledResolution.getScaledWidth();
        this.IIIIllIlIIIllIlllIlllllIl = scaledResolution.getScaledHeight();
        GL11.glClear(256);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)this.IlllIIIlIlllIllIlIIlllIlI, (double)this.IIIIllIlIIIllIlllIlllllIl, 0.0, (double)1000, (double)3000);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, (float)(-2000));
    }
    
    public void updateTick() {
        if (this.IIIllIllIlIlllllllIlIlIII != null && this.IllIIIIIIIlIlIllllIIllIII != 0L && Minecraft.getMinecraft().thePlayer != null) {
            double n = (Minecraft.getSystemTime() - this.IllIIIIIIIlIlIllllIIllIII) / (double)3000;
            if (!this.IlllIllIlIIIIlIIlIIllIIIl) {
                if (n < 0.0 || n > 1.0) {
                    this.IllIIIIIIIlIlIllllIIllIII = 0L;
                    return;
                }
            }
            else if (n > 3.045454502105713 * 0.16417910681452832) {
                n = 0.10101010490225223 * 4.949999809265137;
            }
            this.updateScreen();
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            double n2 = n * 2;
            if (n2 > 1.0) {
                n2 = 2 - n2;
            }
            double n3 = 1.0 - n2 * 4;
            if (n3 < 0.0) {
                n3 = 0.0;
            }
            final double n4 = n3 * n3;
            final double n5 = n4 * n4;
            final int n6 = this.IlllIIIlIlllIllIlIIlllIlI - 160;
            final int n7 = 0 - (int)(n5 * 36);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(3553);
            this.lIIIIIIIIIlIllIIllIlIIlIl.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiAchievement.lIIIIlIIllIIlIIlIIIlIIllI);
            GL11.glDisable(2896);
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n6, n7, 96, 202, 160, 32);
            if (this.IlllIllIlIIIIlIIlIIllIIIl) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl, n6 + 30, n7 + 7, 120, -1);
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl.fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl, n6 + 30, n7 + 7, -256);
                this.lIIIIIIIIIlIllIIllIlIIlIl.fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlIIIlllIIIlIlllIlIllIl, n6 + 30, n7 + 18, -1);
            }
            llIlIlllllIIllIIIIllIllII.IlllIIIlIlllIllIlIIlllIlI();
            GL11.glDisable(2896);
            GL11.glEnable(32826);
            GL11.glEnable(2903);
            GL11.glEnable(2896);
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl.fontRendererObj, this.lIIIIIIIIIlIllIIllIlIIlIl.llIlIlIllIlIIlIlllIllIIlI(), this.IIIllIllIlIlllllllIlIlIII.IIIIllIlIIIllIlllIlllllIl, n6 + 8, n7 + 8);
            GL11.glDisable(2896);
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IIIllIllIlIlllllllIlIlIII = null;
        this.IllIIIIIIIlIlIllllIIllIII = 0L;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/gui/achievement/achievement_background.png");
    }
}
