import java.beans.ConstructorProperties;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIllllIIllllllIlIIIll extends IIIlllIIIllIllIlIIIIIIlII
{
    private List lIIIIlIIllIIlIIlIIIlIIllI;
    private double lIIIIIIIIIlIllIIllIlIIlIl;
    private double IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    
    @ConstructorProperties({ "boxes", "x", "y", "z" })
    public IIIlIIllllIIllllllIlIIIll(final List liiiIlIIllIIlIIlIIIlIIllI, final double liiiiiiiiIlIllIIllIlIIlIl, final double illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public IIIlIIllllIIllllllIlIIIll() {
    }
    
    public List lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public double IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public double IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public double IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
}
