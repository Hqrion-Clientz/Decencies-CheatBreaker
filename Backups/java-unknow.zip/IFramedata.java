import java.nio.ByteBuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IFramedata
{
    boolean IIIIllIIllIIIIllIllIIIlIl();
    
    boolean IlIlIIIlllIIIlIlllIlIllIl();
    
    boolean IIIllIllIlIlllllllIlIlIII();
    
    boolean IllIIIIIIIlIlIllllIIllIII();
    
    boolean lIIIIllIIlIlIllIIIlIllIlI();
    
    DELETE_ME_E IlllIllIlIIIIlIIlIIllIIIl();
    
    ByteBuffer IIIIllIlIIIllIlllIlllllIl();
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IFramedata p0);
}
