import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIlIllIIlIllIIllIlI extends IIlllllllIlllIIllllIIlIll
{
    public IIIIlllIlIllIIlIllIIllIlI() {
        super(Material.IllIIlIIlllllIllIIIlllIII);
        this.lIIIIlIIllIIlIIlIIIlIIllI(2.25f * 0.027777778f, 0.0f, 0.0051020407f * 12.25f, 0.05357143f * 17.5f, 1.0f, 1.3939394f * 0.6725544f);
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    private void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, int n2, final int n3) {
        if (lIIIIIllIlIIIllllIlIlIIIl.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && n2 >= 0) {
            final int n4 = 32;
            if (!lIIIIIllIlIIIllllIlIlIIIl.IIIIlIIIlllllllllIlllIlll && iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(n - n4, n2 - n4, n3 - n4, n + n4, n2 + n4, n3 + n4)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(new IIIllllIllIlIllIlIIIIIIlI(iiiiiIllIlIIIIlIlllIllllI, n + 1.8333333f * 0.27272728f, n2 + 0.8028169f * 0.622807f, n3 + 0.40972224f * 1.220339f, this));
            }
            else {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                while (lIIIIIllIlIIIllllIlIlIIIl.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && n2 > 0) {
                    --n2;
                }
                if (n2 > 0) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this, 0, 2);
                }
            }
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    private void IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == this) {
            for (int i = 0; i < 1000; ++i) {
                final int n4 = n + iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(16) - iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(16);
                final int n5 = n2 + iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(8) - iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(8);
                final int n6 = n3 + iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(16) - iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(16);
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n4, n5, n6).IllIIlllIllIlIllIlIIIIIII == Material.air) {
                    if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
                        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n6, this, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 2);
                        iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                    }
                    else {
                        for (int n7 = 128, j = 0; j < n7; ++j) {
                            final double nextDouble = iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextDouble();
                            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("portal", n4 + (n - n4) * nextDouble + (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextDouble() - 19.49999974574894 * 0.025641025975346565) * 1.0 + 0.3285714296905362 * 1.52173912525177, n5 + (n2 - n5) * nextDouble + iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextDouble() * 1.0 - 0.11538461115233307 * 4.333333492279053, n6 + (n3 - n6) * nextDouble + (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextDouble() - 0.07692307692307693 * 6.5) * 1.0 + 0.1855670064687729 * 2.694444500208822, (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() - 0.23239435f * 2.1515152f) * (2.0333333f * 0.09836066f), (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() - 0.31958762f * 1.5645162f) * (0.034883723f * 5.733333f), (iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextFloat() - 0.8229167f * 0.6075949f) * (0.15421687f * 1.296875f));
                        }
                    }
                    return;
                }
            }
        }
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return 5;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 27;
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(0);
    }
}
