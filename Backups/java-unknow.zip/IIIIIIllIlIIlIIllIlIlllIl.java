// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIlIIlIIllIlIlllIl implements Comparable
{
    private IlIlIlIIIIIIllIIIlllIIIIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIIIllIlIIlIIllIlIlllIl(final IlIlIlIIIIIIllIIIlllIIIIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int func_76329_a() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl().lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.getIdentifier();
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII();
    }
    
    public boolean getIsKeyPressed() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII();
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.getIsKeyPressed();
    }
    
    public String IlIlIIIlllIIIlIlllIlIllIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public long IIIllIllIlIlllllllIlIlIII() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIlIIIIIIllIIIlllIIIIl ilIlIlIIIIIIllIIIlllIIIIl) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(ilIlIlIIIIIIllIIIlllIIIIl);
    }
    
    public long IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIlIIllIlIlllIl iiiiiIllIlIIlIIllIlIlllIl) {
        return (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl() < iiiiiIllIlIIlIIllIlIlllIl.IIIllIllIlIlllllllIlIlIII()) ? 1 : ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl() > iiiiiIllIlIIlIIllIlIlllIl.IIIllIllIlIlllllllIlIlIII()) ? -1 : this.lIIIIlIIllIIlIIlIIIlIIllI.getIdentifier().compareTo(iiiiiIllIlIIlIIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl()));
    }
    
    @Override
    public int compareTo(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIIIIIllIlIIlIIllIlIlllIl)o);
    }
}
