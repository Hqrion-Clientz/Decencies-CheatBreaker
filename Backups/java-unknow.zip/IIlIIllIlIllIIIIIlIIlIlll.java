import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlIllIIIIIlIIlIlll
{
    private ISaveFormat lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIllIlIllIIIIIlIIlIlll(final ISaveFormat liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(s);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String s, final IlIllIlllllllIlIlllIIlIlI ilIllIlllllllIlIlllIIlIlI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s, ilIllIlllllllIlIlllIIlIlI);
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(s);
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(s);
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(s);
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final String s2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s, s2);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl();
    }
    
    public List IlllIIIlIlllIllIlIIlllIlI() {
        final ArrayList<IIIIIIllIlIIlIIllIlIlllIl> list = new ArrayList<IIIIIIllIlIIlIIllIlIlllIl>();
        final Iterator<IlIlIlIIIIIIllIIIlllIIIIl> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().iterator();
        while (iterator.hasNext()) {
            list.add(new IIIIIIllIlIIlIIllIlIlllIl(iterator.next()));
        }
        return list;
    }
}
