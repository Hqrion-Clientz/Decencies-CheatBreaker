// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIlIIIlllIIIIlIlIIll extends GuiScreen
{
    private final GuiScreen lIIIIlIIllIIlIIlIIIlIIllI;
    private lIIlIIIIlIIIIIllIIIIlIIll lIIIIIIIIIlIllIIllIlIIlIl;
    private lIIlIIIIlIIIIIllIIIIlIIll IlllIIIlIlllIllIlIIlllIlI;
    private String IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIIlIlIIIlllIIIIlIlIIll(final GuiScreen liiiIlIIllIIlIIlIIIlIIllI) {
        this.IIIIllIlIIIllIlllIlllllIl = "survival";
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.clear();
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(101, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155, this.IIIIIIlIlIlIllllllIlllIlI - 28, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("lanServer.start", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(102, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 5, this.IIIIIIlIlIlIllllllIlllIlI - 28, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.cancel", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(this.IlllIIIlIlllIllIlIIlllIlI = new lIIlIIIIlIIIIIllIIIIlIIll(104, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155, 100, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.gameMode", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(this.lIIIIIIIIIlIllIIllIlIIlIl = new lIIlIIIIlIIIIIllIIIIlIIll(103, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 5, 100, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.allowCommands", new Object[0])));
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        this.IlllIIIlIlllIllIlIIlllIlI.IllIIIIIIIlIlIllllIIllIII = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.gameMode", new Object[0]) + " " + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.gameMode." + this.IIIIllIlIIIllIlllIlllllIl, new Object[0]);
        this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("selectWorld.allowCommands", new Object[0]) + " ";
        if (this.IIIIllIIllIIIIllIllIIIlIl) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII += IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.on", new Object[0]);
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII += IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("options.off", new Object[0]);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 102) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 104) {
            if (this.IIIIllIlIIIllIlllIlllllIl.equals("survival")) {
                this.IIIIllIlIIIllIlllIlllllIl = "creative";
            }
            else if (this.IIIIllIlIIIllIlllIlllllIl.equals("creative")) {
                this.IIIIllIlIIIllIlllIlllllIl = "adventure";
            }
            else {
                this.IIIIllIlIIIllIlllIlllllIl = "survival";
            }
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 103) {
            this.IIIIllIIllIIIIllIllIIIlIl = !this.IIIIllIIllIIIIllIllIIIlIl;
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 101) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
            final String liiiIlIIllIIlIIlIIIlIIllI = this.lllIIIIIlIllIlIIIllllllII.IlIlIIIlllllIIIlIlIlIllII().lIIIIlIIllIIlIIlIIIlIIllI(IllIIlIIlIlIIllllIIIlIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl), this.IIIIllIIllIIIIllIllIIIlIl);
            llIlIlIllIIIIlIlIIllllIlI llIlIlIllIIIIlIlIIllllIlI;
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                llIlIlIllIIIIlIlIIllllIlI = new IIIlIlIIIlllllIIlllIIIlIl("commands.publish.started", new Object[] { liiiIlIIllIIlIIlIIIlIIllI });
            }
            else {
                llIlIlIllIIIIlIlIIllllIlI = new lIlIIllIIlIIIIIlIllIllllI("commands.publish.failed");
            }
            this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIllIIIIlIlIIllllIlI);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("lanServer.title", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 50, 16777215);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("lanServer.otherPlayers", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 82, 16777215);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
}
