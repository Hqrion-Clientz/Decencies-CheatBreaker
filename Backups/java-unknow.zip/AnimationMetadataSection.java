import java.util.Iterator;
import java.util.HashSet;
import com.google.common.collect.Sets;
import java.util.Set;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class AnimationMetadataSection implements IllIlIIlIIIIIIllIllIllIIl
{
    private final List lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final int IIIIllIlIIIllIlllIlllllIl;
    
    public AnimationMetadataSection(final List liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.size();
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    private lIIIIlIlIIllllllIlIIllIIl IIIIllIlIIIllIlllIlllllIl(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.get(n);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        final lIIIIlIlIIllllllIlIIllIIl iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl(n);
        return iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() ? this.IIIIllIlIIIllIlllIlllllIl : iiiIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return !this.lIIIIlIIllIIlIIlIIIlIIllI.get(n).lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.get(n).IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public Set IIIIllIIllIIIIllIllIIIlIl() {
        final HashSet hashSet = Sets.newHashSet();
        final Iterator<lIIIIlIlIIllllllIlIIllIIl> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI.iterator();
        while (iterator.hasNext()) {
            hashSet.add(iterator.next().IlllIIIlIlllIllIlIIlllIlI());
        }
        return hashSet;
    }
}
