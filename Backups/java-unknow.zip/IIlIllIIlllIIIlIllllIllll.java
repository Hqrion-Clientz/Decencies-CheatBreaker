import org.apache.logging.log4j.LogManager;
import java.util.Iterator;
import java.io.IOException;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import com.google.common.collect.Lists;
import java.util.List;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIlllIIIlIllllIllll extends IIllIIIIllllIIIlIlIIIlIlI
{
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    public final List lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIllIIlllIIIlIllllIllll(final String... array) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Lists.newArrayList((Object[])array);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        this.unloadSounds();
        BufferedImage bufferedImage = null;
        try {
            for (final String s : this.lIIIIlIIllIIlIIlIIIlIIllI) {
                if (s != null) {
                    final BufferedImage read = ImageIO.read(llIllIllIllIIIIlIlllllIlI.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation(s)).lIIIIlIIllIIlIIlIIIlIIllI());
                    if (bufferedImage == null) {
                        bufferedImage = new BufferedImage(read.getWidth(), read.getHeight(), 2);
                    }
                    bufferedImage.getGraphics().drawImage(read, 0, 0, null);
                }
            }
        }
        catch (IOException ex) {
            IIlIllIIlllIIIlIllllIllll.lIIIIIIIIIlIllIIllIlIIlIl.error("Couldn't load layered image", (Throwable)ex);
            return;
        }
        lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(), bufferedImage);
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
    }
}
