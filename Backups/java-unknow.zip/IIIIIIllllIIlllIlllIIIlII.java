import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllllIIlllIlllIIIlII extends IIlllllllIlllIIllllIIlIll
{
    protected IIIIIIllllIIlllIlllIIIlII() {
        super(Material.lllIIIIIlIllIlIIIllllllII);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.IllIIIIIIIlIlIllllIIllIII(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int n) {
        final float n2 = 0.90625f * 0.13793103f;
        if (n == 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 1.0f - n2, 1.0f, 1.0f, 1.0f);
        }
        if (n == 3) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, n2);
        }
        if (n == 4) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f - n2, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        if (n == 5) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, n2, 1.0f, 1.0f);
        }
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 8;
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI();
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final int n8) {
        int n9 = n8;
        if ((n8 == 0 || n4 == 2) && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI()) {
            n9 = 2;
        }
        if ((n9 == 0 || n4 == 3) && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI()) {
            n9 = 3;
        }
        if ((n9 == 0 || n4 == 4) && iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            n9 = 4;
        }
        if ((n9 == 0 || n4 == 5) && iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            n9 = 5;
        }
        return n9;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        boolean b = false;
        if (illlIIIlIlllIllIlIIlllIlI == 2 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI()) {
            b = true;
        }
        if (illlIIIlIlllIllIlIIlllIlI == 3 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI()) {
            b = true;
        }
        if (illlIIIlIlllIllIlIIlllIlI == 4 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            b = true;
        }
        if (illlIIIlIlllIllIlIIlllIlI == 5 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            b = true;
        }
        if (!b) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 0);
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        return 1;
    }
}
