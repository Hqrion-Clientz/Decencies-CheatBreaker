import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlllIIllllIIIlIllllll
{
    IlllIIIllIlIIlIllIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI;
    List lIIIIIIIIIlIllIIllIlIIlIl;
    List IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIlllIIllllIIIlIllllll(final IlllIIIllIlIIlIllIIlIlllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
        this.IlllIIIlIlllIllIlIIlllIlI.clear();
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.contains(entity)) {
            return true;
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI.contains(entity)) {
            return false;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("canSee");
        final boolean llIlIIIlIIIIlIlllIlIIIIll = this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll(entity);
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        if (llIlIIIlIIIIlIlllIlIIIIll) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(entity);
        }
        else {
            this.IlllIIIlIlllIllIlIIlllIlI.add(entity);
        }
        return llIlIIIlIIIIlIlllIlIIIIll;
    }
}
