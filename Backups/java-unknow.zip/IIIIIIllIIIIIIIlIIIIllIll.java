// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIIIIIIIlIIIIllIll
{
    private final int lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final int IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIIIIllIIIIIIIlIIIIllIll(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(int iiiIllIIllIIIIllIllIIIlIl) {
        if (iiiIllIIllIIIIllIllIIIlIl > 10) {
            iiiIllIIllIIIIllIllIIIlIl = 10;
        }
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
}
