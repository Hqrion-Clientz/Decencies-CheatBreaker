import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IIlIlIlIIlIIIIIIlIIlIIlll
{
    void lIIIIlIIllIIlIIlIIIlIIllI();
    
    WorldRenderer lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI p0, final List p1, final int p2, final int p3, final int p4, final int p5);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final RenderGlobal p0, final EntityLivingBase p1);
    
    void lIIIIIIIIIlIllIIllIlIIlIl();
    
    boolean lIIIIlIIllIIlIIlIIIlIIllI(final RenderGlobal p0, final EntityLivingBase p1, final boolean p2);
    
    void IlllIIIlIlllIllIlIIlllIlI();
    
    void IIIIllIlIIIllIlllIlllllIl();
    
    void IIIIllIIllIIIIllIllIIIlIl();
    
    void IlIlIIIlllIIIlIlllIlIllIl();
    
    void IIIllIllIlIlllllllIlIlIII();
}
