// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlllllIllllIllIIlIIII extends llIllIlIlIIIIlIIIIllIllll
{
    private final IlIllIllIlIIlIlllIlIIllll IlllIllIlIIIIlIIlIIllIIIl;
    
    public IIIlIlllllIllllIllIIlIIII(final IlIllIllIlIIlIlllIlIIllll illlIllIlIIIIlIIlIIllIIIl) {
        super(illlIllIlIIIIlIIlIIllIIIl);
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IIIIllIIllIIIIllIllIIIlIl(0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final int n) {
        return n | 0x4;
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(0, n);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n) {
        return this.IlllIllIlIIIIlIIlIIllIIIl.IlIlIIIlllIIIlIlllIlIllIl(lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl());
    }
    
    @Override
    public String IlllIIIlIlllIllIlIIlllIlI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        int illlIllIlIIIIlIIlIIllIIIl = lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl();
        if (illlIllIlIIIIlIIlIIllIIIl < 0 || illlIllIlIIIIlIIlIIllIIIl >= this.IlllIllIlIIIIlIIlIIllIIIl.IIIIlIIIlllllllllIlllIlll().length) {
            illlIllIlIIIIlIIlIIllIIIl = 0;
        }
        return super.IlllIllIlIIIIlIIlIIllIIIl() + "." + this.IlllIllIlIIIIlIIlIIllIIIl.IIIIlIIIlllllllllIlllIlll()[illlIllIlIIIIlIIlIIllIIIl];
    }
}
