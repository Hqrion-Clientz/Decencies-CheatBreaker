import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIllIIIIIIIlIIlllIII implements Comparator
{
    private final Entity lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIlIllIIIIIIIlIIlllIII(final Entity liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final Entity entity2) {
        final double iiiIllIIllIIIIllIllIIIlIl = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(entity);
        final double iiiIllIIllIIIIllIllIIIlIl2 = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(entity2);
        return (iiiIllIIllIIIIllIllIIIlIl < iiiIllIIllIIIIllIllIIIlIl2) ? -1 : (iiiIllIIllIIIIllIllIIIlIl > iiiIllIIllIIIIllIllIIIlIl2);
    }
    
    @Override
    public int compare(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((Entity)o, (Entity)o2);
    }
}
