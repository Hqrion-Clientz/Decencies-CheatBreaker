// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlIlIllIlIIIIIlIlll extends IlIIIIlllIlIIllIIIIlIIIlI
{
    public boolean lIIlIlIllIIlIIIlIIIlllIII;
    private lIIIIllllIlIIIIllIllIIlIl IIIlllIIIllIllIlIIIIIIlII;
    private lIIIIllllIlIIIIllIllIIlIl llIlIIIlIIIIlIlllIlIIIIll;
    
    public IIIIIIIlIlIllIlIIIIIlIlll(final float n) {
        super(n, 0.0f, 64, 128);
        (this.IIIlllIIIllIllIlIIIIIIlII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(64, 128)).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -2, 0.0f);
        this.IIIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(0, 0).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 3, 0.7244898f * -9.316901f, 1, 1, 1, 0.26666668f * -0.93749994f);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlllIIIllIllIlIIIIIIlII);
        (this.llIlIIIlIIIIlIlllIlIIIIll = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(64, 128)).lIIIIlIIllIIlIIlIIIlIIllI(-5, -33.206894f * 0.30208334f, -5);
        this.llIlIIIlIIIIlIlllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(0, 64).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 10, 2, 10);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIIIlIIIIlIlllIlIIIIll);
        final lIIIIllllIlIIIIllIllIIlIl liiiiiiiiIlIllIIllIlIIlIl = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(64, 128);
        liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(3.4027777f * 0.51428574f, -4, 2.0f);
        liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(0, 76).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 7, 4, 7);
        liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl = -0.10471976f * 0.5f;
        liiiiiiiiIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII = 0.95652175f * 0.027369937f;
        this.llIlIIIlIIIIlIlllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl);
        final lIIIIllllIlIIIIllIllIIlIl liiiiiiiiIlIllIIllIlIIlIl2 = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(64, 128);
        liiiiiiiiIlIllIIllIlIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(0.4920635f * 3.5564516f, -4, 2.0f);
        liiiiiiiiIlIllIIllIlIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(0, 87).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 4, 4, 4);
        liiiiiiiiIlIllIIllIlIIlIl2.IlIlIIIlllIIIlIlllIlIllIl = -0.12341971f * 0.8484849f;
        liiiiiiiiIlIllIIllIlIIlIl2.IllIIIIIIIlIlIllllIIllIII = 0.12736186f * 0.41111112f;
        liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl2);
        final lIIIIllllIlIIIIllIllIIlIl liiiiiiiiIlIllIIllIlIIlIl3 = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(64, 128);
        liiiiiiiiIlIllIIllIlIIlIl3.lIIIIlIIllIIlIIlIIIlIIllI(40.0f * 0.04375f, -2, 2.0f);
        liiiiiiiiIlIllIIllIlIIlIl3.lIIIIlIIllIIlIIlIIIlIIllI(0, 95).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1, 2, 1, 1.0111111f * 0.24725275f);
        liiiiiiiiIlIllIIllIlIIlIl3.IlIlIIIlllIIIlIlllIlIllIl = 0.4528302f * -0.46251225f;
        liiiiiiiiIlIllIIllIlIIlIl3.IllIIIIIIIlIlIllllIIllIII = 0.11126474f * 0.9411765f;
        liiiiiiiiIlIllIIllIlIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Entity entity) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, n6, entity);
        final lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl = this.llIIlllIIIIlllIllIlIlllIl;
        final lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl2 = this.llIIlllIIIIlllIllIlIlllIl;
        final lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl3 = this.llIIlllIIIIlllIllIlIlllIl;
        final float llIlIIIlIIIIlIlllIlIIIIll = 0.0f;
        llIIlllIIIIlllIllIlIlllIl3.lllIIIIIlIllIlIIIllllllII = llIlIIIlIIIIlIlllIlIIIIll;
        llIIlllIIIIlllIllIlIlllIl2.IIIlIIllllIIllllllIlIIIll = llIlIIIlIIIIlIlllIlIIIIll;
        llIIlllIIIIlllIllIlIlllIl.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
        final float n7 = 0.0053333333f * 1.875f * (entity.lIIIIlllIIlIlllllIlIllIII() % 10);
        this.llIIlllIIIIlllIllIlIlllIl.IlIlIIIlllIIIlIlllIlIllIl = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(entity.IIIlIllIlllIlIllIllllllll * n7) * (1.3651686f * 3.2962964f) * (4.3982296f * 0.71428573f) / 180;
        this.llIIlllIIIIlllIllIlIlllIl.IIIllIllIlIlllllllIlIlIII = 0.0f;
        this.llIIlllIIIIlllIllIlIlllIl.IllIIIIIIIlIlIllllIIllIII = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(entity.IIIlIllIlllIlIllIllllllll * n7) * (1.3243244f * 1.887755f) * (1.4923077f * 2.105191f) / 180;
        if (this.lIIlIlIllIIlIIIlIIIlllIII) {
            this.llIIlllIIIIlllIllIlIlllIl.IlIlIIIlllIIIlIlllIlIllIl = -0.88988763f * 1.0113636f;
            this.llIIlllIIIIlllIllIlIlllIl.lllIIIIIlIllIlIIIllllllII = -0.11484375f * 0.81632656f;
            this.llIIlllIIIIlllIllIlIlllIl.IIIlIIllllIIllllllIlIIIll = 0.16915761f * 1.1084337f;
        }
    }
}
