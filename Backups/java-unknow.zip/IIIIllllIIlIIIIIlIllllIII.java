import java.util.Arrays;
import java.util.Collection;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllllIIlIIIIIlIllllIII extends Entity
{
    private static final List IIIIllIlIIIllIlllIlllllIl;
    private static final List IIIIllIIllIIIIllIllIIIlIl;
    private static final List IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private IIlllllllIlllIIllllIIlIll IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl;
    private int llIIlllIIIIlllIllIlIlllIl;
    private int lIIlIlIllIIlIIIlIIIlllIII;
    private int IIIlllIIIllIllIlIIIIIIlII;
    private int llIlIIIlIIIIlIlllIlIIIIll;
    private int IIIlIIllllIIllllllIlIIIll;
    private float lllIIIIIlIllIlIIIllllllII;
    public Entity IlllIIIlIlllIllIlIIlllIlI;
    private int lIlIIllIIIlllIIllIIlIIllI;
    private double lIIIlIIIIIIlIIlIIlIIlIIlI;
    private double lIlIlIlIIlIlllIIIIIIllllI;
    private double llllIIllIIlllllIlIlIIllll;
    private double IllIlIIIIlIlllIlllllllIIl;
    private double IIlllllIIlIlIIlIIlllIIIII;
    private double IllIlIlllIIlIIIIIlIIIIIll;
    private double llllIlIlIlllllIllIIllIIIl;
    private double lllIIlIIllIllIIllIIlIIIIl;
    
    public IIIIllllIIlIIIIIlIllllIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.IllIIIIIIIlIlIllllIIllIII = -1;
        this.lIIIIllIIlIlIllIIIlIllIlI = -1;
        this.IIIIllIIllIIIIllIllIIIlIl(1.8113208f * 0.13802083f, 1.3235294f * 0.18888889f);
        this.IllIIIIllllllIlllllIlIlll = true;
    }
    
    public IIIIllllIIlIIIIIlIllllIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final lIllIIIIlIIlIllIIIlIlIlll liiiiiiiiIlIllIIllIlIIlIl) {
        this(iiiiiIllIlIIIIlIlllIllllI);
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        this.IllIIIIllllllIlllllIlIlll = true;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        liiiiiiiiIlIllIIllIlIIlIl.IlIIIIlllIIIlIIllllIIIlll = this;
    }
    
    public IIIIllllIIlIIIIIlIllllIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll liiiiiiiiIlIllIIllIlIIlIl) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.IllIIIIIIIlIlIllllIIllIII = -1;
        this.lIIIIllIIlIlIllIIIlIllIlI = -1;
        this.IllIIIIllllllIlllllIlIlll = true;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        (this.lIIIIIIIIIlIllIIllIlIIlIl.IlIIIIlllIIIlIIllllIIIlll = this).IIIIllIIllIIIIllIllIIIlIl(2.4f * 0.104166664f, 0.13432835f * 1.8611112f);
        this.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll, liiiiiiiiIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI + 0.20481927692890167 * 7.90941177163879 - liiiiiiiiIlIllIIllIlIIlIl.lIlIllIlIlIIIllllIlIllIll, liiiiiiiiIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll, liiiiiiiiIlIllIIllIlIIlIl.IllllIllllIlIIIlIIIllllll, liiiiiiiiIlIllIIllIlIIlIl.IllIIlllIllIlIllIlIIIIIII);
        this.IIIlIIlIlIIIlllIIlIllllll -= MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll / 180 * (3.3333333f * 0.9424778f)) * (4.3f * 0.0372093f);
        this.IllIlIIIIlllIIllIIlllIIlI -= 1.091953992843628 * 0.09157895126121537;
        this.IllIlIlIllllIlIIllllIIlll -= MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll / 180 * (9.873577f * 0.3181818f)) * (0.03409836f * 4.6923075f);
        this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        final float n = 1.4081633f * 0.28405797f;
        this.IllIIlIIlllllIllIIIlllIII = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll / 180 * (4.3196898f * 0.72727275f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllIIlllIllIlIllIlIIIIIII / 180 * (0.7139983f * 4.4f)) * n;
        this.IlllIIlllIIIIllIIllllIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll / 180 * (2.195122f * 1.43117f)) * MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllIIlllIllIlIllIlIIIIIII / 180 * (0.71428573f * 4.3982296f)) * n;
        this.lIlIlIllIIIIIIIIllllIIllI = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlllIllIlIllIlIIIIIII / 180 * (2.987088f * 1.0517242f)) * n;
        this.IlllIIIlIlllIllIlIIlllIlI(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl, 1.3134328f * 1.1420455f, 1.0f);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        final double n2 = this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI() * 4 * 64;
        return n < n2 * n2;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(double n, double n2, double n3, final float n4, final float n5) {
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n2 * n2 + n3 * n3);
        n /= liiiIlIIllIIlIIlIIIlIIllI;
        n2 /= liiiIlIIllIIlIIlIIIlIIllI;
        n3 /= liiiIlIIllIIlIIlIIIlIIllI;
        n += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (2.222222328186035 * 0.0033749997636303417) * n5;
        n2 += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.043269230149267514 * 0.1733333319425583) * n5;
        n3 += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (1.4210525751113892 * 0.005277777869530302) * n5;
        n *= n4;
        n2 *= n4;
        n3 *= n4;
        this.IllIIlIIlllllIllIIIlllIII = n;
        this.lIlIlIllIIIIIIIIllllIIllI = n2;
        this.IlllIIlllIIIIllIIllllIlIl = n3;
        final float liiiIlIIllIIlIIlIIIlIIllI2 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n3 * n3);
        final float n6 = (float)(Math.atan2(n, n3) * 180 / (0.030927835032343864 * 101.578162529138));
        this.IllllIllllIlIIIlIIIllllll = n6;
        this.IlIlIIIlllllIIIlIlIlIllII = n6;
        final float n7 = (float)(Math.atan2(n2, liiiIlIIllIIlIIlIIIlIIllI2) * 180 / (3.8301609846147424 * 0.8202247023582458));
        this.IllIIlllIllIlIllIlIIIIIII = n7;
        this.IIlIIllIIIllllIIlllIllIIl = n7;
        this.llIIlllIIIIlllIllIlIlllIl = 0;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double liiIlIIIIIIlIIlIIlIIlIIlI, final double lIlIlIlIIlIlllIIIIIIllllI, final double llllIIllIIlllllIlIlIIllll, final float n, final float n2, final int lIlIIllIIIlllIIllIIlIIllI) {
        this.lIIIlIIIIIIlIIlIIlIIlIIlI = liiIlIIIIIIlIIlIIlIIlIIlI;
        this.lIlIlIlIIlIlllIIIIIIllllI = lIlIlIlIIlIlllIIIIIIllllI;
        this.llllIIllIIlllllIlIlIIllll = llllIIllIIlllllIlIlIIllll;
        this.IllIlIIIIlIlllIlllllllIIl = n;
        this.IIlllllIIlIlIIlIIlllIIIII = n2;
        this.lIlIIllIIIlllIIllIIlIIllI = lIlIIllIIIlllIIllIIlIIllI;
        this.IllIIlIIlllllIllIIIlllIII = this.IllIlIlllIIlIIIIIlIIIIIll;
        this.lIlIlIllIIIIIIIIllllIIllI = this.llllIlIlIlllllIllIIllIIIl;
        this.IlllIIlllIIIIllIIllllIlIl = this.lllIIlIIllIllIIllIIlIIIIl;
    }
    
    @Override
    public void lIIIIllIIlIlIllIIIlIllIlI(final double n, final double n2, final double n3) {
        this.IllIIlIIlllllIllIIIlllIII = n;
        this.IllIlIlllIIlIIIIIlIIIIIll = n;
        this.lIlIlIllIIIIIIIIllllIIllI = n2;
        this.llllIlIlIlllllIllIIllIIIl = n2;
        this.IlllIIlllIIIIllIIllllIlIl = n3;
        this.lllIIlIIllIllIIllIIlIIIIl = n3;
    }
    
    @Override
    public void x_() {
        super.x_();
        if (this.lIlIIllIIIlllIIllIIlIIllI > 0) {
            final double n = this.IIIlIIlIlIIIlllIIlIllllll + (this.lIIIlIIIIIIlIIlIIlIIlIIlI - this.IIIlIIlIlIIIlllIIlIllllll) / this.lIlIIllIIIlllIIllIIlIIllI;
            final double n2 = this.IllIlIIIIlllIIllIIlllIIlI + (this.lIlIlIlIIlIlllIIIIIIllllI - this.IllIlIIIIlllIIllIIlllIIlI) / this.lIlIIllIIIlllIIllIIlIIllI;
            final double n3 = this.IllIlIlIllllIlIIllllIIlll + (this.llllIIllIIlllllIlIlIIllll - this.IllIlIlIllllIlIIllllIIlll) / this.lIlIIllIIIlllIIllIIlIIllI;
            this.IllllIllllIlIIIlIIIllllll += (float)(MathHelper.IIIllIllIlIlllllllIlIlIII(this.IllIlIIIIlIlllIlllllllIIl - this.IllllIllllIlIIIlIIIllllll) / this.lIlIIllIIIlllIIllIIlIIllI);
            this.IllIIlllIllIlIllIlIIIIIII += (float)((this.IIlllllIIlIlIIlIIlllIIIII - this.IllIIlllIllIlIllIlIIIIIII) / this.lIlIIllIIIlllIIllIIlIIllI);
            --this.lIlIIllIIIlllIIllIIlIIllI;
            this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
        }
        else {
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                final lIlIlIlIlIllllIlllIIIlIlI liiiiiIlIIllIlIlIllIIIIll = this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIlIIllIlIlIllIIIIll();
                if (this.lIIIIIIIIIlIllIIllIlIIlIl.IIllIlIllIlIllIIlIllIlIII || !this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlllIIIIlIllIlllIlIIIll() || liiiiiIlIIllIlIlIllIIIIll == null || liiiiiIlIIllIlIlIllIIIIll.lIIIIlIIllIIlIIlIIIlIIllI() != IIlIlIllIlIIllIllIllIIIll.lllIIlIIllIllIIllIIlIIIIl || this.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl) > 1024) {
                    this.IlIllllIIIlIllllIIIIIllII();
                    this.lIIIIIIIIIlIllIIllIlIIlIl.IlIIIIlllIIIlIIllllIIIlll = null;
                    return;
                }
                if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
                    if (!this.IlllIIIlIlllIllIlIIlllIlI.IIllIlIllIlIllIIlIllIlIII) {
                        this.IIIlIIlIlIIIlllIIlIllllll = this.IlllIIIlIlllIllIlIIlllIlI.IIIlIIlIlIIIlllIIlIllllll;
                        this.IllIlIIIIlllIIllIIlllIIlI = this.IlllIIIlIlllIllIlIIlllIlI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.IlllIIIlIlllIllIlIIlllIlI.llllIIIIlIlIllIIIllllIIll * (0.12549019607843137 * 6.375);
                        this.IllIlIlIllllIlIIllllIIlll = this.IlllIIIlIlllIllIlIIlllIlI.IllIlIlIllllIlIIllllIIlll;
                        return;
                    }
                    this.IlllIIIlIlllIllIlIIlllIlI = null;
                }
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI > 0) {
                --this.lIIIIlIIllIIlIIlIIIlIIllI;
            }
            if (this.IlIlllIIIIllIllllIllIIlIl) {
                if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(this.IIIllIllIlIlllllllIlIlIII, this.IllIIIIIIIlIlIllllIIllIII, this.lIIIIllIIlIlIllIIIlIllIlI) == this.IlllIllIlIIIIlIIlIIllIIIl) {
                    ++this.llIIlllIIIIlllIllIlIlllIl;
                    if (this.llIIlllIIIIlllIllIlIlllIl == 1200) {
                        this.IlIllllIIIlIllllIIIIIllII();
                    }
                    return;
                }
                this.IlIlllIIIIllIllllIllIIlIl = false;
                this.IllIIlIIlllllIllIIIlllIII *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.5945946f * 0.33636364f);
                this.lIlIlIllIIIIIIIIllllIIllI *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.11014493f * 1.8157895f);
                this.IlllIIlllIIIIllIIllllIlIl *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.475f * 0.42105263f);
                this.llIIlllIIIIlllIllIlIlllIl = 0;
                this.lIIlIlIllIIlIIIlIIIlllIII = 0;
            }
            else {
                ++this.lIIlIlIllIIlIIIlIIIlllIII;
            }
            MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll), lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + this.IllIIlIIlllllIllIIIlllIII, this.IllIlIIIIlllIIllIIlllIIlI + this.lIlIlIllIIIIIIIIllllIIllI, this.IllIlIlIllllIlIIllllIIlll + this.IlllIIlllIIIIllIIllllIlIl));
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
            lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + this.IllIIlIIlllllIllIIIlllIII, this.IllIlIIIIlllIIllIIlllIIlI + this.lIlIlIllIIIIIIIIllllIIllI, this.IllIlIlIllllIlIIllllIIlll + this.IlllIIlllIIIIllIIllllIlIl);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                lIllIIIIlllllIIlIllIIIIII = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI);
            }
            Entity entity = null;
            final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl).lIIIIIIIIIlIllIIllIlIIlIl(1.0, 1.0, 1.0));
            double n4 = 0.0;
            for (int i = 0; i < liiiiiiiiIlIllIIllIlIIlIl.size(); ++i) {
                final Entity entity2 = liiiiiiiiIlIllIIllIlIIlIl.get(i);
                if (entity2.IIIIIlIllIllIlIIllIIlIllI() && (entity2 != this.lIIIIIIIIIlIllIIllIlIIlIl || this.lIIlIlIllIIlIIIlIIIlllIII >= 5)) {
                    final float n5 = 1.3684211f * 0.21923077f;
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI3 = entity2.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n5, n5, n5).lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2, lIllIIIIlllllIIlIllIIIIII);
                    if (liiiIlIIllIIlIIlIIIlIIllI3 != null) {
                        final double iiiIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI3.IlIlIIIlllIIIlIlllIlIllIl);
                        if (iiiIllIlIIIllIlllIlllllIl < n4 || n4 == 0.0) {
                            entity = entity2;
                            n4 = iiiIllIlIIIllIlllIlllllIl;
                        }
                    }
                }
            }
            if (entity != null) {
                liiiIlIIllIIlIIlIIIlIIllI = new MovingObjectPosition(entity);
            }
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                if (liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII != null) {
                    if (liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lIIIIIIIIIlIllIIllIlIIlIl), 0.0f)) {
                        this.IlllIIIlIlllIllIlIIlllIlI = liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII;
                    }
                }
                else {
                    this.IlIlllIIIIllIllllIllIIlIl = true;
                }
            }
            if (!this.IlIlllIIIIllIllllIllIIlIl) {
                this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
                final float liiiIlIIllIIlIIlIIIlIIllI4 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl);
                this.IllllIllllIlIIIlIIIllllll = (float)(Math.atan2(this.IllIIlIIlllllIllIIIlllIII, this.IlllIIlllIIIIllIIllllIlIl) * 180 / (0.7894737124443054 * 3.9793505522344055));
                this.IllIIlllIllIlIllIlIIIIIII = (float)(Math.atan2(this.lIlIlIllIIIIIIIIllllIIllI, liiiIlIIllIIlIIlIIIlIIllI4) * 180 / (1.8278357257249704 * 1.71875));
                while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl < -180) {
                    this.IIlIIllIIIllllIIlllIllIIl -= 360;
                }
                while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl >= 180) {
                    this.IIlIIllIIIllllIIlllIllIIl += 360;
                }
                while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII < -180) {
                    this.IlIlIIIlllllIIIlIlIlIllII -= 360;
                }
                while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII >= 180) {
                    this.IlIlIIIlllllIIIlIlIlIllII += 360;
                }
                this.IllIIlllIllIlIllIlIIIIIII = this.IIlIIllIIIllllIIlllIllIIl + (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl) * (0.425f * 0.47058824f);
                this.IllllIllllIlIIIlIIIllllll = this.IlIlIIIlllllIIIlIlIlIllII + (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII) * (0.62f * 0.32258064f);
                float n6 = 16.0f * 0.0575f;
                if (this.lIIIIlllIIlIlllllIlIllIII || this.lIIIlllIlIlllIIIIIIIIIlII) {
                    n6 = 0.44f * 1.1363636f;
                }
                final int n7 = 5;
                double n8 = 0.0;
                for (int j = 0; j < n7; ++j) {
                    if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + (this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl - this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) * (j + 0) / n7 - 0.049632354333326516 * 2.5185184478759766 + 0.072183097864375 * 1.7317073345184326, this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI, this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + (this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl - this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) * (j + 1) / n7 - 2.5833332538604736 * 0.04838709826275912 + 0.034226189699032426 * 3.6521739959716797, this.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl), Material.IllIIIIIIIlIlIllllIIllIII)) {
                        n8 += 1.0 / n7;
                    }
                }
                if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && n8 > 0.0) {
                    final IllllIllIIlllllIIlIIllIlI illllIllIIlllllIIlIIllIlI = (IllllIllIIlllllIIlIIllIlI)this.lIIlllIIlIlllllllllIIIIIl;
                    int n9 = 1;
                    if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 11.0f * 0.022727273f && this.lIIlllIIlIlllllllllIIIIIl.lIIlIIllIIIIIlIllIIIIllII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI) + 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll))) {
                        n9 = 2;
                    }
                    if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 0.065789476f * 7.6f && !this.lIIlllIIlIlllllllllIIIIIl.IllIIIIIIIlIlIllllIIllIII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI) + 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll))) {
                        --n9;
                    }
                    if (this.IIIlllIIIllIllIlIIIIIIlII > 0) {
                        --this.IIIlllIIIllIllIlIIIIIIlII;
                        if (this.IIIlllIIIllIllIlIIIIIIlII <= 0) {
                            this.llIlIIIlIIIIlIlllIlIIIIll = 0;
                            this.IIIlIIllllIIllllllIlIIIll = 0;
                        }
                    }
                    else if (this.IIIlIIllllIIllllllIlIIIll > 0) {
                        this.IIIlIIllllIIllllllIlIIIll -= n9;
                        if (this.IIIlIIllllIIllllllIlIIIll <= 0) {
                            this.lIlIlIllIIIIIIIIllllIIllI -= 0.5 * 0.4000000059604645;
                            this.lIIIIlIIllIIlIIlIIIlIIllI("random.splash", 0.31730768f * 0.7878788f, 1.0f + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (1.3214285f * 0.30270272f));
                            final float n10 = (float)MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl);
                            illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("bubble", this.IIIlIIlIlIIIlllIIlIllllll, n10 + 1.0f, this.IllIlIlIllllIlIIllllIIlll, (int)(1.0f + this.IlIIlIIlIllIIIIllIIllIlIl * 20), this.IlIIlIIlIllIIIIllIIllIlIl, 0.0, this.IlIIlIIlIllIIIIllIIllIlIl, 0.19493671000061116 * 1.0259740352630615);
                            illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("wake", this.IIIlIIlIlIIIlllIIlIllllll, n10 + 1.0f, this.IllIlIlIllllIlIIllllIIlll, (int)(1.0f + this.IlIIlIIlIllIIIIllIIllIlIl * 20), this.IlIIlIIlIllIIIIllIIllIlIl, 0.0, this.IlIIlIIlIllIIIIllIIllIlIl, 1.6341463327407837 * 0.1223880621784911);
                            this.IIIlllIIIllIllIlIIIIIIlII = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 10, 30);
                        }
                        else {
                            this.lllIIIIIlIllIlIIIllllllII += (float)(this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * 4);
                            final float n11 = this.lllIIIIIlIllIlIIIllllllII * (39.5f * 4.418555E-4f);
                            final float liiiIlIIllIIlIIlIIIlIIllI5 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n11);
                            final float liiiiiiiiIlIllIIllIlIIlIl2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n11);
                            final double n12 = this.IIIlIIlIlIIIlllIIlIllllll + liiiIlIIllIIlIIlIIIlIIllI5 * this.IIIlIIllllIIllllllIlIIIll * (0.17999999f * 0.5555556f);
                            final double n13 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) + 1.0f;
                            final double n14 = this.IllIlIlIllllIlIIllllIIlll + liiiiiiiiIlIllIIllIlIIlIl2 * this.IIIlIIllllIIllllllIlIIIll * (0.05f * 2.0f);
                            if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 0.08132531f * 1.8444444f) {
                                illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("bubble", n12, n13 - 1.0 * 0.10000000149011612, n14, 1, liiiIlIIllIIlIIlIIIlIIllI5, 1.4117647409439087 * 0.07083333157416852, liiiiiiiiIlIllIIllIlIIlIl2, 0.0);
                            }
                            final float n15 = liiiIlIIllIIlIIlIIIlIIllI5 * (0.011666667f * 3.4285715f);
                            final float n16 = liiiiiiiiIlIllIIllIlIIlIl2 * (1.1355932f * 0.035223883f);
                            illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("wake", n12, n13, n14, 0, n16, 0.028333332629667408 * 0.3529411852359772, -n15, 1.0);
                            illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("wake", n12, n13, n14, 0, -n16, 3.2272727489471436 * 0.0030985915284855834, n15, 1.0);
                        }
                    }
                    else if (this.llIlIIIlIIIIlIlllIlIIIIll > 0) {
                        this.llIlIIIlIIIIlIlllIlIIIIll -= n9;
                        float n17 = 0.018333334f * 8.181818f;
                        if (this.llIlIIIlIIIIlIlllIlIIIIll < 20) {
                            n17 += (float)((20 - this.llIlIIIlIIIIlIlllIlIIIIll) * (2.884615421295166 * 0.017333333112928607));
                        }
                        else if (this.llIlIIIlIIIIlIlllIlIIIIll < 40) {
                            n17 += (float)((40 - this.llIlIIIlIIIIlIlllIlIIIIll) * (0.02 * 1.0));
                        }
                        else if (this.llIlIIIlIIIIlIlllIlIIIIll < 60) {
                            n17 += (float)((60 - this.llIlIIIlIIIIlIlllIlIIIIll) * (0.5555555820465088 * 0.017999999141693156));
                        }
                        if (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < n17) {
                            final float n18 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 0.0f, 360) * (0.003147315f * 5.5454545f);
                            final float liiiIlIIllIIlIIlIIIlIIllI6 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 25, (float)60);
                            illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI("splash", this.IIIlIIlIlIIIlllIIlIllllll + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n18) * liiiIlIIllIIlIIlIIIlIIllI6 * (1.2258065f * 0.08157895f), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) + 1.0f, this.IllIlIlIllllIlIIllllIIlll + MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n18) * liiiIlIIllIIlIIlIIIlIIllI6 * (0.36363637f * 0.275f), 2 + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(2), 0.26666667064030963 * 0.375, 0.0, 0.2142857164144516 * 0.46666666898462505, 0.0);
                        }
                        if (this.llIlIIIlIIIIlIlllIlIIIIll <= 0) {
                            this.lllIIIIIlIllIlIIIllllllII = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 0.0f, 360);
                            this.IIIlIIllllIIllllllIlIIIll = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 20, 80);
                        }
                    }
                    else {
                        this.llIlIIIlIIIIlIlllIlIIIIll = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, 100, 900);
                        this.llIlIIIlIIIIlIlllIlIIIIll -= lIIlllIlIllIIIIIlIlllIIII.IIIllIllIlIlllllllIlIlIII(this.lIIIIIIIIIlIllIIllIlIIlIl) * 20 * 5;
                    }
                    if (this.IIIlllIIIllIllIlIIIIIIlII > 0) {
                        this.lIlIlIllIIIIIIIIllllIIllI -= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.29302324769044347 * 0.682539701461792);
                    }
                }
                this.lIlIlIllIIIIIIIIllllIIllI += 0.49494948983192444 * 0.08081632555983355 * (n8 * 2 - 1.0);
                if (n8 > 0.0) {
                    n6 *= (float)(1.2905659970968986 * 0.6973684430122375);
                    this.lIlIlIllIIIIIIIIllllIIllI *= 0.5565217391304348 * 1.4375;
                }
                this.IllIIlIIlllllIllIIIlllIII *= n6;
                this.lIlIlIllIIIIIIIIllllIIllI *= n6;
                this.IlllIIlllIIIIllIIllllIlIl *= n6;
                this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("xTile", (short)this.IIIllIllIlIlllllllIlIlIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("yTile", (short)this.IllIIIIIIIlIlIllllIIllIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("zTile", (short)this.lIIIIllIIlIlIllIIIlIllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("inTile", (byte)IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("shake", (byte)this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("inGround", (byte)(this.IlIlllIIIIllIllllIllIIlIl ? 1 : 0));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.IIIllIllIlIlllllllIlIlIII = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("xTile");
        this.IllIIIIIIIlIlIllllIIllIII = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("yTile");
        this.lIIIIllIIlIlIllIIIlIllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("zTile");
        this.IlllIllIlIIIIlIIlIIllIIIl = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("inTile") & 0xFF);
        this.lIIIIlIIllIIlIIlIIIlIIllI = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("shake") & 0xFF);
        this.IlIlllIIIIllIllllIllIIlIl = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("inGround") == 1);
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            return 0;
        }
        int n = 0;
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            final double n2 = this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll;
            final double n3 = this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI - this.IllIlIIIIlllIIllIIlllIIlI;
            final double n4 = this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll;
            final double n5 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2 * n2 + n3 * n3 + n4 * n4);
            final double n6 = 0.9642857313156128 * 0.10370370187223044;
            final Entity illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
            illlIIIlIlllIllIlIIlllIlI.IllIIlIIlllllIllIIIlllIII += n2 * n6;
            final Entity illlIIIlIlllIllIlIIlllIlI2 = this.IlllIIIlIlllIllIlIIlllIlI;
            illlIIIlIlllIllIlIIlllIlI2.lIlIlIllIIIIIIIIllllIIllI += n3 * n6 + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n5) * (0.08163265138864517 * 0.9800000200793152);
            final Entity illlIIIlIlllIllIlIIlllIlI3 = this.IlllIIIlIlllIllIlIIlllIlI;
            illlIIIlIlllIllIlIIlllIlI3.IlllIIlllIIIIllIIllllIlIl += n4 * n6;
            n = 3;
        }
        else if (this.IIIlllIIIllIllIlIIIIIIlII > 0) {
            final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl = new lllIIIIIlIllllIIIlllIllIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IIIIllIlIIIllIlllIlllllIl());
            final double n7 = this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll;
            final double n8 = this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI - this.IllIlIIIIlllIIllIIlllIIlI;
            final double n9 = this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll;
            final double n10 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n7 * n7 + n8 * n8 + n9 * n9);
            final double n11 = 0.013513513339358236 * 7.400000095367432;
            lllIIIIIlIllllIIIlllIllIl.IllIIlIIlllllIllIIIlllIII = n7 * n11;
            lllIIIIIlIllllIIIlllIllIl.lIlIlIllIIIIIIIIllllIIllI = n8 * n11 + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n10) * (3.0 * 0.02666666666666667);
            lllIIIIIlIllllIIIlllIllIl.IlllIIlllIIIIllIIllllIlIl = n9 * n11;
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl);
            this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new IIIIlllIIIlllllIIlllIIIIl(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll, this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI + 1.0909091234207153 * 0.458333319673936, this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll + 0.22340425078606604 * 2.238095283508301, this.IlIlllIIIIlIllIlllIlIIIll.nextInt(6) + 1));
            n = 1;
        }
        if (this.IlIlllIIIIllIllllIllIIlIl) {
            n = 2;
        }
        this.IlIllllIIIlIllllIIIIIllII();
        this.lIIIIIIIIIlIllIIllIlIIlIl.IlIIIIlllIIIlIIllllIIIlll = null;
        return n;
    }
    
    private lIlIlIlIlIllllIlllIIIlIlI IIIIllIlIIIllIlllIlllllIl() {
        final float nextFloat = this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat();
        final int ilIlIIIlllIIIlIlllIlIllIl = lIIlllIlIllIIIIIlIlllIIII.IlIlIIIlllIIIlIlllIlIllIl(this.lIIIIIIIIIlIllIIllIlIIlIl);
        final int iiIllIllIlIlllllllIlIlIII = lIIlllIlIllIIIIIlIlllIIII.IIIllIllIlIlllllllIlIlIII(this.lIIIIIIIIIlIllIIllIlIIlIl);
        final float n = 0.90909094f * 0.11f - ilIlIIIlllIIIlIlllIlIllIl * (24.25f * 0.0010309279f) - iiIllIllIlIlllllllIlIlIII * (0.00862069f * 1.16f);
        final float n2 = 0.02264151f * 2.2083333f + ilIlIIIlllIIIlIlllIlIllIl * (0.070833325f * 0.14117648f) - iiIllIllIlIlllllllIlIlIII * (1.0f * 0.01f);
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, 0.0f, 1.0f);
        final float liiiIlIIllIIlIIlIIIlIIllI2 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2, 0.0f, 1.0f);
        if (nextFloat < liiiIlIIllIIlIIlIIIlIIllI) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.IIIlIIlIlIIIlllIIlIllllll, 1);
            return ((IIIlIlIlIIIIIIIIllIIllIIl)IIIIIllllIlIlllllllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, IIIIllllIIlIIIIIlIllllIII.IIIIllIlIIIllIlllIlllllIl)).lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll);
        }
        if (nextFloat - liiiIlIIllIIlIIlIIIlIIllI < liiiIlIIllIIlIIlIIIlIIllI2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.IllIlIIIIlllIIllIIlllIIlI, 1);
            return ((IIIlIlIlIIIIIIIIllIIllIIl)IIIIIllllIlIlllllllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, IIIIllllIIlIIIIIlIllllIII.IIIIllIIllIIIIllIllIIIlIl)).lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll);
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.lIllIlIlllIIlIIllIIlIIlII, 1);
        return ((IIIlIlIlIIIIIIIIllIIllIIl)IIIIIllllIlIlllllllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, IIIIllllIIlIIIIIlIllllIII.IlIlIIIlllIIIlIlllIlIllIl)).lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll);
    }
    
    @Override
    public void IlIllllIIIlIllllIIIIIllII() {
        super.IlIllllIIIlIllllIIIIIllII();
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IlIIIIlllIIIlIIllllIIIlll = null;
        }
    }
    
    static {
        IIIIllIlIIIllIlllIlllllIl = Arrays.asList(new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIlIllIlIlIIIllllIlIllIll), 10).lIIIIlIIllIIlIIlIIIlIIllI(1.25f * 0.71999997f), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIIIIIllIllllIIlIIlllIII), 10), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIllIIllIIIIIllIlIIIIIIl), 10), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII), 10), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlllIIlllIIIIllIIllllIlIl), 5), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lllIIlIIllIllIIllIIlIIIIl), 2).lIIIIlIIllIIlIIlIIIlIIllI(1.5714285f * 0.57272726f), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIllIlIlllIIlIIllIIlIIlII), 10), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIlIIIllIIIIlllIlIIIIIlI), 5), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIllIllIllllllIllIlllIlIl, 10, 0), 1), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IlllIIllllllllIlIlIlllllI), 10), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIllllllIlIIIIlllIlIlIlll), 10));
        IIIIllIIllIIIIllIllIIIlIl = Arrays.asList(new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IlllIIllIlllllIIIlIllIIII), 1), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIIIlIIllIIIIllllIlIlIlI), 1), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IllIIIIllllllIlllllIlIlll), 1), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIIIlIlllIlIllIl), 1).lIIIIlIIllIIlIIlIIIlIIllI(1.1486486f * 0.21764706f).lIIIIlIIllIIlIIlIIIlIIllI(), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lllIIlIIllIllIIllIIlIIIIl), 1).lIIIIlIIllIIlIIlIIIlIIllI(0.36956522f * 0.6764706f).lIIIIlIIllIIlIIlIIIlIIllI(), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIlIlIlIIlIlllIIIIIIllllI), 1).lIIIIlIIllIIlIIlIIIlIIllI());
        IlIlIIIlllIIIlIlllIlIllIl = Arrays.asList(new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll, 1, IlIIIIIlIllIIIllIIlllllII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI()), 60), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll, 1, IlIIIIIlIllIIIllIIlllllII.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()), 25), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll, 1, IlIIIIIlIllIIIllIIlllllII.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI()), 2), new IIIlIlIlIIIIIIIIllIIllIIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llIIlllIlIIlIIIIIlIllllll, 1, IlIIIIIlIllIIIllIIlllllII.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI()), 13));
    }
}
