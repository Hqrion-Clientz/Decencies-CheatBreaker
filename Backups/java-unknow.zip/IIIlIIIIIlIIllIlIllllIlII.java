import org.lwjgl.util.glu.Project;
import org.lwjgl.opengl.GL11;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIIlIIllIlIllllIlII extends IllIlIIIlIlIlIIIIlIlIllll
{
    private static final ResourceLocation lIlIlIllIIIIIIIIllllIIllI;
    private static final ResourceLocation IlllIIlllIIIIllIIllllIlIl;
    private static final IIIllllIIIlIlIIIlIllIllll IllllIllllIlIIIlIIIllllll;
    private Random IllIIlllIllIlIllIlIIIIIII;
    private IlIlllIlIIIIllIIllIlIIlIl IlIlIIIlllllIIIlIlIlIllII;
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public float lIIIIIIIIIlIllIIllIlIIlIl;
    public float IlllIIIlIlllIllIlIIlllIlI;
    public float IIIIllIlIIIllIlllIlllllIl;
    public float IIIIllIIllIIIIllIllIIIlIl;
    public float IlIlIIIlllIIIlIlllIlIllIl;
    public float IIIllIllIlIlllllllIlIlIII;
    lIlIlIlIlIllllIlllIIIlIlI IllIIIIIIIlIlIllllIIllIII;
    private String IIlIIllIIIllllIIlllIllIIl;
    
    public IIIlIIIIIlIIllIlIllllIlII(final IllIlIIIIIIllIIIIIllIllIl illIlIIIIIIllIIIIIllIllIl, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final String iIlIIllIIIllllIIlllIllIIl) {
        super(new IlIlllIlIIIIllIIllIlIIlIl(illIlIIIIIIllIIIIIllIllIl, iiiiiIllIlIIIIlIlllIllllI, n, n2, n3));
        this.IllIIlllIllIlIllIlIIIIIII = new Random();
        this.IlIlIIIlllllIIIlIlIlIllII = (IlIlllIlIIIIllIIllIlIIlIl)this.lIllIlIlllIIlIIllIIlIIlII;
        this.IIlIIllIIIllllIIlllIllIIl = iIlIIllIIIllllIIlllIllIIl;
    }
    
    @Override
    protected void resize(final int n, final int n2) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl((this.IIlIIllIIIllllIIlllIllIIl == null) ? IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("container.enchant", new Object[0]) : this.IIlIIllIIIllllIIlllIllIIl, 12, 5, 4210752);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("container.inventory", new Object[0]), 8, this.IlIlllIIIIllIllllIllIIlIl - 96 + 2, 4210752);
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        final int n4 = (this.lIIIIIllllIIIIlIlIIIIlIlI - this.IlllIllIlIIIIlIIlIIllIIIl) / 2;
        final int n5 = (this.IIIIIIlIlIlIllllllIlllIlI - this.IlIlllIIIIllIllllIllIIlIl) / 2;
        for (int i = 0; i < 3; ++i) {
            final int n6 = n - (n4 + 60);
            final int n7 = n2 - (n5 + 14 + 19 * i);
            if (n6 >= 0 && n7 >= 0 && n6 < 108 && n7 < 19 && this.IlIlIIIlllllIIIlIlIlIllII.lIIIIIIIIIlIllIIllIlIIlIl(this.lllIIIIIlIllIlIIIllllllII.thePlayer, i)) {
                this.lllIIIIIlIllIlIIIllllllII.playerController.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllllIIIlIlIlIllII.IIIIllIlIIIllIlllIlllllIl, i);
            }
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2, final int n3) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IIIlIIIIIlIIllIlIllllIlII.lIlIlIllIIIIIIIIllllIIllI);
        final int n4 = (this.lIIIIIllllIIIIlIlIIIIlIlI - this.IlllIllIlIIIIlIIlIIllIIIl) / 2;
        final int n5 = (this.IIIIIIlIlIlIllllllIlllIlI - this.IlIlllIIIIllIllllIllIIlIl) / 2;
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4, n5, 0, 0, this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl);
        GL11.glPushMatrix();
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        final ScaledResolution scaledResolution = new ScaledResolution(this.lllIIIIIlIllIlIIIllllllII, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
        GL11.glViewport((scaledResolution.getScaledWidth() - 320) / 2 * scaledResolution.getScaleFactor(), (scaledResolution.getScaledHeight() - 240) / 2 * scaledResolution.getScaleFactor(), 320 * scaledResolution.getScaleFactor(), 240 * scaledResolution.getScaleFactor());
        GL11.glTranslatef(0.5217391f * -0.6516667f, 0.69f * 0.33333334f, 0.0f);
        Project.gluPerspective((float)90, 0.021276595f * 62.66667f, (float)9, (float)80);
        final float n6 = 1.0f;
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        llIlIlllllIIllIIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl();
        GL11.glTranslatef(0.0f, 0.3030303f * 10.889999f, (float)(-16));
        GL11.glScalef(n6, n6, n6);
        final float n7 = 5;
        GL11.glScalef(n7, n7, n7);
        GL11.glRotatef((float)180, 0.0f, 0.0f, 1.0f);
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IIIlIIIIIlIIllIlIllllIlII.IlllIIlllIIIIllIIllllIlIl);
        GL11.glRotatef((float)20, 1.0f, 0.0f, 0.0f);
        final float n8 = this.IIIllIllIlIlllllllIlIlIII + (this.IlIlIIIlllIIIlIlllIlIllIl - this.IIIllIllIlIlllllllIlIlIII) * n;
        GL11.glTranslatef((1.0f - n8) * (30.0f * 0.006666667f), (1.0f - n8) * (0.47191012f * 0.21190476f), (1.0f - n8) * (3.0625f * 0.08163265f));
        GL11.glRotatef(-(1.0f - n8) * 90 - 90, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef((float)180, 1.0f, 0.0f, 0.0f);
        final float n9 = this.IlllIIIlIlllIllIlIIlllIlI + (this.lIIIIIIIIIlIllIIllIlIIlIl - this.IlllIIIlIlllIllIlIIlllIlI) * n + 0.40425533f * 0.618421f;
        final float n10 = this.IlllIIIlIlllIllIlIIlllIlI + (this.lIIIIIIIIIlIllIIllIlIIlIl - this.IlllIIIlIlllIllIlIIlllIlI) * n + 0.52040815f * 1.4411765f;
        float n11 = (n9 - MathHelper.lIIIIIIIIIlIllIIllIlIIlIl((double)n9)) * (1.4325581f * 1.1168832f) - 0.18095239f * 1.6578947f;
        float n12 = (n10 - MathHelper.lIIIIIIIIIlIllIIllIlIIlIl((double)n10)) * (1.2444445f * 1.2857143f) - 0.18032786f * 1.6636364f;
        if (n11 < 0.0f) {
            n11 = 0.0f;
        }
        if (n12 < 0.0f) {
            n12 = 0.0f;
        }
        if (n11 > 1.0f) {
            n11 = 1.0f;
        }
        if (n12 > 1.0f) {
            n12 = 1.0f;
        }
        GL11.glEnable(32826);
        IIIlIIIIIlIIllIlIllllIlII.IllllIllllIlIIIlIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(null, 0.0f, n11, n12, n8, 0.0f, 0.005859375f * 10.666667f);
        GL11.glDisable(32826);
        llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
        GL11.glMatrixMode(5889);
        GL11.glViewport(0, 0, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        llIIlIlllllllIlIIIllIIllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllllIIIlIlIlIllII.IlIlIIIlllIIIlIlllIlIllIl);
        for (int i = 0; i < 3; ++i) {
            final String liiiIlIIllIIlIIlIIIlIIllI = llIIlIlllllllIlIIIllIIllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
            IIIlIIIIIlIIllIlIllllIlII.llIlIIIlIIIIlIlllIlIIIIll = 0.0f;
            this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IIIlIIIIIlIIllIlIllllIlII.lIlIlIllIIIIIIIIllllIIllI);
            final int j = this.IlIlIIIlllllIIIlIlIlIllII.IIIllIllIlIlllllllIlIlIII[i];
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            if (j == 0) {
                IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 60, n5 + 14 + 19 * i, 0, 185, 108, 19);
            }
            else {
                final String string = "" + j;
                final FontRenderer standardGalacticFontRenderer = this.lllIIIIIlIllIlIIIllllllII.standardGalacticFontRenderer;
                int n13 = 6839882;
                if (this.lllIIIIIlIllIlIIIllllllII.thePlayer.IllIIIIIIlllIIIlIIIlIIIlI < j && !this.lllIIIIIlIllIlIIIllllllII.thePlayer.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 60, n5 + 14 + 19 * i, 0, 185, 108, 19);
                    standardGalacticFontRenderer.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n4 + 62, n5 + 16 + 19 * i, 104, (n13 & 0xFEFEFE) >> 1);
                    final FontRenderer fontRendererObj = this.lllIIIIIlIllIlIIIllllllII.fontRendererObj;
                    fontRendererObj.drawStringWithShadow(string, (float)(n4 + 62 + 104 - fontRendererObj.getStringWidth(string)), (float)(n5 + 16 + 19 * i + 7), 4226832);
                }
                else {
                    final int n14 = n2 - (n4 + 60);
                    final int n15 = n3 - (n5 + 14 + 19 * i);
                    if (n14 >= 0 && n15 >= 0 && n14 < 108 && n15 < 19) {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 60, n5 + 14 + 19 * i, 0, 204, 108, 19);
                        n13 = 16777088;
                    }
                    else {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 + 60, n5 + 14 + 19 * i, 0, 166, 108, 19);
                    }
                    standardGalacticFontRenderer.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, n4 + 62, n5 + 16 + 19 * i, 104, n13);
                    final FontRenderer fontRendererObj2 = this.lllIIIIIlIllIlIIIllllllII.fontRendererObj;
                    fontRendererObj2.drawStringWithShadow(string, (float)(n4 + 62 + 104 - fontRendererObj2.getStringWidth(string)), (float)(n5 + 16 + 19 * i + 7), 8453920);
                }
            }
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIllIlIlllIIlIIllIIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI(0).lIIIIlIIllIIlIIlIIIlIIllI();
        if (!lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI, this.IllIIIIIIIlIlIllllIIllIII)) {
            this.IllIIIIIIIlIlIllllIIllIII = liiiIlIIllIIlIIlIIIlIIllI;
            do {
                this.IIIIllIlIIIllIlllIlllllIl += this.IllIIlllIllIlIllIlIIIIIII.nextInt(4) - this.IllIIlllIllIlIllIlIIIIIII.nextInt(4);
            } while (this.lIIIIIIIIIlIllIIllIlIIlIl <= this.IIIIllIlIIIllIlllIlllllIl + 1.0f && this.lIIIIIIIIIlIllIIllIlIIlIl >= this.IIIIllIlIIIllIlllIlllllIl - 1.0f);
        }
        ++this.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl;
        this.IIIllIllIlIlllllllIlIlIII = this.IlIlIIIlllIIIlIlllIlIllIl;
        boolean b = false;
        for (int i = 0; i < 3; ++i) {
            if (this.IlIlIIIlllllIIIlIlIlIllII.IIIllIllIlIlllllllIlIlIII[i] != 0) {
                b = true;
            }
        }
        if (b) {
            this.IlIlIIIlllIIIlIlllIlIllIl += 7.6666665f * 0.026086958f;
        }
        else {
            this.IlIlIIIlllIIIlIlllIlIllIl -= 0.40555558f * 0.49315068f;
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl < 0.0f) {
            this.IlIlIIIlllIIIlIlllIlIllIl = 0.0f;
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl > 1.0f) {
            this.IlIlIIIlllIIIlIlllIlIllIl = 1.0f;
        }
        float n = (this.IIIIllIlIIIllIlllIlllllIl - this.lIIIIIIIIIlIllIIllIlIIlIl) * (1.4153847f * 0.2826087f);
        final float n2 = 0.025f * 8.0f;
        if (n < -n2) {
            n = -n2;
        }
        if (n > n2) {
            n = n2;
        }
        this.IIIIllIIllIIIIllIllIIIlIl += (n - this.IIIIllIIllIIIIllIllIIIlIl) * (0.49787232f * 1.8076923f);
        this.lIIIIIIIIIlIllIIllIlIIlIl += this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    static {
        lIlIlIllIIIIIIIIllllIIllI = new ResourceLocation("textures/gui/container/enchanting_table.png");
        IlllIIlllIIIIllIIllllIlIl = new ResourceLocation("textures/entity/enchanting_table_book.png");
        IllllIllllIlIIIlIIIllllll = new IIIllllIIIlIlIIIlIllIllll();
    }
}
