import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIlllIIlIlIIIlllllII extends lIIlIllIIIlllllIllIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlIllIllIlllllIIIIllIl ilIlIllIllIlllllIIIIllIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        GL11.glPushMatrix();
        GL11.glTranslated(n, n2, n3);
        GL11.glRotatef(n4, 0.0f, 1.0f, 0.0f);
        GL11.glEnable(32826);
        this.lIIIIIIIIIlIllIIllIlIIlIl(ilIlIllIllIlllllIIIIllIl);
        final llIIlIIlIIIIIIlIIllllllIl iiiIllIIllIIIIllIllIIIlIl = ilIlIllIllIlllllIIIIllIl.IIIIllIIllIIIIllIllIIIlIl;
        final float n6 = 5.3333335f * 0.01171875f;
        GL11.glScalef(n6, n6, n6);
        this.lIIIIlIIllIIlIIlIIIlIIllI(ilIlIllIllIlllllIIIIllIl, iiiIllIIllIIIIllIllIIIlIl.IllIlIlIllllIlIIllllIIlll, iiiIllIIllIIIIllIllIIIlIl.IllIIlIIlllllIllIIIlllIII, iiiIllIIllIIIIllIllIIIlIl.lIlIlIllIIIIIIIIllllIIllI, iiiIllIIllIIIIllIllIIIlIl.IlllIIlllIIIIllIIllllIlIl);
        GL11.glDisable(32826);
        GL11.glPopMatrix();
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlIllIllIlllllIIIIllIl ilIlIllIllIlllllIIIIllIl) {
        return IIlIIIIlllIIlIlIIIlllllII.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlIllIllIlllllIIIIllIl ilIlIllIllIlllllIIIIllIl, final int n, final int n2, final int n3, final int n4) {
        final float n5 = -n / 2.0f;
        final float n6 = -n2 / 2.0f;
        final float n7 = 0.055555556f * 9.0f;
        final float n8 = 0.14338236f * 5.230769f;
        final float n9 = 0.027083334f * 30.0f;
        final float n10 = 0.0f;
        final float n11 = 0.8148148f * 0.07670455f;
        final float n12 = 1.3529412f * 0.5543478f;
        final float n13 = 0.11764706f * 6.90625f;
        final float n14 = 0.954023f * 0.0020472514f;
        final float n15 = 0.041503906f * 0.047058824f;
        final float n16 = 0.87890625f * 0.85555553f;
        final float n17 = 0.9878049f * 0.7612365f;
        final float n18 = 0.0f;
        final float n19 = 0.040816326f * 1.53125f;
        for (int i = 0; i < n / 16; ++i) {
            for (int j = 0; j < n2 / 16; ++j) {
                final float n20 = n5 + (i + 1) * 16;
                final float n21 = n5 + i * 16;
                final float n22 = n6 + (j + 1) * 16;
                final float n23 = n6 + j * 16;
                this.lIIIIlIIllIIlIIlIIIlIIllI(ilIlIllIllIlllllIIIIllIl, (n20 + n21) / 2.0f, (n22 + n23) / 2.0f);
                final float n24 = (n3 + n - i * 16) / (float)256;
                final float n25 = (n3 + n - (i + 1) * 16) / (float)256;
                final float n26 = (n4 + n2 - j * 16) / (float)256;
                final float n27 = (n4 + n2 - (j + 1) * 16) / (float)256;
                final Tessellator instance = Tessellator.instance;
                instance.startDrawingQuads();
                instance.IlllIIIlIlllIllIlIIlllIlI(0.0f, 0.0f, -1);
                instance.addVertexWithUV(n20, n23, -n7, n25, n26);
                instance.addVertexWithUV(n21, n23, -n7, n24, n26);
                instance.addVertexWithUV(n21, n22, -n7, n24, n27);
                instance.addVertexWithUV(n20, n22, -n7, n25, n27);
                instance.IlllIIIlIlllIllIlIIlllIlI(0.0f, 0.0f, 1.0f);
                instance.addVertexWithUV(n20, n22, n7, n8, n10);
                instance.addVertexWithUV(n21, n22, n7, n9, n10);
                instance.addVertexWithUV(n21, n23, n7, n9, n11);
                instance.addVertexWithUV(n20, n23, n7, n8, n11);
                instance.IlllIIIlIlllIllIlIIlllIlI(0.0f, 1.0f, 0.0f);
                instance.addVertexWithUV(n20, n22, -n7, n12, n14);
                instance.addVertexWithUV(n21, n22, -n7, n13, n14);
                instance.addVertexWithUV(n21, n22, n7, n13, n15);
                instance.addVertexWithUV(n20, n22, n7, n12, n15);
                instance.IlllIIIlIlllIllIlIIlllIlI(0.0f, -1, 0.0f);
                instance.addVertexWithUV(n20, n23, n7, n12, n14);
                instance.addVertexWithUV(n21, n23, n7, n13, n14);
                instance.addVertexWithUV(n21, n23, -n7, n13, n15);
                instance.addVertexWithUV(n20, n23, -n7, n12, n15);
                instance.IlllIIIlIlllIllIlIIlllIlI(-1, 0.0f, 0.0f);
                instance.addVertexWithUV(n20, n22, n7, n17, n18);
                instance.addVertexWithUV(n20, n23, n7, n17, n19);
                instance.addVertexWithUV(n20, n23, -n7, n16, n19);
                instance.addVertexWithUV(n20, n22, -n7, n16, n18);
                instance.IlllIIIlIlllIllIlIIlllIlI(1.0f, 0.0f, 0.0f);
                instance.addVertexWithUV(n21, n22, -n7, n17, n18);
                instance.addVertexWithUV(n21, n23, -n7, n17, n19);
                instance.addVertexWithUV(n21, n23, n7, n16, n19);
                instance.addVertexWithUV(n21, n22, n7, n16, n18);
                instance.draw();
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlIllIllIlllllIIIIllIl ilIlIllIllIlllllIIIIllIl, final float n, final float n2) {
        int n3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IllIlIIIIlllIIllIIlllIIlI + n2 / 16);
        int n4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IllIlIlIllllIlIIllllIIlll);
        if (ilIlIllIllIlllllIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI == 2) {
            n3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IIIlIIlIlIIIlllIIlIllllll + n / 16);
        }
        if (ilIlIllIllIlllllIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI == 1) {
            n4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IllIlIlIllllIlIIllllIIlll - n / 16);
        }
        if (ilIlIllIllIlllllIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI == 0) {
            n3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IIIlIIlIlIIIlllIIlIllllll - n / 16);
        }
        if (ilIlIllIllIlllllIIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI == 3) {
            n4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIlIllIllIlllllIIIIllIl.IllIlIlIllllIlIIllllIIlll + n / 16);
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIIIIIIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, illlIIIlIlllIllIlIIlllIlI, n4, 0);
        OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI, (float)(liiiIlIIllIIlIIlIIIlIIllI % 65536), (float)(liiiIlIIllIIlIIlIIIlIIllI / 65536));
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIlIllIllIlllllIIIIllIl)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIlIllIllIlllllIIIIllIl)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/painting/paintings_kristoffer_zetterstrand.png");
    }
}
