// 
// Decompiled by Procyon v0.5.36
// 

public class GuiSleepMP extends GuiChat
{
    @Override
    public void s_() {
        super.s_();
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI - 40, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("multiplayer.stopSleeping", new Object[0])));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        if (n == 1) {
            this.shutdownMinecraftApplet();
        }
        else if (n != 28 && n != 156) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        }
        else {
            final String trim = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl().trim();
            if (!trim.isEmpty()) {
                this.lllIIIIIlIllIlIIIllllllII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl(trim);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.setSection("");
            this.lllIIIIIlIllIlIIIllllllII.ingameGUI.getChatGUI().IIIIllIlIIIllIlllIlllllIl();
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
            this.shutdownMinecraftApplet();
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll);
        }
    }
    
    private void shutdownMinecraftApplet() {
        this.lllIIIIIlIllIlIIIllllllII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this.lllIIIIIlIllIlIIIllllllII.thePlayer, 3));
    }
}
