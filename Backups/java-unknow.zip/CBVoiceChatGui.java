import org.lwjgl.opengl.GL11;
import com.google.common.collect.Lists;
import java.util.UUID;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class CBVoiceChatGui extends CBAbstractGui
{
    private static CheatBreaker IIIIllIlIIIllIlllIlllllIl;
    private List<lIIIllIIIIlIIllIIIIIIIlll> IIIIllIIllIIIIllIllIIIlIl;
    private lIIIllIIIIlIIllIIIIIIIlll IlIlIIIlllIIIlIlllIlIllIl;
    private lIIIllIIIIlIIllIIIIIIIlll IIIllIllIlIlllllllIlIlIII;
    private llIIIlllllIIllIlllIlIlIll IllIIIIIIIlIlIllllIIllIII;
    private ResourceLocation lIIIIllIIlIlIllIIIlIllIlI;
    private ResourceLocation IlllIllIlIIIIlIIlIIllIIIl;
    private ResourceLocation IlIlllIIIIllIllllIllIIlIl;
    private ResourceLocation lIllIlIlllIIlIIllIIlIIlII;
    
    public CBVoiceChatGui() {
        this.IllIIIIIIIlIlIllllIIllIII = null;
        this.lIIIIllIIlIlIllIIIlIllIlI = new ResourceLocation("client/icons/headphones.png");
        this.IlllIllIlIIIIlIIlIIllIIIl = new ResourceLocation("client/icons/speaker.png");
        this.IlIlllIIIIllIllllIllIIlIl = new ResourceLocation("client/icons/speaker-mute.png");
        this.lIllIlIlllIIlIIllIIlIIlII = new ResourceLocation("client/icons/microphone-64.png");
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII();
        if (CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIlIIIllIlllIlllllIl() && CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl() != null) {
            this.IllIIIIIIIlIlIllllIIllIII = CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IlIlIIIlllIIIlIlllIlIllIl();
            final boolean contains = CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().contains(this.lllIIIIIlIllIlIIIllllllII.thePlayer.llllIIllllllIlIIlIlIIIllI().getId());
            this.IlIlIIIlllIIIlIlllIlIllIl = new lIIIllIIIIlIIllIIIIIIIlll("Join Channel");
            this.IIIllIllIlIlllllllIlIlIII = new lIIIllIIIIlIIllIIIIIIIlll(contains ? "Un-deafen" : "Deafen");
            this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
            final float n = 16;
            final float n2 = this.IlIlIIIlllIIIlIlllIlIllIl() / 8;
            final float n3 = this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 8 - n * CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl().size() / 2.0f;
            int n4 = 0;
            for (final llIIIlllllIIllIlllIlIlIll llIIIlllllIIllIlllIlIlIll : CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl()) {
                final lIIIllIIIIlIIllIIIIIIIlll liiIllIIIIlIIllIIIIIIIlll;
                this.IIIIllIIllIIIIllIllIIIlIl.add(liiIllIIIIlIIllIIIIIIIlll = new lIIIllIIIIlIIllIIIIIIIlll(llIIIlllllIIllIlllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl()));
                liiIllIIIIlIIllIIIIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n2, n3 + 12 + n * n4, 110, 12);
                if (this.IllIIIIIIIlIlIllllIIllIII == llIIIlllllIIllIlllIlIlIll) {
                    liiIllIIIIlIIllIIIIIIIlll.lIIIIllIIlIlIllIIIlIllIlI();
                }
                ++n4;
            }
        }
    }
    
    @Override
    public void t_() {
        this.lllIIIIIlIllIlIIIllllllII.entityRenderer.unloadSounds();
    }
    
    @Override
    public void setProgress(final float n, final float n2) throws Exception {
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlIIIlllIIIlIlllIlIllIl(), this.IIIllIllIlIlllllllIlIlIII());
        final float n3 = this.IlIlIIIlllIIIlIlllIlIllIl() / 8;
        if (CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIlIIIllIlllIlllllIl() && CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl() != null) {
            final float n4 = this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 8 - 16 * (float)CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl().size() / 2.0f;
            CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI("VOICE CHAT", n3, n4 - 4, -1);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 + 60, n4 - 4, 50, 12);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true);
            this.IIIIllIIllIIIIllIllIIIlIl.forEach(liiIllIIIIlIIllIIIIIIIlll -> {
                if (this.lIIIIlIIllIIlIIlIIIlIIllI(liiIllIIIIlIIllIIIIIIIlll.IlIlllIIIIllIllllIllIIlIl()) == CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IlIlIIIlllIIIlIlllIlIllIl()) {
                    liiIllIIIIlIIllIIIIIIIlll.IIIIllIlIIIllIlllIlllllIl(n, n2, true);
                    lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("client/icons/microphone-64.png"), liiIllIIIIlIIllIIIIIIIlll.IIIIllIlIIIllIlllIlllllIl() + 4, liiIllIIIIlIIllIIIIIIIlll.IIIIllIIllIIIIllIllIIIlIl() + 2.0f, 8, 8);
                }
                else if (this.IllIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl() == liiIllIIIIlIIllIIIIIIIlll.IlIlllIIIIllIllllIllIIlIl()) {
                    liiIllIIIIlIIllIIIIIIIlll.IlllIIIlIlllIllIlIIlllIlI(n, n2, true);
                }
                else {
                    liiIllIIIIlIIllIIIIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true);
                }
                return;
            });
            if (this.IllIIIIIIIlIlIllllIIllIII != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3 + 130, this.IIIllIllIlIlllllllIlIlIII() / 2.0f);
            }
        }
        else {
            CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI("VOICE CHAT IS NOT SUPPORTED", n3, this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 8, -1);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final int n3) {
        if (this.IIIIllIIllIIIIllIllIIIlIl == null) {
            return;
        }
        for (final lIIIllIIIIlIIllIIIIIIIlll liiIllIIIIlIIllIIIIIIIlll : this.IIIIllIIllIIIIllIllIIIlIl) {
            if (liiIllIIIIlIIllIIIIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                final llIIIlllllIIllIlllIlIlIll liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(liiIllIIIIlIIllIIIIIIIlll.IlIlllIIIIllIllllIllIIlIl());
                if (this.IllIIIIIIIlIlIllllIIllIII == liiiIlIIllIIlIIlIIIlIIllI) {
                    continue;
                }
                for (final lIIIllIIIIlIIllIIIIIIIlll liiIllIIIIlIIllIIIIIIIlll2 : this.IIIIllIIllIIIIllIllIIIlIl) {
                    if (this.IllIIIIIIIlIlIllllIIllIII != CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IlIlIIIlllIIIlIlllIlIllIl() && liiIllIIIIlIIllIIIIIIIlll2.IlIlllIIIIllIllllIllIIlIl().equals(this.IllIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl())) {
                        liiIllIIIIlIIllIIIIIIIlll2.IlllIllIlIIIIlIIlIIllIIIl();
                    }
                }
                this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                this.IllIIIIIIIlIlIllllIIllIII = liiiIlIIllIIlIIlIIIlIIllI;
                if (this.IllIIIIIIIlIlIllllIIllIII == CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IlIlIIIlllIIIlIlllIlIllIl()) {
                    continue;
                }
                liiIllIIIIlIIllIIIIIIIlll.IllIIIIIIIlIlIllllIIllIII();
            }
        }
        if (this.IllIIIIIIIlIlIllllIIllIII != null) {
            if (this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(new IIllIlIIIlIlIIllllIIlllIl(this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI()));
                final Iterator<lIIIllIIIIlIIllIIIIIIIlll> iterator3 = this.IIIIllIIllIIIIllIllIIIlIl.iterator();
                while (iterator3.hasNext()) {
                    iterator3.next().IlllIllIlIIIIlIIlIIllIIIl();
                }
                for (final lIIIllIIIIlIIllIIIIIIIlll liiIllIIIIlIIllIIIIIIIlll3 : this.IIIIllIIllIIIIllIllIIIlIl) {
                    if (liiIllIIIIlIIllIIIIIIIlll3.IlIlllIIIIllIllllIllIIlIl().equals(this.IllIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl())) {
                        liiIllIIIIlIIllIIIIIIIlll3.lIIIIllIIlIlIllIIIlIllIlI();
                    }
                }
            }
            if (this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                final UUID id = this.lllIIIIIlIllIlIIIllllllII.thePlayer.llllIIllllllIlIIlIlIIIllI().getId();
                this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(new lIIlIlIIIIIIlIllIIIlIlIII(id));
                if (!CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().removeIf(uuid -> uuid.equals(id))) {
                    CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().add(id);
                }
                this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().contains(this.lllIIIIIlIllIlIIIllllllII.thePlayer.llllIIllllllIlIIlIlIIIllI().getId()) ? "Un-deafen" : "Deafen");
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, this.IlIlIIIlllIIIlIlllIlIllIl() / 8 + 130, this.IIIllIllIlIlllllllIlIlIII() / 2.0f);
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final int n3) {
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, float n4) {
        final float n5 = 14;
        final float n6 = this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI().size() * n5;
        n4 -= n6 / 2.0f;
        CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.lIIIIIIIIIlIllIIllIlIIlIl(), n3, n4 - 14, -1);
        if (!this.lIIlIlIllIIlIIIlIIIlllIII()) {
            this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(n3 + 125, n4 - 14, 50, 12);
            this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true);
        }
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4, n3 + 175, n4 + n6, -1626337264);
        int n7 = 0;
        final ArrayList<llIlIlIlIlIlIllIIIIlIIIII> arrayList = Lists.newArrayList(this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI());
        arrayList.sort((llIlIlIlIlIlIllIIIIlIIIII, llIlIlIlIlIlIllIIIIlIIIII2) -> {
            if (this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()) && !this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI(llIlIlIlIlIlIllIIIIlIIIII2.lIIIIlIIllIIlIIlIIIlIIllI())) {
                return -1;
            }
            else if (!this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()) && this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI(llIlIlIlIlIlIllIIIIlIIIII2.lIIIIlIIllIIlIIlIIIlIIllI())) {
                return 1;
            }
            else {
                return 0;
            }
        });
        for (final llIlIlIlIlIlIllIIIIlIIIII llIlIlIlIlIlIllIIIIlIIIII3 : arrayList) {
            final boolean illlIIIlIlllIllIlIIlllIlI = this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI(llIlIlIlIlIlIllIIIIlIIIII3.lIIIIlIIllIIlIIlIIIlIIllI());
            final boolean contains = CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().contains(llIlIlIlIlIlIllIIIIlIIIII3.lIIIIlIIllIIlIIlIIIlIIllI());
            final float n8 = n4 + n7 * n5;
            final boolean b = n > n3 + 158 && n < n3 + 184 && n2 > n8 && n2 < n8 + n5;
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            if (!illlIIIlIlllIllIlIIlllIlI) {
                lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, n3 + 4, n8 + 3, 8, 8);
            }
            else {
                lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIllIlIlllIIlIIllIIlIIlII, n3 + 4, n8 + 3, 8, 8);
            }
            final float n9 = n3 + 10;
            if (!llIlIlIlIlIlIllIIIIlIIIII3.lIIIIlIIllIIlIIlIIIlIIllI().equals(this.lllIIIIIlIllIlIIIllllllII.thePlayer.llllIIllIIlllllIlIlIIllll())) {
                if (contains) {
                    GL11.glColor4f(1.0f, 1.4848485f * 0.06734694f, 4.9f * 0.020408163f, b ? 1.0f : (0.8117647f * 0.73913044f));
                    lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, n3 + 162, n8 + 3, 8, 8);
                }
                else {
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, b ? 1.0f : (0.11904762f * 5.04f));
                    lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl, n3 + 162, n8 + 3, 8, 8);
                }
            }
            CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIlIlIlIllIIIIlIIIII3.lIIIIIIIIIlIllIIllIlIIlIl().toUpperCase(), n9 + 6, n8 + 2.0f, illlIIIlIlllIllIlIIlllIlI ? -1 : 1879048191);
            ++n7;
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final float n3, float n4) {
        final float n5 = 14;
        n4 -= this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI().size() * n5 / 2.0f;
        int n6 = 0;
        for (final llIlIlIlIlIlIllIIIIlIIIII llIlIlIlIlIlIllIIIIlIIIII : this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI()) {
            final float n7 = n4 + n6 * n5;
            final boolean b = n > n3 + 158 && n < n3 + 184 && n2 > n7 && n2 < n7 + n5;
            if (!llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI().equals(this.lllIIIIIlIllIlIIIllllllII.thePlayer.llllIIllIIlllllIlIlIIllll()) && b) {
                this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(new lIIlIlIIIIIIlIllIIIlIlIII(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()));
                if (!CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().removeIf(uuid -> uuid.equals(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()))) {
                    CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IllIIIIIIIlIlIllllIIllIII().add(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI());
                }
            }
            ++n6;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        if (n == 25 && CBVoiceChatGui.lIllIllIlIIllIllIlIlIIlIl.IIIIllIIllIIIIllIllIIIlIl()) {
            if ((boolean) CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl()) {
                this.lllIIIIIlIllIlIIIllllllII.entityRenderer.unloadSounds();
            }
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
            this.lllIIIIIlIllIlIIIllllllII.setIngameFocus();
        }
    }
    
    private llIIIlllllIIllIlllIlIlIll lIIIIlIIllIIlIIlIIIlIIllI(final String anObject) {
        for (final llIIIlllllIIllIlllIlIlIll llIIIlllllIIllIlllIlIlIll : CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IIIIllIIllIIIIllIllIIIlIl()) {
            if (llIIIlllllIIllIlllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl().equals(anObject)) {
                return llIIIlllllIIllIlllIlIlIll;
            }
        }
        return null;
    }
    
    private boolean lIIlIlIllIIlIIIlIIIlllIII() {
        return this.IllIIIIIIIlIlIllllIIllIII == CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI().IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    static {
        CBVoiceChatGui.IIIIllIlIIIllIlllIlllllIl = CheatBreaker.getInstance();
    }
}
