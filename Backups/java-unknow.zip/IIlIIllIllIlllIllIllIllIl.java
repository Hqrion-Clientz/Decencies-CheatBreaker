// 
// Decompiled by Procyon v0.5.36
// 

final class IIlIIllIllIlllIllIllIllIl extends IIllllIllIIllIIllIlIIIIII
{
    IIlIIllIllIlllIllIllIllIl(final int n, final String s) {
        super(n, s);
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIIllIIllIIIIllIllIIIlIl() {
        return lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IllIIlIIlllllIllIIIlllIII);
    }
}
