// 
// Decompiled by Procyon v0.5.36
// 

public enum CBApiFlag
{
    lIIIIlIIllIIlIIlIIIlIIllI("VOICE_ENABLED", 0, "voiceEnabled", (Class)Boolean.class), 
    lIIIIIIIIIlIllIIllIlIIlIl("MINIMAP_STATUS", 1, "minimapStatus", (Class)String.class), 
    IlllIIIlIlllIllIlIIlllIlI("SERVER_HANDLES_WAYPOINTS", 2, "serverHandlesWaypoints", (Class)Boolean.class), 
    IIIIllIlIIIllIlllIlllllIl("COMPETITIVE_GAMEMODE", 3, "competitiveGame", (Class)Boolean.class);
    
    String IIIIllIIllIIIIllIllIIIlIl;
    Class IlIlIIIlllIIIlIlllIlIllIl;
    
    private CBApiFlag(final String name, final int ordinal, final String iiiIllIIllIIIIllIllIIIlIl, final Class ilIlIIIlllIIIlIlllIlIllIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public static CBApiFlag lIIIIlIIllIIlIIlIIIlIIllI(final String anObject) {
        CBApiFlag cbApiFlag = null;
        for (final CBApiFlag cbApiFlag2 : values()) {
            if (cbApiFlag2.getIdentifier().equals(anObject)) {
                cbApiFlag = cbApiFlag2;
            }
        }
        return cbApiFlag;
    }
    
    public String getIdentifier() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public Class lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
}
