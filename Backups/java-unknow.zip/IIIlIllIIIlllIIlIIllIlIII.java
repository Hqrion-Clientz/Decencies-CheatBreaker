import com.sun.javafx.geom.Vec2d;
import java.awt.Color;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllIIIlllIIlIIllIlIII
{
    private String lIIIIIIIIIlIllIIllIlIIlIl;
    private String IlllIIIlIlllIllIlIIlllIlI;
    private Color IIIIllIlIIIllIlllIlllllIl;
    private Vec2d IIIIllIIllIIIIllIllIIIlIl;
    private Vec2d IlIlIIIlllIIIlIlllIlIllIl;
    private Vec2d IIIllIllIlIlllllllIlIlIII;
    private Vec2d IllIIIIIIIlIlIllllIIllIII;
    private Vec2d lIIIIllIIlIlIllIIIlIllIlI;
    private Vec2d IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    private boolean llIIlllIIIIlllIllIlIlllIl;
    private int lIIlIlIllIIlIIIlIIIlllIII;
    private int IIIlllIIIllIllIlIIIIIIlII;
    final /* synthetic */ IlIIIIlIlIllIIlIIIIllllll lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIlIllIIIlllIIlIIllIlIII(final IlIIIIlIlIllIIlIIIIllllll liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl, final String illlIIIlIlllIllIlIIlllIlI, final int rgba, final double n, final double n2, final double n3, final double n4, final boolean ilIlllIIIIllIllllIllIIlIl, final boolean llIIlllIIIIlllIllIlIlllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = new Color(rgba, true);
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        this.llIIlllIIIIlllIllIlIlllIl = llIIlllIIIIlllIllIlIlllIl;
        final Vec2d vec2d = new Vec2d(n, n2);
        this.IIIIllIIllIIIIllIllIIIlIl = vec2d;
        this.IIIllIllIlIlllllllIlIlIII = vec2d;
        final Vec2d vec2d2 = new Vec2d(n3, n4);
        this.IlIlIIIlllIIIlIlllIlIllIl = vec2d2;
        this.IllIIIIIIIlIlIllllIIllIII = vec2d2;
    }
    
    boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlIlllIIIIllIllllIllIIlIl && this.IIIlllIIIllIllIlIIIIIIlII != 0 && this.lIIlIlIllIIlIIIlIIIlllIII < this.IIIlllIIIllIllIlIIIIIIlII;
    }
    
    boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2) {
        return !this.llIIlllIIIIlllIllIlIlllIl || !this.IlllIIIlIlllIllIlIIlllIlI.equals(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIllIIlIlIllIIIlIllIlI().lIIIIllIIlIlIllIIIlIllIlI()) || (n + 1.0 > this.IlIlIIIlllIIIlIlllIlIllIl() && n < this.IIIIllIlIIIllIlllIlllllIl() && n2 + 1.0 > this.IIIllIllIlIlllllllIlIlIII() && n2 < this.IIIIllIIllIIIIllIllIIIlIl());
    }
    
    void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI()) {
            final double n = this.IIIIllIIllIIIIllIllIIIlIl.x - this.lIIIIllIIlIlIllIIIlIllIlI.x;
            final double n2 = this.IlIlIIIlllIIIlIlllIlIllIl.x - this.IlllIllIlIIIIlIIlIIllIIIl.x;
            final double n3 = this.IIIIllIIllIIIIllIllIIIlIl.y - this.lIIIIllIIlIlIllIIIlIllIlI.y;
            final double n4 = this.IlIlIIIlllIIIlIlllIlIllIl.y - this.IlllIllIlIIIIlIIlIIllIIIl.y;
            final double n5 = this.lIIlIlIllIIlIIIlIIIlllIII / (float)this.IIIlllIIIllIllIlIIIIIIlII;
            final double n6 = this.IIIIllIIllIIIIllIllIIIlIl.x - n * n5;
            final double n7 = this.IlIlIIIlllIIIlIlllIlIllIl.x - n2 * n5;
            final double n8 = this.IIIIllIIllIIIIllIllIIIlIl.y - n3 * n5;
            final double n9 = this.IlIlIIIlllIIIlIlllIlIllIl.y - n4 * n5;
            this.IIIllIllIlIlllllllIlIlIII = new Vec2d(n6, n8);
            this.IllIIIIIIIlIlIllllIIllIII = new Vec2d(n7, n9);
            ++this.lIIlIlIllIIlIIIlIIIlllIII;
        }
        else if (this.IlIlIIIlllIIIlIlllIlIllIl != this.IllIIIIIIIlIlIllllIIllIII || this.IIIIllIIllIIIIllIllIIIlIl != this.IIIllIllIlIlllllllIlIlIII) {
            this.IIIIllIIllIIIIllIllIIIlIl = this.IIIllIllIlIlllllllIlIlIII;
            this.IlIlIIIlllIIIlIlllIlIllIl = this.IllIIIIIIIlIlIllllIIllIII;
            this.IllIIIIIIIlIlIllllIIllIII = this.IlllIllIlIIIIlIIlIIllIIIl;
            this.IIIllIllIlIlllllllIlIlIII = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.IIIlllIIIllIllIlIIIIIIlII = 0;
            this.lIIlIlIllIIlIIIlIIIlllIII = 0;
        }
    }
    
    boolean IlllIIIlIlllIllIlIIlllIlI() {
        return CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI().lIIIIllIIlIlIllIIIlIllIlI().equals(this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    double IIIIllIlIIIllIlllIlllllIl() {
        return this.IllIIIIIIIlIlIllllIIllIII.x;
    }
    
    double IIIIllIIllIIIIllIllIIIlIl() {
        return this.IllIIIIIIIlIlIllllIIllIII.y;
    }
    
    double IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIllIllIlIlllllllIlIlIII.x;
    }
    
    double IIIllIllIlIlllllllIlIlIII() {
        return this.IIIllIllIlIlllllllIlIlIII.y;
    }
    
    double lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIlIllllIlIIllllIIlll);
    }
    
    double lIIIIIIIIIlIllIIllIlIIlIl(final double n, final double n2) {
        return Math.min(Math.min(Math.min(n - this.IlIlIIIlllIIIlIlllIlIllIl(), this.IIIIllIlIIIllIlllIlllllIl() - n), n2 - this.IIIllIllIlIlllllllIlIlIII()), this.IIIIllIIllIIIIllIllIIIlIl() - n2);
    }
    
    double IlllIIIlIlllIllIlIIlllIlI(final double n, final double n2) {
        return Math.min(n2 - this.IIIllIllIlIlllllllIlIlIII(), this.IIIIllIIllIIIIllIllIIIlIl() - n2);
    }
    
    double IIIIllIlIIIllIlllIlllllIl(final double n, final double n2) {
        return Math.min(n - this.IlIlIIIlllIIIlIlllIlIllIl(), this.IIIIllIlIIIllIlllIlllllIl() - n);
    }
    
    public String IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public String lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public Color IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public Vec2d IlIlllIIIIllIllllIllIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public Vec2d llIIlllIIIIlllIllIlIlllIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public Vec2d lIIlIlIllIIlIIIlIIIlllIII() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public Vec2d IIIlllIIIllIllIlIIIIIIlII() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public Vec2d llIlIIIlIIIIlIlllIlIIIIll() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public Vec2d IIIlIIllllIIllllllIlIIIll() {
        return this.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    public boolean lllIIIIIlIllIlIIIllllllII() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public boolean lIIIIIllllIIIIlIlIIIIlIlI() {
        return this.llIIlllIIIIlllIllIlIlllIl;
    }
    
    public int IIIIIIlIlIlIllllllIlllIlI() {
        return this.lIIlIlIllIIlIIIlIIIlllIII;
    }
    
    public int IllIllIIIlIIlllIIIllIllII() {
        return this.IIIlllIIIllIllIlIIIIIIlII;
    }
}
