// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIlIIlIIlllllIlllIlI extends lIIlllIIIlIllllllIlIlIIII
{
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return true;
    }
}
