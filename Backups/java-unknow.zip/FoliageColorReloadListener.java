import java.io.IOException;

// 
// Decompiled by Procyon v0.5.36
// 

public class FoliageColorReloadListener implements IllIllllIIlIllIlIlllllIII
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        try {
            IlllIlIIlIllIlIlllllIIIII.lIIIIlIIllIIlIIlIIIlIIllI(lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIllIllIllIIIIlIlllllIlI, FoliageColorReloadListener.lIIIIlIIllIIlIIlIIIlIIllI));
        }
        catch (IOException ex) {}
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/colormap/foliage.png");
    }
}
