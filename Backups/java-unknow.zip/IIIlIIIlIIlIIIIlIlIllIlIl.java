// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlIIlIIIIlIlIllIlIl extends IllIlIllllllIIIIIllIllIlI
{
    protected final llllllllllllIlIIIIIIIIlll lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIIIlIIlIIIIlIlIllIlIl(final llllllllllllIlIIIIIIIIlll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean hasNext() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.hasNext();
    }
    
    @Override
    public boolean hasPrevious() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.hasPrevious();
    }
    
    @Override
    public Object next() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.next();
    }
    
    @Override
    public Object previous() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.previous();
    }
    
    @Override
    public int nextIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.nextIndex();
    }
    
    @Override
    public int previousIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.previousIndex();
    }
}
