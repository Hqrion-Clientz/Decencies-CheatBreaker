import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIllIllIIlllIIIIlIII extends lIIIIIllIlIIIllllIlIlIIIl
{
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, int n2) {
        if (n2 > 3) {
            n2 = 3;
        }
        return (random.nextInt(10 - n2 * 3) == 0) ? IIlIlIllIlIIllIllIllIIIll.lIIlIlIIlIlIlIIlIlIlllIIl : lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
}
