import java.util.Iterator;
import java.util.UUID;
import com.google.common.collect.Maps;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIIIIIIIlllllIlIllIl
{
    public static final IIIlIlIIIIIIIlllllIlIllIl[] lIIIIlIIllIIlIIlIIIlIIllI;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIIIIIIIIlIllIIllIlIIlIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlllIIIlIlllIllIlIIlllIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIIllIlIIIllIlllIlllllIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIIllIIllIIIIllIllIIIlIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlIlIIIlllIIIlIlllIlIllIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIllIllIlIlllllllIlIlIII;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllIIIIIIIlIlIllllIIllIII;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIIIllIIlIlIllIIIlIllIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlllIllIlIIIIlIIlIIllIIIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlIlllIIIIllIllllIllIIlIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl llIIlllIIIIlllIllIlIlllIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIlIlIllIIlIIIlIIIlllIII;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIlllIIIllIllIlIIIIIIlII;
    public static final IIIlIlIIIIIIIlllllIlIllIl llIlIIIlIIIIlIlllIlIIIIll;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIlIIllllIIllllllIlIIIll;
    public static final IIIlIlIIIIIIIlllllIlIllIl lllIIIIIlIllIlIIIllllllII;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIIIIllllIIIIlIlIIIIlIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIIIIlIlIlIllllllIlllIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllIllIIIlIIlllIIIllIllII;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlIIlIIIIlIIIIllllIIlIllI;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIlIIllIIIIIlIllIIIIllII;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIIlllIIlIlllllllllIIIIIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIllIllIlIIllIllIlIlIIlIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl llIlIIIllIIIIlllIlIIIIIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIllIlIlllIIlIIllIIlIIlII;
    public static final IIIlIlIIIIIIIlllllIlIllIl IIIlIIlIlIIIlllIIlIllllll;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllIlIIIIlllIIllIIlllIIlI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllIlIlIllllIlIIllllIIlll;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllIIlIIlllllIllIIIlllIII;
    public static final IIIlIlIIIIIIIlllllIlIllIl lIlIlIllIIIIIIIIllllIIllI;
    public static final IIIlIlIIIIIIIlllllIlIllIl IlllIIlllIIIIllIIllllIlIl;
    public static final IIIlIlIIIIIIIlllllIlIllIl IllllIllllIlIIIlIIIllllll;
    public final int IllIIlllIllIlIllIlIIIIIII;
    private final Map IlIlIIIlllllIIIlIlIlIllII;
    private final boolean IIlIIllIIIllllIIlllIllIIl;
    private final int lllIlIIllllIIIIlIllIlIIII;
    private String lIIIIlllIIlIlllllIlIllIII;
    private int lIIIlllIlIlllIIIIIIIIIlII;
    private double IIIIlIIIlllllllllIlllIlll;
    private boolean IlIllllIIIlIllllIIIIIllII;
    
    protected IIIlIlIIIIIIIlllllIlIllIl(final int illIIlllIllIlIllIlIIIIIII, final boolean iIlIIllIIIllllIIlllIllIIl, final int lllIlIIllllIIIIlIllIlIIII) {
        this.IlIlIIIlllllIIIlIlIlIllII = Maps.newHashMap();
        this.lIIIIlllIIlIlllllIlIllIII = "";
        this.lIIIlllIlIlllIIIIIIIIIlII = -1;
        this.IllIIlllIllIlIllIlIIIIIII = illIIlllIllIlIllIlIIIIIII;
        IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[illIIlllIllIlIllIlIIIIIII] = this;
        this.IIlIIllIIIllllIIlllIllIIl = iIlIIllIIIllllIIlllIllIIl;
        if (iIlIIllIIIllllIIlllIllIIl) {
            this.IIIIlIIIlllllllllIlllIlll = 0.0555555559694767 * 8.999999932944775;
        }
        else {
            this.IIIIlIIIlllllllllIlllIlll = 1.0;
        }
        this.lllIlIIllllIIIIlIllIlIIII = lllIlIIllllIIIIlIllIlIIII;
    }
    
    protected IIIlIlIIIIIIIlllllIlIllIl lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        this.lIIIlllIlIlllIIIIIIIIIlII = n + n2 * 8;
        return this;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IllIIlllIllIlIllIlIIIIIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final int n) {
        if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl.IllIIlllIllIlIllIlIIIIIII) {
            if (entityLivingBase.getHealth() < entityLivingBase.IlllIIllllllllIlIlIlllllI()) {
                entityLivingBase.IlllIIIlIlllIllIlIIlllIlI(1.0f);
            }
        }
        else if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI.IllIIlllIllIlIllIlIIIIIII) {
            if (entityLivingBase.getHealth() > 1.0f) {
                entityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlIlllIIIIllIllllIllIIlIl, 1.0f);
            }
        }
        else if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.lIIlIIllIIIIIlIllIIIIllII.IllIIlllIllIlIllIlIIIIIII) {
            entityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.llIIlllIIIIlllIllIlIlllIl, 1.0f);
        }
        else if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IIIIIIlIlIlIllllllIlllIlI.IllIIlllIllIlIllIlIIIIIII && entityLivingBase instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            ((lIllIIIIlIIlIllIIIlIlIlll)entityLivingBase).IIIIllIIllIIIIllIllIIIlIl(0.006849315f * 3.65f * (n + 1));
        }
        else if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.llIlIIIllIIIIlllIlIIIIIlI.IllIIlllIllIlIllIlIIIIIII && entityLivingBase instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            if (!entityLivingBase.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                ((lIllIIIIlIIlIllIIIlIlIlll)entityLivingBase).IllIIIIIllllIlllIIlIIllIl().lIIIIlIIllIIlIIlIIIlIIllI(n + 1, 1.0f);
            }
        }
        else if ((this.IllIIlllIllIlIllIlIIIIIII != IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.IllIIlllIllIlIllIlIIIIIII || entityLivingBase.llIIIlllllIlllIIllIlIIlII()) && (this.IllIIlllIllIlIllIlIIIIIII != IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IllIIlllIllIlIllIlIIIIIII || !entityLivingBase.llIIIlllllIlllIIllIlIIlII())) {
            if ((this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IllIIlllIllIlIllIlIIIIIII && !entityLivingBase.llIIIlllllIlllIIllIlIIlII()) || (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.IllIIlllIllIlIllIlIIIIIII && entityLivingBase.llIIIlllllIlllIIllIlIIlII())) {
                entityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlIlllIIIIllIllllIllIIlIl, (float)(6 << n));
            }
        }
        else {
            entityLivingBase.IlllIIIlIlllIllIlIIlllIlI((float)Math.max(4 << n, 0));
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final EntityLivingBase entityLivingBase2, final int n, final double n2) {
        if ((this.IllIIlllIllIlIllIlIIIIIII != IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.IllIIlllIllIlIllIlIIIIIII || entityLivingBase2.llIIIlllllIlllIIllIlIIlII()) && (this.IllIIlllIllIlIllIlIIIIIII != IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IllIIlllIllIlIllIlIIIIIII || !entityLivingBase2.llIIIlllllIlllIIllIlIIlII())) {
            if ((this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.IllIIlllIllIlIllIlIIIIIII && !entityLivingBase2.llIIIlllllIlllIIllIlIIlII()) || (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.IllIIlllIllIlIllIlIIIIIII && entityLivingBase2.llIIIlllllIlllIIllIlIIlII())) {
                final int n3 = (int)(n2 * (6 << n) + 2.142857074737549 * 0.23333334075080048);
                if (entityLivingBase == null) {
                    entityLivingBase2.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlIlllIIIIllIllllIllIIlIl, (float)n3);
                }
                else {
                    entityLivingBase2.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIIIIIIlIllIIllIlIIlIl(entityLivingBase2, entityLivingBase), (float)n3);
                }
            }
        }
        else {
            entityLivingBase2.IlllIIIlIlllIllIlIIlllIlI((float)(int)(n2 * (4 << n) + 0.8196721076965332 * 0.6100000174522405));
        }
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return false;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl.IllIIlllIllIlIllIlIIIIIII) {
            final int n3 = 50 >> n2;
            return n3 <= 0 || n % n3 == 0;
        }
        if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI.IllIIlllIllIlIllIlIIIIIII) {
            final int n4 = 25 >> n2;
            return n4 <= 0 || n % n4 == 0;
        }
        if (this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.lIIlIIllIIIIIlIllIIIIllII.IllIIlllIllIlIllIlIIIIIII) {
            final int n5 = 40 >> n2;
            return n5 <= 0 || n % n5 == 0;
        }
        return this.IllIIlllIllIlIllIlIIIIIII == IIIlIlIIIIIIIlllllIlIllIl.IIIIIIlIlIlIllllllIlllIlI.IllIIlllIllIlIllIlIIIIIII;
    }
    
    public IIIlIlIIIIIIIlllllIlIllIl lIIIIlIIllIIlIIlIIIlIIllI(final String liiiIlllIIlIlllllIlIllIII) {
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        return this;
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlllIIlIlllllIlIllIII;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIlllIlIlllIIIIIIIIIlII >= 0;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIlllIlIlllIIIIIIIIIlII;
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIlIIllIIIllllIIlllIllIIl;
    }
    
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl) {
        if (llIlIlIIlIlIllllIIlIIIlIl.IlIlIIIlllIIIlIlllIlIllIl()) {
            return "**:**";
        }
        return IlIIllllIIlIIIIIIllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIlIlIllllIIlIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    protected IIIlIlIIIIIIIlllllIlIllIl lIIIIlIIllIIlIIlIIIlIIllI(final double iiiIlIIIlllllllllIlllIlll) {
        this.IIIIlIIIlllllllllIlllIlll = iiiIlIIIlllllllllIlllIlll;
        return this;
    }
    
    public double IIIllIllIlIlllllllIlIlIII() {
        return this.IIIIlIIIlllllllllIlllIlll;
    }
    
    public boolean IllIIIIIIIlIlIllllIIllIII() {
        return this.IlIllllIIIlIllllIIIIIllII;
    }
    
    public int lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lllIlIIllllIIIIlIllIlIIII;
    }
    
    public IIIlIlIIIIIIIlllllIlIllIl lIIIIlIIllIIlIIlIIIlIIllI(final llIIllIlllllIIIlIIIIlIlll llIIllIlllllIIIlIIIIlIlll, final String name, final double n, final int n2) {
        this.IlIlIIIlllllIIIlIlIlIllII.put(llIIllIlllllIIIlIIIIlIlll, new IllIIlIIllIlllIIIIIllllII(UUID.fromString(name), this.IlllIIIlIlllIllIlIIlllIlI(), n, n2));
        return this;
    }
    
    public Map IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IlIlIIIlllllIIIlIlIlIllII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final IlIlIIlllIIllIIIllIIllIlI ilIlIIlllIIllIIIllIIllIlI, final int n) {
        for (final Map.Entry<llIIllIlllllIIIlIIIIlIlll, V> entry : this.IlIlIIIlllllIIIlIlIlIllII.entrySet()) {
            final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = ilIlIIlllIIllIIIllIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey());
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl((IllIIlIIllIlllIIIIIllllII)entry.getValue());
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final IlIlIIlllIIllIIIllIIllIlI ilIlIIlllIIllIIIllIIllIlI, final int i) {
        for (final Map.Entry<llIIllIlllllIIIlIIIIlIlll, V> entry : this.IlIlIIIlllllIIIlIlIlIllII.entrySet()) {
            final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = ilIlIIlllIIllIIIllIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey());
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                final IllIIlIIllIlllIIIIIllllII illIIlIIllIlllIIIIIllllII = (IllIIlIIllIlllIIIIIllllII)entry.getValue();
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(illIIlIIllIlllIIIIIllllII);
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(new IllIIlIIllIlllIIIIIllllII(illIIlIIllIlllIIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI(), this.IlllIIIlIlllIllIlIIlllIlI() + " " + i, this.lIIIIlIIllIIlIIlIIIlIIllI(i, illIIlIIllIlllIIIIIllllII), illIIlIIllIlllIIIIIllllII.IlllIIIlIlllIllIlIIlllIlI()));
            }
        }
    }
    
    public double lIIIIlIIllIIlIIlIIIlIIllI(final int n, final IllIIlIIllIlllIIIIIllllII illIIlIIllIlllIIIIIllllII) {
        return illIIlIIllIlllIIIIIllllII.IIIIllIlIIIllIlllIlllllIl() * (n + 1);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new IIIlIlIIIIIIIlllllIlIllIl[32];
        lIIIIIIIIIlIllIIllIlIIlIl = null;
        IlllIIIlIlllIllIlIIlllIlI = new IIIlIlIIIIIIIlllllIlIllIl(1, false, 8171462).lIIIIlIIllIIlIIlIIIlIIllI("potion.moveSpeed").lIIIIlIIllIIlIIlIIIlIIllI(0, 0).lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl, "91AEAA56-376B-4498-935B-2F7F68070635", 0.16176470659131822 * 1.2363636493682861, 2);
        IIIIllIlIIIllIlllIlllllIl = new IIIlIlIIIIIIIlllllIlIllIl(2, true, 5926017).lIIIIlIIllIIlIIlIIIlIIllI("potion.moveSlowdown").lIIIIlIIllIIlIIlIIIlIIllI(1, 0).lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl, "7107DE5E-7CE8-4030-940E-514C1F160890", 0.47826087474823 * -0.31363637270021033, 2);
        IIIIllIIllIIIIllIllIIIlIl = new IIIlIlIIIIIIIlllllIlIllIl(3, false, 14270531).lIIIIlIIllIIlIIlIIIlIIllI("potion.digSpeed").lIIIIlIIllIIlIIlIIIlIIllI(2, 0).lIIIIlIIllIIlIIlIIIlIIllI(1.6200000270366672 * 0.9259259104728699);
        IlIlIIIlllIIIlIlllIlIllIl = new IIIlIlIIIIIIIlllllIlIllIl(4, true, 4866583).lIIIIlIIllIIlIIlIIIlIIllI("potion.digSlowDown").lIIIIlIIllIIlIIlIIIlIIllI(3, 0);
        IIIllIllIlIlllllllIlIlIII = new llIllIllllllIIlIIlIlllIlI(5, false, 9643043).lIIIIlIIllIIlIIlIIIlIIllI("potion.damageBoost").lIIIIlIIllIIlIIlIIIlIIllI(4, 0).lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIIllIIIIllIllIIIlIl, "648D7064-6A60-4F59-8ABE-C2C23A6DD7A9", 3, 2);
        IllIIIIIIIlIlIllllIIllIII = new IIIIIIIIIIIIIIlIIIIllIIIl(6, false, 16262179).lIIIIlIIllIIlIIlIIIlIIllI("potion.heal");
        lIIIIllIIlIlIllIIIlIllIlI = new IIIIIIIIIIIIIIlIIIIllIIIl(7, true, 4393481).lIIIIlIIllIIlIIlIIIlIIllI("potion.harm");
        IlllIllIlIIIIlIIlIIllIIIl = new IIIlIlIIIIIIIlllllIlIllIl(8, false, 7889559).lIIIIlIIllIIlIIlIIIlIIllI("potion.jump").lIIIIlIIllIIlIIlIIIlIIllI(2, 1);
        IlIlllIIIIllIllllIllIIlIl = new IIIlIlIIIIIIIlllllIlIllIl(9, true, 5578058).lIIIIlIIllIIlIIlIIIlIIllI("potion.confusion").lIIIIlIIllIIlIIlIIIlIIllI(3, 1).lIIIIlIIllIIlIIlIIIlIIllI(0.07941176693332243 * 3.1481480598449707);
        llIIlllIIIIlllIllIlIlllIl = new IIIlIlIIIIIIIlllllIlIllIl(10, false, 13458603).lIIIIlIIllIIlIIlIIIlIIllI("potion.regeneration").lIIIIlIIllIIlIIlIIIlIIllI(7, 0).lIIIIlIIllIIlIIlIIIlIIllI(0.4642857015132904 * 0.5384615532745275);
        lIIlIlIllIIlIIIlIIIlllIII = new IIIlIlIIIIIIIlllllIlIllIl(11, false, 10044730).lIIIIlIIllIIlIIlIIIlIIllI("potion.resistance").lIIIIlIIllIIlIIlIIIlIIllI(6, 1);
        IIIlllIIIllIllIlIIIIIIlII = new IIIlIlIIIIIIIlllllIlIllIl(12, false, 14981690).lIIIIlIIllIIlIIlIIIlIIllI("potion.fireResistance").lIIIIlIIllIIlIIlIIIlIIllI(7, 1);
        llIlIIIlIIIIlIlllIlIIIIll = new IIIlIlIIIIIIIlllllIlIllIl(13, false, 3035801).lIIIIlIIllIIlIIlIIIlIIllI("potion.waterBreathing").lIIIIlIIllIIlIIlIIIlIIllI(0, 2);
        IIIlIIllllIIllllllIlIIIll = new IIIlIlIIIIIIIlllllIlIllIl(14, false, 8356754).lIIIIlIIllIIlIIlIIIlIIllI("potion.invisibility").lIIIIlIIllIIlIIlIIIlIIllI(0, 1);
        lllIIIIIlIllIlIIIllllllII = new IIIlIlIIIIIIIlllllIlIllIl(15, true, 2039587).lIIIIlIIllIIlIIlIIIlIIllI("potion.blindness").lIIIIlIIllIIlIIlIIIlIIllI(5, 1).lIIIIlIIllIIlIIlIIIlIIllI(1.5740740299224854 * 0.15882353386664486);
        lIIIIIllllIIIIlIlIIIIlIlI = new IIIlIlIIIIIIIlllllIlIllIl(16, false, 2039713).lIIIIlIIllIIlIIlIIIlIIllI("potion.nightVision").lIIIIlIIllIIlIIlIIIlIIllI(4, 1);
        IIIIIIlIlIlIllllllIlllIlI = new IIIlIlIIIIIIIlllllIlIllIl(17, true, 5797459).lIIIIlIIllIIlIIlIIIlIIllI("potion.hunger").lIIIIlIIllIIlIIlIIIlIIllI(1, 1);
        IllIllIIIlIIlllIIIllIllII = new llIllIllllllIIlIIlIlllIlI(18, true, 4738376).lIIIIlIIllIIlIIlIIIlIIllI("potion.weakness").lIIIIlIIllIIlIIlIIIlIIllI(5, 0).lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIIllIIIIllIllIIIlIl, "22653B89-116E-49DC-9B6B-9971489B5BE5", 2, 0);
        IlIIlIIIIlIIIIllllIIlIllI = new IIIlIlIIIIIIIlllllIlIllIl(19, true, 5149489).lIIIIlIIllIIlIIlIIIlIIllI("potion.poison").lIIIIlIIllIIlIIlIIIlIIllI(6, 0).lIIIIlIIllIIlIIlIIIlIIllI(0.7931034564971924 * 0.31521738803679644);
        lIIlIIllIIIIIlIllIIIIllII = new IIIlIlIIIIIIIlllllIlIllIl(20, true, 3484199).lIIIIlIIllIIlIIlIIIlIIllI("potion.wither").lIIIIlIIllIIlIIlIIIlIIllI(1, 2).lIIIIlIIllIIlIIlIIIlIIllI(0.1643835573488116 * 1.5208333730697632);
        lIIlllIIlIlllllllllIIIIIl = new lIlIlIIllIlIIllIlllIllIIl(21, false, 16284963).lIIIIlIIllIIlIIlIIIlIIllI("potion.healthBoost").lIIIIlIIllIIlIIlIIIlIIllI(2, 2).lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI, "5D6F0BA2-1186-46AC-B896-C61C5CEE99CC", 4, 0);
        lIllIllIlIIllIllIlIlIIlIl = new lIIlIIIlIlIlIlIIIlIIlIlIl(22, false, 2445989).lIIIIlIIllIIlIIlIIIlIIllI("potion.absorption").lIIIIlIIllIIlIIlIIIlIIllI(2, 2);
        llIlIIIllIIIIlllIlIIIIIlI = new IIIIIIIIIIIIIIlIIIIllIIIl(23, false, 16262179).lIIIIlIIllIIlIIlIIIlIIllI("potion.saturation");
        lIllIlIlllIIlIIllIIlIIlII = null;
        IIIlIIlIlIIIlllIIlIllllll = null;
        IllIlIIIIlllIIllIIlllIIlI = null;
        IllIlIlIllllIlIIllllIIlll = null;
        IllIIlIIlllllIllIIIlllIII = null;
        lIlIlIllIIIIIIIIllllIIllI = null;
        IlllIIlllIIIIllIIllllIlIl = null;
        IllllIllllIlIIIlIIIllllll = null;
    }
}
