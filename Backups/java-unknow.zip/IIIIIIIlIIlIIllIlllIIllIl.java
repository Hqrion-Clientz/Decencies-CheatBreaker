import java.util.Iterator;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlIIlIIllIlllIIllIl extends IlIIIllllllIllIlllllIIllI
{
    public static final Pattern lIIIIlIIllIIlIIlIIIlIIllI;
    
    @Override
    public String getIdentifier() {
        return "ban-ip";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 3;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI() && super.lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII);
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.banip.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length >= 1 && array[0].length() > 1) {
            final Matcher matcher = IIIIIIIlIIlIIllIlllIIllIl.lIIIIlIIllIIlIIlIIIlIIllI.matcher(array[0]);
            IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI = null;
            if (array.length >= 2) {
                liiiIlIIllIIlIIlIIIlIIllI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array, 1);
            }
            if (matcher.matches()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[0], (liiiIlIIllIIlIIlIIIlIIllI == null) ? null : liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI());
            }
            else {
                final llIIIIIIlIlllllIIllllIlII liiiIlIIllIIlIIlIIIlIIllI2 = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIlIIllIIlIIlIIIlIIllI(array[0]);
                if (liiiIlIIllIIlIIlIIIlIIllI2 == null) {
                    throw new lIIIIllIIIlllIlllIlllIIlI("commands.banip.invalid", new Object[0]);
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI2.llIlIIIllIIIIlllIlIIIIIlI(), (liiiIlIIllIIlIIlIIIlIIllI == null) ? null : liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI());
            }
            return;
        }
        throw new IIllllIlIlIIlllIlIIllIIll("commands.banip.usage", new Object[0]);
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl()) : null;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String s, final String s2) {
        llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(new IIlIlIIIlIIIlllllIIIIlllI(s, null, lIlllllIIIIIIllIlIIlIlIII.IlIlIIIlllllIIIlIlIlIllII(), null, s2));
        final List liiiiiiiiIlIllIIllIlIIlIl = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIIIIIIlIllIIllIlIIlIl(s);
        final String[] array = new String[liiiiiiiiIlIllIIllIlIIlIl.size()];
        int n = 0;
        for (final llIIIIIIlIlllllIIllllIlII llIIIIIIlIlllllIIllllIlII : liiiiiiiiIlIllIIllIlIIlIl) {
            llIIIIIIlIlllllIIllllIlII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("You have been IP banned.");
            array[n++] = llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII();
        }
        if (liiiiiiiiIlIllIIllIlIIlIl.isEmpty()) {
            IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.banip.success", s);
        }
        else {
            IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.banip.success.players", s, IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI((Object[])array));
        }
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = Pattern.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");
    }
}
