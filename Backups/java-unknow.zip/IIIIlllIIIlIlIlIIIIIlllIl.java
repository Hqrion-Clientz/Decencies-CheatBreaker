import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIIIlIlIlIIIIIlllIl extends lIlIIllIlIlIIlIIlIlIIlIII
{
    private Class lIIIIlllIIlIlllllIlIllIII;
    private boolean lIIIlllIlIlllIIIIIIIIIlII;
    
    protected IIIIlllIIIlIlIlIIIIIlllIl(final Class liiiIlllIIlIlllllIlIllIII, final boolean liiIlllIlIlllIIIIIIIIIlII) {
        super(Material.IIIIllIlIIIllIlllIlllllIl);
        this.lIIIlllIlIlllIIIIIIIIIlII = liiIlllIlIlllIIIIIIIIIlII;
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        final float n = 4.3076925f * 0.058035713f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.36956522f * 1.3529412f - n, 0.0f, 2.0f * 0.25f - n, 0.45454547f * 1.1f + n, 1.0f, 0.3275862f * 1.5263158f + n);
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(n);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.IlllIIIlIlllIllIlIIlllIlI((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return super.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        if (!this.lIIIlllIlIlllIIIIIIIIIlII) {
            final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            final float n4 = 0.13392858f * 2.1f;
            final float n5 = 0.4476826f * 1.745098f;
            final float n6 = 0.0f;
            final float n7 = 1.0f;
            final float n8 = 5.714286f * 0.021875f;
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            if (illlIIIlIlllIllIlIIlllIlI == 2) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(n6, n4, 1.0f - n8, n7, n5, 1.0f);
            }
            if (illlIIIlIlllIllIlIIlllIlI == 3) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(n6, n4, 0.0f, n7, n5, n8);
            }
            if (illlIIIlIlllIllIlIIlllIlI == 4) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f - n8, n4, n6, 1.0f, n5, n7);
            }
            if (illlIIIlIlllIllIlIIlllIlI == 5) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, n4, n6, n8, n5, n7);
            }
        }
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return -1;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return true;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public IllIllIlIIlllIllIIllIlIIl lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n) {
        try {
            return this.lIIIIlllIIlIlllllIlIllIII.newInstance();
        }
        catch (Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return IIlIlIllIlIIllIllIllIIIll.llIIIlIlIIlIlIIlIllIllIll;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        boolean b = false;
        if (this.lIIIlllIlIlllIIIIIIIIIlII) {
            if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
                b = true;
            }
        }
        else {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            b = true;
            if (illlIIIlIlllIllIlIIlllIlI == 2 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
                b = false;
            }
            if (illlIIIlIlllIllIlIIlllIlI == 3 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
                b = false;
            }
            if (illlIIIlIlllIllIlIIlllIlI == 4 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
                b = false;
            }
            if (illlIIIlIlllIllIlIIlllIlI == 5 && iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl()) {
                b = false;
            }
        }
        if (b) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 0);
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIlIlIllIlIIllIllIllIIIll.llIIIlIlIIlIlIIlIllIllIll;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
    }
}
