import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIllIIlllllllllIIIIlIIIlI implements Callable
{
    final /* synthetic */ IllIlIlllIIIIIIlIIllIIIll lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIllIIlllllllllIIIIlIIIlI(final IllIlIlllIIIIIIlIIllIIIll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "";
    }
}
