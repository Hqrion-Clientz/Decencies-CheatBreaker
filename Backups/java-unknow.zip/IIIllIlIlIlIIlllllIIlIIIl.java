import java.util.Iterator;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIlIlIlIIlllllIIlIIIl extends IllIlIllIIIllllllIIIllIlI
{
    private double IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIllIlIlIlIIlllllIIlIIIl() {
        this.IIIIllIIllIIIIllIllIIIlIl = 0.0036417910382964876 * 1.0983606576919556;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "Mineshaft";
    }
    
    public IIIllIlIlIlIIlllllIIlIIIl(final Map map) {
        this.IIIIllIIllIIIIllIllIIIlIl = 0.568965494632721 * 0.007030303309662185;
        for (final Map.Entry<String, V> entry : map.entrySet()) {
            if (entry.getKey().equals("chance")) {
                this.IIIIllIIllIIIIllIllIIIlIl = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((String)entry.getValue(), this.IIIIllIIllIIIIllIllIIIlIl);
            }
        }
    }
    
    @Override
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final int a, final int a2) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.nextDouble() < this.IIIIllIIllIIIIllIllIIIlIl && this.lIIIIIIIIIlIllIIllIlIIlIl.nextInt(80) < Math.max(Math.abs(a), Math.abs(a2));
    }
    
    @Override
    protected IllllIlllIlIlIlllIIIlIlll lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return new lIIIIlIIIIllIIlIIlIIlIlIl(this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl, n, n2);
    }
}
