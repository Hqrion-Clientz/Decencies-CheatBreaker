import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIlIllIlIllIlllIlll extends IIIlllIIIIIlIllIIIIIIIlll
{
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public byte IIIIllIlIIIllIlllIlllllIl;
    public byte IIIIllIIllIIIIllIllIIIlIl;
    public byte[] IlIlIIIlllIIIlIlllIlIllIl;
    public List IIIllIllIlIlllllllIlIlIII;
    private Map lIIIIllIIlIlIllIIIlIllIlI;
    public Map IllIIIIIIIlIlIllllIIllIII;
    
    public IIIlIIIIlIllIlIllIlllIlll(final String s) {
        super(s);
        this.IlIlIIIlllIIIlIlllIlIllIl = new byte[16384];
        this.IIIllIllIlIlllllllIlIlIII = new ArrayList();
        this.lIIIIllIIlIlIllIIIlIllIlI = new HashMap();
        this.IllIIIIIIIlIlIllllIIllIII = new LinkedHashMap();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.IIIIllIlIIIllIlllIlllllIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("dimension");
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("xCenter");
        this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("zCenter");
        this.IIIIllIIllIIIIllIllIIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("scale");
        if (this.IIIIllIIllIIIIllIllIIIlIl < 0) {
            this.IIIIllIIllIIIIllIllIIIlIl = 0;
        }
        if (this.IIIIllIIllIIIIllIllIIIlIl > 4) {
            this.IIIIllIIllIIIIllIllIIIlIl = 4;
        }
        final short iiiIllIIllIIIIllIllIIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("width");
        final short iiiIllIIllIIIIllIllIIIlIl2 = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("height");
        if (iiiIllIIllIIIIllIllIIIlIl == 128 && iiiIllIIllIIIIllIllIIIlIl2 == 128) {
            this.IlIlIIIlllIIIlIlllIlIllIl = ilIIIllIIlIIlllIllllIIIIl.IlIlllIIIIllIllllIllIIlIl("colors");
        }
        else {
            final byte[] ilIlllIIIIllIllllIllIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlllIIIIllIllllIllIIlIl("colors");
            this.IlIlIIIlllIIIlIlllIlIllIl = new byte[16384];
            final int n = (128 - iiiIllIIllIIIIllIllIIIlIl) / 2;
            final int n2 = (128 - iiiIllIIllIIIIllIllIIIlIl2) / 2;
            for (short n3 = 0; n3 < iiiIllIIllIIIIllIllIIIlIl2; ++n3) {
                final int n4 = n3 + n2;
                if (n4 >= 0 || n4 < 128) {
                    for (short n5 = 0; n5 < iiiIllIIllIIIIllIllIIIlIl; ++n5) {
                        final int n6 = n5 + n;
                        if (n6 >= 0 || n6 < 128) {
                            this.IlIlIIIlllIIIlIlllIlIllIl[n6 + n4 * 128] = ilIlllIIIIllIllllIllIIlIl[n5 + n3 * iiiIllIIllIIIIllIllIIIlIl];
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("dimension", this.IIIIllIlIIIllIlllIlllllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("xCenter", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("zCenter", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("scale", this.IIIIllIIllIIIIllIllIIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("width", (short)128);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("height", (short)128);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("colors", this.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        if (!this.lIIIIllIIlIlIllIIIlIllIlI.containsKey(lIllIIIIlIIlIllIIIlIlIlll)) {
            final IIllllllIIIIlllIlIIlIlllI illllllIIIIlllIlIIlIlllI = new IIllllllIIIIlllIlIIlIlllI(this, lIllIIIIlIIlIllIIIlIlIlll);
            this.lIIIIllIIlIlIllIIIlIllIlI.put(lIllIIIIlIIlIllIIIlIlIlll, illllllIIIIlllIlIIlIlllI);
            this.IIIllIllIlIlllllllIlIlIII.add(illllllIIIIlllIlIIlIlllI);
        }
        if (!lIllIIIIlIIlIllIIIlIlIlll.inventory.IlllIIIlIlllIllIlIIlllIlI(lIlIlIlIlIllllIlllIIIlIlI)) {
            this.IllIIIIIIIlIlIllllIIllIII.remove(lIllIIIIlIIlIllIIIlIlIlll.IlIlIIIlllllIIIlIlIlIllII());
        }
        for (int i = 0; i < this.IIIllIllIlIlllllllIlIlIII.size(); ++i) {
            final IIllllllIIIIlllIlIIlIlllI illllllIIIIlllIlIIlIlllI2 = this.IIIllIllIlIlllllllIlIlIII.get(i);
            if (!illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IIllIlIllIlIllIIlIllIlIII && (illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.inventory.IlllIIIlIlllIllIlIIlllIlI(lIlIlIlIlIllllIlllIIIlIlI) || lIlIlIlIlIllllIlllIIIlIlI.IIIlIIlIlIIIlllIIlIllllll())) {
                if (!lIlIlIlIlIllllIlllIIIlIlI.IIIlIIlIlIIIlllIIlIllllll() && illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IIIIIIIllIllllIIlIIlllIII == this.IIIIllIlIIIllIlllIlllllIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(0, illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl, illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllllIIIlIlIlIllII(), illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll, illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll, illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll);
                }
            }
            else {
                this.lIIIIllIIlIlIllIIIlIllIlI.remove(illllllIIIIlllIlIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI);
                this.IIIllIllIlIlllllllIlIlIII.remove(illllllIIIIlllIlIIlIlllI2);
            }
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.IIIlIIlIlIIIlllIIlIllllll()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(1, lIllIIIIlIIlIllIIIlIlIlll.lIIlllIIlIlllllllllIIIIIl, "frame-" + lIlIlIlIlIllllIlllIIIlIlI.IllIlIIIIlllIIllIIlllIIlI().lIIIIlllIIlIlllllIlIllIII(), lIlIlIlIlIllllIlllIIIlIlI.IllIlIIIIlllIIllIIlllIIlI().lIIIIIIIIIlIllIIllIlIIlIl, lIlIlIlIlIllllIlllIIIlIlI.IllIlIIIIlllIIllIIlllIIlI().IIIIllIlIIIllIlllIlllllIl, lIlIlIlIlIllllIlllIIIlIlI.IllIlIIIIlllIIllIIlllIIlI().lIIIIlIIllIIlIIlIIIlIIllI * 90);
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(int n, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final String s, final double n2, final double n3, double n4) {
        final int n5 = 1 << this.IIIIllIIllIIIIllIllIIIlIl;
        final float a = (float)(n2 - this.lIIIIIIIIIlIllIIllIlIIlIl) / n5;
        final float a2 = (float)(n3 - this.IlllIIIlIlllIllIlIIlllIlI) / n5;
        byte b = (byte)(a * 2.0f + 0.9784946441650391 * 0.5109890002787454);
        byte b2 = (byte)(a2 * 2.0f + 1.9696969985961914 * 0.25384615012174533);
        final int n6 = 63;
        byte b3;
        if (a >= -n6 && a2 >= -n6 && a <= n6 && a2 <= n6) {
            n4 += ((n4 < 0.0) ? -8 : ((double)8));
            b3 = (byte)(n4 * 16 / 360);
            if (this.IIIIllIlIIIllIlllIlllllIl < 0) {
                final int n7 = (int)(iiiiiIllIlIIIIlIlllIllllI.lIllIlIlllIIlIIllIIlIIlII().IIIllIllIlIlllllllIlIlIII() / 10L);
                b3 = (byte)(n7 * n7 * 34187121 + n7 * 121 >> 15 & 0xF);
            }
        }
        else {
            if (Math.abs(a) >= 320 || Math.abs(a2) >= 320) {
                this.IllIIIIIIIlIlIllllIIllIII.remove(s);
                return;
            }
            n = 6;
            b3 = 0;
            if (a <= -n6) {
                b = (byte)(n6 * 2 + 14.999999552965177 * 0.1666666716337204);
            }
            if (a2 <= -n6) {
                b2 = (byte)(n6 * 2 + 2.863636338809305 * 0.8730158805847168);
            }
            if (a >= n6) {
                b = (byte)(n6 * 2 + 1);
            }
            if (a2 >= n6) {
                b2 = (byte)(n6 * 2 + 1);
            }
        }
        this.IllIIIIIIIlIlIllllIIllIII.put(s, new IIIlIlIllIIIlIlIIllllIlIl(this, (byte)n, b, b2, b3));
    }
    
    public byte[] lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final IIllllllIIIIlllIlIIlIlllI illllllIIIIlllIlIIlIlllI = this.lIIIIllIIlIlIllIIIlIllIlI.get(lIllIIIIlIIlIllIIIlIlIlll);
        return (byte[])((illllllIIIIlllIlIIlIlllI == null) ? null : illllllIIIIlllIlIIlIlllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        super.IIIIllIlIIIllIlllIlllllIl();
        for (int i = 0; i < this.IIIllIllIlIlllllllIlIlIII.size(); ++i) {
            final IIllllllIIIIlllIlIIlIlllI illllllIIIIlllIlIIlIlllI = this.IIIllIllIlIlllllllIlIlIII.get(i);
            if (illllllIIIIlllIlIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl[n] < 0 || illllllIIIIlllIlIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl[n] > n2) {
                illllllIIIIlllIlIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl[n] = n2;
            }
            if (illllllIIIIlllIlIIlIlllI.IlllIIIlIlllIllIlIIlllIlI[n] < 0 || illllllIIIIlllIlIIlIlllI.IlllIIIlIlllIllIlIIlllIlI[n] < n3) {
                illllllIIIIlllIlIIlIlllI.IlllIIIlIlllIllIlIIlllIlI[n] = n3;
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte[] array) {
        if (array[0] == 0) {
            final int n = array[1] & 0xFF;
            final int n2 = array[2] & 0xFF;
            for (int i = 0; i < array.length - 3; ++i) {
                this.IlIlIIIlllIIIlIlllIlIllIl[(i + n2) * 128 + n] = array[i + 3];
            }
            this.IIIIllIlIIIllIlllIlllllIl();
        }
        else if (array[0] == 1) {
            this.IllIIIIIIIlIlIllllIIllIII.clear();
            for (int j = 0; j < (array.length - 1) / 3; ++j) {
                this.IllIIIIIIIlIlIllllIIllIII.put("icon-" + j, new IIIlIlIllIIIlIlIIllllIlIl(this, (byte)(array[j * 3 + 1] >> 4), array[j * 3 + 2], array[j * 3 + 3], (byte)(array[j * 3 + 1] & 0xF)));
            }
        }
        else if (array[0] == 2) {
            this.IIIIllIIllIIIIllIllIIIlIl = array[1];
        }
    }
    
    public IIllllllIIIIlllIlIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        IIllllllIIIIlllIlIIlIlllI illllllIIIIlllIlIIlIlllI = this.lIIIIllIIlIlIllIIIlIllIlI.get(lIllIIIIlIIlIllIIIlIlIlll);
        if (illllllIIIIlllIlIIlIlllI == null) {
            illllllIIIIlllIlIIlIlllI = new IIllllllIIIIlllIlIIlIlllI(this, lIllIIIIlIIlIllIIIlIlIlll);
            this.lIIIIllIIlIlIllIIIlIllIlI.put(lIllIIIIlIIlIllIIIlIlIlll, illllllIIIIlllIlIIlIlllI);
            this.IIIllIllIlIlllllllIlIlIII.add(illllllIIIIlllIlIIlIlllI);
        }
        return illllllIIIIlllIlIIlIlllI;
    }
}
