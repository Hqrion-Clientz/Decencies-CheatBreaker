// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllllIIIlIllIIIIIIllll extends lIlllIIIIllIlllIlIlIllIII
{
    private final lllIllIIIllllIlIlllllllll IlIlllIIIIllIllllIllIIlIl;
    private float llIIlllIIIIlllIllIlIlllIl;
    
    public IIIIllllIIIlIllIIIIIIllll(final lllIllIIIllllIlIlllllllll ilIlllIIIIllIllllIllIIlIl) {
        super(new ResourceLocation("minecraft:minecart.base"));
        this.llIIlllIIIIlllIllIlIlllIl = 0.0f;
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        this.IllIIIIIIIlIlIllllIIllIII = true;
        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
    }
    
    @Override
    public void IlIlllIIIIllIllllIllIIlIl() {
        if (this.IlIlllIIIIllIllllIllIIlIl.IIllIlIllIlIllIIlIllIlIII) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = true;
        }
        else {
            this.IIIIllIIllIIIIllIllIIIlIl = (float)this.IlIlllIIIIllIllllIllIIlIl.IIIlIIlIlIIIlllIIlIllllll;
            this.IlIlIIIlllIIIlIlllIlIllIl = (float)this.IlIlllIIIIllIllllIllIIlIl.IllIlIIIIlllIIllIIlllIIlI;
            this.IIIllIllIlIlllllllIlIlIII = (float)this.IlIlllIIIIllIllllIllIIlIl.IllIlIlIllllIlIIllllIIlll;
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl.IllIIlIIlllllIllIIIlllIII * this.IlIlllIIIIllIllllIllIIlIl.IllIIlIIlllllIllIIIlllIII + this.IlIlllIIIIllIllllIllIIlIl.IlllIIlllIIIIllIIllllIlIl * this.IlIlllIIIIllIllllIllIIlIl.IlllIIlllIIIIllIIllllIlIl);
            if (liiiIlIIllIIlIIlIIIlIIllI >= 0.6744186282157898 * 0.014827585688811012) {
                this.llIIlllIIIIlllIllIlIlllIl = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.llIIlllIIIIlllIllIlIlllIl + 0.9230769f * 0.0027083333f, 0.0f, 1.0f);
                this.IlllIIIlIlllIllIlIIlllIlI = 0.0f + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 0.0f, 0.16216217f * 3.0833333f) * (0.33333334f * 2.1f);
            }
            else {
                this.llIIlllIIIIlllIllIlIlllIl = 0.0f;
                this.IlllIIIlIlllIllIlIIlllIlI = 0.0f;
            }
        }
    }
}
