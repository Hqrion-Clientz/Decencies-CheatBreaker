// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIllIlIlllIIllllIIIIl extends lllllIlIIllIIlIIlIIIllIIl
{
    public lIIIIllllIlIIIIllIllIIlIl[] IIIllIllIlIlllllllIlIlIII;
    
    public IIllIIllIlIlllIIllllIIIIl() {
        (this.IIIllIllIlIlllllllIlIlIII = new lIIIIllllIlIIIIllIllIIlIl[5])[0] = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 8);
        this.IIIllIllIlIlllllllIlIlIII[1] = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 0);
        this.IIIllIllIlIlllllllIlIlIII[2] = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 0);
        this.IIIllIllIlIlllllllIlIlIII[3] = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 0);
        this.IIIllIllIlIlllllllIlIlIII[4] = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 0);
        final int n = 24;
        final int n2 = 6;
        final int n3 = 20;
        final int n4 = 4;
        this.IIIllIllIlIlllllllIlIlIII[0].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2), (float)(-n3 / 2 + 2), -3, n, n3 - 4, 4, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[0].lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n4, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[1].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2 + 2), (float)(-n2 - 1), -1, n - 4, n2, 2, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[1].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2 + 1), (float)n4, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[2].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2 + 2), (float)(-n2 - 1), -1, n - 4, n2, 2, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[2].lIIIIlIIllIIlIIlIIIlIIllI((float)(n / 2 - 1), (float)n4, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[3].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2 + 2), (float)(-n2 - 1), -1, n - 4, n2, 2, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[3].lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n4, (float)(-n3 / 2 + 1));
        this.IIIllIllIlIlllllllIlIlIII[4].lIIIIlIIllIIlIIlIIIlIIllI((float)(-n / 2 + 2), (float)(-n2 - 1), -1, n - 4, n2, 2, 0.0f);
        this.IIIllIllIlIlllllllIlIlIII[4].lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n4, (float)(n3 / 2 - 1));
        this.IIIllIllIlIlllllllIlIlIII[0].IlIlIIIlllIIIlIlllIlIllIl = 50.0f * 0.03141593f;
        this.IIIllIllIlIlllllllIlIlIII[1].IIIllIllIlIlllllllIlIlIII = 3.455752f * 1.3636364f;
        this.IIIllIllIlIlllllllIlIlIII[2].IIIllIllIlIlllllllIlIlIII = 1.3043479f * 1.2042772f;
        this.IIIllIllIlIlllllllIlIlIII[3].IIIllIllIlIlllllllIlIlIII = 0.046889443f * 67.0f;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        for (int i = 0; i < 5; ++i) {
            this.IIIllIllIlIlllllllIlIlIII[i].lIIIIlIIllIIlIIlIIIlIIllI(n6);
        }
    }
}
