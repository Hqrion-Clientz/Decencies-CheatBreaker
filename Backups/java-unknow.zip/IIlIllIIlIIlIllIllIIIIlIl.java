import java.util.UUID;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIlIIlIllIllIIIIlIl extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private final List lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIllIIlIIlIllIllIIIIlIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
    }
    
    public IIlIllIIlIIlIllIllIIIIlIl(final int liiiIlIIllIIlIIlIIIlIIllI, final Collection collection) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        for (final IlIlIlllIIllIIllIllllllII ilIlIlllIIllIIllIllllllII : collection) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(new llllllIlIIIlIIIlIllllllII(this, ilIlIlllIIllIIllIllllllII.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(), ilIlIlllIIllIIllIllllllII.lIIIIIIIIIlIllIIllIlIIlIl(), ilIlIlllIIllIIllIllllllII.IlllIIIlIlllIllIlIIlllIlI()));
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        for (int int1 = lIlIllllllllIlIIIllIIllII.readInt(), i = 0; i < int1; ++i) {
            final String illlIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(64);
            final double double1 = lIlIllllllllIlIIIllIIllII.readDouble();
            final ArrayList<IllIIlIIllIlllIIIIIllllII> list = new ArrayList<IllIIlIIllIlllIIIIIllllII>();
            for (short short1 = lIlIllllllllIlIIIllIIllII.readShort(), n = 0; n < short1; ++n) {
                list.add(new IllIIlIIllIlllIIIIIllllII(new UUID(lIlIllllllllIlIIIllIIllII.readLong(), lIlIllllllllIlIIIllIIllII.readLong()), "Unknown synced attribute modifier", lIlIllllllllIlIIIllIIllII.readDouble(), lIlIllllllllIlIIIllIIllII.readByte()));
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(new llllllIlIIIlIIIlIllllllII(this, illlIIIlIlllIllIlIIlllIlI, double1, list));
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl.size());
        for (final llllllIlIIIlIIIlIllllllII llllllIlIIIlIIIlIllllllII : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(llllllIlIIIlIIIlIllllllII.lIIIIlIIllIIlIIlIIIlIIllI());
            lIlIllllllllIlIIIllIIllII.writeDouble(llllllIlIIIlIIIlIllllllII.lIIIIIIIIIlIllIIllIlIIlIl());
            lIlIllllllllIlIIIllIIllII.writeShort(llllllIlIIIlIIIlIllllllII.IlllIIIlIlllIllIlIIlllIlI().size());
            for (final IllIIlIIllIlllIIIIIllllII illIIlIIllIlllIIIIIllllII : llllllIlIIIlIIIlIllllllII.IlllIIIlIlllIllIlIIlllIlI()) {
                lIlIllllllllIlIIIllIIllII.writeLong(illIIlIIllIlllIIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI().getMostSignificantBits());
                lIlIllllllllIlIIIllIIllII.writeLong(illIIlIIllIlllIIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI().getLeastSignificantBits());
                lIlIllllllllIlIIIllIIllII.writeDouble(illIIlIIllIlllIIIIIllllII.IIIIllIlIIIllIlllIlllllIl());
                lIlIllllllllIlIIIllIIllII.writeByte(illIIlIIllIlllIIIIIllllII.IlllIIIlIlllIllIlIIlllIlI());
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public List IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
