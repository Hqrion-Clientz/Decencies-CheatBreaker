// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIlIIIIIlIllIIIIlIl extends llIIIlIIIlllIllIIIIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIIIIlIIIIIlIllIIIIlIl() {
        super(new llIlIIllIIIllIIllIIlIIIIl(), 1.5f * 0.2f);
    }
    
    protected float lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIlIIIlllIIIllIIlllIl ilIIlIlIIIlllIIIllIIlllIl) {
        return 180;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIlIIIlllIIIllIIlllIl ilIIlIlIIIlllIIIllIIlllIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIlIIIlllIIIllIIlllIl, n, n2, n3, n4, n5);
    }
    
    protected ResourceLocation lIIIIIIIIIlIllIIllIlIIlIl(final IlIIlIlIIIlllIIIllIIlllIl ilIIlIlIIIlllIIIllIIlllIl) {
        return IIIlIIIIlIIIIIlIllIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    protected int lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIlIIIlllIIIllIIlllIl ilIIlIlIIIlllIIIllIIlllIl, final int n, final float n2) {
        return -1;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIlIIIlllIIIllIIlllIl)illlIIIllIlIIlIllIIlIlllI, n, n2, n3, n4, n5);
    }
    
    @Override
    protected float lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIlIIIlllIIIllIIlllIl)entityLivingBase);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIlIIIlllIIIllIIlllIl)entityLivingBase, n, n2);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIlIIIlllIIIllIIlllIl)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl((IlIIlIlIIIlllIIIllIIlllIl)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlIlIIIlllIIIllIIlllIl)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/silverfish.png");
    }
}
