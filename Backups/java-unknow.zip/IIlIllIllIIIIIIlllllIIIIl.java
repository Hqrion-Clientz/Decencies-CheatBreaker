// 
// Decompiled by Procyon v0.5.36
// 

class IIlIllIllIIIIIIlllllIIIIl implements lllIIllIllIllIIIlllllllII
{
    final /* synthetic */ Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIllIllIIIIIIlllllIIIIl(final Minecraft liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final String format) {
        try {
            return String.format(format, GameSettings.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.gameSettings.keyBindInventory.lIIIIllIIlIlIllIIIlIllIlI()));
        }
        catch (Exception ex) {
            return "Error: " + ex.getLocalizedMessage();
        }
    }
}
