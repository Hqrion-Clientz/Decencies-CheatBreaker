// 
// Decompiled by Procyon v0.5.36
// 

class IIIIllIIllllIIlIlIIIIlIlI extends IlIIIIIlIIIIlIIIIlIlllIlI
{
    final /* synthetic */ lIllIIllIlllIIlIlIlIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIllIIllllIIlIlIIIIlIlI(final lIllIIllIlllIIlIlIlIIlIlI liiiIlIIllIIlIIlIIIlIIllI, final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        super(ilIIlIIllIllllllllIllIII, n, n2, n3);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI != null && (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlllIIllllllllIlIlIlllllI || lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIIllIIlIlIllIIIlIllIlI || lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlIlllIIIIllIllllIllIIlIl || lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlllIllIlIIIIlIIlIIllIIIl);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return 1;
    }
}
