import java.util.ListIterator;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIIlllIlIIlIIIllIIlIII extends IllIlIllllllIIIIIllIllIlI
{
    final ListIterator lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIIlllIlIIlIIIllIIlIII(final ListIterator liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean hasNext() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.hasNext();
    }
    
    @Override
    public boolean hasPrevious() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.hasPrevious();
    }
    
    @Override
    public int nextIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.nextIndex();
    }
    
    @Override
    public int previousIndex() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.previousIndex();
    }
    
    @Override
    public void set(final Object o) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.set(o);
    }
    
    @Override
    public void add(final Object o) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(o);
    }
    
    @Override
    public void remove() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.remove();
    }
    
    @Override
    public Object next() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.next();
    }
    
    @Override
    public Object previous() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.previous();
    }
}
