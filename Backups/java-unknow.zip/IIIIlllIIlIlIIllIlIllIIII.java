// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIIlIlIIllIlIllIIII
{
    public Class lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public int IIIIllIlIIIllIlllIlllllIl;
    
    public IIIIlllIIlIlIIllIlIllIIII(final Class liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return this.IIIIllIlIIIllIlllIlllllIl == 0 || this.IlllIIIlIlllIllIlIIlllIlI < this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIlIIIllIlllIlllllIl == 0 || this.IlllIIIlIlllIllIlIIlllIlI < this.IIIIllIlIIIllIlllIlllllIl;
    }
}
