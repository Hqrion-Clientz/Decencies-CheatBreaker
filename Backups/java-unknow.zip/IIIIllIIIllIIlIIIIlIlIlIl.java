import org.apache.logging.log4j.LogManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Set;
import java.util.Map;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIIllIIlIIIIlIlIlIl implements IIlllIlIIIIllIIlIIIIlIIII
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private final Map lIIIIIIIIIlIllIIllIlIIlIl;
    private final Set IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIllIIIllIIlIIIIlIlIlIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new HashMap();
        this.IlllIIIlIlllIllIlIIlllIlI = new HashSet();
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, String str) {
        str = str.trim();
        if (str.startsWith("/")) {
            str = str.substring(1);
        }
        final String[] split = str.split(" ");
        final String s = split[0];
        final String[] liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(split);
        final lIlIIIllIllIIlllllIlllIIl lIlIIIllIllIIlllllIlllIIl = this.lIIIIIIIIIlIllIIllIlIIlIl.get(s);
        final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(lIlIIIllIllIIlllllIlllIIl, liiiIlIIllIIlIIlIIIlIIllI);
        int n = 0;
        try {
            if (lIlIIIllIllIIlllllIlllIIl == null) {
                throw new lIllIllIIIlllIIIIllIlIlII();
            }
            if (lIlIIIllIllIIlllllIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII)) {
                if (liiiIlIIllIIlIIlIIIlIIllI2 > -1) {
                    final llIIIIIIlIlllllIIllllIlII[] illlIIIlIlllIllIlIIlllIlI = lIIIIllllIllIlIIIIIIIlllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2]);
                    final String s2 = liiiIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2];
                    final llIIIIIIlIlllllIIllllIlII[] array = illlIIIlIlllIllIlIIlllIlI;
                    for (int length = illlIIIlIlllIllIlIIlllIlI.length, i = 0; i < length; ++i) {
                        liiiIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2] = array[i].IlIlIIIlllllIIIlIlIlIllII();
                        try {
                            lIlIIIllIllIIlllllIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI);
                            ++n;
                        }
                        catch (lIllllIllIIIllIlIlIlIIIII lIllllIllIIIllIlIlIlIIIII) {
                            final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl = new IIIlIlIIIlllllIIlllIIIlIl(lIllllIllIIIllIlIlIlIIIII.getMessage(), lIllllIllIIIllIlIlIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI());
                            iiIlIlIIIlllllIIlllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
                            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl);
                        }
                    }
                    liiiIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI2] = s2;
                }
                else {
                    try {
                        lIlIIIllIllIIlllllIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI);
                        ++n;
                    }
                    catch (lIllllIllIIIllIlIlIlIIIII lIllllIllIIIllIlIlIlIIIII2) {
                        final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl2 = new IIIlIlIIIlllllIIlllIIIlIl(lIllllIllIIIllIlIlIlIIIII2.getMessage(), lIllllIllIIIllIlIlIlIIIII2.lIIIIlIIllIIlIIlIIIlIIllI());
                        iiIlIlIIIlllllIIlllIIIlIl2.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
                        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl2);
                    }
                }
            }
            else {
                final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl3 = new IIIlIlIIIlllllIIlllIIIlIl("commands.generic.permission", new Object[0]);
                iiIlIlIIIlllllIIlllIIIlIl3.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
                lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl3);
            }
        }
        catch (IIllllIlIlIIlllIlIIllIIll illllIlIlIIlllIlIIllIIll) {
            final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl4 = new IIIlIlIIIlllllIIlllIIIlIl("commands.generic.usage", new Object[] { new IIIlIlIIIlllllIIlllIIIlIl(illllIlIlIIlllIlIIllIIll.getMessage(), illllIlIlIIlllIlIIllIIll.lIIIIlIIllIIlIIlIIIlIIllI()) });
            iiIlIlIIIlllllIIlllIIIlIl4.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl4);
        }
        catch (lIllllIllIIIllIlIlIlIIIII lIllllIllIIIllIlIlIlIIIII3) {
            final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl5 = new IIIlIlIIIlllllIIlllIIIlIl(lIllllIllIIIllIlIlIlIIIII3.getMessage(), lIllllIllIIIllIlIlIlIIIII3.lIIIIlIIllIIlIIlIIIlIIllI());
            iiIlIlIIIlllllIIlllIIIlIl5.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl5);
        }
        catch (Throwable t) {
            final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl6 = new IIIlIlIIIlllllIIlllIIIlIl("commands.generic.exception", new Object[0]);
            iiIlIlIIIlllllIIlllIIIlIl6.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII);
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIlIIIlllllIIlllIIIlIl6);
            IIIIllIIIllIIlIIIIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI.error("Couldn't process command: '" + str + "'", t);
        }
        return n;
    }
    
    public lIlIIIllIllIIlllllIlllIIl lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIllIllIIlllllIlllIIl lIlIIIllIllIIlllllIlllIIl) {
        final List illlIIIlIlllIllIlIIlllIlI = lIlIIIllIllIIlllllIlllIIl.IlllIIIlIlllIllIlIIlllIlI();
        this.lIIIIIIIIIlIllIIllIlIIlIl.put(lIlIIIllIllIIlllllIlllIIl.getIdentifier(), lIlIIIllIllIIlllllIlllIIl);
        this.IlllIIIlIlllIllIlIIlllIlI.add(lIlIIIllIllIIlllllIlllIIl);
        if (illlIIIlIlllIllIlIIlllIlI != null) {
            for (final String anObject : illlIIIlIlllIllIlIIlllIlI) {
                final lIlIIIllIllIIlllllIlllIIl lIlIIIllIllIIlllllIlllIIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl.get(anObject);
                if (lIlIIIllIllIIlllllIlllIIl2 == null || !lIlIIIllIllIIlllllIlllIIl2.getIdentifier().equals(anObject)) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl.put(anObject, lIlIIIllIllIIlllllIlllIIl);
                }
            }
        }
        return lIlIIIllIllIIlllllIlllIIl;
    }
    
    private static String[] lIIIIlIIllIIlIIlIIIlIIllI(final String[] array) {
        final String[] array2 = new String[array.length - 1];
        for (int i = 1; i < array.length; ++i) {
            array2[i - 1] = array[i];
        }
        return array2;
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String s) {
        final String[] split = s.split(" ", -1);
        final String s2 = split[0];
        if (split.length == 1) {
            final ArrayList<String> list = new ArrayList<String>();
            for (final Map.Entry<String, V> entry : this.lIIIIIIIIIlIllIIllIlIIlIl.entrySet()) {
                if (IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s2, entry.getKey()) && ((lIlIIIllIllIIlllllIlllIIl)entry.getValue()).lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII)) {
                    list.add(entry.getKey());
                }
            }
            return list;
        }
        if (split.length > 1) {
            final lIlIIIllIllIIlllllIlllIIl lIlIIIllIllIIlllllIlllIIl = this.lIIIIIIIIIlIllIIllIlIIlIl.get(s2);
            if (lIlIIIllIllIIlllllIlllIIl != null) {
                return lIlIIIllIllIIlllllIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII, lIIIIlIIllIIlIIlIIIlIIllI(split));
            }
        }
        return null;
    }
    
    @Override
    public List lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        final ArrayList<lIlIIIllIllIIlllllIlllIIl> list = new ArrayList<lIlIIIllIllIIlllllIlllIIl>();
        for (final lIlIIIllIllIIlllllIlllIIl e : this.IlllIIIlIlllIllIlIIlllIlI) {
            if (e.lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII)) {
                list.add(e);
            }
        }
        return list;
    }
    
    @Override
    public Map lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    private int lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIllIllIIlllllIlllIIl lIlIIIllIllIIlllllIlllIIl, final String[] array) {
        if (lIlIIIllIllIIlllllIlllIIl == null) {
            return -1;
        }
        for (int i = 0; i < array.length; ++i) {
            if (lIlIIIllIllIIlllllIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(array, i) && lIIIIllllIllIlIIIIIIIlllI.lIIIIlIIllIIlIIlIIIlIIllI(array[i])) {
                return i;
            }
        }
        return -1;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
