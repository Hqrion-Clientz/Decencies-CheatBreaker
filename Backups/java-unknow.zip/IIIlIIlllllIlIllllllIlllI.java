import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

final class IIIlIIlllllIlIllllllIlllI implements Comparator
{
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIIllIIIlIlllllIlIIlI lIlIlIIllIIIlIlllllIlIIlI, final lIlIlIIllIIIlIlllllIlIIlI lIlIlIIllIIIlIlllllIlIIlI2) {
        return (lIlIlIIllIIIlIlllllIlIIlI.lIIIIIIIIIlIllIIllIlIIlIl() > lIlIlIIllIIIlIlllllIlIIlI2.lIIIIIIIIIlIllIIllIlIIlIl()) ? 1 : ((lIlIlIIllIIIlIlllllIlIIlI.lIIIIIIIIIlIllIIllIlIIlIl() < lIlIlIIllIIIlIlllllIlIIlI2.lIIIIIIIIIlIllIIllIlIIlIl()) ? -1 : 0);
    }
    
    @Override
    public int compare(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((lIlIlIIllIIIlIlllllIlIIlI)o, (lIlIlIIllIIIlIlllllIlIIlI)o2);
    }
}
