// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIllIIIIllIllIIIlIl
{
    private final String lIIIIlIIllIIlIIlIIIlIIllI;
    private final String lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIllIIllIIIIllIllIIIlIl(final String liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
