// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIIIlIIIlIlIIlIIllllllII
{
    lIIIIlIIllIIlIIlIIIlIIllI("everything", 0, "everything", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("mobs", 1, "mobs", 1), 
    IlllIIIlIlllIllIlIIlllIlI("players", 2, "players", 2);
    
    private static final IIIIIlIIIlIlIIlIIllllllII[] IIIIllIlIIIllIlllIlllllIl;
    
    private IIIIIlIIIlIlIIlIIllllllII(final String name, final int ordinal, final String s, final int n) {
    }
    
    static {
        IIIIllIlIIIllIlllIlllllIl = new IIIIIlIIIlIlIIlIIllllllII[] { IIIIIlIIIlIlIIlIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI, IIIIIlIIIlIlIIlIIllllllII.lIIIIIIIIIlIllIIllIlIIlIl, IIIIIlIIIlIlIIlIIllllllII.IlllIIIlIlllIllIlIIlllIlI };
    }
}
