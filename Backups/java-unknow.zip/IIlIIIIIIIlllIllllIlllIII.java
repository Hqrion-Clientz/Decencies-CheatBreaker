// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIIlllIllllIlllIII extends IIIllIlllIlIIIlIlIIlllIIl
{
    private final IlllIIIllIlIIlIllIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI;
    private final float lIIIIIIIIIlIllIIllIlIIlIl;
    private float IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIIIIIIIlllIllllIlllIII(final IlllIIIllIlIIlIllIIlIlllI liiiIlIIllIIlIIlIIIlIIllI, final float liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI(7);
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
        this.IlllIIIlIlllIllIlIIlllIlI = 0.0f;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIIllIlIIIllIlllIlllllIl = false;
        this.IlllIIIlIlllIllIlIIlllIlI = 0.0f;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIlIllIlllIlIIIll() && this.lIIIIlIIllIIlIIlIIIlIIllI.IllIllIIIlIIlllIIIllIllII != null && this.lIIIIlIIllIIlIIlIIIlIIllI.IllIllIIIlIIlllIIIllIllII instanceof lIllIIIIlIIlIllIIIlIlIlll && (this.IIIIllIlIIIllIlllIlllllIl || this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIllIlIIllIIllIlIlll());
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
        final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = (lIllIIIIlIIlIllIIIlIlIlll)this.lIIIIlIIllIIlIIlIIIlIIllI.IllIllIIIlIIlllIIIllIllII;
        final IIlllIIllIllIlIllIIIIIIlI illlIIllIllIlIllIIIIIIlI = (IIlllIIllIllIlIllIIIIIIlI)this.lIIIIlIIllIIlIIlIIIlIIllI;
        float n = MathHelper.IIIllIllIlIlllllllIlIlIII(lIllIIIIlIIlIllIIIlIlIlll.IllllIllllIlIIIlIIIllllll - this.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll) * (0.8958333f * 0.55813956f);
        if (n > 5) {
            n = 5;
        }
        if (n < -5) {
            n = -5;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll = MathHelper.IIIllIllIlIlllllllIlIlIII(this.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll + n);
        if (this.IlllIIIlIlllIllIlIIlllIlI < this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IlllIIIlIlllIllIlIIlllIlI += (this.lIIIIIIIIIlIllIIllIlIIlIl - this.IlllIIIlIlllIllIlIIlllIlI) * (0.024857143f * 0.40229884f);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI > this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll);
        float illlIIIlIlllIllIlIIlllIlI4 = this.IlllIIIlIlllIllIlIIlllIlI;
        if (this.IIIIllIlIIIllIlllIlllllIl) {
            if (this.IIIIllIIllIIIIllIllIIIlIl++ > this.IlIlIIIlllIIIlIlllIlIllIl) {
                this.IIIIllIlIIIllIlllIlllllIl = false;
            }
            illlIIIlIlllIllIlIIlllIlI4 += illlIIIlIlllIllIlIIlllIlI4 * (31.0f * 0.037096772f) * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl / (float)this.IlIlIIIlllIIIlIlllIlIllIl * (2.6721594f * 1.1756756f));
        }
        float n2 = 1.3443182f * 0.6769231f;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlllIIlIlllllIlIllIII) {
            n2 = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IIIIllIlIIIllIlllIlllllIl((float)illlIIIlIlllIllIlIIlllIlI), MathHelper.IIIIllIlIIIllIlllIlllllIl((float)illlIIIlIlllIllIlIIlllIlI2) - 1, MathHelper.IIIIllIlIIIllIlllIlllllIl((float)illlIIIlIlllIllIlIIlllIlI3)).IlIlIIIlllllIIIlIlIlIllII * (0.398125f * 2.2857144f);
        }
        final float n3 = 0.45378682f * 0.35869566f / (n2 * n2 * n2);
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(illlIIllIllIlIllIIIIIIlI.IllllIllllIlIIIlIIIllllll * (57.33407f * 0.05479452f) / 180);
        final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(illlIIllIllIlIllIIIIIIlI.IllllIllllIlIIIlIIIllllll * (11.519173f * 0.27272728f) / 180);
        final float n4 = illlIIIlIlllIllIlIIlllIlI4 * (illlIIllIllIlIllIIIIIIlI.IIIIIlIIIlllIIlIIllllIlll() * n3 / Math.max(illlIIIlIlllIllIlIIlllIlI4, 1.0f));
        float n5 = -(n4 * liiiIlIIllIIlIIlIIIlIIllI);
        float n6 = n4 * liiiiiiiiIlIllIIllIlIIlIl;
        if (MathHelper.IIIIllIIllIIIIllIllIIIlIl(n5) > MathHelper.IIIIllIIllIIIIllIllIIIlIl(n6)) {
            if (n5 < 0.0f) {
                n5 -= this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl / 2.0f;
            }
            if (n5 > 0.0f) {
                n5 += this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl / 2.0f;
            }
            n6 = 0.0f;
        }
        else {
            n5 = 0.0f;
            if (n6 < 0.0f) {
                n6 -= this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl / 2.0f;
            }
            if (n6 > 0.0f) {
                n6 += this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl / 2.0f;
            }
        }
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll + n5);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll + n6);
        final IllllIIllIIlIllIIllIlllII illllIIllIIlIllIIllIlllII = new IllllIIllIIlIllIIllIlllII(MathHelper.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl + 1.0f), MathHelper.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.llllIIIIlIlIllIIIllllIIll + lIllIIIIlIIlIllIIIlIlIlll.llllIIIIlIlIllIIIllllIIll + 1.0f), MathHelper.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIlIllIIIIllIIllIlIl + 1.0f));
        if (illlIIIlIlllIllIlIIlllIlI != illlIIIlIlllIllIlIIlllIlI5 || illlIIIlIlllIllIlIIlllIlI3 != illlIIIlIlllIllIlIIlllIlI6) {
            final IIlllllllIlllIIllllIIlIll block = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI(block) && (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air || !this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3))) && lIIIlIllIlIIIlIlIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI6, illllIIllIIlIllIIllIlllII, false, false, true) == 0 && lIIIlIllIlIIIlIlIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 + 1, illlIIIlIlllIllIlIIlllIlI3, illllIIllIIlIllIIllIlllII, false, false, true) == 1 && lIIIlIllIlIIIlIlIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI2 + 1, illlIIIlIlllIllIlIIlllIlI6, illllIIllIIlIllIIllIlllII, false, false, true) == 1) {
                illlIIllIllIlIllIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll().lIIIIlIIllIIlIIlIIIlIIllI();
            }
        }
        if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl && this.IlllIIIlIlllIllIlIIlllIlI >= this.lIIIIIIIIIlIllIIllIlIIlIl * (0.28787878f * 1.7368422f) && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIllIllIIIIIlllIIlll().nextFloat() < 0.90217394f * 0.0066506024f && !this.IIIIllIlIIIllIlllIlllllIl) {
            final lIlIlIlIlIllllIlllIIIlIlI illIIIllIlIIlIllIIIllllIl = lIllIIIIlIIlIllIIIlIlIlll.IllIIIllIlIIlIllIIIllllIl();
            if (illIIIllIlIIlIllIIIllllIl != null && illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IIIlIIIIllIIIlIIIIIlllllI) {
                illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(1, lIllIIIIlIIlIllIIIlIlIlll);
                if (illIIIllIlIIlIllIIIllllIl.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                    final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lllIIlIIllIllIIllIIlIIIIl);
                    lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl(illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl);
                    lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI[lIllIIIIlIIlIllIIIlIlIlll.inventory.currentItem] = lIlIlIlIlIllllIlllIIIlIlI;
                }
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.setProgress(0.0f, illlIIIlIlllIllIlIIlllIlI4);
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll.IlIlllIIIIllIllllIllIIlIl() == 10 || illlllllIlllIIllllIIlIll instanceof lIlIIllIIIIIIIIllIIIIlIII;
    }
    
    public boolean IllIIIIIIIlIlIllllIIllIII() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI() {
        this.IIIIllIlIIIllIlllIlllllIl = true;
        this.IIIIllIIllIIIIllIllIIIlIl = 0;
        this.IlIlIIIlllIIIlIlllIlIllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIllIllIIIIIlllIIlll().nextInt(841) + 140;
    }
    
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return !this.IllIIIIIIIlIlIllllIIllIII() && this.IlllIIIlIlllIllIlIIlllIlI > this.lIIIIIIIIIlIllIIllIlIIlIl * (1.5f * 0.2f);
    }
}
