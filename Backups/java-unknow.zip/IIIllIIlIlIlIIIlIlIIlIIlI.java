import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIlIlIlIIIlIlIIlIIlI extends IIlllllllIlllIIllllIIlIll
{
    protected IIIllIIlIlIlIIIlIlIIlIIlI() {
        super(Material.lIIIIIllllIIIIlIlIIIIlIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 0.08210784f * 0.76119405f, 1.0f);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
        this.IllIIIIIIIlIlIllllIIllIII(0);
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return IllllllIllIIlllIllIIlIIll.lIIIIlllIIlIlllllIlIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + this.lIllIlIlllIIlIIllIIlIIlII, n2 + this.IIIlIIlIlIIIlllIIlIllllll, n3 + this.IllIlIIIIlllIIllIIlllIIlI, n + this.IllIlIlIllllIlIIllllIIlll, n2 + 0 * (0.8181818f * 0.07638889f), n3 + this.lIlIlIllIIIIIIIIllllIIllI);
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
        this.IllIIIIIIIlIlIllllIIllIII(0);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.IllIIIIIIIlIlIllllIIllIII(liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3));
    }
    
    protected void IllIIIIIIIlIlIllllIIllIII(final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 1 * (1 + 0) / (float)16, 1.0f);
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return super.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3) && this.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    private boolean IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!this.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 0);
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            return false;
        }
        return true;
    }
    
    @Override
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return !iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2 - 1, n3);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return n4 == 1 || super.lIIIIlIIllIIlIIlIIIlIIllI(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4);
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return n;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final IIllllIllIIllIIllIlIIIIII illllIllIIllIIllIlIIIIII, final List list) {
        for (int i = 0; i < 16; ++i) {
            list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, i));
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
    }
}
