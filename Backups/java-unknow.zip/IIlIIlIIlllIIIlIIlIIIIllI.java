import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIlllIIIlIIlIIIIllI extends IIllIlIIlllIlIIlIllllllll
{
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 10; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n4, n5, n6) && IllllllIllIIlllIllIIlIIll.IlllIIllIlllllIIIlIllIIII.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n4, n5, n6)) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n6, IllllllIllIIlllIllIIlIIll.IlllIIllIlllllIIIlIllIIII, 0, 2);
            }
        }
        return true;
    }
}
