// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIIIllIllIIlllIllII extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "testfor";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.testfor.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length != 1) {
            throw new IIllllIlIlIIlllIlIIllIIll("commands.testfor.usage", new Object[0]);
        }
        if (!(lIlllllIIIIIIllIlIIlIlIII instanceof IllllIlIllIIllllllIIlIIll)) {
            throw new lIllllIllIIIllIlIlIlIIIII("commands.testfor.failed", new Object[0]);
        }
        IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[0]);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 0;
    }
}
