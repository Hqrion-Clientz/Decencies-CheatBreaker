import com.mojang.authlib.GameProfile;
import java.util.UUID;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIIllIlIlIIllIIlllll extends llIIIlIIIlllIllIIIIlIlIlI
{
    protected llIIIllllIlIIllIlIIlIIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    protected float IlIlIIIlllIIIlIlllIlIllIl;
    protected llIIIllllIlIIllIlIIlIIIlI IIIllIllIlIlllllllIlIlIII;
    protected llIIIllllIlIIllIlIIlIIIlI IllIIIIIIIlIlIllllIIllIII;
    private static final ResourceLocation[] lIIIIllIIlIlIllIIIlIllIlI;
    private static final String[] IlllIllIlIIIIlIIlIIllIIIl;
    
    public IIIlIlIIllIlIlIIllIIlllll(final llIIIllllIlIIllIlIIlIIIlI llIIIllllIlIIllIlIIlIIIlI, final float n) {
        this(llIIIllllIlIIllIlIIlIIIlI, n, 1.0f);
    }
    
    public IIIlIlIIllIlIlIIllIIlllll(final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI, final float n, final float ilIlIIIlllIIIlIlllIlIllIl) {
        super(liiiIlIIllIIlIIlIIIlIIllI, n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIllIllIlIlllllllIlIlIII = new llIIIllllIlIIllIlIIlIIIlI(1.0f);
        this.IllIIIIIIIlIlIllllIIllIII = new llIIIllllIlIIllIlIIlIIIlI(0.13000001f * 3.8461537f);
    }
    
    public static ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIlIlllIlllIlIIIIlll llIlIlIlIlllIlllIlIIIIlll, final int n) {
        return IIIlIlIIllIlIlIIllIIlllll.lIIIIllIIlIlIllIIIlIllIlI[(llIlIlIlIlllIlllIlIIIIlll.llIIlllIIIIlllIllIlIlllIl << 1) + ((n == 2) ? 1 : 0)];
    }
    
    public static ResourceLocation lIIIIIIIIIlIllIIllIlIIlIl(final llIlIlIlIlllIlllIlIIIIlll llIlIlIlIlllIlllIlIIIIlll, final int n) {
        return IIIlIlIIllIlIlIIllIIlllll.lIIIIllIIlIlIllIIIlIllIlI[(llIlIlIlIlllIlllIlIIIIlll.llIIlllIIIIlllIllIlIlllIl << 1) + ((n == 2) ? 11 : 10)];
    }
    
    protected int lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final int n, final float n2) {
        final lIlIlIlIlIllllIlllIIIlIlI ilIlllIIIIllIllllIllIIlIl = illlIIIllIlIIlIllIIlIlllI.IlIlllIIIIllIllllIllIIlIl(3 - n);
        if (ilIlllIIIIllIllllIllIIlIl != null) {
            final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI = ilIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI instanceof llIlIlIlIlllIlllIlIIIIlll) {
                final llIlIlIlIlllIlllIlIIIIlll llIlIlIlIlllIlllIlIIIIlll = (llIlIlIlIlllIlllIlIIIIlll)liiiIlIIllIIlIIlIIIlIIllI;
                this.lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIlIlllIlllIlIIIIlll, n));
                final llIIIllllIlIIllIlIIlIIIlI llIIIllllIlIIllIlIIlIIIlI = (n == 2) ? this.IllIIIIIIIlIlIllllIIllIII : this.IIIllIllIlIlllllllIlIlIII;
                llIIIllllIlIIllIlIIlIIIlI.IIIllIllIlIlllllllIlIlIII.IlllIllIlIIIIlIIlIIllIIIl = (n == 0);
                llIIIllllIlIIllIlIIlIIIlI.IllIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl = (n == 0);
                llIIIllllIlIIllIlIIlIIIlI.lIIIIllIIlIlIllIIIlIllIlI.IlllIllIlIIIIlIIlIIllIIIl = (n == 1 || n == 2);
                llIIIllllIlIIllIlIIlIIIlI.IlllIllIlIIIIlIIlIIllIIIl.IlllIllIlIIIIlIIlIIllIIIl = (n == 1);
                llIIIllllIlIIllIlIIlIIIlI.IlIlllIIIIllIllllIllIIlIl.IlllIllIlIIIIlIIlIIllIIIl = (n == 1);
                llIIIllllIlIIllIlIIlIIIlI.llIIlllIIIIlllIllIlIlllIl.IlllIllIlIIIIlIIlIIllIIIl = (n == 2 || n == 3);
                llIIIllllIlIIllIlIIlIIIlI.lIIlIlIllIIlIIIlIIIlllIII.IlllIllIlIIIIlIIlIIllIIIl = (n == 2 || n == 3);
                this.lIIIIlIIllIIlIIlIIIlIIllI(llIIIllllIlIIllIlIIlIIIlI);
                llIIIllllIlIIllIlIIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI;
                llIIIllllIlIIllIlIIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl = this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl;
                llIIIllllIlIIllIlIIlIIIlI.IIIIllIlIIIllIlllIlllllIl = this.lIIlIlIllIIlIIIlIIIlllIII.IIIIllIlIIIllIlllIlllllIl;
                if (llIlIlIlIlllIlllIlIIIIlll.IlIIlIIIIlIIIIllllIIlIllI() == IIlllIIlIIIlllIIIIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI) {
                    final int iiIlllIIIllIllIlIIIIIIlII = llIlIlIlIlllIlllIlIIIIlll.IIIlllIIIllIllIlIIIIIIlII(ilIlllIIIIllIllllIllIIlIl);
                    GL11.glColor3f((iiIlllIIIllIllIlIIIIIIlII >> 16 & 0xFF) / (float)255, (iiIlllIIIllIllIlIIIIIIlII >> 8 & 0xFF) / (float)255, (iiIlllIIIllIllIlIIIIIIlII & 0xFF) / (float)255);
                    if (ilIlllIIIIllIllllIllIIlIl.llIlIIIllIIIIlllIlIIIIIlI()) {
                        return 31;
                    }
                    return 16;
                }
                else {
                    GL11.glColor3f(1.0f, 1.0f, 1.0f);
                    if (ilIlllIIIIllIllllIllIIlIl.llIlIIIllIIIIlllIlIIIIIlI()) {
                        return 15;
                    }
                    return 1;
                }
            }
        }
        return -1;
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final int n, final float n2) {
        final lIlIlIlIlIllllIlllIIIlIlI ilIlllIIIIllIllllIllIIlIl = illlIIIllIlIIlIllIIlIlllI.IlIlllIIIIllIllllIllIIlIl(3 - n);
        if (ilIlllIIIIllIllllIllIIlIl != null) {
            final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI = ilIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI instanceof llIlIlIlIlllIlllIlIIIIlll) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(lIIIIIIIIIlIllIIllIlIIlIl((llIlIlIlIlllIlllIlIIIIlll)liiiIlIIllIIlIIlIIIlIIllI, n));
                GL11.glColor3f(1.0f, 1.0f, 1.0f);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIllIlIIlIllIIlIlllI, illlIIIllIlIIlIllIIlIlllI.IllIIIllIlIIlIllIIIllllIl());
        double n6 = n2 - illlIIIllIlIIlIllIIlIlllI.lIlIllIlIlIIIllllIlIllIll;
        if (illlIIIllIlIIlIllIIlIlllI.lIlIlIllIIIIIIIIllllIIllI()) {
            n6 -= 0.030172414289218217 * 4.142857074737549;
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIllIlIIlIllIIlIlllI, n, n6, n3, n4, n5);
        final llIIIllllIlIIllIlIIlIIIlI iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII;
        final llIIIllllIlIIllIlIIlIIIlI illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII;
        final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final boolean iiiiiIlIlIlIllllllIlllIlI = false;
        liiiIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        illIIIIIIIlIlIllllIIllIII.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        iiIllIllIlIlllllllIlIlIII.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        final llIIIllllIlIIllIlIIlIIIlI iiIllIllIlIlllllllIlIlIII2 = this.IIIllIllIlIlllllllIlIlIII;
        final llIIIllllIlIIllIlIIlIIIlI illIIIIIIIlIlIllllIIllIII2 = this.IllIIIIIIIlIlIllllIIllIII;
        final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final boolean liiiiIllllIIIIlIlIIIIlIlI = false;
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        illIIIIIIIlIlIllllIIllIII2.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        iiIllIllIlIlllllllIlIlIII2.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        final llIIIllllIlIIllIlIIlIIIlI iiIllIllIlIlllllllIlIlIII3 = this.IIIllIllIlIlllllllIlIlIII;
        final llIIIllllIlIIllIlIIlIIIlI illIIIIIIIlIlIllllIIllIII3 = this.IllIIIIIIIlIlIllllIIllIII;
        final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final int lllIIIIIlIllIlIIIllllllII = 0;
        liiiIlIIllIIlIIlIIIlIIllI3.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        illIIIIIIIlIlIllllIIllIII3.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        iiIllIllIlIlllllllIlIlIII3.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI) {
        return null;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final llIIIllllIlIIllIlIIlIIIlI iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII;
        final llIIIllllIlIIllIlIIlIIIlI illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII;
        final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final int lllIIIIIlIllIlIIIllllllII;
        final int n = lllIIIIIlIllIlIIIllllllII = ((lIlIlIlIlIllllIlllIIIlIlI != null) ? 1 : 0);
        liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII = n;
        illIIIIIIIlIlIllllIIllIII.lllIIIIIlIllIlIIIllllllII = n;
        iiIllIllIlIlllllllIlIlIII.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        final llIIIllllIlIIllIlIIlIIIlI iiIllIllIlIlllllllIlIlIII2 = this.IIIllIllIlIlllllllIlIlIII;
        final llIIIllllIlIIllIlIIlIIIlI illIIIIIIIlIlIllllIIllIII2 = this.IllIIIIIIIlIlIllllIIllIII;
        final llIIIllllIlIIllIlIIlIIIlI liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final boolean lIlIlIllIIIIIIIIllllIIllI = illlIIIllIlIIlIllIIlIlllI.lIlIlIllIIIIIIIIllllIIllI();
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIllllIIIIlIlIIIIlIlI = lIlIlIllIIIIIIIIllllIIllI;
        illIIIIIIIlIlIllllIIllIII2.lIIIIIllllIIIIlIlIIIIlIlI = lIlIlIllIIIIIIIIllllIIllI;
        iiIllIllIlIlllllllIlIlIII2.lIIIIIllllIIIIlIlIIIIlIlI = lIlIlIllIIIIIIIIllllIIllI;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final float n) {
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        super.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIllIlIIlIllIIlIlllI, n);
        final lIlIlIlIlIllllIlllIIIlIlI illIIIllIlIIlIllIIIllllIl = illlIIIllIlIIlIllIIlIlllI.IllIIIllIlIIlIllIIIllllIl();
        final lIlIlIlIlIllllIlllIIIlIlI ilIlllIIIIllIllllIllIIlIl = illlIIIllIlIIlIllIIlIlllI.IlIlllIIIIllIllllIllIIlIl(3);
        if (ilIlllIIIIllIllllIllIIlIl != null) {
            GL11.glPushMatrix();
            this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII.IlllIIIlIlllIllIlIIlllIlI(0.039930556f * 1.5652174f);
            final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI = ilIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI instanceof llIllIlIlIIIIlIIIIllIllll) {
                if (RenderBlocks.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI).IlIlllIIIIllIllllIllIIlIl())) {
                    final float n2 = 1.1298077f * 0.5531915f;
                    GL11.glTranslatef(0.0f, 0.2631579f * -0.95f, 0.0f);
                    GL11.glRotatef((float)90, 0.0f, 1.0f, 0.0f);
                    GL11.glScalef(n2, -n2, -n2);
                }
                this.lIIIIIIIIIlIllIIllIlIIlIl.itemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIllIlIIlIllIIlIlllI, ilIlllIIIIllIllllIllIIlIl, 0);
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI == IIlIlIllIlIIllIllIllIIIll.llllIlIIIIIllIIlIlllIllll) {
                final float n3 = 0.63380283f * 1.6763889f;
                GL11.glScalef(n3, -n3, -n3);
                GameProfile liiiIlIIllIIlIIlIIIlIIllI2 = null;
                if (ilIlllIIIIllIllllIllIIlIl.IIIlIIllllIIllllllIlIIIll()) {
                    final IlIIIllIIlIIlllIllllIIIIl lllIIIIIlIllIlIIIllllllII = ilIlllIIIIllIllllIllIIlIl.lllIIIIIlIllIlIIIllllllII();
                    if (lllIIIIIlIllIlIIIllllllII.lIIIIIIIIIlIllIIllIlIIlIl("SkullOwner", 10)) {
                        liiiIlIIllIIlIIlIIIlIIllI2 = lIIlIIIlIIlllIlIllIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllIlIIIllllllII.lIIlIlIllIIlIIIlIIIlllIII("SkullOwner"));
                    }
                    else if (lllIIIIIlIllIlIIIllllllII.lIIIIIIIIIlIllIIllIlIIlIl("SkullOwner", 8) && !IlIIllllIIlIIIIIIllIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(lllIIIIIlIllIlIIIllllllII.IlllIllIlIIIIlIIlIIllIIIl("SkullOwner"))) {
                        liiiIlIIllIIlIIlIIIlIIllI2 = new GameProfile((UUID)null, lllIIIIIlIllIlIIIllllllII.IlllIllIlIIIIlIIlIIllIIIl("SkullOwner"));
                    }
                }
                lllIllIllIllIlllIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(0.61333334f * -0.8152174f, 0.0f, 3.5652175f * -0.1402439f, 1, 180, ilIlllIIIIllIllllIllIIlIl.IlllIllIlIIIIlIIlIIllIIIl(), liiiIlIIllIIlIIlIIIlIIllI2);
            }
            GL11.glPopMatrix();
        }
        if (illIIIllIlIIlIllIIIllllIl != null && illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI() != null) {
            final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI3 = illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glPushMatrix();
            if (this.lIIlIlIllIIlIIIlIIIlllIII.IIIIllIlIIIllIlllIlllllIl) {
                final float n4 = 2.3095238f * 0.21649484f;
                GL11.glTranslatef(0.0f, 1.3448275f * 0.4647436f, 0.0f);
                GL11.glRotatef((float)(-20), (float)(-1), 0.0f, 0.0f);
                GL11.glScalef(n4, n4, n4);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI(0.18f * 0.3472222f);
            GL11.glTranslatef(-0.08064517f * 0.775f, 3.0624998f * 0.14285715f, 0.5813953f * 0.1075f);
            if (liiiIlIIllIIlIIlIIIlIIllI3 instanceof llIllIlIlIIIIlIIIIllIllll && RenderBlocks.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3).IlIlllIIIIllIllllIllIIlIl())) {
                final float n5 = 1.9f * 0.2631579f;
                GL11.glTranslatef(0.0f, 0.1875f * 1.0f, -0.07183908f * 4.35f);
                final float n6 = n5 * (0.21052632f * 3.5625f);
                GL11.glRotatef((float)20, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)45, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(-n6, -n6, n6);
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI3 == IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIIIlIlllIlIllIl) {
                final float n7 = 2.8365383f * 0.22033899f;
                GL11.glTranslatef(0.0f, 1.42f * 0.08802817f, 0.92771083f * 0.33685064f);
                GL11.glRotatef((float)(-20), 0.0f, 1.0f, 0.0f);
                GL11.glScalef(n7, -n7, n7);
                GL11.glRotatef((float)(-100), 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)45, 0.0f, 1.0f, 0.0f);
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI3.IllIIIIIIIlIlIllllIIllIII()) {
                final float n8 = 0.73913044f * 0.8455882f;
                if (liiiIlIIllIIlIIlIIIlIIllI3.lIIIIllIIlIlIllIIIlIllIlI()) {
                    GL11.glRotatef((float)180, 0.0f, 0.0f, 1.0f);
                    GL11.glTranslatef(0.0f, 1.2586207f * -0.09931506f, 0.0f);
                }
                this.IIIIllIlIIIllIlllIlllllIl();
                GL11.glScalef(n8, -n8, n8);
                GL11.glRotatef((float)(-100), 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)45, 0.0f, 1.0f, 0.0f);
            }
            else {
                final float n9 = 6.6666665f * 0.056250002f;
                GL11.glTranslatef(0.39583334f * 0.6315789f, 0.15671642f * 1.1964285f, -0.034539476f * 5.428571f);
                GL11.glScalef(n9, n9, n9);
                GL11.glRotatef((float)60, 0.0f, 0.0f, 1.0f);
                GL11.glRotatef((float)(-90), 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)20, 0.0f, 0.0f, 1.0f);
            }
            if (illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI().IIIlIIllllIIllllllIlIIIll()) {
                for (int i = 0; i <= 1; ++i) {
                    final int liiiIlIIllIIlIIlIIIlIIllI4 = illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl, i);
                    GL11.glColor4f((liiiIlIIllIIlIIlIIIlIIllI4 >> 16 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI4 >> 8 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI4 & 0xFF) / (float)255, 1.0f);
                    this.lIIIIIIIIIlIllIIllIlIIlIl.itemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIllIlIIlIllIIlIlllI, illIIIllIlIIlIllIIIllllIl, i);
                }
            }
            else {
                final int liiiIlIIllIIlIIlIIIlIIllI5 = illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl, 0);
                GL11.glColor4f((liiiIlIIllIIlIIlIIIlIIllI5 >> 16 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI5 >> 8 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI5 & 0xFF) / (float)255, 1.0f);
                this.lIIIIIIIIIlIllIIllIlIIlIl.itemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIllIlIIlIllIIlIlllI, illIIIllIlIIlIllIIIllllIl, 0);
            }
            GL11.glPopMatrix();
        }
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl() {
        GL11.glTranslatef(0.0f, 2.2f * 0.08522727f, 0.0f);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        this.lIIIIIIIIIlIllIIllIlIIlIl((IlllIIIllIlIIlIllIIlIlllI)entityLivingBase, n, n2);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIIIllIlIIlIllIIlIlllI)entityLivingBase, n, n2);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIIIllIlIIlIllIIlIlllI)entityLivingBase, n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIIIllIlIIlIllIIlIlllI)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIIIllIlIIlIllIIlIlllI)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIIIllIlIIlIllIIlIlllI)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIllIIlIlIllIIIlIllIlI = new ResourceLocation[] { new ResourceLocation("textures/models/armor/leather_layer_1.png"), new ResourceLocation("textures/models/armor/leather_layer_2.png"), new ResourceLocation("textures/models/armor/chainmail_layer_1.png"), new ResourceLocation("textures/models/armor/chainmail_layer_2.png"), new ResourceLocation("textures/models/armor/iron_layer_1.png"), new ResourceLocation("textures/models/armor/iron_layer_2.png"), new ResourceLocation("textures/models/armor/diamond_layer_1.png"), new ResourceLocation("textures/models/armor/diamond_layer_2.png"), new ResourceLocation("textures/models/armor/gold_layer_1.png"), new ResourceLocation("textures/models/armor/gold_layer_2.png"), new ResourceLocation("textures/models/armor/leather_layer_1_overlay.png"), new ResourceLocation("textures/models/armor/leather_layer_2_overlay.png") };
        IlllIllIlIIIIlIIlIIllIIIl = new String[] { "leather", "chainmail", "iron", "diamond", "gold" };
    }
}
