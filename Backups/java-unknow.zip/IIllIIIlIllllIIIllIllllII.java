import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIlIllllIIIllIllllII
{
    private static final Random lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return IIllIIIlIllllIIIllIllllII.lIIIIlIIllIIlIIlIIIlIIllI.nextInt(n2 + 1 - n) + n;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new Random();
    }
}
