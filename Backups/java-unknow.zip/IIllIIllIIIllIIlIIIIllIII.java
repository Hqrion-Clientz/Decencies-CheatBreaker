import java.util.Arrays;
import java.io.DataInput;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIllIIIllIIlIIIIllIII extends lIllIIIIIlIIllIIIIlIIllII
{
    private int[] lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIllIIllIIIllIIlIIIIllIII() {
    }
    
    public IIllIIllIIIllIIlIIIIllIII(final int[] liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataOutput dataOutput) {
        dataOutput.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl.length);
        for (int i = 0; i < this.lIIIIIIIIIlIllIIllIlIIlIl.length; ++i) {
            dataOutput.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl[i]);
        }
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataInput dataInput, final int n, final llllIlIIllllIllIlllllllll llllIlIIllllIllIlllllllll) {
        final int int1 = dataInput.readInt();
        llllIlIIllllIllIlllllllll.lIIIIlIIllIIlIIlIIIlIIllI(32 * int1);
        this.lIIIIIIIIIlIllIIllIlIIlIl = new int[int1];
        for (int i = 0; i < int1; ++i) {
            this.lIIIIIIIIIlIllIIllIlIIlIl[i] = dataInput.readInt();
        }
    }
    
    @Override
    public byte lIIIIlIIllIIlIIlIIIlIIllI() {
        return 11;
    }
    
    @Override
    public String toString() {
        String string = "[";
        final int[] liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        for (int length = liiiiiiiiIlIllIIllIlIIlIl.length, i = 0; i < length; ++i) {
            string = string + liiiiiiiiIlIllIIllIlIIlIl[i] + ",";
        }
        return string + "]";
    }
    
    @Override
    public lIllIIIIIlIIllIIIIlIIllII lIIIIIIIIIlIllIIllIlIIlIl() {
        final int[] array = new int[this.lIIIIIIIIIlIllIIllIlIIlIl.length];
        System.arraycopy(this.lIIIIIIIIIlIllIIllIlIIlIl, 0, array, 0, this.lIIIIIIIIIlIllIIllIlIIlIl.length);
        return new IIllIIllIIIllIIlIIIIllIII(array);
    }
    
    @Override
    public boolean equals(final Object o) {
        return super.equals(o) && Arrays.equals(this.lIIIIIIIIIlIllIIllIlIIlIl, ((IIllIIllIIIllIIlIIIIllIII)o).lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    public int hashCode() {
        return super.hashCode() ^ Arrays.hashCode(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public int[] IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
