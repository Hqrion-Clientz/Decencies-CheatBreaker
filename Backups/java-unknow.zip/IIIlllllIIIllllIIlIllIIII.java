import java.util.Collection;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.AbstractCollection;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIlllllIIIllllIIlIllIIII extends AbstractCollection implements IlIIIlIIlIllIIllllIlIIlIl
{
    protected IIIlllllIIIllllIIlIllIIII() {
    }
    
    @Override
    public Object[] toArray() {
        final Object[] array = new Object[this.size()];
        lIIIIlIlIllIIIIIIIlIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(), array);
        return array;
    }
    
    @Override
    public Object[] toArray(Object[] array) {
        final int size = this.size();
        if (array.length < size) {
            array = (Object[])Array.newInstance(array.getClass().getComponentType(), size);
        }
        lIIIIlIlIllIIIIIIIlIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(), array);
        if (size < array.length) {
            array[size] = null;
        }
        return array;
    }
    
    @Override
    public boolean addAll(final Collection collection) {
        boolean b = false;
        final Iterator<Object> iterator = collection.iterator();
        int size = collection.size();
        while (size-- != 0) {
            if (this.add(iterator.next())) {
                b = true;
            }
        }
        return b;
    }
    
    @Override
    public boolean add(final Object o) {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    @Override
    public lllllIllIlIIllIIIlllllIIl IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    @Override
    public abstract lllllIllIlIIllIIIlllllIIl lIIIIlIIllIIlIIlIIIlIIllI();
    
    @Override
    public boolean remove(final Object o) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(o);
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final Object o) {
        final lllllIllIlIIllIIIlllllIIl liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI();
        while (liiiIlIIllIIlIIlIIIlIIllI.hasNext()) {
            if (o == liiiIlIIllIIlIIlIIIlIIllI.next()) {
                liiiIlIIllIIlIIlIIIlIIllI.remove();
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean containsAll(final Collection collection) {
        int size = collection.size();
        final Iterator<Object> iterator = collection.iterator();
        while (size-- != 0) {
            if (!this.contains(iterator.next())) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean retainAll(final Collection collection) {
        boolean b = false;
        int size = this.size();
        final lllllIllIlIIllIIIlllllIIl liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI();
        while (size-- != 0) {
            if (!collection.contains(liiiIlIIllIIlIIlIIIlIIllI.next())) {
                liiiIlIIllIIlIIlIIIlIIllI.remove();
                b = true;
            }
        }
        return b;
    }
    
    @Override
    public boolean removeAll(final Collection collection) {
        boolean b = false;
        int size = collection.size();
        final Iterator<Object> iterator = collection.iterator();
        while (size-- != 0) {
            if (this.remove(iterator.next())) {
                b = true;
            }
        }
        return b;
    }
    
    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        final lllllIllIlIIllIIIlllllIIl liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI();
        int size = this.size();
        int n = 1;
        sb.append("{");
        while (size-- != 0) {
            if (n != 0) {
                n = 0;
            }
            else {
                sb.append(", ");
            }
            final IIIlllllIIIllllIIlIllIIII next = liiiIlIIllIIlIIlIIIlIIllI.next();
            if (this == next) {
                sb.append("(this collection)");
            }
            else {
                sb.append(String.valueOf(next));
            }
        }
        sb.append("}");
        return sb.toString();
    }
}
