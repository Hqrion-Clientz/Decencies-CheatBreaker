// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIllIllllIlIIlIIlIII extends IIllIlIIlIllIIIIIlIIIIlII
{
    private final String IlIlIIIlllIIIlIlllIlIllIl;
    private final String IIIllIllIlIlllllllIlIlIII;
    private final String IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIlIIIIllIllllIlIIlIIlIII(final IlIllIlIIllIIIlIIlllllllI ilIllIlIIllIIIlIIlllllllI, final String illIIIIIIIlIlIllllIIllIII, final int n, final boolean b) {
        super(ilIllIlIIllIIIlIIlllllllI, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(b ? "chat.link.confirmTrusted" : "chat.link.confirm", new Object[0]), illIIIIIIIlIlIllllIIllIII, n);
        this.lIIIIllIIlIlIllIIIlIllIlI = true;
        this.IlllIIIlIlllIllIlIIlllIlI = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(b ? "chat.link.open" : "gui.yes", new Object[0]);
        this.IIIIllIlIIIllIlllIlllllIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(b ? "gui.cancel" : "gui.no", new Object[0]);
        this.IIIllIllIlIlllllllIlIlIII = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("chat.copy", new Object[0]);
        this.IlIlIIIlllIIIlIlllIlIllIl = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("chat.link.warning", new Object[0]);
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 154, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 96, 100, 20, this.IlllIIIlIlllIllIlIIlllIlI));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(2, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 50, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 96, 100, 20, this.IIIllIllIlIlllllllIlIlIII));
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 54, this.IIIIIIlIlIlIllllllIlllIlI / 6 + 96, 100, 20, this.IIIIllIlIIIllIlllIlllllIl));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 2) {
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0, this.IIIIllIIllIIIIllIllIIIlIl);
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        GuiScreen.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        if (this.lIIIIllIIlIlIllIIIlIllIlI) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.IlIlIIIlllIIIlIlllIlIllIl, this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 110, 16764108);
        }
    }
    
    public void shutdownMinecraftApplet() {
        this.lIIIIllIIlIlIllIIIlIllIlI = false;
    }
}
