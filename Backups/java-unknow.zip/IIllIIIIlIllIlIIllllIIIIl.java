import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIlIllIlIIllllIIIIl extends llIIIlIIIlllIllIIIIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private static final ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    
    public IIllIIIIlIllIlIIllllIIIIl() {
        super(new IlIIlllIlllllllllllIIIllI(), 1.0f);
        this.IIIllIllIlIlllllllIlIlIII = ((IlIIlllIlllllllllllIIIllI)this.lIIlIlIllIIlIIIlIIIlllIII).lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIllIIlIlIlllIIIIllIIlIII illIIlIlIlllIIIIllIIlIII, final double n, final double n2, final double n3, final float n4, final float n5) {
        llIIIllIIllIIIllIlllIlllI.lIIIIlIIllIIlIIlIIIlIIllI(illIIlIlIlllIIIIllIIlIII, true);
        final int liiiIlIIllIIlIIlIIIlIIllI = ((IlIIlllIlllllllllllIIIllI)this.lIIlIlIllIIlIIIlIIIlllIII).lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI != this.IIIllIllIlIlllllllIlIlIII) {
            this.IIIllIllIlIlllllllIlIlIII = liiiIlIIllIIlIIlIIIlIIllI;
            this.lIIlIlIllIIlIIIlIIIlllIII = new IlIIlllIlllllllllllIIIllI();
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(illIIlIlIlllIIIIllIIlIII, n, n2, n3, n4, n5);
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IIllIIlIlIlllIIIIllIIlIII illIIlIlIlllIIIIllIIlIII) {
        final int ilIIIIlllIIIlIIllllIIIlll = illIIlIlIlllIIIIllIIlIII.IlIIIIlllIIIlIIllllIIIlll();
        return (ilIIIIlllIIIlIIllllIIIlll > 0 && (ilIIIIlllIIIlIIllllIIIlll > 80 || ilIIIIlllIIIlIIllllIIIlll / 5 % 2 != 1)) ? IIllIIIIlIllIlIIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI : IIllIIIIlIllIlIIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIllIIlIlIlllIIIIllIIlIII illIIlIlIlllIIIIllIIlIII, final float n) {
        final int ilIIIIlllIIIlIIllllIIIlll = illIIlIlIlllIIIIllIIlIII.IlIIIIlllIIIlIIllllIIIlll();
        if (ilIIIIlllIIIlIIllllIIIlll > 0) {
            final float n2 = 2.0f - (ilIIIIlllIIIlIIllllIIIlll - n) / 220 * (0.01923077f * 26.0f);
            GL11.glScalef(n2, n2, n2);
        }
        else {
            GL11.glScalef(2.0f, 2.0f, 2.0f);
        }
    }
    
    protected int lIIIIlIIllIIlIIlIIIlIIllI(final IIllIIlIlIlllIIIIllIIlIII illIIlIlIlllIIIIllIIlIII, final int n, final float n2) {
        if (illIIlIlIlllIIIIllIIlIII.IllIIIIIllllIlllIIlIIllIl()) {
            if (illIIlIlIlllIIIIllIIlIII.IIIllllIlIIlIIIlIlIlllIII()) {
                GL11.glDepthMask(false);
            }
            else {
                GL11.glDepthMask(true);
            }
            if (n == 1) {
                final float n3 = illIIlIlIlllIIIIllIIlIII.IIIlIllIlllIlIllIllllllll + n2;
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIllIIIIlIllIlIIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI);
                GL11.glMatrixMode(5890);
                GL11.glLoadIdentity();
                GL11.glTranslatef(MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n3 * (4.8780488E-4f * 41.0f)) * 3, n3 * (0.4875f * 0.02051282f), 0.0f);
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII);
                GL11.glMatrixMode(5888);
                GL11.glEnable(3042);
                final float n4 = 5.357143f * 0.093333334f;
                GL11.glColor4f(n4, n4, n4, 1.0f);
                GL11.glDisable(2896);
                GL11.glBlendFunc(1, 1);
                GL11.glTranslatef(0.0f, 2.5151515f * -0.0039759036f, 0.0f);
                GL11.glScalef(1.821875f * 0.6037736f, 0.6152543f * 1.7878788f, 0.5208333f * 2.1120002f);
                return 1;
            }
            if (n == 2) {
                GL11.glMatrixMode(5890);
                GL11.glLoadIdentity();
                GL11.glMatrixMode(5888);
                GL11.glEnable(2896);
                GL11.glDisable(3042);
            }
        }
        return -1;
    }
    
    protected int lIIIIIIIIIlIllIIllIlIIlIl(final IIllIIlIlIlllIIIIllIIlIII illIIlIlIlllIIIIllIIlIII, final int n, final float n2) {
        return -1;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)illlIIIllIlIIlIllIIlIlllI, n, n2, n3, n4, n5);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)entityLivingBase, n);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)entityLivingBase, n, n2);
    }
    
    @Override
    protected int IlllIIIlIlllIllIlIIlllIlI(final EntityLivingBase entityLivingBase, final int n, final float n2) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl((IIllIIlIlIlllIIIIllIIlIII)entityLivingBase, n, n2);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllIIlIlIlllIIIIllIIlIII)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
        IlIlIIIlllIIIlIlllIlIllIl = new ResourceLocation("textures/entity/wither/wither.png");
    }
}
