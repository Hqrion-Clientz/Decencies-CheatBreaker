// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlllIlIlIlllIIllIlIIl extends IllllIllIlIIIIlIIlIIIIIII
{
    IIIIIllIIlIlllllIlIllllIl lIIIIlIIllIIlIIlIIIlIIllI;
    EntityLivingBase lIIIIIIIIIlIllIIllIlIIlIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    
    public IIlIIlllIlIlIlllIIllIlIIl(final IIIIIllIIlIlllllIlIllllIl liiiIlIIllIIlIIlIIIlIIllI) {
        super(liiiIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIlIIllIIlIIlIIIlIIllI(1);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.llllIIllIIlIIllIIIllIlIlI()) {
            return false;
        }
        final EntityLivingBase llIlllIIllIlllIlIlIlIIIll = this.lIIIIlIIllIIlIIlIIIlIIllI.llIlllIIllIlllIlIlIlIIIll();
        if (llIlllIIllIlllIlIlIlIIIll == null) {
            return false;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = llIlllIIllIlllIlIlIlIIIll.llIIllllIlIlIllIlIllIlIlI();
        return llIlllIIllIlllIlIlIlIIIll.IlllIIIIlllllIlIlllllIlll() != this.IIIIllIIllIIIIllIllIIIlIl && this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, false) && this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, llIlllIIllIlllIlIlIlIIIll);
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl);
        final EntityLivingBase llIlllIIllIlllIlIlIlIIIll = this.lIIIIlIIllIIlIIlIIIlIIllI.llIlllIIllIlllIlIlIlIIIll();
        if (llIlllIIllIlllIlIlIlIIIll != null) {
            this.IIIIllIIllIIIIllIllIIIlIl = llIlllIIllIlllIlIlIlIIIll.IlllIIIIlllllIlIlllllIlll();
        }
        super.IIIIllIIllIIIIllIllIIIlIl();
    }
}
