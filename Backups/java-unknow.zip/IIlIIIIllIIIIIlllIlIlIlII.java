// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIllIIIIIlllIlIlIlII extends IIlllIllIlIllIIlIIIlIIlll
{
    private float lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIIIllIIIIIlllIlIlIlII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, n5, n6);
        this.IllIIlIIlllllIllIIIlllIII = this.IllIIlIIlllllIllIIIlllIII * (8.333333147068819E-4 * 12.0) + n4;
        this.lIlIlIllIIIIIIIIllllIIllI = this.lIlIlIllIIIIIIIIllllIIllI * (0.025789473512289923 * 0.3877550959587097) + n5;
        this.IlllIIlllIIIIllIIllllIlIl = this.IlllIIlllIIIIllIIllllIlIl * (0.0018749999022111326 * 5.333333492279053) + n6;
        final double n7 = n + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (2.0588236f * 0.024285713f);
        final double n8 = n2 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.37974682f * 0.13166668f);
        final double n9 = n3 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.10222223f * 0.48913044f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = this.IllIIIIIIIlIlIllllIIllIII;
        final float illlIllIlIIIIlIIlIIllIIIl = 1.0f;
        this.llIIlllIIIIlllIllIlIlllIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IlIlllIIIIllIllllIllIIlIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IIIllIllIlIlllllllIlIlIII = (int)(8 / (Math.random() * (14.666666984558105 * 0.05454545336321369) + 0.6478873491287231 * 0.30869564017411266)) + 4;
        this.lllIIllllIIlIlIlIlIIIlIII = true;
        this.updateDebugProfilerName(48);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Tessellator tessellator, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        final float n7 = (this.IlIlIIIlllIIIlIlllIlIllIl + n) / this.IIIllIllIlIlllllllIlIlIII;
        this.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI * (1.0f - n7 * n7 * (26.0f * 0.01923077f));
        super.lIIIIlIIllIIlIIlIIIlIIllI(tessellator, n, n2, n3, n4, n5, n6);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        float n2 = (this.IlIlIIIlllIIIlIlllIlIllIl + n) / this.IIIllIllIlIlllllllIlIlIII;
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = super.lIIIIlIIllIIlIIlIIIlIIllI(n);
        final int n3 = liiiIlIIllIIlIIlIIIlIIllI & 0xFF;
        final int n4 = liiiIlIIllIIlIIlIIIlIIllI >> 16 & 0xFF;
        int n5 = n3 + (int)(n2 * 15 * 16);
        if (n5 > 240) {
            n5 = 240;
        }
        return n5 | n4 << 16;
    }
    
    @Override
    public float lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        float n2 = (this.IlIlIIIlllIIIlIlllIlIllIl + n) / this.IIIllIllIlIlllllllIlIlIII;
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        return super.lIIIIIIIIIlIllIIllIlIIlIl(n) * n2 + (1.0f - n2);
    }
    
    @Override
    public void x_() {
        this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
        this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
        if (this.IlIlIIIlllIIIlIlllIlIllIl++ >= this.IIIllIllIlIlllllllIlIlIII) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        this.IllIIlIIlllllIllIIIlllIII *= 2.8490321176927904 * 0.33695653080940247;
        this.lIlIlIllIIIIIIIIllllIIllI *= 0.13292307200177894 * 7.222222328186035;
        this.IlllIIlllIIIIllIIllllIlIl *= 0.5142857432365417 * 1.8666665198626424;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            this.IllIIlIIlllllIllIIIlllIII *= 1.75 * 0.3999999931880406;
            this.IlllIIlllIIIIllIIllllIlIl *= 1.0616666158917893 * 0.6593406796455383;
        }
    }
}
