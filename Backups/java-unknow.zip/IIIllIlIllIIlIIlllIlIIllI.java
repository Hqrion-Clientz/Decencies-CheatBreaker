import org.lwjgl.opengl.GL11;
import java.nio.FloatBuffer;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIlIllIIlIIlllIlIIllI extends lIlllIIIIIIIlIIIllllIIIlI
{
    private static final ResourceLocation IlllIIIlIlllIllIlIIlllIlI;
    private static final ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private static final Random IIIIllIIllIIIIllIllIIIlIl;
    FloatBuffer lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIllIlIllIIlIIlllIlIIllI() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = GLAllocation.IIIIllIIllIIIIllIllIIIlIl(16);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIIIlllllIlIIIIlIllII lIlIIIIIlllllIlIIIIlIllII, final double n, final double n2, final double n3, final float n4) {
        final float n5 = (float)this.lIIIIIIIIIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl;
        final float n6 = (float)this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlllIIIIllIllllIllIIlIl;
        final float n7 = (float)this.lIIIIIIIIIlIllIIllIlIIlIl.llIIlllIIIIlllIllIlIlllIl;
        GL11.glDisable(2896);
        IIIllIlIllIIlIIlllIlIIllI.IIIIllIIllIIIIllIllIIIlIl.setSeed(31100L);
        final float n8 = 8.8f * 0.08522727f;
        for (int i = 0; i < 16; ++i) {
            GL11.glPushMatrix();
            float n9 = (float)(16 - i);
            float n10 = 0.06161972f * 1.0142857f;
            float n11 = 1.0f / (n9 + 1.0f);
            if (i == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIIllIlIllIIlIIlllIlIIllI.IlllIIIlIlllIllIlIIlllIlI);
                n11 = 0.108333334f * 0.9230769f;
                n9 = 65;
                n10 = 1.1230769f * 0.11130137f;
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
            }
            if (i == 1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(IIIllIlIllIIlIIlllIlIIllI.IIIIllIlIIIllIlllIlllllIl);
                GL11.glEnable(3042);
                GL11.glBlendFunc(1, 1);
                n10 = 0.43617022f * 1.1463414f;
            }
            final float n12 = (float)(-(n2 + n8));
            GL11.glTranslatef(n5, (n12 + IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl) / (n12 + n9 + IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl) + (float)(n2 + n8), n7);
            GL11.glTexGeni(8192, 9472, 9217);
            GL11.glTexGeni(8193, 9472, 9217);
            GL11.glTexGeni(8194, 9472, 9217);
            GL11.glTexGeni(8195, 9472, 9216);
            GL11.glTexGen(8192, 9473, this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 0.0f, 0.0f, 0.0f));
            GL11.glTexGen(8193, 9473, this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 1.0f, 0.0f));
            GL11.glTexGen(8194, 9473, this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f));
            GL11.glTexGen(8195, 9474, this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 1.0f, 0.0f, 0.0f));
            GL11.glEnable(3168);
            GL11.glEnable(3169);
            GL11.glEnable(3170);
            GL11.glEnable(3171);
            GL11.glPopMatrix();
            GL11.glMatrixMode(5890);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, Minecraft.getSystemTime() % 700000L / (float)700000, 0.0f);
            GL11.glScalef(n10, n10, n10);
            GL11.glTranslatef(0.6836735f * 0.73134327f, 0.31034482f * 1.6111112f, 0.0f);
            GL11.glRotatef((i * i * 4321 + i * 9) * 2.0f, 0.0f, 0.0f, 1.0f);
            GL11.glTranslatef(-0.33333334f * 1.5f, -0.3655914f * 1.367647f, 0.0f);
            GL11.glTranslatef(-n5, -n7, -n6);
            final float n13 = n12 + IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl;
            GL11.glTranslatef(IlIIIllIlIlIIIlIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI * n9 / n13, IlIIIllIlIlIIIlIIlIIIIlIl.IlllIIIlIlllIllIlIIlllIlI * n9 / n13, -n6);
            final Tessellator instance = Tessellator.instance;
            instance.startDrawingQuads();
            float n14 = IIIllIlIllIIlIIlllIlIIllI.IIIIllIIllIIIIllIllIIIlIl.nextFloat() * (0.8979592f * 0.5568182f) + 0.0076923077f * 13.0f;
            float n15 = IIIllIlIllIIlIIlllIlIIllI.IIIIllIIllIIIIllIllIIIlIl.nextFloat() * (0.43939397f * 1.137931f) + 0.10344828f * 3.8666666f;
            float n16 = IIIllIlIllIIlIIlllIlIIllI.IIIIllIIllIIIIllIllIIIlIl.nextFloat() * (1.1206896f * 0.44615385f) + 0.60389614f * 0.827957f;
            if (i == 0) {
                n16 = 1.0f;
                n15 = 1.0f;
                n14 = 1.0f;
            }
            instance.lIIIIlIIllIIlIIlIIIlIIllI(n14 * n11, n15 * n11, n16 * n11, 1.0f);
            instance.addVertex(n, n2 + n8, n3);
            instance.addVertex(n, n2 + n8, n3 + 1.0);
            instance.addVertex(n + 1.0, n2 + n8, n3 + 1.0);
            instance.addVertex(n + 1.0, n2 + n8, n3);
            instance.draw();
            GL11.glPopMatrix();
            GL11.glMatrixMode(5888);
        }
        GL11.glDisable(3042);
        GL11.glDisable(3168);
        GL11.glDisable(3169);
        GL11.glDisable(3170);
        GL11.glDisable(3171);
        GL11.glEnable(2896);
    }
    
    private FloatBuffer lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
        this.lIIIIlIIllIIlIIlIIIlIIllI.put(n).put(n2).put(n3).put(n4);
        this.lIIIIlIIllIIlIIlIIIlIIllI.flip();
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl, final double n, final double n2, final double n3, final float n4) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIlIIIIIlllllIlIIIIlIllII)illIllIlIIlllIllIIllIlIIl, n, n2, n3, n4);
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = new ResourceLocation("textures/environment/end_sky.png");
        IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("textures/entity/end_portal.png");
        IIIIllIIllIIIIllIllIIIlIl = new Random(31100L);
    }
}
