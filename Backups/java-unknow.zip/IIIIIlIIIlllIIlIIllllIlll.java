import java.util.Iterator;
import java.awt.Color;
import org.lwjgl.opengl.GL11;
import com.google.common.collect.Lists;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIIlllIIlIIllllIlll
{
    private final Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    private final CheatBreaker lIIIIIIIIIlIllIIllIlIIlIl;
    private final List IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIIlIIIlllIIlIIllllIlll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Minecraft.getMinecraft();
        this.lIIIIIIIIIlIllIIllIlIIlIl = CheatBreaker.getInstance();
        this.IlllIIIlIlllIllIlIIlllIlI = Lists.newArrayList();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIllIlIIllIllIlIlIIlIl lIllIllIlIIllIllIlIlIIlIl) {
        GL11.glEnable(3042);
        for (final llllIlIIIIIllIIlIlllIllll llllIlIIIIIllIIlIlllIllll : this.IlllIIIlIlllIllIlIIlllIlI) {
            final boolean b = llllIlIIIIIllIIlIlllIllll.lIIIIIIIIIlIllIIllIlIIlIl == IIIlIIIIllIIIlIIIIIlllllI.lIIIIIIIIIlIllIIllIlIIlIl;
            final float n = b ? 4 : (1.875f * 0.8f);
            final float n2 = b ? -30 : ((float)10);
            final float n3 = n * llllIlIIIIIllIIlIlllIllll.IIIIllIlIIIllIlllIlllllIl;
            GL11.glScalef(n3, n3, n3);
            float b2 = 255;
            if (llllIlIIIIIllIIlIlllIllll.lIIIIlIIllIIlIIlIIIlIIllI()) {
                b2 = 1.0f - (llllIlIIIIIllIIlIlllIllll.IlIlIIIlllIIIlIlllIlIllIl - (System.currentTimeMillis() - llllIlIIIIIllIIlIlllIllll.lIIIIlIIllIIlIIlIIIlIIllI)) / (float)llllIlIIIIIllIIlIlllIllll.IlIlIIIlllIIIlIlllIlIllIl;
            }
            else if (llllIlIIIIIllIIlIlllIllll.lIIIIIIIIIlIllIIllIlIIlIl()) {
                final float n4 = (float)(llllIlIIIIIllIIlIlllIllll.IIIIllIIllIIIIllIllIIIlIl - (System.currentTimeMillis() - llllIlIIIIIllIIlIlllIllll.lIIIIlIIllIIlIIlIIIlIIllI));
                if (n4 <= 0.0f) {
                    b2 = 0.0f;
                }
                else {
                    b2 = n4 / llllIlIIIIIllIIlIlllIllll.IIIllIllIlIlllllllIlIlIII;
                }
            }
            float min = Math.min(1.0f, Math.max(0.0f, b2));
            if (min <= 0.8611111044883728 * 0.17419354972680576) {
                min = 1.6f * 0.09375f;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(llllIlIIIIIllIIlIlllIllll.IlllIIIlIlllIllIlIIlllIlI, (int)(lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().getScaledWidth() / 2 / n3), (int)((lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().getScaledHeight() / 2 - this.lIIIIlIIllIIlIIlIIIlIIllI.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI / 2 + n2) / n3), new Color(1.0f, 1.0f, 1.0f, min).getRGB());
            GL11.glScalef(1.0f / n3, 1.0f / n3, 1.0f / n3);
        }
        GL11.glDisable(3042);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final CBTickEvent cbTickEvent) {
        if (!this.IlllIIIlIlllIllIlIIlllIlI.isEmpty()) {
            this.IlllIIIlIlllIllIlIIlllIlI.removeIf(llllIlIIIIIllIIlIlllIllll -> llllIlIIIIIllIIlIlllIllll.lIIIIlIIllIIlIIlIIIlIIllI + llllIlIIIIIllIIlIlllIllll.IIIIllIIllIIIIllIllIIIlIl < System.currentTimeMillis());
        }
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
}
