// 
// Decompiled by Procyon v0.5.36
// 

package com.cheatbreaker.client.network.messages;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.annotation.Annotation;
import net.minecraft.client.main.Main;

public class Message
{
    private String action;
    public static byte[] b;
    public static byte[] a;
    
    public Message(final String action) {
        this.action = action;
    }
    
    public String getAction() {
        return this.action;
    }
    
    public static native void dispatchCommandsToNative(final String[] p0);
    
    public static native void b(final String p0);
    
    public static native void c(final String p0, final String p1, final String p2);
    
    public static void d() {
        String string = "";
        String string2 = "";
        String string3 = "";
        String string4 = "";
        String string5 = "";
        String string6 = "";
        String string7 = "";
        for (final Method method : Minecraft.class.getMethods()) {
            if (method.getReturnType() == Minecraft.class) {
                string = method.getName() + ":()L" + Minecraft.class.getCanonicalName().replaceAll("\\.", "/") + ";";
            }
            else if (method.getReturnType() == lIIIIIlIlIIIIIIIlIlIlllIl.class) {
                string2 = method.getName() + ":()L" + lIIIIIlIlIIIIIIIlIlIlllIl.class.getCanonicalName().replaceAll("\\.", "/") + ";";
            }
        }
        for (final Method method2 : lIIIIIlIlIIIIIIIlIlIlllIl.class.getMethods()) {
            if (method2.getParameterTypes().length == 1 && method2.getParameterTypes()[0] == IIllIlllIIlllllIlllIIIlIl.class) {
                string3 = method2.getName() + ":(L" + IIllIlllIIlllllIlllIIIlIl.class.getCanonicalName().replaceAll("\\.", "/") + ";)V";
            }
        }
        for (final Field field : Entity.class.getFields()) {
            if (field.getType() == Float.TYPE) {
                string4 = field.getName() + ":F";
                break;
            }
        }
        for (final Method method3 : Main.class.getMethods()) {
            if (method3.getParameterTypes().length == 1 && method3.getParameterTypes()[0] == String[].class) {
                string5 = method3.getName() + ":([Ljava/lang/String;)V";
            }
        }
        for (final Method method4 : CBAgentResources.class.getMethods()) {
            if (method4.isAnnotationPresent(CBAgentByteArrayReference.class)) {
                string6 = method4.getName() + ":(Ljava/lang/String;)[B";
            }
            if (method4.isAnnotationPresent(CBAgentBooleanReference.class)) {
                string7 = method4.getName() + ":(Ljava/lang/String;)Z";
            }
        }
        dispatchCommandsToNative(new String[] { r(lIIlIlllIlIllIlIlIllllIlI.class.getName()), r(IllIIIIllIIIIIIIIIIlIllIl.class.getName()), r(Minecraft.class.getName()), r(lIIIIIlIlIIIIIIIlIlIlllIl.class.getName()), r(Entity.class.getName()), r(CBAgentResources.class.getName()), r(Main.class.getName()), string, string2, string3, string4, string5, string6, string7 });
    }
    
    private static String r(final String s) {
        return s.replaceAll("\\.", "/");
    }
    
    public static native void e(final boolean p0);
    
    public static native void f(final String p0, final byte[] p1);
    
    public static void j(final byte[] array) {
        CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI(new lllIlIlIllIlIIIIIlllIIlll(array));
    }
    
    public static void r(final byte[] b) {
        Message.b = b;
        final Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft.theWorld != null && minecraft.getNetHandler().IlllIIIlIlllIllIlIIlllIlI().IllIIIIIIIlIlIllllIIllIII().isOpen() && CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI().lIIIIIIIIIlIllIIllIlIIlIl()) {
            minecraft.getNetHandler().IlllIIIlIlllIllIlIIlllIlI().IllIIIIIIIlIlIllllIIllIII().writeAndFlush((Object)new lIIlIlllIlIllIlIlIllllIlI(CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl(), b));
        }
    }
    
    public static void g(final String[] array, final String[] array2) {
        for (int i = 0; i < array.length; ++i) {
            System.out.print("[CB] Added mic option : " + array2[i]);
            CheatBreaker.IllIlIlIllllIlIIllllIIlll().add(new IIIIllIIllIIIIllIllIIIlIl(array[i], array2[i]));
        }
    }
    
    public static native void h(final String p0);
    
    public static native byte[] i();
    
    public static native void k();
    
    public static native void l(final float p0);
    
    public static native void m(final float p0);
    
    public static void n() {
        Minecraft.getMinecraft().gameSettings.saveOptions();
        CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
        CheatBreaker.getInstance().lIllIllIlIIllIllIlIlIIlIl().updateScreen();
        System.exit(0);
    }
    
    public static void o(final String s) {
        final Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft != null && minecraft.ingameGUI != null && minecraft.ingameGUI.getChatGUI() != null) {
            Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(s));
        }
    }
    
    public static native void s(final int p0, final boolean p1);
}
