// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlllIlIIlIIIIlIIllIlI extends IIIllIlIIIllIlIIIIlIlllII
{
    private IIlllIllIllllIIlIllIIIIIl lIIIIlIIllIIlIIlIIIlIIllI;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    
    public IIIIIlllIlIIlIIIIlIIllIlI(final IllIlIIIIIIllIIIIIllIllIl illIlIIIIIIllIIIIIllIllIl, final IIlllIllIllllIIlIllIIIIIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(liiiIlIIllIIlIIlIIIlIIllI, 0, 56, 17));
        this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(liiiIlIIllIIlIIlIIIlIIllI, 1, 56, 53));
        this.lIIIIIIIIIlIllIIllIlIIlIl(new IIIIllIIlIlIIIIIIIlIIIlIl(illIlIIIIIIllIIIIIllIllIl.IIIIllIlIIIllIlllIlllllIl, liiiIlIIllIIlIIlIIIlIIllI, 2, 116, 35));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(illIlIIIIIIllIIIIIllIllIl, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(illIlIIIIIIllIIIIIllIllIl, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllllIIIIlIllIIllIIlIIll lIllllIIIIlIllIIllIIlIIll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lIllllIIIIlIllIIllIIlIIll);
        lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 0, this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl);
        lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII);
        lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 2, this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
        super.IlllIIIlIlllIllIlIIlllIlI();
        for (int i = 0; i < this.IIIIllIIllIIIIllIllIIIlIl.size(); ++i) {
            final lIllllIIIIlIllIIllIIlIIll lIllllIIIIlIllIIllIIlIIll = this.IIIIllIIllIIIIllIllIIIlIl.get(i);
            if (this.IlIlIIIlllIIIlIlllIlIllIl != this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl) {
                lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 0, this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl);
            }
            if (this.IIIllIllIlIlllllllIlIlIII != this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII) {
                lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 1, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII);
            }
            if (this.IllIIIIIIIlIlIllllIIllIII != this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI) {
                lIllllIIIIlIllIIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, 2, this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI);
            }
        }
        this.IlIlIIIlllIIIlIlllIlIllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl;
        this.IIIllIllIlIlllllllIlIlIII = this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII;
        this.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int liiiIllIIlIlIllIIIlIllIlI) {
        if (n == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl = liiiIllIIlIlIllIIIlIllIlI;
        }
        if (n == 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII = liiiIllIIlIlIllIIIlIllIlI;
        }
        if (n == 2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n) {
        lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = null;
        final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
        if (ilIIIIIlIIIIlIIIIlIlllIlI != null && ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl()) {
            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
            llIIlllIIIIlllIllIlIlllIl = liiiIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
            if (n == 2) {
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 3, 39, true)) {
                    return null;
                }
                ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, llIIlllIIIIlllIllIlIlllIl);
            }
            else if (n != 1 && n != 0) {
                if (lIllllIllIIllIlIllllIIIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) != null) {
                    if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 0, 1, false)) {
                        return null;
                    }
                }
                else if (IIlllIllIllllIIlIllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI)) {
                    if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 1, 2, false)) {
                        return null;
                    }
                }
                else if (n >= 3 && n < 30) {
                    if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 30, 39, false)) {
                        return null;
                    }
                }
                else if (n >= 30 && n < 39 && !this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 3, 30, false)) {
                    return null;
                }
            }
            else if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 3, 39, false)) {
                return null;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(null);
            }
            else {
                ilIIIIIlIIIIlIIIIlIlllIlI.IlllIIIlIlllIllIlIIlllIlI();
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl == llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl) {
                return null;
            }
            ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, liiiIlIIllIIlIIlIIIlIIllI);
        }
        return llIIlllIIIIlllIllIlIlllIl;
    }
}
