import java.util.concurrent.Callable;
import java.util.List;
import java.util.UUID;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class Entity
{
    private static int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    public double lIIIIIllllIIIIlIlIIIIlIlI;
    public boolean IIIIIIlIlIlIllllllIlllIlI;
    public Entity IllIllIIIlIIlllIIIllIllII;
    public Entity IlIIlIIIIlIIIIllllIIlIllI;
    public boolean lIIlIIllIIIIIlIllIIIIllII;
    public IIIIIIllIlIIIIlIlllIllllI lIIlllIIlIlllllllllIIIIIl;
    public double lIllIllIlIIllIllIlIlIIlIl;
    public double llIlIIIllIIIIlllIlIIIIIlI;
    public double lIllIlIlllIIlIIllIIlIIlII;
    public double IIIlIIlIlIIIlllIIlIllllll;
    public double IllIlIIIIlllIIllIIlllIIlI;
    public double IllIlIlIllllIlIIllllIIlll;
    public double IllIIlIIlllllIllIIIlllIII;
    public double lIlIlIllIIIIIIIIllllIIllI;
    public double IlllIIlllIIIIllIIllllIlIl;
    public float IllllIllllIlIIIlIIIllllll;
    public float IllIIlllIllIlIllIlIIIIIII;
    public float IlIlIIIlllllIIIlIlIlIllII;
    public float IIlIIllIIIllllIIlllIllIIl;
    public final IlIllIIlIlIllIlIllllllllI lllIlIIllllIIIIlIllIlIIII;
    public boolean lIIIIlllIIlIlllllIlIllIII;
    public boolean lIIIlllIlIlllIIIIIIIIIlII;
    public boolean IIIIlIIIlllllllllIlllIlll;
    public boolean IlIllllIIIlIllllIIIIIllII;
    public boolean IlIIIIllIIIIIlllIIlIIlllI;
    protected boolean llIlIlIllIlIIlIlllIllIIlI;
    public boolean llIlIlIlllIlllllIIIllIIll;
    public boolean IIllIlIllIlIllIIlIllIlIII;
    public float lIlIllIlIlIIIllllIlIllIll;
    public float IlIIlIIlIllIIIIllIIllIlIl;
    public float llllIIIIlIlIllIIIllllIIll;
    public float IIlIlIIlIIIlIlllllIIlIIlI;
    public float lIIIlllIIIlIIIIIlIIIIIIII;
    public float lIIlIIIIIIIIllIIllIIlllIl;
    public float IllllllIllllIIlllIllllllI;
    private int IlllIIIlIlllIllIlIIlllIlI;
    public double lIlIlIIIlIIllllllllIIlllI;
    public double IlIlllIllIlIllIlllIlllIll;
    public double llIIIllIIllllIlIlIlIlIIll;
    public float IIIIIlIllIllIlIIllIIlIllI;
    public float lIIllIIllllllIIlllIlllIIl;
    public boolean lllIIllllIIlIlIlIlIIIlIII;
    public float IlIIllIlIlIIIllIllIIlIIII;
    protected Random IlIlllIIIIlIllIlllIlIIIll;
    public int IIIlIllIlllIlIllIllllllll;
    public int IllllllllIlIIIIIIIIllIIII;
    private int IIIIllIlIIIllIlllIlllllIl;
    protected boolean lIIlIlIIlIlIlIIlIlIlllIIl;
    public int IllIIIlIIlIllIllIIllllIIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    protected boolean IIlIlllIllIlIlIIIIIlllIll;
    protected IIIIllIllIIlIlIIllllIIlIl IlIIllIIIlllIIIIlIIIIlIll;
    private double IIIllIllIlIlllllllIlIlIII;
    private double IllIIIIIIIlIlIllllIIllIII;
    public boolean lIIIIIIlIIllllllIIIlIlIIl;
    public int llIIIlIlIIlIlIIlIllIllIll;
    public int IlIIlllIlIIIlIIIlIlIlIlIl;
    public int IIIlllllIIlIlIIIllllllIII;
    public int lIlIlIIIIllIlllIlIIlllIlI;
    public int IIllllIllllIIIlIIllllIlll;
    public int llllIIIIIlIlIlIlIllIIIIII;
    public boolean IllIIIIllllllIlllllIlIlll;
    public boolean IIIllllIlIIlIIIlIlIlllIII;
    public int IIlIlllllIIIlIIllIllIlIlI;
    protected boolean IlIllIllIllIllIllllIIIlII;
    protected int lllIllIllIlIllIlIIllllIIl;
    public int IIIIIIIllIllllIIlIIlllIII;
    protected int IIIIlIllIIIIIIlIIIIIlllll;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    protected UUID llllIIlIlIllIllllIIIIllll;
    public IllllllllIIlIlIIIlllIlIII IIlIlIlllIllIIlIllIIlIIlI;
    
    public int lIIIIlllIIlIlllllIlIllIII() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public Entity(final IIIIIIllIlIIIIlIlllIllllI liIlllIIlIlllllllllIIIIIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = Entity.lIIIIlIIllIIlIIlIIIlIIllI++;
        this.lIIIIIllllIIIIlIlIIIIlIlI = 1.0;
        this.lllIlIIllllIIIIlIllIlIIII = IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        this.llIlIlIlllIlllllIIIllIIll = true;
        this.IlIIlIIlIllIIIIllIIllIlIl = 5.5625f * 0.10786517f;
        this.llllIIIIlIlIllIIIllllIIll = 1.3333334f * 1.3499999f;
        this.IlllIIIlIlllIllIlIIlllIlI = 1;
        this.IlIlllIIIIlIllIlllIlIIIll = new Random();
        this.IllllllllIlIIIIIIIIllIIII = 1;
        this.IIIIllIIllIIIIllIllIIIlIl = true;
        this.llllIIlIlIllIllllIIIIllll = UUID.randomUUID();
        this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl;
        this.lIIlllIIlIlllllllllIIIIIl = liIlllIIlIlllllllllIIIIIl;
        this.IlllIIIlIlllIllIlIIlllIlI(0.0, 0.0, 0.0);
        if (liIlllIIlIlllllllllIIIIIl != null) {
            this.IIIIIIIllIllllIIlIIlllIII = liIlllIIlIlllllllllIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI;
        }
        (this.IlIIllIIIlllIIIIlIIIIlIll = new IIIIllIllIIlIlIIllllIIlIl(this)).lIIIIlIIllIIlIIlIIIlIIllI(0, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(1, (Object)300);
        this.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    protected abstract void lIIIIIIIIIlIllIIllIlIIlIl();
    
    public IIIIllIllIIlIlIIllllIIlIl lIIIlllIlIlllIIIIIIIIIlII() {
        return this.IlIIllIIIlllIIIIlIIIIlIll;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof Entity && ((Entity)o).lIIIIIIIIIlIllIIllIlIIlIl == this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public int hashCode() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    protected void IIIIlIIIlllllllllIlllIlll() {
        if (this.lIIlllIIlIlllllllllIIIIIl != null) {
            while (this.IllIlIIIIlllIIllIIlllIIlI > 0.0) {
                this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
                if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII).isEmpty()) {
                    break;
                }
                ++this.IllIlIIIIlllIIllIIlllIIlI;
            }
            final double illIIlIIlllllIllIIIlllIII = 0.0;
            this.IlllIIlllIIIIllIIllllIlIl = illIIlIIlllllIllIIIlllIII;
            this.lIlIlIllIIIIIIIIllllIIllI = illIIlIIlllllIllIIIlllIII;
            this.IllIIlIIlllllIllIIIlllIII = illIIlIIlllllIllIIIlllIII;
            this.IllIIlllIllIlIllIlIIIIIII = 0.0f;
        }
    }
    
    public void IlIllllIIIlIllllIIIIIllII() {
        this.IIllIlIllIlIllIIlIllIlIII = true;
    }
    
    protected void IIIIllIIllIIIIllIllIIIlIl(final float ilIIlIIlIllIIIIllIIllIlIl, final float llllIIIIlIlIllIIIllllIIll) {
        if (ilIIlIIlIllIIIIllIIllIlIl != this.IlIIlIIlIllIIIIllIIllIlIl || llllIIIIlIlIllIIIllllIIll != this.llllIIIIlIlIllIIIllllIIll) {
            final float ilIIlIIlIllIIIIllIIllIlIl2 = this.IlIIlIIlIllIIIIllIIllIlIl;
            this.IlIIlIIlIllIIIIllIIllIlIl = ilIIlIIlIllIIIIllIIllIlIl;
            this.llllIIIIlIlIllIIIllllIIll = llllIIIIlIlIllIIIllllIIll;
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl = this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI + this.IlIIlIIlIllIIIIllIIllIlIl;
            this.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl = this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI + this.IlIIlIIlIllIIIIllIIllIlIl;
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.llllIIIIlIlIllIIIllllIIll;
            if (this.IlIIlIIlIllIIIIllIIllIlIl > ilIIlIIlIllIIIIllIIllIlIl2 && !this.IIIIllIIllIIIIllIllIIIlIl && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                this.IIIIllIIllIIIIllIllIIIlIl(ilIIlIIlIllIIIIllIIllIlIl2 - this.IlIIlIIlIllIIIIllIIllIlIl, 0.0, ilIIlIIlIllIIIIllIIllIlIl2 - this.IlIIlIIlIllIIIIllIIllIlIl);
            }
        }
        final float n = ilIIlIIlIllIIIIllIIllIlIl % 2.0f;
        if (n < 0.2957746386528015 * 1.2678571824415212) {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        else if (n < 0.6340206481658117 * 1.1829267740249634) {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        else if (n < 1.0) {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.IlllIIIlIlllIllIlIIlllIlI;
        }
        else if (n < 4.6032610604352975 * 0.29870128631591797) {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.IIIIllIlIIIllIlllIlllllIl;
        }
        else if (n < 1.4318181973350936 * 1.2222222089767456) {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.IIIIllIIllIIIIllIllIIIlIl;
        }
        else {
            this.IIlIlIlllIllIIlIllIIlIIlI = IllllllllIIlIlIIIlllIlIII.IlIlIIIlllIIIlIlllIlIllIl;
        }
    }
    
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n, final float n2) {
        this.IllllIllllIlIIIlIIIllllll = n % 360;
        this.IllIIlllIllIlIllIlIIIIIII = n2 % 360;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final double iiIlIIlIlIIIlllIIlIllllll, final double illIlIIIIlllIIllIIlllIIlI, final double illIlIlIllllIlIIllllIIlll) {
        this.IIIlIIlIlIIIlllIIlIllllll = iiIlIIlIlIIIlllIIlIllllll;
        this.IllIlIIIIlllIIllIIlllIIlI = illIlIIIIlllIIllIIlllIIlI;
        this.IllIlIlIllllIlIIllllIIlll = illIlIlIllllIlIIllllIIlll;
        final float n = this.IlIIlIIlIllIIIIllIIllIlIl / 2.0f;
        this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(iiIlIIlIlIIIlllIIlIllllll - n, illIlIIIIlllIIllIIlllIIlI - this.lIlIllIlIlIIIllllIlIllIll + this.IIIIIlIllIllIlIIllIIlIllI, illIlIlIllllIlIIllllIIlll - n, iiIlIIlIlIIIlllIIlIllllll + n, illIlIIIIlllIIllIIlllIIlI - this.lIlIllIlIlIIIllllIlIllIll + this.IIIIIlIllIllIlIIllIIlIllI + this.llllIIIIlIlIllIIIllllIIll, illIlIlIllllIlIIllllIIlll + n);
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final float n, final float n2) {
        final float illIIlllIllIlIllIlIIIIIII = this.IllIIlllIllIlIllIlIIIIIII;
        final float illllIllllIlIIIlIIIllllll = this.IllllIllllIlIIIlIIIllllll;
        this.IllllIllllIlIIIlIIIllllll += (float)(n * (0.9080459475517273 * 0.16518987877698244));
        this.IllIIlllIllIlIllIlIIIIIII -= (float)(n2 * (0.1363636334080342 * 1.100000023841858));
        if (this.IllIIlllIllIlIllIlIIIIIII < -90) {
            this.IllIIlllIllIlIllIlIIIIIII = -90;
        }
        if (this.IllIIlllIllIlIllIlIIIIIII > 90) {
            this.IllIIlllIllIlIllIlIIIIIII = 90;
        }
        this.IIlIIllIIIllllIIlllIllIIl += this.IllIIlllIllIlIllIlIIIIIII - illIIlllIllIlIllIlIIIIIII;
        this.IlIlIIIlllllIIIlIlIlIllII += this.IllllIllllIlIIIlIIIllllll - illllIllllIlIIIlIIIllllll;
    }
    
    public void x_() {
        this.IlIIIIllIIIIIlllIIlIIlllI();
    }
    
    public void IlIIIIllIIIIIlllIIlIIlllI() {
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("entityBaseTick");
        if (this.IlIIlIIIIlIIIIllllIIlIllI != null && this.IlIIlIIIIlIIIIllllIIlIllI.IIllIlIllIlIllIIlIllIlIII) {
            this.IlIIlIIIIlIIIIllllIIlIllI = null;
        }
        this.IIlIlIIlIIIlIlllllIIlIIlI = this.lIIIlllIIIlIIIIIlIIIIIIII;
        this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
        this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
        this.IIlIIllIIIllllIIlllIllIIl = this.IllIIlllIllIlIllIlIIIIIII;
        this.IlIlIIIlllllIIIlIlIlIllII = this.IllllIllllIlIIIlIIIllllll;
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.lIIlllIIlIlllllllllIIIIIl instanceof IllllIllIIlllllIIlIIllIlI) {
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("portal");
            final llllIlIlllllIIlIIllllIIII llIlIlIllIlIIlIlllIllIIlI = ((IllllIllIIlllllIIlIIllIlI)this.lIIlllIIlIlllllllllIIIIIl).llIlIlIllIlIIlIlllIllIIlI();
            final int llIlIlIllIlIIlIlllIllIIlI2 = this.llIlIlIllIlIIlIlllIllIIlI();
            if (this.IlIllIllIllIllIllllIIIlII) {
                if (llIlIlIllIlIIlIlllIllIIlI.IIIIIIlIlIlIllllllIlllIlI()) {
                    if (this.IlIIlIIIIlIIIIllllIIlIllI == null && this.lllIllIllIlIllIlIIllllIIl++ >= llIlIlIllIlIIlIlllIllIIlI2) {
                        this.lllIllIllIlIllIlIIllllIIl = llIlIlIllIlIIlIlllIllIIlI2;
                        this.IIlIlllllIIIlIIllIllIlIlI = this.IlIIlllIlIIIlIIIlIlIlIlIl();
                        int n;
                        if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI == -1) {
                            n = 0;
                        }
                        else {
                            n = -1;
                        }
                        this.lIIIIllIIlIlIllIIIlIllIlI(n);
                    }
                    this.IlIllIllIllIllIllllIIIlII = false;
                }
            }
            else {
                if (this.lllIllIllIlIllIlIIllllIIl > 0) {
                    this.lllIllIllIlIllIlIIllllIIl -= 4;
                }
                if (this.lllIllIllIlIllIlIIllllIIl < 0) {
                    this.lllIllIllIlIllIlIIllllIIl = 0;
                }
            }
            if (this.IIlIlllllIIIlIIllIllIlIlI > 0) {
                --this.IIlIlllllIIIlIIllIllIlIlI;
            }
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        }
        if (this.IllIIIIllllllIlllllIlIlll() && !this.lIIlIIIIIIIIllIIllIIlllIl()) {
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - 1.5800000070631504 * 0.1265822798013687 - this.lIlIllIlIlIIIllllIlIllIll);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
            final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
            if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("blockcrack_" + IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(block) + "_" + this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3), this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.24390244469764627 * 2.049999952316284) * this.IlIIlIIlIllIIIIllIIllIlIl, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 0.07261904617623681 * 1.377049207687378, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.19565217188490813 * 2.555555582046509) * this.IlIIlIIlIllIIIIllIIllIlIl, -this.IllIIlIIlllllIllIIIlllIII * 4, 3.1184209621410814 * 0.4810126721858978, -this.IlllIIlllIIIIllIIllllIlIl * 4);
            }
        }
        this.IllllllIllllIIlllIllllllI();
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            this.IIIIllIlIIIllIlllIlllllIl = 0;
        }
        else if (this.IIIIllIlIIIllIlllIlllllIl > 0) {
            if (this.IIlIlllIllIlIlIIIIIlllIll) {
                this.IIIIllIlIIIllIlllIlllllIl -= 4;
                if (this.IIIIllIlIIIllIlllIlllllIl < 0) {
                    this.IIIIllIlIIIllIlllIlllllIl = 0;
                }
            }
            else {
                if (this.IIIIllIlIIIllIlllIlllllIl % 20 == 0) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIIIIIIlIllIIllIlIIlIl, 1.0f);
                }
                --this.IIIIllIlIIIllIlllIlllllIl;
            }
        }
        if (this.IlIlllIllIlIllIlllIlllIll()) {
            this.llIlIlIlllIlllllIIIllIIll();
            this.IllllllIllllIIlllIllllllI *= 2.4666667f * 0.2027027f;
        }
        if (this.IllIlIIIIlllIIllIIlllIIlI < -64) {
            this.lIlIllIlIlIIIllllIlIllIll();
        }
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0, this.IIIIllIlIIIllIlllIlllllIl > 0);
        }
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
    }
    
    public int llIlIlIllIlIIlIlllIllIIlI() {
        return 0;
    }
    
    protected void llIlIlIlllIlllllIIIllIIll() {
        if (!this.IIlIlllIllIlIlIIIIIlllIll) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlllIIIlIlllIllIlIIlllIlI, 4);
            this.IIIIllIIllIIIIllIllIIIlIl(15);
        }
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final int n) {
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIllIIIlIIIIlIlIlIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, n * 20);
        if (this.IIIIllIlIIIllIlllIlllllIl < liiiIlIIllIIlIIlIIIlIIllI) {
            this.IIIIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI;
        }
    }
    
    public void IIllIlIllIlIllIIlIllIlIII() {
        this.IIIIllIlIIIllIlllIlllllIl = 0;
    }
    
    protected void lIlIllIlIlIIIllllIlIllIll() {
        this.IlIllllIIIlIllllIIIIIllII();
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final double n, final double n2, final double n3) {
        final IlIllIIlIlIllIlIllllllllI illlIIIlIlllIllIlIIlllIlI = this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, illlIIIlIlllIllIlIIlllIlI).isEmpty() && !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(illlIIIlIlllIllIlIIlllIlI);
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(double n, double n2, double n3) {
        if (this.lllIIllllIIlIlIlIlIIIlIII) {
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(n, n2, n3);
            this.IIIlIIlIlIIIlllIIlIllllll = (this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI + this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl) / 2;
            this.IllIlIIIIlllIIllIIlllIIlI = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.lIlIllIlIlIIIllllIlIllIll - this.IIIIIlIllIllIlIIllIIlIllI;
            this.IllIlIlIllllIlIIllllIIlll = (this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI + this.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl) / 2;
        }
        else {
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("move");
            this.IIIIIlIllIllIlIIllIIlIllI *= 0.25531915f * 1.5666667f;
            final double iiIlIIlIlIIIlllIIlIllllll = this.IIIlIIlIlIIIlllIIlIllllll;
            final double illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
            final double illIlIlIllllIlIIllllIIlll = this.IllIlIlIllllIlIIllllIIlll;
            if (this.llIlIlIllIlIIlIlllIllIIlI) {
                this.llIlIlIllIlIIlIlllIllIIlI = false;
                n *= 0.22321428476395655 * 1.1200000047683716;
                n2 *= 12.0 * 0.004166666728754838;
                n3 *= 1.4166666314833702 * 0.1764705926179886;
                this.IllIIlIIlllllIllIIIlllIII = 0.0;
                this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
                this.IlllIIlllIIIIllIIllllIlIl = 0.0;
            }
            double n4 = n;
            final double n5 = n2;
            double n6 = n3;
            final IlIllIIlIlIllIlIllllllllI liiiiiiiiIlIllIIllIlIIlIl = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl();
            final boolean b = this.lIIIIlllIIlIlllllIlIllIII && this.lIlIlIllIIIIIIIIllllIIllI() && this instanceof lIllIIIIlIIlIllIIIlIlIlll;
            if (b) {
                final double n7 = 0.37362638115882874 * 0.1338235267138296;
                while (n != 0.0 && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(n, -1, 0.0)).isEmpty()) {
                    if (n < n7 && n >= -n7) {
                        n = 0.0;
                    }
                    else if (n > 0.0) {
                        n -= n7;
                    }
                    else {
                        n += n7;
                    }
                    n4 = n;
                }
                while (n3 != 0.0 && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(0.0, -1, n3)).isEmpty()) {
                    if (n3 < n7 && n3 >= -n7) {
                        n3 = 0.0;
                    }
                    else if (n3 > 0.0) {
                        n3 -= n7;
                    }
                    else {
                        n3 += n7;
                    }
                    n6 = n3;
                }
                while (n != 0.0 && n3 != 0.0 && this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(n, -1, n3)).isEmpty()) {
                    if (n < n7 && n >= -n7) {
                        n = 0.0;
                    }
                    else if (n > 0.0) {
                        n -= n7;
                    }
                    else {
                        n += n7;
                    }
                    if (n3 < n7 && n3 >= -n7) {
                        n3 = 0.0;
                    }
                    else if (n3 > 0.0) {
                        n3 -= n7;
                    }
                    else {
                        n3 += n7;
                    }
                    n4 = n;
                    n6 = n3;
                }
            }
            final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3));
            for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                n2 = liiiIlIIllIIlIIlIIIlIIllI.get(i).lIIIIIIIIIlIllIIllIlIIlIl(this.lllIlIIllllIIIIlIllIlIIII, n2);
            }
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(0.0, n2, 0.0);
            if (!this.llIlIlIlllIlllllIIIllIIll && n5 != n2) {
                n3 = 0.0;
                n2 = 0.0;
                n = 0.0;
            }
            final boolean b2 = this.lIIIIlllIIlIlllllIlIllIII || (n5 != n2 && n5 < 0.0);
            for (int j = 0; j < liiiIlIIllIIlIIlIIIlIIllI.size(); ++j) {
                n = liiiIlIIllIIlIIlIIIlIIllI.get(j).lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII, n);
            }
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(n, 0.0, 0.0);
            if (!this.llIlIlIlllIlllllIIIllIIll && n4 != n) {
                n3 = 0.0;
                n2 = 0.0;
                n = 0.0;
            }
            for (int k = 0; k < liiiIlIIllIIlIIlIIIlIIllI.size(); ++k) {
                n3 = liiiIlIIllIIlIIlIIIlIIllI.get(k).IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII, n3);
            }
            this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(0.0, 0.0, n3);
            if (!this.llIlIlIlllIlllllIIIllIIll && n6 != n3) {
                n3 = 0.0;
                n2 = 0.0;
                n = 0.0;
            }
            if (this.lIIllIIllllllIIlllIlllIIl > 0.0f && b2 && (b || this.IIIIIlIllIllIlIIllIIlIllI < 0.04117647f * 1.2142857f) && (n4 != n || n6 != n3)) {
                final double n8 = n;
                final double n9 = n2;
                final double n10 = n3;
                n = n4;
                n2 = this.lIIllIIllllllIIlllIlllIIl;
                n3 = n6;
                final IlIllIIlIlIllIlIllllllllI liiiiiiiiIlIllIIllIlIIlIl2 = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl();
                this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(liiiiiiiiIlIllIIllIlIIlIl);
                final List liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(n4, n2, n6));
                for (int l = 0; l < liiiIlIIllIIlIIlIIIlIIllI2.size(); ++l) {
                    n2 = liiiIlIIllIIlIIlIIIlIIllI2.get(l).lIIIIIIIIIlIllIIllIlIIlIl(this.lllIlIIllllIIIIlIllIlIIII, n2);
                }
                this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(0.0, n2, 0.0);
                if (!this.llIlIlIlllIlllllIIIllIIll && n5 != n2) {
                    n3 = 0.0;
                    n2 = 0.0;
                    n = 0.0;
                }
                for (int n11 = 0; n11 < liiiIlIIllIIlIIlIIIlIIllI2.size(); ++n11) {
                    n = liiiIlIIllIIlIIlIIIlIIllI2.get(n11).lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII, n);
                }
                this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(n, 0.0, 0.0);
                if (!this.llIlIlIlllIlllllIIIllIIll && n4 != n) {
                    n3 = 0.0;
                    n2 = 0.0;
                    n = 0.0;
                }
                for (int n12 = 0; n12 < liiiIlIIllIIlIIlIIIlIIllI2.size(); ++n12) {
                    n3 = liiiIlIIllIIlIIlIIIlIIllI2.get(n12).IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII, n3);
                }
                this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(0.0, 0.0, n3);
                if (!this.llIlIlIlllIlllllIIIllIIll && n6 != n3) {
                    n3 = 0.0;
                    n2 = 0.0;
                    n = 0.0;
                }
                if (!this.llIlIlIlllIlllllIIIllIIll && n5 != n2) {
                    n3 = 0.0;
                    n2 = 0.0;
                    n = 0.0;
                }
                else {
                    n2 = -this.lIIllIIllllllIIlllIlllIIl;
                    for (int n13 = 0; n13 < liiiIlIIllIIlIIlIIIlIIllI2.size(); ++n13) {
                        n2 = liiiIlIIllIIlIIlIIIlIIllI2.get(n13).lIIIIIIIIIlIllIIllIlIIlIl(this.lllIlIIllllIIIIlIllIlIIII, n2);
                    }
                    this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl(0.0, n2, 0.0);
                }
                if (n8 * n8 + n10 * n10 >= n * n + n3 * n3) {
                    n = n8;
                    n2 = n9;
                    n3 = n10;
                    this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(liiiiiiiiIlIllIIllIlIIlIl2);
                }
            }
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("rest");
            this.IIIlIIlIlIIIlllIIlIllllll = (this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI + this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl) / 2;
            this.IllIlIIIIlllIIllIIlllIIlI = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.lIlIllIlIlIIIllllIlIllIll - this.IIIIIlIllIllIlIIllIIlIllI;
            this.IllIlIlIllllIlIIllllIIlll = (this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI + this.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl) / 2;
            this.lIIIlllIlIlllIIIIIIIIIlII = (n4 != n || n6 != n3);
            this.IIIIlIIIlllllllllIlllIlll = (n5 != n2);
            this.lIIIIlllIIlIlllllIlIllIII = (n5 != n2 && n5 < 0.0);
            this.IlIllllIIIlIllllIIIIIllII = (this.lIIIlllIlIlllIIIIIIIIIlII || this.IIIIlIIIlllllllllIlllIlll);
            this.lIIIIlIIllIIlIIlIIIlIIllI(n2, this.lIIIIlllIIlIlllllIlIllIII);
            if (n4 != n) {
                this.IllIIlIIlllllIllIIIlllIII = 0.0;
            }
            if (n5 != n2) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
            }
            if (n6 != n3) {
                this.IlllIIlllIIIIllIIllllIlIl = 0.0;
            }
            final double n14 = this.IIIlIIlIlIIIlllIIlIllllll - iiIlIIlIlIIIlllIIlIllllll;
            double n15 = this.IllIlIIIIlllIIllIIlllIIlI - illIlIIIIlllIIllIIlllIIlI;
            final double n16 = this.IllIlIlIllllIlIIllllIIlll - illIlIlIllllIlIIllllIIlll;
            if (this.IIIllIllIlIlllllllIlIlIII() && !b && this.IlIIlIIIIlIIIIllllIIlIllI == null) {
                final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
                final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - 3.800000028312206 * 0.05263157933950424 - this.lIlIllIlIlIIIllllIlIllIll);
                final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
                IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
                final int ilIlllIIIIllIllllIllIIlIl = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3).IlIlllIIIIllIllllIllIIlIl();
                if (ilIlllIIIIllIllllIllIIlIl == 11 || ilIlllIIIIllIllllIllIIlIl == 32 || ilIlllIIIIllIllllIllIIlIl == 21) {
                    illlllllIlllIIllllIIlIll = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3);
                }
                if (illlllllIlllIIllllIIlIll != IllllllIllIIlllIllIIlIIll.llIIIlIlIIlIlIIlIllIllIll) {
                    n15 = 0.0;
                }
                this.lIIIlllIIIlIIIIIlIIIIIIII += (float)(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n14 * n14 + n16 * n16) * (0.27692306676559936 * 2.1666667461395264));
                this.lIIlIIIIIIIIllIIllIIlllIl += (float)(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n14 * n14 + n15 * n15 + n16 * n16) * (0.30909091802339606 * 1.941176414489746));
                if (this.lIIlIIIIIIIIllIIllIIlllIl > this.IlllIIIlIlllIllIlIIlllIlI && illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                    this.IlllIIIlIlllIllIlIIlllIlI = (int)this.lIIlIIIIIIIIllIIllIIlllIl + 1;
                    if (this.lIIlIIIIIIIIllIIllIIlllIl()) {
                        float n17 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII * (0.4675324559211731 * 0.42777779477613986) + this.lIlIlIllIIIIIIIIllllIIllI * this.lIlIlIllIIIIIIIIllllIIllI + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl * (1.0967742204666138 * 0.18235293941823674)) * (17.4f * 0.020114943f);
                        if (n17 > 1.0f) {
                            n17 = 1.0f;
                        }
                        this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIIlIIlIllIIIIllIIllIlIl(), n17, 1.0f + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (1.24f * 0.32258064f));
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlllllIlllIIllllIIlIll);
                    illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, this);
                }
            }
            try {
                this.llllIIIIlIlIllIIIllllIIll();
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Checking entity block collision");
                this.lIIIIlIIllIIlIIlIIIlIIllI(crashReport.makeCategory("Entity being checked for collision"));
                throw new ReportedException(crashReport);
            }
            final boolean liiIlllIIIlIIIIIlIIIIIIII = this.lIIIlllIIIlIIIIIlIIIIIIII();
            if (this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl(this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl(0.002599999953508378 * 0.38461539149284363, 0.375 * 0.0026666666666666666, 0.0010243902736870333 * 0.976190447807312))) {
                this.IlIlIIIlllIIIlIlllIlIllIl(1);
                if (!liiIlllIIIlIIIIIlIIIIIIII) {
                    ++this.IIIIllIlIIIllIlllIlllllIl;
                    if (this.IIIIllIlIIIllIlllIlllllIl == 0) {
                        this.IIIIllIIllIIIIllIllIIIlIl(8);
                    }
                }
            }
            else if (this.IIIIllIlIIIllIlllIlllllIl <= 0) {
                this.IIIIllIlIIIllIlllIlllllIl = -this.IllllllllIlIIIIIIIIllIIII;
            }
            if (liiIlllIIIlIIIIIlIIIIIIII && this.IIIIllIlIIIllIlllIlllllIl > 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI("random.fizz", 1.6341463f * 0.4283582f, 0.7242105f * 2.2093024f + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.08988765f * 4.45f));
                this.IIIIllIlIIIllIlllIlllllIl = -this.IllllllllIlIIIIIIIIllIIII;
            }
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        }
    }
    
    protected String IlIIlIIlIllIIIIllIIllIlIl() {
        return "game.neutral.swim";
    }
    
    protected void llllIIIIlIlIllIIIllllIIll() {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI + 0.0012432432632711009 * 0.804347813129425);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 0.004136363627958642 * 0.24175824224948883);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI + 0.001 * 1.0);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl - 1.399999976158142 * 7.142857264499277E-4);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl - 1.2790697390740476E-4 * 7.818181991577148);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl - 0.0017037037638806861 * 0.5869565010070801);
        if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6)) {
            for (int i = illlIIIlIlllIllIlIIlllIlI; i <= illlIIIlIlllIllIlIIlllIlI4; ++i) {
                for (int j = illlIIIlIlllIllIlIIlllIlI2; j <= illlIIIlIlllIllIlIIlllIlI5; ++j) {
                    for (int k = illlIIIlIlllIllIlIIlllIlI3; k <= illlIIIlIlllIllIlIIlllIlI6; ++k) {
                        final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(i, j, k);
                        try {
                            block.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, i, j, k, this);
                        }
                        catch (Throwable t) {
                            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Colliding entity with block");
                            lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(crashReport.makeCategory("Block being collided with"), i, j, k, block, this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(i, j, k));
                            throw new ReportedException(crashReport);
                        }
                    }
                }
            }
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        final lIIIIIlIllIIIIlllIIlIIlIl illlIIlllIIIIllIIllllIlIl = illlllllIlllIIllllIIlIll.IlllIIlllIIIIllIIllllIlIl;
        if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(n, n2 + 1, n3) == IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll) {
            final lIIIIIlIllIIIIlllIIlIIlIl illlIIlllIIIIllIIllllIlIl2 = IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll.IlllIIlllIIIIllIIllllIlIl;
            this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIlllIIIIllIIllllIlIl2.IIIIllIIllIIIIllIllIIIlIl(), illlIIlllIIIIllIIllllIlIl2.IlllIIIlIlllIllIlIIlllIlI() * (0.5945946f * 0.25227273f), illlIIlllIIIIllIIllllIlIl2.IIIIllIlIIIllIlllIlllllIl());
        }
        else if (!illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl().lIIIIlIIllIIlIIlIIIlIIllI()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIlllIIIIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl(), illlIIlllIIIIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI() * (0.050625004f * 2.9629629f), illlIIlllIIIIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl());
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final float n, final float n2) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, s, n, n2);
    }
    
    protected boolean IIIllIllIlIlllllllIlIlIII() {
        return true;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final boolean b) {
        if (b) {
            if (this.IllllllIllllIIlllIllllllI > 0.0f) {
                this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllllIllllIIlllIllllllI);
                this.IllllllIllllIIlllIllllllI = 0.0f;
            }
        }
        else if (n < 0.0) {
            this.IllllllIllllIIlllIllllllI -= (float)n;
        }
    }
    
    public IlIllIIlIlIllIlIllllllllI IlllIllIlIIIIlIIlIIllIIIl() {
        return null;
    }
    
    protected void IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        if (!this.IIlIlllIllIlIlIIIIIlllIll) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI, (float)n);
        }
    }
    
    public final boolean IIlIlIIlIIIlIlllllIIlIIlI() {
        return this.IIlIlllIllIlIlIIIIIlllIll;
    }
    
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        if (this.IllIllIIIlIIlllIIIllIllII != null) {
            this.IllIllIIIlIIlllIIIllIllII.IlIlIIIlllIIIlIlllIlIllIl(n);
        }
    }
    
    public boolean lIIIlllIIIlIIIIIlIIIIIIII() {
        return this.lIIlIlIIlIlIlIIlIlIlllIIl || this.lIIlllIIlIlllllllllIIIIIl.lIIlIIllIIIIIlIllIIIIllII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)) || this.lIIlllIIlIlllllllllIIIIIl.lIIlIIllIIIIIlIllIIIIllII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI + this.llllIIIIlIlIllIIIllllIIll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll));
    }
    
    public boolean lIIlIIIIIIIIllIIllIIlllIl() {
        return this.lIIlIlIIlIlIlIIlIlIlllIIl;
    }
    
    public boolean IllllllIllllIIlllIllllllI() {
        if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(0.0, -0.2999999955296518 * 1.3333333730697632, 0.0).IIIIllIIllIIIIllIllIIIlIl(0.004470588313667008 * 0.22368420660495758, 0.3132530152797699 * 0.0031923076593752446, 18.399999618530273 * 5.434782721369841E-5), Material.IllIIIIIIIlIlIllllIIllIII, this)) {
            if (!this.lIIlIlIIlIlIlIIlIlIlllIIl && !this.IIIIllIIllIIIIllIllIIIlIl) {
                float n = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII * (1.7804877758026123 * 0.11232877063145001) + this.lIlIlIllIIIIIIIIllllIIllI * this.lIlIlIllIIIIIIIIllllIIllI + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl * (0.34939759969711304 * 0.5724137863385693)) * (2.5833333f * 0.077419356f);
                if (n > 1.0f) {
                    n = 1.0f;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIlIlIIIlIIllllllllIIlllI(), n, 1.0f + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (6.818182f * 0.058666665f));
                final float n2 = (float)MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl);
                for (int n3 = 0; n3 < 1.0f + this.IlIIlIIlIllIIIIllIIllIlIl * 20; ++n3) {
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("bubble", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 2.0f - 1.0f) * this.IlIIlIIlIllIIIIllIIllIlIl, n2 + 1.0f, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 2.0f - 1.0f) * this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.13513513f * 1.4800001f), this.IlllIIlllIIIIllIIllllIlIl);
                }
                for (int n4 = 0; n4 < 1.0f + this.IlIIlIIlIllIIIIllIIllIlIl * 20; ++n4) {
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("splash", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 2.0f - 1.0f) * this.IlIIlIIlIllIIIIllIIllIlIl, n2 + 1.0f, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 2.0f - 1.0f) * this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
                }
            }
            this.IllllllIllllIIlllIllllllI = 0.0f;
            this.lIIlIlIIlIlIlIIlIlIlllIIl = true;
            this.IIIIllIlIIIllIlllIlllllIl = 0;
        }
        else {
            this.lIIlIlIIlIlIlIIlIlIlllIIl = false;
        }
        return this.lIIlIlIIlIlIlIIlIlIlllIIl;
    }
    
    protected String lIlIlIIIlIIllllllllIIlllI() {
        return "game.neutral.swim.splash";
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final Material material) {
        final double n = this.IllIlIIIIlllIIllIIlllIIlI + this.lIIlIlIllIIlIIIlIIIlllIII();
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
        final int iiiIllIlIIIllIlllIlllllIl = MathHelper.IIIIllIlIIIllIlllIlllllIl((float)MathHelper.IlllIIIlIlllIllIlIIlllIlI(n));
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
        return this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl, illlIIIlIlllIllIlIIlllIlI2).IlIlIIIlllIIIlIlllIlIllIl() == material && n < iiiIllIlIIIllIlllIlllllIl + 1 - (lllIlIIIIIllllIIIlIIlIIIl.IllIIIIIIIlIlIllllIIllIII(this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl, illlIIIlIlllIllIlIIlllIlI2)) - 2.3333333f * 0.04761905f);
    }
    
    public float lIIlIlIllIIlIIIlIIIlllIII() {
        return 0.0f;
    }
    
    public boolean IlIlllIllIlIllIlllIlllIll() {
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(-0.17234042460303764 * 0.5802469253540039, 1.8529411554336548 * -0.21587302154063825, 2.046511650085449 * -0.04886363656221589), Material.lIIIIllIIlIlIllIIIlIllIlI);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(float n, float n2, final float n3) {
        final float n4 = n * n + n2 * n2;
        if (n4 >= 3.375f * 2.962963E-5f) {
            float illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n4);
            if (illlIIIlIlllIllIlIIlllIlI < 1.0f) {
                illlIIIlIlllIllIlIIlllIlI = 1.0f;
            }
            final float n5 = n3 / illlIIIlIlllIllIlIIlllIlI;
            n *= n5;
            n2 *= n5;
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll * (0.5625f * 5.585054f) / 180);
            final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll * (5.0265484f * 0.625f) / 180);
            this.IllIIlIIlllllIllIIIlllIII += n * liiiiiiiiIlIllIIllIlIIlIl - n2 * liiiIlIIllIIlIIlIIIlIIllI;
            this.IlllIIlllIIIIllIIllllIlIl += n2 * liiiiiiiiIlIllIIllIlIIlIl + n * liiiIlIIllIIlIIlIIIlIIllI;
        }
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
        if (this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI, 0, illlIIIlIlllIllIlIIlllIlI2)) {
            return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - this.lIlIllIlIlIIIllllIlIllIll + (this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl - this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) * (1.7659459871959313 * 0.3737373650074005)), illlIIIlIlllIllIlIIlllIlI2, 0);
        }
        return 0;
    }
    
    public float lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
        if (this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI, 0, illlIIIlIlllIllIlIIlllIlI2)) {
            return this.lIIlllIIlIlllllllllIIIIIl.llIIlllIIIIlllIllIlIlllIl(illlIIIlIlllIllIlIIlllIlI, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - this.lIlIllIlIlIIIllllIlIllIll + (this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl - this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) * (0.4678481069136041 * 1.4107142686843872)), illlIIIlIlllIllIlIIlllIlI2);
        }
        return 0.0f;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI liIlllIIlIlllllllllIIIIIl) {
        this.lIIlllIIlIlllllllllIIIIIl = liIlllIIlIlllllllllIIIIIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final float n4, final float n5) {
        this.IIIlIIlIlIIIlllIIlIllllll = n;
        this.lIllIllIlIIllIllIlIlIIlIl = n;
        this.IllIlIIIIlllIIllIIlllIIlI = n2;
        this.llIlIIIllIIIIlllIlIIIIIlI = n2;
        this.IllIlIlIllllIlIIllllIIlll = n3;
        this.lIllIlIlllIIlIIllIIlIIlII = n3;
        this.IllllIllllIlIIIlIIIllllll = n4;
        this.IlIlIIIlllllIIIlIlIlIllII = n4;
        this.IllIIlllIllIlIllIlIIIIIII = n5;
        this.IIlIIllIIIllllIIlllIllIIl = n5;
        this.IIIIIlIllIllIlIIllIIlIllI = 0.0f;
        final double n6 = this.IlIlIIIlllllIIIlIlIlIllII - n4;
        if (n6 < -180) {
            this.IlIlIIIlllllIIIlIlIlIllII += 360;
        }
        if (n6 >= 180) {
            this.IlIlIIIlllllIIIlIlIlIllII -= 360;
        }
        this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        this.IlIlIIIlllIIIlIlllIlIllIl(n4, n5);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final double lIlIlIIIlIIllllllllIIlllI, final double n, final double llIIIllIIllllIlIlIlIlIIll, final float illllIllllIlIIIlIIIllllll, final float illIIlllIllIlIllIlIIIIIII) {
        this.IIIlIIlIlIIIlllIIlIllllll = lIlIlIIIlIIllllllllIIlllI;
        this.lIllIllIlIIllIllIlIlIIlIl = lIlIlIIIlIIllllllllIIlllI;
        this.lIlIlIIIlIIllllllllIIlllI = lIlIlIIIlIIllllllllIIlllI;
        final double ilIlllIllIlIllIlllIlllIll = n + this.lIlIllIlIlIIIllllIlIllIll;
        this.IllIlIIIIlllIIllIIlllIIlI = ilIlllIllIlIllIlllIlllIll;
        this.llIlIIIllIIIIlllIlIIIIIlI = ilIlllIllIlIllIlllIlllIll;
        this.IlIlllIllIlIllIlllIlllIll = ilIlllIllIlIllIlllIlllIll;
        this.IllIlIlIllllIlIIllllIIlll = llIIIllIIllllIlIlIlIlIIll;
        this.lIllIlIlllIIlIIllIIlIIlII = llIIIllIIllllIlIlIlIlIIll;
        this.llIIIllIIllllIlIlIlIlIIll = llIIIllIIllllIlIlIlIlIIll;
        this.IllllIllllIlIIIlIIIllllll = illllIllllIlIIIlIIIllllll;
        this.IllIIlllIllIlIllIlIIIIIII = illIIlllIllIlIllIlIIIIIII;
        this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
    }
    
    public float IIIIllIlIIIllIlllIlllllIl(final Entity entity) {
        final float n = (float)(this.IIIlIIlIlIIIlllIIlIllllll - entity.IIIlIIlIlIIIlllIIlIllllll);
        final float n2 = (float)(this.IllIlIIIIlllIIllIIlllIIlI - entity.IllIlIIIIlllIIllIIlllIIlI);
        final float n3 = (float)(this.IllIlIlIllllIlIIllllIIlll - entity.IllIlIlIllllIlIIllllIIlll);
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(n * n + n2 * n2 + n3 * n3);
    }
    
    public double IlIlIIIlllIIIlIlllIlIllIl(final double n, final double n2, final double n3) {
        final double n4 = this.IIIlIIlIlIIIlllIIlIllllll - n;
        final double n5 = this.IllIlIIIIlllIIllIIlllIIlI - n2;
        final double n6 = this.IllIlIlIllllIlIIllllIIlll - n3;
        return n4 * n4 + n5 * n5 + n6 * n6;
    }
    
    public double IIIllIllIlIlllllllIlIlIII(final double n, final double n2, final double n3) {
        final double n4 = this.IIIlIIlIlIIIlllIIlIllllll - n;
        final double n5 = this.IllIlIIIIlllIIllIIlllIIlI - n2;
        final double n6 = this.IllIlIlIllllIlIIllllIIlll - n3;
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n4 * n4 + n5 * n5 + n6 * n6);
    }
    
    public double IIIIllIIllIIIIllIllIIIlIl(final Entity entity) {
        final double n = this.IIIlIIlIlIIIlllIIlIllllll - entity.IIIlIIlIlIIIlllIIlIllllll;
        final double n2 = this.IllIlIIIIlllIIllIIlllIIlI - entity.IllIlIIIIlllIIllIIlllIIlI;
        final double n3 = this.IllIlIlIllllIlIIllllIIlll - entity.IllIlIlIllllIlIIllllIIlll;
        return n * n + n2 * n2 + n3 * n3;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final Entity entity) {
        if (entity.IllIllIIIlIIlllIIIllIllII != this && entity.IlIIlIIIIlIIIIllllIIlIllI != this) {
            final double n = entity.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll;
            final double n2 = entity.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll;
            final double liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
            if (liiiIlIIllIIlIIlIIIlIIllI >= 1.2328766584396362 * 0.008111111284350915) {
                final double n3 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
                final double n4 = n / n3;
                final double n5 = n2 / n3;
                double n6 = 1.0 / n3;
                if (n6 > 1.0) {
                    n6 = 1.0;
                }
                final double n7 = n4 * n6;
                final double n8 = n5 * n6;
                final double n9 = n7 * (1.2878787517547607 * 0.03882353107925109);
                final double n10 = n8 * (0.23255814611911774 * 0.2149999971166254);
                final double n11 = n9 * (1.0f - this.IlIIllIlIlIIIllIllIIlIIII);
                final double n12 = n10 * (1.0f - this.IlIIllIlIlIIIllIllIIlIIII);
                this.IllIIIIIIIlIlIllllIIllIII(-n11, 0.0, -n12);
                entity.IllIIIIIIIlIlIllllIIllIII(n11, 0.0, n12);
            }
        }
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final double n, final double n2, final double n3) {
        this.IllIIlIIlllllIllIIIlllIII += n;
        this.lIlIlIllIIIIIIIIllllIIllI += n2;
        this.IlllIIlllIIIIllIIllllIlIl += n3;
        this.IIIllllIlIIlIIIlIlIlllIII = true;
    }
    
    protected void llIIIllIIllllIlIlIlIlIIll() {
        this.IlIIIIllIIIIIlllIIlIIlllI = true;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        this.llIIIllIIllllIlIlIlIlIIll();
        return false;
    }
    
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return false;
    }
    
    public boolean isFramerateLimitBelowMax() {
        return false;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity, final int n) {
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
        final double n4 = this.IIIlIIlIlIIIlllIIlIllllll - n;
        final double n5 = this.IllIlIIIIlllIIllIIlllIIlI - n2;
        final double n6 = this.IllIlIlIllllIlIIllllIIlll - n3;
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n4 * n4 + n5 * n5 + n6 * n6);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        final double n2 = this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI() * (64 * this.lIIIIIllllIIIIlIlIIIIlIlI);
        return n < n2 * n2;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        final String lllIIllllIIlIlIlIlIIIlIII = this.lllIIllllIIlIlIlIlIIIlIII();
        if (!this.IIllIlIllIlIllIIlIllIlIII && lllIIllllIIlIlIlIlIIIlIII != null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("id", lllIIllllIIlIlIlIlIIIlIII);
            this.IIIIllIIllIIIIllIllIIIlIl(ilIIIllIIlIIlllIllllIIIIl);
            return true;
        }
        return false;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        final String lllIIllllIIlIlIlIlIIIlIII = this.lllIIllllIIlIlIlIlIIIlIII();
        if (!this.IIllIlIllIlIllIIlIllIlIII && lllIIllllIIlIlIlIlIIIlIII != null && this.IllIllIIIlIIlllIIIllIllII == null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("id", lllIIllllIIlIlIlIlIIIlIII);
            this.IIIIllIIllIIIIllIllIIIlIl(ilIIIllIIlIIlllIllllIIIIl);
            return true;
        }
        return false;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        try {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Pos", this.lIIIIlIIllIIlIIlIIIlIIllI(new double[] { this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.IIIIIlIllIllIlIIllIIlIllI, this.IllIlIlIllllIlIIllllIIlll }));
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Motion", this.lIIIIlIIllIIlIIlIIIlIIllI(new double[] { this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl }));
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Rotation", this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII));
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("FallDistance", this.IllllllIllllIIlllIllllllI);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Fire", (short)this.IIIIllIlIIIllIlllIlllllIl);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Air", (short)this.IlIllIllIllIllIllllIIIlII());
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("OnGround", this.lIIIIlllIIlIlllllIlIllIII);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Dimension", this.IIIIIIIllIllllIIlIIlllIII);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Invulnerable", this.lIIIIllIIlIlIllIIIlIllIlI);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("PortalCooldown", this.IIlIlllllIIIlIIllIllIlIlI);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("UUIDMost", this.llllIIllIIlllllIlIlIIllll().getMostSignificantBits());
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("UUIDLeast", this.llllIIllIIlllllIlIlIIllll().getLeastSignificantBits());
            this.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
            if (this.IlIIlIIIIlIIIIllllIIlIllI != null) {
                final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
                if (this.IlIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI(ilIIIllIIlIIlllIllllIIIIl2)) {
                    ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Riding", ilIIIllIIlIIlllIllllIIIIl2);
                }
            }
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Saving entity NBT");
            this.lIIIIlIIllIIlIIlIIIlIIllI(crashReport.makeCategory("Entity being saved"));
            throw new ReportedException(crashReport);
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        try {
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Pos", 6);
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI2 = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Motion", 6);
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI3 = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Rotation", 5);
            this.IllIIlIIlllllIllIIIlllIII = illlIIIlIlllIllIlIIlllIlI2.IIIIllIlIIIllIlllIlllllIl(0);
            this.lIlIlIllIIIIIIIIllllIIllI = illlIIIlIlllIllIlIIlllIlI2.IIIIllIlIIIllIlllIlllllIl(1);
            this.IlllIIlllIIIIllIIllllIlIl = illlIIIlIlllIllIlIIlllIlI2.IIIIllIlIIIllIlllIlllllIl(2);
            if (Math.abs(this.IllIIlIIlllllIllIIIlllIII) > 10) {
                this.IllIIlIIlllllIllIIIlllIII = 0.0;
            }
            if (Math.abs(this.lIlIlIllIIIIIIIIllllIIllI) > 10) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
            }
            if (Math.abs(this.IlllIIlllIIIIllIIllllIlIl) > 10) {
                this.IlllIIlllIIIIllIIllllIlIl = 0.0;
            }
            final double iiiIllIlIIIllIlllIlllllIl = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(0);
            this.IIIlIIlIlIIIlllIIlIllllll = iiiIllIlIIIllIlllIlllllIl;
            this.lIlIlIIIlIIllllllllIIlllI = iiiIllIlIIIllIlllIlllllIl;
            this.lIllIllIlIIllIllIlIlIIlIl = iiiIllIlIIIllIlllIlllllIl;
            final double iiiIllIlIIIllIlllIlllllIl2 = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(1);
            this.IllIlIIIIlllIIllIIlllIIlI = iiiIllIlIIIllIlllIlllllIl2;
            this.IlIlllIllIlIllIlllIlllIll = iiiIllIlIIIllIlllIlllllIl2;
            this.llIlIIIllIIIIlllIlIIIIIlI = iiiIllIlIIIllIlllIlllllIl2;
            final double iiiIllIlIIIllIlllIlllllIl3 = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(2);
            this.IllIlIlIllllIlIIllllIIlll = iiiIllIlIIIllIlllIlllllIl3;
            this.llIIIllIIllllIlIlIlIlIIll = iiiIllIlIIIllIlllIlllllIl3;
            this.lIllIlIlllIIlIIllIIlIIlII = iiiIllIlIIIllIlllIlllllIl3;
            final float iiiIllIIllIIIIllIllIIIlIl = illlIIIlIlllIllIlIIlllIlI3.IIIIllIIllIIIIllIllIIIlIl(0);
            this.IllllIllllIlIIIlIIIllllll = iiiIllIIllIIIIllIllIIIlIl;
            this.IlIlIIIlllllIIIlIlIlIllII = iiiIllIIllIIIIllIllIIIlIl;
            final float iiiIllIIllIIIIllIllIIIlIl2 = illlIIIlIlllIllIlIIlllIlI3.IIIIllIIllIIIIllIllIIIlIl(1);
            this.IllIIlllIllIlIllIlIIIIIII = iiiIllIIllIIIIllIllIIIlIl2;
            this.IIlIIllIIIllllIIlllIllIIl = iiiIllIIllIIIIllIllIIIlIl2;
            this.IllllllIllllIIlllIllllllI = ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("FallDistance");
            this.IIIIllIlIIIllIlllIlllllIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Fire");
            this.IllIIIIIIIlIlIllllIIllIII(ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Air"));
            this.lIIIIlllIIlIlllllIlIllIII = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("OnGround");
            this.IIIIIIIllIllllIIlIIlllIII = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Dimension");
            this.lIIIIllIIlIlIllIIIlIllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Invulnerable");
            this.IIlIlllllIIIlIIllIllIlIlI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("PortalCooldown");
            if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("UUIDMost", 4) && ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("UUIDLeast", 4)) {
                this.llllIIlIlIllIllllIIIIllll = new UUID(ilIIIllIIlIIlllIllllIIIIl.IIIllIllIlIlllllllIlIlIII("UUIDMost"), ilIIIllIIlIIlllIllllIIIIl.IIIllIllIlIlllllllIlIlIII("UUIDLeast"));
            }
            this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
            this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
            this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
            if (this.isJvm64bit()) {
                this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
            }
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Loading entity NBT");
            this.lIIIIlIIllIIlIIlIIIlIIllI(crashReport.makeCategory("Entity being loaded"));
            throw new ReportedException(crashReport);
        }
    }
    
    protected boolean isJvm64bit() {
        return true;
    }
    
    protected final String lllIIllllIIlIlIlIlIIIlIII() {
        return llIlllIlIllllIIIllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(this);
    }
    
    protected abstract void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl p0);
    
    protected abstract void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl p0);
    
    public void startGame() {
    }
    
    protected IllIlllIlIllIIIIIIllIllll lIIIIlIIllIIlIIlIIIlIIllI(final double... array) {
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
        for (int length = array.length, i = 0; i < length; ++i) {
            illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(new llIIIIIllIIIIllIlIIlIIllI(array[i]));
        }
        return illIlllIlIllIIIIIIllIllll;
    }
    
    protected IllIlllIlIllIIIIIIllIllll lIIIIlIIllIIlIIlIIIlIIllI(final float... array) {
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
        for (int length = array.length, i = 0; i < length; ++i) {
            illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(new IlIlIIIlIIllIIIlIIIllIIII(array[i]));
        }
        return illIlllIlIllIIIIIIllIllll;
    }
    
    public float llIIlllIIIIlllIllIlIlllIl() {
        return this.llllIIIIlIlIllIIIllllIIll / 2.0f;
    }
    
    public lllIIIIIlIllllIIIlllIllIl lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(liIlllIIIlIllllllIlIlIIII, n, 0.0f);
    }
    
    public lllIIIIIlIllllIIIlllIllIl lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final int n, final float n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, n, 0), n2);
    }
    
    public lllIIIIIlIllllIIIlllIllIl lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final float n) {
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl != 0 && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() != null) {
            final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl = new lllIIIIIlIllllIIIlllIllIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + n, this.IllIlIlIllllIlIIllllIIlll, lIlIlIlIlIllllIlllIIIlIlI);
            lllIIIIIlIllllIIIlllIllIl.lIIIIIIIIIlIllIIllIlIIlIl = 10;
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl);
            return lllIIIIIlIllllIIIlllIllIl;
        }
        return null;
    }
    
    public boolean IlIlllIIIIlIllIlllIlIIIll() {
        return !this.IIllIlIllIlIllIIlIllIlIII;
    }
    
    public boolean isEntityInsideOpaqueBlock() {
        for (int i = 0; i < 8; ++i) {
            if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll + ((i >> 0) % 2 - 0.5425532f * 0.92156863f) * this.IlIIlIIlIllIIIIllIIllIlIl * (1.1578947f * 0.6909091f)), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI + this.lIIlIlIllIIlIIIlIIIlllIII() + ((i >> 1) % 2 - 12.5f * 0.04f) * (0.111627914f * 0.8958333f)), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll + ((i >> 2) % 2 - 0.33333334f * 1.5f) * this.IlIIlIIlIllIIIIllIIllIlIl * (0.0969697f * 8.25f))).lIIIIllIIlIlIllIIIlIllIlI()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean b_(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return false;
    }
    
    public IlIllIIlIlIllIlIllllllllI IIIllIllIlIlllllllIlIlIII(final Entity entity) {
        return null;
    }
    
    public void IllllllllIlIIIIIIIIllIIII() {
        if (this.IlIIlIIIIlIIIIllllIIlIllI.IIllIlIllIlIllIIlIllIlIII) {
            this.IlIIlIIIIlIIIIllllIIlIllI = null;
        }
        else {
            this.IllIIlIIlllllIllIIIlllIII = 0.0;
            this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
            this.IlllIIlllIIIIllIIllllIlIl = 0.0;
            this.x_();
            if (this.IlIIlIIIIlIIIIllllIIlIllI != null) {
                this.IlIIlIIIIlIIIIllllIIlIllI.runGameLoop();
                this.IllIIIIIIIlIlIllllIIllIII += this.IlIIlIIIIlIIIIllllIIlIllI.IllllIllllIlIIIlIIIllllll - this.IlIIlIIIIlIIIIllllIIlIllI.IlIlIIIlllllIIIlIlIlIllII;
                this.IIIllIllIlIlllllllIlIlIII += this.IlIIlIIIIlIIIIllllIIlIllI.IllIIlllIllIlIllIlIIIIIII - this.IlIIlIIIIlIIIIllllIIlIllI.IIlIIllIIIllllIIlllIllIIl;
                while (this.IllIIIIIIIlIlIllllIIllIII >= 180) {
                    this.IllIIIIIIIlIlIllllIIllIII -= 360;
                }
                while (this.IllIIIIIIIlIlIllllIIllIII < -180) {
                    this.IllIIIIIIIlIlIllllIIllIII += 360;
                }
                while (this.IIIllIllIlIlllllllIlIlIII >= 180) {
                    this.IIIllIllIlIlllllllIlIlIII -= 360;
                }
                while (this.IIIllIllIlIlllllllIlIlIII < -180) {
                    this.IIIllIllIlIlllllllIlIlIII += 360;
                }
                double n = this.IllIIIIIIIlIlIllllIIllIII * (0.6181818208615643 * 0.8088235259056091);
                double n2 = this.IIIllIllIlIlllllllIlIlIII * (0.9285714030265808 * 0.5384615532745275);
                final float n3 = 10;
                if (n > n3) {
                    n = n3;
                }
                if (n < -n3) {
                    n = -n3;
                }
                if (n2 > n3) {
                    n2 = n3;
                }
                if (n2 < -n3) {
                    n2 = -n3;
                }
                this.IllIIIIIIIlIlIllllIIllIII -= n;
                this.IIIllIllIlIlllllllIlIlIII -= n2;
            }
        }
    }
    
    public void runGameLoop() {
        if (this.IllIllIIIlIIlllIIIllIllII != null) {
            this.IllIllIIIlIIlllIIIllIllII.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.IIlIlllIllIlIlIIIIIlllIll() + this.IllIllIIIlIIlllIIIllIllII.IllIIIlIIlIllIllIIllllIIl(), this.IllIlIlIllllIlIIllllIIlll);
        }
    }
    
    public double IllIIIlIIlIllIllIIllllIIl() {
        return this.lIlIllIlIlIIIllllIlIllIll;
    }
    
    public double IIlIlllIllIlIlIIIIIlllIll() {
        return this.llllIIIIlIlIllIIIllllIIll * (1.0561797618865967 * 0.7101063919841786);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity ilIIlIIIIlIIIIllllIIlIllI) {
        this.IIIllIllIlIlllllllIlIlIII = 0.0;
        this.IllIIIIIIIlIlIllllIIllIII = 0.0;
        if (ilIIlIIIIlIIIIllllIIlIllI == null) {
            if (this.IlIIlIIIIlIIIIllllIIlIllI != null) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIIlIIIIlIIIIllllIIlIllI.IIIlIIlIlIIIlllIIlIllllll, this.IlIIlIIIIlIIIIllllIIlIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.IlIIlIIIIlIIIIllllIIlIllI.llllIIIIlIlIllIIIllllIIll, this.IlIIlIIIIlIIIIllllIIlIllI.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
                this.IlIIlIIIIlIIIIllllIIlIllI.IllIllIIIlIIlllIIIllIllII = null;
            }
            this.IlIIlIIIIlIIIIllllIIlIllI = null;
        }
        else {
            if (this.IlIIlIIIIlIIIIllllIIlIllI != null) {
                this.IlIIlIIIIlIIIIllllIIlIllI.IllIllIIIlIIlllIIIllIllII = null;
            }
            if (ilIIlIIIIlIIIIllllIIlIllI != null) {
                for (Entity entity = ilIIlIIIIlIIIIllllIIlIllI.IlIIlIIIIlIIIIllllIIlIllI; entity != null; entity = entity.IlIIlIIIIlIIIIllllIIlIllI) {
                    if (entity == this) {
                        return;
                    }
                }
            }
            this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
            ilIIlIIIIlIIIIllllIIlIllI.IllIllIIIlIIlllIIIllIllII = this;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, double n2, final double n3, final float n4, final float n5, final int n6) {
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        this.IlIlIIIlllIIIlIlllIlIllIl(n4, n5);
        final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl(14.0 * 0.002232142857142857, 0.0, 6.800000190734863 * 0.004595588106391343));
        if (!liiiIlIIllIIlIIlIIIlIIllI.isEmpty()) {
            double iiiIllIIllIIIIllIllIIIlIl = 0.0;
            for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI = liiiIlIIllIIlIIlIIIlIIllI.get(i);
                if (ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl > iiiIllIIllIIIIllIllIIIlIl) {
                    iiiIllIIllIIIIllIllIIIlIl = ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl;
                }
            }
            n2 += iiiIllIIllIIIIllIllIIIlIl - this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl;
            this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        }
    }
    
    public float IlIIllIIIlllIIIIlIIIIlIll() {
        return 0.10684932f * 0.9358974f;
    }
    
    public lIllIIIIlllllIIlIllIIIIII lIIIIIIlIIllllllIIIlIlIIl() {
        return null;
    }
    
    public void llIIIlIlIIlIlIIlIllIllIll() {
        if (this.IIlIlllllIIIlIIllIllIlIlI > 0) {
            this.IIlIlllllIIIlIIllIllIlIlI = this.IlIIlllIlIIIlIIIlIlIlIlIl();
        }
        else {
            final double n = this.lIllIllIlIIllIllIlIlIIlIl - this.IIIlIIlIlIIIlllIIlIllllll;
            final double n2 = this.lIllIlIlllIIlIIllIIlIIlII - this.IllIlIlIllllIlIIllllIIlll;
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && !this.IlIllIllIllIllIllllIIIlII) {
                this.IIIIlIllIIIIIIlIIIIIlllll = llIllIlIIIlllllIllllllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
            }
            this.IlIllIllIllIllIllllIIIlII = true;
        }
    }
    
    public int IlIIlllIlIIIlIIIlIlIlIlIl() {
        return 300;
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(final double illIIlIIlllllIllIIIlllIII, final double lIlIlIllIIIIIIIIllllIIllI, final double illlIIlllIIIIllIIllllIlIl) {
        this.IllIIlIIlllllIllIIIlllIII = illIIlIIlllllIllIIIlllIII;
        this.lIlIlIllIIIIIIIIllllIIllI = lIlIlIllIIIIIIIIllllIIllI;
        this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
    }
    
    public void IIIlllllIIlIlIIIllllllIII() {
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI[] lIlIlIIIIllIlllIlIIlllIlI() {
        return null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
    }
    
    public boolean IIllllIllllIIIlIIllllIlll() {
        final boolean b = this.lIIlllIIlIlllllllllIIIIIl != null && this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll;
        return !this.IIlIlllIllIlIlIIIIIlllIll && (this.IIIIllIlIIIllIlllIlllllIl > 0 || (b && this.IIIllIllIlIlllllllIlIlIII(0)));
    }
    
    public boolean llllIIIIIlIlIlIlIllIIIIII() {
        return this.IlIIlIIIIlIIIIllllIIlIllI != null;
    }
    
    public boolean lIlIlIllIIIIIIIIllllIIllI() {
        return this.IIIllIllIlIlllllllIlIlIII(1);
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final boolean b) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(1, b);
    }
    
    public boolean IllIIIIllllllIlllllIlIlll() {
        return this.IIIllIllIlIlllllllIlIlIII(3);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean b) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(3, b);
    }
    
    public boolean IIIllllIlIIlIIIlIlIlllIII() {
        return this.IIIllIllIlIlllllllIlIlIII(5);
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return this.IIIllllIlIIlIIIlIlIlllIII();
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final boolean b) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(5, b);
    }
    
    public boolean IIlIlllllIIIlIIllIllIlIlI() {
        return this.IIIllIllIlIlllllllIlIlIII(4);
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final boolean b) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(4, b);
    }
    
    protected boolean IIIllIllIlIlllllllIlIlIII(final int n) {
        return (this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0) & 1 << n) != 0x0;
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final boolean b) {
        final byte liiiIlIIllIIlIIlIIIlIIllI = this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0);
        if (b) {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(0, (byte)(liiiIlIIllIIlIIlIIIlIIllI | 1 << n));
        }
        else {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(0, (byte)(liiiIlIIllIIlIIlIIIlIIllI & ~(1 << n)));
        }
    }
    
    public int IlIllIllIllIllIllllIIIlII() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(1);
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int n) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(1, (short)n);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIIIllIllIIIIlIlllIIl lllIlIIIllIllIIIIlIlllIIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl(5);
        ++this.IIIIllIlIIIllIlllIlllllIl;
        if (this.IIIIllIlIIIllIlllIlllllIl == 0) {
            this.IIIIllIIllIIIIllIllIIIlIl(8);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase) {
    }
    
    protected boolean lIIIIIIIIIlIllIIllIlIIlIl(final double n, final double n2, final double n3) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n2);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n3);
        final double n4 = n - illlIIIlIlllIllIlIIlllIlI;
        final double n5 = n2 - illlIIIlIlllIllIlIIlllIlI2;
        final double n6 = n3 - illlIIIlIlllIllIlIIlllIlI3;
        if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII).isEmpty() && !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3)) {
            return false;
        }
        final boolean b = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI - 1, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
        final boolean b2 = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI + 1, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
        final boolean b3 = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3);
        final boolean b4 = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 + 1, illlIIIlIlllIllIlIIlllIlI3);
        final boolean b5 = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3 - 1);
        final boolean b6 = !this.lIIlllIIlIlllllllllIIIIIl.IIIlllIIIllIllIlIIIIIIlII(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3 + 1);
        int n7 = 3;
        double n8 = 9999;
        if (b && n4 < n8) {
            n8 = n4;
            n7 = 0;
        }
        if (b2 && 1.0 - n4 < n8) {
            n8 = 1.0 - n4;
            n7 = 1;
        }
        if (b4 && 1.0 - n5 < n8) {
            n8 = 1.0 - n5;
            n7 = 3;
        }
        if (b5 && n6 < n8) {
            n8 = n6;
            n7 = 4;
        }
        if (b6 && 1.0 - n6 < n8) {
            n7 = 5;
        }
        final float n9 = this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.021276597f * 9.4f) + 0.006329114f * 15.8f;
        if (n7 == 0) {
            this.IllIIlIIlllllIllIIIlllIII = -n9;
        }
        if (n7 == 1) {
            this.IllIIlIIlllllIllIIIlllIII = n9;
        }
        if (n7 == 2) {
            this.lIlIlIllIIIIIIIIllllIIllI = -n9;
        }
        if (n7 == 3) {
            this.lIlIlIllIIIIIIIIllllIIllI = n9;
        }
        if (n7 == 4) {
            this.IlllIIlllIIIIllIIllllIlIl = -n9;
        }
        if (n7 == 5) {
            this.IlllIIlllIIIIllIIllllIlIl = n9;
        }
        return true;
    }
    
    public void lllIllIllIlIllIlIIllllIIl() {
        this.llIlIlIllIlIIlIlllIllIIlI = true;
        this.IllllllIllllIIlllIllllllI = 0.0f;
    }
    
    public String IlIlIIIlllllIIIlIlIlIllII() {
        String liiiiiiiiIlIllIIllIlIIlIl = llIlllIlIllllIIIllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(this);
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            liiiiiiiiIlIllIIllIlIIlIl = "generic";
        }
        return IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI("entity." + liiiiiiiiIlIllIIllIlIIlIl + ".name");
    }
    
    public Entity[] IIIIIIIllIllllIIlIIlllIII() {
        return null;
    }
    
    public boolean IllIIIIIIIlIlIllllIIllIII(final Entity entity) {
        return this == entity;
    }
    
    public float IIIIlIllIIIIIIlIIIIIlllll() {
        return 0.0f;
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final float n) {
    }
    
    public boolean r_() {
        return true;
    }
    
    public boolean lIIIIllIIlIlIllIIIlIllIlI(final Entity entity) {
        return false;
    }
    
    @Override
    public String toString() {
        return String.format("%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f]", this.getClass().getSimpleName(), this.IlIlIIIlllllIIIlIlIlIllII(), this.lIIIIIIIIIlIllIIllIlIIlIl, (this.lIIlllIIlIlllllllllIIIIIl == null) ? "~NULL~" : this.lIIlllIIlIlllllllllIIIIIl.lIllIlIlllIIlIIllIIlIIlII().IlIlllIIIIllIllllIllIIlIl(), this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
    }
    
    public boolean llllIIlIlIllIllllIIIIllll() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final Entity entity) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIIIIlllIIllIIlllIIlI, entity.IllIlIlIllllIlIIllllIIlll, entity.IllllIllllIlIIIlIIIllllll, entity.IllIIlllIllIlIllIlIIIIIII);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final boolean b) {
        final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
        entity.IIIIllIIllIIIIllIllIIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.IlIlIIIlllIIIlIlllIlIllIl(ilIIIllIIlIIlllIllllIIIIl);
        this.IIlIlllllIIIlIIllIllIlIlI = entity.IIlIlllllIIIlIIllIllIlIlI;
        this.IIIIlIllIIIIIIlIIIIIlllll = entity.IIIIlIllIIIIIIlIIIIIlllll;
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(final int iiiiiiIllIllllIIlIIlllIII) {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && !this.IIllIlIllIlIllIIlIllIlIII) {
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("changeDimension");
            final llllIlIlllllIIlIIllllIIII iiIlIIlIlIIIlllIIlIllllll = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll();
            final int iiiiiiIllIllllIIlIIlllIII2 = this.IIIIIIIllIllllIIlIIlllIII;
            final IllllIllIIlllllIIlIIllIlI liiiIlIIllIIlIIlIIIlIIllI = iiIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiiIllIllllIIlIIlllIII2);
            IllllIllIIlllllIIlIIllIlI illllIllIIlllllIIlIIllIlI = iiIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiiIllIllllIIlIIlllIII);
            this.IIIIIIIllIllllIIlIIlllIII = iiiiiiIllIllllIIlIIlllIII;
            if (iiiiiiIllIllllIIlIIlllIII2 == 1 && iiiiiiIllIllllIIlIIlllIII == 1) {
                illllIllIIlllllIIlIIllIlI = iiIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(0);
                this.IIIIIIIllIllllIIlIIlllIII = 0;
            }
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this);
            this.IIllIlIllIlIllIIlIllIlIII = false;
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("reposition");
            iiIlIIlIlIIIlllIIlIllllll.IllllllIllllIIlllIllllllI().lIIIIlIIllIIlIIlIIIlIIllI(this, iiiiiiIllIllllIIlIIlllIII2, liiiIlIIllIIlIIlIIIlIIllI, illllIllIIlllllIIlIIllIlI);
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endStartSection("reloading");
            final Entity liiiIlIIllIIlIIlIIIlIIllI2 = llIlllIlIllllIIIllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIlllIlIllllIIIllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(this), illllIllIIlllllIIlIIllIlI);
            if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(this, true);
                if (iiiiiiIllIllllIIlIIlllIII2 == 1 && iiiiiiIllIllllIIlIIlllIII == 1) {
                    final IlllIllllIIIIIlIlIlIIIllI liIlllIIlIlllllllllIIIIIl = illllIllIIlllllIIlIIllIlI.lIIlllIIlIlllllllllIIIIIl();
                    liIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIllIIlIlIllIIIlIllIlI(liIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI, liIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI);
                    liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl(liIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI, liIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl, liIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI, liiiIlIIllIIlIIlIIIlIIllI2.IllllIllllIlIIIlIIIllllll, liiiIlIIllIIlIIlIIIlIIllI2.IllIIlllIllIlIllIlIIIIIII);
                }
                illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2);
            }
            this.IIllIlIllIlIllIIlIllIlIII = true;
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlllIIlIlllllIlIllIII();
            illllIllIIlllllIIlIIllIlI.lIIIIlllIIlIlllllIlIllIII();
            this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        }
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlllIlllIlIIlIllllll lIlIlIlllIlllIlIIlIllllll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlllIlllIlIIlIllllll lIlIlIlllIlllIlIIlIllllll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final float n4) {
        return true;
    }
    
    public int IIlIlIlllIllIIlIllIIlIIlI() {
        return 3;
    }
    
    public int lIlIIllIIIlllIIllIIlIIllI() {
        return this.IIIIlIllIIIIIIlIIIIIlllll;
    }
    
    public boolean lIIIlIIIIIIlIIlIIlIIlIIlI() {
        return false;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllIIIIIlllIlllIIIllIl lIlIllIIIIIlllIlllIIIllIl) {
        lIlIllIIIIIlllIlllIIIllIl.addCrashSectionCallable("Entity Type", new IlllllIllIlllllIIllIlllII(this));
        lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI("Entity ID", this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllIIIIIlllIlllIIIllIl.addCrashSectionCallable("Entity Name", new llIlllllllIIlllllIIIllIII(this));
        lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI("Entity's Exact location", String.format("%.2f, %.2f, %.2f", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll));
        lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI("Entity's Momentum", String.format("%.2f, %.2f, %.2f", this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl));
    }
    
    public boolean lIlIlIlIIlIlllIIIIIIllllI() {
        return this.IIllllIllllIIIlIIllllIlll();
    }
    
    public UUID llllIIllIIlllllIlIlIIllll() {
        return this.llllIIlIlIllIllllIIIIllll;
    }
    
    public boolean IllIlIIIIlIlllIlllllllIIl() {
        return true;
    }
    
    public IllIllIIlIIlIlllIIllIIIlI IIlIIllIIIllllIIlllIllIIl() {
        return new lIlIIllIIlIIIIIlIllIllllI(this.IlIlIIIlllllIIIlIlIlIllII());
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final int n) {
    }
}
