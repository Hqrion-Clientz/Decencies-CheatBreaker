// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIlIlllIIlIIIIlIlIll extends IIIllIlllIlIIIlIlIIlllIIl
{
    private IIlllIIllIllIlIllIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private double lIIIIIIIIIlIllIIllIlIIlIl;
    private double IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private double IIIIllIIllIIIIllIllIIIlIl;
    
    public IIlIIIIlIlllIIlIIIIlIlIll(final IIlllIIllIllIlIllIIIIIIlI liiiIlIIllIIlIIlIIIlIIllI, final double iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI(1);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII()) {
            return false;
        }
        final IlllIllllIIIIIlIlIlIIIllI liiiiIllllIIIIlIlIIIIlIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIllllIIIIlIlIIIIlIlI();
        final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, 16, 7, lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI, liiiiIllllIIIIlIlIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl, liiiiIllllIIIIlIlIIIIlIlI.IlllIIIlIlllIllIlIIlllIlI));
        if (liiiIlIIllIIlIIlIIIlIIllI == null) {
            return false;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl;
        this.IIIIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI;
        return true;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return !this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll().IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll().lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl);
    }
}
