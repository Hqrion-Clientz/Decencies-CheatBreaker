import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import com.google.common.collect.Lists;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIllIllllIIlIllIlllIIlll extends Thread
{
    final /* synthetic */ ResourcePackRepository lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ llllllIIIlIIIllIlIIIIlIll lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ llllllIIIlIIIllIlIIIIlIll IlllIIIlIlllIllIlIIlllIlI;
    
    IIIllIllllIIlIllIlllIIlll(final llllllIIIlIIIllIlIIIIlIll illlIIIlIlllIllIlIIlllIlI, final ResourcePackRepository liiiIlIIllIIlIIlIIIlIIllI, final llllllIIIlIIIllIlIIIIlIll liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void run() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
        final ArrayList arrayList = Lists.newArrayList((Iterable)this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
        arrayList.removeAll(this.lIIIIlIIllIIlIIlIIIlIIllI.getRepositoryEntries());
        final Iterator<lllIlllIIIlIllllllIlIIlIl> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI.add(new IllllIlllIllllllIIIIllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, iterator.next()));
        }
        this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.addAll(this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI);
        final Iterator<lllIlllIIIlIllllllIlIIlIl> iterator2 = Lists.reverse(this.lIIIIlIIllIIlIIlIIIlIIllI.getRepositoryEntries()).iterator();
        while (iterator2.hasNext()) {
            this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl.add(Math.max(0, this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl.size() - 1), new IllllIlllIllllllIIIIllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, iterator2.next()));
        }
        this.IlllIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI.IlIlIIIlllIIIlIlllIlIllIl.addAll(this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl);
        this.IlllIIIlIlllIllIlIIlllIlI.IllIlIIIIlllIIllIIlllIIlI.IlllIllIlIIIIlIIlIIllIIIl = true;
        this.IlllIIIlIlllIllIlIIlllIlI.IlllIllIlIIIIlIIlIIllIIIl = true;
    }
}
