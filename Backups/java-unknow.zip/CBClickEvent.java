// 
// Decompiled by Procyon v0.5.36
// 

public class CBClickEvent extends CBEvent
{
    private final int lIIIIlIIllIIlIIlIIIlIIllI;
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public CBClickEvent(final int liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
}
