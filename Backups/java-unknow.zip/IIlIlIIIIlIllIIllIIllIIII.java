// 
// Decompiled by Procyon v0.5.36
// 

public interface IIlIlIIIIlIllIIllIIllIIII extends lIlIIIlIlIllIlIlIIIlIlIII
{
    void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIllIIlIlIIlIIIlllIll p0);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIIllIIlIlIIIIIlIllII p0);
}
