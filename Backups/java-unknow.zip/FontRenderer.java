import java.io.InputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ArrayList;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import com.ibm.icu.text.ArabicShaping;
import org.lwjgl.opengl.GL11;
import java.util.Properties;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class FontRenderer implements IllIllllIIlIllIlIlllllIII
{
    private static final ResourceLocation[] IllIIIIIIIlIlIllllIIllIII;
    private float[] lIIIIllIIlIlIllIIIlIllIlI;
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public Random lIIIIIIIIIlIllIIllIlIIlIl;
    private byte[] IlllIllIlIIIIlIIlIIllIIIl;
    public int[] IlllIIIlIlllIllIlIIlllIlI;
    private ResourceLocation IlIlllIIIIllIllllIllIIlIl;
    private final TextureManager llIIlllIIIIlllIllIlIlllIl;
    private float lIIlIlIllIIlIIIlIIIlllIII;
    private float IIIlllIIIllIllIlIIIIIIlII;
    private boolean llIlIIIlIIIIlIlllIlIIIIll;
    private boolean IIIlIIllllIIllllllIlIIIll;
    private float lllIIIIIlIllIlIIIllllllII;
    private float lIIIIIllllIIIIlIlIIIIlIlI;
    private float IIIIIIlIlIlIllllllIlllIlI;
    private float IllIllIIIlIIlllIIIllIllII;
    private int IlIIlIIIIlIIIIllllIIlIllI;
    private boolean lIIlIIllIIIIIlIllIIIIllII;
    private boolean lIIlllIIlIlllllllllIIIIIl;
    private boolean lIllIllIlIIllIllIlIlIIlIl;
    private boolean llIlIIIllIIIIlllIlIIIIIlI;
    private boolean lIllIlIlllIIlIIllIIlIIlII;
    public GameSettings IIIIllIlIIIllIlllIlllllIl;
    public ResourceLocation IIIIllIIllIIIIllIllIIIlIl;
    public boolean IlIlIIIlllIIIlIlllIlIllIl;
    public float IIIllIllIlIlllllllIlIlIII;
    private ResourceLocation IIIlIIlIlIIIlllIIlIllllll;
    private int IllIlIIIIlllIIllIIlllIIlI;
    private int IllIlIlIllllIlIIllllIIlll;
    private boolean[] IllIIlIIlllllIllIIIlllIII;
    private final IlllIIlllIIIIllIIllllIlIl lIlIlIllIIIIIIIIllllIIllI;
    private List IlllIIlllIIIIllIIllllIlIl;
    private long IllllIllllIlIIIlIIIllllll;
    
    public FontRenderer(final GameSettings iiiIllIlIIIllIlllIlllllIl, final ResourceLocation resourceLocation, final TextureManager llIIlllIIIIlllIllIlIlllIl, final boolean llIlIIIlIIIIlIlllIlIIIIll) {
        this.lIIIIllIIlIlIllIIIlIllIlI = new float[256];
        this.lIIIIlIIllIIlIIlIIIlIIllI = 9;
        this.lIIIIIIIIIlIllIIllIlIIlIl = new Random();
        this.IlllIllIlIIIIlIIlIIllIIIl = new byte[65536];
        this.IlllIIIlIlllIllIlIIlllIlI = new int[32];
        this.IlIlIIIlllIIIlIlllIlIllIl = true;
        this.IIIllIllIlIlllllllIlIlIII = 1.0f;
        this.lIlIlIllIIIIIIIIllllIIllI = new IlllIIlllIIIIllIIllllIlIl();
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = resourceLocation;
        this.IlIlllIIIIllIllllIllIIlIl = resourceLocation;
        this.llIIlllIIIIlllIllIlIlllIl = llIIlllIIIIlllIllIlIlllIl;
        this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
        this.IlIlllIIIIllIllllIllIIlIl = IllIlIIlIIllllllllIIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl);
        for (int i = 0; i < 32; ++i) {
            final int n = (i >> 3 & 0x1) * 85;
            int n2 = (i >> 2 & 0x1) * 170 + n;
            int n3 = (i >> 1 & 0x1) * 170 + n;
            int n4 = (i >> 0 & 0x1) * 170 + n;
            if (i == 6) {
                n2 += 85;
            }
            if (iiiIllIlIIIllIlllIlllllIl.IIIIllIIllIIIIllIllIIIlIl) {
                final int n5 = (n2 * 30 + n3 * 59 + n4 * 11) / 100;
                final int n6 = (n2 * 30 + n3 * 70) / 100;
                final int n7 = (n2 * 30 + n4 * 70) / 100;
                n2 = n5;
                n3 = n6;
                n4 = n7;
            }
            if (i >= 16) {
                n2 /= 4;
                n3 /= 4;
                n4 /= 4;
            }
            this.IlllIIIlIlllIllIlIIlllIlI[i] = ((n2 & 0xFF) << 16 | (n3 & 0xFF) << 8 | (n4 & 0xFF));
        }
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        this.lIlIlIllIIIIIIIIllllIIllI.clear();
        this.IlIlllIIIIllIllllIllIIlIl = IllIlIIlIIllllllllIIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl);
        for (int i = 0; i < FontRenderer.IllIIIIIIIlIlIllllIIllIII.length; ++i) {
            FontRenderer.IllIIIIIIIlIlIllllIIllIII[i] = null;
        }
        this.IIIIllIIllIIIIllIllIIIlIl();
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    private void IIIIllIIllIIIIllIllIIIlIl() {
        BufferedImage read;
        try {
            read = ImageIO.read(this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl));
        }
        catch (IOException cause) {
            throw new RuntimeException(cause);
        }
        final Properties liiiIlIIllIIlIIlIIIlIIllI = IllIlIIlIIllllllllIIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl);
        final int width = read.getWidth();
        final int height = read.getHeight();
        final int n = width / 16;
        final int n2 = height / 16;
        final float n3 = width / (float)128;
        this.IIIllIllIlIlllllllIlIlIII = 1.0f / lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(n3, 1.0f, 2.0f);
        final float liiiIlIIllIIlIIlIIIlIIllI2 = IllIlIIlIIllllllllIIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, "offsetBold", -1);
        if (liiiIlIIllIIlIIlIIIlIIllI2 >= 0.0f) {
            this.IIIllIllIlIlllllllIlIlIII = liiiIlIIllIIlIIlIIIlIIllI2;
        }
        final int[] rgbArray = new int[width * height];
        read.getRGB(0, 0, width, height, rgbArray, 0, width);
        for (int i = 0; i < 256; ++i) {
            final int n4 = i % 16;
            final int n5 = i / 16;
            int j;
            for (j = n - 1; j >= 0; --j) {
                final int n6 = n4 * n + j;
                int n7 = 1;
                for (int n8 = 0; n8 < n2 && n7 != 0; ++n8) {
                    if ((rgbArray[n6 + (n5 * n2 + n8) * width] >> 24 & 0xFF) > 16) {
                        n7 = 0;
                    }
                }
                if (n7 == 0) {
                    break;
                }
            }
            if (i == 65) {
                i = i;
            }
            if (i == 32) {
                if (n <= 8) {
                    j = (int)(2.0f * n3);
                }
                else {
                    j = (int)(1.4021739f * 1.0697675f * n3);
                }
            }
            this.lIIIIllIIlIlIllIIIlIllIlI[i] = (j + 1) / n3 + 1.0f;
        }
        IllIlIIlIIllllllllIIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, this.lIIIIllIIlIlIllIIIlIllIlI);
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        try {
            this.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("font/glyph_sizes.bin")).read(this.IlllIllIlIIIIlIIlIIllIIIl);
        }
        catch (IOException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final int n, final char ch, final boolean b) {
        if (ch == ' ') {
            this.IllIIIIIIIlIlIllllIIllIII();
            return this.llIlIIIlIIIIlIlllIlIIIIll ? 4 : this.lIIIIllIIlIlIllIIIlIllIlI[ch];
        }
        return ("\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8£\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1ªº¿®¬½¼¡«»\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261±\u2265\u2264\u2320\u2321\u00f7\u2248°\u2219·\u221a\u207f²\u25a0\u0000".indexOf(ch) != -1 && !this.llIlIIIlIIIIlIlllIlIIIIll) ? this.lIIIIlIIllIIlIIlIIIlIIllI(n, b) : this.lIIIIlIIllIIlIIlIIIlIIllI(ch, b);
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final int n, final boolean b) {
        if (this.IIIlIIlIlIIIlllIIlIllllll == null && !this.IllIIlIIlllllIllIIIlllIII[this.IllIlIIIIlllIIllIIlllIIlI]) {
            this.IIIlIIlIlIIIlllIIlIllllll = this.IlIlllIIIIllIllllIllIIlIl;
            if (!Tessellator.instance.IlIlIIIlllIIIlIlllIlIllIl) {
                final int glGenLists = GL11.glGenLists(1);
                this.IlllIIlllIIIIllIIllllIlIl.add(new IllIIlllIllIlIllIlIIIIIII(glGenLists, this.IIIlIIlIlIIIlllIIlIllllll));
                GL11.glNewList(glGenLists, 4864);
                Tessellator.instance.startDrawingQuads();
            }
        }
        if (this.IIIlIIlIlIIIlllIIlIllllll == this.IlIlllIIIIllIllllIllIIlIl) {
            final float n2 = (float)(n % 16 * 8);
            final float n3 = (float)(n / 16 * 8);
            final float n4 = b ? 1.0f : 0.0f;
            final float n5 = 9.004603f * 0.8873239f;
            this.lIIIIllIIlIlIllIIIlIllIlI();
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI(n2 / 128, n3 / 128);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n4, this.IIIlllIIIllIllIlIIIIIIlII, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI(n2 / 128, (n3 + 1.2398275f * 6.4444447f) / 128);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII - n4, this.IIIlllIIIllIllIlIIIIIIlII + 1.2f * 6.658333f, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI((n2 + n5 - 1.0f) / 128, (n3 + 2.3103614f * 3.4583333f) / 128);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n5 - 1.0f - n4, this.IIIlllIIIllIllIlIIIIIIlII + 0.79899997f * 10.0f, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI((n2 + n5 - 1.0f) / 128, n3 / 128);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n5 - 1.0f + n4, this.IIIlllIIIllIllIlIIIIIIlII, 0.0);
            this.IllIIIIIIIlIlIllllIIllIII();
        }
        return this.lIIIIllIIlIlIllIIIlIllIlI[n];
    }
    
    private ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final int i) {
        if (FontRenderer.IllIIIIIIIlIlIllllIIllIII[i] == null) {
            FontRenderer.IllIIIIIIIlIlIllllIIllIII[i] = new ResourceLocation(String.format("textures/font/unicode_page_%02x.png", i));
            FontRenderer.IllIIIIIIIlIlIllllIIllIII[i] = IllIlIIlIIllllllllIIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(FontRenderer.IllIIIIIIIlIlIllllIIllIII[i]);
        }
        return FontRenderer.IllIIIIIIIlIlIllllIIllIII[i];
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final char c, final boolean b) {
        if (this.IlllIllIlIIIIlIIlIIllIIIl[c] == 0) {
            this.IllIIIIIIIlIlIllllIIllIII();
            return 0.0f;
        }
        final ResourceLocation liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(c / '\u0100');
        final int n = this.IlllIllIlIIIIlIIlIIllIIIl[c] >>> 4;
        final int n2 = this.IlllIllIlIIIIlIIlIIllIIIl[c] & 0xF;
        final float n3 = (float)(n & 0xF);
        final float n4 = (float)(n2 + 1);
        if (this.IIIlIIlIlIIIlllIIlIllllll == null && !this.IllIIlIIlllllIllIIIlllIII[this.IllIlIIIIlllIIllIIlllIIlI]) {
            this.IIIlIIlIlIIIlllIIlIllllll = liiiIlIIllIIlIIlIIIlIIllI;
            if (!Tessellator.instance.IlIlIIIlllIIIlIlllIlIllIl) {
                final int glGenLists = GL11.glGenLists(1);
                this.IlllIIlllIIIIllIIllllIlIl.add(new IllIIlllIllIlIllIlIIIIIII(glGenLists, this.IIIlIIlIlIIIlllIIlIllllll));
                GL11.glNewList(glGenLists, 4864);
                Tessellator.instance.startDrawingQuads();
            }
        }
        if (this.IIIlIIlIlIIIlllIIlIllllll == liiiIlIIllIIlIIlIIIlIIllI) {
            final float n5 = c % '\u0010' * 16 + n3;
            final float n6 = (float)((c & '\u00ff') / 16 * 16);
            final float n7 = n4 - n3 - 0.2804878f * 0.07130434f;
            final float n8 = b ? 1.0f : 0.0f;
            this.lIIIIllIIlIlIllIIIlIllIlI();
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI(n5 / 256, n6 / 256);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n8, this.IIIlllIIIllIllIlIIIIIIlII, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI(n5 / 256, (n6 + 0.33333334f * 47.94f) / 256);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII - n8, this.IIIlllIIIllIllIlIIIIIIlII + 1.2666667f * 6.3078947f, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI((n5 + n7) / 256, (n6 + 1.7073171f * 9.359714f) / 256);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n7 / 2.0f - n8, this.IIIlllIIIllIllIlIIIIIIlII + 4.7659645f * 1.6764706f, 0.0);
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI((n5 + n7) / 256, n6 / 256);
            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + n7 / 2.0f + n8, this.IIIlllIIIllIllIlIIIIIIlII, 0.0);
            this.IllIIIIIIIlIlIllllIIllIII();
        }
        return (n4 - n3) / 2.0f + 1.0f;
    }
    
    public int drawStringWithShadow(final String s, final float n, final float n2, final int n3) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2, n3, true);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2, final int n3) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s, (float)(n - this.getStringWidth(s) / 2), (float)n2, n3, true);
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final String s, final float n, final float n2, final int n3) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s, n - this.getStringWidth(s) / 2, n2, n3, false);
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n, final int n2, final int n3) {
        return this.IlIlIIIlllIIIlIlllIlIllIl ? this.lIIIIlIIllIIlIIlIIIlIIllI(s, (float)n, (float)n2, n3, false) : 0;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final String s, final float n, final float n2, final int n3, final boolean b) {
        this.unloadSounds();
        this.IIIllIllIlIlllllllIlIlIII();
        int n4;
        if (b) {
            n4 = Math.max(this.lIIIIIIIIIlIllIIllIlIIlIl(s, n + 1.0f, n2 + 1.0f, n3, true), this.lIIIIIIIIIlIllIIllIlIIlIl(s, n, n2, n3, false));
        }
        else {
            n4 = this.lIIIIIIIIIlIllIIllIlIIlIl(s, n, n2, n3, false);
        }
        return n4;
    }
    
    private String lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        try {
            final Bidi bidi = new Bidi(new ArabicShaping(8).shape(s), 127);
            bidi.setReorderingMode(0);
            return bidi.writeReordered(2);
        }
        catch (ArabicShapingException ex) {
            return s;
        }
    }
    
    private void IIIllIllIlIlllllllIlIlIII() {
        this.lIIlIIllIIIIIlIllIIIIllII = false;
        this.lIIlllIIlIlllllllllIIIIIl = false;
        this.lIllIllIlIIllIllIlIlIIlIl = false;
        this.llIlIIIllIIIIlllIlIIIIIlI = false;
        this.lIllIlIlllIIlIIllIIlIIlII = false;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final boolean b, final int n) {
        final lIlIlIllIIIIIIIIllllIIllI liiiIlIIllIIlIIlIIIlIIllI = this.lIlIlIllIIIIIIIIllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s, n, b);
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll);
            GL11.glPushMatrix();
            GL11.glTranslatef(this.lIIlIlIllIIlIIIlIIIlllIII, this.IIIlllIIIllIllIlIIIIIIlII, 0.0f);
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glPopMatrix();
            this.lIIlIlIllIIlIIIlIIIlllIII += liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI();
            return;
        }
        final float liIlIlIllIIlIIIlIIIlllIII = this.lIIlIlIllIIlIIIlIIIlllIII;
        final float iiIlllIIIllIllIlIIIIIIlII = this.IIIlllIIIllIllIlIIIIIIlII;
        this.lIIlIlIllIIlIIIlIIIlllIII = 0.0f;
        this.IIIlllIIIllIllIlIIIIIIlII = 0.0f;
        this.IlllIIlllIIIIllIIllllIlIl = new ArrayList();
        this.IllIIlIIlllllIllIIIlllIII = new boolean[s.length()];
        this.IllIlIlIllllIlIIllllIIlll = s.length();
        boolean b2 = false;
        while (this.IllIlIlIllllIlIIllllIIlll >= 0) {
            if (this.IllIlIlIllllIlIIllllIIlll == 0) {
                this.IllIlIlIllllIlIIllllIIlll = -1;
            }
            this.lIIlIlIllIIlIIIlIIIlllIII = 0.0f;
            this.IIIlIIlIlIIIlllIIlIllllll = null;
            this.IlIIlIIIIlIIIIllllIIlIllI = -1;
            this.IIIllIllIlIlllllllIlIlIII();
            this.IllIlIIIIlllIIllIIlllIIlI = 0;
            while (this.IllIlIIIIlllIIllIIlllIIlI < s.length()) {
                final char char1 = s.charAt(this.IllIlIIIIlllIIllIIlllIIlI);
                if (char1 == '§' && this.IllIlIIIIlllIIllIIlllIIlI + 1 < s.length()) {
                    int index = "0123456789abcdefklmnor".indexOf(Character.toLowerCase(s.charAt(this.IllIlIIIIlllIIllIIlllIIlI + 1)));
                    if (index < 16) {
                        this.lIIlIIllIIIIIlIllIIIIllII = false;
                        this.lIIlllIIlIlllllllllIIIIIl = false;
                        this.lIllIlIlllIIlIIllIIlIIlII = false;
                        this.llIlIIIllIIIIlllIlIIIIIlI = false;
                        this.lIllIllIlIIllIllIlIlIIlIl = false;
                        if (index < 0 || index > 15) {
                            index = 15;
                        }
                        if (b) {
                            index += 16;
                        }
                        int liiiIlIIllIIlIIlIIIlIIllI2 = this.IlllIIIlIlllIllIlIIlllIlI[index];
                        if (lIIIllIIIllIlllllIIlIllII.IllIlIIIIlIlllIlllllllIIl()) {
                            liiiIlIIllIIlIIlIIIlIIllI2 = lIIIllIllIIIIIlIIIIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(index, liiiIlIIllIIlIIlIIIlIIllI2);
                        }
                        this.IlIIlIIIIlIIIIllllIIlIllI = liiiIlIIllIIlIIlIIIlIIllI2;
                    }
                    else if (index == 16) {
                        this.lIIlIIllIIIIIlIllIIIIllII = true;
                        b2 = true;
                    }
                    else if (index == 17) {
                        this.lIIlllIIlIlllllllllIIIIIl = true;
                    }
                    else if (index == 18) {
                        this.lIllIlIlllIIlIIllIIlIIlII = true;
                    }
                    else if (index == 19) {
                        this.llIlIIIllIIIIlllIlIIIIIlI = true;
                    }
                    else if (index == 20) {
                        this.lIllIllIlIIllIllIlIlIIlIl = true;
                    }
                    else if (index == 21) {
                        this.lIIlIIllIIIIIlIllIIIIllII = false;
                        this.lIIlllIIlIlllllllllIIIIIl = false;
                        this.lIllIlIlllIIlIIllIIlIIlII = false;
                        this.llIlIIIllIIIIlllIlIIIIIlI = false;
                        this.lIllIllIlIIllIllIlIlIIlIl = false;
                        this.IlIIlIIIIlIIIIllllIIlIllI = -1;
                    }
                    this.IllIIIIIIIlIlIllllIIllIII();
                    ++this.IllIlIIIIlllIIllIIlllIIlI;
                    this.IllIIIIIIIlIlIllllIIllIII();
                }
                else {
                    int index2 = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8£\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1ªº¿®¬½¼¡«»\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261±\u2265\u2264\u2320\u2321\u00f7\u2248°\u2219·\u221a\u207f²\u25a0\u0000".indexOf(char1);
                    if (this.lIIlIIllIIIIIlIllIIIIllII && index2 != -1) {
                        int nextInt;
                        do {
                            nextInt = this.lIIIIIIIIIlIllIIllIlIIlIl.nextInt(this.lIIIIllIIlIlIllIIIlIllIlI.length);
                        } while ((int)this.lIIIIllIIlIlIllIIIlIllIlI[index2] != (int)this.lIIIIllIIlIlIllIIIlIllIlI[nextInt]);
                        index2 = nextInt;
                    }
                    final float n2 = (index2 != -1 && !this.llIlIIIlIIIIlIlllIlIIIIll) ? this.IIIllIllIlIlllllllIlIlIII : (0.50769234f * 0.98484844f);
                    final boolean b3 = (char1 == '\0' || index2 == -1 || this.llIlIIIlIIIIlIlllIlIIIIll) && b;
                    if (b3) {
                        this.lIIlIlIllIIlIIIlIIIlllIII -= n2;
                        this.IIIlllIIIllIllIlIIIIIIlII -= n2;
                    }
                    float liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI(index2, char1, this.lIllIllIlIIllIllIlIlIIlIl);
                    if (b3) {
                        this.lIIlIlIllIIlIIIlIIIlllIII += n2;
                        this.IIIlllIIIllIllIlIIIIIIlII += n2;
                    }
                    if (this.lIIlllIIlIlllllllllIIIIIl) {
                        this.lIIlIlIllIIlIIIlIIIlllIII += n2;
                        if (b3) {
                            this.lIIlIlIllIIlIIIlIIIlllIII -= n2;
                            this.IIIlllIIIllIllIlIIIIIIlII -= n2;
                        }
                        this.lIIIIlIIllIIlIIlIIIlIIllI(index2, char1, this.lIllIllIlIIllIllIlIlIIlIl);
                        this.lIIlIlIllIIlIIIlIIIlllIII -= n2;
                        if (b3) {
                            this.lIIlIlIllIIlIIIlIIIlllIII += n2;
                            this.IIIlllIIIllIllIlIIIIIIlII += n2;
                        }
                        liiiIlIIllIIlIIlIIIlIIllI3 += n2;
                    }
                    if (this.IllIlIlIllllIlIIllllIIlll == -1 && (this.lIllIlIlllIIlIIllIIlIIlII || this.llIlIIIllIIIIlllIlIIIIIlI)) {
                        if (!Tessellator.instance.IlIlIIIlllIIIlIlllIlIllIl) {
                            final int glGenLists = GL11.glGenLists(1);
                            this.IlllIIlllIIIIllIIllllIlIl.add(new IllIIlllIllIlIllIlIIIIIII(glGenLists, null));
                            GL11.glNewList(glGenLists, 4864);
                            Tessellator.instance.startDrawingQuads();
                        }
                        this.lIIIIllIIlIlIllIIIlIllIlI();
                        if (this.lIllIlIlllIIlIIllIIlIIlII) {
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI / 2, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + liiiIlIIllIIlIIlIIIlIIllI3, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI / 2, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + liiiIlIIllIIlIIlIIIlIIllI3, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI / 2 - 1.0f, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI / 2 - 1.0f, 0.0);
                        }
                        if (this.llIlIIIllIIIIlllIlIIIIIlI) {
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII - 1.0f, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + liiiIlIIllIIlIIlIIIlIIllI3, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII + liiiIlIIllIIlIIlIIIlIIllI3, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI - 1.0f, 0.0);
                            Tessellator.instance.addVertex(this.lIIlIlIllIIlIIIlIIIlllIII - 1.0f, this.IIIlllIIIllIllIlIIIIIIlII + this.lIIIIlIIllIIlIIlIIIlIIllI - 1.0f, 0.0);
                        }
                    }
                    this.lIIlIlIllIIlIIIlIIIlllIII += liiiIlIIllIIlIIlIIIlIIllI3;
                }
                ++this.IllIlIIIIlllIIllIIlllIIlI;
            }
            if (Tessellator.instance.IlIlIIIlllIIIlIlllIlIllIl) {
                Tessellator.instance.draw();
                GL11.glEndList();
            }
        }
        final lIlIlIllIIIIIIIIllllIIllI lIlIlIllIIIIIIIIllllIIllI = new lIlIlIllIIIIIIIIllllIIllI(this.IlllIIlllIIIIllIIllllIlIl, this.lIIlIlIllIIlIIIlIIIlllIII, this.IllllIllllIlIIIlIIIllllll, b2);
        this.lIlIlIllIIIIIIIIllllIIllI.put(new IllllIllllIlIIIlIIIllllll(s, n, b), lIlIlIllIIIIIIIIllllIIllI);
        GL11.glPushMatrix();
        GL11.glTranslatef(liIlIlIllIIlIIIlIIIlllIII, iiIlllIIIllIllIlIIIIIIlII, 0.0f);
        lIlIlIllIIIIIIIIllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
        GL11.glPopMatrix();
        this.IlllIIlllIIIIllIIllllIlIl = null;
        this.lIIlIlIllIIlIIIlIIIlllIII += liIlIlIllIIlIIIlIIIlllIII;
    }
    
    private void IllIIIIIIIlIlIllllIIllIII() {
        if (!this.IllIIlIIlllllIllIIIlllIII[this.IllIlIIIIlllIIllIIlllIIlI]) {
            this.IllIIlIIlllllIllIIIlllIII[this.IllIlIIIIlllIIllIIlllIIlI] = true;
            --this.IllIlIlIllllIlIIllllIIlll;
        }
    }
    
    private void lIIIIllIIlIlIllIIIlIllIlI() {
        if (this.IlIIlIIIIlIIIIllllIIlIllI == -1) {
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIIIIlIllIlIIIllllllII, this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI, this.IllIllIIIlIIlllIIIllIllII);
        }
        else {
            Tessellator.instance.lIIIIlIIllIIlIIlIIIlIIllI((this.IlIIlIIIIlIIIIllllIIlIllI >> 16) / (float)255, (this.IlIIlIIIIlIIIIllllIIlIllI >> 8 & 0xFF) / (float)255, (this.IlIIlIIIIlIIIIllllIIlIllI & 0xFF) / (float)255, this.IllIllIIIlIIlllIIIllIllII);
        }
    }
    
    private int lIIIIlIIllIIlIIlIIIlIIllI(final String s, int n, final int n2, final int n3, final int n4, final boolean b) {
        if (this.IIIlIIllllIIllllllIlIIIll) {
            n = n + n3 - this.getStringWidth(this.lIIIIIIIIIlIllIIllIlIIlIl(s));
        }
        return this.lIIIIIIIIIlIllIIllIlIIlIl(s, (float)n, (float)n2, n4, b);
    }
    
    private int lIIIIIIIIIlIllIIllIlIIlIl(String liiiiiiiiIlIllIIllIlIIlIl, final float liIlIlIllIIlIIIlIIIlllIII, final float iiIlllIIIllIllIlIIIIIIlII, int n, final boolean b) {
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            return 0;
        }
        if (this.IIIlIIllllIIllllllIlIIIll) {
            liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl);
        }
        if ((n & 0xFC000000) == 0x0) {
            n |= 0xFF000000;
        }
        if (b) {
            n = ((n & 0xFCFCFC) >> 2 | (n & 0xFF000000));
        }
        this.lllIIIIIlIllIlIIIllllllII = (n >> 16 & 0xFF) / (float)255;
        this.lIIIIIllllIIIIlIlIIIIlIlI = (n >> 8 & 0xFF) / (float)255;
        this.IIIIIIlIlIlIllllllIlllIlI = (n & 0xFF) / (float)255;
        this.IllIllIIIlIIlllIIIllIllII = (n >> 24 & 0xFF) / (float)255;
        this.lIIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII;
        this.IIIlllIIIllIllIlIIIIIIlII = iiIlllIIIllIllIlIIIIIIlII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl, b, n);
        return (int)this.lIIlIlIllIIlIIIlIIIlllIII;
    }
    
    public int getStringWidth(final String s) {
        if (s == null) {
            return 0;
        }
        float n = 0.0f;
        boolean b = false;
        for (int i = 0; i < s.length(); ++i) {
            float liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(s.charAt(i));
            if (liiiiiiiiIlIllIIllIlIIlIl < 0.0f && i < s.length() - 1) {
                ++i;
                final char char1 = s.charAt(i);
                if (char1 != 'l' && char1 != 'L') {
                    if (char1 == 'r' || char1 == 'R') {
                        b = false;
                    }
                }
                else {
                    b = true;
                }
                liiiiiiiiIlIllIIllIlIIlIl = 0.0f;
            }
            n += liiiiiiiiIlIllIIllIlIIlIl;
            if (b && liiiiiiiiIlIllIIllIlIIlIl > 0.0f) {
                n += (this.llIlIIIlIIIIlIlllIlIIIIll ? 1.0f : this.IIIllIllIlIlllllllIlIlIII);
            }
        }
        return (int)n;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final char c) {
        return Math.round(this.lIIIIIIIIIlIllIIllIlIIlIl(c));
    }
    
    private float lIIIIIIIIIlIllIIllIlIIlIl(final char ch) {
        if (ch == '§') {
            return -1;
        }
        if (ch == ' ') {
            return this.lIIIIllIIlIlIllIIIlIllIlI[32];
        }
        final int index = "\u00c0\u00c1\u00c2\u00c8\u00ca\u00cb\u00cd\u00d3\u00d4\u00d5\u00da\u00df\u00e3\u00f5\u011f\u0130\u0131\u0152\u0153\u015e\u015f\u0174\u0175\u017e\u0207\u0000\u0000\u0000\u0000\u0000\u0000\u0000 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u0000\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8£\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1ªº¿®¬½¼¡«»\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u03b2\u0393\u03c0\u03a3\u03c3\u03bc\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u2205\u2208\u2229\u2261±\u2265\u2264\u2320\u2321\u00f7\u2248°\u2219·\u221a\u207f²\u25a0\u0000".indexOf(ch);
        if (ch > '\0' && index != -1 && !this.llIlIIIlIIIIlIlllIlIIIIll) {
            return this.lIIIIllIIlIlIllIIIlIllIlI[index];
        }
        if (this.IlllIllIlIIIIlIIlIIllIIIl[ch] != 0) {
            final int n = this.IlllIllIlIIIIlIIlIIllIIIl[ch] >>> 4;
            int n2 = this.IlllIllIlIIIIlIIlIIllIIIl[ch] & 0xF;
            return (float)((++n2 - (n & 0xF)) / 2 + 1);
        }
        return 0.0f;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s, n, false);
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final boolean b) {
        final StringBuilder sb = new StringBuilder();
        float n2 = 0.0f;
        final int n3 = b ? (s.length() - 1) : 0;
        final int n4 = b ? -1 : 1;
        int n5 = 0;
        boolean b2 = false;
        for (int index = n3; index >= 0 && index < s.length() && n2 < n; index += n4) {
            final char char1 = s.charAt(index);
            final float liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(char1);
            if (n5 != 0) {
                n5 = 0;
                if (char1 != 'l' && char1 != 'L') {
                    if (char1 == 'r' || char1 == 'R') {
                        b2 = false;
                    }
                }
                else {
                    b2 = true;
                }
            }
            else if (liiiiiiiiIlIllIIllIlIIlIl < 0.0f) {
                n5 = 1;
            }
            else {
                n2 += liiiiiiiiIlIllIIllIlIIlIl;
                if (b2) {
                    ++n2;
                }
            }
            if (n2 > n) {
                break;
            }
            if (b) {
                sb.insert(0, char1);
            }
            else {
                sb.append(char1);
            }
        }
        return sb.toString();
    }
    
    private String IlllIIIlIlllIllIlIIlllIlI(String substring) {
        while (substring != null && substring.endsWith("\n")) {
            substring = substring.substring(0, substring.length() - 1);
        }
        return substring;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(String illlIIIlIlllIllIlIIlllIlI, final int n, final int n2, final int n3, final int ilIIlIIIIlIIIIllllIIlIllI) {
        this.IIIllIllIlIlllllllIlIlIII();
        this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
        illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, n, n2, n3, false);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, int n2, final int n3, final boolean b) {
        final Iterator<String> iterator = this.IlllIIIlIlllIllIlIIlllIlI(s, n3).iterator();
        while (iterator.hasNext()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next(), n, n2, n3, this.IlIIlIIIIlIIIIllllIIlIllI, b);
            n2 += this.lIIIIlIIllIIlIIlIIIlIIllI;
        }
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI * this.IlllIIIlIlllIllIlIIlllIlI(s, n).size();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean llIlIIIlIIIIlIlllIlIIIIll) {
        this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    public boolean isCurrentLocaleUnicode() {
        return this.llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean iiIlIIllllIIllllllIlIIIll) {
        this.IIIlIIllllIIllllllIlIIIll = iiIlIIllllIIllllllIlIIIll;
    }
    
    public List IlllIIIlIlllIllIlIIlllIlI(final String s, final int n) {
        return Arrays.asList(this.IIIIllIlIIIllIlllIlllllIl(s, n).split("\n"));
    }
    
    String IIIIllIlIIIllIlllIlllllIl(final String s, final int n) {
        final int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(s, n);
        if (s.length() <= iiiIllIIllIIIIllIllIIIlIl) {
            return s;
        }
        final String substring = s.substring(0, iiiIllIIllIIIIllIllIIIlIl);
        final char char1 = s.charAt(iiiIllIIllIIIIllIllIIIlIl);
        return substring + "\n" + this.IIIIllIlIIIllIlllIlllllIl(IIIIllIlIIIllIlllIlllllIl(substring) + s.substring(iiiIllIIllIIIIllIllIIIlIl + ((char1 == ' ' || char1 == '\n') ? 1 : 0)), n);
    }
    
    private int IIIIllIIllIIIIllIllIIIlIl(final String s, final int n) {
        final int length = s.length();
        float n2 = 0.0f;
        int i = 0;
        int n3 = -1;
        boolean b = false;
        while (i < length) {
            final char char1 = s.charAt(i);
            Label_0167: {
                switch (char1) {
                    case 10: {
                        --i;
                        break Label_0167;
                    }
                    case 167: {
                        if (i < length - 1) {
                            ++i;
                            final char char2 = s.charAt(i);
                            if (char2 != 'l' && char2 != 'L') {
                                if (char2 == 'r' || char2 == 'R' || IlllIIIlIlllIllIlIIlllIlI(char2)) {
                                    b = false;
                                }
                            }
                            else {
                                b = true;
                            }
                        }
                        break Label_0167;
                    }
                    case 32: {
                        n3 = i;
                        break;
                    }
                }
                n2 += this.lIIIIIIIIIlIllIIllIlIIlIl(char1);
                if (b) {
                    ++n2;
                }
            }
            if (char1 == '\n') {
                n3 = ++i;
                break;
            }
            if (n2 > n) {
                break;
            }
            ++i;
        }
        return (i != length && n3 != -1 && n3 < i) ? n3 : i;
    }
    
    private static boolean IlllIIIlIlllIllIlIIlllIlI(final char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }
    
    private static boolean IIIIllIlIIIllIlllIlllllIl(final char c) {
        return (c >= 'k' && c <= 'o') || (c >= 'K' && c <= 'O') || c == 'r' || c == 'R';
    }
    
    private static String IIIIllIlIIIllIlllIlllllIl(final String s) {
        String str = "";
        int index = -1;
        final int length = s.length();
        while ((index = s.indexOf(167, index + 1)) != -1) {
            if (index < length - 1) {
                final char char1 = s.charAt(index + 1);
                if (IlllIIIlIlllIllIlIIlllIlI(char1)) {
                    str = "§" + char1;
                }
                else {
                    if (!IIIIllIlIIIllIlllIlllllIl(char1)) {
                        continue;
                    }
                    str = str + "§" + char1;
                }
            }
        }
        return str;
    }
    
    public boolean isCurrentLanguageBidirectional() {
        return this.IIIlIIllllIIllllllIlIIIll;
    }
    
    protected void unloadSounds() {
        GL11.glEnable(3008);
    }
    
    protected InputStream lIIIIlIIllIIlIIlIIIlIIllI(final ResourceLocation resourceLocation) {
        return Minecraft.getMinecraft().llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation).lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        final long n = this.IllllIllllIlIIIlIIIllllll - 20 * 10;
        final lllllIllIlIIllIIIlllllIIl liiiIlIIllIIlIIlIIIlIIllI = this.lIlIlIllIIIIIIIIllllIIllI.IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI();
        while (liiiIlIIllIIlIIlIIIlIIllI.hasNext()) {
            final lIlIlIllIIIIIIIIllllIIllI lIlIlIllIIIIIIIIllllIIllI = liiiIlIIllIIlIIlIIIlIIllI.next();
            if (lIlIlIllIIIIIIIIllllIIllI.IIIIllIIllIIIIllIllIIIlIl() || lIlIlIllIIIIIIIIllllIIllI.IIIIllIlIIIllIlllIlllllIl() < n) {
                lIlIlIllIIIIIIIIllllIIllI.lIIIIIIIIIlIllIIllIlIIlIl();
                liiiIlIIllIIlIIlIIIlIIllI.remove();
            }
        }
        if (this.IllllIllllIlIIIlIIIllllll % 50L == 0L) {
            this.lIlIlIllIIIIIIIIllllIIllI.lIIIIllIIlIlIllIIIlIllIlI();
        }
        ++this.IllllIllllIlIIIlIIIllllll;
    }
    
    static {
        IllIIIIIIIlIlIllllIIllIII = new ResourceLocation[256];
    }
}
