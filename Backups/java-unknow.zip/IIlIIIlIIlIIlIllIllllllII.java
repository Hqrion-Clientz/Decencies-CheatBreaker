// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIlIIlIIlIllIllllllII extends IIIllIlIIIllIlIIIIlIlllII
{
    private IIlIIlIIllIllllllllIllIII lIIIIlIIllIIlIIlIIIlIIllI;
    private lIlIIIIIlIIIIIIlIIIIIIlll IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIIIlIIlIIlIllIllllllII(final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final IIlIIlIIllIllllllllIllIII liiiIlIIllIIlIIlIIIlIIllI, final lIlIIIIIlIIIIIIlIIIIIIlll ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        final int n = 3;
        liiiIlIIllIIlIIlIIIlIIllI.sendHorseInteraction();
        final int n2 = (n - 4) * 18;
        this.lIIIIIIIIIlIllIIllIlIIlIl(new IlllllIIIllllIIIIIIlIlIll(this, liiiIlIIllIIlIIlIIIlIIllI, 0, 8, 18));
        this.lIIIIIIIIIlIllIIllIlIIlIl(new lIIIlllIIlIllllIlllIIIllI(this, liiiIlIIllIIlIIlIIIlIIllI, 1, 8, 36, ilIlIIIlllIIIlIlllIlIllIl));
        if (ilIlIIIlllIIIlIlllIlIllIl.lIllIlIlIIlIllIllllIllIIl()) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < 5; ++j) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(liiiIlIIllIIlIIlIIIlIIllI, 2 + j + i * 5, 80 + j * 18, 18 + i * 18));
                }
            }
        }
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 9; ++l) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(ilIIlIIllIllllllllIllIII, l + k * 9 + 9, 8 + l * 18, 102 + k * 18 + n2));
            }
        }
        for (int n3 = 0; n3 < 9; ++n3) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(new IlIIIIIlIIIIlIIIIlIlllIlI(ilIIlIIllIllllllllIllIII, n3, 8 + n3 * 18, 160 + n2));
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll) && this.IlIlIIIlllIIIlIlllIlIllIl.IlIlllIIIIlIllIlllIlIIIll() && this.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll) < 8;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n) {
        lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = null;
        final IlIIIIIlIIIIlIIIIlIlllIlI ilIIIIIlIIIIlIIIIlIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI.get(n);
        if (ilIIIIIlIIIIlIIIIlIlllIlI != null && ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl()) {
            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
            llIIlllIIIIlllIllIlIlllIl = liiiIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
            if (n < this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl()) {
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(), this.IlllIIIlIlllIllIlIIlllIlI.size(), true)) {
                    return null;
                }
            }
            else if (this.lIIIIlIIllIIlIIlIIIlIIllI(1).lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && !this.lIIIIlIIllIIlIIlIIIlIIllI(1).lIIIIIIIIIlIllIIllIlIIlIl()) {
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 1, 2, false)) {
                    return null;
                }
            }
            else if (this.lIIIIlIIllIIlIIlIIIlIIllI(0).lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI)) {
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 0, 1, false)) {
                    return null;
                }
            }
            else if (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl() <= 2 || !this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, 2, this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(), false)) {
                return null;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
                ilIIIIIlIIIIlIIIIlIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(null);
            }
            else {
                ilIIIIIlIIIIlIIIIlIlllIlI.IlllIIIlIlllIllIlIIlllIlI();
            }
        }
        return llIIlllIIIIlllIllIlIlllIl;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(lIllIIIIlIIlIllIIIlIlIlll);
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII();
    }
}
