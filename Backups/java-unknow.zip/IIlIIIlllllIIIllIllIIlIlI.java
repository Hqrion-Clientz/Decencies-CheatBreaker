// 
// Decompiled by Procyon v0.5.36
// 

final class IIlIIIlllllIIIllIllIIlIlI extends IIlIlIlllllIlllIllIIIlllI
{
    IIlIIIlllllIIIllIllIIlIlI(final Class clazz, final int n, final int n2) {
        super(clazz, n, n2);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(n) && n > 5;
    }
}
