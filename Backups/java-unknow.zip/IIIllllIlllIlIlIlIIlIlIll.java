import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIlllIlIlIlIIlIlIll extends lIIllllIIlIIlllIlIIllIIIl
{
    public IIIllllIlllIlIlIlIIlIlIll(final boolean b) {
        super(b);
    }
    
    @Override
    public boolean a_(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        final int n4 = random.nextInt(3) + random.nextInt(2) + 6;
        int n5 = 1;
        if (n2 < 1 || n2 + n4 + 1 > 256) {
            return false;
        }
        for (int i = n2; i <= n2 + 1 + n4; ++i) {
            int n6 = 1;
            if (i == n2) {
                n6 = 0;
            }
            if (i >= n2 + 1 + n4 - 2) {
                n6 = 2;
            }
            for (int n7 = n - n6; n7 <= n + n6 && n5 != 0; ++n7) {
                for (int n8 = n3 - n6; n8 <= n3 + n6 && n5 != 0; ++n8) {
                    if (i >= 0 && i < 256) {
                        if (!this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n7, i, n8))) {
                            n5 = 0;
                        }
                    }
                    else {
                        n5 = 0;
                    }
                }
            }
        }
        if (n5 == 0) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3);
        if ((block == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI || block == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl) && n2 < 256 - n4 - 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 - 1, n3, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 - 1, n3 + 1, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3 + 1, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl);
            final int nextInt = random.nextInt(4);
            final int n9 = n4 - random.nextInt(4);
            int n10 = 2 - random.nextInt(3);
            int n11 = n;
            int n12 = n3;
            int n13 = 0;
            for (int j = 0; j < n4; ++j) {
                final int n14 = n2 + j;
                if (j >= n9 && n10 > 0) {
                    n11 += llIllIlIIIlllllIllllllIIl.lIIIIlIIllIIlIIlIIIlIIllI[nextInt];
                    n12 += llIllIlIIIlllllIllllllIIl.lIIIIIIIIIlIllIIllIlIIlIl[nextInt];
                    --n10;
                }
                final IIlllllllIlllIIllllIIlIll block2 = iiiiiIllIlIIIIlIlllIllllI.getBlock(n11, n14, n12);
                if (block2.IlIlIIIlllIIIlIlllIlIllIl() == Material.air || block2.IlIlIIIlllIIIlIlllIlIllIl() == Material.IlllIllIlIIIIlIIlIIllIIIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11, n14, n12, IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI, 1);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + 1, n14, n12, IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI, 1);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11, n14, n12 + 1, IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI, 1);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + 1, n14, n12 + 1, IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI, 1);
                    n13 = n14;
                }
            }
            for (int k = -2; k <= 0; ++k) {
                for (int l = -2; l <= 0; ++l) {
                    final int n15 = -1;
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + k, n13 + n15, n12 + l);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, 1 + n11 - k, n13 + n15, n12 + l);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + k, n13 + n15, 1 + n12 - l);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, 1 + n11 - k, n13 + n15, 1 + n12 - l);
                    if ((k > -2 || l > -1) && (k != -1 || l != -2)) {
                        final int n16 = 1;
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + k, n13 + n16, n12 + l);
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, 1 + n11 - k, n13 + n16, n12 + l);
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + k, n13 + n16, 1 + n12 - l);
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, 1 + n11 - k, n13 + n16, 1 + n12 - l);
                    }
                }
            }
            if (random.nextBoolean()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11, n13 + 2, n12);
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + 1, n13 + 2, n12);
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + 1, n13 + 2, n12 + 1);
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11, n13 + 2, n12 + 1);
            }
            for (int a = -3; a <= 4; ++a) {
                for (int a2 = -3; a2 <= 4; ++a2) {
                    if ((a != -3 || a2 != -3) && (a != -3 || a2 != 4) && (a != 4 || a2 != -3) && (a != 4 || a2 != 4) && (Math.abs(a) < 3 || Math.abs(a2) < 3)) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + a, n13, n12 + a2);
                    }
                }
            }
            for (int n17 = -1; n17 <= 2; ++n17) {
                for (int n18 = -1; n18 <= 2; ++n18) {
                    if ((n17 < 0 || n17 > 1 || n18 < 0 || n18 > 1) && random.nextInt(3) <= 0) {
                        for (int n19 = random.nextInt(3) + 2, n20 = 0; n20 < n19; ++n20) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n + n17, n13 - n20 - 1, n3 + n18, IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI, 1);
                        }
                        for (int n21 = -1; n21 <= 1; ++n21) {
                            for (int n22 = -1; n22 <= 1; ++n22) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + n17 + n21, n13 - 0, n12 + n18 + n22);
                            }
                        }
                        for (int a3 = -2; a3 <= 2; ++a3) {
                            for (int a4 = -2; a4 <= 2; ++a4) {
                                if (Math.abs(a3) != 2 || Math.abs(a4) != 2) {
                                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n11 + n17 + a3, n13 - 1, n12 + n18 + a4);
                                }
                            }
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, IllllllIllIIlllIllIIlIIll.IlIIlIIIIlIIIIllllIIlIllI, 1);
        }
    }
}
