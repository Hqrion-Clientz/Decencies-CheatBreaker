import java.beans.ConstructorProperties;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIlllIllIIllIIIIlIlI extends llIlIIIlIIlIlllIIlIIIIIll
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private double lIIIIIIIIIlIllIIllIlIIlIl;
    private double IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private double IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeDouble(this.lIIIIIIIIIlIllIIllIlIIlIl);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeDouble(this.IlllIIIlIlllIllIlIIlllIlI);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeDouble(this.IIIIllIlIIIllIlllIlllllIl);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeDouble(this.IIIIllIIllIIIIllIllIIIlIl);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeInt(this.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIIllIIIIIlIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readDouble();
        this.IlllIIIlIlllIllIlIIlllIlI = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readDouble();
        this.IIIIllIlIIIllIlllIlllllIl = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readDouble();
        this.IIIIllIIllIIIIllIllIIIlIl = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readDouble();
        this.IlIlIIIlllIIIlIlllIlIllIl = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readInt();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIlIIIlIlIllIIllllII illllIIlIIIlIlIllIIllllII) {
        ((llllIIlIIllIIIlllIlIIIllI)illllIIlIIIlIlIllIIllllII).lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public double IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public double IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public double IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public double IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public IIIIlIIlllIllIIllIIIIlIlI() {
    }
    
    @ConstructorProperties({ "id", "minX", "minZ", "maxX", "maxZ", "durationTicks" })
    public IIIIlIIlllIllIIllIIIIlIlI(final String liiiIlIIllIIlIIlIIIlIIllI, final double liiiiiiiiIlIllIIllIlIIlIl, final double illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl, final double iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
}
