import org.lwjgl.opengl.GL11;
import java.nio.ByteOrder;
import java.awt.image.DataBufferByte;
import java.nio.ByteBuffer;
import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlllIlllIIlllIIllIIlI extends BufferedImage
{
    private ByteBuffer IlllIIIlIlllIllIlIIlllIlI;
    public byte[] lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    private Object IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIIlllIlllIIlllIIllIIlI(final int width, final int height, final int imageType) {
        super(width, height, imageType);
        this.lIIIIIIIIIlIllIIllIlIIlIl = 0;
        this.IIIIllIlIIIllIlllIlllllIl = new Object();
        this.lIIIIlIIllIIlIIlIIIlIIllI = ((DataBufferByte)this.getRaster().getDataBuffer()).getData();
        this.IlllIIIlIlllIllIlIIlllIlI = ByteBuffer.allocateDirect(this.lIIIIlIIllIIlIIlIIIlIIllI.length).order(ByteOrder.nativeOrder());
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != 0) {
            GL11.glDeleteTextures(this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != 0) {
            GL11.glDeleteTextures(this.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl = GL11.glGenTextures();
        }
        this.IlllIIIlIlllIllIlIIlllIlI.clear();
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            this.IlllIIIlIlllIllIlIIlllIlI.put(this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        this.IlllIIIlIlllIllIlIIlllIlI.position(0).limit(this.lIIIIlIIllIIlIIlIIIlIIllI.length);
        if (!IIlIIlllIlIlIlllIIIlIlllI.IIIIllIIllIIIIllIllIIIlIl && !IIlIIlllIlIlIlllIIIlIlllI.IlllIIIlIlllIllIlIIlllIlI) {
            if (IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.IIIlIIllllIIllllllIlIIIll) {
                for (int i = 0; i < this.getWidth(); ++i) {
                    this.IlllIIIlIlllIllIlIIlllIlI.put(i * 4 + 3, (byte)0);
                    this.IlllIIIlIlllIllIlIIlllIlI.put(i * this.getWidth() * 4 + 3, (byte)0);
                }
            }
            if (IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.IIIlIIllllIIllllllIlIIIll && (IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.lIIlllIIlIlllllllllIIIIIl > 0 || lIllIlllllIIlllIIlIlIllII.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl().lIIIIlIIllIIlIIlIIIlIIllI() > 1.0f)) {
                for (int j = 0; j < this.getWidth(); ++j) {
                    this.IlllIIIlIlllIllIlIIlllIlI.put(j * this.getWidth() * 4 + 7, (byte)0);
                }
            }
            if (IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.IIIlIIllllIIllllllIlIIIll && (IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.lIIlllIIlIlllllllllIIIIIl > 0 || lIllIlllllIIlllIIlIlIllII.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl().lIIIIIIIIIlIllIIllIlIIlIl() > 1.0f)) {
                for (int k = 0; k < this.getWidth(); ++k) {
                    this.IlllIIIlIlllIllIlIIlllIlI.put(k * 4 + 3 + this.getWidth() * 4, (byte)0);
                }
            }
        }
        GL11.glBindTexture(3553, this.lIIIIIIIIIlIllIIllIlIIlIl);
        GL11.glTexParameteri(3553, 10241, 9728);
        GL11.glTexParameteri(3553, 10240, 9728);
        GL11.glTexParameteri(3553, 10242, 33071);
        GL11.glTexParameteri(3553, 10243, 33071);
        GL11.glTexImage2D(3553, 0, 6408, this.getWidth(), this.getHeight(), 0, 32993, 5121, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.length; ++i) {
            this.lIIIIlIIllIIlIIlIIIlIIllI[i] = 0;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    @Override
    public void setRGB(final int n, final int n2, final int n3) {
        final int n4 = (n + n2 * this.getWidth()) * 4;
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            final int n5 = n3 >> 24 & 0xFF;
            this.lIIIIlIIllIIlIIlIIIlIIllI[n4] = (byte)((n3 >> 0 & 0xFF) * n5 / 255);
            this.lIIIIlIIllIIlIIlIIIlIIllI[n4 + 1] = (byte)((n3 >> 8 & 0xFF) * n5 / 255);
            this.lIIIIlIIllIIlIIlIIIlIIllI[n4 + 2] = (byte)((n3 >> 16 & 0xFF) * n5 / 255);
            this.lIIIIlIIllIIlIIlIIIlIIllI[n4 + 3] = -1;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            if (n > 0) {
                System.arraycopy(this.lIIIIlIIllIIlIIlIIIlIIllI, n * 4, this.lIIIIlIIllIIlIIlIIIlIIllI, 0, this.lIIIIlIIllIIlIIlIIIlIIllI.length - n * 4);
            }
            else if (n < 0) {
                System.arraycopy(this.lIIIIlIIllIIlIIlIIIlIIllI, 0, this.lIIIIlIIllIIlIIlIIIlIIllI, -n * 4, this.lIIIIlIIllIIlIIlIIIlIIllI.length + n * 4);
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        synchronized (this.IIIIllIlIIIllIlllIlllllIl) {
            if (n > 0) {
                System.arraycopy(this.lIIIIlIIllIIlIIlIIIlIIllI, n * this.getWidth() * 4, this.lIIIIlIIllIIlIIlIIIlIIllI, 0, this.lIIIIlIIllIIlIIlIIIlIIllI.length - n * this.getWidth() * 4);
            }
            else if (n < 0) {
                System.arraycopy(this.lIIIIlIIllIIlIIlIIIlIIllI, 0, this.lIIIIlIIllIIlIIlIIIlIIllI, -n * this.getWidth() * 4, this.lIIIIlIIllIIlIIlIIIlIIllI.length + n * this.getWidth() * 4);
            }
        }
    }
}
