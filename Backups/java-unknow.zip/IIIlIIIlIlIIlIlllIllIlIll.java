// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlIlIIlIlllIllIlIll extends IIllIlllIIlllllIlllIIIlIl
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private String lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    
    public IIIlIIIlIlIIlIlllIllIlIll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
    }
    
    public IIIlIIIlIlIIlIlllIllIlIll(final lIlIlIIllIIIlIlllllIlIIlI lIlIlIIllIIIlIlllllIlIIlI, final int iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIlIIllIIIlIlllllIlIIlI.IIIIllIlIIIllIlllIlllllIl();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIlIIllIIIlIlllllIlIIlI.IlllIIIlIlllIllIlIIlllIlI().lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIlIIllIIIlIlllllIlIIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public IIIlIIIlIlIIlIlllIllIlIll(final String liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.IlllIIIlIlllIllIlIIlllIlI = 0;
        this.IIIIllIlIIIllIlllIlllllIl = 1;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(16);
        this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.readByte();
        if (this.IIIIllIlIIIllIlllIlllllIl != 1) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(16);
            this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readInt();
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IIIIllIlIIIllIlllIlllllIl);
        if (this.IIIIllIlIIIllIlllIlllllIl != 1) {
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl);
            lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
