import java.util.List;
import java.awt.Color;
import org.lwjgl.opengl.GL11;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiIngame extends IlIIIlIIlIIllIllllIlIlIll
{
    private static final ResourceLocation IlllIIIlIlllIllIlIIlllIlI;
    private static final ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private static final ResourceLocation IIIIllIIllIIIIllIllIIIlIl;
    private static final IIIlIllIIlIllIIIIlIIlIlIl IlIlIIIlllIIIlIlllIlIllIl;
    private final Random IIIllIllIlIlllllllIlIlIII;
    private final Minecraft IllIIIIIIIlIlIllllIIllIII;
    private final lIlIlIllIIIlIIlIIlIlllIlI lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private String IlIlllIIIIllIllllIllIIlIl;
    private int IIIlIIllllIIllllllIlIIIll;
    private boolean lllIIIIIlIllIlIIIllllllII;
    public float lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIllllIIIIlIlIIIIlIlI;
    private lIlIlIlIlIllllIlllIIIlIlI IIIIIIlIlIlIllllllIlllIlI;
    public static boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public GuiIngame(final Minecraft illIIIIIIIlIlIllllIIllIII) {
        this.IIIllIllIlIlllllllIlIlIII = new Random();
        this.IlIlllIIIIllIllllIllIIlIl = "";
        this.lIIIIlIIllIIlIIlIIIlIIllI = 1.0f;
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.lIIIIllIIlIlIllIIIlIllIlI = new lIlIlIllIIIlIIlIIlIlllIlI(illIIIIIIIlIlIllllIIllIII);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final boolean b, final int n2, final int n3) {
        final ScaledResolution scaledResolution = new ScaledResolution(this.IllIIIIIIIlIlIllllIIllIII, this.IllIIIIIIIlIlIllllIIllIII.displayWidth, this.IllIIIIIIIlIlIllllIIllIII.displayHeight);
        final int scaledWidth = scaledResolution.getScaledWidth();
        final int scaledHeight = scaledResolution.getScaledHeight();
        final FontRenderer fontRendererObj = this.IllIIIIIIIlIlIllllIIllIII.fontRendererObj;
        this.IllIIIIIIIlIlIllllIIllIII.entityRenderer.lIIIIllIIlIlIllIIIlIllIlI();
        GL11.glEnable(3042);
        if (Minecraft.lIllIlIlllIIlIIllIIlIIlII()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl(n), scaledWidth, scaledHeight);
        }
        else {
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        }
        final lIlIlIlIlIllllIlllIIIlIlI liiiiiiiiIlIllIIllIlIIlIl = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.inventory.lIIIIIIIIIlIllIIllIlIIlIl(3);
        if (this.IllIIIIIIIlIlIllllIIllIII.gameSettings.thirdPersonView == 0 && liiiiiiiiIlIllIIllIlIIlIl != null && liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI() == lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll)) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(scaledWidth, scaledHeight);
        }
        if (!this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IlIlllIIIIllIllllIllIIlIl)) {
            final float n4 = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIlIlIllIIlIIIlIIIlllIII + (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.llIIlllIIIIlllIllIlIlllIl - this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIlIlIllIIlIIIlIIIlllIII) * n;
            if (n4 > 0.0f) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n4, scaledWidth, scaledHeight);
            }
        }
        if (!this.IllIIIIIIIlIlIllllIIllIII.playerController.lIIIIlIIllIIlIIlIIIlIIllI()) {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IIIIllIlIIIllIlllIlllllIl);
            final IllIlIIIIIIllIIIIIllIllIl inventory = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.inventory;
            GuiIngame.llIlIIIlIIIIlIlllIlIIIIll = -90;
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(scaledWidth / 2 - 91, scaledHeight - 22, 0, 0, 182, 22);
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(scaledWidth / 2 - 91 - 1 + inventory.currentItem * 20, scaledHeight - 22 - 1, 0, 22, 24, 22);
            this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IIIlllIIIllIllIlIIIIIIlII);
            GL11.glEnable(3042);
            GL11.glEnable(3008);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(775, 769, 1, 0);
            final IIIIllIlIlIIIlIlIIllllllI ilIlIIIlllIIIlIlllIlIllIl = CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl();
            if (ilIlIIIlllIIIlIlllIlIllIl.lIIIlllIlIlllIIIIIIIIIlII.IIIIllIlIIIllIlllIlllllIl()) {
                GL11.glPushMatrix();
                final float n5 = 1.0f / CheatBreaker.IlllIllIlIIIIlIIlIIllIIIl();
                final int n6 = (int)(scaledWidth / n5);
                final int n7 = (int)(scaledHeight / n5);
                GL11.glScalef(n5, n5, n5);
                final float floatValue = (float)ilIlIIIlllIIIlIlllIlIllIl.llIlIlIllIlIIlIlllIllIIlI.IIIIllIlIIIllIlllIlllllIl();
                final float floatValue2 = (float)ilIlIIIlllIIIlIlllIlIllIl.llIlIlIlllIlllllIIIllIIll.IIIIllIlIIIllIlllIlllllIl();
                final float floatValue3 = (float)ilIlIIIlllIIIlIlllIlIllIl.IlIIIIllIIIIIlllIIlIIlllI.IIIIllIlIIIllIlllIlllllIl();
                final int liiiIlIIllIIlIIlIIIlIIllI = ilIlIIIlllIIIlIlllIlIllIl.IlIllllIIIlIllllIIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI();
                final boolean booleanValue = (boolean)ilIlIIIlllIIIlIlllIlIllIl.IIIIlIIIlllllllllIlllIlll.IIIIllIlIIIllIlllIlllllIl();
                final int n8 = n6 / 2;
                final int n9 = n7 / 2;
                if (booleanValue) {
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(n8 - floatValue2 - floatValue, n9 - floatValue3 / 2.0f, n8 - floatValue2, n9 + floatValue3 / 2.0f, 0.1904762f * 2.625f, -1358954496, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(n8 + floatValue2, n9 - floatValue3 / 2.0f, n8 + floatValue2 + floatValue, n9 + floatValue3 / 2.0f, 5.3333335f * 0.09375f, -1358954496, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(n8 - floatValue3 / 2.0f, n9 - floatValue2 - floatValue, n8 + floatValue3 / 2.0f, n9 - floatValue2, 2.45f * 0.20408162f, -1358954496, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(n8 - floatValue3 / 2.0f, n9 + floatValue2, n8 + floatValue3 / 2.0f, n9 + floatValue2 + floatValue, 0.7395833f * 0.6760564f, -1358954496, liiiIlIIllIIlIIlIIIlIIllI);
                }
                else {
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n8 - floatValue2 - floatValue, n9 - floatValue3 / 2.0f, n8 - floatValue2, n9 + floatValue3 / 2.0f, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n8 + floatValue2, n9 - floatValue3 / 2.0f, n8 + floatValue2 + floatValue, n9 + floatValue3 / 2.0f, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n8 - floatValue3 / 2.0f, n9 - floatValue2 - floatValue, n8 + floatValue3 / 2.0f, n9 - floatValue2, liiiIlIIllIIlIIlIIIlIIllI);
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n8 - floatValue3 / 2.0f, n9 + floatValue2, n8 + floatValue3 / 2.0f, n9 + floatValue2 + floatValue, liiiIlIIllIIlIIlIIIlIIllI);
                }
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
            else {
                IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(scaledWidth / 2 - 7, scaledHeight / 2 - 7, 0, 0, 16, 16);
            }
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("bossHealth");
            this.IIIIllIlIIIllIlllIlllllIl();
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
            if (this.IllIIIIIIIlIlIllllIIllIII.playerController.lIIIIIIIIIlIllIIllIlIIlIl()) {
                this.resize(scaledWidth, scaledHeight);
            }
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("actionBar");
            GL11.glEnable(32826);
            llIlIlllllIIllIIIIllIllII.IlllIIIlIlllIllIlIIlllIlI();
            for (int i = 0; i < 9; ++i) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(i, scaledWidth / 2 - 90 + i * 20 + 2, scaledHeight - 16 - 3, n);
            }
            llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glDisable(32826);
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
            GL11.glDisable(3042);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIlIIIlIIIlllllllllllIlIl() > 0) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("sleep");
            GL11.glDisable(2929);
            GL11.glDisable(3008);
            final int lIlIIIlIIIlllllllllllIlIl = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIlIIIlIIIlllllllllllIlIl();
            float n10 = lIlIIIlIIIlllllllllllIlIl / (float)100;
            if (n10 > 1.0f) {
                n10 = 1.0f - (lIlIIIlIIIlllllllllllIlIl - 100) / (float)10;
            }
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)scaledWidth, (float)scaledHeight, (int)(220 * n10) << 24 | 0x101020);
            GL11.glEnable(3008);
            GL11.glEnable(2929);
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final int n11 = scaledWidth / 2 - 91;
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllllIllllIlIIIlIIIllllll()) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("jumpBar");
            this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IlIIIlIIlIIllIllllIlIlIll.IIIlllIIIllIllIlIIIIIIlII);
            final float illIIlllIllIlIllIlIIIIIII = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIlllIllIlIllIlIIIIIII();
            final int n12 = 182;
            final int n13 = (int)(illIIlllIllIlIllIlIIIIIII * (n12 + 1));
            final int n14 = scaledHeight - 32 + 3;
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n11, n14, 0, 84, n12, 5);
            if (n13 > 0) {
                IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n11, n14, 0, 89, n13, 5);
            }
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        else if (this.IllIIIIIIIlIlIllllIIllIII.playerController.IlIlIIIlllIIIlIlllIlIllIl()) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("expBar");
            this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IlIIIlIIlIIllIllllIlIlIll.IIIlllIIIllIllIlIIIIIIlII);
            if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlIIIIlllIIIlIIllllIIIlll() > 0) {
                final int n15 = 182;
                final int n16 = (int)(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lllIIlIIIllIIlllIlIIIllIl * (n15 + 1));
                final int n17 = scaledHeight - 32 + 3;
                IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n11, n17, 0, 64, n15, 5);
                if (n16 > 0) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n11, n17, 0, 69, n16, 5);
                }
            }
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
            if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIIIIlllIIIlIIIlIIIlI > 0) {
                this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("expLevel");
                final int n18 = false ? 16777215 : 8453920;
                final String string = "" + this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIIIIlllIIIlIIIlIIIlI;
                final int n19 = (scaledWidth - fontRendererObj.getStringWidth(string)) / 2;
                final int n20 = scaledHeight - 31 - 4;
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(string, n19 + 1, n20, 0);
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(string, n19 - 1, n20, 0);
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(string, n19, n20 + 1, 0);
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(string, n19, n20 - 1, 0);
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(string, n19, n20, n18);
                this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
            }
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.gameSettings.llllIIllllllIlIIlIlIIIllI) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("toolHighlight");
            if (this.lIIIIIllllIIIIlIlIIIIlIlI > 0 && this.IIIIIIlIlIlIllllllIlllIlI != null) {
                final String iiiiiIlIlIlIllllllIlllIlI = this.IIIIIIlIlIlIllllllIlllIlI.IIIIIIlIlIlIllllllIlllIlI();
                final int n21 = (scaledWidth - fontRendererObj.getStringWidth(iiiiiIlIlIlIllllllIlllIlI)) / 2;
                int n22 = scaledHeight - 59;
                if (!this.IllIIIIIIIlIlIllllIIllIII.playerController.lIIIIIIIIIlIllIIllIlIIlIl()) {
                    n22 += 14;
                }
                int n23 = (int)(this.lIIIIIllllIIIIlIlIIIIlIlI * (float)256 / 10);
                if (n23 > 255) {
                    n23 = 255;
                }
                if (n23 > 0) {
                    GL11.glPushMatrix();
                    GL11.glEnable(3042);
                    OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                    fontRendererObj.drawStringWithShadow(iiiiiIlIlIlIllllllIlllIlI, (float)n21, (float)n22, 16777215 + (n23 << 24));
                    GL11.glDisable(3042);
                    GL11.glPopMatrix();
                }
            }
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.lIIlllIIlIlllllllllIIIIIl()) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("demo");
            String s;
            if (this.IllIIIIIIIlIlIllllIIllIII.theWorld.IlIIlIIIIlIIIIllllIIlIllI() >= 120500L) {
                s = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("demo.demoExpired", new Object[0]);
            }
            else {
                s = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("demo.remainingTime", IlIIllllIIlIIIIIIllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI((int)(120500L - this.IllIIIIIIIlIlIllllIIllIII.theWorld.IlIIlIIIIlIIIIllllIIlIllI())));
            }
            fontRendererObj.drawStringWithShadow(s, (float)(scaledWidth - fontRendererObj.getStringWidth(s) - 10), 5, 16777215);
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.gameSettings.showDebugInfo) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("debug");
            GL11.glPushMatrix();
            fontRendererObj.drawStringWithShadow("Minecraft 1.7.10 (" + this.IllIIIIIIIlIlIllllIIllIII.debug + ")", 2.0f, 2.0f, 16777215);
            fontRendererObj.drawStringWithShadow(this.IllIIIIIIIlIlIllllIIllIII.IIIIIIlIlIlIllllllIlllIlI(), 2.0f, 12, 16777215);
            fontRendererObj.drawStringWithShadow(this.IllIIIIIIIlIlIllllIIllIII.IllIllIIIlIIlllIIIllIllII(), 2.0f, 22, 16777215);
            fontRendererObj.drawStringWithShadow(this.IllIIIIIIIlIlIllllIIllIII.lIIlIIllIIIIIlIllIIIIllII(), 2.0f, 32, 16777215);
            fontRendererObj.drawStringWithShadow(this.IllIIIIIIIlIlIllllIIllIII.IlIIlIIIIlIIIIllllIIlIllI(), 2.0f, 42, 16777215);
            final long maxMemory = Runtime.getRuntime().maxMemory();
            final long totalMemory = Runtime.getRuntime().totalMemory();
            final long n24 = totalMemory - Runtime.getRuntime().freeMemory();
            final String string2 = "Used memory: " + n24 * 100L / maxMemory + "% (" + n24 / 1024L / 1024L + "MB) of " + maxMemory / 1024L / 1024L + "MB";
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, string2, scaledWidth - fontRendererObj.getStringWidth(string2) - 2, 2, 14737632);
            final String string3 = "Allocated memory: " + totalMemory * 100L / maxMemory + "% (" + totalMemory / 1024L / 1024L + "MB)";
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, string3, scaledWidth - fontRendererObj.getStringWidth(string3) - 2, 12, 14737632);
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIlIIIIlllIIllIIlllIIlI);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIlIlIllllIlIIllllIIlll);
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, String.format("x: %.5f (%d) // c: %d (%d)", this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IIIlIIlIlIIIlllIIlIllllll, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI >> 4, illlIIIlIlllIllIlIIlllIlI & 0xF), 2, 64, 14737632);
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, String.format("y: %.3f (feet pos, %.3f eyes pos)", this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl, this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIlIIIIlllIIllIIlllIIlI), 2, 72, 14737632);
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, String.format("z: %.5f (%d) // c: %d (%d)", this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIlIlIllllIlIIllllIIlll, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI3 >> 4, illlIIIlIlllIllIlIIlllIlI3 & 0xF), 2, 80, 14737632);
            final int j = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllllIllllIlIIIlIIIllllll * 4 / 360 + 0.07894736643973485 * 6.333333492279053) & 0x3;
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, "f: " + j + " (" + llIllIlIIIlllllIllllllIIl.IlllIIIlIlllIllIlIIlllIlI[j] + ") / " + MathHelper.IIIllIllIlIlllllllIlIlIII(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllllIllllIlIIIlIIIllllll), 2, 88, 14737632);
            if (this.IllIIIIIIIlIlIllllIIllIII.theWorld != null && this.IllIIIIIIIlIlIllllIIllIII.theWorld.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3)) {
                final lIlllllIIllIlIlIlllIIIIII iiiIllIlIIIllIlllIlllllIl = this.IllIIIIIIIlIlIllllIIllIII.theWorld.IIIIllIlIIIllIlllIlllllIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI3);
                this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, "lc: " + (iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() + 15) + " b: " + iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI & 0xF, illlIIIlIlllIllIlIIlllIlI3 & 0xF, this.IllIIIIIIIlIlIllllIIllIII.theWorld.lIIIIllIIlIlIllIIIlIllIlI()).lllIIllllIIlIlIlIlIIIlIII + " bl: " + iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI & 0xF, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3 & 0xF) + " sl: " + iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI, illlIIIlIlllIllIlIIlllIlI & 0xF, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3 & 0xF) + " rl: " + iiiIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI & 0xF, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3 & 0xF, 0), 2, 96, 14737632);
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, String.format("ws: %.3f, fs: %.3f, g: %b, fl: %d", this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(), this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlllIIIllIlIlIIIllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(), this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlllIIlIlllllIlIllIII, this.IllIIIIIIIlIlIllllIIllIII.theWorld.IlIlIIIlllIIIlIlllIlIllIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI3)), 2, 104, 14737632);
            if (this.IllIIIIIIIlIlIllllIIllIII.entityRenderer != null && this.IllIIIIIIIlIlIllllIIllIII.entityRenderer.isCurrentLocaleUnicode()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(fontRendererObj, String.format("shader: %s", this.IllIIIIIIIlIlIllllIIllIII.entityRenderer.IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl()), 2, 112, 14737632);
            }
            GL11.glPopMatrix();
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        if (GuiIngame.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IllIIIIIIIlIlIllllIIllIII.fontRendererObj.drawStringWithShadow("Uploading screenshot...", 4, (float)(scaledResolution.getScaledHeight() - 24), -1);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.currentScreen instanceof lIIlIlIIlIlIlIIlIlIlllIIl || this.IllIIIIIIIlIlIllllIIllIII.currentScreen instanceof IIIlllllIIlIlIIIllllllIII) {
            CheatBreaker.getInstance().getEventBus().callEvent(new lIllIlIlllIIlIIllIIlIIlII(scaledResolution));
        }
        CheatBreaker.getInstance().getEventBus().callEvent(new llIlIIIllIIIIlllIlIIIIIlI(scaledResolution));
        if (!this.IllIIIIIIIlIlIllllIIllIII.gameSettings.showDebugInfo || (boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlllIIlllIIIIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl()) {
            CheatBreaker.getInstance().getEventBus().callEvent(new lIllIllIlIIllIllIlIlIIlIl(scaledResolution));
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.currentScreen == null) {
            IlllllIllIIIllIIIllIllIII.llIlIIIlIIIIlIlllIlIIIIll().setIngameFocus();
        }
        if (this.IIIlIIllllIIllllllIlIIIll > 0) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("overlayMessage");
            final float n25 = this.IIIlIIllllIIllllllIlIIIll - n;
            int n26 = (int)(n25 * 255 / 20);
            if (n26 > 255) {
                n26 = 255;
            }
            if (n26 > 8) {
                GL11.glPushMatrix();
                GL11.glTranslatef((float)(scaledWidth / 2), (float)(scaledHeight - 68), 0.0f);
                GL11.glEnable(3042);
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                int n27 = 16777215;
                if (this.lllIIIIIlIllIlIIIllllllII) {
                    n27 = (Color.HSBtoRGB(n25 / 50, 2.94f * 0.23809524f, 0.7111111f * 0.84375f) & 0xFFFFFF);
                }
                fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlllIIIIllIllllIllIIlIl, -fontRendererObj.getStringWidth(this.IlIlllIIIIllIllllIllIIlIl) / 2, -4, n27 + (n26 << 24 & 0xFF000000));
                GL11.glDisable(3042);
                GL11.glPopMatrix();
            }
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        }
        this.IllIIIIIIIlIlIllllIIllIII.theWorld.IllIIlllIllIlIllIlIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(1);
        GL11.glEnable(3042);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        GL11.glDisable(3008);
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, (float)(scaledHeight - 48), 0.0f);
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("chat");
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl);
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
        GL11.glPopMatrix();
        final IIlIlIlIlIllIlIllIIllIIII liiiIlIIllIIlIIlIIIlIIllI2 = this.IllIIIIIIIlIlIllllIIllIII.theWorld.IllIIlllIllIlIllIlIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(0);
        if (this.IllIIIIIIIlIlIllllIIllIII.gameSettings.IIIIIlllIllIIIIllIllIIIII.getIsKeyPressed() && (!this.IllIIIIIIIlIlIllllIIllIII.IllllIllllIlIIIlIIIllllll() || this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl.size() > 1 || liiiIlIIllIIlIIlIIIlIIllI2 != null)) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("playerList");
            final lIIIIIlIlIIIIIIIlIlIlllIl liiiiiiiiIlIllIIllIlIIlIl2 = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIIIIIIlIllIIllIlIIlIl;
            final List liiiiiiiiIlIllIIllIlIIlIl3 = liiiiiiiiIlIllIIllIlIIlIl2.lIIIIIIIIIlIllIIllIlIIlIl;
            int k;
            int n28;
            int n29;
            for (n28 = (k = liiiiiiiiIlIllIIllIlIIlIl2.IlllIIIlIlllIllIlIIlllIlI), n29 = 1; k > 20; k = (n28 + n29 - 1) / n29) {
                ++n29;
            }
            int n30 = 300 / n29;
            if (n30 > 150) {
                n30 = 150;
            }
            final int n31 = (scaledWidth - n29 * n30) / 2;
            final int n32 = 15;
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n31 - 1), (float)(n32 - 1), (float)(n31 + n30 * n29), (float)(n32 + 9 * k), Integer.MIN_VALUE);
            for (int l = 0; l < n28; ++l) {
                final int n33 = n31 + l % n29 * n30;
                final int n34 = n32 + l / n29 * 9;
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)n33, (float)n34, (float)(n33 + n30 - 1), (float)(n34 + 8), 553648127);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glEnable(3008);
                if (l < liiiiiiiiIlIllIIllIlIIlIl3.size()) {
                    final llIIlIllllllIllIIIIlIlIIl llIIlIllllllIllIIIIlIlIIl = liiiiiiiiIlIllIIllIlIIlIl3.get(l);
                    final String liiiIlIIllIIlIIlIIIlIIllI3 = lIIllllIllIIllIlIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.theWorld.IllIIlllIllIlIllIlIIIIIII().IIIllIllIlIlllllllIlIlIII(llIIlIllllllIllIIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI), llIIlIllllllIllIIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI);
                    fontRendererObj.drawStringWithShadow(liiiIlIIllIIlIIlIIIlIIllI3, (float)n33, (float)n34, 16777215);
                    if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                        final int n35 = n33 + fontRendererObj.getStringWidth(liiiIlIIllIIlIIlIIIlIIllI3) + 5;
                        final int n36 = n33 + n30 - 12 - 5;
                        if (n36 - n35 > 5) {
                            final String string4 = IlIllllIIlIIllIlIlllllIlI.llIlIIIlIIIIlIlllIlIIIIll + "" + liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(llIIlIllllllIllIIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2).lIIIIIIIIIlIllIIllIlIIlIl();
                            fontRendererObj.drawStringWithShadow(string4, (float)(n36 - fontRendererObj.getStringWidth(string4)), (float)n34, 16777215);
                        }
                    }
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl > 0) {
                        this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IIIlllIIIllIllIlIIIIIIlII);
                        final int n37 = 0;
                        int n38;
                        if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl < 0) {
                            n38 = 5;
                        }
                        else if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl < 150) {
                            n38 = 0;
                        }
                        else if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl < 300) {
                            n38 = 1;
                        }
                        else if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl < 600) {
                            n38 = 2;
                        }
                        else if (llIIlIllllllIllIIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl < 1000) {
                            n38 = 3;
                        }
                        else {
                            n38 = 4;
                        }
                        GuiIngame.llIlIIIlIIIIlIlllIlIIIIll += 100;
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n33 + n30 - 12, n34, 0 + n37 * 10, 176 + n38 * 8, 10, 8);
                        GuiIngame.llIlIIIlIIIIlIlllIlIIIIll -= 100;
                    }
                }
            }
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(2896);
        GL11.glEnable(3008);
    }
    
    private void resize(final int n, final int n2) {
        boolean b = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIlIIlIllIllIIllllIIl / 3 % 2 == 1;
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIlIIlIllIllIIllllIIl < 10) {
            b = false;
        }
        final int ilIlIIIlllIIIlIlllIlIllIl = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.getHealth());
        final int ilIlIIIlllIIIlIlllIlIllIl2 = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIlIIIIIIlIIlIIlIIlIIlI);
        this.IIIllIllIlIlllllllIlIlIII.setSeed(this.IlllIllIlIIIIlIIlIIllIIIl * 312871);
        final boolean b2 = false;
        final IIIIllIIllIIIlIlllllllIlI illIIIIIllllIlllIIlIIllIl = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIIIllllIlllIIlIIllIl();
        final int liiiIlIIllIIlIIlIIIlIIllI = illIIIIIllllIlllIIlIIllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        final int liiiiiiiiIlIllIIllIlIIlIl = illIIIIIllllIlllIIlIIllIl.lIIIIIIIIIlIllIIllIlIIlIl();
        final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI2 = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI);
        final int n3 = n / 2 - 91;
        final int n4 = n / 2 + 91;
        final int n5 = n2 - 39;
        final float n6 = (float)liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIIllIIIIllIllIIIlIl();
        final float illIIIIIIlllIIIlIIIlIIIlI = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIIIIlllIIIlIIIlIIIlI();
        final int ilIlIIIlllIIIlIlllIlIllIl3 = MathHelper.IlIlIIIlllIIIlIlllIlIllIl((n6 + illIIIIIIlllIIIlIIIlIIIlI) / 2.0f / 10);
        final int max = Math.max(10 - (ilIlIIIlllIIIlIlllIlIllIl3 - 2), 3);
        final int n7 = n5 - (ilIlIIIlllIIIlIlllIlIllIl3 - 1) * max - 10;
        float n8 = illIIIIIIlllIIIlIIIlIIIlI;
        final int ilIIlllIIlIlIIIlIlllllIll = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlIIlllIIlIlIIIlIlllllIll();
        int n9 = -1;
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl)) {
            n9 = this.IlllIllIlIIIIlIIlIIllIIIl % MathHelper.IlIlIIIlllIIIlIlllIlIllIl(n6 + 5);
        }
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.startSection("armor");
        for (int i = 0; i < 10; ++i) {
            if (ilIIlllIIlIlIIIlIlllllIll > 0) {
                final int n10 = n3 + i * 8;
                if (i * 2 + 1 < ilIIlllIIlIlIIIlIlllllIll) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n10, n7, 34, 9, 9, 9);
                }
                if (i * 2 + 1 == ilIIlllIIlIlIIIlIlllllIll) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n10, n7, 25, 9, 9, 9);
                }
                if (i * 2 + 1 > ilIIlllIIlIlIIIlIlllllIll) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n10, n7, 16, 9, 9, 9);
                }
            }
        }
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endStartSection("health");
        for (int j = MathHelper.IlIlIIIlllIIIlIlllIlIllIl((n6 + illIIIIIIlllIIIlIIIlIIIlI) / 2.0f) - 1; j >= 0; --j) {
            int n11 = 16;
            if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI)) {
                n11 += 36;
            }
            else if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lIIlIIllIIIIIlIllIIIIllII)) {
                n11 += 72;
            }
            int n12 = 0;
            if (b) {
                n12 = 1;
            }
            final int n13 = MathHelper.IlIlIIIlllIIIlIlllIlIllIl((j + 1) / (float)10) - 1;
            final int n14 = n3 + j % 10 * 8;
            int n15 = n5 - n13 * max;
            if (ilIlIIIlllIIIlIlllIlIllIl <= 4) {
                n15 += this.IIIllIllIlIlllllllIlIlIII.nextInt(2);
            }
            if (j == n9) {
                n15 -= 2;
            }
            int n16 = 0;
            if (this.IllIIIIIIIlIlIllllIIllIII.theWorld.lIllIlIlllIIlIIllIIlIIlII().IllIllIIIlIIlllIIIllIllII()) {
                n16 = 5;
            }
            IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, 16 + n12 * 9, 9 * n16, 9, 9);
            if (b) {
                if (j * 2 + 1 < ilIlIIIlllIIIlIlllIlIllIl2) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 54, 9 * n16, 9, 9);
                }
                if (j * 2 + 1 == ilIlIIIlllIIIlIlllIlIllIl2) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 63, 9 * n16, 9, 9);
                }
            }
            if (n8 > 0.0f) {
                if (n8 == illIIIIIIlllIIIlIIIlIIIlI && illIIIIIIlllIIIlIIIlIIIlI % 2.0f == 1.0f) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 153, 9 * n16, 9, 9);
                }
                else {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 144, 9 * n16, 9, 9);
                }
                n8 -= 2.0f;
            }
            else {
                if (j * 2 + 1 < ilIlIIIlllIIIlIlllIlIllIl) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 36, 9 * n16, 9, 9);
                }
                if (j * 2 + 1 == ilIlIIIlllIIIlIlllIlIllIl) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n14, n15, n11 + 45, 9 * n16, 9, 9);
                }
            }
        }
        final Entity ilIIlIIIIlIIIIllllIIlIllI = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlIIlIIIIlIIIIllllIIlIllI;
        if (ilIIlIIIIlIIIIllllIIlIllI == null) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endStartSection("food");
            for (int k = 0; k < 10; ++k) {
                int n17 = n5;
                int n18 = 16;
                int n19 = 0;
                if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IIIIIIlIlIlIllllllIlllIlI)) {
                    n18 += 36;
                    n19 = 13;
                }
                if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IllIIIIIllllIlllIIlIIllIl().IIIIllIlIIIllIlllIlllllIl() <= 0.0f && this.IlllIllIlIIIIlIIlIIllIIIl % (liiiIlIIllIIlIIlIIIlIIllI * 3 + 1) == 0) {
                    n17 = n5 + (this.IIIllIllIlIlllllllIlIlIII.nextInt(3) - 1);
                }
                if (b2) {
                    n19 = 1;
                }
                final int n20 = n4 - k * 8 - 9;
                IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n20, n17, 16 + n19 * 9, 27, 9, 9);
                if (b2) {
                    if (k * 2 + 1 < liiiiiiiiIlIllIIllIlIIlIl) {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n20, n17, n18 + 54, 27, 9, 9);
                    }
                    if (k * 2 + 1 == liiiiiiiiIlIllIIllIlIIlIl) {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n20, n17, n18 + 63, 27, 9, 9);
                    }
                }
                if (k * 2 + 1 < liiiIlIIllIIlIIlIIIlIIllI) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n20, n17, n18 + 36, 27, 9, 9);
                }
                if (k * 2 + 1 == liiiIlIIllIIlIIlIIIlIIllI) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n20, n17, n18 + 45, 27, 9, 9);
                }
            }
        }
        else if (ilIIlIIIIlIIIIllllIIlIllI instanceof EntityLivingBase) {
            this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endStartSection("mountHealth");
            final EntityLivingBase entityLivingBase = (EntityLivingBase)ilIIlIIIIlIIIIllllIIlIllI;
            final int n21 = (int)Math.ceil(entityLivingBase.getHealth());
            int l = (int)(entityLivingBase.IlllIIllllllllIlIlIlllllI() + 1.2307693f * 0.40625f) / 2;
            if (l > 30) {
                l = 30;
            }
            int n22 = n5;
            int n23 = 0;
            while (l > 0) {
                final int min = Math.min(l, 10);
                l -= min;
                for (int n24 = 0; n24 < min; ++n24) {
                    final int n25 = 52;
                    int n26 = 0;
                    if (b2) {
                        n26 = 1;
                    }
                    final int n27 = n4 - n24 * 8 - 9;
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n27, n22, n25 + n26 * 9, 9, 9, 9);
                    if (n24 * 2 + 1 + n23 < n21) {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n27, n22, n25 + 36, 9, 9, 9);
                    }
                    if (n24 * 2 + 1 + n23 == n21) {
                        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n27, n22, n25 + 45, 9, 9, 9);
                    }
                }
                n22 -= 10;
                n23 += 20;
            }
        }
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endStartSection("air");
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer.lIIIIlIIllIIlIIlIIIlIIllI(Material.IllIIIIIIIlIlIllllIIllIII)) {
            final int ilIllIllIllIllIllllIIIlII = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.IlIllIllIllIllIllllIIIlII();
            for (int ilIlIIIlllIIIlIlllIlIllIl4 = MathHelper.IlIlIIIlllIIIlIlllIlIllIl((ilIllIllIllIllIllllIIIlII - 2) * (double)10 / 300), n28 = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(ilIllIllIllIllIllllIIIlII * (double)10 / 300) - ilIlIIIlllIIIlIlllIlIllIl4, n29 = 0; n29 < ilIlIIIlllIIIlIlllIlIllIl4 + n28; ++n29) {
                if (n29 < ilIlIIIlllIIIlIlllIlIllIl4) {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 - n29 * 8 - 9, n7, 16, 18, 9, 9);
                }
                else {
                    IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4 - n29 * 8 - 9, n7, 25, 18, 9, 9);
                }
            }
        }
        this.IllIIIIIIIlIlIllllIIllIII.mcProfiler.endSection();
    }
    
    private void IIIIllIlIIIllIlllIlllllIl() {
        if (llIIIllIIllIIIllIlllIlllI.IlllIIIlIlllIllIlIIlllIlI != null && llIIIllIIllIIIllIlllIlllI.lIIIIIIIIIlIllIIllIlIIlIl > 0) {
            this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IIIlllIIIllIllIlIIIIIIlII);
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3008);
        this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IIIIllIIllIIIIllIllIIIlIl);
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        instance.addVertexWithUV(0.0, n2, -90, 0.0, 1.0);
        instance.addVertexWithUV(n, n2, -90, 1.0, 1.0);
        instance.addVertexWithUV(n, 0.0, -90, 1.0, 0.0);
        instance.addVertexWithUV(0.0, 0.0, -90, 0.0, 0.0);
        instance.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(float n, final int n2, final int n3) {
        n = 1.0f - n;
        if (n < 0.0f) {
            n = 0.0f;
        }
        if (n > 1.0f) {
            n = 1.0f;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI += (float)((n - this.lIIIIlIIllIIlIIlIIIlIIllI) * (0.01863636277800753 * 0.5365853905677795));
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(0, 769, 1, 0);
        GL11.glColor4f(this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIlIIllIIlIIlIIIlIIllI, 1.0f);
        this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiIngame.IlllIIIlIlllIllIlIIlllIlI);
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        instance.addVertexWithUV(0.0, n3, -90, 0.0, 1.0);
        instance.addVertexWithUV(n2, n3, -90, 1.0, 1.0);
        instance.addVertexWithUV(n2, 0.0, -90, 1.0, 0.0);
        instance.addVertexWithUV(0.0, 0.0, -90, 0.0, 0.0);
        instance.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(float n, final int n2, final int n3) {
        if (n < 1.0f) {
            n *= n;
            n *= n;
            n = n * (1.1111112f * 0.71999997f) + 0.3846154f * 0.52f;
        }
        GL11.glDisable(3008);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, n);
        final IlllIllIIIIlllIllIIIIIlII iiiIllIlIIIllIlllIlllllIl = IllllllIllIIlllIllIIlIIll.IlIlIIIlllIlIllIlIIIlllIl.IIIIllIlIIIllIlllIlllllIl(1);
        this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(TextureMap.locationBlocksTexture);
        final float illlIIIlIlllIllIlIIlllIlI = iiiIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI();
        final float iiiIllIIllIIIIllIllIIIlIl = iiiIllIlIIIllIlllIlllllIl.IIIIllIIllIIIIllIllIIIlIl();
        final float iiiIllIlIIIllIlllIlllllIl2 = iiiIllIlIIIllIlllIlllllIl.IIIIllIlIIIllIlllIlllllIl();
        final float ilIlIIIlllIIIlIlllIlIllIl = iiiIllIlIIIllIlllIlllllIl.IlIlIIIlllIIIlIlllIlIllIl();
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        instance.addVertexWithUV(0.0, n3, -90, illlIIIlIlllIllIlIIlllIlI, ilIlIIIlllIIIlIlllIlIllIl);
        instance.addVertexWithUV(n2, n3, -90, iiiIllIlIIIllIlllIlllllIl2, ilIlIIIlllIIIlIlllIlIllIl);
        instance.addVertexWithUV(n2, 0.0, -90, iiiIllIlIIIllIlllIlllllIl2, iiiIllIIllIIIIllIllIIIlIl);
        instance.addVertexWithUV(0.0, 0.0, -90, illlIIIlIlllIllIlIIlllIlI, iiiIllIIllIIIIllIllIIIlIl);
        instance.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final float n4) {
        final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.inventory.lIIIIlIIllIIlIIlIIIlIIllI[n];
        if (lIlIlIlIlIllllIlllIIIlIlI != null) {
            final float n5 = lIlIlIlIlIllllIlllIIIlIlI.IlllIIIlIlllIllIlIIlllIlI - n4;
            if (n5 > 0.0f) {
                GL11.glPushMatrix();
                final float n6 = 1.0f + n5 / 5;
                GL11.glTranslatef((float)(n2 + 8), (float)(n3 + 12), 0.0f);
                GL11.glScalef(1.0f / n6, (n6 + 1.0f) / 2.0f, 1.0f);
                GL11.glTranslatef((float)(-(n2 + 8)), (float)(-(n3 + 12)), 0.0f);
            }
            GuiIngame.IlIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IllIIIIIIIlIlIllllIIllIII.fontRendererObj, this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI(), lIlIlIlIlIllllIlllIIIlIlI, n2, n3);
            if (n5 > 0.0f) {
                GL11.glPopMatrix();
            }
            GuiIngame.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI(this.IllIIIIIIIlIlIllllIIllIII.fontRendererObj, this.IllIIIIIIIlIlIllllIIllIII.llIlIlIllIlIIlIlllIllIIlI(), lIlIlIlIlIllllIlllIIIlIlI, n2, n3);
        }
    }
    
    public void updateTick() {
        if (this.IIIlIIllllIIllllllIlIIIll > 0) {
            --this.IIIlIIllllIIllllllIlIIIll;
        }
        ++this.IlllIllIlIIIIlIIlIIllIIIl;
        if (this.IllIIIIIIIlIlIllllIIllIII.thePlayer != null) {
            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.IllIIIIIIIlIlIllllIIllIII.thePlayer.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                this.lIIIIIllllIIIIlIlIIIIlIlI = 0;
            }
            else if (this.IIIIIIlIlIlIllllllIlllIlI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI() && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, this.IIIIIIlIlIlIllllllIlllIlI) && (liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() || liiiIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl() == this.IIIIIIlIlIlIllllllIlllIlI.IlllIllIlIIIIlIIlIIllIIIl())) {
                if (this.lIIIIIllllIIIIlIlIIIIlIlI > 0) {
                    --this.lIIIIIllllIIIIlIlIIIIlIlI;
                }
            }
            else {
                this.lIIIIIllllIIIIlIlIIIIlIlI = 40;
            }
            this.IIIIIIlIlIlIllllllIlllIlI = liiiIlIIllIIlIIlIIIlIIllI;
        }
    }
    
    public void setSection(final String s) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("record.nowPlaying", s), true);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String ilIlllIIIIllIllllIllIIlIl, final boolean lllIIIIIlIllIlIIIllllllII) {
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        this.IIIlIIllllIIllllllIlIIIll = 60;
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
    }
    
    public lIlIlIllIIIlIIlIIlIlllIlI getChatGUI() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = new ResourceLocation("textures/misc/vignette.png");
        IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("textures/gui/widgets.png");
        IIIIllIIllIIIIllIllIIIlIl = new ResourceLocation("textures/misc/pumpkinblur.png");
        IlIlIIIlllIIIlIlllIlIllIl = new IIIlIllIIlIllIIIIlIIlIlIl();
        GuiIngame.lIIIIIIIIIlIllIIllIlIIlIl = false;
    }
}
