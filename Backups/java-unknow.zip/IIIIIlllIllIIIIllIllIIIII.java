import java.util.function.Consumer;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlllIllIIIIllIllIIIII extends IlIIIIlllIIIlIIllllIIIlll
{
    private final lIlIIIIIIlIllIlIllIlIlIlI lIIIIIIIIIlIllIIllIlIIlIl;
    public static llIllllIIIIIlIllIlIIIllIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    public lIlIIIIIIlIllIlIllIlIlIlI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public IIIIIlllIllIIIIllIllIIIII() {
        super("Zans Minimap");
        this.lIIIIIIIIIlIllIIllIlIIlIl(false);
        this.IIIlIIlIlIIIlllIIlIllllll = false;
        this.lIIIIIIIIIlIllIIllIlIIlIl(CBGuiAnchor.RIGHT_TOP);
        this.lIIIIIIIIIlIllIIllIlIIlIl = new lIlIIIIIIlIllIlIllIlIlIlI(true, true);
        this.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("client/icons/mods/zans.png"), 42, 42);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIllIlIIllIllIlIlIIlIl.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        if (IIIIIlllIllIIIIllIllIIIII.lIIIIlIIllIIlIIlIIIlIIllI == llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI) {
            CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("Error", "&4Minimap &fis not allowed on this server. Some functions may not work.", 4000L);
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIllIlIIllIllIlIlIIlIl lIllIllIlIIllIllIlIlIIlIl) {
        final float n = 1.0f / CheatBreaker.IlllIllIlIIIIlIIlIIllIIIl();
        switch (this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().lIllIlIlllIIlIIllIIlIIlII) {
            case 0: {
                if (this.llIlIIIlIIIIlIlllIlIIIIll() != CBGuiAnchor.LEFT_TOP) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(CBGuiAnchor.LEFT_TOP);
                    break;
                }
                break;
            }
            case 1: {
                if (this.llIlIIIlIIIIlIlllIlIIIIll() != CBGuiAnchor.RIGHT_TOP) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(CBGuiAnchor.RIGHT_TOP);
                    break;
                }
                break;
            }
            case 2: {
                if (this.llIlIIIlIIIIlIlllIlIIIIll() != CBGuiAnchor.RIGHT_BOTTOM) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(CBGuiAnchor.RIGHT_BOTTOM);
                    break;
                }
                break;
            }
            case 3: {
                if (this.llIlIIIlIIIIlIlllIlIIIIll() != CBGuiAnchor.LEFT_BOTTOM) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(CBGuiAnchor.LEFT_BOTTOM);
                    break;
                }
                break;
            }
        }
        switch (this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().llIlIIIllIIIIlllIlIIIIIlI) {
            case -1: {
                this.lIIIIlIIllIIlIIlIIIlIIllI((float)(int)(-5 * n), (float)(int)(5 * n));
                this.IlllIIIlIlllIllIlIIlllIlI((float)(int)(100 * n), (float)(int)(100 * n));
                break;
            }
            case 0: {
                this.lIIIIlIIllIIlIIlIIIlIIllI((float)(int)(-5 * n), (float)(int)(5 * n));
                this.IlllIIIlIlllIllIlIIlllIlI((float)(int)(135 * n), (float)(int)(135 * n));
                break;
            }
            case 1: {
                this.lIIIIlIIllIIlIIlIIIlIIllI((float)(int)(-5 * n), (float)(int)(5 * n));
                this.IlllIIIlIlllIllIlIIlllIlI((float)(int)(175 * n), (float)(int)(175 * n));
                break;
            }
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(Minecraft.getMinecraft());
    }
    
    static {
        IIIIIlllIllIIIIllIllIIIII.lIIIIlIIllIIlIIlIIIlIIllI = llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI;
    }
}
