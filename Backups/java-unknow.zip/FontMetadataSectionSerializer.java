import com.google.gson.JsonObject;
import org.apache.commons.lang3.Validate;
import com.google.gson.JsonParseException;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;

// 
// Decompiled by Procyon v0.5.36
// 

public class FontMetadataSectionSerializer extends IIlIIllIIIIlIIIlIIlllIlll
{
    public FontMetadataSection lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) {
        final JsonObject asJsonObject = jsonElement.getAsJsonObject();
        final float[] array = new float[256];
        final float[] array2 = new float[256];
        final float[] array3 = new float[256];
        float liiiIlIIllIIlIIlIIIlIIllI = 1.0f;
        float liiiIlIIllIIlIIlIIIlIIllI2 = 0.0f;
        float liiiIlIIllIIlIIlIIIlIIllI3 = 0.0f;
        if (asJsonObject.has("characters")) {
            if (!asJsonObject.get("characters").isJsonObject()) {
                throw new JsonParseException("Invalid font->characters: expected object, was " + asJsonObject.get("characters"));
            }
            final JsonObject asJsonObject2 = asJsonObject.getAsJsonObject("characters");
            if (asJsonObject2.has("default")) {
                if (!asJsonObject2.get("default").isJsonObject()) {
                    throw new JsonParseException("Invalid font->characters->default: expected object, was " + asJsonObject2.get("default"));
                }
                final JsonObject asJsonObject3 = asJsonObject2.getAsJsonObject("default");
                liiiIlIIllIIlIIlIIIlIIllI = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(asJsonObject3, "width", liiiIlIIllIIlIIlIIIlIIllI);
                Validate.inclusiveBetween((Object)0.0f, (Object)(1.8560855E38f * 1.8333334f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI, "Invalid default width", new Object[0]);
                liiiIlIIllIIlIIlIIIlIIllI2 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(asJsonObject3, "spacing", liiiIlIIllIIlIIlIIIlIIllI2);
                Validate.inclusiveBetween((Object)0.0f, (Object)(2.229436E38f * 1.5263158f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI2, "Invalid default spacing", new Object[0]);
                liiiIlIIllIIlIIlIIIlIIllI3 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(asJsonObject3, "left", liiiIlIIllIIlIIlIIIlIIllI2);
                Validate.inclusiveBetween((Object)0.0f, (Object)(3.2305289E38f * 1.0533333f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI3, "Invalid default left", new Object[0]);
            }
            for (int i = 0; i < 256; ++i) {
                final JsonElement value = asJsonObject2.get(Integer.toString(i));
                float liiiIlIIllIIlIIlIIIlIIllI4 = liiiIlIIllIIlIIlIIIlIIllI;
                float liiiIlIIllIIlIIlIIIlIIllI5 = liiiIlIIllIIlIIlIIIlIIllI2;
                float liiiIlIIllIIlIIlIIIlIIllI6 = liiiIlIIllIIlIIlIIIlIIllI3;
                if (value != null) {
                    final JsonObject iiiIllIIllIIIIllIllIIIlIl = llIlllIllIllIIIlllIIIIlll.IIIIllIIllIIIIllIllIIIlIl(value, "characters[" + i + "]");
                    liiiIlIIllIIlIIlIIIlIIllI4 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "width", liiiIlIIllIIlIIlIIIlIIllI);
                    Validate.inclusiveBetween((Object)0.0f, (Object)(3.1875f * 1.0675525E38f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI4, "Invalid width", new Object[0]);
                    liiiIlIIllIIlIIlIIIlIIllI5 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "spacing", liiiIlIIllIIlIIlIIIlIIllI2);
                    Validate.inclusiveBetween((Object)0.0f, (Object)(3.1901468E38f * 1.0666667f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI5, "Invalid spacing", new Object[0]);
                    liiiIlIIllIIlIIlIIIlIIllI6 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "left", liiiIlIIllIIlIIlIIIlIIllI3);
                    Validate.inclusiveBetween((Object)0.0f, (Object)(1.0930233f * 3.1132213E38f), (Comparable)liiiIlIIllIIlIIlIIIlIIllI6, "Invalid left", new Object[0]);
                }
                array[i] = liiiIlIIllIIlIIlIIIlIIllI4;
                array2[i] = liiiIlIIllIIlIIlIIIlIIllI5;
                array3[i] = liiiIlIIllIIlIIlIIIlIIllI6;
            }
        }
        return new FontMetadataSection(array, array3, array2);
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "font";
    }
}
