// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIIlIIIIIIlIlIlllllI
{
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIllllllllllIIIllIlIl lIllIIllllllllllIIIllIlIl) {
        lIllIIllllllllllIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlIIlIlIIIlllIIlIllllll), IllllllIllIIlllIllIIlIIll.IlIIIIllIIIIIlllIIlIIlllI, IllllllIllIIlllIllIIlIIll.llIlIlIllIlIIlIlllIllIIlI, IIlIlIllIlIIllIllIllIIIll.lIllIlIlllIIlIIllIIlIIlII);
        lIllIIllllllllllIIIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlllIllIlIIllIIllIlIlll, 8), "#X#", 'X', new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIllIllIllllllIllIlllIlIl, 1, 3), '#', IIlIlIllIlIIllIllIllIIIll.IlIllllIIIlIllllIIIIIllII);
        lIllIIllllllllllIIIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.lIIIIIIlIIllIlIlIllIIIIll), "MMM", "MMM", "MMM", 'M', IIlIlIllIlIIllIllIllIIIll.lIIIIIIlIIllIlIlIllIIIIll);
        lIllIIllllllllllIIIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lllIllIlIllIlIllIIIIIIlll), "M", 'M', IIlIlIllIlIIllIllIllIIIll.lIIIIIIlIIllIlIlIllIIIIll);
        lIllIIllllllllllIIIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.lIIlIIIllIIlllIlllIlIIlll, 4), "M", 'M', IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll);
        lIllIIllllllllllIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IllIIIIIIlllIIIlIIIlIIIlI), IllllllIllIIlllIllIIlIIll.IllIlIlllIIlIIIIIlIIIIIll, IIlIlIllIlIIllIllIllIIIll.lIlllIIlllIllIlllIIllllIl, IIlIlIllIlIIllIllIllIIIll.IllIlIlllIIlIIIIIlIIIIIll);
        lIllIIllllllllllIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlllIIIIlllllIlIlllllIlll), IIlIlIllIlIIllIllIllIIIll.llIIllllIlIlIllIlIllIlIlI, IllllllIllIIlllIllIIlIIll.IlIIIIllIIIIIlllIIlIIlllI, IIlIlIllIlIIllIllIllIIIll.lIlllIIlllIllIlllIIllllIl);
        lIllIIllllllllllIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IIIlIllIIllllIIIllllIllll, 2), IIlIlIllIlIIllIllIllIIIll.IlIIlIllIllllIIlIllllIlII);
        lIllIIllllllllllIIIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llllIIIllllllIlllIIlIIlll), IIlIlIllIlIIllIllIllIIIll.IIIlIllIIllllIIIllllIllll, IIlIlIllIlIIllIllIllIIIll.llllIIllIIlllllIlIlIIllll);
    }
}
