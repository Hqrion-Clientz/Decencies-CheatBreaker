// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIlIllIlIIlllIlIIIl extends lIIlllIIIlIllllllIlIlIIII
{
    @Override
    public boolean llIIlllIIIIlllIllIlIlllIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl == 1;
    }
    
    @Override
    public int llIlIIIlIIIIlIlllIlIIIIll() {
        return 1;
    }
}
