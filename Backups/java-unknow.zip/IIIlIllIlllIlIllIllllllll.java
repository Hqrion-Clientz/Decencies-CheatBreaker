import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllIlllIlIllIllllllll extends llllIIIIlIlIllIIIllllIIll
{
    private final lIlIllIlIlIIIllllIlIllIll IIIllIllIlIlllllllIlIlIII;
    private String IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    private boolean llIIlllIIIIlllIllIlIlllIl;
    private boolean lIIlIlIllIIlIIIlIIIlllIII;
    private boolean IIIlllIIIllIllIlIIIIIIlII;
    private int llIlIIIlIIIIlIlllIlIIIIll;
    private int IIIlIIllllIIllllllIlIIIll;
    private int lllIIIIIlIllIlIIIllllllII;
    private int lIIIIIllllIIIIlIlIIIIlIlI;
    private int IIIIIIlIlIlIllllllIlllIlI;
    private boolean IllIllIIIlIIlllIIIllIllII;
    private final int IlIIlIIIIlIIIIllllIIlIllI;
    private final int lIIlIIllIIIIIlIllIIIIllII;
    private final String lIIlllIIlIlllllllllIIIIIl;
    
    public IIIlIllIlllIlIllIllllllll(final lIlIllIlIlIIIllllIlIllIll iiIllIllIlIlllllllIlIlIII, final String liIlllIIlIlllllllllIIIIIl, final int ilIIlIIIIlIIIIllllIIlIllI, final int liIlIIllIIIIIlIllIIIIllII) {
        this.IllIIIIIIIlIlIllllIIllIII = "";
        this.lIIIIllIIlIlIllIIIlIllIlI = 32;
        this.IlIlllIIIIllIllllIllIIlIl = true;
        this.llIIlllIIIIlllIllIlIlllIl = true;
        this.IIIlllIIIllIllIlIIIIIIlII = true;
        this.lIIIIIllllIIIIlIlIIIIlIlI = 14737632;
        this.IIIIIIlIlIlIllllllIlllIlI = 7368816;
        this.IllIllIIIlIIlllIIIllIllII = true;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.lIIlllIIlIlllllllllIIIIIl = liIlllIIlIlllllllllIIIIIl;
        this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
        this.lIIlIIllIIIIIlIllIIIIllII = liIlIIllIIIIIlIllIIIIllII;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII() {
        ++this.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String illIIIIIIIlIlIllllIIllIII) {
        if (illIIIIIIIlIlIllllIIllIII.length() > this.lIIIIllIIlIlIllIIIlIllIlI) {
            this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII.substring(0, this.lIIIIllIIlIlIllIIIlIllIlI);
        }
        else {
            this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        }
        this.llIIlllIIIIlllIllIlIlllIl();
    }
    
    public String lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public String IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IllIIIIIIIlIlIllllIIllIII.substring((this.IIIlIIllllIIllllllIlIIIll < this.lllIIIIIlIllIlIIIllllllII) ? this.IIIlIIllllIIllllllIlIIIll : this.lllIIIIIlIllIlIIIllllllII, (this.IIIlIIllllIIllllllIlIIIll < this.lllIIIIIlIllIlIIIllllllII) ? this.lllIIIIIlIllIlIIIllllllII : this.IIIlIIllllIIllllllIlIIIll);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        String string = "";
        final String liiiIlIIllIIlIIlIIIlIIllI = IIlllIllIlIllIllIIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(s);
        final int endIndex = (this.IIIlIIllllIIllllllIlIIIll < this.lllIIIIIlIllIlIIIllllllII) ? this.IIIlIIllllIIllllllIlIIIll : this.lllIIIIIlIllIlIIIllllllII;
        final int beginIndex = (this.IIIlIIllllIIllllllIlIIIll < this.lllIIIIIlIllIlIIIllllllII) ? this.lllIIIIIlIllIlIIIllllllII : this.IIIlIIllllIIllllllIlIIIll;
        final int endIndex2 = this.lIIIIllIIlIlIllIIIlIllIlI - this.IllIIIIIIIlIlIllllIIllIII.length() - (endIndex - this.lllIIIIIlIllIlIIIllllllII);
        if (this.IllIIIIIIIlIlIllllIIllIII.length() > 0) {
            string += this.IllIIIIIIIlIlIllllIIllIII.substring(0, endIndex);
        }
        String s2;
        int length;
        if (endIndex2 < liiiIlIIllIIlIIlIIIlIIllI.length()) {
            s2 = string + liiiIlIIllIIlIIlIIIlIIllI.substring(0, endIndex2);
            length = endIndex2;
        }
        else {
            s2 = string + liiiIlIIllIIlIIlIIIlIIllI;
            length = liiiIlIIllIIlIIlIIIlIIllI.length();
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.length() > 0 && beginIndex < this.IllIIIIIIIlIlIllllIIllIII.length()) {
            s2 += this.IllIIIIIIIlIlIllllIIllIII.substring(beginIndex);
        }
        this.IllIIIIIIIlIlIllllIIllIII = s2;
        this.IIIIllIlIIIllIlllIlllllIl(endIndex - this.lllIIIIIlIllIlIIIllllllII + length);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (this.IllIIIIIIIlIlIllllIIllIII.length() != 0) {
            if (this.lllIIIIIlIllIlIIIllllllII != this.IIIlIIllllIIllllllIlIIIll) {
                this.lIIIIIIIIIlIllIIllIlIIlIl("");
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) - this.IIIlIIllllIIllllllIlIIIll);
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        if (this.IllIIIIIIIlIlIllllIIllIII.length() != 0) {
            if (this.lllIIIIIlIllIlIIIllllllII != this.IIIlIIllllIIllllllIlIIIll) {
                this.lIIIIIIIIIlIllIIllIlIIlIl("");
            }
            else {
                final boolean b = n < 0;
                final int endIndex = b ? (this.IIIlIIllllIIllllllIlIIIll + n) : this.IIIlIIllllIIllllllIlIIIll;
                final int beginIndex = b ? this.IIIlIIllllIIllllllIlIIIll : (this.IIIlIIllllIIllllllIlIIIll + n);
                String s = "";
                if (endIndex >= 0) {
                    s = this.IllIIIIIIIlIlIllllIIllIII.substring(0, endIndex);
                }
                if (beginIndex < this.IllIIIIIIIlIlIllllIIllIII.length()) {
                    s += this.IllIIIIIIIlIlIllllIIllIII.substring(beginIndex);
                }
                this.IllIIIIIIIlIlIllllIIllIII = s;
                if (b) {
                    this.IIIIllIlIIIllIlllIlllllIl(n);
                }
            }
        }
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, this.llIlIIIlIIIIlIlllIlIIIIll());
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, this.llIlIIIlIIIIlIlllIlIIIIll(), true);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int a, final int n, final boolean b) {
        int index = n;
        final boolean b2 = a < 0;
        for (int abs = Math.abs(a), i = 0; i < abs; ++i) {
            if (b2) {
                while (b && index > 0 && this.IllIIIIIIIlIlIllllIIllIII.charAt(index - 1) == ' ') {
                    --index;
                }
                while (index > 0 && this.IllIIIIIIIlIlIllllIIllIII.charAt(index - 1) != ' ') {
                    --index;
                }
            }
            else {
                final int length = this.IllIIIIIIIlIlIllllIIllIII.length();
                index = this.IllIIIIIIIlIlIllllIIllIII.indexOf(32, index);
                if (index == -1) {
                    index = length;
                }
                else {
                    while (b && index < length && this.IllIIIIIIIlIlIllllIIllIII.charAt(index) == ' ') {
                        ++index;
                    }
                }
            }
        }
        return index;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n) {
        this.IIIIllIIllIIIIllIllIIIlIl(this.lllIIIIIlIllIlIIIllllllII + n);
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final int iiIlIIllllIIllllllIlIIIll) {
        this.IIIlIIllllIIllllllIlIIIll = iiIlIIllllIIllllllIlIIIll;
        final int length = this.IllIIIIIIIlIlIllllIIllIII.length();
        if (this.IIIlIIllllIIllllllIlIIIll < 0) {
            this.IIIlIIllllIIllllllIlIIIll = 0;
        }
        if (this.IIIlIIllllIIllllllIlIIIll > length) {
            this.IIIlIIllllIIllllllIlIIIll = length;
        }
        this.lIIIIllIIlIlIllIIIlIllIlI(this.IIIlIIllllIIllllllIlIIIll);
    }
    
    public void IlIlllIIIIllIllllIllIIlIl() {
        this.IIIIllIIllIIIIllIllIIIlIl(0);
    }
    
    public void llIIlllIIIIlllIllIlIlllIl() {
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIIIIIIlIlIllllIIllIII.length());
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final char c, final int n) {
        if (!this.lIIlIlIllIIlIIIlIIIlllIII) {
            return false;
        }
        switch (c) {
            case '\u0001': {
                this.llIIlllIIIIlllIllIlIlllIl();
                this.lIIIIllIIlIlIllIIIlIllIlI(0);
                return true;
            }
            case '\u0003': {
                GuiScreen.IlllIIIlIlllIllIlIIlllIlI(this.IlllIllIlIIIIlIIlIIllIIIl());
                return true;
            }
            case '\u0016': {
                if (this.IIIlllIIIllIllIlIIIIIIlII) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(GuiScreen.IIIIIIlIlIlIllllllIlllIlI());
                }
                return true;
            }
            case '\u0018': {
                GuiScreen.IlllIIIlIlllIllIlIIlllIlI(this.IlllIllIlIIIIlIIlIIllIIIl());
                if (this.IIIlllIIIllIllIlIIIIIIlII) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl("");
                }
                return true;
            }
            default: {
                switch (n) {
                    case 14: {
                        if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            if (this.IIIlllIIIllIllIlIIIIIIlII) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(-1);
                            }
                        }
                        else if (this.IIIlllIIIllIllIlIIIIIIlII) {
                            this.lIIIIIIIIIlIllIIllIlIIlIl(-1);
                        }
                        return true;
                    }
                    case 199: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            this.lIIIIllIIlIlIllIIIlIllIlI(0);
                        }
                        else {
                            this.IlIlllIIIIllIllllIllIIlIl();
                        }
                        return true;
                    }
                    case 203: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.lIIIIIllllIIIIlIlIIIIlIlI()));
                            }
                            else {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIIllllIIIIlIlIIIIlIlI() - 1);
                            }
                        }
                        else if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            this.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(-1));
                        }
                        else {
                            this.IIIIllIlIIIllIlllIlllllIl(-1);
                        }
                        return true;
                    }
                    case 205: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI(1, this.lIIIIIllllIIIIlIlIIIIlIlI()));
                            }
                            else {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIIllllIIIIlIlIIIIlIlI() + 1);
                            }
                        }
                        else if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            this.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(1));
                        }
                        else {
                            this.IIIIllIlIIIllIlllIlllllIl(1);
                        }
                        return true;
                    }
                    case 207: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            this.lIIIIllIIlIlIllIIIlIllIlI(this.IllIIIIIIIlIlIllllIIllIII.length());
                        }
                        else {
                            this.llIIlllIIIIlllIllIlIlllIl();
                        }
                        return true;
                    }
                    case 211: {
                        if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            if (this.IIIlllIIIllIllIlIIIIIIlII) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(1);
                            }
                        }
                        else if (this.IIIlllIIIllIllIlIIIIIIlII) {
                            this.lIIIIIIIIIlIllIIllIlIIlIl(1);
                        }
                        return true;
                    }
                    default: {
                        if (IIlllIllIlIllIllIIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(c)) {
                            if (this.IIIlllIIIllIllIlIIIIIIlII) {
                                this.lIIIIIIIIIlIllIIllIlIIlIl(Character.toString(c));
                            }
                            return true;
                        }
                        return false;
                    }
                }
                break;
            }
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final int n3, final boolean b) {
        if (!b) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(false);
            return true;
        }
        if (n3 == 1 && this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI("");
        }
        final boolean b2 = n >= this.lIIIIlIIllIIlIIlIIIlIIllI && n < this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI && n2 >= this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl;
        if (this.llIIlllIIIIlllIllIlIlllIl) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(b2);
        }
        if (this.lIIlIlIllIIlIIIlIIIlllIII && n3 == 0) {
            float n4 = n - this.lIIIIlIIllIIlIIlIIIlIIllI;
            if (this.IlIlllIIIIllIllllIllIIlIl) {
                n4 -= 4;
            }
            this.IIIIllIIllIIIIllIllIIIlIl(this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.substring(this.llIlIIIlIIIIlIlllIlIIIIll), this.IIIIIIlIlIlIllllllIlllIlI()), n4).length() + this.llIlIIIlIIIIlIlllIlIIIIll);
        }
        return false;
    }
    
    public void lIIlIlIllIIlIIIlIIIlllIII() {
        if (this.IllIllIIIlIIlllIIIllIllII()) {
            if (this.IIIlIIllllIIllllllIlIIIll()) {
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl, this.IlIIlIIIIlIIIIllllIIlIllI);
            }
            final int n = this.IIIlllIIIllIllIlIIIIIIlII ? this.lIIIIIllllIIIIlIlIIIIlIlI : this.IIIIIIlIlIlIllllllIlllIlI;
            final int n2 = this.IIIlIIllllIIllllllIlIIIll - this.llIlIIIlIIIIlIlllIlIIIIll;
            int length = this.lllIIIIIlIllIlIIIllllllII - this.llIlIIIlIIIIlIlllIlIIIIll;
            final String liiiIlIIllIIlIIlIIIlIIllI = this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.substring(this.llIlIIIlIIIIlIlllIlIIIIll), this.IIIIIIlIlIlIllllllIlllIlI());
            final boolean b = n2 >= 0 && n2 <= liiiIlIIllIIlIIlIIIlIIllI.length();
            final boolean b2 = this.lIIlIlIllIIlIIIlIIIlllIII && this.IlllIllIlIIIIlIIlIIllIIIl / 6 % 2 == 0 && b;
            final float n3 = this.IlIlllIIIIllIllllIllIIlIl ? (this.lIIIIlIIllIIlIIlIIIlIIllI + 4) : this.lIIIIlIIllIIlIIlIIIlIIllI;
            final float n4 = this.IlIlllIIIIllIllllIllIIlIl ? (this.lIIIIIIIIIlIllIIllIlIIlIl + (this.IIIIllIlIIIllIlllIlllllIl - 8) / 2.0f) : this.lIIIIIIIIIlIllIIllIlIIlIl;
            float liiiIlIIllIIlIIlIIIlIIllI2 = n3;
            if (length > liiiIlIIllIIlIIlIIIlIIllI.length()) {
                length = liiiIlIIllIIlIIlIIIlIIllI.length();
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.length() > 0) {
                liiiIlIIllIIlIIlIIIlIIllI2 = this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(b ? liiiIlIIllIIlIIlIIIlIIllI.substring(0, n2) : liiiIlIIllIIlIIlIIIlIIllI, n3, (double)n4, n);
            }
            else if (!this.lllIIIIIlIllIlIIIllllllII()) {
                this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, n3, (double)n4, n);
            }
            final boolean b3 = this.IIIlIIllllIIllllllIlIIIll < this.IllIIIIIIIlIlIllllIIllIII.length() || this.IllIIIIIIIlIlIllllIIllIII.length() >= this.IIIlllIIIllIllIlIIIIIIlII();
            float n5 = liiiIlIIllIIlIIlIIIlIIllI2;
            if (!b) {
                n5 = ((n2 > 0) ? (n3 + this.IlllIIIlIlllIllIlIIlllIlI) : n3);
            }
            else if (b3) {
                n5 = liiiIlIIllIIlIIlIIIlIIllI2 - 1.0f;
                --liiiIlIIllIIlIIlIIIlIIllI2;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.length() > 0 && b && n2 < liiiIlIIllIIlIIlIIIlIIllI.length()) {
                this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.substring(n2), liiiIlIIllIIlIIlIIIlIIllI2, (double)n4, n);
            }
            if (b2) {
                if (b3) {
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(n5, n4 - 1.0f, n5 + 1.0f, n4 + 1.0f + this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(), -3092272);
                }
                else {
                    this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI("_", n5, (double)n4, n);
                }
            }
            if (length != n2) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n5, n4 - 1.0f + 2.0f, n3 + this.IIIllIllIlIlllllllIlIlIII.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI.substring(0, length)) - 1.0f, n4 + 1.0f + this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI() + 2.0f);
            }
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(float n, float n2, float n3, float n4) {
        if (n < n3) {
            final float n5 = n;
            n = n3;
            n3 = n5;
        }
        if (n2 < n4) {
            final float n6 = n2;
            n2 = n4;
            n4 = n6;
        }
        if (n3 > this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI) {
            n3 = this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI;
        }
        if (n > this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI) {
            n = this.lIIIIlIIllIIlIIlIIIlIIllI + this.IlllIIIlIlllIllIlIIlllIlI;
        }
        final Tessellator instance = Tessellator.instance;
        GL11.glColor4f(0.0f, 0.0f, (float)255, (float)255);
        GL11.glDisable(3553);
        GL11.glEnable(3058);
        GL11.glLogicOp(5387);
        instance.startDrawingQuads();
        instance.addVertex(n, n4, 0.0);
        instance.addVertex(n3, n4, 0.0);
        instance.addVertex(n3, n2, 0.0);
        instance.addVertex(n, n2, 0.0);
        instance.draw();
        GL11.glDisable(3058);
        GL11.glEnable(3553);
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        this.lIIIIllIIlIlIllIIIlIllIlI = n;
        if (this.IllIIIIIIIlIlIllllIIllIII.length() > n) {
            this.IllIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII.substring(0, n);
        }
    }
    
    public int IIIlllIIIllIllIlIIIIIIlII() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public int llIlIIIlIIIIlIlllIlIIIIll() {
        return this.IIIlIIllllIIllllllIlIIIll;
    }
    
    public boolean IIIlIIllllIIllllllIlIIIll() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean ilIlllIIIIllIllllIllIIlIl) {
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final int liiiiIllllIIIIlIlIIIIlIlI) {
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int iiiiiIlIlIlIllllllIlllIlI) {
        this.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean liIlIlIllIIlIIIlIIIlllIII) {
        if (liIlIlIllIIlIIIlIIIlllIII && !this.lIIlIlIllIIlIIIlIIIlllIII) {
            this.IlllIllIlIIIIlIIlIIllIIIl = 0;
        }
        this.lIIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII;
    }
    
    public boolean lllIIIIIlIllIlIIIllllllII() {
        return this.lIIlIlIllIIlIIIlIIIlllIII;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final boolean iiIlllIIIllIllIlIIIIIIlII) {
        this.IIIlllIIIllIllIlIIIIIIlII = iiIlllIIIllIllIlIIIIIIlII;
    }
    
    public int lIIIIIllllIIIIlIlIIIIlIlI() {
        return this.lllIIIIIlIllIlIIIllllllII;
    }
    
    public float IIIIIIlIlIlIllllllIlllIlI() {
        return this.IIIlIIllllIIllllllIlIIIll() ? (this.IlllIIIlIlllIllIlIIlllIlI - 8) : this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(int lllIIIIIlIllIlIIIllllllII) {
        final int length = this.IllIIIIIIIlIlIllllIIllIII.length();
        if (lllIIIIIlIllIlIIIllllllII > length) {
            lllIIIIIlIllIlIIIllllllII = length;
        }
        if (lllIIIIIlIllIlIIIllllllII < 0) {
            lllIIIIIlIllIlIIIllllllII = 0;
        }
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        if (this.IIIllIllIlIlllllllIlIlIII != null) {
            if (this.llIlIIIlIIIIlIlllIlIIIIll > length) {
                this.llIlIIIlIIIIlIlllIlIIIIll = length;
            }
            final float iiiiiIlIlIlIllllllIlllIlI = this.IIIIIIlIlIlIllllllIlllIlI();
            final int n = this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII.substring(this.llIlIIIlIIIIlIlllIlIIIIll), iiiiiIlIlIlIllllllIlllIlI).length() + this.llIlIIIlIIIIlIlllIlIIIIll;
            if (lllIIIIIlIllIlIIIllllllII == this.llIlIIIlIIIIlIlllIlIIIIll) {
                this.llIlIIIlIIIIlIlllIlIIIIll -= this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, iiiiiIlIlIlIllllllIlllIlI, true).length();
            }
            if (lllIIIIIlIllIlIIIllllllII > n) {
                this.llIlIIIlIIIIlIlllIlIIIIll += lllIIIIIlIllIlIIIllllllII - n;
            }
            else if (lllIIIIIlIllIlIIIllllllII <= this.llIlIIIlIIIIlIlllIlIIIIll) {
                this.llIlIIIlIIIIlIlllIlIIIIll -= this.llIlIIIlIIIIlIlllIlIIIIll - lllIIIIIlIllIlIIIllllllII;
            }
            if (this.llIlIIIlIIIIlIlllIlIIIIll < 0) {
                this.llIlIIIlIIIIlIlllIlIIIIll = 0;
            }
            if (this.llIlIIIlIIIIlIlllIlIIIIll > length) {
                this.llIlIIIlIIIIlIlllIlIIIIll = length;
            }
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final boolean llIIlllIIIIlllIllIlIlllIl) {
        this.llIIlllIIIIlllIllIlIlllIl = llIIlllIIIIlllIllIlIlllIl;
    }
    
    public boolean IllIllIIIlIIlllIIIllIllII() {
        return this.IllIllIIIlIIlllIIIllIllII;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final boolean illIllIIIlIIlllIIIllIllII) {
        this.IllIllIIIlIIlllIIIllIllII = illIllIIIlIIlllIIIllIllII;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IllIIIIIIIlIlIllllIIllIII();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final boolean b) {
        this.lIIlIlIllIIlIIIlIIIlllIII();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(c, n);
    }
}
