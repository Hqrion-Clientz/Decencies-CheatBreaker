import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIllIllIlIIIIIIlIll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "xp";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.xp.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length <= 0) {
            throw new IIllllIlIlIIlllIlIIllIIll("commands.xp.usage", new Object[0]);
        }
        String substring = array[0];
        final boolean b = substring.endsWith("l") || substring.endsWith("L");
        if (b && substring.length() > 1) {
            substring = substring.substring(0, substring.length() - 1);
        }
        int liiiIlIIllIIlIIlIIIlIIllI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, substring);
        final boolean b2 = liiiIlIIllIIlIIlIIIlIIllI < 0;
        if (b2) {
            liiiIlIIllIIlIIlIIIlIIllI *= -1;
        }
        llIIIIIIlIlllllIIllllIlII llIIIIIIlIlllllIIllllIlII;
        if (array.length > 1) {
            llIIIIIIlIlllllIIllllIlII = IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[1]);
        }
        else {
            llIIIIIIlIlllllIIllllIlII = IlIIIllllllIllIlllllIIllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII);
        }
        if (b) {
            if (b2) {
                llIIIIIIlIlllllIIllllIlII.IlIIlIIIIlIIIIllllIIlIllI(-liiiIlIIllIIlIIlIIIlIIllI);
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.xp.success.negative.levels", liiiIlIIllIIlIIlIIIlIIllI, llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII());
            }
            else {
                llIIIIIIlIlllllIIllllIlII.IlIIlIIIIlIIIIllllIIlIllI(liiiIlIIllIIlIIlIIIlIIllI);
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.xp.success.levels", liiiIlIIllIIlIIlIIIlIIllI, llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII());
            }
        }
        else {
            if (b2) {
                throw new IIllllIlIlIIlllIlIIllIIll("commands.xp.failure.widthdrawXp", new Object[0]);
            }
            llIIIIIIlIlllllIIllllIlII.IllIllIIIlIIlllIIIllIllII(liiiIlIIllIIlIIlIIIlIIllI);
            IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.xp.success", liiiIlIIllIIlIIlIIIlIIllI, llIIIIIIlIlllllIIllllIlII.IlIlIIIlllllIIIlIlIlIllII());
        }
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 2) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl()) : null;
    }
    
    protected String[] IIIIllIlIIIllIlllIlllllIl() {
        return llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 1;
    }
}
