import org.apache.logging.log4j.LogManager;
import java.util.Collections;
import java.io.FilenameFilter;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutput;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class AnvilSaveConverter extends IllllIlIIIIlllllIIIIllllI
{
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    
    public AnvilSaveConverter(final File file) {
        super(file);
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "Anvil";
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null && this.lIIIIlIIllIIlIIlIIIlIIllI.exists() && this.lIIIIlIIllIIlIIlIIIlIIllI.isDirectory()) {
            final ArrayList<IlIlIlIIIIIIllIIIlllIIIIl> list = new ArrayList<IlIlIlIIIIIIllIIIlllIIIIl>();
            File[] listFiles;
            for (int length = (listFiles = this.lIIIIlIIllIIlIIlIIIlIIllI.listFiles()).length, i = 0; i < length; ++i) {
                final File file = listFiles[i];
                if (file.isDirectory()) {
                    final String name = file.getName();
                    final IllIlIlllIIIIIIlIIllIIIll illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(name);
                    if (illlIIIlIlllIllIlIIlllIlI != null && (illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl() == 19132 || illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl() == 19133)) {
                        final boolean b = illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl() != this.IlllIIIlIlllIllIlIIlllIlI();
                        String ilIlllIIIIllIllllIllIIlIl = illlIIIlIlllIllIlIIlllIlI.IlIlllIIIIllIllllIllIIlIl();
                        if (ilIlllIIIIllIllllIllIIlIl == null || MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(ilIlllIIIIllIllllIllIIlIl)) {
                            ilIlllIIIIllIllllIllIIlIl = name;
                        }
                        list.add(new IlIlIlIIIIIIllIIIlllIIIIl(name, ilIlllIIIIllIllllIllIIlIl, illlIIIlIlllIllIlIIlllIlI.lIIlIlIllIIlIIIlIIIlllIII(), 0L, illlIIIlIlllIllIlIIlllIlI.lIIIIIllllIIIIlIlIIIIlIlI(), b, illlIIIlIlllIllIlIIlllIlI.IllIllIIIlIIlllIIIllIllII(), illlIIIlIlllIllIlIIlllIlI.lIIlIIllIIIIIlIllIIIIllII()));
                    }
                }
            }
            return list;
        }
        throw new lIlIlllllIllIllIIlIllIIll("Unable to read or access folder where game worlds are saved!");
    }
    
    protected int IlllIIIlIlllIllIlIIlllIlI() {
        return 19133;
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
        llIlIIIIIIlIlIlIlIlIIlIll.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    @Override
    public IIIlIIIllIIIlIlllIlIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final String s, final boolean b) {
        return new llllllIllIIIIlllIIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI, s, b);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        final IllIlIlllIIIIIIlIIllIIIll illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(s);
        return illlIIIlIlllIllIlIIlllIlI != null && illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl() == 19132;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        final IllIlIlllIIIIIIlIIllIIIll illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(s);
        return illlIIIlIlllIllIlIIlllIlI != null && illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl() != this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String child, final IlIllIlllllllIlIlllIIlIlI ilIllIlllllllIlIlllIIlIlI) {
        ilIllIlllllllIlIlllIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(0);
        final ArrayList list = new ArrayList();
        final ArrayList list2 = new ArrayList();
        final ArrayList list3 = new ArrayList();
        final File parent = new File(this.lIIIIlIIllIIlIIlIIIlIIllI, child);
        final File parent2 = new File(parent, "DIM-1");
        final File parent3 = new File(parent, "DIM1");
        AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.info("Scanning folders...");
        this.lIIIIlIIllIIlIIlIIIlIIllI(parent, list);
        if (parent2.exists()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(parent2, list2);
        }
        if (parent3.exists()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(parent3, list3);
        }
        final int i = list.size() + list2.size() + list3.size();
        AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.info("Total conversion count is " + i);
        final IllIlIlllIIIIIIlIIllIIIll illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(child);
        IIlIllIIlIlIIIlIlIllIIIlI ilIllIIlIlIIIlIlIllIIIlI;
        if (illlIIIlIlllIllIlIIlllIlI.IlIIlIIIIlIIIIllllIIlIllI() == IlIlIlIIlllIIIlIIllllIlII.IlllIIIlIlllIllIlIIlllIlI) {
            ilIllIIlIlIIIlIlIllIIIlI = new IlIIlIllIIIIIIllIIIIlllIl(IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll, 0.31034482f * 1.6111112f);
        }
        else {
            ilIllIIlIlIIIlIlIllIIIlI = new IIlIllIIlIlIIIlIlIllIIIlI(illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(), illlIIIlIlllIllIlIIlllIlI.IlIIlIIIIlIIIIllllIIlIllI());
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(new File(parent, "region"), list, ilIllIIlIlIIIlIlIllIIIlI, 0, i, ilIllIlllllllIlIlllIIlIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(new File(parent2, "region"), list2, new IlIIlIllIIIIIIllIIIIlllIl(IIlIIlIIllIIllIlIIIIIIIlI.lIIlllIIlIlllllllllIIIIIl, 0.0f), list.size(), i, ilIllIlllllllIlIlllIIlIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(new File(parent3, "region"), list3, new IlIIlIllIIIIIIllIIIIlllIl(IIlIIlIIllIIllIlIIIIIIIlI.lIllIllIlIIllIllIlIlIIlIl, 0.0f), list.size() + list2.size(), i, ilIllIlllllllIlIlllIIlIlI);
        illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(19133);
        if (illlIIIlIlllIllIlIIlllIlI.IlIIlIIIIlIIIIllllIIlIllI() == IlIlIlIIlllIIIlIIllllIlII.IlIlIIIlllIIIlIlllIlIllIl) {
            illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(IlIlIlIIlllIIIlIIllllIlII.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        this.IIIllIllIlIlllllllIlIlIII(child);
        this.lIIIIlIIllIIlIIlIIIlIIllI(child, false).lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI);
        return true;
    }
    
    private void IIIllIllIlIlllllllIlIlIII(final String child) {
        final File file = new File(this.lIIIIlIIllIIlIIlIIIlIIllI, child);
        if (!file.exists()) {
            AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.warn("Unable to create level.dat_mcr backup");
        }
        else {
            final File file2 = new File(file, "level.dat");
            if (!file2.exists()) {
                AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.warn("Unable to create level.dat_mcr backup");
            }
            else if (!file2.renameTo(new File(file, "level.dat_mcr"))) {
                AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.warn("Unable to create level.dat_mcr backup");
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final File file, final Iterable iterable, final IIlIllIIlIlIIIlIlIllIIIlI ilIllIIlIlIIIlIlIllIIIlI, int n, final int n2, final IlIllIlllllllIlIlllIIlIlI ilIllIlllllllIlIlllIIlIlI) {
        final Iterator<File> iterator = iterable.iterator();
        while (iterator.hasNext()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(file, iterator.next(), ilIllIIlIlIIIlIlIllIIIlI, n, n2, ilIllIlllllllIlIlllIIlIlI);
            ++n;
            ilIllIlllllllIlIlllIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI((int)Math.round(100 * (double)n / n2));
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final File parent, final File file, final IIlIllIIlIlIIIlIlIllIIIlI ilIllIIlIlIIIlIlIllIIIlI, final int n, final int n2, final IlIllIlllllllIlIlllIIlIlI ilIllIlllllllIlIlllIIlIlI) {
        try {
            final String name = file.getName();
            final IlllllIlllIIlllIlIllIlIIl illlllIlllIIlllIlIllIlIIl = new IlllllIlllIIlllIlIllIlIIl(file);
            final IlllllIlllIIlllIlIllIlIIl illlllIlllIIlllIlIllIlIIl2 = new IlllllIlllIIlllIlIllIlIIl(new File(parent, name.substring(0, name.length() - ".mcr".length()) + ".mca"));
            for (int i = 0; i < 32; ++i) {
                for (int j = 0; j < 32; ++j) {
                    if (illlllIlllIIlllIlIllIlIIl.IlllIIIlIlllIllIlIIlllIlI(i, j) && !illlllIlllIIlllIlIllIlIIl2.IlllIIIlIlllIllIlIIlllIlI(i, j)) {
                        final DataInputStream liiiIlIIllIIlIIlIIIlIIllI = illlllIlllIIlllIlIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(i, j);
                        if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                            AnvilSaveConverter.lIIIIIIIIIlIllIIllIlIIlIl.warn("Failed to fetch input stream");
                        }
                        else {
                            final IlIIIllIIlIIlllIllllIIIIl liiiIlIIllIIlIIlIIIlIIllI2 = lIlIlIlIllIIIllIlIlIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
                            liiiIlIIllIIlIIlIIIlIIllI.close();
                            final IllIlIIllIIIIllIIIlIIIIlI liiiIlIIllIIlIIlIIIlIIllI3 = llIlIlIlIIIlIIIIIlIllllII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2.lIIlIlIllIIlIIIlIIIlllIII("Level"));
                            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
                            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
                            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Level", ilIIIllIIlIIlllIllllIIIIl2);
                            llIlIlIlIIIlIIIIIlIllllII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3, ilIIIllIIlIIlllIllllIIIIl2, ilIllIIlIlIIIlIlIllIIIlI);
                            final DataOutputStream liiiiiiiiIlIllIIllIlIIlIl = illlllIlllIIlllIlIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl(i, j);
                            lIlIlIlIllIIIllIlIlIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl, (DataOutput)liiiiiiiiIlIllIIllIlIIlIl);
                            liiiiiiiiIlIllIIllIlIIlIl.close();
                        }
                    }
                }
                final int n3 = (int)Math.round(100 * (double)(n * 1024) / (n2 * 1024));
                final int n4 = (int)Math.round(100 * (double)((i + 1) * 32 + n * 1024) / (n2 * 1024));
                if (n4 > n3) {
                    ilIllIlllllllIlIlllIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n4);
                }
            }
            illlllIlllIIlllIlIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI();
            illlllIlllIIlllIlIllIlIIl2.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final File parent, final Collection c) {
        final File[] listFiles = new File(parent, "region").listFiles(new lllIIlllIllIIlIIIlIlIlIIl(this));
        if (listFiles != null) {
            Collections.addAll(c, listFiles);
        }
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
    }
}
