import java.util.List;
import java.lang.reflect.Type;
import java.lang.reflect.ParameterizedType;

// 
// Decompiled by Procyon v0.5.36
// 

final class IIllIIIIlIIllIIlIIIIIllII implements ParameterizedType
{
    @Override
    public Type[] getActualTypeArguments() {
        return new Type[] { String.class };
    }
    
    @Override
    public Type getRawType() {
        return List.class;
    }
    
    @Override
    public Type getOwnerType() {
        return null;
    }
}
