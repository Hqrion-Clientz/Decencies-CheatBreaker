import org.lwjgl.opengl.GL11;
import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlIIIIIlllllIIIllIll extends lIIlIllIIIlllllIllIlIlIlI
{
    IllllIIlIllIIIlIlllIlIIIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIIlIIIIIlllllIIIllIll(final IllllIIlIllIIIlIlllIlIIIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return new ResourceLocation("", "");
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIllIlIlIllIIIlIIlIlIIl ilIIllIlIlIllIIIlIIlIlIIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        if (!CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl.IlIlIIIlllIIIlIlllIlIllIl()) {
            return;
        }
        for (final lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl : ilIIllIlIlIllIIIlIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (liIllIllIlIllIIIlIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl()) {
                final int illlIIIlIlllIllIlIIlllIlI = liIllIllIlIllIIIlIlllllIl.IlllIIIlIlllIllIlIIlllIlI();
                final int iiiIllIlIIIllIlllIlllllIl = liIllIllIlIllIIIlIlllllIl.IIIIllIlIIIllIlllIlllllIl();
                final int iiiIllIIllIIIIllIllIIIlIl = liIllIllIlIllIIIlIlllllIl.IIIIllIIllIIIIllIllIIIlIl();
                final double sqrt = Math.sqrt(liIllIllIlIllIIIlIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII));
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIllllIIIIlIlIIIIlIlI && ilIIllIlIlIllIIIlIIlIlIIl.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl).IIIIllIlIIIllIlllIlllllIl) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(liIllIllIlIllIIIlIlllllIl, illlIIIlIlllIllIlIIlllIlI - RenderManager.lIIIIIIIIIlIllIIllIlIIlIl, 0.0 - RenderManager.IlllIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl - RenderManager.IIIIllIlIIIllIlllIlllllIl, 64, sqrt);
                }
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI || this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIlIllIlIIlIlllIllIIlI.gameSettings.IllIIIIIllllIlllIIlIIllIl) {
                    continue;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(liIllIllIlIllIIIlIlllllIl, liIllIllIlIllIIIlIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI, n + illlIIIlIlllIllIlIIlllIlI, n2 + iiiIllIIllIIIIllIllIIIlIl + 1.0, n3 + iiiIllIlIIIllIlllIlllllIl, 64, sqrt);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl, final double n, final double n2, final double n3, final float n4, final double n5) {
        final Tessellator instance = Tessellator.instance;
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        GL11.glDepthMask(false);
        GL11.glEnable(3042);
        GL11.glAlphaFunc(516, 0.088f * 1.1363636f);
        GL11.glBlendFunc(770, 1);
        final int n6 = 256;
        final float n7 = 0.014444443f * 1.3846154f;
        final double n8 = 0.28205129504203796 * 3.722727101265407;
        final double n9 = 0.43749998261531264 * 2.4000000953674316;
        final float iiIlIIllllIIllllllIlIIIll = liIllIllIlIllIIIlIlllllIl.IIIlIIllllIIllllllIlIIIll;
        final float liiiiIllllIIIIlIlIIIIlIlI = liIllIllIlIllIIIlIlllllIl.lIIIIIllllIIIIlIlIIIIlIlI;
        final float lllIIIIIlIllIlIIIllllllII = liIllIllIlIllIIIlIlllllIl.lllIIIIIlIllIlIIIllllllII;
        float n10 = (n5 < 30) ? ((float)n5 / 30) : 1.0f;
        if (n10 < 0.725f * 0.27586207f) {
            n10 = 1.4179105f * 0.14105263f;
        }
        for (int i = 0; i < 4; ++i) {
            instance.startDrawing(5);
            instance.lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIllllIIllllllIlIIIll * n7, lllIIIIIlIllIlIIIllllllII * n7, liiiiIllllIIIIlIlIIIIlIlI * n7, 0.40851063f * 1.9583334f * n10);
            final double n11 = (0.012328767767541325 * 8.11111068725586 + i * (1.0116279125213623 * 0.19770114834170974)) * n8;
            final double n12 = (0.08 * 1.25 + i * (0.010989011265337467 * 18.1999995423481)) * n9;
            for (int j = 0; j < 5; ++j) {
                double n13 = n + 1.557692289352417 * 0.32098765810021834 - n11;
                double n14 = n3 + 0.07547169923782349 * 6.624999901279809 - n11;
                if (j == 1 || j == 2) {
                    n13 += n11 * 2;
                }
                if (j == 2 || j == 3) {
                    n14 += n11 * 2;
                }
                double n15 = n + 0.380952388048172 * 1.3124999755527829 - n12;
                double n16 = n3 + 0.37499998882412944 * 1.3333333730697632 - n12;
                if (j == 1 || j == 2) {
                    n15 += n12 * 2;
                }
                if (j == 2 || j == 3) {
                    n16 += n12 * 2;
                }
                instance.addVertex(n15, n2 + 0.0, n16);
                instance.addVertex(n13, n2 + n6, n14);
            }
            instance.draw();
        }
        GL11.glDisable(3042);
        GL11.glEnable(2912);
        GL11.glEnable(2896);
        GL11.glEnable(3553);
        GL11.glDepthMask(true);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl, String string, double n, double n2, double n3, final int n4, final double n5) {
        GL11.glAlphaFunc(516, 0.053658538f * 1.8636364f);
        if (n5 <= this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIIIlIIIIllllIIlIllI || this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIIIlIIIIllllIIlIllI < 0) {
            string = string + " (" + (int)n5 + "m)";
            final double n6 = this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIlIllIlIIlIlllIllIIlI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIlIIlIlIIlIlIlIll.IlIlIIIlllIIIlIlllIlIllIl) * 16 * (0.05660377358490566 * 13.25);
            double n7 = n5;
            if (n5 > n6) {
                n = n / n5 * n6;
                n2 = n2 / n5 * n6;
                n3 = n3 / n5 * n6;
                n7 = n6;
            }
            final FontRenderer liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl();
            final float n8 = ((float)n7 * (1.0588236f * 0.09444444f) + 1.0f) * (0.005148387f * 5.1666665f);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)n + 0.43636364f * 1.1458334f, (float)n2 + 0.043333333f * 30.0f, (float)n3 + 1.220339f * 0.40972224f);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            GL11.glRotatef(-this.lIIIIIIIIIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlllIIIIllIllllIllIIlIl, 1.0f, 0.0f, 0.0f);
            GL11.glScalef(-n8, -n8, n8);
            GL11.glDisable(2896);
            GL11.glDisable(2912);
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            final Tessellator instance = Tessellator.instance;
            final int n9 = 0;
            GL11.glDisable(3553);
            final int n10 = liiiiiiiiIlIllIIllIlIIlIl.getStringWidth(string) / 2;
            GL11.glEnable(2929);
            if (n5 < n6) {
                GL11.glDepthMask(true);
            }
            float n11 = (n5 < 30) ? ((float)n5 / 30) : 1.0f;
            if (n11 < 0.3642857f * 0.54901963f) {
                n11 = 1.4642857f * 0.13658537f;
            }
            GL11.glEnable(32823);
            GL11.glPolygonOffset(1.0f, (float)3);
            instance.startDrawingQuads();
            instance.lIIIIlIIllIIlIIlIIIlIIllI(liIllIllIlIllIIIlIlllllIl.IIIlIIllllIIllllllIlIIIll, liIllIllIlIllIIIlIlllllIl.lllIIIIIlIllIlIIIllllllII, liIllIllIlIllIIIlIlllllIl.lIIIIIllllIIIIlIlIIIIlIlI, 2.4f * 0.25f * n11);
            instance.addVertex(-n10 - 2, -2 + n9, 0.0);
            instance.addVertex(-n10 - 2, 9 + n9, 0.0);
            instance.addVertex(n10 + 2, 9 + n9, 0.0);
            instance.addVertex(n10 + 2, -2 + n9, 0.0);
            instance.draw();
            GL11.glPolygonOffset(1.0f, 1.0f);
            instance.startDrawingQuads();
            instance.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 0.005172414f * 29.0f);
            instance.addVertex(-n10 - 1, -1 + n9, 0.0);
            instance.addVertex(-n10 - 1, 8 + n9, 0.0);
            instance.addVertex(n10 + 1, 8 + n9, 0.0);
            instance.addVertex(n10 + 1, -1 + n9, 0.0);
            instance.draw();
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glPolygonOffset(1.0f, (float)7);
            instance.startDrawingQuads();
            instance.lIIIIlIIllIIlIIlIIIlIIllI(liIllIllIlIllIIIlIlllllIl.IIIlIIllllIIllllllIlIIIll, liIllIllIlIllIIIlIlllllIl.lllIIIIIlIllIlIIIllllllII, liIllIllIlIllIIIlIlllllIl.lIIIIIllllIIIIlIlIIIIlIlI, 0.014285714f * 10.5f * n11);
            instance.addVertex(-n10 - 2, -2 + n9, 0.0);
            instance.addVertex(-n10 - 2, 9 + n9, 0.0);
            instance.addVertex(n10 + 2, 9 + n9, 0.0);
            instance.addVertex(n10 + 2, -2 + n9, 0.0);
            instance.draw();
            GL11.glPolygonOffset(1.0f, (float)5);
            instance.startDrawingQuads();
            instance.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.3529412f * 0.11086957f * n11);
            instance.addVertex(-n10 - 1, -1 + n9, 0.0);
            instance.addVertex(-n10 - 1, 8 + n9, 0.0);
            instance.addVertex(n10 + 1, 8 + n9, 0.0);
            instance.addVertex(n10 + 1, -1 + n9, 0.0);
            instance.draw();
            GL11.glDisable(32823);
            GL11.glEnable(3553);
            final int n12 = 13421772;
            final int n13 = 16777215;
            liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(string, -liiiiiiiiIlIllIIllIlIIlIl.getStringWidth(string) / 2, n9, n12 | (int)(255 * n11) << 24);
            GL11.glEnable(2929);
            liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(string, -liiiiiiiiIlIllIIllIlIIlIl.getStringWidth(string) / 2, n9, n13 | (int)(255 * n11) << 24);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glEnable(2912);
            GL11.glEnable(2896);
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glPopMatrix();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIllIlIlIllIIIlIIlIlIIl)entity, n, n2, n3, n4, n5);
    }
}
