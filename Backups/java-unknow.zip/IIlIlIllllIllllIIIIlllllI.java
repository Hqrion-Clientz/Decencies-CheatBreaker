// 
// Decompiled by Procyon v0.5.36
// 

public enum IIlIlIllllIllllIIIIlllllI
{
    lIIIIlIIllIIlIIlIIIlIIllI("NONE", 0, "NONE", 0, 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("LINEAR", 1, "LINEAR", 1, 2);
    
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private static final IIlIlIllllIllllIIIIlllllI[] IIIIllIlIIIllIlllIlllllIl;
    
    private IIlIlIllllIllllIIIIlllllI(final String name, final int ordinal, final String s, final int n, final int illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    static {
        IIIIllIlIIIllIlllIlllllIl = new IIlIlIllllIllllIIIIlllllI[] { IIlIlIllllIllllIIIIlllllI.lIIIIlIIllIIlIIlIIIlIIllI, IIlIlIllllIllllIIIIlllllI.lIIIIIIIIIlIllIIllIlIIlIl };
    }
}
