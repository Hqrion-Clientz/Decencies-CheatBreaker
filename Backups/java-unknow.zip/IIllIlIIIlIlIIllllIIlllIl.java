import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIIlIlIIllllIIlllIl extends llIlIIIlIIlIlllIIlIIIIIll
{
    private UUID lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIllIlIIIlIlIIllllIIlllIl() {
    }
    
    public IIllIlIIIlIlIIllllIIlllIl(final UUID liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIIllIIIIIlIIIIIlII.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIlIIIlIlIllIIllllII illllIIlIIIlIlIllIIllllII) {
        ((IIlIllIllIIIIllIlIIlIlIll)illllIIlIIIlIlIllIIllllII).lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public UUID lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
