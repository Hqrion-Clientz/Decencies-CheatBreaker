import org.lwjgl.opengl.GLContext;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import java.nio.IntBuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlllIlIlIlllIIIlIlllI
{
    private static Tessellator IlIlIIIlllIIIlIlllIlIllIl;
    public static TextureManager lIIIIlIIllIIlIIlIIIlIIllI;
    public static int lIIIIIIIIIlIllIIllIlIIlIl;
    public static boolean IlllIIIlIlllIllIlIIlllIlI;
    public static int IIIIllIlIIIllIlllIlllllIl;
    private static int IIIllIllIlIlllllllIlIlIII;
    public static boolean IIIIllIIllIIIIllIllIIIlIl;
    private static final IntBuffer IllIIIIIIIlIlIllllIIllIII;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        IIlIIlllIlIlIlllIIIlIlllI.IIIllIllIlIlllllllIlIlIII = GL11.glGetInteger(36006);
        IIlIIlllIlIlIlllIIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl = EXTFramebufferObject.glGenFramebuffersEXT();
        IIlIIlllIlIlIlllIIIlIlllI.IIIIllIlIIIllIlllIlllllIl = GL11.glGenTextures();
        final int n = 256;
        final int n2 = 256;
        EXTFramebufferObject.glBindFramebufferEXT(36160, IIlIIlllIlIlIlllIIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final ByteBuffer byteBuffer = BufferUtils.createByteBuffer(4 * n * n2);
        GL11.glBindTexture(3553, IIlIIlllIlIlIlllIIIlIlllI.IIIIllIlIIIllIlllIlllllIl);
        GL11.glTexParameteri(3553, 10242, 10496);
        GL11.glTexParameteri(3553, 10243, 10496);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexImage2D(3553, 0, 6408, n, n2, 0, 6408, 5120, byteBuffer);
        EXTFramebufferObject.glFramebufferTexture2DEXT(36160, 36064, 3553, IIlIIlllIlIlIlllIIIlIlllI.IIIIllIlIIIllIlllIlllllIl, 0);
        final int glGenRenderbuffersEXT = EXTFramebufferObject.glGenRenderbuffersEXT();
        EXTFramebufferObject.glBindRenderbufferEXT(36161, glGenRenderbuffersEXT);
        EXTFramebufferObject.glRenderbufferStorageEXT(36161, 33190, 256, 256);
        EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, glGenRenderbuffersEXT);
        EXTFramebufferObject.glBindRenderbufferEXT(36161, 0);
        EXTFramebufferObject.glBindFramebufferEXT(36160, IIlIIlllIlIlIlllIIIlIlllI.IIIllIllIlIlllllllIlIlIII);
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl() {
        IIlIIlllIlIlIlllIIIlIlllI.IIIllIllIlIlllllllIlIlIII = GL11.glGetInteger(36006);
        EXTFramebufferObject.glBindFramebufferEXT(36160, IIlIIlllIlIlIlllIIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public static void IlllIIIlIlllIllIlIIlllIlI() {
        EXTFramebufferObject.glBindFramebufferEXT(36160, IIlIIlllIlIlIlllIIIlIlllI.IIIllIllIlIlllllllIlIlIII);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        lIIIIlIIllIIlIIlIIIlIIllI(n, (float)n2, 128);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final float n2, final int n3) {
        final int n4 = n3 / 4;
        lIIIIlIIllIIlIIlIIIlIIllI(n - n4, n2 + n4, 1.0, 0.0, 1.0);
        lIIIIlIIllIIlIIlIIIlIIllI(n + n4, n2 + n4, 1.0, 1.0, 1.0);
        lIIIIlIIllIIlIIlIIIlIIllI(n + n4, n2 - n4, 1.0, 1.0, 0.0);
        lIIIIlIIllIIlIIlIIIlIIllI(n - n4, n2 - n4, 1.0, 0.0, 0.0);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage bufferedImage) {
        final int glGenTextures = GL11.glGenTextures();
        final int width = bufferedImage.getWidth();
        final int height = bufferedImage.getHeight();
        final int[] array = new int[width * height];
        bufferedImage.getRGB(0, 0, width, height, array, 0, width);
        GL11.glBindTexture(3553, glGenTextures);
        IIlIIlllIlIlIlllIIIlIlllI.IllIIIIIIIlIlIllllIIllIII.clear();
        IIlIIlllIlIlIlllIIIlIlllI.IllIIIIIIIlIlIllllIIllIII.put(array, 0, width * height);
        IIlIIlllIlIlIlllIIIlIlllI.IllIIIIIIIlIlIllllIIllIII.position(0).limit(width * height);
        GL11.glTexImage2D(3553, 0, 6408, width, height, 0, 32993, 33639, IIlIIlllIlIlIlllIIIlIlllI.IllIIIIIIIlIlIllllIIllIII);
        return glGenTextures;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        IIlIIlllIlIlIlllIIIlIlllI.lIIIIlIIllIIlIIlIIIlIIllI.bindTexture(new ResourceLocation(s));
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final ResourceLocation resourceLocation) {
        IIlIIlllIlIlIlllIIIlIlllI.lIIIIlIIllIIlIIlIIIlIIllI.bindTexture(resourceLocation);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        GL11.glBindTexture(3553, n);
    }
    
    public static void IIIIllIlIIIllIlllIlllllIl() {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl.startDrawingQuads();
    }
    
    public static void IIIIllIIllIIIIllIllIIIlIl() {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl.draw();
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        GL11.glDeleteTextures(n);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final double n3, final double n4, final double n5) {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl.addVertexWithUV(n, n2, n3, n4, n5);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl.addVertex(n, n2, n3);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final double n4, final double n5) {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl.addVertexWithUV(n, n2, n3, n4, n5);
    }
    
    static {
        IIlIIlllIlIlIlllIIIlIlllI.IlIlIIIlllIIIlIlllIlIllIl = Tessellator.instance;
        IIlIIlllIlIlIlllIIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl = 0;
        IIlIIlllIlIlIlllIIIlIlllI.IlllIIIlIlllIllIlIIlllIlI = (GLContext.getCapabilities().GL_EXT_framebuffer_object && GLContext.getCapabilities().OpenGL14);
        IIlIIlllIlIlIlllIIIlIlllI.IIIIllIlIIIllIlllIlllllIl = 0;
        IIlIIlllIlIlIlllIIIlIlllI.IIIllIllIlIlllllllIlIlIII = 0;
        IIlIIlllIlIlIlllIIIlIlllI.IIIIllIIllIIIIllIllIIIlIl = (GL11.glGetInteger(3413) > 0);
        IllIIIIIIIlIlIllllIIllIII = GLAllocation.IIIIllIlIIIllIlllIlllllIl(4194304);
    }
}
