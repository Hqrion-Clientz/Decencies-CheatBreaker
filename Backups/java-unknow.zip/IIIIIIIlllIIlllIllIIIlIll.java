import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlllIIlllIllIIIlIll extends llllIIlIIIIlIIllIIIlllIIl
{
    private static final Logger IlllIIIlIlllIllIlIIlllIlI;
    private llllIIlIIIIlIIllIIIlllIIl IIIIllIlIIIllIlllIlllllIl;
    
    public IIIIIIIlllIIlllIllIIIlIll(final long n, final llllIIlIIIIlIIllIIIlllIIl liiiIlIIllIIlIIlIIIlIIllI, final llllIIlIIIIlIIllIIIlllIIl iiiIllIlIIIllIlllIlllllIl) {
        super(n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public int[] lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n - 1, n2 - 1, n3 + 2, n4 + 2);
        final int[] liiiIlIIllIIlIIlIIIlIIllI2 = this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n - 1, n2 - 1, n3 + 2, n4 + 2);
        final int[] liiiIlIIllIIlIIlIIIlIIllI3 = lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 * n4);
        for (int i = 0; i < n4; ++i) {
            for (int j = 0; j < n3; ++j) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(j + n, (long)(i + n2));
                final int k = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 1) * (n3 + 2)];
                final int n5 = liiiIlIIllIIlIIlIIIlIIllI2[j + 1 + (i + 1) * (n3 + 2)];
                final boolean b = (n5 - 2) % 29 == 0;
                if (k > 255) {
                    IIIIIIIlllIIlllIllIIIlIll.IlllIIIlIlllIllIlIIlllIlI.debug("old! " + k);
                }
                if (k != 0 && n5 >= 2 && (n5 - 2) % 29 == 1 && k < 128) {
                    if (IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(k + 128) != null) {
                        liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = k + 128;
                    }
                    else {
                        liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = k;
                    }
                }
                else if (this.lIIIIlIIllIIlIIlIIIlIIllI(3) != 0 && !b) {
                    liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = k;
                }
                else {
                    int n6;
                    if ((n6 = k) == IIlIIlIIllIIllIlIIIIIIIlI.lllIIIIIlIllIlIIIllllllII.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IlllIIlllIIIIllIIllllIlIl.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IIIIIIlIlIlIllllllIlllIlI.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IllllIllllIlIIIlIIIllllll.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IlIIIIllIIIIIlllIIlIIlllI.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.llIlIlIllIlIIlIlllIllIIlI.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.llIlIlIlllIlllllIIIllIIll.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IllIllIIIlIIlllIIIllIllII.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IllIIlllIllIlIllIlIIIIIII.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IlIIlIIlIllIIIIllIIllIlIl.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.llllIIIIlIlIllIIIllllIIll.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IIllIlIllIlIllIIlIllIlIII.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.lIlIllIlIlIIIllllIlIllIll.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll.IlIllIllIllIllIllllIIIlII) {
                        if (this.lIIIIlIIllIIlIIlIIIlIIllI(3) == 0) {
                            n6 = IIlIIlIIllIIllIlIIIIIIIlI.IllllIllllIlIIIlIIIllllll.IlIllIllIllIllIllllIIIlII;
                        }
                        else {
                            n6 = IIlIIlIIllIIllIlIIIIIIIlI.IIIIIIlIlIlIllllllIlllIlI.IlIllIllIllIllIllllIIIlII;
                        }
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IllIlIIIIlllIIllIIlllIIlI.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.IIlIIllIIIllllIIlllIllIIl.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.lllIlIIllllIIIIlIllIlIIII.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.llIlIIIlIIIIlIlllIlIIIIll.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.lIIIlllIlIlllIIIIIIIIIlII.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.lIIIIIllllIIIIlIlIIIIlIlI.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IIlIlIIlIIIlIlllllIIlIIlI.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.lIIIlllIIIlIIIIIlIIIIIIII.IlIllIllIllIllIllllIIIlII) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.lIIlIIIIIIIIllIIllIIlllIl.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(k, IIlIIlIIllIIllIlIIIIIIIlI.lIlIlIIIlIIllllllllIIlllI.IlIllIllIllIllIllllIIIlII)) {
                        n6 = IIlIIlIIllIIllIlIIIIIIIlI.IllllllIllllIIlllIllllllI.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (k == IIlIIlIIllIIllIlIIIIIIIlI.lIIIlllIlIlllIIIIIIIIIlII.IlIllIllIllIllIllllIIIlII && this.lIIIIlIIllIIlIIlIIIlIIllI(3) == 0) {
                        if (this.lIIIIlIIllIIlIIlIIIlIIllI(2) == 0) {
                            n6 = IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll.IlIllIllIllIllIllllIIIlII;
                        }
                        else {
                            n6 = IIlIIlIIllIIllIlIIIIIIIlI.IIIIIIlIlIlIllllllIlllIlI.IlIllIllIllIllIllllIIIlII;
                        }
                    }
                    if (b && n6 != k) {
                        if (IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(n6 + 128) != null) {
                            n6 += 128;
                        }
                        else {
                            n6 = k;
                        }
                    }
                    if (n6 == k) {
                        liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = k;
                    }
                    else {
                        final int n7 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 1 - 1) * (n3 + 2)];
                        final int n8 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + 1 + (i + 1) * (n3 + 2)];
                        final int n9 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 - 1 + (i + 1) * (n3 + 2)];
                        final int n10 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 1 + 1) * (n3 + 2)];
                        int n11 = 0;
                        if (llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n7, k)) {
                            ++n11;
                        }
                        if (llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n8, k)) {
                            ++n11;
                        }
                        if (llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n9, k)) {
                            ++n11;
                        }
                        if (llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n10, k)) {
                            ++n11;
                        }
                        if (n11 >= 3) {
                            liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = n6;
                        }
                        else {
                            liiiIlIIllIIlIIlIIIlIIllI3[j + i * n3] = k;
                        }
                    }
                }
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI3;
    }
    
    static {
        IlllIIIlIlllIllIlIIlllIlI = LogManager.getLogger();
    }
}
