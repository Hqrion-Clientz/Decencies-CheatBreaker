import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIllIIIIIIIIIlIlII extends IIllIIlIllIllIllIIIIIlIII implements IlllllIIIlIlllllIIlIlllIl
{
    public static final String[] lIIIIlllIIlIlllllIlIllIII;
    private IlllIllIIIIlllIllIIIIIlII[] IIIIlIIIlllllllllIlllIlll;
    private IlllIllIIIIlllIllIIIIIlII[] IlIllllIIIlIllllIIIIIllII;
    public IlllIllIIIIlllIllIIIIIlII[] lIIIlllIlIlllIIIIIIIIIlII;
    
    public IIIIIIllIllIIIIIIIIIlIlII() {
        super(Material.IlIlllIIIIllIllllIllIIlIl);
        this.IlllIIIlIlllIllIlIIlllIlI(0.0f);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIIIIIllIllIIIIIIIIIlIlII.IlIlIIIlllIIIlIlllIlIllIl);
        this.lIIIIIIIIIlIllIIllIlIIlIl("doublePlant");
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 40;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return IllIIIIIIIlIlIllllIIllIII(illlIIIlIlllIllIlIIlllIlI) ? (liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3) & 0x7) : (illlIIIlIlllIllIlIIlllIlI & 0x7);
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return super.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3) && iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2 + 1, n3);
    }
    
    @Override
    protected void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!this.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            if (!IllIIIIIIIlIlIllllIIllIII(illlIIIlIlllIllIlIIlllIlI)) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 0);
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3) == this) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 + 1, n3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, 0, 2);
                }
            }
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, 0, 2);
        }
    }
    
    @Override
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IllIIIIIIIlIlIllllIIllIII(iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3)) ? (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == this) : (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3) == this && super.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3));
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        if (IllIIIIIIIlIlIllllIIllIII(n)) {
            return null;
        }
        final int liiiIllIIlIlIllIIIlIllIlI = lIIIIllIIlIlIllIIIlIllIlI(n);
        return (liiiIllIIlIlIllIIIlIllIlI != 3 && liiiIllIIlIlIllIIIlIllIlI != 2) ? lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this) : null;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return IllIIIIIIIlIlIllllIIllIII(n) ? 0 : (n & 0x7);
    }
    
    public static boolean IllIIIIIIIlIlIllllIIllIII(final int n) {
        return (n & 0x8) != 0x0;
    }
    
    public static int lIIIIllIIlIlIllIIIlIllIlI(final int n) {
        return n & 0x7;
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return IllIIIIIIIlIlIllllIIllIII(n2) ? this.IIIIlIIIlllllllllIlllIlll[0] : this.IIIIlIIIlllllllllIlllIlll[n2 & 0x7];
    }
    
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        return b ? this.IlIllllIIIlIllllIIIIIllII[n] : this.IIIIlIIIlllllllllIlllIlll[n];
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3);
        return (iiiIllIIllIIIIllIllIIIlIl != 2 && iiiIllIIllIIIIllIllIIIlIl != 3) ? 16777215 : liIllIIIllIIIIllIllIIllIl.a_(n, n3).lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final int n5) {
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this, n4, n5);
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 + 1, n3, this, 8, n5);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final EntityLivingBase entityLivingBase, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 + 1, n3, this, 0x8 | ((MathHelper.IlllIIIlIlllIllIlIIlllIlI(entityLivingBase.IllllIllllIlIIIlIIIllllll * 4 / 360 + 20.750000772997765 * 0.024096384644508362) & 0x3) + 2) % 4, 2);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n, final int n2, final int n3, final int n4) {
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll || lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll() == null || lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll().lIIIIlIIllIIlIIlIIIlIIllI() != IIlIlIllIlIIllIllIllIIIll.lIIIllIIIIlIIllIIIIIIIlll || IllIIIIIIIlIlIllllIIllIII(n4) || !this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, lIllIIIIlIIlIllIIIlIlIlll)) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, lIllIIIIlIIlIllIIIlIlIlll, n, n2, n3, n4);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        if (IllIIIIIIIlIlIllllIIllIII(n4)) {
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == this) {
                if (!lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                    final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3);
                    final int liiiIllIIlIlIllIIIlIllIlI = lIIIIllIIlIlIllIIIlIllIlI(illlIIIlIlllIllIlIIlllIlI);
                    if (liiiIllIIlIlIllIIIlIllIlI != 3 && liiiIllIIlIlIllIIIlIllIlI != 2) {
                        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 - 1, n3, true);
                    }
                    else {
                        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll && lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll() != null && lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIlIIllIlIlIllIIIIll().lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lIIIllIIIIlIIllIIIIIIIlll) {
                            this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, lIllIIIIlIIlIllIIIlIlIlll);
                        }
                        iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2 - 1, n3);
                    }
                }
                else {
                    iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2 - 1, n3);
                }
            }
        }
        else if (lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3) == this) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2 + 1, n3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, 0, 2);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final int liiiIllIIlIlIllIIIlIllIlI = lIIIIllIIlIlIllIIIlIllIlI(n4);
        if (liiiIllIIlIlIllIIIlIllIlI != 3 && liiiIllIIlIlIllIIIlIllIlI != 2) {
            return false;
        }
        lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.IllIlIlIllllIlIIllllIIlll[IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this)], 1);
        int n5 = 1;
        if (liiiIllIIlIlIllIIIlIllIlI == 3) {
            n5 = 2;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, new lIlIlIlIlIllllIlllIIIlIlI(IllllllIllIIlllIllIIlIIll.IllIIlllIllIlIllIlIIIIIII, 2, n5));
        return true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIIIlIIIlllllllllIlllIlll = new IlllIllIIIIlllIllIIIIIlII[IIIIIIllIllIIIIIIIIIlIlII.lIIIIlllIIlIlllllIlIllIII.length];
        this.IlIllllIIIlIllllIIIIIllII = new IlllIllIIIIlllIllIIIIIlII[IIIIIIllIllIIIIIIIIIlIlII.lIIIIlllIIlIlllllIlIllIII.length];
        for (int i = 0; i < this.IIIIlIIIlllllllllIlllIlll.length; ++i) {
            this.IIIIlIIIlllllllllIlllIlll[i] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("double_plant_" + IIIIIIllIllIIIIIIIIIlIlII.lIIIIlllIIlIlllllIlIllIII[i] + "_bottom");
            this.IlIllllIIIlIllllIIIIIllII[i] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("double_plant_" + IIIIIIllIllIIIIIIIIIlIlII.lIIIIlllIIlIlllllIlIllIII[i] + "_top");
        }
        (this.lIIIlllIlIlllIIIIIIIIIlII = new IlllIllIIIIlllIllIIIIIlII[2])[0] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("double_plant_sunflower_front");
        this.lIIIlllIlIlllIIIIIIIIIlII[1] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("double_plant_sunflower_back");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final IIllllIllIIllIIllIlIIIIII illllIllIIllIIllIlIIIIII, final List list) {
        for (int i = 0; i < this.IIIIlIIIlllllllllIlllIlll.length; ++i) {
            list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, i));
        }
    }
    
    @Override
    public int IllIIIIIIIlIlIllllIIllIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return IllIIIIIIIlIlIllllIIllIII(illlIIIlIlllIllIlIIlllIlI) ? lIIIIllIIlIlIllIIIlIllIlI(iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3)) : lIIIIllIIlIlIllIIIlIllIlI(illlIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final boolean b) {
        final int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        return iiiIllIIllIIIIllIllIIIlIl != 2 && iiiIllIIllIIIIllIllIIIlIl != 3;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        return true;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, new lIlIlIlIlIllllIlllIIIlIlI(this, 1, this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)));
    }
    
    static {
        lIIIIlllIIlIlllllIlIllIII = new String[] { "sunflower", "syringa", "grass", "fern", "rose", "paeonia" };
    }
}
