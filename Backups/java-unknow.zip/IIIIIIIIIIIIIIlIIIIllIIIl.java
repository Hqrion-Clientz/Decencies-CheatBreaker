// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIIIIIIlIIIIllIIIl extends IIIlIlIIIIIIIlllllIlIllIl
{
    public IIIIIIIIIIIIIIlIIIIllIIIl(final int n, final boolean b, final int n2) {
        super(n, b, n2);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return true;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return n >= 1;
    }
}
