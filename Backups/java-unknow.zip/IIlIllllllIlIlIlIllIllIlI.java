// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllllllIlIlIlIllIllIlI extends llIIlllIIlIIIIIIIllIlIIlI
{
    private final double lIIIIlIIllIIlIIlIIIlIIllI;
    private final double lIIIIIIIIIlIllIIllIlIIlIl;
    private String IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIllllllIlIlIlIllIllIlI(final String s, final double n, final double liiiIlIIllIIlIIlIIIlIIllI, final double liiiiiiiiIlIllIIllIlIIlIl) {
        super(s, n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        if (liiiIlIIllIIlIIlIIIlIIllI > liiiiiiiiIlIllIIllIlIIlIl) {
            throw new IllegalArgumentException("Minimum value cannot be bigger than maximum value!");
        }
        if (n < liiiIlIIllIIlIIlIIIlIIllI) {
            throw new IllegalArgumentException("Default value cannot be lower than minimum value!");
        }
        if (n > liiiiiiiiIlIllIIllIlIIlIl) {
            throw new IllegalArgumentException("Default value cannot be bigger than maximum value!");
        }
    }
    
    public IIlIllllllIlIlIlIllIllIlI lIIIIlIIllIIlIIlIIIlIIllI(final String illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        return this;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public double lIIIIlIIllIIlIIlIIIlIIllI(double n) {
        if (n < this.lIIIIlIIllIIlIIlIIIlIIllI) {
            n = this.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        if (n > this.lIIIIIIIIIlIllIIllIlIIlIl) {
            n = this.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        return n;
    }
}
