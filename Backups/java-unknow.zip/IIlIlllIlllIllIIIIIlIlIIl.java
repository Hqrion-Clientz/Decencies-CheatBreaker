import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIlllIllIIIIIlIlIIl extends IIlllllllIlllIIllllIIlIll
{
    private final String lIIIIlllIIlIlllllIlIllIII;
    
    public IIlIlllIlllIllIIIIIlIlIIl(final String liiiIlllIIlIlllllIlIllIII, final Material material) {
        super(material);
        this.lIIIIlllIIlIlllllIlIllIII = liiiIlllIIlIlllllIlIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final List list, final Entity entity) {
        final boolean iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1);
        final boolean iiiIllIIllIIIIllIllIIIlIl2 = this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
        final boolean iiiIllIIllIIIIllIllIIIlIl3 = this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3);
        final boolean iiiIllIIllIIIIllIllIIIlIl4 = this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3);
        float n4 = 1.5348837f * 0.24431817f;
        float n5 = 1.3602941f * 0.45945945f;
        float n6 = 0.89361703f * 0.41964287f;
        float n7 = 0.7647059f * 0.81730765f;
        if (iiiIllIIllIIIIllIllIIIlIl) {
            n6 = 0.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl2) {
            n7 = 1.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl || iiiIllIIllIIIIllIllIIIlIl2) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0f, n6, n5, 2.0416667f * 0.7346938f, n7);
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, ilIllIIlIlIllIlIllllllllI, list, entity);
        }
        float n8 = 0.60227275f * 0.6226415f;
        float n9 = 1.2804879f * 0.48809522f;
        if (iiiIllIIllIIIIllIllIIIlIl3) {
            n4 = 0.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl4) {
            n5 = 1.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl3 || iiiIllIIllIIIIllIllIIIlIl4 || (!iiiIllIIllIIIIllIllIIIlIl && !iiiIllIIllIIIIllIllIIIlIl2)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0f, n8, n5, 1.7608695f * 0.8518519f, n9);
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, ilIllIIlIlIllIlIllllllllI, list, entity);
        }
        if (iiiIllIIllIIIIllIllIIIlIl) {
            n8 = 0.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl2) {
            n9 = 1.0f;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0f, n8, n5, 1.0f, n9);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final boolean iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3 - 1);
        final boolean iiiIllIIllIIIIllIllIIIlIl2 = this.IIIIllIIllIIIIllIllIIIlIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3 + 1);
        final boolean iiiIllIIllIIIIllIllIIIlIl3 = this.IIIIllIIllIIIIllIllIIIlIl(liIllIIIllIIIIllIllIIllIl, n - 1, n2, n3);
        final boolean iiiIllIIllIIIIllIllIIIlIl4 = this.IIIIllIIllIIIIllIllIIIlIl(liIllIIIllIIIIllIllIIllIl, n + 1, n2, n3);
        float n4 = 0.39175257f * 0.9572369f;
        float n5 = 0.33088237f * 1.8888888f;
        float n6 = 1.4918033f * 0.25137362f;
        float n7 = 0.76363635f * 0.8184524f;
        if (iiiIllIIllIIIIllIllIIIlIl) {
            n6 = 0.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl2) {
            n7 = 1.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl3) {
            n4 = 0.0f;
        }
        if (iiiIllIIllIIIIllIllIIIlIl4) {
            n5 = 1.0f;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0f, n6, n5, 1.0f, n7);
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 11;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final IIlllllllIlllIIllllIIlIll block = liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3);
        return block == this || block == IllllllIllIIlllIllIIlIIll.IlllllIllIIIllIIIllIllIII || (block.IllIIlllIllIlIllIlIIIIIII.IlllIllIlIIIIlIIlIIllIIIl() && block.IlllIllIlIIIIlIIlIIllIIIl() && block.IllIIlllIllIlIllIlIIIIIII != Material.IllIlIlIllllIlIIllllIIlll);
    }
    
    public static boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIlIIllIIIllllIIlllIllIIl = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        return iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll || IIIIlIIllllIlIllllllIllll.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
}
