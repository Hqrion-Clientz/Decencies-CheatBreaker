// 
// Decompiled by Procyon v0.5.36
// 

public class CBMojangServiceEntry
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private String lIIIIIIIIIlIllIIllIlIIlIl;
    private lIIIIlllIlIlllIIIlllllIlI IlllIIIlIlllIllIlIIlllIlI;
    
    public CBMojangServiceEntry(final String liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = lIIIIlllIlIlllIIIlllllIlI.IIIIllIlIIIllIlllIlllllIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public lIIIIlllIlIlllIIIlllllIlI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlllIlIlllIIIlllllIlI illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
