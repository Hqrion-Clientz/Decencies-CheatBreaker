import java.util.NoSuchElementException;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllIIIlIIIIIIIIIIIlII extends IllIlIllllllIIIIIllIllIlI
{
    private final Object[] lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    
    public IIIlIllIIIlIIIIIIIIIIIlII(final Object[] liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public boolean hasNext() {
        return this.IIIIllIlIIIllIlllIlllllIl < this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public boolean hasPrevious() {
        return this.IIIIllIlIIIllIlllIlllllIl > 0;
    }
    
    @Override
    public Object next() {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        return this.lIIIIlIIllIIlIIlIIIlIIllI[this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl++];
    }
    
    @Override
    public Object previous() {
        if (!this.hasPrevious()) {
            throw new NoSuchElementException();
        }
        final Object[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        final int iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl - 1;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        return liiiIlIIllIIlIIlIIIlIIllI[liiiiiiiiIlIllIIllIlIIlIl + iiiIllIlIIIllIlllIlllllIl];
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(int n) {
        if (n <= this.IlllIIIlIlllIllIlIIlllIlI - this.IIIIllIlIIIllIlllIlllllIl) {
            this.IIIIllIlIIIllIlllIlllllIl += n;
            return n;
        }
        n = this.IlllIIIlIlllIllIlIIlllIlI - this.IIIIllIlIIIllIlllIlllllIl;
        this.IIIIllIlIIIllIlllIlllllIl = this.IlllIIIlIlllIllIlIIlllIlI;
        return n;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(int iiiIllIlIIIllIlllIlllllIl) {
        if (iiiIllIlIIIllIlllIlllllIl <= this.IIIIllIlIIIllIlllIlllllIl) {
            this.IIIIllIlIIIllIlllIlllllIl -= iiiIllIlIIIllIlllIlllllIl;
            return iiiIllIlIIIllIlllIlllllIl;
        }
        iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        this.IIIIllIlIIIllIlllIlllllIl = 0;
        return iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public int nextIndex() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public int previousIndex() {
        return this.IIIIllIlIIIllIlllIlllllIl - 1;
    }
}
