// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlllllIIIIIIIIIIlIl extends llllIIlIIIIlIIllIIIlllIIl
{
    public IIIlIIIlllllIIIIIIIIIIlIl(final long n, final llllIIlIIIIlIIllIIIlllIIl liiiIlIIllIIlIIlIIIlIIllI) {
        super(n);
        super.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int[] lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, final int n3, final int n4) {
        n -= 2;
        n2 -= 2;
        final int n5 = n >> 2;
        final int n6 = n2 >> 2;
        final int n7 = (n3 >> 2) + 2;
        final int n8 = (n4 >> 2) + 2;
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n5, n6, n7, n8);
        final int n9 = n7 - 1 << 2;
        final int[] liiiIlIIllIIlIIlIIIlIIllI2 = lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n9 * (n8 - 1 << 2));
        for (int i = 0; i < n8 - 1; ++i) {
            int j = 0;
            int n10 = liiiIlIIllIIlIIlIIIlIIllI[j + 0 + (i + 0) * n7];
            int n11 = liiiIlIIllIIlIIlIIIlIIllI[j + 0 + (i + 1) * n7];
            while (j < n7 - 1) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(j + n5 << 2, (long)(i + n6 << 2));
                final double n12 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 0.7708333134651184 * 0.648648665367556) * (1.0535714626312256 * 3.4169490420794393);
                final double n13 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 0.7555555835770983 * 0.6617646813392639) * (5.727272525552883 * 0.6285714507102966);
                this.lIIIIlIIllIIlIIlIIIlIIllI(j + n5 + 1 << 2, (long)(i + n6 << 2));
                final double n14 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 0.42682927201575716 * 1.1714285612106323) * (4.294117450714111 * 0.8383562027166538) + 4;
                final double n15 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 1.2463767528533936 * 0.4011628096041784) * (20.117646406369246 * 0.17894737422466278);
                this.lIIIIlIIllIIlIIlIIIlIIllI(j + n5 << 2, (long)(i + n6 + 1 << 2));
                final double n16 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 1.5762711763381958 * 0.3172043031082634) * (2.8051948746816184 * 1.2833333015441895);
                final double n17 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 1.4249999523162842 * 0.35087720472359923) * (4.4999999329447755 * 0.800000011920929) + 4;
                this.lIIIIlIIllIIlIIlIIIlIIllI(j + n5 + 1 << 2, (long)(i + n6 + 1 << 2));
                final double n18 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 0.36986300349235535 * 1.3518518891558573) * (0.9836065769195557 * 3.659999927282335) + 4;
                final double n19 = (this.lIIIIlIIllIIlIIlIIIlIIllI(1024) / (double)1024 - 0.37037036382939437 * 1.350000023841858) * (0.9239130616188049 * 3.896470511730156) + 4;
                final int n20 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 0) * n7] & 0xFF;
                final int n21 = liiiIlIIllIIlIIlIIIlIIllI[j + 1 + (i + 1) * n7] & 0xFF;
                for (int k = 0; k < 4; ++k) {
                    int n22 = ((i << 2) + k) * n9 + (j << 2);
                    for (int l = 0; l < 4; ++l) {
                        final double n23 = (k - n13) * (k - n13) + (l - n12) * (l - n12);
                        final double n24 = (k - n15) * (k - n15) + (l - n14) * (l - n14);
                        final double n25 = (k - n17) * (k - n17) + (l - n16) * (l - n16);
                        final double n26 = (k - n19) * (k - n19) + (l - n18) * (l - n18);
                        if (n23 < n24 && n23 < n25 && n23 < n26) {
                            liiiIlIIllIIlIIlIIIlIIllI2[n22++] = n10;
                        }
                        else if (n24 < n23 && n24 < n25 && n24 < n26) {
                            liiiIlIIllIIlIIlIIIlIIllI2[n22++] = n20;
                        }
                        else if (n25 < n23 && n25 < n24 && n25 < n26) {
                            liiiIlIIllIIlIIlIIIlIIllI2[n22++] = n11;
                        }
                        else {
                            liiiIlIIllIIlIIlIIIlIIllI2[n22++] = n21;
                        }
                    }
                }
                n10 = n20;
                n11 = n21;
                ++j;
            }
        }
        final int[] liiiIlIIllIIlIIlIIIlIIllI3 = lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 * n4);
        for (int n27 = 0; n27 < n4; ++n27) {
            System.arraycopy(liiiIlIIllIIlIIlIIIlIIllI2, (n27 + (n2 & 0x3)) * n9 + (n & 0x3), liiiIlIIllIIlIIlIIIlIIllI3, n27 * n3, n3);
        }
        return liiiIlIIllIIlIIlIIIlIIllI3;
    }
}
