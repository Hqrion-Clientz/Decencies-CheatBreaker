import java.util.Iterator;
import java.util.function.Consumer;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class CBStaffModules
{
    public final List lIIIIlIIllIIlIIlIIIlIIllI;
    public final List<IlIIIIlllIIIlIIllllIIIlll> lIIIIIIIIIlIllIIllIlIIlIl;
    public final IlIIlllIIlIlIIIlIlllllIll IlllIIIlIlllIllIlIIlllIlI;
    public final IIIIIlllIllIIIIllIllIIIII IIIIllIlIIIllIlllIlllllIl;
    public final llIIllIIIllllIIIllIIIIIIl IIIIllIIllIIIIllIllIIIlIl;
    public final IlIIIIlIlllIllIlIlIIlIlIl IlIlIIIlllIIIlIlllIlIllIl;
    public final lIlllIIIlIlIIlIIIIIIlIlII IIIllIllIlIlllllllIlIlIII;
    public final lIllIllIIlIlIIIIllIllllll IllIIIIIIIlIlIllllIIllIII;
    public final lIIlIlIllllllIllllIIllllI lIIIIllIIlIlIllIIIlIllIlI;
    public final lIIIlIlIIIlIlIlllIlIlllII IlllIllIlIIIIlIIlIIllIIIl;
    public final IlllIIllllllllIlIlIlllllI IlIlllIIIIllIllllIllIIlIl;
    public final llIlIlIIIIIIIlllIIIllIlll llIIlllIIIIlllIllIlIlllIl;
    public final IlIllIIIIIlIlllIIIIlllIIl lIIlIlIllIIlIIIlIIIlllIII;
    public final llIIIlllllIlllIIllIlIIlII IIIlllIIIllIllIlIIIIIIlII;
    public final IllIIIIIIlIlIlllllllIIllI llIlIIIlIIIIlIlllIlIIIIll;
    public final llllllIIIIIlllllIllIlIllI IIIlIIllllIIllllllIlIIIll;
    public final lIllIlllIIllIllllIllIIlll lllIIIIIlIllIlIIIllllllII;
    public final IIIlllIllIIllIllIlIIIllII lIIIIIllllIIIIlIlIIIIlIlI;
    public final lllIlIIIllIIlIIlIlIllIIlI IIIIIIlIlIlIllllllIlllIlI;
    public final IIlIIlIlIlIlllIIlIIlIIlII IllIllIIIlIIlllIIIllIllII;
    public final llllIIIllllllIlllIIlIIlll IlIIlIIIIlIIIIllllIIlIllI;
    public final IlllIIIllIlIlIIIllIIIlIlI lIIlIIllIIIIIlIllIIIIllII;
    public final lllIIlIIIllIIlllIlIIIllIl lIIlllIIlIlllllllllIIIIIl;
    
    public CBStaffModules(final CBEventBus cbEventBus) {
        (this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList()).add(this.IlllIIIlIlllIllIlIIlllIlI = new IlIIlllIIlIlIIIlIlllllIll());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IIIIllIlIIIllIlllIlllllIl = new IIIIIlllIllIIIIllIllIIIII());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IIIIllIIllIIIIllIllIIIlIl = new llIIllIIIllllIIIllIIIIIIl());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IlIlIIIlllIIIlIlllIlIllIl = new IlIIIIlIlllIllIlIlIIlIlIl());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IIIllIllIlIlllllllIlIlIII = new lIlllIIIlIlIIlIIIIIIlIlII());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IllIIIIIIIlIlIllllIIllIII = new lIllIllIIlIlIIIIllIllllll());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.lIIIIllIIlIlIllIIIlIllIlI = new lIIlIlIllllllIllllIIllllI());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IlllIllIlIIIIlIIlIIllIIIl = new lIIIlIlIIIlIlIlllIlIlllII());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IlIlllIIIIllIllllIllIIlIl = new IlllIIllllllllIlIlIlllllI());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.llIIlllIIIIlllIllIlIlllIl = new llIlIlIIIIIIIlllIIIllIlll());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.lIIlIlIllIIlIIIlIIIlllIII = new IlIllIIIIIlIlllIIIIlllIIl());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IIIlllIIIllIllIlIIIIIIlII = new llIIIlllllIlllIIllIlIIlII());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.llIlIIIlIIIIlIlllIlIIIIll = new IllIIIIIIlIlIlllllllIIllI());
        this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.IIIlIIllllIIllllllIlIIIll = new llllllIIIIIlllllIllIlIllI());
        (this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList()).add(this.lllIIIIIlIllIlIIIllllllII = new lIllIlllIIllIllllIllIIlll("xray"));
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(this.lIIIIIllllIIIIlIlIIIIlIlI = new IIIlllIllIIllIllIlIIIllII("nametags"));
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(this.IIIIIIlIlIlIllllllIlllIlI = new lllIlIIIllIIlIIlIlIllIIlI("noclip"));
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(this.IllIllIIIlIIlllIIIllIllII = new IIlIIlIlIlIlllIIlIIlIIlII("bunnyhop"));
        this.lIIlllIIlIlllllllllIIIIIl = new lllIIlIIIllIIlllIlIIIllIl();
        this.IlIIlIIIIlIIIIllllIIlIllI = new llllIIIllllllIlllIIlIIlll();
        (this.lIIlIIllIIIIIlIllIIIIllII = new IlllIIIllIlIlIIIllIIIlIlI()).lIIIIlIIllIIlIIlIIIlIIllI(true);
        cbEventBus.addEvent(IllIIlIIlllllIllIIIlllIII.class, this::lIIIIlIIllIIlIIlIIIlIIllI1);
        cbEventBus.addEvent(IlIIlIIIIlIIIIllllIIlIllI.class, this::lIIIIlIIllIIlIIlIIIlIIllI2);
        cbEventBus.addEvent(CBDisconnectEvent.class, p0 -> {
            CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI("", "", 0);
            final Iterator<IlIIIIlllIIIlIIllllIIIlll> iterator = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator.hasNext()) {
                IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll = iterator.next();
                ilIIIIlllIIIlIIllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(false);
                ilIIIIlllIIIlIIllllIIIlll.IIIIllIlIIIllIlllIlllllIl(false);
            }
        });
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI1(final IllIIlIIlllllIllIIIlllIII illIIlIIlllllIllIIIlllIII) {
        if ((int)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIlIllllIlIIllllIIlll.IIIIllIlIIIllIlllIlllllIl() != -14490) {
            illIIlIIlllllIllIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI((long)(int)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIlIlIllllIlIIllllIIlll.IIIIllIlIIIllIlllIlllllIl());
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI2(final IlIIlIIIIlIIIIllllIIlIllI ilIIlIIIIlIIIIllllIIlIllI) {
        if (ilIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI() == 0) {
            return;
        }
        for (final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final lIllIlIlIIlIllIllllIllIIl lIllIlIlIIlIllIllllIllIIl = (lIllIlIlIIlIllIllllIllIIl)ilIIIIlllIIIlIIllllIIIlll;
            if (lIllIlIlIIlIllIllllIllIIl.IIIIllIIllIIIIllIllIIIlIl() && (int)lIllIlIlIIlIllIllllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI().IIIIllIlIIIllIlllIlllllIl() == ilIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI()) {
                lIllIlIlIIlIllIllllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(!ilIIIIlllIIIlIIllllIIIlll.IlIlIIIlllIIIlIlllIlIllIl());
            }
        }
    }
}
