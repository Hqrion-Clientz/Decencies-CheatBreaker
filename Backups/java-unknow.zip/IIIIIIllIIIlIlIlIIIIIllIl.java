// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllIIIlIlIlIIIIIllIl
{
    private final lllIIIIIIIllIlllllIIlllll lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final float IlllIIIlIlllIllIlIIlllIlI;
    private final float IIIIllIlIIIllIlllIlllllIl;
    private final String IIIIllIIllIIIIllIllIIIlIl;
    private final float IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIIIIllIIIlIlIlIIIIIllIl(final lllIIIIIIIllIlllllIIlllll liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final float iiiIllIlIIIllIlllIlllllIl, final float illlIIIlIlllIllIlIIlllIlI, final String iiiIllIIllIIIIllIllIIIlIl, final float ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public lllIIIIIIIllIlllllIIlllll lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public float lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl() instanceof EntityLivingBase;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public IllIllIIlIIlIlllIIllIIIlI IIIIllIIllIIIIllIllIIIlIl() {
        return (this.lIIIIlIIllIIlIIlIIIlIIllI().IlllIllIlIIIIlIIlIIllIIIl() == null) ? null : this.lIIIIlIIllIIlIIlIIIlIIllI().IlllIllIlIIIIlIIlIIllIIIl().IIlIIllIIIllllIIlllIllIIl();
    }
    
    public float IlIlIIIlllIIIlIlllIlIllIl() {
        return (this.lIIIIlIIllIIlIIlIIIlIIllI == lllIIIIIIIllIlllllIIlllll.lIIIIllIIlIlIllIIIlIllIlI) ? (2.6218477E38f * 1.2978723f) : this.IlIlIIIlllIIIlIlllIlIllIl;
    }
}
