import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class CheatBreakerSplash extends CBAbstractGui
{
    private final ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private final Minecraft IIIIllIIllIIIIllIllIIIlIl;
    private ScaledResolution IlIlIIIlllIIIlIlllIlIllIl;
    private Framebuffer IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private String IlllIllIlIIIIlIIlIIllIIIl;
    private lIlIllIlIlIIIllllIlIllIll IlIlllIIIIllIllllIllIIlIl;
    
    public CheatBreakerSplash(final int illIIIIIIIlIlIllllIIllIII) {
        this.IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("client/logo_108.png");
        this.IIIIllIIllIIIIllIllIIIlIl = Minecraft.getMinecraft();
        this.IlIlllIIIIllIllllIllIIlIl = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.IllllIllllIlIIIlIIIllllll(), 14);
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.IlIlIIIlllIIIlIlllIlIllIl = new ScaledResolution(this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.displayWidth, this.IIIIllIIllIIIIllIllIIIlIl.displayHeight);
        final int scaleFactor = this.IlIlIIIlllIIIlIlllIlIllIl.getScaleFactor();
        this.IIIllIllIlIlllllllIlIlIII = new Framebuffer(this.IlIlIIIlllIIIlIlllIlIllIl.getScaledWidth() * scaleFactor, this.IlIlIIIlllIIIlIlllIlIllIl.getScaledHeight() * scaleFactor, true);
    }
    
    public void setSection(final String illlIllIlIIIIlIIlIIllIIIl) {
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        ++this.lIIIIllIIlIlIllIIIlIllIlI;
        this.setProgress(0.0f, 0.0f);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2) {
        final float n3 = 27;
        lIlIIIlllIllllIlllIIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIlIIIllIlllIlllllIl, n3, (float)(n / 2 - n3), (float)(n2 / 2 - n3));
    }
    
    private void shutdown() {
        this.IIIllIllIlIlllllllIlIlIII.bindFramebuffer(false);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)this.IlIlIIIlllIIIlIlllIlIllIl.getScaledWidth(), (double)this.IlIlIIIlllIIIlIlllIlIllIl.getScaledHeight(), 0.0, (double)1000, (double)3000);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, (float)(-2000));
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        GL11.glDisable(2929);
        GL11.glEnable(3553);
        GL11.glEnable(3008);
    }
    
    private void setIngameFocus() {
        final int scaleFactor = this.IlIlIIIlllIIIlIlllIlIllIl.getScaleFactor();
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        this.IIIllIllIlIlllllllIlIlIII.unbindFramebuffer();
        this.IIIllIllIlIlllllllIlIlIII.framebufferRender(this.IlIlIIIlllIIIlIlllIlIllIl.getScaledWidth() * scaleFactor, this.IlIlIIIlllIIIlIlllIlIllIl.getScaledHeight() * scaleFactor);
        GL11.glAlphaFunc(516, 0.095238104f * 1.05f);
        GL11.glFlush();
    }
    
    @Override
    public void setProgress(final float n, final float n2) {
        this.shutdown();
        final double illlIIIlIlllIllIlIIlllIlI = this.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI();
        final double iiiIllIlIIIllIlllIlllllIl = this.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl();
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)illlIIIlIlllIllIlIIlllIlI, (float)iiiIllIlIIIllIlllIlllllIl, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl);
        final float n3 = 160;
        final float n4 = (float)illlIIIlIlllIllIlIIlllIlI / 2.0f - 80;
        final float n5 = (float)iiiIllIlIIIllIlllIlllllIl - 40;
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n4 + 160, n5 + 10, (double)8, -657931);
        final float n6 = n3 * (this.lIIIIllIIlIlIllIIIlIllIlI / (float)this.IllIIIIIIIlIlIllllIIllIII);
        if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
            this.IlIlllIIIIllIllllIllIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIllIlIIIIlIIlIIllIIIl.toLowerCase(), (float)illlIIIlIlllIllIlIIlllIlI / 2.0f, n5 - 11, -3092272);
        }
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n4 + n6, n5 + 10, (double)8, -2473389);
        this.setIngameFocus();
        this.IIIIllIIllIIIIllIllIIIlIl.resetSize();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final int n3) {
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final int n3) {
    }
}
