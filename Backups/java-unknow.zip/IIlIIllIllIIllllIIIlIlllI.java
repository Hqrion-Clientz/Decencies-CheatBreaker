// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIllIIllllIIIlIlllI extends llIlIIIlIIlIlllIIlIIIIIll
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private long lIIIIIIIIIlIllIIllIlIIlIl;
    private String IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIllIllIIllllIIIlIlllI() {
    }
    
    public IIlIIllIllIIllllIIIlIlllI(final String liiiIlIIllIIlIIlIIIlIIllI, final long liiiiiiiiIlIllIIllIlIIlIl, final String illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().writeLong(this.lIIIIIIIIIlIllIIllIlIIlIl);
        liiiIlIIIllIIIIIlIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIIIIlIIIllIIIIIlIIIIIlII liiiIlIIIllIIIIIlIIIIIlII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIIllIIIIIlIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiIlIIIllIIIIIlIIIIIlII.IIIIllIlIIIllIlllIlllllIl().readLong();
        this.IlllIIIlIlllIllIlIIlllIlI = liiiIlIIIllIIIIIlIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIlIIIlIlIllIIllllII illllIIlIIIlIlIllIIllllII) {
        ((llllIIlIIllIIIlllIlIIIllI)illllIIlIIIlIlIllIIllllII).lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public long IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
}
