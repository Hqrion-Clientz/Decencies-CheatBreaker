import org.apache.logging.log4j.LogManager;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import com.google.gson.JsonObject;
import org.apache.commons.io.IOUtils;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.google.common.base.Charsets;
import java.io.InputStream;
import java.io.File;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIllIIlIIlIIIIIIIlllIlI implements IlllIIllIIIIllllIlIIllIll
{
    private static final Logger lIIIIIIIIIlIllIIllIlIIlIl;
    public final File lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIllIIlIIlIIIIIIIlllIlI(final File liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    private static String IlllIIIlIlllIllIlIIlllIlI(final ResourceLocation resourceLocation) {
        return String.format("%s/%s/%s", "assets", resourceLocation.lIIIIIIIIIlIllIIllIlIIlIl(), resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI());
    }
    
    protected static String lIIIIlIIllIIlIIlIIIlIIllI(final File file, final File file2) {
        return file.toURI().relativize(file2.toURI()).getPath();
    }
    
    @Override
    public InputStream func_152780_c(final ResourceLocation resourceLocation) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(IlllIIIlIlllIllIlIIlllIlI(resourceLocation));
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final ResourceLocation resourceLocation) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(IlllIIIlIlllIllIlIIlllIlI(resourceLocation));
    }
    
    protected abstract InputStream lIIIIlIIllIIlIIlIIIlIIllI(final String p0);
    
    protected abstract boolean lIIIIIIIIIlIllIIllIlIIlIl(final String p0);
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final String s) {
        IIIIllIIlIIlIIIIIIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl.warn("ResourcePack: ignored non-lowercase namespace: %s in %s", new Object[] { s, this.lIIIIlIIllIIlIIlIIIlIIllI });
    }
    
    @Override
    public IllIlIIlIIIIIIllIllIllIIl lIIIIlIIllIIlIIlIIIlIIllI(final IMetadataSerializer metadataSerializer, final String s) {
        return lIIIIlIIllIIlIIlIIIlIIllI(metadataSerializer, this.lIIIIlIIllIIlIIlIIIlIIllI("pack.mcmeta"), s);
    }
    
    static IllIlIIlIIIIIIllIllIllIIl lIIIIlIIllIIlIIlIIIlIIllI(final IMetadataSerializer metadataSerializer, final InputStream in, final String s) {
        JsonObject asJsonObject = null;
        Reader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(in, Charsets.UTF_8));
            asJsonObject = new JsonParser().parse(reader).getAsJsonObject();
        }
        catch (RuntimeException ex) {
            throw new JsonParseException((Throwable)ex);
        }
        finally {
            IOUtils.closeQuietly(reader);
        }
        return metadataSerializer.lIIIIlIIllIIlIIlIIIlIIllI(s, asJsonObject);
    }
    
    @Override
    public BufferedImage lIIIIIIIIIlIllIIllIlIIlIl() {
        return ImageIO.read(this.lIIIIlIIllIIlIIlIIIlIIllI("pack.png"));
    }
    
    @Override
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.getName();
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = LogManager.getLogger();
    }
}
