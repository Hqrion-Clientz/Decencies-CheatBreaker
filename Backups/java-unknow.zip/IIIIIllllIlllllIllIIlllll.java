// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllllIlllllIllIIlllll extends Material
{
    public IIIIIllllIlllllIllIIlllll(final llIllllIlIlIlllIllIlIIIll llIllllIlIlIlllIllIlIIIll) {
        super(llIllllIlIlIlllIllIlIIIll);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return false;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return false;
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return false;
    }
}
