import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIlIIlllIIIllIIlIlIlI
{
    private static Map lIIIIlIIllIIlIIlIIIlIIllI;
    private static long lIIIIIIIIIlIllIIllIlIIlIl;
    private static final double IlllIIIlIlllIllIlIIlllIlI = 7.5;
    private static final double IIIIllIlIIIllIlllIlllllIl = 56.25;
    private static final int IIIIllIIllIIIIllIllIIIlIl = 15;
    private static final int IlIlIIIlllIIIlIlllIlIllIl = 15;
    private static final int IIIllIllIlIlllllllIlIlIII = 10;
    private static final int IllIIIIIIIlIlIllllIIllIII = 8;
    private static final int lIIIIllIIlIlIllIIIlIllIlI = 13;
    private static final int IlllIllIlIIIIlIIlIIllIIIl = 8;
    private static final int IlIlllIIIIllIllllIllIIlIl = 8;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final RenderGlobal renderGlobal) {
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity, final RenderGlobal renderGlobal) {
        final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            final lIIIIlllIIIllIlIIIlIIlIIl liiiIlllIIIllIlIIIlIIlIIl = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.remove(lIllIIIllllIlllIIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(entity.lIIIIlllIIlIlllllIlIllIII()));
            if (liiiIlllIIIllIlIIIlIIlIIl != null) {
                liiiIlllIIIllIlIIIlIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl(renderGlobal);
            }
        }
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final RenderGlobal renderGlobal) {
        final long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis >= IIllIIlIIlllIIIllIIlIlIlI.lIIIIIIIIIlIllIIllIlIIlIl + 50L) {
            IIllIIlIIlllIIIllIIlIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = currentTimeMillis;
            final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
            synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
                IlllIIIlIlllIllIlIIlllIlI(renderGlobal);
                if (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.size() > 0) {
                    final Iterator<lIIIIlllIIIllIlIIIlIIlIIl> iterator = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.values().iterator();
                    while (iterator.hasNext()) {
                        iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(renderGlobal);
                    }
                }
            }
        }
    }
    
    private static void IlllIIIlIlllIllIlIIlllIlI(final RenderGlobal renderGlobal) {
        final WorldClient liiiiiiiiIlIllIIllIlIIlIl = renderGlobal.lIIIIIIIIIlIllIIllIlIIlIl;
        if (liiiiiiiiIlIllIIllIlIIlIl != null) {
            for (final Entity entity : liiiiiiiiIlIllIIllIlIIlIl.lIIIIIllllIIIIlIlIIIIlIlI()) {
                if (lIIIIlIIllIIlIIlIIIlIIllI(entity) > 0) {
                    final Integer liiiIlIIllIIlIIlIIIlIIllI = lIllIIIllllIlllIIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(entity.lIIIIlllIIlIlllllIlIllIII());
                    if (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.get(liiiIlIIllIIlIIlIIIlIIllI) != null) {
                        continue;
                    }
                    IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.put(liiiIlIIllIIlIIlIIIlIIllI, new lIIIIlllIIIllIlIIIlIIlIIl(entity));
                }
                else {
                    final lIIIIlllIIIllIlIIIlIIlIIl liiiIlllIIIllIlIIIlIIlIIl = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.remove(lIllIIIllllIlllIIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(entity.lIIIIlllIIlIlllllIlIllIII()));
                    if (liiiIlllIIIllIlIIIlIIlIIl == null) {
                        continue;
                    }
                    liiiIlllIIIllIlIIIlIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl(renderGlobal);
                }
            }
        }
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, int liiiIlIIllIIlIIlIIIlIIllI) {
        liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3), liiiIlIIllIIlIIlIIIlIIllI);
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, int liiiIlIIllIIlIIlIIIlIIllI) {
        liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI(entity), liiiIlIIllIIlIIlIIIlIIllI);
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final double n, int n2) {
        if (n > 0.0) {
            final int n3 = (int)(n * 16);
            if (n3 > (n2 & 0xFF)) {
                n2 &= 0xFFFFFF00;
                n2 |= n3;
            }
        }
        return n2;
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        double n4 = 0.0;
        final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            for (final lIIIIlllIIIllIlIIIlIIlIIl liiiIlllIIIllIlIIIlIIlIIl : IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.values()) {
                int n5 = liiiIlllIIIllIlIIIlIIlIIl.IIIIllIIllIIIIllIllIIIlIl();
                if (n5 > 0) {
                    final double liiiiiiiiIlIllIIllIlIIlIl = liiiIlllIIIllIlIIIlIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl();
                    final double illlIIIlIlllIllIlIIlllIlI = liiiIlllIIIllIlIIIlIIlIIl.IlllIIIlIlllIllIlIIlllIlI();
                    final double iiiIllIlIIIllIlllIlllllIl = liiiIlllIIIllIlIIIlIIlIIl.IIIIllIlIIIllIlllIlllllIl();
                    final double n6 = n - liiiiiiiiIlIllIIllIlIIlIl;
                    final double n7 = n2 - illlIIIlIlllIllIlIIlllIlI;
                    final double n8 = n3 - iiiIllIlIIIllIlllIlllllIl;
                    double a = n6 * n6 + n7 * n7 + n8 * n8;
                    if (liiiIlllIIIllIlIIIlIIlIIl.IlIlIIIlllIIIlIlllIlIllIl() && !lIIIllIIIllIlllllIIlIllII.IlIIlllIlIIIlIIIlIlIlIlIl()) {
                        n5 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(n5 - 2, 0, 15);
                        a *= 2;
                    }
                    if (a > 58.08423977016889 * 0.9684210419654846) {
                        continue;
                    }
                    final double n9 = (1.0 - Math.sqrt(a) / (0.7875000238418579 * 9.523809235472626)) * n5;
                    if (n9 <= n4) {
                        continue;
                    }
                    n4 = n9;
                }
            }
        }
        return lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0, 15);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        if (lIlIlIlIlIllllIlllIIIlIlI == null) {
            return 0;
        }
        final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI instanceof llIllIlIlIIIIlIIIIllIllll) {
            final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI2 = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                return liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl();
            }
        }
        return (liiiIlIIllIIlIIlIIIlIIllI == IIlIlIllIlIIllIllIllIIIll.IIllllIllllIIIlIIllllIlll) ? IllllllIllIIlllIllIIlIIll.llIIlllIIIIlllIllIlIlllIl.IIIIllIlIIIllIlllIlllllIl() : ((liiiIlIIllIIlIIlIIIlIIllI != IIlIlIllIlIIllIllIllIIIll.IlIIlIllIllllIIlIllllIlII && liiiIlIIllIIlIIlIIIlIIllI != IIlIlIllIlIIllIllIllIIIll.IIIlIllIIllllIIIllllIllll) ? ((liiiIlIIllIIlIIlIIIlIIllI == IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIlIllIlIIIlllIl) ? 8 : ((liiiIlIIllIIlIIlIIIlIIllI == IIlIlIllIlIIllIllIllIIIll.llllIIIllllllIlllIIlIIlll) ? 8 : ((liiiIlIIllIIlIIlIIIlIIllI == IIlIlIllIlIIllIllIllIIIll.IlllIIIllIlIlIIIllIIIlIlI) ? (IllllllIllIIlllIllIIlIIll.IIIIIlllIllIIIIllIllIIIII.IIIIllIlIIIllIlllIlllllIl() / 2) : 0))) : 10);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        if (entity == lIIIllIIIllIlllllIIlIllII.lIIlIIIIIIIIllIIllIIlllIl().renderViewEntity && !lIIIllIIIllIlllllIIlIllII.IlIIlIIllIllIIIIIlllIIlll()) {
            return 0;
        }
        if (entity.IIllllIllllIIIlIIllllIlll()) {
            return 15;
        }
        if (entity instanceof IIIllIlIIlIllIlIllIlIIlIl) {
            return 15;
        }
        if (entity instanceof IIIllllIlllIllIIlllIlIIII) {
            return 15;
        }
        if (entity instanceof lIlllIllllIIIIlIllIIlllII) {
            return ((lIlllIllllIIIIlIllIIlllII)entity).IIIlIllIIIlllIIlIIllIlIII() ? 15 : 10;
        }
        if (entity instanceof lllllIlIlIIIIlIllIIIlIllI) {
            return (((lllllIlIlIIIIlIllIIIlIllI)entity).lIIIIIIIIIlIllIIllIlIIlIl > 1.6749999523162842 * 0.358208965421334) ? 13 : 8;
        }
        if (entity instanceof IIIIllllIlIIlllIllIlllllI && ((IIIIllllIlIIlllIllIlllllI)entity).IllIIIIIllllIlllIIlIIllIl() > 0) {
            return 15;
        }
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            return Math.max(lIIIIlIIllIIlIIlIIIlIIllI(entityLivingBase.IllIIIllIlIIlIllIIIllllIl()), lIIIIlIIllIIlIIlIIIlIIllI(entityLivingBase.IlllIIIlIlllIllIlIIlllIlI(4)));
        }
        if (entity instanceof lllIIIIIlIllllIIIlllIllIl) {
            return lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI((lllIIIIIlIllllIIIlllIllIl)entity));
        }
        return 0;
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl(final RenderGlobal renderGlobal) {
        final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            final Iterator<lIIIIlllIIIllIlIIIlIIlIIl> iterator = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.values().iterator();
            while (iterator.hasNext()) {
                final lIIIIlllIIIllIlIIIlIIlIIl liiiIlllIIIllIlIIIlIIlIIl = iterator.next();
                iterator.remove();
                liiiIlllIIIllIlIIIlIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl(renderGlobal);
            }
        }
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.clear();
        }
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl() {
        final Map liiiIlIIllIIlIIlIIIlIIllI = IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        synchronized (IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            return IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.size();
        }
    }
    
    public static lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl) {
        return lllIIIIIlIllllIIIlllIllIl.lIIIlllIlIlllIIIIIIIIIlII().IlIlIIIlllIIIlIlllIlIllIl(10);
    }
    
    static {
        IIllIIlIIlllIIIllIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI = new HashMap();
        IIllIIlIIlllIIIllIIlIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = 0L;
    }
}
