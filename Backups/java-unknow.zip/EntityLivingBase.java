import java.util.List;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class EntityLivingBase extends Entity
{
    private static final UUID lIIIIlIIllIIlIIlIIIlIIllI;
    private static final IllIIlIIllIlllIIIIIllllII lIIIIIIIIIlIllIIllIlIIlIl;
    private IlIlIIlllIIllIIIllIIllIlI IlllIIIlIlllIllIlIIlllIlI;
    private final lIlllIlllllIlIlllIllIIlll IIIIllIlIIIllIlllIlllllIl;
    private final HashMap IIIIllIIllIIIIllIllIIIlIl;
    private final lIlIlIlIlIllllIlllIIIlIlI[] IIIllIllIlIlllllllIlIlIII;
    public boolean IIIlIIllllIIllllllIlIIIll;
    public int lllIIIIIlIllIlIIIllllllII;
    public int lIlIIllIIIlllIIllIIlIIllI;
    public float lIIIlIIIIIIlIIlIIlIIlIIlI;
    public int lIlIlIlIIlIlllIIIIIIllllI;
    public int llllIIllIIlllllIlIlIIllll;
    public float IllIlIIIIlIlllIlllllllIIl;
    public int IIlllllIIlIlIIlIIlllIIIII;
    public int IllIlIlllIIlIIIIIlIIIIIll;
    public float llllIlIlIlllllIllIIllIIIl;
    public float lllIIlIIllIllIIllIIlIIIIl;
    public float IIllIllIlIIlllllIlIIIlIll;
    public float IlIlIIIlllIlIllIlIIIlllIl;
    public float llIIlllIlIIlIIIIIlIllllll;
    public int IIllllIIIIllIIlIllIIIIIlI;
    public float lIllIllIllllllIllIlllIlIl;
    public float IlIllIIllIIIIIllIlIIIIIIl;
    public float lIlllIIlllIllIlllIIllllIl;
    public float IllIIIllIlIIlIllIIIllllIl;
    public float lIIIlIlIIllIIlllIIIlIIllI;
    public float lIIIlIIlIIIIIllIIlIlIlIII;
    public float IIIlllIllIlIIllIIllIlIlll;
    public float IlIlIIIIIllIlIlIIllIlIIIl;
    public float lIIIllIIIIlIIllIIIIIIIlll;
    protected lIllIIIIlIIlIllIIIlIlIlll lIIIIIIlIIllIlIlIllIIIIll;
    protected int lIIlIIIllIIlllIlllIlIIlll;
    protected boolean lllIllIlIllIlIllIIIIIIlll;
    public int llllIIllllllIlIIlIlIIIllI;
    protected float IlllllIllIIIllIIIllIllIII;
    protected float lIlllllIlIllllIIIllllllII;
    protected float lIlIIIlIIIlllllllllllIlIl;
    protected float IIllllllIlIIIIlllIlIlIlll;
    protected float IlllIIllIlllllIIIlIllIIII;
    protected int IlIIlIllIllllIIlIllllIlII;
    protected float IIlllllIIlIIlIlIIlIIlIlII;
    protected boolean llIIllIllIlIlIlIllllllIII;
    public float IlIIlIIllIllIIIIIlllIIlll;
    public float llIIIIlIlIIIllIllIIIIllII;
    protected float llllIllIIIlIIIlIllIlIlIlI;
    protected int llIIllllIlIlIllIlIllIlIlI;
    protected double IlllIIIIlllllIlIlllllIlll;
    protected double IIIlIllIIllllIIIllllIllll;
    protected double llllIIIllllllIlllIIlIIlll;
    protected double lIlllIIIlIlIIlIIIIIIlIlII;
    protected double IlIllIIIIIlIlllIIIIlllIIl;
    private boolean IllIIIIIIIlIlIllllIIllIII;
    private EntityLivingBase lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private EntityLivingBase IlIlllIIIIllIllllIllIIlIl;
    private int llIIlllIIIIlllIllIlIlllIl;
    private float lIIlIlIllIIlIIIlIIIlllIII;
    private int IIIlllIIIllIllIlIIIIIIlII;
    private float llIlIIIlIIIIlIlllIlIIIIll;
    
    public EntityLivingBase(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIlIIIllIlllIlllllIl = new lIlllIlllllIlIlllIllIIlll(this);
        this.IIIIllIIllIIIIllIllIIIlIl = new HashMap();
        this.IIIllIllIlIlllllllIlIlIII = new lIlIlIlIlIllllIlllIIIlIlI[5];
        this.IIllllIIIIllIIlIllIIIIIlI = 20;
        this.lIIIllIIIIlIIllIIIIIIIlll = 0.79999995f * 0.025f;
        this.IllIIIIIIIlIlIllllIIllIII = true;
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.IlllIllIlIIIIlIIlIIllIIIl(this.IlllIIllllllllIlIlIlllllI());
        this.IIIIIIlIlIlIllllllIlllIlI = true;
        this.IllIIIllIlIIlIllIIIllllIl = (float)(Math.random() + 1.0) * (0.0074074073f * 1.35f);
        this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        this.lIlllIIlllIllIlllIIllllIl = (float)Math.random() * 12398;
        this.IllllIllllIlIIIlIIIllllll = (float)(Math.random() * (0.441786463619499 * 7.111111164093018) * 2);
        this.IIIlllIllIlIIllIIllIlIlll = this.IllllIllllIlIIIlIIIllllll;
        this.lIIllIIllllllIIlllIlllIIl = 0.22077923f * 2.264706f;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(7, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(8, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(9, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(6, 1.0f);
    }
    
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        this.IlllIlIlllIlIlllIIlllIlIl().lIIIIIIIIIlIllIIllIlIIlIl(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI);
        this.IlllIlIlllIlIlllIIlllIlIl().lIIIIIIIIIlIllIIllIlIIlIl(IIlIlIIlIlllIIlIIlIIllIIl.IlllIIIlIlllIllIlIIlllIlI);
        this.IlllIlIlllIlIlllIIlllIlIl().lIIIIIIIIIlIllIIllIlIIlIl(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl);
        if (!this.IIllIllIlIIlllllIlIIIlIll()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).lIIIIlIIllIIlIIlIIIlIIllI(0.3378378450870514 * 0.2959999980592728);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final boolean b) {
        if (!this.lIIlIIIIIIIIllIIllIIlllIl()) {
            this.IllllllIllllIIlllIllllllI();
        }
        if (b && this.IllllllIllllIIlllIllllllI > 0.0f) {
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - 0.1880597049640531 * 1.0634920597076416 - this.lIlIllIlIlIIIllllIlIllIll);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
            IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
            if (illlllllIlllIIllllIIlIll.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                final int ilIlllIIIIllIllllIllIIlIl = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3).IlIlllIIIIllIllllIllIIlIl();
                if (ilIlllIIIIllIllllIllIIlIl == 11 || ilIlllIIIIllIllllIllIIlIl == 32 || ilIlllIIIIllIllllIllIIlIl == 21) {
                    illlllllIlllIIllllIIlIll = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2 - 1, illlIIIlIlllIllIlIIlllIlI3);
                }
            }
            else if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.IllllllIllllIIlllIllllllI > 3) {
                this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(2006, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, MathHelper.IlIlIIIlllIIIlIlllIlIllIl(this.IllllllIllllIIlllIllllllI - 3));
            }
            illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, this, this.IllllllIllllIIlllIllllllI);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, b);
    }
    
    public boolean IlllIIllIlllllIIIlIllIIII() {
        return false;
    }
    
    @Override
    public void IlIIIIllIIIIIlllIIlIIlllI() {
        this.llllIlIlIlllllIllIIllIIIl = this.lllIIlIIllIllIIllIIlIIIIl;
        super.IlIIIIllIIIIIlllIIlIIlllI();
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("livingEntityBaseTick");
        if (this.IlIlllIIIIlIllIlllIlIIIll() && this.isEntityInsideOpaqueBlock()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IIIIllIlIIIllIlllIlllllIl, 1.0f);
        }
        if (this.IIlIlIIlIIIlIlllllIIlIIlI() || this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            this.IIllIlIllIlIllIIlIllIlIII();
        }
        final boolean b = this instanceof lIllIIIIlIIlIllIIIlIlIlll && ((lIllIIIIlIIlIllIIIlIlIlll)this).IlllIIIllIlIlIIIllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        if (this.IlIlllIIIIlIllIlllIlIIIll() && this.lIIIIlIIllIIlIIlIIIlIIllI(Material.IllIIIIIIIlIlIllllIIllIII)) {
            if (!this.IlllIIllIlllllIIIlIllIIII() && !this.lIIlIlIllIIlIIIlIIIlllIII(IIIlIlIIIIIIIlllllIlIllIl.llIlIIIlIIIIlIlllIlIIIIll.IllIIlllIllIlIllIlIIIIIII) && !b) {
                this.IllIIIIIIIlIlIllllIIllIII(this.llIIlllIIIIlllIllIlIlllIl(this.IlIllIllIllIllIllllIIIlII()));
                if (this.IlIllIllIllIllIllllIIIlII() == -20) {
                    this.IllIIIIIIIlIlIllllIIllIII(0);
                    for (int i = 0; i < 8; ++i) {
                        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("bubble", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()), this.IllIlIIIIlllIIllIIlllIIlI + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()), this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()), this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IIIIllIIllIIIIllIllIIIlIl, 2.0f);
                }
            }
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.llllIIIIIlIlIlIlIllIIIIII() && this.IlIIlIIIIlIIIIllllIIlIllI instanceof EntityLivingBase) {
                this.lIIIIlIIllIIlIIlIIIlIIllI((Entity)null);
            }
        }
        else {
            this.IllIIIIIIIlIlIllllIIllIII(300);
        }
        if (this.IlIlllIIIIlIllIlllIlIIIll() && this.lIIIlllIIIlIIIIIlIIIIIIII()) {
            this.IIllIlIllIlIllIIlIllIlIII();
        }
        this.lIllIllIllllllIllIlllIlIl = this.IlIllIIllIIIIIllIlIIIIIIl;
        if (this.IllIlIlllIIlIIIIIlIIIIIll > 0) {
            --this.IllIlIlllIIlIIIIIlIIIIIll;
        }
        if (this.lIlIlIlIIlIlllIIIIIIllllI > 0) {
            --this.lIlIlIlIIlIlllIIIIIIllllI;
        }
        if (this.IllIIIlIIlIllIllIIllllIIl > 0 && !(this instanceof llIIIIIIlIlllllIIllllIlII)) {
            --this.IllIIIlIIlIllIllIIllllIIl;
        }
        if (this.getHealth() <= 0.0f) {
            this.IlIIlIllIllllIIlIllllIlII();
        }
        if (this.lIIlIIIllIIlllIlllIlIIlll > 0) {
            --this.lIIlIIIllIIlllIlllIlIIlll;
        }
        else {
            this.lIIIIIIlIIllIlIlIllIIIIll = null;
        }
        if (this.IlIlllIIIIllIllllIllIIlIl != null && !this.IlIlllIIIIllIllllIllIIlIl.IlIlllIIIIlIllIlllIlIIIll()) {
            this.IlIlllIIIIllIllllIllIIlIl = null;
        }
        if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
            if (!this.lIIIIllIIlIlIllIIIlIllIlI.IlIlllIIIIlIllIlllIlIIIll()) {
                this.IlllIIIlIlllIllIlIIlllIlI((EntityLivingBase)null);
            }
            else if (this.IIIlIllIlllIlIllIllllllll - this.IlllIllIlIIIIlIIlIIllIIIl > 100) {
                this.IlllIIIlIlllIllIlIIlllIlI((EntityLivingBase)null);
            }
        }
        this.llllIIIllllllIlllIIlIIlll();
        this.IIllllllIlIIIIlllIlIlIlll = this.lIlIIIlIIIlllllllllllIlIl;
        this.lIIIlIIlIIIIIllIIlIlIlIII = this.lIIIlIlIIllIIlllIIIlIIllI;
        this.IlIlIIIIIllIlIlIIllIlIIIl = this.IIIlllIllIlIIllIIllIlIlll;
        this.IlIlIIIlllllIIIlIlIlIllII = this.IllllIllllIlIIIlIIIllllll;
        this.IIlIIllIIIllllIIlllIllIIl = this.IllIIlllIllIlIllIlIIIIIII;
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
    }
    
    public boolean l_() {
        return false;
    }
    
    protected void IlIIlIllIllllIIlIllllIlII() {
        ++this.IIlllllIIlIlIIlIIlllIIIII;
        if (this.IIlllllIIlIlIIlIIlllIIIII == 20) {
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && (this.lIIlIIIllIIlllIlllIlIIlll > 0 || this.llIIllIllIlIlIlIllllllIII()) && this.IIlllllIIlIIlIlIIlIIlIlII() && this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("doMobLoot")) {
                int i = this.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIIIlIIllIlIlIllIIIIll);
                while (i > 0) {
                    final int liiiIlIIllIIlIIlIIIlIIllI = IIIIlllIIIlllllIIlllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(i);
                    i -= liiiIlIIllIIlIIlIIIlIIllI;
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new IIIIlllIIIlllllIIlllIIIIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, liiiIlIIllIIlIIlIIIlIIllI));
                }
            }
            this.IlIllllIIIlIllllIIIIIllII();
            for (int j = 0; j < 20; ++j) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("explode", this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.019024390299216685 * 1.0512820482254028), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.09529412031998692 * 0.20987653732299805), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.05428571497907445 * 0.3684210479259491));
            }
        }
    }
    
    protected boolean IIlllllIIlIIlIlIIlIIlIlII() {
        return !this.l_();
    }
    
    protected int llIIlllIIIIlllIllIlIlllIl(final int n) {
        final int liiiiiiiiIlIllIIllIlIIlIl = lIIlllIlIllIIIIIlIlllIIII.lIIIIIIIIIlIllIIllIlIIlIl(this);
        return (liiiiiiiiIlIllIIllIlIIlIl > 0 && this.IlIlllIIIIlIllIlllIlIIIll.nextInt(liiiiiiiiIlIllIIllIlIIlIl + 1) > 0) ? n : (n - 1);
    }
    
    protected int IIIIllIIllIIIIllIllIIIlIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return 0;
    }
    
    protected boolean llIIllIllIlIlIlIllllllIII() {
        return false;
    }
    
    public Random IlIIlIIllIllIIIIIlllIIlll() {
        return this.IlIlllIIIIlIllIlllIlIIIll;
    }
    
    public EntityLivingBase llIIIIlIlIIIllIllIIIIllII() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public int llllIllIIIlIIIlIllIlIlIlI() {
        return this.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final EntityLivingBase liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IlllIllIlIIIIlIIlIIllIIIl = this.IIIlIllIlllIlIllIllllllll;
    }
    
    public EntityLivingBase llIIllllIlIlIllIlIllIlIlI() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public int IlllIIIIlllllIlIlllllIlll() {
        return this.llIIlllIIIIlllIllIlIlllIl;
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final Entity entity) {
        if (entity instanceof EntityLivingBase) {
            this.IlIlllIIIIllIllllIllIIlIl = (EntityLivingBase)entity;
        }
        else {
            this.IlIlllIIIIllIllllIllIIlIl = null;
        }
        this.llIIlllIIIIlllIllIlIlllIl = this.IIIlIllIlllIlIllIllllllll;
    }
    
    public int IIIlIllIIllllIIIllllIllll() {
        return this.llllIIllllllIlIIlIlIIIllI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("HealF", this.getHealth());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Health", (short)Math.ceil(this.getHealth()));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("HurtTime", (short)this.lIlIlIlIIlIlllIIIIIIllllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("DeathTime", (short)this.IIlllllIIlIlIIlIIlllIIIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("AttackTime", (short)this.IllIlIlllIIlIIIIIlIIIIIll);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("AbsorptionAmount", this.IllIIIIIIlllIIIlIIIlIIIlI());
        for (final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI : this.lIlIlIIIIllIlllIlIIlllIlI()) {
            if (lIlIlIlIlIllllIlllIIIlIlI != null) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.IllIIlIIlllllIllIIIlllIII());
            }
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Attributes", IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIlIlllIlIlllIIlllIlIl()));
        for (final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI2 : this.lIlIlIIIIllIlllIlIIlllIlI()) {
            if (lIlIlIlIlIllllIlllIIIlIlI2 != null) {
                this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(lIlIlIlIlIllllIlllIIIlIlI2.IllIIlIIlllllIllIIIlllIII());
            }
        }
        if (!this.IIIIllIIllIIIIllIllIIIlIl.isEmpty()) {
            final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
            final Iterator<llIlIlIIlIlIllllIIlIIIlIl> iterator = this.IIIIllIIllIIIIllIllIIIlIl.values().iterator();
            while (iterator.hasNext()) {
                illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(new IlIIIllIIlIIlllIllllIIIIl()));
            }
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ActiveEffects", illIlllIlIllIIIIIIllIllll);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.llIlIIIlIIIIlIlllIlIIIIll(ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("AbsorptionAmount"));
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Attributes", 9) && this.lIIlllIIlIlllllllllIIIIIl != null && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIlIlllIlIlllIIlllIlIl(), ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Attributes", 10));
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("ActiveEffects", 9)) {
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("ActiveEffects", 10);
            for (int i = 0; i < illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
                final llIlIlIIlIlIllllIIlIIIlIl liiiiiiiiIlIllIIllIlIIlIl = llIlIlIIlIlIllllIIlIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(i));
                if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                    this.IIIIllIIllIIIIllIllIIIlIl.put(liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(), liiiiiiiiIlIllIIllIlIIlIl);
                }
            }
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("HealF", 99)) {
            this.IlllIllIlIIIIlIIlIIllIIIl(ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("HealF"));
        }
        else {
            final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Health");
            if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                this.IlllIllIlIIIIlIIlIIllIIIl(this.IlllIIllllllllIlIlIlllllI());
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == 5) {
                this.IlllIllIlIIIIlIIlIIllIIIl(((IlIlIIIlIIllIIIlIIIllIIII)liiiIlIIllIIlIIlIIIlIIllI).lIIIIllIIlIlIllIIIlIllIlI());
            }
            else if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == 2) {
                this.IlllIllIlIIIIlIIlIIllIIIl((float)((lIIllIIIIIlIlIIIlIlIlIIIl)liiiIlIIllIIlIIlIIIlIIllI).IlIlIIIlllIIIlIlllIlIllIl());
            }
        }
        this.lIlIlIlIIlIlllIIIIIIllllI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("HurtTime");
        this.IIlllllIIlIlIIlIIlllIIIII = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("DeathTime");
        this.IllIlIlllIIlIIIIIlIIIIIll = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("AttackTime");
    }
    
    protected void llllIIIllllllIlllIIlIIlll() {
        final Iterator<Integer> iterator = this.IIIIllIIllIIIIllIllIIIlIl.keySet().iterator();
        while (iterator.hasNext()) {
            final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl.get(iterator.next());
            if (!llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this)) {
                if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                    continue;
                }
                iterator.remove();
                this.IIIIllIlIIIllIlllIlllllIl(llIlIlIIlIlIllllIIlIIIlIl);
            }
            else {
                if (llIlIlIIlIlIllllIIlIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl() % 600 != 0) {
                    continue;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIlIlIllllIIlIIIlIl, false);
            }
        }
        if (this.IllIIIIIIIlIlIllllIIllIII) {
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                if (this.IIIIllIIllIIIIllIllIIIlIl.isEmpty()) {
                    this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(8, 0);
                    this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(7, 0);
                    this.IIIIllIIllIIIIllIllIIIlIl(false);
                }
                else {
                    final int liiiIlIIllIIlIIlIIIlIIllI = IIlIllIIIlIIIIlIIIIllIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl.values());
                    this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(8, (byte)(byte)(IIlIllIIIlIIIIlIIIIllIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl.values()) ? 1 : 0));
                    this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(7, liiiIlIIllIIlIIlIIIlIIllI);
                    this.IIIIllIIllIIIIllIllIIIlIl(this.lIIlIlIllIIlIIIlIIIlllIII(IIIlIlIIIIIIIlllllIlIllIl.IIIlIIllllIIllllllIlIIIll.IllIIlllIllIlIllIlIIIIIII));
                }
            }
            this.IllIIIIIIIlIlIllllIIllIII = false;
        }
        final int illlIIIlIlllIllIlIIlllIlI = this.IlIIllIIIlllIIIIlIIIIlIll.IlllIIIlIlllIllIlIIlllIlI(7);
        final boolean b = this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(8) > 0;
        if (illlIIIlIlllIllIlIIlllIlI > 0) {
            boolean nextBoolean;
            if (!this.IIIllllIlIIlIIIlIlIlllIII()) {
                nextBoolean = this.IlIlllIIIIlIllIlllIlIIIll.nextBoolean();
            }
            else {
                nextBoolean = (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(15) == 0);
            }
            if (b) {
                nextBoolean &= (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(5) == 0);
            }
            if (nextBoolean && illlIIIlIlllIllIlIIlllIlI > 0) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(b ? "mobSpellAmbient" : "mobSpell", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() - 1.5666667071315987 * 0.3191489279270172) * this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() * this.llllIIIIlIlIllIIIllllIIll - this.lIlIllIlIlIIIllllIlIllIll, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() - 0.9767441589681448 * 0.511904776096344) * this.IlIIlIIlIllIIIIllIIllIlIl, (illlIIIlIlllIllIlIIlllIlI >> 16 & 0xFF) / (double)255, (illlIIIlIlllIllIlIIlllIlI >> 8 & 0xFF) / (double)255, (illlIIIlIlllIllIlIIlllIlI >> 0 & 0xFF) / (double)255);
            }
        }
    }
    
    public void lIlllIIIlIlIIlIIIIIIlIlII() {
        final Iterator<Integer> iterator = this.IIIIllIIllIIIIllIllIIIlIl.keySet().iterator();
        while (iterator.hasNext()) {
            final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl.get(iterator.next());
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                iterator.remove();
                this.IIIIllIlIIIllIlllIlllllIl(llIlIlIIlIlIllllIIlIIIlIl);
            }
        }
    }
    
    public Collection IlIllIIIIIlIlllIIIIlllIIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl.values();
    }
    
    public boolean lIIlIlIllIIlIIIlIIIlllIII(final int i) {
        return this.IIIIllIIllIIIIllIllIIIlIl.containsKey(i);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIlIIIIIIIlllllIlIllIl iiIlIlIIIIIIIlllllIlIllIl) {
        return this.IIIIllIIllIIIIllIllIIIlIl.containsKey(iiIlIlIIIIIIIlllllIlIllIl.IllIIlllIllIlIllIlIIIIIII);
    }
    
    public llIlIlIIlIlIllllIIlIIIlIl lIIIIIIIIIlIllIIllIlIIlIl(final IIIlIlIIIIIIIlllllIlIllIl iiIlIlIIIIIIIlllllIlIllIl) {
        return this.IIIIllIIllIIIIllIllIIIlIl.get(iiIlIlIIIIIIIlllllIlIllIl.IllIIlllIllIlIllIlIIIIIII);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIIlIlIllllIIlIIIlIl value) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl(value)) {
            if (this.IIIIllIIllIIIIllIllIIIlIl.containsKey(value.lIIIIlIIllIIlIIlIIIlIIllI())) {
                this.IIIIllIIllIIIIllIllIIIlIl.get(value.lIIIIlIIllIIlIIlIIIlIIllI()).lIIIIlIIllIIlIIlIIIlIIllI(value);
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl.get(value.lIIIIlIIllIIlIIlIIIlIIllI()), true);
            }
            else {
                this.IIIIllIIllIIIIllIllIIIlIl.put(value.lIIIIlIIllIIlIIlIIIlIIllI(), value);
                this.IlllIIIlIlllIllIlIIlllIlI(value);
            }
        }
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl) {
        if (this.IlIIIIlIlllIllIlIlIIlIlIl() == lIIIllIIlllIlIIIIIIllIllI.lIIIIIIIIIlIllIIllIlIIlIl) {
            final int liiiIlIIllIIlIIlIIIlIIllI = llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI == IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl.IllIIlllIllIlIllIlIIIIIII || liiiIlIIllIIlIIlIIIlIIllI == IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI.IllIIlllIllIlIllIlIIIIIII) {
                return false;
            }
        }
        return true;
    }
    
    public boolean llIIIlllllIlllIIllIlIIlII() {
        return this.IlIIIIlIlllIllIlIlIIlIlIl() == lIIIllIIlllIlIIIIIIllIllI.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void IIIlllIIIllIllIlIIIIIIlII(final int i) {
        this.IIIIllIIllIIIIllIllIIIlIl.remove(i);
    }
    
    public void llIlIIIlIIIIlIlllIlIIIIll(final int i) {
        final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl.remove(i);
        if (llIlIlIIlIlIllllIIlIIIlIl != null) {
            this.IIIIllIlIIIllIlllIlllllIl(llIlIlIIlIlIllllIIlIIIlIl);
        }
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl) {
        this.IllIIIIIIIlIlIllllIIllIII = true;
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()].lIIIIIIIIIlIllIIllIlIIlIl(this, this.IlllIlIlllIlIlllIIlllIlIl(), llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI());
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl, final boolean b) {
        this.IllIIIIIIIlIlIllllIIllIII = true;
        if (b && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()].lIIIIlIIllIIlIIlIIIlIIllI(this, this.IlllIlIlllIlIlllIIlllIlIl(), llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI());
            IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()].lIIIIIIIIIlIllIIllIlIIlIl(this, this.IlllIlIlllIlIlllIIlllIlIl(), llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI());
        }
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl) {
        this.IllIIIIIIIlIlIllllIIllIII = true;
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()].lIIIIlIIllIIlIIlIIIlIIllI(this, this.IlllIlIlllIlIlllIIlllIlIl(), llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI());
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final float n) {
        final float health = this.getHealth();
        if (health > 0.0f) {
            this.IlllIllIlIIIIlIIlIIllIIIl(health + n);
        }
    }
    
    public final float getHealth() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.IIIIllIlIIIllIlllIlllllIl(6);
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final float n) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(6, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, 0.0f, this.IlllIIllllllllIlIlIlllllI()));
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            return false;
        }
        this.llllIIllllllIlIIlIlIIIllI = 0;
        if (this.getHealth() <= 0.0f) {
            return false;
        }
        if (lllIIIIIIIllIlllllIIlllll.llIlIIIlIIIIlIlllIlIIIIll() && this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IIIlllIIIllIllIlIIIIIIlII)) {
            return false;
        }
        if ((lllIIIIIIIllIlllllIIlllll == lllIIIIIIIllIlllllIIlllll.lIIlIlIllIIlIIIlIIIlllIII || lllIIIIIIIllIlllllIIlllll == lllIIIIIIIllIlllllIIlllll.IIIlllIIIllIllIlIIIIIIlII) && this.IlllIIIlIlllIllIlIIlllIlI(4) != null) {
            this.IlllIIIlIlllIllIlIIlllIlI(4).lIIIIlIIllIIlIIlIIIlIIllI((int)(n * 4 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * n * 2.0f), this);
            n *= 2.1176472f * 0.35416666f;
        }
        this.IlIlIIIlllIlIllIlIIIlllIl = 9.75f * 0.15384616f;
        boolean b = true;
        if (this.IllIIIlIIlIllIllIIllllIIl > this.IIllllIIIIllIIlIllIIIIIlI / 2.0f) {
            if (n <= this.IIlllllIIlIIlIlIIlIIlIlII) {
                return false;
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(lllIIIIIIIllIlllllIIlllll, n - this.IIlllllIIlIIlIlIIlIIlIlII);
            this.IIlllllIIlIIlIlIIlIIlIlII = n;
            b = false;
        }
        else {
            this.IIlllllIIlIIlIlIIlIIlIlII = n;
            this.lIIIlIIIIIIlIIlIIlIIlIIlI = this.getHealth();
            this.IllIIIlIIlIllIllIIllllIIl = this.IIllllIIIIllIIlIllIIIIIlI;
            this.lIIIIIIIIIlIllIIllIlIIlIl(lllIIIIIIIllIlllllIIlllll, n);
            final int n2 = 10;
            this.llllIIllIIlllllIlIlIIllll = n2;
            this.lIlIlIlIIlIlllIIIIIIllllI = n2;
        }
        this.IllIlIIIIlIlllIlllllllIIl = 0.0f;
        final Entity illlIllIlIIIIlIIlIIllIIIl = lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl();
        if (illlIllIlIIIIlIIlIIllIIIl != null) {
            if (illlIllIlIIIIlIIlIIllIIIl instanceof EntityLivingBase) {
                this.IlllIIIlIlllIllIlIIlllIlI((EntityLivingBase)illlIllIlIIIIlIIlIIllIIIl);
            }
            if (illlIllIlIIIIlIIlIIllIIIl instanceof lIllIIIIlIIlIllIIIlIlIlll) {
                this.lIIlIIIllIIlllIlllIlIIlll = 100;
                this.lIIIIIIlIIllIlIlIllIIIIll = (lIllIIIIlIIlIllIIIlIlIlll)illlIllIlIIIIlIIlIIllIIIl;
            }
            else if (illlIllIlIIIIlIIlIIllIIIl instanceof IIlllllIllIlIIIIlIIIlllII && ((IIlllllIllIlIIIIlIIIlllII)illlIllIlIIIIlIIlIIllIIIl).llllIIllIIlIIllIIIllIlIlI()) {
                this.lIIlIIIllIIlllIlllIlIIlll = 100;
                this.lIIIIIIlIIllIlIlIllIIIIll = null;
            }
        }
        if (b) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)2);
            if (lllIIIIIIIllIlllllIIlllll != lllIIIIIIIllIlllllIIlllll.IIIIllIIllIIIIllIllIIIlIl) {
                this.llIIIllIIllllIlIlIlIlIIll();
            }
            if (illlIllIlIIIIlIIlIIllIIIl != null) {
                double x;
                double y;
                for (x = illlIllIlIIIIlIIlIIllIIIl.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll, y = illlIllIlIIIIlIIlIIllIIIl.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll; x * x + y * y < 0.7560975551605225 * 1.322580655333155E-4; x = (Math.random() - Math.random()) * (3.0999999046325684 * 0.0032258065508506085), y = (Math.random() - Math.random()) * (0.0028169014462874164 * 3.549999952316284)) {}
                this.IllIlIIIIlIlllIlllllllIIl = (float)(Math.atan2(y, x) * 180 / (0.953125 * 3.296097210323717)) - this.IllllIllllIlIIIlIIIllllll;
                this.lIIIIlIIllIIlIIlIIIlIIllI(illlIllIlIIIIlIIlIIllIIIl, n, x, y);
            }
            else {
                this.IllIlIIIIlIlllIlllllllIIl = (float)((int)(Math.random() * 2) * 180);
            }
        }
        if (this.getHealth() <= 0.0f) {
            final String illIIIIIIlIlIlllllllIIllI = this.IllIIIIIIlIlIlllllllIIllI();
            if (b && illIIIIIIlIlIlllllllIIllI != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(illIIIIIIlIlIlllllllIIllI, this.lIIlIlIllllllIllllIIllllI(), this.llIIllIIIllllIIIllIIIIIIl());
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll);
        }
        else {
            final String llIlIlIIIIIIIlllIIIllIlll = this.llIlIlIIIIIIIlllIIIllIlll();
            if (b && llIlIlIIIIIIIlllIIIllIlll != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIIIIIIlllIIIllIlll, this.lIIlIlIllllllIllllIIllllI(), this.llIIllIIIllllIIIllIIIIIIl());
            }
        }
        return true;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("random.break", 3.7222223f * 0.21492536f, 0.92800003f * 0.86206895f + this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextFloat() * (0.27272728f * 1.4666667f));
        for (int i = 0; i < 5; ++i) {
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.010416666977107525 * 47.99999856948857) * (4.800000190734863 * 0.02083333250549108), Math.random() * (0.02465753553508265 * 4.05555534362793) + 0.07118644039030221 * 1.4047619104385376, 0.0);
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(-this.IllIIlllIllIlIllIlIIIIIII * (6.432785f * 0.4883721f) / 180);
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(-this.IllllIllllIlIIIlIIIllllll * (13.333333f * 0.23561946f) / 180);
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 2.4999999627470975 * 0.20000000298023224) * (1.7575757503509521 * 0.17068965587406182), -this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.8571428717399132 * 0.699999988079071) - 0.5099999787211427 * 0.5882353186607361, 1.519999945640566 * 0.3947368562221527);
            liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(-this.IllIIlllIllIlIllIlIIIIIII * (5.1705384f * 0.6075949f) / 180);
            liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl(-this.IllllIllllIlIIIlIIIllllll * (3.6651914f * 0.85714287f) / 180);
            final lIllIIIIlllllIIlIllIIIIII illlIIIlIlllIllIlIIlllIlI = liiiIlIIllIIlIIlIIIlIIllI2.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.lIIlIlIllIIlIIIlIIIlllIII(), this.IllIlIlIllllIlIIllllIIlll);
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("iconcrack_" + lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()), illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI, illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl + 0.012307692307692308 * 4.0625, liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll) {
        final Entity illlIllIlIIIIlIIlIIllIIIl = lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl();
        final EntityLivingBase llllllIIIIIlllllIllIlIllI = this.llllllIIIIIlllllIllIlIllI();
        if (this.IlIIlIllIllllIIlIllllIlII >= 0 && llllllIIIIIlllllIllIlIllI != null) {
            llllllIIIIIlllllIllIlIllI.lIIIIIIIIIlIllIIllIlIIlIl(this, this.IlIIlIllIllllIIlIllllIlII);
        }
        if (illlIllIlIIIIlIIlIIllIIIl != null) {
            illlIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
        }
        this.lllIllIlIllIlIllIIIIIIlll = true;
        this.lIllIllIIlIlIIIIllIllllll().IIIIllIlIIIllIlllIlllllIl();
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            int illIIIIIIIlIlIllllIIllIII = 0;
            if (illlIllIlIIIIlIIlIIllIIIl instanceof lIllIIIIlIIlIllIIIlIlIlll) {
                illIIIIIIIlIlIllllIIllIII = lIIlllIlIllIIIIIlIlllIIII.IllIIIIIIIlIlIllllIIllIII((EntityLivingBase)illlIllIlIIIIlIIlIIllIIIl);
            }
            if (this.IIlllllIIlIIlIlIIlIIlIlII() && this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("doMobLoot")) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIIllIIlllIlllIlIIlll > 0, illIIIIIIIlIlIllllIIllIII);
                this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlIIIllIIlllIlllIlIIlll > 0, illIIIIIIIlIlIllllIIllIII);
                if (this.lIIlIIIllIIlllIlllIlIIlll > 0) {
                    final int n = this.IlIlllIIIIlIllIlllIlIIIll.nextInt(200) - illIIIIIIIlIlIllllIIllIII;
                    if (n < 5) {
                        this.IIIlIIllllIIllllllIlIIIll((n <= 0) ? 1 : 0);
                    }
                }
            }
        }
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)3);
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final boolean b, final int n) {
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n, final double n2, final double n3) {
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() >= this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IlllIIIlIlllIllIlIIlllIlI).IIIIllIIllIIIIllIllIIIlIl()) {
            this.IIIllllIlIIlIIIlIlIlllIII = true;
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2 * n2 + n3 * n3);
            final float n4 = 9.4f * 0.042553194f;
            this.IllIIlIIlllllIllIIIlllIII /= 2;
            this.lIlIlIllIIIIIIIIllllIIllI /= 2;
            this.IlllIIlllIIIIllIIllllIlIl /= 2;
            this.IllIIlIIlllllIllIIIlllIII -= n2 / liiiIlIIllIIlIIlIIIlIIllI * n4;
            this.lIlIlIllIIIIIIIIllllIIllI += n4;
            this.IlllIIlllIIIIllIIllllIlIl -= n3 / liiiIlIIllIIlIIlIIIlIIllI * n4;
            if (this.lIlIlIllIIIIIIIIllllIIllI > 3.923076868057251 * 0.1019607872630211) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.30833335171143295 * 1.2972972393035889;
            }
        }
    }
    
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "game.neutral.hurt";
    }
    
    protected String IllIIIIIIlIlIlllllllIIllI() {
        return "game.neutral.die";
    }
    
    protected void IIIlIIllllIIllllllIlIIIll(final int n) {
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
    }
    
    public boolean m_() {
        final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll));
        return block == IllllllIllIIlllIllIIlIIll.llIIIlIlIIlIlIIlIllIllIll || block == IllllllIllIIlllIllIIlIIll.llllIIllllllIlIIlIlIIIllI;
    }
    
    @Override
    public boolean IlIlllIIIIlIllIlllIlIIIll() {
        return !this.IIllIlIllIlIllIIlIllIlIII && this.getHealth() > 0.0f;
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        super.IlIlIIIlllIIIlIlllIlIllIl(n);
        final llIlIlIIlIlIllllIIlIIIlIl liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl);
        final int ilIlIIIlllIIIlIlllIlIllIl = MathHelper.IlIlIIIlllIIIlIlllIlIllIl(n - 3 - ((liiiiiiiiIlIllIIllIlIIlIl != null) ? ((float)(liiiiiiiiIlIllIIllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI() + 1)) : 0.0f));
        if (ilIlIIIlllIIIlIlllIlIllIl > 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIIIIIlIllIlIIIllllllII(ilIlIIIlllIIIlIlllIlIllIl), 1.0f, 1.0f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IllIIIIIIIlIlIllllIIllIII, (float)ilIlIIIlllIIIlIlllIlIllIl);
            final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - 0.2591549351796629 * 0.77173912525177 - this.lIlIllIlIlIIIllllIlIllIll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll));
            if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                final lIIIIIlIllIIIIlllIIlIIlIl illlIIlllIIIIllIIllllIlIl = block.IlllIIlllIIIIllIIllllIlIl;
                this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIlllIIIIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl(), illlIIlllIIIIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI() * (0.39041096f * 1.2807018f), illlIIlllIIIIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl() * (0.012987013f * 57.75f));
            }
        }
    }
    
    protected String lllIIIIIlIllIlIIIllllllII(final int n) {
        return (n > 4) ? "game.neutral.hurt.fall.big" : "game.neutral.hurt.fall.small";
    }
    
    @Override
    public void IIIlllllIIlIlIIIllllllIII() {
        final int n = 10;
        this.llllIIllIIlllllIlIlIIllll = n;
        this.lIlIlIlIIlIlllIIIIIIllllI = n;
        this.IllIlIIIIlIlllIlllllllIIl = 0.0f;
    }
    
    public int IlIIlllIIlIlIIIlIlllllIll() {
        int n = 0;
        for (final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI : this.lIlIlIIIIllIlllIlIIlllIlI()) {
            if (lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() instanceof llIlIlIlIlllIlllIlIIIIlll) {
                n += ((llIlIlIlIlllIlllIlIIIIlll)lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()).IlIlllIIIIllIllllIllIIlIl;
            }
        }
        return n;
    }
    
    protected void IlIlllIIIIllIllllIllIIlIl(final float n) {
    }
    
    protected float IlllIIIlIlllIllIlIIlllIlI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, float n) {
        if (!lllIIIIIIIllIlllllIIlllll.IIIIllIIllIIIIllIllIIIlIl()) {
            final float n2 = n * (25 - this.IlIIlllIIlIlIIIlIlllllIll());
            this.IlIlllIIIIllIllllIllIIlIl(n);
            n = n2 / 25;
        }
        return n;
    }
    
    protected float IIIIllIlIIIllIlllIlllllIl(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, float n) {
        if (lllIIIIIIIllIlllllIIlllll.IllIIIIIIIlIlIllllIIllIII()) {
            return n;
        }
        if (this instanceof IIlIIIIIIlIllIIIIlIIIIlll) {
            n = n;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.lIIlIlIllIIlIIIlIIIlllIII) && lllIIIIIIIllIlllllIIlllll != lllIIIIIIIllIlllllIIlllll.lIIIIllIIlIlIllIIIlIllIlI) {
            n = n * (25 - (this.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.lIIlIlIllIIlIIIlIIIlllIII).IlllIIIlIlllIllIlIIlllIlI() + 1) * 5) / 25;
        }
        if (n <= 0.0f) {
            return 0.0f;
        }
        int liiiIlIIllIIlIIlIIIlIIllI = lIIlllIlIllIIIIIlIlllIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIlIlIIIIllIlllIlIIlllIlI(), lllIIIIIIIllIlllllIIlllll);
        if (liiiIlIIllIIlIIlIIIlIIllI > 20) {
            liiiIlIIllIIlIIlIIIlIIllI = 20;
        }
        if (liiiIlIIllIIlIIlIIIlIIllI > 0 && liiiIlIIllIIlIIlIIIlIIllI <= 20) {
            n = n * (25 - liiiIlIIllIIlIIlIIIlIIllI) / 25;
        }
        return n;
    }
    
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, float n) {
        if (!this.llllIIlIlIllIllllIIIIllll()) {
            n = this.IlllIIIlIlllIllIlIIlllIlI(lllIIIIIIIllIlllllIIlllll, n);
            final float iiiIllIlIIIllIlllIlllllIl;
            n = (iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl(lllIIIIIIIllIlllllIIlllll, n));
            n = Math.max(n - this.IllIIIIIIlllIIIlIIIlIIIlI(), 0.0f);
            this.llIlIIIlIIIIlIlllIlIIIIll(this.IllIIIIIIlllIIIlIIIlIIIlI() - (iiiIllIlIIIllIlllIlllllIl - n));
            if (n != 0.0f) {
                final float health = this.getHealth();
                this.IlllIllIlIIIIlIIlIIllIIIl(health - n);
                this.lIllIllIIlIlIIIIllIllllll().lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, health, n);
                this.llIlIIIlIIIIlIlllIlIIIIll(this.IllIIIIIIlllIIIlIIIlIIIlI() - n);
            }
        }
    }
    
    public lIlllIlllllIlIlllIllIIlll lIllIllIIlIlIIIIllIllllll() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public EntityLivingBase llllllIIIIIlllllIllIlIllI() {
        return (this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI() != null) ? this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI() : ((this.lIIIIIIlIIllIlIlIllIIIIll != null) ? this.lIIIIIIlIIllIlIlIllIIIIll : ((this.lIIIIllIIlIlIllIIIlIllIlI != null) ? this.lIIIIllIIlIlIllIIIlIllIlI : null));
    }
    
    public final float IlllIIllllllllIlIlIlllllI() {
        return (float)this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI).IIIIllIIllIIIIllIllIIIlIl();
    }
    
    public final int lIllIIIIIlIllIllllIlIllII() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(9);
    }
    
    public final void lIIIIIllllIIIIlIlIIIIlIlI(final int n) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(9, (byte)n);
    }
    
    private int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IIIIllIIllIIIIllIllIIIlIl) ? (6 - (1 + this.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IIIIllIIllIIIIllIllIIIlIl).IlllIIIlIlllIllIlIIlllIlI()) * 1) : (this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IlIlIIIlllIIIlIlllIlIllIl) ? (6 + (1 + this.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IlIlIIIlllIIIlIlllIlIllIl).IlllIIIlIlllIllIlIIlllIlI()) * 2) : 6);
    }
    
    public void swingItem() {
        if (!this.IIIlIIllllIIllllllIlIIIll || this.lllIIIIIlIllIlIIIllllllII >= this.IIIIllIIllIIIIllIllIIIlIl() / 2 || this.lllIIIIIlIllIlIIIllllllII < 0) {
            this.lllIIIIIlIllIlIIIllllllII = -1;
            this.IIIlIIllllIIllllllIlIIIll = true;
            if (this.lIIlllIIlIlllllllllIIIIIl instanceof IllllIllIIlllllIIlIIllIlI) {
                ((IllllIllIIlllllIIlIIllIlI)this.lIIlllIIlIlllllllllIIIIIl).llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(this, new lIIIIllIlllIlIlIllIlIIlIl(this, 0));
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        if (b == 2) {
            this.IlIlIIIlllIlIllIlIIIlllIl = 4.568182f * 0.3283582f;
            this.IllIIIlIIlIllIllIIllllIIl = this.IIllllIIIIllIIlIllIIIIIlI;
            final int n = 10;
            this.llllIIllIIlllllIlIlIIllll = n;
            this.lIlIlIlIIlIlllIIIIIIllllI = n;
            this.IllIlIIIIlIlllIlllllllIIl = 0.0f;
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIlIIIIIIIlllIIIllIlll(), this.lIIlIlIllllllIllllIIllllI(), (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.5217391f * 0.38333336f) + 1.0f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl, 0.0f);
        }
        else if (b == 3) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIlIlIlllllllIIllI(), this.lIIlIlIllllllIllllIIllllI(), (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (2.06383f * 0.09690721f) + 1.0f);
            this.IlllIllIlIIIIlIIlIIllIIIl(0.0f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl);
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(b);
        }
    }
    
    @Override
    protected void lIlIllIlIlIIIllllIlIllIll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIllIIlIlIllIIIlIllIlI, 4);
    }
    
    protected void IIlllllllIllIlIllIIIlllIl() {
        final int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl();
        if (this.IIIlIIllllIIllllllIlIIIll) {
            ++this.lllIIIIIlIllIlIIIllllllII;
            if (this.lllIIIIIlIllIlIIIllllllII >= iiiIllIIllIIIIllIllIIIlIl) {
                this.lllIIIIIlIllIlIIIllllllII = 0;
                this.IIIlIIllllIIllllllIlIIIll = false;
            }
        }
        else {
            this.lllIIIIIlIllIlIIIllllllII = 0;
        }
        this.lllIIlIIllIllIIllIIlIIIIl = this.lllIIIIIlIllIlIIIllllllII / (float)iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public IlIlIlllIIllIIllIllllllII lIIIIlIIllIIlIIlIIIlIIllI(final llIIllIlllllIIIlIIIIlIlll llIIllIlllllIIIlIIIIlIlll) {
        return this.IlllIlIlllIlIlllIIlllIlIl().lIIIIlIIllIIlIIlIIIlIIllI(llIIllIlllllIIIlIIIIlIlll);
    }
    
    public IlIlIIlllIIllIIIllIIllIlI IlllIlIlllIlIlllIIlllIlIl() {
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = new llIIllIlllIIIIIllllIIIIll();
        }
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public lIIIllIIlllIlIIIIIIllIllI IlIIIIlIlllIllIlIlIIlIlIl() {
        return lIIIllIIlllIlIIIIIIllIllI.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public abstract lIlIlIlIlIllllIlllIIIlIlI IllIIIllIlIIlIllIIIllllIl();
    
    public abstract lIlIlIlIlIllllIlllIIIlIlI IlllIIIlIlllIllIlIIlllIlI(final int p0);
    
    @Override
    public abstract void lIIIIlIIllIIlIIlIIIlIIllI(final int p0, final lIlIlIlIlIllllIlllIIIlIlI p1);
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean b) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(b);
        final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl);
        if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(EntityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI) != null) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(EntityLivingBase.lIIIIIIIIIlIllIIllIlIIlIl);
        }
        if (b) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(EntityLivingBase.lIIIIIIIIIlIllIIllIlIIlIl);
        }
    }
    
    @Override
    public abstract lIlIlIlIlIllllIlllIIIlIlI[] lIlIlIIIIllIlllIlIIlllIlI();
    
    protected float lIIlIlIllllllIllllIIllllI() {
        return 1.0f;
    }
    
    protected float llIIllIIIllllIIIllIIIIIIl() {
        return this.l_() ? ((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.09642857f * 2.074074f) + 0.15f * 10.0f) : ((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.14871795f * 1.3448275f) + 1.0f);
    }
    
    protected boolean IIIIIlllIllIIIIllIllIIIII() {
        return this.getHealth() <= 0.0f;
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final double n, final double n2, final double n3) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
    }
    
    public void llIIlllIIIIlllIllIlIlllIl(final Entity entity) {
        double iiIlIIlIlIIIlllIIlIllllll = entity.IIIlIIlIlIIIlllIIlIllllll;
        double n = entity.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + entity.llllIIIIlIlIllIIIllllIIll;
        double illIlIlIllllIlIIllllIIlll = entity.IllIlIlIllllIlIIllllIIlll;
        for (int n2 = 1, i = -n2; i <= n2; ++i) {
            for (int j = -n2; j < n2; ++j) {
                if (i != 0 || j != 0) {
                    final int n3 = (int)(this.IIIlIIlIlIIIlllIIlIllllll + i);
                    final int n4 = (int)(this.IllIlIlIllllIlIIllllIIlll + j);
                    if (this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(i, 1.0, j)).isEmpty()) {
                        if (IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, n3, (int)this.IllIlIIIIlllIIllIIlllIIlI, n4)) {
                            this.IlllIllIlIIIIlIIlIIllIIIl(this.IIIlIIlIlIIIlllIIlIllllll + i, this.IllIlIIIIlllIIllIIlllIIlI + 1.0, this.IllIlIlIllllIlIIllllIIlll + j);
                            return;
                        }
                        if (IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, n3, (int)this.IllIlIIIIlllIIllIIlllIIlI - 1, n4) || this.lIIlllIIlIlllllllllIIIIIl.getBlock(n3, (int)this.IllIlIIIIlllIIllIIlllIIlI - 1, n4).IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII) {
                            iiIlIIlIlIIIlllIIlIllllll = this.IIIlIIlIlIIIlllIIlIllllll + i;
                            n = this.IllIlIIIIlllIIllIIlllIIlI + 1.0;
                            illIlIlIllllIlIIllllIIlll = this.IllIlIlIllllIlIIllllIIlll + j;
                        }
                    }
                }
            }
        }
        this.IlllIllIlIIIIlIIlIIllIIIl(iiIlIIlIlIIIlllIIlIllllll, n, illIlIlIllllIlIIllllIIlll);
    }
    
    public boolean lllIllIlIllIlIllIIIIIIlll() {
        return false;
    }
    
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n) {
        return lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().IIIlIIllllIIllllllIlIIIll() ? lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl(), n) : lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    protected void k_() {
        this.lIlIlIllIIIIIIIIllllIIllI = 3.289999905452132 * 0.12765957415103912;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(IIIlIlIIIIIIIlllllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl)) {
            this.lIlIlIllIIIIIIIIllllIIllI += (this.lIIIIIIIIIlIllIIllIlIIlIl(IIIlIlIIIIIIIlllllIlIllIl.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI() + 1) * (0.21481481f * 0.46551725f);
        }
        if (this.IllIIIIllllllIlllllIlIlll()) {
            final float n = this.IllllIllllIlIIIlIIIllllll * (0.030313613f * 0.57575756f);
            this.IllIIlIIlllllIllIIIlllIII -= MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n) * (0.14117648f * 1.4166666f);
            this.IlllIIlllIIIIllIIllllIlIl += MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n) * (1.8064516f * 0.110714294f);
        }
        this.IIIllllIlIIlIIIlIlIlllIII = true;
    }
    
    public void setProgress(final float n, final float n2) {
        if (this.lIIlIIIIIIIIllIIllIIlllIl() && (!(this instanceof lIllIIIIlIIlIllIIIlIlIlll) || !((lIllIIIIlIIlIllIIIlIlIlll)this).IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl)) {
            final double illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, this.IIllIllIlIIlllllIlIIIlIll() ? (0.0139999995f * 2.857143f) : (0.014666666f * 1.3636364f));
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.IllIIlIIlllllIllIIIlllIII *= 1.2758620977401733 * 0.6270270222290492;
            this.lIlIlIllIIIIIIIIllllIIllI *= 7.466666703754001 * 0.1071428582072258;
            this.IlllIIlllIIIIllIIllllIlIl *= 0.8818182003337983 * 0.907216489315033;
            this.lIlIlIllIIIIIIIIllllIIllI -= 0.016744186417872106 * 1.1944444179534912;
            if (this.lIIIlllIlIlllIIIIIIIIIlII && this.IIIIllIlIIIllIlllIlllllIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI + 2.0416667461395264 * 0.29387755125872744 - this.IllIlIIIIlllIIllIIlllIIlI + illIlIIIIlllIIllIIlllIIlI, this.IlllIIlllIIIIllIIllllIlIl)) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.5384615659713745 * 0.5571428508174666;
            }
        }
        else if (this.IlIlllIllIlIllIlllIlllIll() && (!(this instanceof lIllIIIIlIIlIllIIIlIlIlll) || !((lIllIIIIlIIlIllIIIlIlIlll)this).IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl)) {
            final double illIlIIIIlllIIllIIlllIIlI2 = this.IllIlIIIIlllIIllIIlllIIlI;
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, 0.0089552235f * 2.2333333f);
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.IllIIlIIlllllIllIIIlllIII *= 0.3076923076923077 * 1.625;
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.2727272668160684 * 1.8333333730697632;
            this.IlllIIlllIIIIllIIllllIlIl *= 0.18617021559913435 * 2.6857142448425293;
            this.lIlIlIllIIIIIIIIllllIIllI -= 0.5222222208976746 * 0.038297872437563024;
            if (this.lIIIlllIlIlllIIIIIIIIIlII && this.IIIIllIlIIIllIlllIlllllIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI + 1.6615385580345037 * 0.3611111044883728 - this.IllIlIIIIlllIIllIIlllIIlI + illIlIIIIlllIIllIIlllIIlI2, this.IlllIIlllIIIIllIIllllIlIl)) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.3066666772277266 * 0.97826087474823;
            }
        }
        else {
            float n3 = 16.0f * 0.056875f;
            if (this.lIIIIlllIIlIlllllIlIllIII) {
                n3 = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) - 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)).IlIlIIIlllllIIIlIlIlIllII * (24.115f * 0.03773585f);
            }
            final float n4 = 0.43137255f * 0.3773336f / (n3 * n3 * n3);
            float liiIllIIIIlIIllIIIIIIIlll;
            if (this.lIIIIlllIIlIlllllIlIllIII) {
                liiIllIIIIlIIllIIIIIIIlll = this.IIIIIlIIIlllIIlIIllllIlll() * n4;
            }
            else {
                liiIllIIIIlIIllIIIIIIIlll = this.lIIIllIIIIlIIllIIIIIIIlll;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, liiIllIIIIlIIllIIIIIIIlll);
            float n5 = 0.77402306f * 1.1756756f;
            if (this.lIIIIlllIIlIlllllIlIllIII) {
                n5 = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) - 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)).IlIlIIIlllllIIIlIlIlIllII * (2.6975002f * 0.33734939f);
            }
            if (this.m_()) {
                final float n6 = 0.6419753f * 0.23365386f;
                if (this.IllIIlIIlllllIllIIIlllIII < -n6) {
                    this.IllIIlIIlllllIllIIIlllIII = -n6;
                }
                if (this.IllIIlIIlllllIllIIIlllIII > n6) {
                    this.IllIIlIIlllllIllIIIlllIII = n6;
                }
                if (this.IlllIIlllIIIIllIIllllIlIl < -n6) {
                    this.IlllIIlllIIIIllIIllllIlIl = -n6;
                }
                if (this.IlllIIlllIIIIllIIllllIlIl > n6) {
                    this.IlllIIlllIIIIllIIllllIlIl = n6;
                }
                this.IllllllIllllIIlllIllllllI = 0.0f;
                if (this.lIlIlIllIIIIIIIIllllIIllI < 1.2435897588729858 * -0.12061855521867502) {
                    this.lIlIlIllIIIIIIIIllllIIllI = 10.777777671813965 * -0.013917525910028731;
                }
                if (this.lIlIlIllIIIIIIIIllllIIllI() && this instanceof lIllIIIIlIIlIllIIIlIlIlll && this.lIlIlIllIIIIIIIIllllIIllI < 0.0) {
                    this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
                }
            }
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            if (this.lIIIlllIlIlllIIIIIIIIIlII && this.m_()) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.23859648424209048 * 0.8382353186607361;
            }
            if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && (!this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl((int)this.IIIlIIlIlIIIlllIIlIllllll, 0, (int)this.IllIlIlIllllIlIIllllIIlll) || !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl((int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIlIllllIlIIllllIIlll).IIIIllIlIIIllIlllIlllllIl)) {
                if (this.IllIlIIIIlllIIllIIlllIIlI > 0.0) {
                    this.lIlIlIllIIIIIIIIllllIIllI = 4.857142925262451 * -0.02058823500537543;
                }
                else {
                    this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
                }
            }
            else {
                this.lIlIlIllIIIIIIIIllllIIllI -= 0.36000001430511475 * 0.22222221339190484;
            }
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.38243903183355565 * 2.5625;
            this.IllIIlIIlllllIllIIIlllIII *= n5;
            this.IlllIIlllIIIIllIIllllIlIl *= n5;
        }
        this.IIllIllIlIIlllllIlIIIlIll = this.IlIlIIIlllIlIllIlIIIlllIl;
        final double n7 = this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl;
        final double n8 = this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII;
        float n9 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n7 * n7 + n8 * n8) * 4;
        if (n9 > 1.0f) {
            n9 = 1.0f;
        }
        this.IlIlIIIlllIlIllIlIIIlllIl += (n9 - this.IlIlIIIlllIlIllIlIIIlllIl) * (5.2222223f * 0.076595746f);
        this.llIIlllIlIIlIIIIIlIllllll += this.IlIlIIIlllIlIllIlIIIlllIl;
    }
    
    protected boolean IIllIllIlIIlllllIlIIIlIll() {
        return false;
    }
    
    public float IIIIIlIIIlllIIlIIllllIlll() {
        return this.IIllIllIlIIlllllIlIIIlIll() ? this.lIIlIlIllIIlIIIlIIIlllIII : (0.32222223f * 0.31034482f);
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(final float liIlIlIllIIlIIIlIIIlllIII) {
        this.lIIlIlIllIIlIIIlIIIlllIII = liIlIlIllIIlIIIlIIIlllIII;
    }
    
    public boolean lIIlIlIllIIlIIIlIIIlllIII(final Entity entity) {
        this.IlIlllIIIIllIllllIllIIlIl(entity);
        return false;
    }
    
    public boolean isPlayerSleeping() {
        return false;
    }
    
    @Override
    public void x_() {
        super.x_();
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final int lIllIIIIIlIllIllllIlIllII = this.lIllIIIIIlIllIllllIlIllII();
            if (lIllIIIIIlIllIllllIlIllII > 0) {
                if (this.lIlIIllIIIlllIIllIIlIIllI <= 0) {
                    this.lIlIIllIIIlllIIllIIlIIllI = 20 * (30 - lIllIIIIIlIllIllllIlIllII);
                }
                --this.lIlIIllIIIlllIIllIIlIIllI;
                if (this.lIlIIllIIIlllIIllIIlIIllI <= 0) {
                    this.lIIIIIllllIIIIlIlIIIIlIlI(lIllIIIIIlIllIllllIlIllII - 1);
                }
            }
            for (int i = 0; i < 5; ++i) {
                final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.IIIllIllIlIlllllllIlIlIII[i];
                final lIlIlIlIlIllllIlllIIIlIlI illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(i);
                if (!lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, lIlIlIlIlIllllIlllIIIlIlI)) {
                    ((IllllIllIIlllllIIlIIllIlI)this.lIIlllIIlIlllllllllIIIIIl).llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(this, new IIIIlllllIllIIIIlIlIlllII(this.lIIIIlllIIlIlllllIlIllIII(), i, illlIIIlIlllIllIlIIlllIlI));
                    if (lIlIlIlIlIllllIlllIIIlIlI != null) {
                        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.IllIIlIIlllllIllIIIlllIII());
                    }
                    if (illlIIIlIlllIllIlIIlllIlI != null) {
                        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.IllIIlIIlllllIllIIIlllIII());
                    }
                    this.IIIllIllIlIlllllllIlIlIII[i] = ((illlIIIlIlllIllIlIIlllIlI == null) ? null : illlIIIlIlllIllIlIIlllIlI.llIIlllIIIIlllIllIlIlllIl());
                }
            }
            if (this.IIIlIllIlllIlIllIllllllll % 20 == 0) {
                this.lIllIllIIlIlIIIIllIllllll().IIIIllIlIIIllIlllIlllllIl();
            }
        }
        this.i_();
        final double x = this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl;
        final double y = this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII;
        final float n = (float)(x * x + y * y);
        float n2 = this.lIIIlIlIIllIIlllIIIlIIllI;
        float n3 = 0.0f;
        this.IlllllIllIIIllIIIllIllIII = this.lIlllllIlIllllIIIllllllII;
        float n4 = 0.0f;
        if (n > 0.47619048f * 0.0052500004f) {
            n4 = 1.0f;
            n3 = (float)Math.sqrt(n) * 3;
            n2 = (float)Math.atan2(y, x) * 180 / (0.9897959f * 3.1739802f) - 90;
        }
        if (this.lllIIlIIllIllIIllIIlIIIIl > 0.0f) {
            n2 = this.IllllIllllIlIIIlIIIllllll;
        }
        if (!this.lIIIIlllIIlIlllllIlIllIII) {
            n4 = 0.0f;
        }
        this.lIlllllIlIllllIIIllllllII += (n4 - this.lIlllllIlIllllIIIllllllII) * (0.5089286f * 0.58947366f);
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("headTurn");
        final float liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(n2, n3);
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("rangeChecks");
        while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII < -180) {
            this.IlIlIIIlllllIIIlIlIlIllII -= 360;
        }
        while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII >= 180) {
            this.IlIlIIIlllllIIIlIlIlIllII += 360;
        }
        while (this.lIIIlIlIIllIIlllIIIlIIllI - this.lIIIlIIlIIIIIllIIlIlIlIII < -180) {
            this.lIIIlIIlIIIIIllIIlIlIlIII -= 360;
        }
        while (this.lIIIlIlIIllIIlllIIIlIIllI - this.lIIIlIIlIIIIIllIIlIlIlIII >= 180) {
            this.lIIIlIIlIIIIIllIIlIlIlIII += 360;
        }
        while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl < -180) {
            this.IIlIIllIIIllllIIlllIllIIl -= 360;
        }
        while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl >= 180) {
            this.IIlIIllIIIllllIIlllIllIIl += 360;
        }
        while (this.IIIlllIllIlIIllIIllIlIlll - this.IlIlIIIIIllIlIlIIllIlIIIl < -180) {
            this.IlIlIIIIIllIlIlIIllIlIIIl -= 360;
        }
        while (this.IIIlllIllIlIIllIIllIlIlll - this.IlIlIIIIIllIlIlIIllIlIIIl >= 180) {
            this.IlIlIIIIIllIlIlIIllIlIIIl += 360;
        }
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.lIlIIIlIIIlllllllllllIlIl += liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    protected float lIIIIIIIIIlIllIIllIlIIlIl(final float n, float n2) {
        this.lIIIlIlIIllIIlllIIIlIIllI += MathHelper.IIIllIllIlIlllllllIlIlIII(n - this.lIIIlIlIIllIIlllIIIlIIllI) * (1.4285715f * 0.21000001f);
        float iiIllIllIlIlllllllIlIlIII = MathHelper.IIIllIllIlIlllllllIlIlIII(this.IllllIllllIlIIIlIIIllllll - this.lIIIlIlIIllIIlllIIIlIIllI);
        final boolean b = iiIllIllIlIlllllllIlIlIII < -90 || iiIllIllIlIlllllllIlIlIII >= 90;
        if (iiIllIllIlIlllllllIlIlIII < -75) {
            iiIllIllIlIlllllllIlIlIII = -75;
        }
        if (iiIllIllIlIlllllllIlIlIII >= 75) {
            iiIllIllIlIlllllllIlIlIII = 75;
        }
        this.lIIIlIlIIllIIlllIIIlIIllI = this.IllllIllllIlIIIlIIIllllll - iiIllIllIlIlllllllIlIlIII;
        if (iiIllIllIlIlllllllIlIlIII * iiIllIllIlIlllllllIlIlIII > 2500) {
            this.lIIIlIlIIllIIlllIIIlIIllI += iiIllIllIlIlllllllIlIlIII * (0.38888887f * 0.51428574f);
        }
        if (b) {
            n2 *= -1;
        }
        return n2;
    }
    
    public void i_() {
        if (this.IIIlllIIIllIllIlIIIIIIlII > 0) {
            --this.IIIlllIIIllIllIlIIIIIIlII;
        }
        if (this.llIIllllIlIlIllIlIllIlIlI > 0) {
            final double n = this.IIIlIIlIlIIIlllIIlIllllll + (this.IlllIIIIlllllIlIlllllIlll - this.IIIlIIlIlIIIlllIIlIllllll) / this.llIIllllIlIlIllIlIllIlIlI;
            final double n2 = this.IllIlIIIIlllIIllIIlllIIlI + (this.IIIlIllIIllllIIIllllIllll - this.IllIlIIIIlllIIllIIlllIIlI) / this.llIIllllIlIlIllIlIllIlIlI;
            final double n3 = this.IllIlIlIllllIlIIllllIIlll + (this.llllIIIllllllIlllIIlIIlll - this.IllIlIlIllllIlIIllllIIlll) / this.llIIllllIlIlIllIlIllIlIlI;
            this.IllllIllllIlIIIlIIIllllll += (float)(MathHelper.IIIllIllIlIlllllllIlIlIII(this.lIlllIIIlIlIIlIIIIIIlIlII - this.IllllIllllIlIIIlIIIllllll) / this.llIIllllIlIlIllIlIllIlIlI);
            this.IllIIlllIllIlIllIlIIIIIII += (float)((this.IlIllIIIIIlIlllIIIIlllIIl - this.IllIIlllIllIlIllIlIIIIIII) / this.llIIllllIlIlIllIlIllIlIlI);
            --this.llIIllllIlIlIllIlIllIlIlI;
            this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
        }
        else if (!this.IlllIIlllIIIIllIIllllIlIl()) {
            this.IllIIlIIlllllIllIIIlllIII *= 4.764705657958984 * 0.2056790220321383;
            this.lIlIlIllIIIIIIIIllllIIllI *= 1.1003508771929824 * 0.890625;
            this.IlllIIlllIIIIllIIllllIlIl *= 1.6450000315159565 * 0.5957446694374084;
        }
        if (Math.abs(this.IllIIlIIlllllIllIIIlllIII) < 0.0036315788698988954 * 1.3768116235733032) {
            this.IllIIlIIlllllIllIIIlllIII = 0.0;
        }
        if (Math.abs(this.lIlIlIllIIIIIIIIllllIIllI) < 0.6190476417541504 * 0.008076922780663316) {
            this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
        }
        if (Math.abs(this.IlllIIlllIIIIllIIllllIlIl) < 0.03999999910593033 * 0.12500000279396778) {
            this.IlllIIlllIIIIllIIllllIlIl = 0.0;
        }
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("ai");
        if (this.IIIIIlllIllIIIIllIllIIIII()) {
            this.llIIllIllIlIlIlIllllllIII = false;
            this.IlIIlIIllIllIIIIIlllIIlll = 0.0f;
            this.llIIIIlIlIIIllIllIIIIllII = 0.0f;
            this.llllIllIIIlIIIlIllIlIlIlI = 0.0f;
        }
        else if (this.IlllIIlllIIIIllIIllllIlIl()) {
            if (this.IIllIllIlIIlllllIlIIIlIll()) {
                this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("newAi");
                this.IIllllIIIIllIIlIllIIIIIlI();
                this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
            }
            else {
                this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("oldAi");
                this.IllIlIIIIlllIIllIIlllIIlI();
                this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
                this.IIIlllIllIlIIllIIllIlIlll = this.IllllIllllIlIIIlIIIllllll;
            }
        }
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("jump");
        if (this.llIIllIllIlIlIlIllllllIII) {
            if (!this.lIIlIIIIIIIIllIIllIIlllIl() && !this.IlIlllIllIlIllIlllIlllIll()) {
                if (this.lIIIIlllIIlIlllllIlIllIII && this.IIIlllIIIllIllIlIIIIIIlII == 0) {
                    this.k_();
                    this.IIIlllIIIllIllIlIIIIIIlII = 10;
                }
            }
            else {
                this.lIlIlIllIIIIIIIIllllIIllI += 0.03826087029647289 * 1.045454502105713;
            }
        }
        else {
            this.IIIlllIIIllIllIlIIIIIIlII = 0;
        }
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("travel");
        this.IlIIlIIllIllIIIIIlllIIlll *= 1.1620001f * 0.8433735f;
        this.llIIIIlIlIIIllIllIIIIllII *= 0.75f * 1.3066667f;
        this.llllIllIIIlIIIlIllIlIlIlI *= 0.10746268f * 8.375f;
        this.setProgress(this.IlIIlIIllIllIIIIIlllIIlll, this.llIIIIlIlIIIllIllIIIIllII);
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.startSection("push");
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            this.IIIlIIIIllIIIlIIIIIlllllI();
        }
        this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll.endSection();
    }
    
    protected void IIllllIIIIllIIlIllIIIIIlI() {
    }
    
    protected void IIIlIIIIllIIIlIIIIIlllllI() {
        final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(0.7272727223467237 * 0.2750000059604645, 0.0, 0.847058859910933 * 0.2361111044883728));
        if (liiiiiiiiIlIllIIllIlIIlIl != null && !liiiiiiiiIlIllIIllIlIIlIl.isEmpty()) {
            for (int i = 0; i < liiiiiiiiIlIllIIllIlIIlIl.size(); ++i) {
                final Entity entity = liiiiiiiiIlIllIIllIlIIlIl.get(i);
                if (entity.isFramerateLimitBelowMax()) {
                    this.IIIlllIIIllIllIlIIIIIIlII(entity);
                }
            }
        }
    }
    
    protected void IIIlllIIIllIllIlIIIIIIlII(final Entity entity) {
        entity.IlIlIIIlllIIIlIlllIlIllIl(this);
    }
    
    @Override
    public void IllllllllIlIIIIIIIIllIIII() {
        super.IllllllllIlIIIIIIIIllIIII();
        this.IlllllIllIIIllIIIllIllIII = this.lIlllllIlIllllIIIllllllII;
        this.lIlllllIlIllllIIIllllllII = 0.0f;
        this.IllllllIllllIIlllIllllllI = 0.0f;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double illlIIIIlllllIlIlllllIlll, final double iiIlIllIIllllIIIllllIllll, final double llllIIIllllllIlllIIlIIlll, final float n, final float n2, final int llIIllllIlIlIllIlIllIlIlI) {
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        this.IlllIIIIlllllIlIlllllIlll = illlIIIIlllllIlIlllllIlll;
        this.IIIlIllIIllllIIIllllIllll = iiIlIllIIllllIIIllllIllll;
        this.llllIIIllllllIlllIIlIIlll = llllIIIllllllIlllIIlIIlll;
        this.lIlllIIIlIlIIlIIIIIIlIlII = n;
        this.IlIllIIIIIlIlllIIIIlllIIl = n2;
        this.llIIllllIlIlIllIlIllIlIlI = llIIllllIlIlIllIlIllIlIlI;
    }
    
    protected void IlllIIIllIlIlIIIllIIIlIlI() {
    }
    
    protected void IllIlIIIIlllIIllIIlllIIlI() {
        ++this.llllIIllllllIlIIlIlIIIllI;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final boolean llIIllIllIlIlIlIllllllIII) {
        this.llIIllIllIlIlIlIllllllIII = llIIllIllIlIlIlIllllllIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final int n) {
        if (!entity.IIllIlIllIlIllIIlIllIlIII && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final lIlIIlllllIlllllIIIlIIIIl llIlIlIlllIlllllIIIllIIll = ((IllllIllIIlllllIIlIIllIlI)this.lIIlllIIlIlllllllllIIIIIl).llIlIlIlllIlllllIIIllIIll();
            if (entity instanceof lllIIIIIlIllllIIIlllIllIl) {
                llIlIlIlllIlllllIIIllIIll.lIIIIlIIllIIlIIlIIIlIIllI(entity, new IIIllIlIIlIlIllllIlIIllll(entity.lIIIIlllIIlIlllllIlIllIII(), this.lIIIIlllIIlIlllllIlIllIII()));
            }
            if (entity instanceof IlIIlIIlllIlIlIlIIlIIlIIl) {
                llIlIlIlllIlllllIIIllIIll.lIIIIlIIllIIlIIlIIIlIIllI(entity, new IIIllIlIIlIlIllllIlIIllll(entity.lIIIIlllIIlIlllllIlIllIII(), this.lIIIIlllIIlIlllllIlIllIII()));
            }
            if (entity instanceof IIIIlllIIIlllllIIlllIIIIl) {
                llIlIlIlllIlllllIIIllIIll.lIIIIlIIllIIlIIlIIIlIIllI(entity, new IIIllIlIIlIlIllllIlIIllll(entity.lIIIIlllIIlIlllllIlIllIII(), this.lIIIIlllIIlIlllllIlIllIII()));
            }
        }
    }
    
    public boolean llIlIIIlIIIIlIlllIlIIIIll(final Entity entity) {
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.lIIlIlIllIIlIIIlIIIlllIII(), this.IllIlIlIllllIlIIllllIIlll), lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIIIIlllIIllIIlllIIlI + entity.lIIlIlIllIIlIIIlIIIlllIII(), entity.IllIlIlIllllIlIIllllIIlll)) == null;
    }
    
    @Override
    public lIllIIIIlllllIIlIllIIIIII lIIIIIIlIIllllllIIIlIlIIl() {
        return this.llIIlllIIIIlllIllIlIlllIl(1.0f);
    }
    
    public lIllIIIIlllllIIlIllIIIIII llIIlllIIIIlllIllIlIlllIl(final float n) {
        if (n == 1.0f) {
            final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(-this.IllllIllllIlIIIlIIIllllll * (0.021756843f * 0.8021978f) - 4.8619885f * 0.64615387f);
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(-this.IllllIllllIlIIIlIIIllllll * (0.0416627f * 0.4189189f) - 1.1153846f * 2.8166006f);
            final float n2 = -MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(-this.IllIIlllIllIlIllIlIIIIIII * (4.5789475f * 0.0038116383f));
            return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI * n2, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(-this.IllIIlllIllIlIllIlIIIIIII * (0.005470435f * 3.1904762f)), liiiiiiiiIlIllIIllIlIIlIl * n2);
        }
        final float n3 = this.IIlIIllIIIllllIIlllIllIIl + (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl) * n;
        final float n4 = this.IlIlIIIlllllIIIlIlIlIllII + (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII) * n;
        final float liiiiiiiiIlIllIIllIlIIlIl2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(-n4 * (0.4651163f * 0.037524577f) - 4.571429f * 0.6872234f);
        final float liiiIlIIllIIlIIlIIIlIIllI2 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(-n4 * (0.0031028076f * 5.625f) - 11.457573f * 0.27419356f);
        final float n5 = -MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(-n3 * (0.95993114f * 0.018181818f));
        return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2 * n5, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(-n3 * (0.10471975f * 0.16666667f)), liiiiiiiiIlIllIIllIlIIlIl2 * n5);
    }
    
    public float lIIlIlIllIIlIIIlIIIlllIII(final float n) {
        float n2 = this.lllIIlIIllIllIIllIIlIIIIl - this.llllIlIlIlllllIllIIllIIIl;
        if (n2 < 0.0f) {
            ++n2;
        }
        return this.llllIlIlIlllllIllIIllIIIl + n2 * n;
    }
    
    public lIllIIIIlllllIIlIllIIIIII IIIlllIIIllIllIlIIIIIIlII(final float n) {
        if (n == 1.0f) {
            return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        }
        return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIllIllIlIIllIllIlIlIIlIl + (this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl) * n, this.llIlIIIllIIIIlllIlIIIIIlI + (this.IllIlIIIIlllIIllIIlllIIlI - this.llIlIIIllIIIIlllIlIIIIIlI) * n, this.lIllIlIlllIIlIIllIIlIIlII + (this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII) * n);
    }
    
    public MovingObjectPosition lIIIIlIIllIIlIIlIIIlIIllI(final double n, final float n2) {
        final lIllIIIIlllllIIlIllIIIIII iiIlllIIIllIllIlIIIIIIlII = this.IIIlllIIIllIllIlIIIIIIlII(n2);
        final lIllIIIIlllllIIlIllIIIIII llIIlllIIIIlllIllIlIlllIl = this.llIIlllIIIIlllIllIlIlllIl(n2);
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(iiIlllIIIllIllIlIIIIIIlII, iiIlllIIIllIllIlIIIIIIlII.IlllIIIlIlllIllIlIIlllIlI(llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI * n, llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl * n, llIIlllIIIIlllIllIlIlllIl.IlllIIIlIlllIllIlIIlllIlI * n), false, false, true);
    }
    
    public boolean IlllIIlllIIIIllIIllllIlIl() {
        return !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll;
    }
    
    @Override
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return !this.IIllIlIllIlIllIIlIllIlIII;
    }
    
    @Override
    public boolean isFramerateLimitBelowMax() {
        return !this.IIllIlIllIlIllIIlIllIlIII;
    }
    
    @Override
    public float lIIlIlIllIIlIIIlIIIlllIII() {
        return this.llllIIIIlIlIllIIIllllIIll * (0.37777779f * 2.25f);
    }
    
    @Override
    protected void llIIIllIIllllIlIlIlIlIIll() {
        this.IlIIIIllIIIIIlllIIlIIlllI = (this.IlIlllIIIIlIllIlllIlIIIll.nextDouble() >= this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IlllIIIlIlllIllIlIIlllIlI).IIIIllIIllIIIIllIllIIIlIl());
    }
    
    @Override
    public float IIIIlIllIIIIIIlIIIIIlllll() {
        return this.IIIlllIllIlIIllIIllIlIlll;
    }
    
    @Override
    public void IIIllIllIlIlllllllIlIlIII(final float iiIlllIllIlIIllIIllIlIlll) {
        this.IIIlllIllIlIIllIIllIlIlll = iiIlllIllIlIIllIIllIlIlll;
    }
    
    public float IllIIIIIIlllIIIlIIIlIIIlI() {
        return this.llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    public void llIlIIIlIIIIlIlllIlIIIIll(float llIlIIIlIIIIlIlllIlIIIIll) {
        if (llIlIIIlIIIIlIlllIlIIIIll < 0.0f) {
            llIlIIIlIIIIlIlllIlIIIIll = 0.0f;
        }
        this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
    }
    
    public lIlllllllllIlIIIlIIIIlIIl IlIlIIlllIIIIIlIlIlIIIllI() {
        return null;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final EntityLivingBase entityLivingBase) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(entityLivingBase.IlIlIIlllIIIIIlIlIlIIIllI());
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllllllIlIIIlIIIIlIIl lIlllllllllIlIIIlIIIIlIIl) {
        return this.IlIlIIlllIIIIIlIlIlIIIllI() != null && this.IlIlIIlllIIIIIlIlIlIIIllI().lIIIIlIIllIIlIIlIIIlIIllI(lIlllllllllIlIIIlIIIIlIIl);
    }
    
    public void lllIIlIIIllIIlllIlIIIllIl() {
    }
    
    public void IlIIIIlIlIllIIlIIIIllllll() {
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = UUID.fromString("662A6B8D-DA3E-4C1C-8813-96EA6097278D");
        lIIIIIIIIIlIllIIllIlIIlIl = new IllIIlIIllIlllIIIIIllllII(EntityLivingBase.lIIIIlIIllIIlIIlIIIlIIllI, "Sprinting speed boost", 0.02891566379960761 * 10.375, 2).lIIIIlIIllIIlIIlIIIlIIllI(false);
    }
}
