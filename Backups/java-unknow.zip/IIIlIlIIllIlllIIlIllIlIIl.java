// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIIllIlllIIlIllIlIIl extends lIIlllIIIlIllllllIlIlIIII
{
    protected IlIIIllllIlllllIIlIlllllI lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIIlIlIIllIlllIIlIllIlIIl(final IlIIIllllIlllllIIlIlllllI liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = 1;
        this.IIIIllIIllIIIIllIllIIIlIl(liiiIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI());
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.lIIIIllIIlIlIllIIIlIllIlI);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7) {
        if (!lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, lIlIlIlIlIllllIlllIIIlIlI)) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3);
        if (n4 == 0 || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.air || (block != IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI && block != IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl)) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll liIlIlIIlIlIlIIlIlIlllIIl = IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl;
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 0.071428575f * 6.9999995f, n2 + 0.9354838f * 0.5344828f, n3 + 0.5f * 1.0f, liIlIlIIlIlIlIIlIlIlllIIl.IlllIIlllIIIIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl(), (liIlIlIIlIlIlIIlIlIlllIIl.IlllIIlllIIIIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI() + 1.0f) / 2.0f, liIlIlIIlIlIlIIlIlIlllIIl.IlllIIlllIIIIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl() * (0.8585366f * 0.9318182f));
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            return true;
        }
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, liIlIlIIlIlIlIIlIlIlllIIl);
        lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, lIllIIIIlIIlIllIIIlIlIlll);
        return true;
    }
    
    @Override
    public boolean IllIIIIIIIlIlIllllIIllIII() {
        return true;
    }
    
    public String IlIIlIIIIlIIIIllllIIlIllI() {
        return this.lIIIIllIIlIlIllIIIlIllIlI.toString();
    }
}
