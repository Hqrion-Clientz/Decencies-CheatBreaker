// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIIlIlIIIlIIIllIlllIIlII
{
    lIIIIlIIllIIlIIlIIIlIIllI("BLURPLE", 0, "6debd47ed13483642cf09e832ed0bc1b"), 
    lIIIIIIIIIlIllIIllIlIIlIl("GREY", 1, "322c936a8c8be1b803cd94861bdfa868"), 
    IlllIIIlIlllIllIlIIlllIlI("GREEN", 2, "dd4dbc0016779df1378e7812eabaa04d"), 
    IIIIllIlIIIllIlllIlllllIl("ORANGE", 3, "0e291f67c9274a1abdddeb3fd919cbaa"), 
    IIIIllIIllIIIIllIllIIIlIl("RED", 4, "1cbd08c76f8af6dddce02c5138971129");
    
    private final String IlIlIIIlllIIIlIlllIlIllIl;
    
    private IIIIlIlIIIlIIIllIlllIIlII(final String name, final int ordinal, final String ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    @Override
    public String toString() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
}
