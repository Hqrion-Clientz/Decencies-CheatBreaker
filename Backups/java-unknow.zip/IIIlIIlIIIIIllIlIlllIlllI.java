// 
// Decompiled by Procyon v0.5.36
// 

final class IIIlIIlIIIIIllIlIlllIlllI extends llllIllIlIIlIllIllIIIIIII
{
    @Override
    protected llIllllllIIIIIIlIllIlIllI lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final DELETE_ME_A delete_ME_A) {
        return new IlIlIIlIIIIIIlIIlIIlIIIll(iiiiiIllIlIIIIlIlllIllllI, delete_ME_A.lIIIIIIIIIlIllIIllIlIIlIl(), delete_ME_A.IlllIIIlIlllIllIlIIlllIlI(), delete_ME_A.IIIIllIlIIIllIlllIlllllIl());
    }
    
    @Override
    protected float lIIIIlIIllIIlIIlIIIlIIllI() {
        return super.lIIIIlIIllIIlIIlIIIlIIllI() * (2.8f * 0.17857143f);
    }
    
    @Override
    protected float lIIIIIIIIIlIllIIllIlIIlIl() {
        return super.lIIIIIIIIIlIllIIllIlIIlIl() * (1.0742188f * 1.1636363f);
    }
}
