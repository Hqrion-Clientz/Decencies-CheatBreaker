import java.util.Iterator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIlIlIlllIIIIllIIlIII extends IlIlIIllIlIIlIllIIIIllllI implements lIIlllIllllIIlIlIllllIIII, llIIllllllIlIlllIlIIIIIll
{
    private float[] llIIIlllllIlllIIllIlIIlII;
    private float[] lIIIlIlIIIlIlIlllIlIlllII;
    private float[] llIlIlIIIIIIIlllIIIllIlll;
    private float[] IllIIIIIIlIlIlllllllIIllI;
    private int[] IlIIlllIIlIlIIIlIlllllIll;
    private int[] lIllIllIIlIlIIIIllIllllll;
    private int llllllIIIIIlllllIllIlIllI;
    private static final lllIIIlllllllIlIIIlIllIIl IlllIIllllllllIlIlIlllllI;
    
    public IIllIIlIlIlllIIIIllIIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.llIIIlllllIlllIIllIlIIlII = new float[2];
        this.lIIIlIlIIIlIlIlllIlIlllII = new float[2];
        this.llIlIlIIIIIIIlllIIIllIlll = new float[2];
        this.IllIIIIIIlIlIlllllllIIllI = new float[2];
        this.IlIIlllIIlIlIIIlIlllllIll = new int[2];
        this.lIllIllIIlIlIIIIllIllllll = new int[2];
        this.IlllIllIlIIIIlIIlIIllIIIl(this.IlllIIllllllllIlIlIlllllI());
        this.IIIIllIIllIIIIllIllIIIlIl(0.53521127f * 1.6815789f, 4);
        this.IIlIlllIllIlIlIIIIIlllIll = true;
        this.IllIlIlIllllIlIIllllIIlll().IIIIllIIllIIIIllIllIIIlIl(true);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0, new IIllIIIIllIlIIlIllIIIlllI(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(2, new llllllIlIIlIIIllIIlIIllll(this, 1.0, 40, 20));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(5, new IllIIllIIlIlIlIllIlIIIlll(this, 1.0));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(6, new IlIIllIllIllIlllIlIlllIIl(this, lIllIIIIlIIlIllIIIlIlIlll.class, 8));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(7, new IllIIIlIllIIIIlllIlllIIIl(this));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, new lIIIIIIllIllllllllIllIIlI(this, false));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(2, new lllIIIllIIllIlllIIlllIlll(this, IlllIIIllIlIIlIllIIlIlllI.class, 0, false, false, IIllIIlIlIlllIIIIllIIlIII.IlllIIllllllllIlIlIlllllI));
        this.IIIllIllIlIlllllllIlIlIII = 50;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(17, new Integer(0));
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(18, new Integer(0));
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(19, new Integer(0));
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(20, new Integer(0));
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Invul", this.IlIIIIlllIIIlIIllllIIIlll());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.IIIIIIlIlIlIllllllIlllIlI(ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Invul"));
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return this.llllIIIIlIlIllIIIllllIIll / 8;
    }
    
    @Override
    protected String llllIlIlIlllllIllIIllIIIl() {
        return "mob.wither.idle";
    }
    
    @Override
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "mob.wither.hurt";
    }
    
    @Override
    protected String IllIIIIIIlIlIlllllllIIllI() {
        return "mob.wither.death";
    }
    
    @Override
    public void i_() {
        this.lIlIlIllIIIIIIIIllllIIllI *= 1.5625 * 0.3840000152587891;
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.IllIllIIIlIIlllIIIllIllII(0) > 0) {
            final Entity liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIllIIIlIIlllIIIllIllII(0));
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                if (this.IllIlIIIIlllIIllIIlllIIlI < liiiIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI || (!this.IllIIIIIllllIlllIIlIIllIl() && this.IllIlIIIIlllIIllIIlllIIlI < liiiIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI + 5)) {
                    if (this.lIlIlIllIIIIIIIIllllIIllI < 0.0) {
                        this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
                    }
                    this.lIlIlIllIIIIIIIIllllIIllI += (3.4999998435378146 * 0.1428571492433548 - this.lIlIlIllIIIIIIIIllllIIllI) * (0.6551724317477327 * 0.9157894849777222);
                }
                final double n = liiiIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll;
                final double n2 = liiiIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll;
                final double n3 = n * n + n2 * n2;
                if (n3 > 9) {
                    final double n4 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n3);
                    this.IllIIlIIlllllIllIIIlllIII += (n / n4 * (0.24358974397182465 * 2.052631575727727) - this.IllIIlIIlllllIllIIIlllIII) * (7.666666507720947 * 0.07826087429753333);
                    this.IlllIIlllIIIIllIIllllIlIl += (n2 / n4 * (4.999999925494195 * 0.10000000149011612) - this.IlllIIlllIIIIllIIllllIlIl) * (0.957446813583374 * 0.6266666882479631);
                }
            }
        }
        if (this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl > 1.045454502105713 * 0.04782608965225177) {
            this.IllllIllllIlIIIlIIIllllll = (float)Math.atan2(this.IlllIIlllIIIIllIIllllIlIl, this.IllIIlIIlllllIllIIIlllIII) * (1.3538462f * 42.320744f) - 90;
        }
        super.i_();
        for (int i = 0; i < 2; ++i) {
            this.IllIIIIIIlIlIlllllllIIllI[i] = this.lIIIlIlIIIlIlIlllIlIlllII[i];
            this.llIlIlIIIIIIIlllIIIllIlll[i] = this.llIIIlllllIlllIIllIlIIlII[i];
        }
        for (int j = 0; j < 2; ++j) {
            final int illIllIIIlIIlllIIIllIllII = this.IllIllIIIlIIlllIIIllIllII(j + 1);
            Entity liiiIlIIllIIlIIlIIIlIIllI2 = null;
            if (illIllIIIlIIlllIIIllIllII > 0) {
                liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIllIIIlIIlllIIIllIllII);
            }
            if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                final double ilIIlIIIIlIIIIllllIIlIllI = this.IlIIlIIIIlIIIIllllIIlIllI(j + 1);
                final double liIlIIllIIIIIlIllIIIIllII = this.lIIlIIllIIIIIlIllIIIIllII(j + 1);
                final double liIlllIIlIlllllllllIIIIIl = this.lIIlllIIlIlllllllllIIIIIl(j + 1);
                final double x = liiiIlIIllIIlIIlIIIlIIllI2.IIIlIIlIlIIIlllIIlIllllll - ilIIlIIIIlIIIIllllIIlIllI;
                final double y = liiiIlIIllIIlIIlIIIlIIllI2.IllIlIIIIlllIIllIIlllIIlI + liiiIlIIllIIlIIlIIIlIIllI2.lIIlIlIllIIlIIIlIIIlllIII() - liIlIIllIIIIIlIllIIIIllII;
                final double y2 = liiiIlIIllIIlIIlIIIlIIllI2.IllIlIlIllllIlIIllllIIlll - liIlllIIlIlllllllllIIIIIl;
                final double x2 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(x * x + y2 * y2);
                final float n5 = (float)(Math.atan2(y2, x) * 180 / (0.18571428954601288 * 16.916267785691456)) - 90;
                this.llIIIlllllIlllIIllIlIIlII[j] = this.lIIIIIIIIIlIllIIllIlIIlIl(this.llIIIlllllIlllIIllIlIIlII[j], (float)(-(Math.atan2(y, x2) * 180 / (0.875 * 3.5903916041026207))), 40);
                this.lIIIlIlIIIlIlIlllIlIlllII[j] = this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIlIlIIIlIlIlllIlIlllII[j], n5, 10);
            }
            else {
                this.lIIIlIlIIIlIlIlllIlIlllII[j] = this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIlIlIIIlIlIlllIlIlllII[j], this.lIIIlIlIIllIIlllIIIlIIllI, 10);
            }
        }
        final boolean illIIIIIllllIlllIIlIIllIl = this.IllIIIIIllllIlllIIlIIllIl();
        for (int k = 0; k < 3; ++k) {
            final double ilIIlIIIIlIIIIllllIIlIllI2 = this.IlIIlIIIIlIIIIllllIIlIllI(k);
            final double liIlIIllIIIIIlIllIIIIllII2 = this.lIIlIIllIIIIIlIllIIIIllII(k);
            final double liIlllIIlIlllllllllIIIIIl2 = this.lIIlllIIlIlllllllllIIIIIl(k);
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("smoke", ilIIlIIIIlIIIIllllIIlIllI2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.6656250388477937 * 0.4507042169570923), liIlIIllIIIIIlIllIIIIllII2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.562499993015081 * 0.5333333611488342), liIlllIIlIlllllllllIIIIIl2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (6.545454502105713 * 0.04583333545812855), 0.0, 0.0, 0.0);
            if (illIIIIIllllIlllIIlIIllIl && this.lIIlllIIlIlllllllllIIIIIl.lllIIIIIlIllIlIIIllllllII.nextInt(4) == 0) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("mobSpell", ilIIlIIIIlIIIIllllIIlIllI2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (1.1714285612106323 * 0.25609757338585715), liIlIIllIIIIIlIllIIIIllII2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.3414634168148041 * 0.878571457871977), liIlllIIlIlllllllllIIIIIl2 + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.7311828136444092 * 0.41029412388079706), 0.5306122303009033 * 1.3192307830562258, 2.538461446762085 * 0.2757575810229266, 1.7499999217689073 * 0.2857142984867096);
            }
        }
        if (this.IlIIIIlllIIIlIIllllIIIlll() > 0) {
            for (int l = 0; l < 3; ++l) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("mobSpell", this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * 1.0, this.IllIlIIIIlllIIllIIlllIIlI + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (1.8464285f * 1.7872341f), this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * 1.0, 0.06382978707551956 * 10.966666507141458, 2.6249998183921073 * 0.2666666805744171, 1.0144927501678467 * 0.8871428366631877);
            }
        }
    }
    
    @Override
    protected void IIllllIIIIllIIlIllIIIIIlI() {
        if (this.IlIIIIlllIIIlIIllllIIIlll() > 0) {
            final int n = this.IlIIIIlllIIIlIIllllIIIlll() - 1;
            if (n <= 0) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + this.lIIlIlIllIIlIIIlIIIlllIII(), this.IllIlIlIllllIlIIllllIIlll, 7, false, this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing"));
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(1013, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
            }
            this.IIIIIIlIlIlIllllllIlllIlI(n);
            if (this.IIIlIllIlllIlIllIllllllll % 10 == 0) {
                this.IlllIIIlIlllIllIlIIlllIlI((float)10);
            }
        }
        else {
            super.IIllllIIIIllIIlIllIIIIIlI();
            for (int i = 1; i < 3; ++i) {
                if (this.IIIlIllIlllIlIllIllllllll >= this.IlIIlllIIlIlIIIlIlllllIll[i - 1]) {
                    this.IlIIlllIIlIlIIIlIlllllIll[i - 1] = this.IIIlIllIlllIlIllIllllllll + 10 + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(10);
                    if (this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IlllIIIlIlllIllIlIIlllIlI || this.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                        final int n2 = i - 1;
                        final int n3 = this.lIllIllIIlIlIIIIllIllllll[i - 1];
                        this.lIllIllIIlIlIIIIllIllllll[n2] = this.lIllIllIIlIlIIIIllIllllll[i - 1] + 1;
                        if (n3 > 15) {
                            final float n4 = 10;
                            final float n5 = 5;
                            this.lIIIIlIIllIIlIIlIIIlIIllI(i + 1, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, this.IIIlIIlIlIIIlllIIlIllllll - n4, this.IIIlIIlIlIIIlllIIlIllllll + n4), MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, this.IllIlIIIIlllIIllIIlllIIlI - n5, this.IllIlIIIIlllIIllIIlllIIlI + n5), MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIlIllIlllIlIIIll, this.IllIlIlIllllIlIIllllIIlll - n4, this.IllIlIlIllllIlIIllllIIlll + n4), true);
                            this.lIllIllIIlIlIIIIllIllllll[i - 1] = 0;
                        }
                    }
                    final int illIllIIIlIIlllIIIllIllII = this.IllIllIIIlIIlllIIIllIllII(i);
                    if (illIllIIIlIIlllIIIllIllII > 0) {
                        final Entity liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIllIIIlIIlllIIIllIllII);
                        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.IlIlllIIIIlIllIlllIlIIIll() && this.IIIIllIIllIIIIllIllIIIlIl(liiiIlIIllIIlIIlIIIlIIllI) <= 900 && this.llIlIIIlIIIIlIlllIlIIIIll(liiiIlIIllIIlIIlIIIlIIllI)) {
                            this.lIIIIlIIllIIlIIlIIIlIIllI(i + 1, (EntityLivingBase)liiiIlIIllIIlIIlIIIlIIllI);
                            this.IlIIlllIIlIlIIIlIlllllIll[i - 1] = this.IIIlIllIlllIlIllIllllllll + 40 + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(20);
                            this.lIllIllIIlIlIIIIllIllllll[i - 1] = 0;
                        }
                        else {
                            this.lIIIIIIIIIlIllIIllIlIIlIl(i, 0);
                        }
                    }
                    else {
                        final List liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(EntityLivingBase.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(20, 8, 20), IIllIIlIlIlllIIIIllIIlIII.IlllIIllllllllIlIlIlllllI);
                        int n6 = 0;
                        while (n6 < 10 && !liiiIlIIllIIlIIlIIIlIIllI2.isEmpty()) {
                            final EntityLivingBase entityLivingBase = liiiIlIIllIIlIIlIIIlIIllI2.get(this.IlIlllIIIIlIllIlllIlIIIll.nextInt(liiiIlIIllIIlIIlIIIlIIllI2.size()));
                            if (entityLivingBase != this && entityLivingBase.IlIlllIIIIlIllIlllIlIIIll() && this.llIlIIIlIIIIlIlllIlIIIIll(entityLivingBase)) {
                                if (!(entityLivingBase instanceof lIllIIIIlIIlIllIIIlIlIlll)) {
                                    this.lIIIIIIIIIlIllIIllIlIIlIl(i, entityLivingBase.lIIIIlllIIlIlllllIlIllIII());
                                    break;
                                }
                                if (!((lIllIIIIlIIlIllIIIlIlIlll)entityLivingBase).IlllIIIllIlIlIIIllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
                                    this.lIIIIIIIIIlIllIIllIlIIlIl(i, entityLivingBase.lIIIIlllIIlIlllllIlIllIII());
                                    break;
                                }
                                break;
                            }
                            else {
                                liiiIlIIllIIlIIlIIIlIIllI2.remove(entityLivingBase);
                                ++n6;
                            }
                        }
                    }
                }
            }
            if (this.IllllIllllIlIIIlIIIllllll() != null) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(0, this.IllllIllllIlIIIlIIIllllll().lIIIIlllIIlIlllllIlIllIII());
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl(0, 0);
            }
            if (this.llllllIIIIIlllllIllIlIllI > 0) {
                --this.llllllIIIIIlllllIllIlIllI;
                if (this.llllllIIIIIlllllIllIlIllI == 0 && this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing")) {
                    final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI);
                    final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
                    final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
                    boolean b = false;
                    for (int j = -1; j <= 1; ++j) {
                        for (int k = -1; k <= 1; ++k) {
                            for (int l = 0; l <= 3; ++l) {
                                final int n7 = illlIIIlIlllIllIlIIlllIlI2 + j;
                                final int n8 = illlIIIlIlllIllIlIIlllIlI + l;
                                final int n9 = illlIIIlIlllIllIlIIlllIlI3 + k;
                                final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(n7, n8, n9);
                                if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air && block != IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII && block != IllllllIllIIlllIllIIlIIll.IlllIIIIlllllIlIlllllIlll && block != IllllllIllIIlllIllIIlIIll.IIIlIllIIllllIIIllllIllll && block != IllllllIllIIlllIllIIlIIll.llIIllIIIllllIIIllIIIIIIl) {
                                    b = (this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n7, n8, n9, true) || b);
                                }
                            }
                        }
                    }
                    if (b) {
                        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(null, 1012, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
                    }
                }
            }
            if (this.IIIlIllIlllIlIllIllllllll % 20 == 0) {
                this.IlllIIIlIlllIllIlIIlllIlI(1.0f);
            }
        }
    }
    
    public void IIIlIllIIIlllIIlIIllIlIII() {
        this.IIIIIIlIlIlIllllllIlllIlI(220);
        this.IlllIllIlIIIIlIIlIIllIIIl(this.IlllIIllllllllIlIlIlllllI() / 3);
    }
    
    @Override
    public void lllIllIllIlIllIlIIllllIIl() {
    }
    
    @Override
    public int IlIIlllIIlIlIIIlIlllllIll() {
        return 4;
    }
    
    private double IlIIlIIIIlIIIIllllIIlIllI(final int n) {
        if (n <= 0) {
            return this.IIIlIIlIlIIIlllIIlIllllll;
        }
        return this.IIIlIIlIlIIIlllIIlIllllll + MathHelper.lIIIIIIIIIlIllIIllIlIIlIl((this.lIIIlIlIIllIIlllIIIlIIllI + 180 * (n - 1)) / 180 * (0.6f * 5.2359877f)) * (2.352381045856177 * 0.5526315569877625);
    }
    
    private double lIIlIIllIIIIIlIllIIIIllII(final int n) {
        return (n <= 0) ? (this.IllIlIIIIlllIIllIIlllIIlI + 3) : (this.IllIlIIIIlllIIllIIlllIIlI + 2.427586206896552 * 0.90625);
    }
    
    private double lIIlllIIlIlllllllllIIIIIl(final int n) {
        if (n <= 0) {
            return this.IllIlIlIllllIlIIllllIIlll;
        }
        return this.IllIlIlIllllIlIIllllIIlll + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((this.lIIIlIlIIllIIlllIIIlIIllI + 180 * (n - 1)) / 180 * (1.9290482f * 1.6285714f)) * (1.8735293395069672 * 0.6938775777816772);
    }
    
    private float lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final float n3) {
        float iiIllIllIlIlllllllIlIlIII = MathHelper.IIIllIllIlIlllllllIlIlIII(n2 - n);
        if (iiIllIllIlIlllllllIlIlIII > n3) {
            iiIllIllIlIlllllllIlIlIII = n3;
        }
        if (iiIllIllIlIlllllllIlIlIII < -n3) {
            iiIllIllIlIlllllllIlIlIII = -n3;
        }
        return n + iiIllIllIlIlllllllIlIlIII;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final EntityLivingBase entityLivingBase) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, entityLivingBase.IIIlIIlIlIIIlllIIlIllllll, entityLivingBase.IllIlIIIIlllIIllIIlllIIlI + entityLivingBase.lIIlIlIllIIlIIIlIIIlllIII() * (0.42857144316848494 * 1.1666666269302368), entityLivingBase.IllIlIlIllllIlIIllllIIlll, n == 0 && this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() < 6.777778E-4f * 1.4754099f);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final double n2, final double n3, final double n4, final boolean b) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(null, 1014, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
        final double ilIIlIIIIlIIIIllllIIlIllI = this.IlIIlIIIIlIIIIllllIIlIllI(n);
        final double liIlIIllIIIIIlIllIIIIllII = this.lIIlIIllIIIIIlIllIIIIllII(n);
        final double liIlllIIlIlllllllllIIIIIl = this.lIIlllIIlIlllllllllIIIIIl(n);
        final llllIIIlIIIIIlIlIlllIIlll llllIIIlIIIIIlIlIlllIIlll = new llllIIIlIIIIIlIlIlllIIlll(this.lIIlllIIlIlllllllllIIIIIl, this, n2 - ilIIlIIIIlIIIIllllIIlIllI, n3 - liIlIIllIIIIIlIllIIIIllII, n4 - liIlllIIlIlllllllllIIIIIl);
        if (b) {
            llllIIIlIIIIIlIlIlllIIlll.sendClickBlockToController(true);
        }
        llllIIIlIIIIIlIlIlllIIlll.IllIlIIIIlllIIllIIlllIIlI = liIlIIllIIIIIlIllIIIIllII;
        llllIIIlIIIIIlIlIlllIIlll.IIIlIIlIlIIIlllIIlIllllll = ilIIlIIIIlIIIIllllIIlIllI;
        llllIIIlIIIIIlIlIlllIIlll.IllIlIlIllllIlIIllllIIlll = liIlllIIlIlllllllllIIIIIl;
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(llllIIIlIIIIIlIlIlllIIlll);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(0, entityLivingBase);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        if (lllIIIIIIIllIlllllIIlllll == lllIIIIIIIllIlllllIIlllll.IIIIllIIllIIIIllIllIIIlIl) {
            return false;
        }
        if (this.IlIIIIlllIIIlIIllllIIIlll() > 0) {
            return false;
        }
        if (this.IllIIIIIllllIlllIIlIIllIl() && lllIIIIIIIllIlllllIIlllll.lIIIIllIIlIlIllIIIlIllIlI() instanceof IlIIlIIlllIlIlIlIIlIIlIIl) {
            return false;
        }
        final Entity illlIllIlIIIIlIIlIIllIIIl = lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl();
        if (illlIllIlIIIIlIIlIIllIIIl != null && !(illlIllIlIIIIlIIlIIllIIIl instanceof lIllIIIIlIIlIllIIIlIlIlll) && illlIllIlIIIIlIIlIIllIIIl instanceof EntityLivingBase && ((EntityLivingBase)illlIllIlIIIIlIIlIIllIIIl).IlIIIIlIlllIllIlIlIIlIlIl() == this.IlIIIIlIlllIllIlIlIIlIlIl()) {
            return false;
        }
        if (this.llllllIIIIIlllllIllIlIllI <= 0) {
            this.llllllIIIIIlllllIllIlIllI = 20;
        }
        for (int i = 0; i < this.lIllIllIIlIlIIIIllIllllll.length; ++i) {
            final int[] lIllIllIIlIlIIIIllIllllll = this.lIllIllIIlIlIIIIllIllllll;
            final int n2 = i;
            lIllIllIIlIlIIIIllIllllll[n2] += 3;
        }
        return super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, n);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.IlllIIIllIlIlIIIllIIIlIlI, 1);
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final Iterator<lIllIIIIlIIlIllIIIlIlIlll> iterator = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(50, 100, 50)).iterator();
            while (iterator.hasNext()) {
                iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(AchievementList.IIlIIllIIIllllIIlllIllIIl);
            }
        }
    }
    
    @Override
    public void llIIlllIlIIlIIIIIlIllllll() {
        this.llllIIllllllIlIIlIlIIIllI = 0;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        return 15728880;
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl) {
    }
    
    @Override
    protected boolean IIllIllIlIIlllllIlIIIlIll() {
        return true;
    }
    
    @Override
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(300);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).lIIIIlIIllIIlIIlIIIlIIllI(0.25 * 2.4000000953674316);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIIIIIIlIllIIllIlIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(40);
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return this.lIIIlIlIIIlIlIlllIlIlllII[n];
    }
    
    public float lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return this.llIIIlllllIlllIIllIlIIlII[n];
    }
    
    public int IlIIIIlllIIIlIIllllIIIlll() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.IlllIIIlIlllIllIlIIlllIlI(20);
    }
    
    public void IIIIIIlIlIlIllllllIlllIlI(final int i) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(20, i);
    }
    
    public int IllIllIIIlIIlllIIIllIllII(final int n) {
        return this.IlIIllIIIlllIIIIlIIIIlIll.IlllIIIlIlllIllIlIIlllIlI(17 + n);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int i) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(17 + n, i);
    }
    
    public boolean IllIIIIIllllIlllIIlIIllIl() {
        return this.getHealth() <= this.IlllIIllllllllIlIlIlllllI() / 2.0f;
    }
    
    @Override
    public lIIIllIIlllIlIIIIIIllIllI IlIIIIlIlllIllIlIlIIlIlIl() {
        return lIIIllIIlllIlIIIIIIllIllI.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        this.IlIIlIIIIlIIIIllllIIlIllI = null;
    }
    
    static {
        IlllIIllllllllIlIlIlllllI = new llllIIlIIIIIIIIIIlllIllll();
    }
}
