import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIIIlIIIllllIllllI extends GuiScreen
{
    private static llllIlllIIIIIllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIIIIIIIIlIIIllllIllllI(final llllIlllIIIIIllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        super.IllIllIIIlIIlllIIIllIllII = Collections.synchronizedList(new ArrayList<Object>());
    }
    
    public llllIlllIIIIIllllIlIlIIII IlIlIIIlllIIIlIlllIlIllIl() {
        return IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void s_() {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
        super.s_();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, s, n, n2, n3);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n, final int n2, final int n3) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl, s, n, n2, n3);
    }
    
    public static void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, n6);
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n, n2, n3, n4, n5, n6);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)n, (float)n2, (float)n3, (float)n4, n5, n6);
    }
    
    @Override
    public void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public boolean isUnicode() {
        return super.isUnicode();
    }
    
    @Override
    public void updateDebugProfilerName(final int n) {
        super.updateDebugProfilerName(n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, n, n2);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n, final int n2) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(s, n, n2);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final List list, final int n, final int n2) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(list, n, n2);
    }
    
    @Override
    public void updateScreen() {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl();
        super.updateScreen();
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return this.lIIlllIIlIlllllllllIIIIIl.getStringWidth(s);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final String s, final int n, final int n2, final int n3) {
        this.lIIlllIIlIlllllllllIIIIIl.drawStringWithShadow(s, (float)n, (float)n2, n3);
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n) {
        return this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(s, n);
    }
    
    public final void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(((IIIlIllIllllIllIlIllllllI)liIlIIIIlIIIIIllIIIIlIIll).lIIIIllIIlIlIllIIIlIllIlI());
    }
    
    public void run() {
        super.IllIllIIIlIIlllIIIllIllII.clear();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIllIlIlllIlIlIIIllIllIll illIlIlllIlIlIIIllIllIll) {
        super.IllIllIIIlIIlllIIIllIllII.add(illIlIlllIlIlIIIllIllIll.lIIIIlIIllIIlIIlIIIlIIllI());
    }
    
    public List lIIIIllIIlIlIllIIIlIllIlI() {
        final ArrayList<IIllIlIlllIlIlIIIllIllIll> list = new ArrayList<IIllIlIlllIlIlIIIllIllIll>(super.IllIllIIIlIIlllIIIllIllII.size());
        final Iterator<lIIlIIIIlIIIIIllIIIIlIIll> iterator = super.IllIllIIIlIIlllIIIllIllII.iterator();
        while (iterator.hasNext()) {
            list.add(((IIIlIllIllllIllIlIllllllI)iterator.next()).lIIIIllIIlIlIllIIIlIllIlI());
        }
        return list;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIllIlIlllIlIlIIIllIllIll illIlIlllIlIlIIIllIllIll) {
        super.IllIllIIIlIIlllIIIllIllII.remove(illIlIlllIlIlIIIllIllIll);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    @Override
    public void handleMouseInput() {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIllIllllIllIIlIl();
        super.handleMouseInput();
    }
    
    @Override
    public void lIIlIIllIIIIIlIllIIIIllII() {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
        super.lIIlIIllIIIIIlIllIIIIllII();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final long n4) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(b, n);
    }
    
    @Override
    public void t_() {
        IIIIIIIIIIIlIIIllllIllllI.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII();
        super.t_();
    }
}
