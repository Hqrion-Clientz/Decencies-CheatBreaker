import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class AchievementList
{
    public static int lIIIIlIIllIIlIIlIIIlIIllI;
    public static int lIIIIIIIIIlIllIIllIlIIlIl;
    public static int IlllIIIlIlllIllIlIIlllIlI;
    public static int IIIIllIlIIIllIlllIlllllIl;
    public static List IIIIllIIllIIIIllIllIIIlIl;
    public static IIlllIllIlIIIIIlIlllllIIl IlIlIIIlllIIIlIlllIlIllIl;
    public static IIlllIllIlIIIIIlIlllllIIl IIIllIllIlIlllllllIlIlIII;
    public static IIlllIllIlIIIIIlIlllllIIl IllIIIIIIIlIlIllllIIllIII;
    public static IIlllIllIlIIIIIlIlllllIIl lIIIIllIIlIlIllIIIlIllIlI;
    public static IIlllIllIlIIIIIlIlllllIIl IlllIllIlIIIIlIIlIIllIIIl;
    public static IIlllIllIlIIIIIlIlllllIIl IlIlllIIIIllIllllIllIIlIl;
    public static IIlllIllIlIIIIIlIlllllIIl llIIlllIIIIlllIllIlIlllIl;
    public static IIlllIllIlIIIIIlIlllllIIl lIIlIlIllIIlIIIlIIIlllIII;
    public static IIlllIllIlIIIIIlIlllllIIl IIIlllIIIllIllIlIIIIIIlII;
    public static IIlllIllIlIIIIIlIlllllIIl llIlIIIlIIIIlIlllIlIIIIll;
    public static IIlllIllIlIIIIIlIlllllIIl IIIlIIllllIIllllllIlIIIll;
    public static IIlllIllIlIIIIIlIlllllIIl lllIIIIIlIllIlIIIllllllII;
    public static IIlllIllIlIIIIIlIlllllIIl lIIIIIllllIIIIlIlIIIIlIlI;
    public static IIlllIllIlIIIIIlIlllllIIl IIIIIIlIlIlIllllllIlllIlI;
    public static IIlllIllIlIIIIIlIlllllIIl IllIllIIIlIIlllIIIllIllII;
    public static IIlllIllIlIIIIIlIlllllIIl IlIIlIIIIlIIIIllllIIlIllI;
    public static IIlllIllIlIIIIIlIlllllIIl lIIlIIllIIIIIlIllIIIIllII;
    public static IIlllIllIlIIIIIlIlllllIIl lIIlllIIlIlllllllllIIIIIl;
    public static IIlllIllIlIIIIIlIlllllIIl lIllIllIlIIllIllIlIlIIlIl;
    public static IIlllIllIlIIIIIlIlllllIIl llIlIIIllIIIIlllIlIIIIIlI;
    public static IIlllIllIlIIIIIlIlllllIIl lIllIlIlllIIlIIllIIlIIlII;
    public static IIlllIllIlIIIIIlIlllllIIl IIIlIIlIlIIIlllIIlIllllll;
    public static IIlllIllIlIIIIIlIlllllIIl IllIlIIIIlllIIllIIlllIIlI;
    public static IIlllIllIlIIIIIlIlllllIIl IllIlIlIllllIlIIllllIIlll;
    public static IIlllIllIlIIIIIlIlllllIIl IllIIlIIlllllIllIIIlllIII;
    public static IIlllIllIlIIIIIlIlllllIIl lIlIlIllIIIIIIIIllllIIllI;
    public static IIlllIllIlIIIIIlIlllllIIl IlllIIlllIIIIllIIllllIlIl;
    public static IIlllIllIlIIIIIlIlllllIIl IllllIllllIlIIIlIIIllllll;
    public static IIlllIllIlIIIIIlIlllllIIl IllIIlllIllIlIllIlIIIIIII;
    public static IIlllIllIlIIIIIlIlllllIIl IlIlIIIlllllIIIlIlIlIllII;
    public static IIlllIllIlIIIIIlIlllllIIl IIlIIllIIIllllIIlllIllIIl;
    public static IIlllIllIlIIIIIlIlllllIIl lllIlIIllllIIIIlIllIlIIII;
    public static IIlllIllIlIIIIIlIlllllIIl lIIIIlllIIlIlllllIlIllIII;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
    }
    
    static {
        AchievementList.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        AchievementList.IlIlIIIlllIIIlIlllIlIllIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.openInventory", "openInventory", 0, 0, IIlIlIllIlIIllIllIllIIIll.lIlIlIlIIlIlllIIIIIIllllI, null).lIIIIlIIllIIlIIlIIIlIIllI().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIIllIllIlIlllllllIlIlIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.mineWood", "mineWood", 2, 1, IllllllIllIIlllIllIIlIIll.lIIIIIllllIIIIlIlIIIIlIlI, AchievementList.IlIlIIIlllIIIlIlllIlIllIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIIIIIIIlIlIllllIIllIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildWorkBench", "buildWorkBench", 4, -1, IllllllIllIIlllIllIIlIIll.IIIlIllIlllIlIllIllllllll, AchievementList.IIIllIllIlIlllllllIlIlIII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIIIllIIlIlIllIIIlIllIlI = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildPickaxe", "buildPickaxe", 4, 2, IIlIlIllIlIIllIllIllIIIll.llIlIIIlIIIIlIlllIlIIIIll, AchievementList.IllIIIIIIIlIlIllllIIllIII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IlllIllIlIIIIlIIlIIllIIIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildFurnace", "buildFurnace", 3, 4, IllllllIllIIlllIllIIlIIll.IllIIIlIIlIllIllIIllllIIl, AchievementList.lIIIIllIIlIlIllIIIlIllIlI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IlIlllIIIIllIllllIllIIlIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.acquireIron", "acquireIron", 1, 4, IIlIlIllIlIIllIllIllIIIll.IlllIllIlIIIIlIIlIIllIIIl, AchievementList.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.llIIlllIIIIlllIllIlIlllIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildHoe", "buildHoe", 2, -3, IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllllIIIlIlIlIllII, AchievementList.IllIIIIIIIlIlIllllIIllIII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIlIlIllIIlIIIlIIIlllIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.makeBread", "makeBread", -1, -3, IIlIlIllIlIIllIllIllIIIll.IlIIIIllIIIIIlllIIlIIlllI, AchievementList.llIIlllIIIIlllIllIlIlllIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIIlllIIIllIllIlIIIIIIlII = new IIlllIllIlIIIIIlIlllllIIl("achievement.bakeCake", "bakeCake", 0, -5, IIlIlIllIlIIllIllIllIIIll.IllIIIllIlIIlIllIIIllllIl, AchievementList.llIIlllIIIIlllIllIlIlllIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.llIlIIIlIIIIlIlllIlIIIIll = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildBetterPickaxe", "buildBetterPickaxe", 6, 2, IIlIlIllIlIIllIllIllIIIll.IIIIIIlIlIlIllllllIlllIlI, AchievementList.lIIIIllIIlIlIllIIIlIllIlI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIIlIIllllIIllllllIlIIIll = new IIlllIllIlIIIIIlIlllllIIl("achievement.cookFish", "cookFish", 2, 6, IIlIlIllIlIIllIllIllIIIll.IIllllIIIIllIIlIllIIIIIlI, AchievementList.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lllIIIIIlIllIlIIIllllllII = new IIlllIllIlIIIIIlIlllllIIl("achievement.onARail", "onARail", 2, 3, IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, AchievementList.IlIlllIIIIllIllllIllIIlIl).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIIIIllllIIIIlIlIIIIlIlI = new IIlllIllIlIIIIIlIlllllIIl("achievement.buildSword", "buildSword", 6, -1, IIlIlIllIlIIllIllIllIIIll.lIIlIlIllIIlIIIlIIIlllIII, AchievementList.IllIIIIIIIlIlIllllIIllIII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIIIIIlIlIlIllllllIlllIlI = new IIlllIllIlIIIIIlIlllllIIl("achievement.killEnemy", "killEnemy", 8, -1, IIlIlIllIlIIllIllIllIIIll.IlIllIIllIIIIIllIlIIIIIIl, AchievementList.lIIIIIllllIIIIlIlIIIIlIlI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIllIIIlIIlllIIIllIllII = new IIlllIllIlIIIIIlIlllllIIl("achievement.killCow", "killCow", 7, -3, IIlIlIllIlIIllIllIllIIIll.IIIIIIIllIllllIIlIIlllIII, AchievementList.lIIIIIllllIIIIlIlIIIIlIlI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IlIIlIIIIlIIIIllllIIlIllI = new IIlllIllIlIIIIIlIlllllIIl("achievement.flyPig", "flyPig", 9, -3, IIlIlIllIlIIllIllIllIIIll.IllIIIIllllllIlllllIlIlll, AchievementList.IllIllIIIlIIlllIIIllIllII).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIlIIllIIIIIlIllIIIIllII = new IIlllIllIlIIIIIlIlllllIIl("achievement.snipeSkeleton", "snipeSkeleton", 7, 0, IIlIlIllIlIIllIllIllIIIll.IlIlIIIlllIIIlIlllIlIllIl, AchievementList.IIIIIIlIlIlIllllllIlllIlI).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIlllIIlIlllllllllIIIIIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.diamonds", "diamonds", -1, 5, IllllllIllIIlllIllIIlIIll.IlIIllIlIlIIIllIllIIlIIII, AchievementList.IlIlllIIIIllIllllIllIIlIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIllIllIlIIllIllIlIlIIlIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.diamondsToYou", "diamondsToYou", -1, 2, IIlIlIllIlIIllIllIllIIIll.lIIIIllIIlIlIllIIIlIllIlI, AchievementList.lIIlllIIlIlllllllllIIIIIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.llIlIIIllIIIIlllIlIIIIIlI = new IIlllIllIlIIIIIlIlllllIIl("achievement.portal", "portal", -1, 7, IllllllIllIIlllIllIIlIIll.IllllllIllllIIlllIllllllI, AchievementList.lIIlllIIlIlllllllllIIIIIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIllIlIlllIIlIIllIIlIIlII = new IIlllIllIlIIIIIlIlllllIIl("achievement.ghast", "ghast", -4, 8, IIlIlIllIlIIllIllIllIIIll.IIlllllIIlIIlIlIIlIIlIlII, AchievementList.llIlIIIllIIIIlllIlIIIIIlI).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIIlIIlIlIIIlllIIlIllllll = new IIlllIllIlIIIIIlIlllllIIl("achievement.blazeRod", "blazeRod", 0, 9, IIlIlIllIlIIllIllIllIIIll.IlIIlIllIllllIIlIllllIlII, AchievementList.llIlIIIllIIIIlllIlIIIIIlI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIlIIIIlllIIllIIlllIIlI = new IIlllIllIlIIIIIlIlllllIIl("achievement.potion", "potion", 2, 8, IIlIlIllIlIIllIllIllIIIll.llIIIIlIlIIIllIllIIIIllII, AchievementList.IIIlIIlIlIIIlllIIlIllllll).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIlIlIllllIlIIllllIIlll = new IIlllIllIlIIIIIlIlllllIIl("achievement.theEnd", "theEnd", 3, 10, IIlIlIllIlIIllIllIllIIIll.llIIIlllllIlllIIllIlIIlII, AchievementList.IIIlIIlIlIIIlllIIlIllllll).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIIlIIlllllIllIIIlllIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.theEnd2", "theEnd2", 4, 13, IllllllIllIIlllIllIIlIIll.lIlllIIIlIlIIlIIIIIIlIlII, AchievementList.IllIlIlIllllIlIIllllIIlll).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIlIlIllIIIIIIIIllllIIllI = new IIlllIllIlIIIIIlIlllllIIl("achievement.enchantments", "enchantments", -4, 4, IllllllIllIIlllIllIIlIIll.llIIIIlIlIIIllIllIIIIllII, AchievementList.lIIlllIIlIlllllllllIIIIIl).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IlllIIlllIIIIllIIllllIlIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.overkill", "overkill", -4, 1, IIlIlIllIlIIllIllIllIIIll.IlIIlIIIIlIIIIllllIIlIllI, AchievementList.lIlIlIllIIIIIIIIllllIIllI).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllllIllllIlIIIlIIIllllll = new IIlllIllIlIIIIIlIlllllIIl("achievement.bookcase", "bookcase", -3, 6, IllllllIllIIlllIllIIlIIll.lIIIlllIIIlIIIIIlIIIIIIII, AchievementList.lIlIlIllIIIIIIIIllllIIllI).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IllIIlllIllIlIllIlIIIIIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.breedCow", "breedCow", 7, -5, IIlIlIllIlIIllIllIllIIIll.IlIllllIIIlIllllIIIIIllII, AchievementList.IllIllIIIlIIlllIIIllIllII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IlIlIIIlllllIIIlIlIlIllII = new IIlllIllIlIIIIIlIlllllIIl("achievement.spawnWither", "spawnWither", 7, 12, new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llllIlIIIIIllIIlIlllIllll, 1, 1), AchievementList.IllIIlIIlllllIllIIIlllIII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.IIlIIllIIIllllIIlllIllIIl = new IIlllIllIlIIIIIlIlllllIIl("achievement.killWither", "killWither", 7, 10, IIlIlIllIlIIllIllIllIIIll.IlllIIIllIlIlIIIllIIIlIlI, AchievementList.IlIlIIIlllllIIIlIlIlIllII).IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lllIlIIllllIIIIlIllIlIIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.fullBeacon", "fullBeacon", 7, 8, IllllllIllIIlllIllIIlIIll.IIIIIlllIllIIIIllIllIIIII, AchievementList.IIlIIllIIIllllIIlllIllIIl).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
        AchievementList.lIIIIlllIIlIlllllIlIllIII = new IIlllIllIlIIIIIlIlllllIIl("achievement.exploreAllBiomes", "exploreAllBiomes", 4, 8, IIlIlIllIlIIllIllIllIIIll.lllIIllllIIlIlIlIlIIIlIII, AchievementList.IllIlIlIllllIlIIllllIIlll).lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIIIIIlllIlIlIIIIIlI.class).lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI();
    }
}
