import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIlIIllIIllIlIIIllII
{
    private static lIllIIIIlllllIIlIllIIIIII lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static lIllIIIIlllllIIlIllIIIIII lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIIllIllIlIllIIIIIIlI illlIIllIllIlIllIIIIIIlI, final int n, final int n2) {
        return IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI, n, n2, null);
    }
    
    public static lIllIIIIlllllIIlIllIIIIII lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIIllIllIlIllIIIIIIlI illlIIllIllIlIllIIIIIIlI, final int n, final int n2, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII) {
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI - illlIIllIllIlIllIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll;
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl = lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl - illlIIllIllIlIllIIIIIIlI.IllIlIIIIlllIIllIIlllIIlI;
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI = lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI - illlIIllIllIlIllIIIIIIlI.IllIlIlIllllIlIIllllIIlll;
        return IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI, n, n2, IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public static lIllIIIIlllllIIlIllIIIIII lIIIIIIIIIlIllIIllIlIIlIl(final IIlllIIllIllIlIllIIIIIIlI illlIIllIllIlIllIIIIIIlI, final int n, final int n2, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII) {
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = illlIIllIllIlIllIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI;
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl = illlIIllIllIlIllIIIIIIlI.IllIlIIIIlllIIllIIlllIIlI - lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl;
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI = illlIIllIllIlIllIIIIIIlI.IllIlIlIllllIlIIllllIIlll - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI;
        return IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI, n, n2, IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    private static lIllIIIIlllllIIlIllIIIIII IlllIIIlIlllIllIlIIlllIlI(final IIlllIIllIllIlIllIIIIIIlI illlIIllIllIlIllIIIIIIlI, final int n, final int n2, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII) {
        final Random ilIIlIIllIllIIIIIlllIIlll = illlIIllIllIlIllIIIIIIlI.IlIIlIIllIllIIIIIlllIIlll();
        boolean b = false;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        float n6 = -99999;
        boolean b2;
        if (illlIIllIllIlIllIIIIIIlI.lIIlIIllIIIIIlIllIIIIllII()) {
            final double n7 = illlIIllIllIlIllIIIIIIlI.lIIIIIllllIIIIlIlIIIIlIlI().lIIIIIIIIIlIllIIllIlIIlIl(MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IllIlIlIllllIlIIllllIIlll)) + 4;
            final double n8 = illlIIllIllIlIllIIIIIIlI.IllIllIIIlIIlllIIIllIllII() + n;
            b2 = (n7 < n8 * n8);
        }
        else {
            b2 = false;
        }
        for (int i = 0; i < 10; ++i) {
            final int n9 = ilIIlIIllIllIIIIIlllIIlll.nextInt(2 * n) - n;
            final int n10 = ilIIlIIllIllIIIIIlllIIlll.nextInt(2 * n2) - n2;
            final int n11 = ilIIlIIllIllIIIIIlllIIlll.nextInt(2 * n) - n;
            if (lIllIIIIlllllIIlIllIIIIII == null || n9 * lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI + n11 * lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI >= 0.0) {
                final int n12 = n9 + MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll);
                final int n13 = n10 + MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IllIlIIIIlllIIllIIlllIIlI);
                final int n14 = n11 + MathHelper.IlllIIIlIlllIllIlIIlllIlI(illlIIllIllIlIllIIIIIIlI.IllIlIlIllllIlIIllllIIlll);
                if (!b2 || illlIIllIllIlIllIIIIIIlI.lIIIIIIIIIlIllIIllIlIIlIl(n12, n13, n14)) {
                    final float liiiIlIIllIIlIIlIIIlIIllI = illlIIllIllIlIllIIIIIIlI.lIIIIlIIllIIlIIlIIIlIIllI(n12, n13, n14);
                    if (liiiIlIIllIIlIIlIIIlIIllI > n6) {
                        n6 = liiiIlIIllIIlIIlIIIlIIllI;
                        n3 = n12;
                        n4 = n13;
                        n5 = n14;
                        b = true;
                    }
                }
            }
        }
        if (b) {
            return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4, n5);
        }
        return null;
    }
    
    static {
        IIllIlIlIIllIIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 0.0, 0.0);
    }
}
