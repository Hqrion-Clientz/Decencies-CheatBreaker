import java.util.Random;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIlIlIIIlIlIllIIIlI
{
    private llllIIlIIIIlIIllIIIlllIIl lIIIIlIIllIIlIIlIIIlIIllI;
    private llllIIlIIIIlIIllIIIlllIIl lIIIIIIIIIlIllIIllIlIIlIl;
    private IIlIIlllIlllllIlIllllIIll IlllIIIlIlllIllIlIIlllIlI;
    private List IIIIllIlIIIllIlllIlllllIl;
    
    protected IIlIllIIlIlIIIlIlIllIIIlI() {
        this.IlllIIIlIlllIllIlIIlllIlI = new IIlIIlllIlllllIlIllllIIll(this);
        (this.IIIIllIlIIIllIlllIlllllIl = new ArrayList()).add(IIlIIlIIllIIllIlIIIIIIIlI.IIIIIIlIlIlIllllllIlllIlI);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.IllIllIIIlIIlllIIIllIllII);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.IllIIlllIllIlIllIlIIIIIII);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.IllllIllllIlIIIlIIIllllll);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.IIlIIllIIIllllIIlllIllIIl);
        this.IIIIllIlIIIllIlllIlllllIl.add(IIlIIlIIllIIllIlIIIIIIIlI.lllIlIIllllIIIIlIllIlIIII);
    }
    
    public IIlIllIIlIlIIIlIlIllIIIlI(final long n, final IlIlIlIIlllIIIlIIllllIlII ilIlIlIIlllIIIlIIllllIlII) {
        this();
        final llllIIlIIIIlIIllIIIlllIIl[] liiiIlIIllIIlIIlIIIlIIllI = llllIIlIIIIlIIllIIIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, ilIlIlIIlllIIIlIIllllIlII);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI[0];
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiIlIIllIIlIIlIIIlIIllI[1];
    }
    
    public IIlIllIIlIlIIIlIlIllIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        this(iiiiiIllIlIIIIlIlllIllllI.IllIllIIIlIIlllIIIllIllII(), iiiiiIllIlIIIIlIlllIllllI.lIllIlIlllIIlIIllIIlIIlII().IlIIlIIIIlIIIIllllIIlIllI());
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
    }
    
    public float[] lIIIIlIIllIIlIIlIIIlIIllI(float[] array, final int i, final int j, final int k, final int l) {
        lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI();
        if (array == null || array.length < k * l) {
            array = new float[k * l];
        }
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(i, j, k, l);
        for (int m = 0; m < k * l; ++m) {
            try {
                float n = IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI[m]).IllIIIIIIIlIlIllllIIllIII() / (float)65536;
                if (n > 1.0f) {
                    n = 1.0f;
                }
                array[m] = n;
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Invalid Biome id");
                final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("DownfallBlock");
                category.lIIIIlIIllIIlIIlIIIlIIllI("biome id", m);
                category.lIIIIlIIllIIlIIlIIIlIIllI("downfalls[] size", array.length);
                category.lIIIIlIIllIIlIIlIIIlIIllI("x", i);
                category.lIIIIlIIllIIlIIlIIIlIIllI("z", j);
                category.lIIIIlIIllIIlIIlIIIlIIllI("w", k);
                category.lIIIIlIIllIIlIIlIIIlIIllI("h", l);
                throw new ReportedException(crashReport);
            }
        }
        return array;
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2) {
        return n;
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI[] lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI[] array, final int i, final int j, final int k, final int l) {
        lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI();
        if (array == null || array.length < k * l) {
            array = new IIlIIlIIllIIllIlIIIIIIIlI[k * l];
        }
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(i, j, k, l);
        try {
            for (int n = 0; n < k * l; ++n) {
                array[n] = IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI[n]);
            }
            return array;
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Invalid Biome id");
            final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("RawBiomeBlock");
            category.lIIIIlIIllIIlIIlIIIlIIllI("biomes[] size", array.length);
            category.lIIIIlIIllIIlIIlIIIlIIllI("x", i);
            category.lIIIIlIIllIIlIIlIIIlIIllI("z", j);
            category.lIIIIlIIllIIlIIlIIIlIIllI("w", k);
            category.lIIIIlIIllIIlIIlIIIlIIllI("h", l);
            throw new ReportedException(crashReport);
        }
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI[] lIIIIIIIIIlIllIIllIlIIlIl(final IIlIIlIIllIIllIlIIIIIIIlI[] array, final int n, final int n2, final int n3, final int n4) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(array, n, n2, n3, n4, true);
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI[] lIIIIlIIllIIlIIlIIIlIIllI(IIlIIlIIllIIllIlIIIIIIIlI[] array, final int n, final int n2, final int n3, final int n4, final boolean b) {
        lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI();
        if (array == null || array.length < n3 * n4) {
            array = new IIlIIlIIllIIllIlIIIIIIIlI[n3 * n4];
        }
        if (b && n3 == 16 && n4 == 16 && (n & 0xF) == 0x0 && (n2 & 0xF) == 0x0) {
            System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(n, n2), 0, array, 0, n3 * n4);
            return array;
        }
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4);
        for (int i = 0; i < n3 * n4; ++i) {
            array[i] = IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI[i]);
        }
        return array;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int i, final int j, final int k, final List list) {
        lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI();
        final int n = i - k >> 2;
        final int n2 = j - k >> 2;
        final int n3 = i + k >> 2;
        final int n4 = j + k >> 2;
        final int n5 = n3 - n + 1;
        final int n6 = n4 - n2 + 1;
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n5, n6);
        try {
            for (int l = 0; l < n5 * n6; ++l) {
                if (!list.contains(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI[l]))) {
                    return false;
                }
            }
            return true;
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Invalid Biome id");
            final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Layer");
            category.lIIIIlIIllIIlIIlIIIlIIllI("Layer", this.lIIIIlIIllIIlIIlIIIlIIllI.toString());
            category.lIIIIlIIllIIlIIlIIIlIIllI("x", i);
            category.lIIIIlIIllIIlIIlIIIlIIllI("z", j);
            category.lIIIIlIIllIIlIIlIIIlIIllI("radius", k);
            category.lIIIIlIIllIIlIIlIIIlIIllI("allowed", list);
            throw new ReportedException(crashReport);
        }
    }
    
    public IIlIlIlIlIlIlllIIlIllIIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final List list, final Random random) {
        lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI();
        final int n4 = n - n3 >> 2;
        final int n5 = n2 - n3 >> 2;
        final int n6 = n + n3 >> 2;
        final int n7 = n2 + n3 >> 2;
        final int n8 = n6 - n4 + 1;
        final int n9 = n7 - n5 + 1;
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n4, n5, n8, n9);
        IIlIlIlIlIlIlllIIlIllIIlI ilIlIlIlIlIlllIIlIllIIlI = null;
        int n10 = 0;
        for (int i = 0; i < n8 * n9; ++i) {
            final int n11 = n4 + i % n8 << 2;
            final int n12 = n5 + i / n8 << 2;
            if (list.contains(IIlIIlIIllIIllIlIIIIIIIlI.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI[i])) && (ilIlIlIlIlIlllIIlIllIIlI == null || random.nextInt(n10 + 1) == 0)) {
                ilIlIlIlIlIlllIIlIllIIlI = new IIlIlIlIlIlIlllIIlIllIIlI(n11, 0, n12);
                ++n10;
            }
        }
        return ilIlIlIlIlIlllIIlIllIIlI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI();
    }
}
