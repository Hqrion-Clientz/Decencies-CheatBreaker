import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIIIllIIlIlllIlIIII
{
    public final lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    public final int IlllIIIlIlllIllIlIIlllIlI;
    public final int IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private String IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private String lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private final boolean IlIlllIIIIllIllllIllIIlIl;
    private Minecraft llIIlllIIIIlllIllIlIlllIl;
    
    public IIllIlIIIIllIIlIlllIlIIII(final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final boolean ilIlllIIIIllIllllIllIIlIl) {
        this.IIIllIllIlIlllllllIlIlIII = "";
        this.lIIIIllIIlIlIllIIIlIllIlI = "";
        this.llIIlllIIIIlllIllIlIlllIl = Minecraft.getMinecraft();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    private void IlllIIIlIlllIllIlIIlllIlI() {
        this.IlIlIIIlllIIIlIlllIlIllIl = (lIlllIIIlIlIIlIIIIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl() ? Math.max(Minecraft.getMinecraft().fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI * 2, this.IlllIIIlIlllIllIlIIlllIlI) : Math.max(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI, this.IlllIIIlIlllIllIlIIlllIlI));
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            if (((this.IlIlllIIIIllIllllIllIIlIl && (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IllIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl()) || (!this.IlIlllIIIIllIllllIllIIlIl && (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IIIllIllIlIlllllllIlIlIII.IIIIllIlIIIllIlllIlllllIl())) && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) {
                final int i = this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIllIllllIllIIlIl() + 1;
                final int j = i - this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI();
                if (((String)lIlllIIIlIlIIlIIIIIIlIlII.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl()).equalsIgnoreCase("value")) {
                    this.lIIIIllIIlIlIllIIIlIllIlI = "§" + IlllIlllIlIIIIllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(lIlllIIIlIlIIlIIIIIIlIlII.lIIlIlIllIIlIIIlIIIlllIII, ((String)lIlllIIIlIlIIlIIIIIIlIlII.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl()).equalsIgnoreCase("percent") ? (j * 100 / i) : j) + j + (lIlllIIIlIlIIlIIIIIIlIlII.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl() ? ("/" + i) : "");
                }
                else if (((String)lIlllIIIlIlIIlIIIIIIlIlII.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl()).equalsIgnoreCase("percent")) {
                    this.lIIIIllIIlIlIllIIIlIllIlI = "§" + IlllIlllIlIIIIllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(lIlllIIIlIlIIlIIIIIIlIlII.lIIlIlIllIIlIIIlIIIlllIII, ((String)lIlllIIIlIlIIlIIIIIIlIlII.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl()).equalsIgnoreCase("percent") ? (j * 100 / i) : j) + j * 100 / i + "%";
                }
            }
            this.IlllIllIlIIIIlIIlIIllIIIl = this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.getStringWidth(lIIlIlIIllIIIIlIIIllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI));
            this.IIIIllIIllIIIIllIllIIIlIl = this.IIIIllIlIIIllIlllIlllllIl + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl + this.IlllIllIlIIIIlIIlIIllIIIl;
            if (lIlllIIIlIlIIlIIIIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl()) {
                this.IIIllIllIlIlllllllIlIlIII = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI();
                this.IIIIllIIllIIIIllIllIIIlIl = this.IIIIllIlIIIllIlllIlllllIl + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl + Math.max(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.getStringWidth(lIIlIlIIllIIIIlIIIllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII)), this.IlllIllIlIIIIlIIlIIllIIIl);
            }
            this.IllIIIIIIIlIlIllllIIllIII = this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.getStringWidth(lIIlIlIIllIIIIlIIIllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII));
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(32826);
        llIlIlllllIIllIIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl();
        llIlIlllllIIllIIIIllIllII.IlllIIIlIlllIllIlIIlllIlI();
        lIlllIIIlIlIIlIIIIIIlIlII.llIIlllIIIIlllIllIlIlllIl.IlIlIIIlllIIIlIlllIlIllIl = -10;
        if (IllIlIlllIIllIlIIlIIIIIII.IlllIIIlIlllIllIlIIlllIlI(CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IIIllIllIlIlllllllIlIlIII.llIlIIIlIIIIlIlllIlIIIIll()) == llIIIlIIIllllllIllIIlIIll.IIIIllIIllIIIIllIllIIIlIl) {
            lIlllIIIlIlIIlIIIIIIlIlII.llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj, this.llIIlllIIIIlllIllIlIlllIl.llIlIlIllIlIIlIlllIllIIlI(), this.lIIIIlIIllIIlIIlIIIlIIllI, (int)(n - (this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl)), (int)n2);
            lIIlIlIIllIIIIlIIIllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj, this.lIIIIlIIllIIlIIlIIIlIIllI, (int)(n - (this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl)), (int)n2, (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(), (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl());
            llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glDisable(32826);
            GL11.glDisable(3042);
            this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.drawStringWithShadow(this.IIIllIllIlIlllllllIlIlIII + "§r", n - (this.IIIIllIlIIIllIlllIlllllIl + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl) - this.IllIIIIIIIlIlIllllIIllIII, n2, 16777215);
            this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.drawStringWithShadow(this.lIIIIllIIlIlIllIIIlIllIlI + "§r", n - (this.IIIIllIlIIIllIlllIlllllIl + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl) - this.IlllIllIlIIIIlIIlIIllIIIl, n2 + (lIlllIIIlIlIIlIIIIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl() ? (this.IlIlIIIlllIIIlIlllIlIllIl / 2) : (this.IlIlIIIlllIIIlIlllIlIllIl / 4)), 16777215);
        }
        else {
            lIlllIIIlIlIIlIIIIIIlIlII.llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj, this.llIIlllIIIIlllIllIlIlllIl.llIlIlIllIlIIlIlllIllIIlI(), this.lIIIIlIIllIIlIIlIIIlIIllI, (int)n, (int)n2);
            lIIlIlIIllIIIIlIIIllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj, this.lIIIIlIIllIIlIIlIIIlIIllI, (int)n, (int)n2, (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(), (boolean)lIlllIIIlIlIIlIIIIIIlIlII.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl());
            llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
            GL11.glDisable(32826);
            GL11.glDisable(3042);
            this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.drawStringWithShadow(this.IIIllIllIlIlllllllIlIlIII + "§r", n + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl, n2, 16777215);
            this.llIIlllIIIIlllIllIlIlllIl.fontRendererObj.drawStringWithShadow(this.lIIIIllIIlIlIllIIIlIllIlI + "§r", n + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl, n2 + (lIlllIIIlIlIIlIIIIIIlIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl() ? (this.IlIlIIIlllIIIlIlllIlIllIl / 2) : (this.IlIlIIIlllIIIlIlllIlIllIl / 4)), 16777215);
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
}
