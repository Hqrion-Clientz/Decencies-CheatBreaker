import io.netty.buffer.ByteBuf;
import java.security.Key;
import java.security.PublicKey;
import javax.crypto.SecretKey;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllllIlllIllllIlIIIII extends IllllIllIllIIIIIIlIllIIll
{
    private byte[] lIIIIlIIllIIlIIlIIIlIIllI;
    private byte[] IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIllllllIlllIllllIlIIIII(final SecretKey secretKey, final PublicKey publicKey, final byte[] array) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new byte[0];
        this.IlllIIIlIlllIllIlIIlllIlI = new byte[0];
        this.lIIIIlIIllIIlIIlIIIlIIllI = IIlIlIIIIIlIllIllllllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(publicKey, secretKey.getEncoded());
        this.IlllIIIlIlllIllIlIIlllIlI = IIlIlIIIIIlIllIllllllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(publicKey, array);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII, this.lIIIIlIIllIIlIIlIIIlIIllI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll liIlllIIlllIlIllIIlIIIIll) {
    }
}
