import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonParseException;
import org.apache.commons.lang3.Validate;
import com.google.common.collect.Lists;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonElement;
import com.google.gson.JsonSerializer;

// 
// Decompiled by Procyon v0.5.36
// 

public class AnimationMetadataSectionSerializer extends IIlIIllIIIIlIIIlIIlllIlll implements JsonSerializer
{
    public AnimationMetadataSection lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) {
        final ArrayList arrayList = Lists.newArrayList();
        final JsonObject iiiIllIIllIIIIllIllIIIlIl = llIlllIllIllIIIlllIIIIlll.IIIIllIIllIIIIllIllIIIlIl(jsonElement, "metadata section");
        final int liiiIlIIllIIlIIlIIIlIIllI = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "frametime", 1);
        if (liiiIlIIllIIlIIlIIIlIIllI != 1) {
            Validate.inclusiveBetween((Object)1, (Object)Integer.MAX_VALUE, (Comparable)liiiIlIIllIIlIIlIIIlIIllI, "Invalid default frame time", new Object[0]);
        }
        if (iiiIllIIllIIIIllIllIIIlIl.has("frames")) {
            try {
                final JsonArray illlIllIlIIIIlIIlIIllIIIl = llIlllIllIllIIIlllIIIIlll.IlllIllIlIIIIlIIlIIllIIIl(iiiIllIIllIIIIllIllIIIlIl, "frames");
                for (int i = 0; i < illlIllIlIIIIlIIlIIllIIIl.size(); ++i) {
                    final lIIIIlIlIIllllllIlIIllIIl liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(i, illlIllIlIIIIlIIlIIllIIIl.get(i));
                    if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                        arrayList.add(liiiIlIIllIIlIIlIIIlIIllI2);
                    }
                }
            }
            catch (ClassCastException ex) {
                throw new JsonParseException("Invalid animation->frames: expected array, was " + iiiIllIIllIIIIllIllIIIlIl.get("frames"), (Throwable)ex);
            }
        }
        final int liiiIlIIllIIlIIlIIIlIIllI3 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "width", -1);
        final int liiiIlIIllIIlIIlIIIlIIllI4 = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "height", -1);
        if (liiiIlIIllIIlIIlIIIlIIllI3 != -1) {
            Validate.inclusiveBetween((Object)1, (Object)Integer.MAX_VALUE, (Comparable)liiiIlIIllIIlIIlIIIlIIllI3, "Invalid width", new Object[0]);
        }
        if (liiiIlIIllIIlIIlIIIlIIllI4 != -1) {
            Validate.inclusiveBetween((Object)1, (Object)Integer.MAX_VALUE, (Comparable)liiiIlIIllIIlIIlIIIlIIllI4, "Invalid height", new Object[0]);
        }
        return new AnimationMetadataSection(arrayList, liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI4, liiiIlIIllIIlIIlIIIlIIllI);
    }
    
    private lIIIIlIlIIllllllIlIIllIIl lIIIIlIIllIIlIIlIIIlIIllI(final int n, final JsonElement jsonElement) {
        if (jsonElement.isJsonPrimitive()) {
            return new lIIIIlIlIIllllllIlIIllIIl(llIlllIllIllIIIlllIIIIlll.IIIIllIlIIIllIlllIlllllIl(jsonElement, "frames[" + n + "]"));
        }
        if (jsonElement.isJsonObject()) {
            final JsonObject iiiIllIIllIIIIllIllIIIlIl = llIlllIllIllIIIlllIIIIlll.IIIIllIIllIIIIllIllIIIlIl(jsonElement, "frames[" + n + "]");
            final int liiiIlIIllIIlIIlIIIlIIllI = llIlllIllIllIIIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIIllIIIIllIllIIIlIl, "time", -1);
            if (iiiIllIIllIIIIllIllIIIlIl.has("time")) {
                Validate.inclusiveBetween((Object)1, (Object)Integer.MAX_VALUE, (Comparable)liiiIlIIllIIlIIlIIIlIIllI, "Invalid frame time", new Object[0]);
            }
            final int illIIIIIIIlIlIllllIIllIII = llIlllIllIllIIIlllIIIIlll.IllIIIIIIIlIlIllllIIllIII(iiiIllIIllIIIIllIllIIIlIl, "index");
            Validate.inclusiveBetween((Object)0, (Object)Integer.MAX_VALUE, (Comparable)illIIIIIIIlIlIllllIIllIII, "Invalid frame index", new Object[0]);
            return new lIIIIlIlIIllllllIlIIllIIl(illIIIIIIIlIlIllllIIllIII, liiiIlIIllIIlIIlIIIlIIllI);
        }
        return null;
    }
    
    public JsonElement lIIIIlIIllIIlIIlIIIlIIllI(final AnimationMetadataSection animationMetadataSection, final Type type, final JsonSerializationContext jsonSerializationContext) {
        final JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("frametime", (Number)animationMetadataSection.IIIIllIlIIIllIlllIlllllIl());
        if (animationMetadataSection.lIIIIIIIIIlIllIIllIlIIlIl() != -1) {
            jsonObject.addProperty("width", (Number)animationMetadataSection.lIIIIIIIIIlIllIIllIlIIlIl());
        }
        if (animationMetadataSection.lIIIIlIIllIIlIIlIIIlIIllI() != -1) {
            jsonObject.addProperty("height", (Number)animationMetadataSection.lIIIIlIIllIIlIIlIIIlIIllI());
        }
        if (animationMetadataSection.IlllIIIlIlllIllIlIIlllIlI() > 0) {
            final JsonArray jsonArray = new JsonArray();
            for (int i = 0; i < animationMetadataSection.IlllIIIlIlllIllIlIIlllIlI(); ++i) {
                if (animationMetadataSection.lIIIIIIIIIlIllIIllIlIIlIl(i)) {
                    final JsonObject jsonObject2 = new JsonObject();
                    jsonObject2.addProperty("index", (Number)animationMetadataSection.IlllIIIlIlllIllIlIIlllIlI(i));
                    jsonObject2.addProperty("time", (Number)animationMetadataSection.lIIIIlIIllIIlIIlIIIlIIllI(i));
                    jsonArray.add((JsonElement)jsonObject2);
                }
                else {
                    jsonArray.add((JsonElement)new JsonPrimitive((Number)animationMetadataSection.IlllIIIlIlllIllIlIIlllIlI(i)));
                }
            }
            jsonObject.add("frames", (JsonElement)jsonArray);
        }
        return (JsonElement)jsonObject;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "animation";
    }
    
    public JsonElement serialize(final Object o, final Type type, final JsonSerializationContext jsonSerializationContext) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((AnimationMetadataSection)o, type, jsonSerializationContext);
    }
}
