// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIIIIlllllIIIlllIlI extends IIllllIlIlllIIIIlllllIllI implements IlIIllIllIIIlIIIlIllIllII
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIllIIIIIIIlllllIIIlllIlI() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "*";
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String liiiIlIIllIIlIIlIIIlIIllI) {
        if (liiiIlIIllIIlIIlIIIlIIllI == null) {
            throw new IllegalArgumentException("http resource descriptor must not be null");
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
