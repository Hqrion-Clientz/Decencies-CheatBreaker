import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIllIlIIlllIlIIlIllllllll
{
    private final boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIllIlIIlllIlIIlIllllllll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = false;
    }
    
    public IIllIlIIlllIlIIlIllllllll(final boolean liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public abstract boolean a_(final IIIIIIllIlIIIIlIlllIllllI p0, final Random p1, final int p2, final int p3, final int p4);
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, 0);
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlllllIlllIIllllIIlIll, n4, 3);
        }
        else {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlllllIlllIIllllIIlIll, n4, 2);
        }
    }
}
