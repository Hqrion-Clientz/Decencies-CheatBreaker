import java.util.concurrent.Executors;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.logging.log4j.LogManager;
import java.io.ByteArrayInputStream;
import java.net.Proxy;
import java.io.InputStream;
import java.io.FileNotFoundException;
import org.apache.commons.io.FileUtils;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllIIllllllIIIllIllI extends IlllIIIlIlllIllIlIIIIllll
{
    private static final Logger IlIlIIIlllIIIlIlllIlIllIl;
    private static final AtomicInteger IIIllIllIlIlllllllIlIlIII;
    private final File IllIIIIIIIlIlIllllIIllIII;
    private final String lIIIIllIIlIlIllIIIlIllIlI;
    private final IIIIlIllllIIlIIIIlIlIIIII IlllIllIlIIIIlIIlIIllIIIl;
    private BufferedImage IlIlllIIIIllIllllIllIIlIl;
    private Thread llIIlllIIIIlllIllIlIlllIl;
    private boolean lIIlIlIllIIlIIIlIIIlllIII;
    public Boolean lIIIIlIIllIIlIIlIIIlIIllI;
    public boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private static ThreadFactory IIIlllIIIllIllIlIIIIIIlII;
    public static Runtime IlllIIIlIlllIllIlIIlllIlI;
    private static ExecutorService llIlIIIlIIIIlIlllIlIIIIll;
    
    public IIlIlIllIIllllllIIIllIllI(final File illIIIIIIIlIlIllllIIllIII, final String liiiIllIIlIlIllIIIlIllIlI, final ResourceLocation resourceLocation, final IIIIlIllllIIlIIIIlIlIIIII illlIllIlIIIIlIIlIIllIIIl) {
        super(resourceLocation);
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
    }
    
    private void IIIIllIlIIIllIlllIlllllIl() {
        if (!this.lIIlIlIllIIlIIIlIIIlllIII && this.IlIlllIIIIllIllllIllIIlIl != null) {
            if (this.IIIIllIIllIIIIllIllIIIlIl != null) {
                this.unloadSounds();
            }
            lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(super.lIIIIlIIllIIlIIlIIIlIIllI(), this.IlIlllIIIIllIllllIllIIlIl);
            this.lIIlIlIllIIlIIIlIIIlllIII = true;
        }
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IIIIllIlIIIllIlllIlllllIl();
        return super.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final BufferedImage ilIlllIIIIllIllllIllIIlIl) {
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = (this.IlIlllIIIIllIllllIllIIlIl != null);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllIllIllIIIIlIlllllIlI llIllIllIllIIIIlIlllllIlI) {
        if (this.IlIlllIIIIllIllllIllIIlIl == null && this.IIIIllIIllIIIIllIllIIIlIl != null) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(llIllIllIllIIIIlIlllllIlI);
        }
        if (this.llIIlllIIIIlllIllIlIlllIl == null) {
            if (this.IllIIIIIIIlIlIllllIIllIII != null && this.IllIIIIIIIlIlIllllIIllIII.isFile()) {
                IIlIlIllIIllllllIIIllIllI.IlIlIIIlllIIIlIlllIlIllIl.debug("Loading http texture from local cache ({})", new Object[] { this.IllIIIIIIIlIlIllllIIllIII });
                try {
                    this.IlIlllIIIIllIllllIllIIlIl = ImageIO.read(this.IllIIIIIIIlIlIllllIIllIII);
                    if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl));
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI = (this.IlIlllIIIIllIllllIllIIlIl != null);
                }
                catch (IOException ex) {
                    IIlIlIllIIllllllIIIllIllI.IlIlIIIlllIIIlIlllIlIllIl.error("Couldn't load skin " + this.IllIIIIIIIlIlIllllIIllIII, (Throwable)ex);
                    this.tick();
                }
            }
            else {
                this.tick();
            }
        }
    }
    
    protected void tick() {
        HttpURLConnection httpURLConnection = null;
        final InputStream input;
        BufferedImage bufferedImage;
        final Throwable t2;
        final InputStream inputStream;
        final Throwable t4;
        IIlIlIllIIllllllIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.submit(() -> {
            IIlIlIllIIllllllIIIllIllI.IlIlIIIlllIIIlIlllIlIllIl.debug("Downloading http texture from {} to {}", new Object[] { this.lIIIIllIIlIlIllIIIlIllIlI, this.IllIIIIIIIlIlIllllIIllIII });
            try {
                httpURLConnection = (HttpURLConnection)new URL(this.lIIIIllIIlIlIllIIIlIllIlI).openConnection(Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI());
                httpURLConnection.getInputStream();
                try {
                    if (this.IllIIIIIIIlIlIllllIIllIII != null) {
                        FileUtils.copyInputStreamToFile(input, this.IllIIIIIIIlIlIllllIIllIII);
                        bufferedImage = ImageIO.read(this.IllIIIIIIIlIlIllllIIllIII);
                    }
                    else {
                        bufferedImage = ImageIO.read(input);
                    }
                    if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                        bufferedImage = this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage);
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage);
                }
                catch (Throwable t) {
                    throw t;
                }
                finally {
                    if (input != null) {
                        if (t2 != null) {
                            try {
                                input.close();
                            }
                            catch (Throwable exception) {
                                t2.addSuppressed(exception);
                            }
                        }
                        else {
                            input.close();
                        }
                    }
                }
            }
            catch (Exception ex) {
                if (!(ex instanceof FileNotFoundException)) {
                    IIlIlIllIIllllllIIIllIllI.IlIlIIIlllIIIlIlllIlIllIl.error("Couldn't download http texture: " + ex.getClass().getName() + ": " + ex.getMessage());
                }
            }
            finally {
                this.lIIIIlIIllIIlIIlIIIlIIllI = (this.IlIlllIIIIllIllllIllIIlIl != null);
                if (httpURLConnection != null && httpURLConnection.getErrorStream() != null) {
                    try {
                        httpURLConnection.getErrorStream();
                        try {
                            while (inputStream.skip(2048L) > 0L) {}
                        }
                        catch (Throwable t3) {
                            throw t3;
                        }
                        finally {
                            if (inputStream != null) {
                                if (t4 != null) {
                                    try {
                                        inputStream.close();
                                    }
                                    catch (Throwable exception2) {
                                        t4.addSuppressed(exception2);
                                    }
                                }
                                else {
                                    inputStream.close();
                                }
                            }
                        }
                    }
                    catch (Exception ex2) {}
                }
            }
        });
    }
    
    private boolean IIIIllIIllIIIIllIllIIIlIl() {
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl) {
            return false;
        }
        final Proxy ilIIIIllIIIIIlllIIlIIlllI = Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI();
        return (ilIIIIllIIIIIlllIIlIIlllI.type() == Proxy.Type.DIRECT || ilIIIIllIIIIIlllIIlIIlllI.type() == Proxy.Type.SOCKS) && this.lIIIIllIIlIlIllIIIlIllIlI.startsWith("http://");
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        try {
            final llllIlllIIIlIlIlIIlIllIII liiiIlIIllIIlIIlIIIlIIllI = lIIIIIIlllIIIIIIllIlIllll.lIIIIlIIllIIlIIlIIIlIIllI(lIIIIIIlllIIIIIIllIlIllll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI()));
            if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() / 100 != 2) {
                return;
            }
            final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(liiiIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl());
            BufferedImage bufferedImage;
            if (this.IllIIIIIIIlIlIllllIIllIII != null) {
                FileUtils.copyInputStreamToFile((InputStream)byteArrayInputStream, this.IllIIIIIIIlIlIllllIIllIII);
                bufferedImage = ImageIO.read(this.IllIIIIIIIlIlIllllIIllIII);
            }
            else {
                bufferedImage = lllIIlIlIlIlllIIIIIIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(byteArrayInputStream);
            }
            if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                bufferedImage = this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(bufferedImage);
        }
        catch (Exception ex) {
            IIlIlIllIIllllllIIIllIllI.IlIlIIIlllIIIlIlllIlIllIl.error("Couldn't download http texture: " + ex.getClass().getName() + ": " + ex.getMessage());
        }
        finally {
            this.lIIIIlIIllIIlIIlIIIlIIllI = (this.IlIlllIIIIllIllllIllIIlIl != null);
        }
    }
    
    static {
        IlIlIIIlllIIIlIlllIlIllIl = LogManager.getLogger();
        IIIllIllIlIlllllllIlIlIII = new AtomicInteger(0);
        IIlIlIllIIllllllIIIllIllI.IIIlllIIIllIllIlIIIIIIlII = new ThreadFactoryBuilder().setNameFormat("Texture Downloader #%d").setDaemon(true).build();
        IIlIlIllIIllllllIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll = Executors.newFixedThreadPool((IIlIlIllIIllllllIIIllIllI.IlllIIIlIlllIllIlIIlllIlI = Runtime.getRuntime()).availableProcessors(), IIlIlIllIIllllllIIIllIllI.IIIlllIIIllIllIlIIIIIIlII);
    }
}
