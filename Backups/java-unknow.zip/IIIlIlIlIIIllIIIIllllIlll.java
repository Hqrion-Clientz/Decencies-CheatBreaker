import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIlIIIllIIIIllllIlll extends IlIIIllllllIllIlllllIIllI
{
    private llllIIIllIIllllIllIIlIllI lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIlIlIIIllIIIIllllIlll(final llllIIIllIIllllIllIIlIllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public String getIdentifier() {
        return "ztp";
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "/ztp [waypointName]";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length < 1) {
            throw new IIllllIlIlIIlllIlIIllIIll("/ztp [waypointName]", new Object[0]);
        }
        llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll();
        llIIIIIIlIlllllIIllllIlII illlIIIlIlllIllIlIIlllIlI = null;
        if (illlIIIlIlllIllIlIIlllIlI == null) {
            illlIIIlIlllIllIlIIlllIlI = IlIIIllllllIllIlllllIIllI.IlllIIIlIlllIllIlIIlllIlI(lIlllllIIIIIIllIlIIlIlIII);
        }
        if (illlIIIlIlllIllIlIIlllIlI == null) {
            throw new lIIIIllIIIlllIlllIlllIIlI();
        }
        String string = array[0];
        for (int i = 1; i < array.length; ++i) {
            string = string + " " + array[i];
        }
        final ArrayList liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
        lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl = null;
        for (final lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl2 : liiiIlIIllIIlIIlIIIlIIllI) {
            if (liIllIllIlIllIIIlIlllllIl2.lIIIIlIIllIIlIIlIIIlIIllI.equalsIgnoreCase(string)) {
                liIllIllIlIllIIIlIlllllIl = liIllIllIlIllIIIlIlllllIl2;
            }
        }
        final boolean b = illlIIIlIlllIllIlIIlllIlI.IIIIIIIllIllllIIlIIlllIII == -1;
        if (liIllIllIlIllIIIlIlllllIl != null && illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl != null) {
            final int n = 30000000;
            final int liiiIlIIllIIlIIlIIIlIIllI2 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, "" + liIllIllIlIllIIIlIlllllIl.IlllIIIlIlllIllIlIIlllIlI(), -n, n);
            final int liiiIlIIllIIlIIlIIIlIIllI3 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, "" + liIllIllIlIllIIIlIlllllIl.IIIIllIlIIIllIlllIlllllIl(), -n, n);
            int n2 = liIllIllIlIllIIIlIlllllIl.IIIIllIIllIIIIllIllIIIlIl();
            if (b) {
                illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
                illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl.lIllIllIlIIllIllIlIlIIlIl().IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
                int n3 = -1;
                for (int j = 0; j < 127; ++j) {
                    if (n2 + j < 127 && this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 + j, liiiIlIIllIIlIIlIIIlIIllI3) && this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 + j + 1, liiiIlIIllIIlIIlIIIlIIllI3) && this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 + j + 2, liiiIlIIllIIlIIlIIIlIIllI3)) {
                        n3 = n2 + j + 1;
                        j = 128;
                    }
                    if (n2 - j > 0 && this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 - j, liiiIlIIllIIlIIlIIIlIIllI3) && this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 - j + 1, liiiIlIIllIIlIIlIIIlIIllI3) && this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI2, n2 - j + 2, liiiIlIIllIIlIIlIIIlIIllI3)) {
                        n3 = n2 - j + 1;
                        j = 128;
                    }
                }
                if (n3 == -1) {
                    return;
                }
                n2 = n3;
            }
            else {
                if (liIllIllIlIllIIIlIlllllIl.IIIIllIIllIIIIllIllIIIlIl() == -1) {
                    n2 = illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
                }
                if (n2 == 0) {
                    illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
                    n2 = illlIIIlIlllIllIlIIlllIlI.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3);
                }
            }
            illlIIIlIlllIllIlIIlllIlI.IlllIllIlIIIIlIIlIIllIIIl(liiiIlIIllIIlIIlIIIlIIllI2 + 2.7407408f * 0.18243243f, n2, liiiIlIIllIIlIIlIIIlIIllI3 + 8.0f * 0.0625f);
        }
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length != 1 && array.length != 2) ? null : IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl());
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3);
        if (block.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            return block instanceof IIlIlllIlllIllIIIIIlIlIIl;
        }
        return block != null && block.IlIlIIIlllIIIlIlllIlIllIl().IlllIllIlIIIIlIIlIIllIIIl();
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3);
        if (block.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            return !(block instanceof IIlIlllIlllIllIIIIIlIlIIl);
        }
        return block == null;
    }
}
