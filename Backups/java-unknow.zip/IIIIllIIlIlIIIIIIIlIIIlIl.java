// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIlIlIIIIIIIlIIIlIl extends IlIIIIIlIIIIlIIIIlIlllIlI
{
    private lIllIIIIlIIlIllIIIlIlIlll lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIllIIlIlIIIIIIIlIIIlIl(final lIllIIIIlIIlIllIIIlIlIlll liiiIlIIllIIlIIlIIIlIIllI, final IIlIIlIIllIllllllllIllIII ilIIlIIllIllllllllIllIII, final int n, final int n2, final int n3) {
        super(ilIIlIIllIllllllllIllIII, n, n2, n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return false;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int a) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl()) {
            this.lIIIIIIIIIlIllIIllIlIIlIl += Math.min(a, this.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl);
        }
        return super.lIIIIlIIllIIlIIlIIIlIIllI(a);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.IIIIllIlIIIllIlllIlllllIl(lIlIlIlIlIllllIlllIIIlIlI);
        super.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, lIlIlIlIlIllllIlllIIIlIlI);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n) {
        this.lIIIIIIIIIlIllIIllIlIIlIl += n;
        this.IIIIllIlIIIllIlllIlllllIl(lIlIlIlIlIllllIlllIIIlIlI);
    }
    
    @Override
    protected void IIIIllIlIIIllIlllIlllllIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl);
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            int i = this.lIIIIIIIIIlIllIIllIlIIlIl;
            final float liiiiiiiiIlIllIIllIlIIlIl = lIllllIllIIllIlIllllIIIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl(lIlIlIlIlIllllIlllIIIlIlI);
            if (liiiiiiiiIlIllIIllIlIIlIl == 0.0f) {
                i = 0;
            }
            else if (liiiiiiiiIlIllIIllIlIIlIl < 1.0f) {
                int iiiIllIlIIIllIlllIlllllIl = MathHelper.IIIIllIlIIIllIlllIlllllIl(i * liiiiiiiiIlIllIIllIlIIlIl);
                if (iiiIllIlIIIllIlllIlllllIl < MathHelper.IlIlIIIlllIIIlIlllIlIllIl(i * liiiiiiiiIlIllIIllIlIIlIl) && (float)Math.random() < i * liiiiiiiiIlIllIIllIlIIlIl - iiiIllIlIIIllIlllIlllllIl) {
                    ++iiiIllIlIIIllIlllIlllllIl;
                }
                i = iiiIllIlIIIllIlllIlllllIl;
            }
            while (i > 0) {
                final int liiiIlIIllIIlIIlIIIlIIllI = IIIIlllIIIlllllIIlllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(i);
                i -= liiiIlIIllIIlIIlIIIlIIllI;
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new IIIIlllIIIlllllIIlllIIIIl(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI + 0.9230769276618958 * 0.5416666639761792, this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll + 0.25 * 2.0, liiiIlIIllIIlIIlIIIlIIllI));
            }
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = 0;
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IlllIllIlIIIIlIIlIIllIIIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(AchievementList.IlIlllIIIIllIllllIllIIlIl, 1);
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IIllllIIIIllIIlIllIIIIIlI) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(AchievementList.IIIlIIllllIIllllllIlIIIll, 1);
        }
    }
}
