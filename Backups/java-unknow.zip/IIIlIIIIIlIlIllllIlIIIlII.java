import java.util.Random;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIIlIlIllllIlIIIlII extends IIlllllllIlllIIllllIIlIll
{
    private boolean lIIIIlllIIlIlllllIlIllIII;
    private Set lIIIlllIlIlllIIIIIIIIIlII;
    private IlllIllIIIIlllIllIIIIIlII IIIIlIIIlllllllllIlllIlll;
    private IlllIllIIIIlllIllIIIIIlII IlIllllIIIlIllllIIIIIllII;
    private IlllIllIIIIlllIllIIIIIlII IlIIIIllIIIIIlllIIlIIlllI;
    private IlllIllIIIIlllIllIIIIIlII llIlIlIllIlIIlIlllIllIIlI;
    
    public IIIlIIIIIlIlIllllIlIIIlII() {
        super(Material.lllIIIIIlIllIlIIIllllllII);
        this.lIIIIlllIIlIlllllIlIllIII = true;
        this.lIIIlllIlIlllIIIIIIIIIlII = new HashSet();
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 0.0f, 1.0f, 0.62637365f * 0.0997807f, 1.0f);
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 5;
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return 8388608;
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) || iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == IllllllIllIIlllIllIIlIIll.IIllIllIlIIlllllIlIIIlIll;
    }
    
    private void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n, n2, n3);
        final ArrayList<IIlIlIlIlIlIlllIIlIllIIlI> list = new ArrayList<IIlIlIlIlIlIlllIIlIllIIlI>(this.lIIIlllIlIlllIIIIIIIIIlII);
        this.lIIIlllIlIlllIIIIIIIIIlII.clear();
        for (int i = 0; i < list.size(); ++i) {
            final IIlIlIlIlIlIlllIIlIllIIlI ilIlIlIlIlIlllIIlIllIIlI = list.get(i);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(ilIlIlIlIlIlllIIlIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI, ilIlIlIlIlIlllIIlIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl, ilIlIlIlIlIlllIIlIllIIlI.IlllIIIlIlllIllIlIIlllIlI, this);
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        int iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n4, n5, n6, 0);
        this.lIIIIlllIIlIlllllIlIllIII = false;
        final int illIllIIIlIIlllIIIllIllII = iiiiiIllIlIIIIlIlllIllllI.IllIllIIIlIIlllIIIllIllII(n, n2, n3);
        this.lIIIIlllIIlIlllllIlIllIII = true;
        if (illIllIIIlIIlllIIIllIllII > 0 && illIllIIIlIIlllIIIllIllII > iiIllIllIlIlllllllIlIlIII - 1) {
            iiIllIllIlIlllllllIlIlIII = illIllIIIlIIlllIIIllIllII;
        }
        int n7 = 0;
        for (int i = 0; i < 4; ++i) {
            int n8 = n;
            int n9 = n3;
            if (i == 0) {
                n8 = n - 1;
            }
            if (i == 1) {
                ++n8;
            }
            if (i == 2) {
                n9 = n3 - 1;
            }
            if (i == 3) {
                ++n9;
            }
            if (n8 != n4 || n9 != n6) {
                n7 = this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n8, n2, n9, n7);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n8, n2, n9).lIIIIllIIlIlIllIIIlIllIlI() && !iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 + 1, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
                if ((n8 != n4 || n9 != n6) && n2 >= n5) {
                    n7 = this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n8, n2 + 1, n9, n7);
                }
            }
            else if (!iiiiiIllIlIIIIlIlllIllllI.getBlock(n8, n2, n9).lIIIIllIIlIlIllIIIlIllIlI() && (n8 != n4 || n9 != n6) && n2 <= n5) {
                n7 = this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n8, n2 - 1, n9, n7);
            }
        }
        if (n7 > iiIllIllIlIlllllllIlIlIII) {
            iiIllIllIlIlllllllIlIlIII = n7 - 1;
        }
        else if (iiIllIllIlIlllllllIlIlIII > 0) {
            --iiIllIllIlIlllllllIlIlIII;
        }
        else {
            iiIllIllIlIlllllllIlIlIII = 0;
        }
        if (illIllIIIlIIlllIIIllIllII > iiIllIllIlIlllllllIlIlIII - 1) {
            iiIllIllIlIlllllllIlIlIII = illIllIIIlIIlllIIIllIllII;
        }
        if (illlIIIlIlllIllIlIIlllIlI != iiIllIllIlIlllllllIlIlIII) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, iiIllIllIlIlllllllIlIlIII, 2);
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n, n2, n3));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n - 1, n2, n3));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n + 1, n2, n3));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n, n2 - 1, n3));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n, n2 + 1, n3));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n, n2, n3 - 1));
            this.lIIIlllIlIlllIIIIIIIIIlII.add(new IIlIlIlIlIlIlllIIlIllIIlI(n, n2, n3 + 1));
        }
    }
    
    private void IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == this) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 + 1, n3, this);
        }
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        super.IIIIllIlIIIllIlllIlllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 + 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2 + 1, n3);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2 - 1, n3);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 + 1, n3);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 - 1, n3);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3 - 1);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3 - 1);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3 + 1);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3 + 1);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, n4);
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 + 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n + 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n - 1, n2, n3, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 + 1, this);
            iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3 - 1, this);
            this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1);
            this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2 + 1, n3);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2 - 1, n3);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 + 1, n3);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2 - 1, n3);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3 - 1);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3 - 1);
            }
            if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3 + 1);
            }
            else {
                this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3 + 1);
            }
        }
    }
    
    private int IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) != this) {
            return n4;
        }
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return (illlIIIlIlllIllIlIIlllIlI > n4) ? illlIIIlIlllIllIlIIlllIlI : n4;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            if (this.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
                this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, 0, 0);
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
        }
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return IIlIlIllIlIIllIllIllIIIll.IIlIlllllIIIlIIllIllIlIlI;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return this.lIIIIlllIIlIlllllIlIllIII ? this.IIIIllIlIIIllIlllIlllllIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4) : 0;
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        if (!this.lIIIIlllIIlIlllllIlIllIII) {
            return 0;
        }
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        if (illlIIIlIlllIllIlIIlllIlI == 0) {
            return 0;
        }
        if (n4 == 1) {
            return illlIIIlIlllIllIlIIlllIlI;
        }
        boolean b = IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n - 1, n2, n3, 1) || (!liIllIIIllIIIIllIllIIllIl.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n - 1, n2 - 1, n3, -1));
        boolean b2 = IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n + 1, n2, n3, 3) || (!liIllIIIllIIIIllIllIIllIl.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n + 1, n2 - 1, n3, -1));
        boolean b3 = IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2, n3 - 1, 2) || (!liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2 - 1, n3 - 1, -1));
        boolean b4 = IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2, n3 + 1, 0) || (!liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2 - 1, n3 + 1, -1));
        if (!liIllIIIllIIIIllIllIIllIl.getBlock(n, n2 + 1, n3).lIIIIllIIlIlIllIIIlIllIlI()) {
            if (liIllIIIllIIIIllIllIIllIl.getBlock(n - 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n - 1, n2 + 1, n3, -1)) {
                b = true;
            }
            if (liIllIIIllIIIIllIllIIllIl.getBlock(n + 1, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n + 1, n2 + 1, n3, -1)) {
                b2 = true;
            }
            if (liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 - 1).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2 + 1, n3 - 1, -1)) {
                b3 = true;
            }
            if (liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3 + 1).lIIIIllIIlIlIllIIIlIllIlI() && IIIllIllIlIlllllllIlIlIII(liIllIIIllIIIIllIllIIllIl, n, n2 + 1, n3 + 1, -1)) {
                b4 = true;
            }
        }
        return (!b3 && !b2 && !b && !b4 && n4 >= 2 && n4 <= 5) ? illlIIIlIlllIllIlIIlllIlI : ((n4 == 2 && b3 && !b && !b2) ? illlIIIlIlllIllIlIIlllIlI : ((n4 == 3 && b4 && !b && !b2) ? illlIIIlIlllIllIlIIlllIlI : ((n4 == 4 && b && !b3 && !b4) ? illlIIIlIlllIllIlIIlllIlI : ((n4 == 5 && b2 && !b3 && !b4) ? illlIIIlIlllIllIlIIlllIlI : false))));
    }
    
    @Override
    public boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return this.lIIIIlllIIlIlllllIlIllIII;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        if (illlIIIlIlllIllIlIIlllIlI > 0) {
            final double n4 = n + 0.692307710647583 * 0.7222222030898676 + (random.nextFloat() - 0.546875 * 0.9142857142857143) * (0.738095223903656 * 0.27096774714546334);
            final double n5 = n2 + 0.056686047f * 1.1025641f;
            final double n6 = n3 + 2.882352828979492 * 0.1734693945074819 + (random.nextFloat() - 1.2619047905582426 * 0.3962264060974121) * (1.56521737575531 * 0.12777777904713597);
            final float n7 = illlIIIlIlllIllIlIIlllIlI / (float)15;
            float n8 = n7 * (0.48979592f * 1.225f) + 1.4285715f * 0.28f;
            if (illlIIIlIlllIllIlIIlllIlI == 0) {
                n8 = 0.0f;
            }
            float n9 = n7 * n7 * (2.6451614f * 0.26463413f) - 1.2368422f * 0.4042553f;
            float n10 = n7 * n7 * (0.12911393f * 4.647059f) - 0.93333334f * 0.75f;
            if (n9 < 0.0f) {
                n9 = 0.0f;
            }
            if (n10 < 0.0f) {
                n10 = 0.0f;
            }
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4, n5, n6, n8, n9, n10);
        }
    }
    
    public static boolean IlIlIIIlllIIIlIlllIlIllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        final IIlllllllIlllIIllllIIlIll block = liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3);
        if (block == IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII) {
            return true;
        }
        if (!IllllllIllIIlllIllIIlIIll.lIllIllIllllllIllIlllIlIl.IIIIllIIllIIIIllIllIIIlIl(block)) {
            return block.llIlIIIllIIIIlllIlIIIIIlI() && n4 != -1;
        }
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return n4 == (illlIIIlIlllIllIlIIlllIlI & 0x3) || n4 == llIllIlIIIlllllIllllllIIl.IlIlIIIlllIIIlIlllIlIllIl[illlIIIlIlllIllIlIIlllIlI & 0x3];
    }
    
    public static boolean IIIllIllIlIlllllllIlIlIII(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return IlIlIIIlllIIIlIlllIlIllIl(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4) || (liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3) == IllllllIllIIlllIllIIlIIll.IlIllIIllIIIIIllIlIIIIIIl && n4 == (liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x3));
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIlIlIllIlIIllIllIllIIIll.IIlIlllllIIIlIIllIllIlIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIIIlIIIlllllllllIlllIlll = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_cross");
        this.IlIllllIIIlIllllIIIIIllII = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_line");
        this.IlIIIIllIIIIIlllIIlIIlllI = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_cross_overlay");
        this.llIlIlIllIlIIlIlllIllIIlI = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_line_overlay");
        this.IIlIIllIIIllllIIlllIllIIl = this.IIIIlIIIlllllllllIlllIlll;
    }
    
    public static IlllIllIIIIlllIllIIIIIlII IIIIllIlIIIllIlllIlllllIl(final String s) {
        return s.equals("cross") ? IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII.IIIIlIIIlllllllllIlllIlll : (s.equals("line") ? IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII.IlIllllIIIlIllllIIIIIllII : (s.equals("cross_overlay") ? IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII.IlIIIIllIIIIIlllIIlIIlllI : (s.equals("line_overlay") ? IllllllIllIIlllIllIIlIIll.lllIIllllIIlIlIlIlIIIlIII.llIlIlIllIlIIlIlllIllIIlI : null)));
    }
}
