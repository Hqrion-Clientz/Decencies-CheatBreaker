// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIlllIllIIlllIlIIII extends Entity
{
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    private EntityLivingBase lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIllllIlllIllIIlllIlIIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIIIlIlIlIllllllIlllIlI = true;
        this.IIIIllIIllIIIIllIllIIIlIl(2.2866666f * 0.42857143f, 1.5f * 0.65333337f);
        this.lIlIllIlIlIIIllllIlIllIll = this.llllIIIIlIlIllIIIllllIIll / 2.0f;
    }
    
    public IIIllllIlllIllIIlllIlIIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double lIllIllIlIIllIllIlIlIIlIl, final double llIlIIIllIIIIlllIlIIIIIlI, final double lIllIlIlllIIlIIllIIlIIlII, final EntityLivingBase liiiiiiiiIlIllIIllIlIIlIl) {
        this(iiiiiIllIlIIIIlIlllIllllI);
        this.IlllIIIlIlllIllIlIIlllIlI(lIllIllIlIIllIllIlIlIIlIl, llIlIIIllIIIIlllIlIIIIIlI, lIllIlIlllIIlIIllIIlIIlII);
        final float n = (float)(Math.random() * (2.085714340209961 * 1.5062430137357836) * 2);
        this.IllIIlIIlllllIllIIIlllIII = -(float)Math.sin(n) * (0.005897436f * 3.3913043f);
        this.lIlIlIllIIIIIIIIllllIIllI = 2.2647058963775635 * 0.08831168908074807;
        this.IlllIIlllIIIIllIIllllIlIl = -(float)Math.cos(n) * (0.0028571428f * 7.0f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = 80;
        this.lIllIllIlIIllIllIlIlIIlIl = lIllIllIlIIllIllIlIlIIlIl;
        this.llIlIIIllIIIIlllIlIIIIIlI = llIlIIIllIIIIlllIlIIIIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = lIllIlIlllIIlIIllIIlIIlII;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
    }
    
    @Override
    protected boolean IIIllIllIlIlllllllIlIlIII() {
        return false;
    }
    
    @Override
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return !this.IIllIlIllIlIllIIlIllIlIII;
    }
    
    @Override
    public void x_() {
        this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
        this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
        this.lIlIlIllIIIIIIIIllllIIllI -= 1.3606557846069336 * 0.029397588691018967;
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        this.IllIIlIIlllllIllIIIlllIII *= 2.1559999777078636 * 0.4545454680919647;
        this.lIlIlIllIIIIIIIIllllIIllI *= 1.0 * 0.9800000190734863;
        this.IlllIIlllIIIIllIIllllIlIl *= 0.8166666501098215 * 1.2000000476837158;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            this.IllIIlIIlllllIllIIIlllIII *= 1.9189189672470093 * 0.36478871699482496;
            this.IlllIIlllIIIIllIIllllIlIl *= 19.366667058318868 * 0.03614457696676254;
            this.lIlIlIllIIIIIIIIllllIIllI *= 0.8333333134651184 * -0.6000000143051151;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI-- <= 0) {
            this.IlIllllIIIlIllllIIIIIllII();
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                this.IIIIllIlIIIllIlllIlllllIl();
            }
        }
        else {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("smoke", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + 0.23863635957241058 * 2.095238130919788, this.IllIlIlIllllIlIIllllIIlll, 0.0, 0.0, 0.0);
        }
    }
    
    private void IIIIllIlIIIllIlllIlllllIl() {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, 4, true);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Fuse", (byte)this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("Fuse");
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    public EntityLivingBase IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
