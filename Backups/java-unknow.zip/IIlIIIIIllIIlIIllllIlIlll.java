// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIllIIlIIllllIlIlll
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private String lIIIIIIIIIlIllIIllIlIIlIl;
    private long IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIIIIllIIlIIllllIlIlll(final String liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = Minecraft.getSystemTime();
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        this.IlllIIIlIlllIllIlIIlllIlI = Minecraft.getSystemTime();
    }
}
