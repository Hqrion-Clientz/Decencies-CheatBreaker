import java.util.Iterator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlIlIIIIIIlllllllIl extends llIIlIIllIIllIlIIllIIllII
{
    public IIIIIIIlIlIIIIIIlllllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIIIIIIlIlIIIIIIlllllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, 0);
        this.IlllIIIlIlllIllIlIIlllIlI(n + 0.09459459703276858 * 5.285714149475098, n2 + 1.4545454545454546 * 0.34375, n3 + 0.10294117502687714 * 4.857142925262451);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return 9;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return 9;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        return n < 1024;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity) {
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        return false;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
    }
    
    @Override
    public boolean b_(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI illIIIllIlIIlIllIIIllllIl = lIllIIIIlIIlIllIIIlIlIlll.IllIIIllIlIIlIllIIIllllIl();
        boolean b = false;
        if (illIIIllIlIIlIllIIIllllIl != null && illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.lllIIlIlIllIIlIllIIIIIlII && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final double n = 7;
            final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(IlllIIIllIlIIlIllIIlIlllI.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll - n, this.IllIlIIIIlllIIllIIlllIIlI - n, this.IllIlIlIllllIlIIllllIIlll - n, this.IIIlIIlIlIIIlllIIlIllllll + n, this.IllIlIIIIlllIIllIIlllIIlI + n, this.IllIlIlIllllIlIIllllIIlll + n));
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                for (final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI : liiiIlIIllIIlIIlIIIlIIllI) {
                    if (illlIIIllIlIIlIllIIlIlllI.lIlIIIlIIIlllllllllllIlIl() && illlIIIllIlIIlIllIIlIlllI.IIllllllIlIIIIlllIlIlIlll() == lIllIIIIlIIlIllIIIlIlIlll) {
                        illlIIIllIlIIlIllIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl(this, true);
                        b = true;
                    }
                }
            }
        }
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && !b) {
            this.IlIllllIIIlIllllIIIIIllII();
            if (lIllIIIIlIIlIllIIIlIlIlll.IlllIIIllIlIlIIIllIIIlIlI.IIIIllIlIIIllIlllIlllllIl) {
                final double n2 = 7;
                final List liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(IlllIIIllIlIIlIllIIlIlllI.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll - n2, this.IllIlIIIIlllIIllIIlllIIlI - n2, this.IllIlIlIllllIlIIllllIIlll - n2, this.IIIlIIlIlIIIlllIIlIllllll + n2, this.IllIlIIIIlllIIllIIlllIIlI + n2, this.IllIlIlIllllIlIIllllIIlll + n2));
                if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                    for (final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI2 : liiiIlIIllIIlIIlIIIlIIllI2) {
                        if (illlIIIllIlIIlIllIIlIlllI2.lIlIIIlIIIlllllllllllIlIl() && illlIIIllIlIIlIllIIlIlllI2.IIllllllIlIIIIlllIlIlIlll() == this) {
                            illlIIIllIlIIlIllIIlIlllI2.lIIIIlIIllIIlIIlIIIlIIllI(true, false);
                        }
                    }
                }
            }
        }
        return true;
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIlllIIlIlllllllllIIIIIl.getBlock(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl).IlIlllIIIIllIllllIllIIlIl() == 11;
    }
    
    public static IIIIIIIlIlIIIIIIlllllllIl lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final IIIIIIIlIlIIIIIIlllllllIl iiiiiiIlIlIIIIIIlllllllIl = new IIIIIIIlIlIIIIIIlllllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
        iiiiiiIlIlIIIIIIlllllllIl.lIIlIIllIIIIIlIllIIIIllII = true;
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiiIlIlIIIIIIlllllllIl);
        return iiiiiiIlIlIIIIIIlllllllIl;
    }
    
    public static IIIIIIIlIlIIIIIIlllllllIl lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final List liiiIlIIllIIlIIlIIIlIIllI = iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(IIIIIIIlIlIIIIIIlllllllIl.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n - 1.0, n2 - 1.0, n3 - 1.0, n + 1.0, n2 + 1.0, n3 + 1.0));
        if (liiiIlIIllIIlIIlIIIlIIllI != null) {
            for (final IIIIIIIlIlIIIIIIlllllllIl iiiiiiIlIlIIIIIIlllllllIl : liiiIlIIllIIlIIlIIIlIIllI) {
                if (iiiiiiIlIlIIIIIIlllllllIl.lIIIIIIIIIlIllIIllIlIIlIl == n && iiiiiiIlIlIIIIIIlllllllIl.IlllIIIlIlllIllIlIIlllIlI == n2 && iiiiiiIlIlIIIIIIlllllllIl.IIIIllIlIIIllIlllIlllllIl == n3) {
                    return iiiiiiIlIlIIIIIIlllllllIl;
                }
            }
        }
        return null;
    }
}
