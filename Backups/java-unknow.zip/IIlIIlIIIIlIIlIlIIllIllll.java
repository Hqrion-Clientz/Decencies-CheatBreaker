import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIIIlIIlIlIIllIllll extends IllIllIlIIlllIllIIllIlIIl implements IIlIIlIIllIllllllllIllIII
{
    private lIlIlIlIlIllllIlllIIIlIlI[] IIIlIIllllIIllllllIlIIIll;
    public boolean IllIIIIIIIlIlIllllIIllIII;
    public IIlIIlIIIIlIIlIlIIllIllll lIIIIllIIlIlIllIIIlIllIlI;
    public IIlIIlIIIIlIIlIlIIllIllll IlllIllIlIIIIlIIlIIllIIIl;
    public IIlIIlIIIIlIIlIlIIllIllll IlIlllIIIIllIllllIllIIlIl;
    public IIlIIlIIIIlIIlIlIIllIllll llIIlllIIIIlllIllIlIlllIl;
    public float lIIlIlIllIIlIIIlIIIlllIII;
    public float IIIlllIIIllIllIlIIIIIIlII;
    public int llIlIIIlIIIIlIlllIlIIIIll;
    private int lllIIIIIlIllIlIIIllllllII;
    private int lIIIIIllllIIIIlIlIIIIlIlI;
    private String IIIIIIlIlIlIllllllIlllIlI;
    
    public IIlIIlIIIIlIIlIlIIllIllll() {
        this.IIIlIIllllIIllllllIlIIIll = new lIlIlIlIlIllllIlllIIIlIlI[36];
        this.lIIIIIllllIIIIlIlIIIIlIlI = -1;
    }
    
    public IIlIIlIIIIlIIlIlIIllIllll(final int liiiiIllllIIIIlIlIIIIlIlI) {
        this.IIIlIIllllIIllllllIlIIIll = new lIlIlIlIlIllllIlllIIIlIlI[36];
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return 27;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIlIlIllIIlIIIlIIIlllIII(final int n) {
        return this.IIIlIIllllIIllllllIlIIIll[n];
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (this.IIIlIIllllIIllllllIlIIIll[n] == null) {
            return null;
        }
        if (this.IIIlIIllllIIllllllIlIIIll[n].lIIIIIIIIIlIllIIllIlIIlIl <= n2) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.IIIlIIllllIIllllllIlIIIll[n];
            this.IIIlIIllllIIllllllIlIIIll[n] = null;
            this.lIllIllIlIIllIllIlIlIIlIl();
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.IIIlIIllllIIllllllIlIIIll[n].lIIIIlIIllIIlIIlIIIlIIllI(n2);
        if (this.IIIlIIllllIIllllllIlIIIll[n].lIIIIIIIIIlIllIIllIlIIlIl == 0) {
            this.IIIlIIllllIIllllllIlIIIll[n] = null;
        }
        this.lIllIllIlIIllIllIlIlIIlIl();
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI IIIlllIIIllIllIlIIIIIIlII(final int n) {
        if (this.IIIlIIllllIIllllllIlIIIll[n] != null) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = this.IIIlIIllllIIllllllIlIIIll[n];
            this.IIIlIIllllIIllllllIlIIIll[n] = null;
            return lIlIlIlIlIllllIlllIIIlIlI;
        }
        return null;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.IIIlIIllllIIllllllIlIIIll[n] = lIlIlIlIlIllllIlllIIIlIlI;
        if (lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl > this.IllIlIIIIlllIIllIIlllIIlI()) {
            lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl = this.IllIlIIIIlllIIllIIlllIIlI();
        }
        this.lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public String IIIlIIlIlIIIlllIIlIllllll() {
        return this.lIIlIIllIIIIIlIllIIIIllII() ? this.IIIIIIlIlIlIllllllIlllIlI : "container.chest";
    }
    
    @Override
    public boolean lIIlIIllIIIIIlIllIIIIllII() {
        return this.IIIIIIlIlIlIllllllIlllIlI != null && this.IIIIIIlIlIlIllllllIlllIlI.length() > 0;
    }
    
    public void setSection(final String iiiiiIlIlIlIllllllIlllIlI) {
        this.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Items", 10);
        this.IIIlIIllllIIllllllIlIIIll = new lIlIlIlIlIllllIlllIIIlIlI[this.IIIIllIIllIIIIllIllIIIlIl()];
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("CustomName", 8)) {
            this.IIIIIIlIlIlIllllllIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("CustomName");
        }
        for (int i = 0; i < illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
            final IlIIIllIIlIIlllIllllIIIIl liiiiiiiiIlIllIIllIlIIlIl = illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(i);
            final int n = liiiiiiiiIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl("Slot") & 0xFF;
            if (n >= 0 && n < this.IIIlIIllllIIllllllIlIIIll.length) {
                this.IIIlIIllllIIllllllIlIIIll[n] = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl);
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
        for (int i = 0; i < this.IIIlIIllllIIllllllIlIIIll.length; ++i) {
            if (this.IIIlIIllllIIllllllIlIIIll[i] != null) {
                final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
                ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("Slot", (byte)i);
                this.IIIlIIllllIIllllllIlIIIll[i].lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl2);
                illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl2);
            }
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Items", illIlllIlIllIIIIIIllIllll);
        if (this.lIIlIIllIIIIIlIllIIIIllII()) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CustomName", this.IIIIIIlIlIlIllllllIlllIlI);
        }
    }
    
    @Override
    public int IllIlIIIIlllIIllIIlllIIlI() {
        return 64;
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl) == this && lIllIIIIlIIlIllIIIlIlIlll.IlIlIIIlllIIIlIlllIlIllIl(this.lIIIIIIIIIlIllIIllIlIIlIl + 0.44767440184991186 * 1.1168831586837769, this.IlllIIIlIlllIllIlIIlllIlI + 2.648648738861084 * 0.18877550377442628, this.IIIIllIlIIIllIlllIlllllIl + 2.2666666507720947 * 0.220588236840951) <= 64;
    }
    
    @Override
    public void freeMemory() {
        super.freeMemory();
        this.IllIIIIIIIlIlIllllIIllIII = false;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIlIIIIlIIlIlIIllIllll ilIIlIIIIlIIlIlIIllIllll, final int n) {
        if (ilIIlIIIIlIIlIlIIllIllll.lIIIIllIIlIlIllIIIlIllIlI()) {
            this.IllIIIIIIIlIlIllllIIllIII = false;
        }
        else if (this.IllIIIIIIIlIlIllllIIllIII) {
            switch (n) {
                case 0: {
                    if (this.llIIlllIIIIlllIllIlIlllIl != ilIIlIIIIlIIlIlIIllIllll) {
                        this.IllIIIIIIIlIlIllllIIllIII = false;
                        break;
                    }
                    break;
                }
                case 1: {
                    if (this.IlIlllIIIIllIllllIllIIlIl != ilIIlIIIIlIIlIlIIllIllll) {
                        this.IllIIIIIIIlIlIllllIIllIII = false;
                        break;
                    }
                    break;
                }
                case 2: {
                    if (this.lIIIIllIIlIlIllIIIlIllIlI != ilIIlIIIIlIIlIlIIllIllll) {
                        this.IllIIIIIIIlIlIllllIIllIII = false;
                        break;
                    }
                    break;
                }
                case 3: {
                    if (this.IlllIllIlIIIIlIIlIIllIIIl != ilIIlIIIIlIIlIlIIllIllll) {
                        this.IllIIIIIIIlIlIllllIIllIII = false;
                        break;
                    }
                    break;
                }
            }
        }
    }
    
    public void updateTick() {
        if (!this.IllIIIIIIIlIlIllllIIllIII) {
            this.IllIIIIIIIlIlIllllIIllIII = true;
            this.lIIIIllIIlIlIllIIIlIllIlI = null;
            this.IlllIllIlIIIIlIIlIIllIIIl = null;
            this.IlIlllIIIIllIllllIllIIlIl = null;
            this.llIIlllIIIIlllIllIlIlllIl = null;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl - 1, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl)) {
                final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl - 1, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
                if (liiiiiiiiIlIllIIllIlIIlIl instanceof IIlIIlIIIIlIIlIlIIllIllll) {
                    this.IlIlllIIIIllIllllIllIIlIl = (IIlIIlIIIIlIIlIlIIllIllll)liiiiiiiiIlIllIIllIlIIlIl;
                }
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl + 1, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl)) {
                final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl + 1, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
                if (liiiiiiiiIlIllIIllIlIIlIl2 instanceof IIlIIlIIIIlIIlIlIIllIllll) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = (IIlIIlIIIIlIIlIlIIllIllll)liiiiiiiiIlIllIIllIlIIlIl2;
                }
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl - 1)) {
                final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl3 = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl - 1);
                if (liiiiiiiiIlIllIIllIlIIlIl3 instanceof IIlIIlIIIIlIIlIlIIllIllll) {
                    this.lIIIIllIIlIlIllIIIlIllIlI = (IIlIIlIIIIlIIlIlIIllIllll)liiiiiiiiIlIllIIllIlIIlIl3;
                }
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl + 1)) {
                final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl4 = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl + 1);
                if (liiiiiiiiIlIllIIllIlIIlIl4 instanceof IIlIIlIIIIlIIlIlIIllIllll) {
                    this.llIIlllIIIIlllIllIlIlllIl = (IIlIIlIIIIlIIlIlIIllIllll)liiiiiiiiIlIllIIllIlIIlIl4;
                }
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this, 0);
            }
            if (this.llIIlllIIIIlllIllIlIlllIl != null) {
                this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(this, 2);
            }
            if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, 1);
            }
            if (this.IlIlllIIIIllIllllIllIIlIl != null) {
                this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this, 3);
            }
        }
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == null) {
            return false;
        }
        final IIlllllllIlllIIllllIIlIll block = this.lIIIIlIIllIIlIIlIIIlIIllI.getBlock(n, n2, n3);
        return block instanceof IIIlIIlllIllllIlIllllIlIl && ((IIIlIIlllIllllIlIllllIlIl)block).lIIIIlllIIlIlllllIlIllIII == this.IIIlllIIIllIllIlIIIIIIlII();
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        this.updateTick();
        ++this.lllIIIIIlIllIlIIIllllllII;
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll && this.llIlIIIlIIIIlIlllIlIIIIll != 0 && (this.lllIIIIIlIllIlIIIllllllII + this.lIIIIIIIIIlIllIIllIlIIlIl + this.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIlIIIllIlllIlllllIl) % 200 == 0) {
            this.llIlIIIlIIIIlIlllIlIIIIll = 0;
            final float n = 5;
            for (final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll : this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl - n, this.IlllIIIlIlllIllIlIIlllIlI - n, this.IIIIllIlIIIllIlllIlllllIl - n, this.lIIIIIIIIIlIllIIllIlIIlIl + 1 + n, this.IlllIIIlIlllIllIlIIlllIlI + 1 + n, this.IIIIllIlIIIllIlllIlllllIl + 1 + n))) {
                if (lIllIIIIlIIlIllIIIlIlIlll.llIIIlllllIlllIIllIlIIlII instanceof IlIllllIIIIIIIIlIIlIllllI) {
                    final IIlIIlIIllIllllllllIllIII liiiIlIIllIIlIIlIIIlIIllI = ((IlIllllIIIIIIIIlIIlIllllI)lIllIIIIlIIlIllIIIlIlIlll.llIIIlllllIlllIIllIlIIlII).lIIIIlIIllIIlIIlIIIlIIllI();
                    if (liiiIlIIllIIlIIlIIIlIIllI != this && (!(liiiIlIIllIIlIIlIIIlIIllI instanceof llIIlIIIlllIlllllIlllllll) || !((llIIlIIIlllIlllllIlllllll)liiiIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(this))) {
                        continue;
                    }
                    ++this.llIlIIIlIIIIlIlllIlIIIIll;
                }
            }
        }
        this.IIIlllIIIllIllIlIIIIIIlII = this.lIIlIlIllIIlIIIlIIIlllIII;
        final float n2 = 0.1425532f * 0.70149255f;
        if (this.llIlIIIlIIIIlIlllIlIIIIll > 0 && this.lIIlIlIllIIlIIIlIIIlllIII == 0.0f && this.lIIIIllIIlIlIllIIIlIllIlI == null && this.IlIlllIIIIllIllllIllIIlIl == null) {
            double n3 = this.lIIIIIIIIIlIllIIllIlIIlIl + 12.399999618530273 * 0.040322581885632605;
            double n4 = this.IIIIllIlIIIllIlllIlllllIl + 0.6363636255264282 * 0.7857142990949205;
            if (this.llIIlllIIIIlllIllIlIlllIl != null) {
                n4 += 2.6764705181121826 * 0.18681319170766328;
            }
            if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                n3 += 1.1200000106811525 * 0.4464285671710968;
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n3, this.IlllIIIlIlllIllIlIIlllIlI + 1.03125 * 0.48484848484848486, n4, "random.chestopen", 0.047058824f * 10.625f, this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextFloat() * (0.17027026f * 0.5873016f) + 3.0f * 0.29999998f);
        }
        if ((this.llIlIIIlIIIIlIlllIlIIIIll == 0 && this.lIIlIlIllIIlIIIlIIIlllIII > 0.0f) || (this.llIlIIIlIIIIlIlllIlIIIIll > 0 && this.lIIlIlIllIIlIIIlIIIlllIII < 1.0f)) {
            final float liIlIlIllIIlIIIlIIIlllIII = this.lIIlIlIllIIlIIIlIIIlllIII;
            if (this.llIlIIIlIIIIlIlllIlIIIIll > 0) {
                this.lIIlIlIllIIlIIIlIIIlllIII += n2;
            }
            else {
                this.lIIlIlIllIIlIIIlIIIlllIII -= n2;
            }
            if (this.lIIlIlIllIIlIIIlIIIlllIII > 1.0f) {
                this.lIIlIlIllIIlIIIlIIIlllIII = 1.0f;
            }
            final float n5 = 0.4722222f * 1.0588236f;
            if (this.lIIlIlIllIIlIIIlIIIlllIII < n5 && liIlIlIllIIlIIIlIIIlllIII >= n5 && this.lIIIIllIIlIlIllIIIlIllIlI == null && this.IlIlllIIIIllIllllIllIIlIl == null) {
                double n6 = this.lIIIIIIIIIlIllIIllIlIIlIl + 0.5714285714285714 * 0.875;
                double n7 = this.IIIIllIlIIIllIlllIlllllIl + 0.1764705926179886 * 2.8333332629667405;
                if (this.llIIlllIIIIlllIllIlIlllIl != null) {
                    n7 += 0.9473684430122375 * 0.5277777655441087;
                }
                if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                    n6 += 0.14285714285714285 * 3.5;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(n6, this.IlllIIIlIlllIllIlIIlllIlI + 0.6076923288678284 * 0.8227847814559937, n7, "random.chestclosed", 0.6971831f * 0.7171717f, this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextFloat() * (0.5212766f * 0.19183674f) + 1.475f * 0.6101695f);
            }
            if (this.lIIlIlIllIIlIIIlIIIlllIII < 0.0f) {
                this.lIIlIlIllIIlIIIlIIIlllIII = 0.0f;
            }
        }
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int llIlIIIlIIIIlIlllIlIIIIll) {
        if (n == 1) {
            this.llIlIIIlIIIIlIlllIlIIIIll = llIlIIIlIIIIlIlllIlIIIIll;
            return true;
        }
        return super.lIIIIIIIIIlIllIIllIlIIlIl(n, llIlIIIlIIIIlIlllIlIIIIll);
    }
    
    @Override
    public void sendHorseInteraction() {
        if (this.llIlIIIlIIIIlIlllIlIIIIll < 0) {
            this.llIlIIIlIIIIlIlllIlIIIIll = 0;
        }
        ++this.llIlIIIlIIIIlIlllIlIIIIll;
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII(), 1, this.llIlIIIlIIIIlIlllIlIIIIll);
        this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII());
        this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - 1, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII());
    }
    
    @Override
    public void lIllIlIlllIIlIIllIIlIIlII() {
        if (this.IIIllIllIlIlllllllIlIlIII() instanceof IIIlIIlllIllllIlIllllIlIl) {
            --this.llIlIIIlIIIIlIlllIlIIIIll;
            this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII(), 1, this.llIlIIIlIIIIlIlllIlIIIIll);
            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII());
            this.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - 1, this.IIIIllIlIIIllIlllIlllllIl, this.IIIllIllIlIlllllllIlIlIII());
        }
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        return true;
    }
    
    @Override
    public void IlllIllIlIIIIlIIlIIllIIIl() {
        super.IlllIllIlIIIIlIIlIIllIIIl();
        this.freeMemory();
        this.updateTick();
    }
    
    public int IIIlllIIIllIllIlIIIIIIlII() {
        if (this.lIIIIIllllIIIIlIlIIIIlIlI == -1) {
            if (this.lIIIIlIIllIIlIIlIIIlIIllI == null || !(this.IIIllIllIlIlllllllIlIlIII() instanceof IIIlIIlllIllllIlIllllIlIl)) {
                return 0;
            }
            this.lIIIIIllllIIIIlIlIIIIlIlI = ((IIIlIIlllIllllIlIllllIlIl)this.IIIllIllIlIlllllllIlIlIII()).lIIIIlllIIlIlllllIlIllIII;
        }
        return this.lIIIIIllllIIIIlIlIIIIlIlI;
    }
}
