// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIlllIIllllIIlIlllII extends lllllIlIIllIIlIIlIIIllIIl
{
    public lIIIIllllIlIIIIllIllIIlIl IIIllIllIlIlllllllIlIlIII;
    public lIIIIllllIlIIIIllIllIIlIl IllIIIIIIIlIlIllllIIllIII;
    public lIIIIllllIlIIIIllIllIIlIl lIIIIllIIlIlIllIIIlIllIlI;
    public lIIIIllllIlIIIIllIllIIlIl IlllIllIlIIIIlIIlIIllIIIl;
    public lIIIIllllIlIIIIllIllIIlIl IlIlllIIIIllIllllIllIIlIl;
    public lIIIIllllIlIIIIllIllIIlIl llIIlllIIIIlllIllIlIlllIl;
    
    public IIIIlIIlllIIllllIIlIlllII() {
        this(0.0f);
    }
    
    public IIIIlIIlllIIllllIIlIlllII(final float n) {
        this(n, -7);
    }
    
    public IIIIlIIlllIIllllIIlIlllII(final float n, final float n2) {
        final int n3 = 128;
        final int n4 = 128;
        (this.IIIllIllIlIlllllllIlIlIII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4)).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f + n2, -2);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(0, 0).lIIIIlIIllIIlIIlIIIlIIllI(-4, -12, 1.0128205f * -5.43038f, 8, 10, 8, n);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(24, 0).lIIIIlIIllIIlIIlIIIlIIllI(-1, -5, -3.9516127f * 1.8979592f, 2, 4, 2, n);
        (this.IllIIIIIIIlIlIllllIIllIII = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4)).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f + n2, 0.0f);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0, 40).lIIIIlIIllIIlIIlIIIlIIllI(-9, -2, -6, 18, 12, 11, n);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(0, 70).lIIIIlIIllIIlIIlIIIlIIllI(-3.9244187f * 1.1466666f, 10, -3, 9, 5, 6, n + 0.93333334f * 0.53571427f);
        (this.lIIIIllIIlIlIllIIIlIllIlI = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4)).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -7, 0.0f);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(60, 21).lIIIIlIIllIIlIIlIIIlIIllI(-13, 0.31914893f * -7.8333335f, -3, 4, 30, 6, n);
        (this.IlllIllIlIIIIlIIlIIllIIIl = new lIIIIllllIlIIIIllIllIIlIl(this).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4)).lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -7, 0.0f);
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(60, 58).lIIIIlIIllIIlIIlIIIlIIllI(9, 3.0f * -0.8333333f, -3, 4, 30, 6, n);
        (this.IlIlllIIIIllIllllIllIIlIl = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 22).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4)).lIIIIlIIllIIlIIlIIIlIIllI(-4, 18 + n2, 0.0f);
        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(37, 0).lIIIIlIIllIIlIIlIIIlIIllI(1.7058823f * -2.0517242f, -3, -3, 6, 16, 5, n);
        this.llIIlllIIIIlllIllIlIlllIl = new lIIIIllllIlIIIIllIllIIlIl(this, 0, 22).lIIIIIIIIIlIllIIllIlIIlIl(n3, n4);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIllIIlIlIllIIIlIllIlI = true;
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(60, 0).lIIIIlIIllIIlIIlIIIlIIllI(5, 18 + n2, 0.0f);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(-3.2812498f * 1.0666667f, -3, -3, 6, 16, 5, n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5, n6, entity);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n6);
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n6);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Entity entity) {
        this.IIIllIllIlIlllllllIlIlIII.IIIllIllIlIlllllllIlIlIII = n4 / (1.8787879f * 30.49614f);
        this.IIIllIllIlIlllllllIlIlIII.IlIlIIIlllIIIlIlllIlIllIl = n5 / (7.4545455f * 7.686019f);
        this.IlIlllIIIIllIllllIllIIlIl.IlIlIIIlllIIIlIlllIlIllIl = 1.1707317f * -1.28125f * this.lIIIIlIIllIIlIIlIIIlIIllI(n, 13) * n2;
        this.llIIlllIIIIlllIllIlIlllIl.IlIlIIIlllIIIlIlllIlIllIl = 0.44444445f * 3.375f * this.lIIIIlIIllIIlIIlIIIlIIllI(n, 13) * n2;
        this.IlIlllIIIIllIllllIllIIlIl.IIIllIllIlIlllllllIlIlIII = 0.0f;
        this.llIIlllIIIIlllIllIlIlllIl.IIIllIllIlIlllllllIlIlIII = 0.0f;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n, final float n2, final float n3) {
        final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll = (llIlIIlIlllIllIlIlIllIlll)entityLivingBase;
        final int ilIIIIlllIIIlIIllllIIIlll = llIlIIlIlllIllIlIlIllIlll.IlIIIIlllIIIlIIllllIIIlll();
        if (ilIIIIlllIIIlIIllllIIIlll > 0) {
            this.lIIIIllIIlIlIllIIIlIllIlI.IlIlIIIlllIIIlIlllIlIllIl = -2 + 28.5f * 0.05263158f * this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIlllIIIlIIllllIIIlll - n3, 10);
            this.IlllIllIlIIIIlIIlIIllIIIl.IlIlIIIlllIIIlIlllIlIllIl = -2 + 33.0f * 0.045454547f * this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIlllIIIlIIllllIIIlll - n3, 10);
        }
        else {
            final int illIIIIIllllIlllIIlIIllIl = llIlIIlIlllIllIlIlIllIlll.IllIIIIIllllIlllIIlIIllIl();
            if (illIIIIIllllIlllIIlIIllIl > 0) {
                this.lIIIIllIIlIlIllIIIlIllIlI.IlIlIIIlllIIIlIlllIlIllIl = -0.78160924f * 1.0235294f + 0.031111112f * 0.8035714f * this.lIIIIlIIllIIlIIlIIIlIIllI((float)illIIIIIllllIlllIIlIIllIl, 70);
                this.IlllIllIlIIIIlIIlIIllIIIl.IlIlIIIlllIIIlIlllIlIllIl = 0.0f;
            }
            else {
                this.lIIIIllIIlIlIllIIIlIllIlI.IlIlIIIlllIIIlIlllIlIllIl = (0.81395346f * -0.24571429f + 1.453125f * 1.032258f * this.lIIIIlIIllIIlIIlIIIlIIllI(n, 13)) * n2;
                this.IlllIllIlIIIIlIIlIIllIIIl.IlIlIIIlllIIIlIlllIlIllIl = (-0.13939394f * 1.4347826f - 0.85227275f * 1.76f * this.lIIIIlIIllIIlIIlIIIlIIllI(n, 13)) * n2;
            }
        }
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2) {
        return (Math.abs(n % n2 - n2 * (0.22222222f * 2.25f)) - n2 * (1.9268292f * 0.12974684f)) / (n2 * (0.18604651f * 1.34375f));
    }
}
