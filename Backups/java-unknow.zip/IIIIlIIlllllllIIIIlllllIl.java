import java.io.DataInput;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIlllllllIIIIlllllIl extends IlIIllIlIIIlIllllllIlIlII
{
    private byte lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIIlIIlllllllIIIIlllllIl() {
    }
    
    public IIIIlIIlllllllIIIIlllllIl(final byte liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataOutput dataOutput) {
        dataOutput.writeByte(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    void lIIIIlIIllIIlIIlIIIlIIllI(final DataInput dataInput, final int n, final llllIlIIllllIllIlllllllll llllIlIIllllIllIlllllllll) {
        llllIlIIllllIllIlllllllll.lIIIIlIIllIIlIIlIIIlIIllI(8L);
        this.lIIIIIIIIIlIllIIllIlIIlIl = dataInput.readByte();
    }
    
    @Override
    public byte lIIIIlIIllIIlIIlIIIlIIllI() {
        return 1;
    }
    
    @Override
    public String toString() {
        return "" + this.lIIIIIIIIIlIllIIllIlIIlIl + "b";
    }
    
    @Override
    public lIllIIIIIlIIllIIIIlIIllII lIIIIIIIIIlIllIIllIlIIlIl() {
        return new IIIIlIIlllllllIIIIlllllIl(this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    public boolean equals(final Object o) {
        return super.equals(o) && this.lIIIIIIIIIlIllIIllIlIIlIl == ((IIIIlIIlllllllIIIIlllllIl)o).lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public int hashCode() {
        return super.hashCode() ^ this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public long IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public short IlIlIIIlllIIIlIlllIlIllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public byte IIIllIllIlIlllllllIlIlIII() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public double IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public float lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
