import com.google.common.collect.Sets;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIlllIlIllIlIIlIIIIIl extends lllIllllIllllIllIIlIlllII
{
    private static final Set IlIlllIIIIllIllllIllIIlIl;
    
    public IIlIIIlllIlIllIlIIlIIIIIl(final IlIIIllllIlllllIIlIlllllI ilIIIllllIlllllIIlIlllllI) {
        super(1.0f, ilIIIllllIlllllIIlIlllllI, IIlIIIlllIlIllIlIIlIIIIIl.IlIlllIIIIllIllllIllIIlIl);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lIlIIllIIIlllIIllIIlIIllI;
    }
    
    static {
        IlIlllIIIIllIllllIllIIlIl = Sets.newHashSet((Object[])new IIlllllllIlllIIllllIIlIll[] { IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI, IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl, IllllllIllIIlllIllIIlIIll.lIIlIlIllIIlIIIlIIIlllIII, IllllllIllIIlllIllIIlIIll.IIIlllIIIllIllIlIIIIIIlII, IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll, IllllllIllIIlllIllIIlIIll.lIlIIllIIIlllIIllIIlIIllI, IllllllIllIIlllIllIIlIIll.lIlIlIlIIlIlllIIIIIIllllI, IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl, IllllllIllIIlllIllIIlIIll.lllIIlIIllIllIIllIIlIIIIl, IllllllIllIIlllIllIIlIIll.IIllllllIlIIIIlllIlIlIlll });
    }
}
