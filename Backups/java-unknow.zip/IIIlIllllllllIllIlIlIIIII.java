import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllllllllIllIlIlIIIII extends lllllIlIIllIllIIIIllIIlIl
{
    final Iterator lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIllllllllIllIlIlIIIII(final Iterator liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean hasNext() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.hasNext();
    }
    
    @Override
    public void remove() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.remove();
    }
    
    @Override
    public Object next() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.next();
    }
}
