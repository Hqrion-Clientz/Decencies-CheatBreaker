// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIlIlllIlIllIllIlIllIllIl extends Framedata
{
    public IIlIlllIlIllIllIlIllIllIl(final DELETE_ME_E delete_ME_E) {
        super(delete_ME_E);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
    }
}
