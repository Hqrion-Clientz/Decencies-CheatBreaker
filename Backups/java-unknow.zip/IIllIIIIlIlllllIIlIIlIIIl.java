import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIlIlllllIIlIIlIIIl extends IllIlIIIlIlIlIIIIlIlIllll
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private IIlIIlIIllIllllllllIllIII lIIIIIIIIIlIllIIllIlIIlIl;
    private IIlIIlIIllIllllllllIllIII IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    
    public IIllIIIIlIlllllIIlIIlIIIl(final IIlIIlIIllIllllllllIllIII liiiiiiiiIlIllIIllIlIIlIl, final IIlIIlIIllIllllllllIllIII illlIIIlIlllIllIlIIlllIlI) {
        super(new IlIllllIIIIIIIIlIIlIllllI(liiiiiiiiIlIllIIllIlIIlIl, illlIIIlIlllIllIlIIlllIlI));
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIlIIllIIIIIlIllIIIIllII = false;
        final int n = 222 - 108;
        this.IIIIllIlIIIllIlllIlllllIl = illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl() / 9;
        this.IlIlllIIIIllIllllIllIIlIl = n + this.IIIIllIlIIIllIlllIlllllIl * 18;
    }
    
    @Override
    protected void resize(final int n, final int n2) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI.lIIlIIllIIIIIlIllIIIIllII() ? this.IlllIIIlIlllIllIlIIlllIlI.IIIlIIlIlIIIlllIIlIllllll() : IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI.IIIlIIlIlIIIlllIIlIllllll(), new Object[0]), 8, 6, 4210752);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlIIllIIIIIlIllIIIIllII() ? this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll() : IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlIIlIlIIIlllIIlIllllll(), new Object[0]), 8, this.IlIlllIIIIllIllllIllIIlIl - 96 + 2, 4210752);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2, final int n3) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(IIllIIIIlIlllllIIlIIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI);
        final int n4 = (this.lIIIIIllllIIIIlIlIIIIlIlI - this.IlllIllIlIIIIlIIlIIllIIIl) / 2;
        final int n5 = (this.IIIIIIlIlIlIllllllIlllIlI - this.IlIlllIIIIllIllllIllIIlIl) / 2;
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4, n5, 0, 0, this.IlllIllIlIIIIlIIlIIllIIIl, this.IIIIllIlIIIllIlllIlllllIl * 18 + 17);
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(n4, n5 + this.IIIIllIlIIIllIlllIlllllIl * 18 + 17, 0, 126, this.IlllIllIlIIIIlIIlIIllIIIl, 96);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/gui/container/generic_54.png");
    }
}
