// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIlllllllIIlIIIllIIl extends lllIllIIIllllIlIlllllllll
{
    public IIlIllIlllllllIIlIIIllIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
    }
    
    public IIlIllIlllllllIIlIIIllIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public boolean b_(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        if (this.IllIllIIIlIIlllIIIllIllII != null && this.IllIllIIIlIIlllIIIllIllII instanceof lIllIIIIlIIlIllIIIlIlIlll && this.IllIllIIIlIIlllIIIllIllII != lIllIIIIlIIlIllIIIlIlIlll) {
            return true;
        }
        if (this.IllIllIIIlIIlllIIIllIllII != null && this.IllIllIIIlIIlllIIIllIllII != lIllIIIIlIIlIllIIIlIlIlll) {
            return false;
        }
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(this);
        }
        return true;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 0;
    }
}
