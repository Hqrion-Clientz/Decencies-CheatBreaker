// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIlIlIlIIlIllIIlIl extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "list";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 0;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.players.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.players.list", new Object[] { llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIlIIllIIIIIlIllIIIIllII(), llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIlllIIlIlllllllllIIIIIl() }));
        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIlIIllIIlIIlIIIlIIllI(array.length > 0 && "uuids".equalsIgnoreCase(array[0]))));
    }
}
