// 
// Decompiled by Procyon v0.5.36
// 

class IIllIIllIllllIlIIlIIlIllI
{
    public IIIllIlllIlIIIlIlIIlllIIl lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ IIlllllIlllIlllllllIlllll IlllIIIlIlllIllIlIIlllIlI;
    
    public IIllIIllIllllIlIIlIIlIllI(final IIlllllIlllIlllllllIlllll illlIIIlIlllIllIlIIlllIlI, final int liiiiiiiiIlIllIIllIlIIlIl, final IIIllIlllIlIIIlIlIIlllIIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
}
