import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.util.TimeZone;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Calendar;
import java.util.LinkedList;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.nio.ByteBuffer;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIllllllIIIIIIIlIlll extends IIIIlIlllIlIllIlIllllIllI
{
    private IlIlIIlIlllIlIlllIIIIllII IlIlIIIlllIIIlIlllIlIllIl;
    private List IIIllIllIlIlllllllIlIlIII;
    private IllIIlIllIlIllllIIIlIlIIl IllIIIIIIIlIlIllllIIllIII;
    private List lIIIIllIIlIlIllIIIlIllIlI;
    private IFramedata IlllIllIlIIIIlIIlIIllIIIl;
    private List IlIlllIIIIllIllllIllIIlIl;
    private ByteBuffer llIIlllIIIIlllIllIlIlllIl;
    private final Random lIIlIlIllIIlIIIlIIIlllIII;
    static final /* synthetic */ boolean IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIIlIllllllIIIIIIIlIlll() {
        this(Collections.emptyList());
    }
    
    public IIIIIlIllllllIIIIIIIlIlll(final IlIlIIlIlllIlIlllIIIIllII o) {
        this(Collections.singletonList(o));
    }
    
    public IIIIIlIllllllIIIIIIIlIlll(final List list) {
        this(list, Collections.singletonList(new lIIIIllIlllIIlIllllllIlll("")));
    }
    
    public IIIIIlIllllllIIIIIIIlIlll(final List list, final List list2) {
        this.IlIlIIIlllIIIlIlllIlIllIl = new llIlIIIlllIIIllIllllIIIll();
        this.lIIlIlIllIIlIIIlIIIlllIII = new Random();
        if (list == null || list2 == null) {
            throw new IllegalArgumentException();
        }
        this.IIIllIllIlIlllllllIlIlIII = new ArrayList(list.size());
        this.lIIIIllIIlIlIllIIIlIllIlI = new ArrayList(list2.size());
        boolean b = false;
        this.IlIlllIIIIllIllllIllIIlIl = new ArrayList();
        final Iterator<IlIlIIlIlllIlIlllIIIIllII> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getClass().equals(llIlIIIlllIIIllIllllIIIll.class)) {
                b = true;
            }
        }
        this.IIIllIllIlIlllllllIlIlIII.addAll(list);
        if (!b) {
            this.IIIllIllIlIlllllllIlIlIII.add(this.IIIllIllIlIlllllllIlIlIII.size(), this.IlIlIIIlllIIIlIlllIlIllIl);
        }
        this.lIIIIllIIlIlIllIIIlIllIlI.addAll(list2);
    }
    
    @Override
    public lIlIIIIIIIIlllllllIlIIIll lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll lllIlllIIIIIllllIlIIIIIll) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl(lllIlllIIIIIllllIlIIIIIll) != 13) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        lIlIIIIIIIIlllllllIlIIIll lIlIIIIIIIIlllllllIlIIIll = lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        final String liiiiiiiiIlIllIIllIlIIlIl = lllIlllIIIIIllllIlIIIIIll.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Extensions");
        for (final IlIlIIlIlllIlIlllIIIIllII ilIlIIIlllIIIlIlllIlIllIl : this.IIIllIllIlIlllllllIlIlIII) {
            if (ilIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl)) {
                this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
                lIlIIIIIIIIlllllllIlIIIll = lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
                break;
            }
        }
        lIlIIIIIIIIlllllllIlIIIll lIlIIIIIIIIlllllllIlIIIll2 = lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        final String liiiiiiiiIlIllIIllIlIIlIl2 = lllIlllIIIIIllllIlIIIIIll.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Protocol");
        for (final IllIIlIllIlIllllIIIlIlIIl illIIIIIIIlIlIllllIIllIII : this.lIIIIllIIlIlIllIIIlIllIlI) {
            if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl2)) {
                this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
                lIlIIIIIIIIlllllllIlIIIll2 = lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
                break;
            }
        }
        if (lIlIIIIIIIIlllllllIlIIIll2 == lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI && lIlIIIIIIIIlllllllIlIIIll == lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public lIlIIIIIIIIlllllllIlIIIll lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll lllIlllIIIIIllllIlIIIIIll, final IllIIllIIlllIlllIllIIIIIl illIIllIIlllIlllIllIIIIIl) {
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI(illIIllIIlllIlllIllIIIIIl)) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        if (!lllIlllIIIIIllllIlIIIIIll.IlllIIIlIlllIllIlIIlllIlI("Sec-WebSocket-Key") || !illIIllIIlllIlllIllIIIIIl.IlllIIIlIlllIllIlIIlllIlI("Sec-WebSocket-Accept")) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI(lllIlllIIIIIllllIlIIIIIll.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Key")).equals(illIIllIIlllIlllIllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Accept"))) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        lIlIIIIIIIIlllllllIlIIIll lIlIIIIIIIIlllllllIlIIIll = lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        final String liiiiiiiiIlIllIIllIlIIlIl = illIIllIIlllIlllIllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Extensions");
        for (final IlIlIIlIlllIlIlllIIIIllII ilIlIIIlllIIIlIlllIlIllIl : this.IIIllIllIlIlllllllIlIlIII) {
            if (ilIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl)) {
                this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
                lIlIIIIIIIIlllllllIlIIIll = lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
                break;
            }
        }
        lIlIIIIIIIIlllllllIlIIIll lIlIIIIIIIIlllllllIlIIIll2 = lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
        final String liiiiiiiiIlIllIIllIlIIlIl2 = illIIllIIlllIlllIllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Protocol");
        for (final IllIIlIllIlIllllIIIlIlIIl illIIIIIIIlIlIllllIIllIII : this.lIIIIllIIlIlIllIIIlIllIlI) {
            if (illIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl2)) {
                this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
                lIlIIIIIIIIlllllllIlIIIll2 = lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
                break;
            }
        }
        if (lIlIIIIIIIIlllllllIlIIIll2 == lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI && lIlIIIIIIIIlllllllIlIIIll == lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI) {
            return lIlIIIIIIIIlllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        return lIlIIIIIIIIlllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public IlIlIIlIlllIlIlllIIIIllII IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public List IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public IllIIlIllIlIllllIIIlIlIIl IIIllIllIlIlllllllIlIlIII() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public List IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    @Override
    public IlIIllIllIIIlIIIlIllIllII lIIIIlIIllIIlIIlIIIlIIllI(final IlIIllIllIIIlIIIlIllIllII ilIIllIllIIIlIIIlIllIllII) {
        ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Upgrade", "websocket");
        ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Connection", "Upgrade");
        final byte[] bytes = new byte[16];
        this.lIIlIlIllIIlIIIlIIIlllIII.nextBytes(bytes);
        ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Key", lIllIIlllIIIlIlIIIlllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(bytes));
        ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Version", "13");
        final StringBuilder sb = new StringBuilder();
        for (final IlIlIIlIlllIlIlllIIIIllII ilIlIIlIlllIlIlllIIIIllII : this.IIIllIllIlIlllllllIlIlIII) {
            if (ilIlIIlIlllIlIlllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI() != null && ilIlIIlIlllIlIlllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI().length() != 0) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(ilIlIIlIlllIlIlllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI());
            }
        }
        if (sb.length() != 0) {
            ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Extensions", sb.toString());
        }
        final StringBuilder sb2 = new StringBuilder();
        for (final IllIIlIllIlIllllIIIlIlIIl illIIlIllIlIllllIIIlIlIIl : this.lIIIIllIIlIlIllIIIlIllIlI) {
            if (illIIlIllIlIllllIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI().length() != 0) {
                if (sb2.length() > 0) {
                    sb2.append(", ");
                }
                sb2.append(illIIlIllIlIllllIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI());
            }
        }
        if (sb2.length() != 0) {
            ilIIllIllIIIlIIIlIllIllII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Protocol", sb2.toString());
        }
        return ilIIllIllIIIlIIIlIllIllII;
    }
    
    @Override
    public IIlllllIIIllllIIlIlIIllIl lIIIIlIIllIIlIIlIIIlIIllI(final lllIlllIIIIIllllIlIIIIIll lllIlllIIIIIllllIlIIIIIll, final lIlIllllIlllIllllIIlIIIII lIlIllllIlllIllllIIlIIIII) {
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Upgrade", "websocket");
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Connection", lllIlllIIIIIllllIlIIIIIll.lIIIIIIIIIlIllIIllIlIIlIl("Connection"));
        final String liiiiiiiiIlIllIIllIlIIlIl = lllIlllIIIIIllllIlIIIIIll.lIIIIIIIIIlIllIIllIlIIlIl("Sec-WebSocket-Key");
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            throw new IlIlIlIIllIIllllIIIlllIll("missing Sec-WebSocket-Key");
        }
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Accept", this.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl));
        if (this.IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl().length() != 0) {
            lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Extensions", this.IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl());
        }
        if (this.IIIllIllIlIlllllllIlIlIII() != null && this.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().length() != 0) {
            lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Sec-WebSocket-Protocol", this.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI());
        }
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Web Socket Protocol Handshake");
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Server", "TooTallNate Java-WebSocket");
        lIlIllllIlllIllllIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI("Date", this.lIIIIllIIlIlIllIIIlIllIlI());
        return lIlIllllIlllIllllIIlIIIII;
    }
    
    @Override
    public IIIIlIlllIlIllIlIllllIllI IlllIIIlIlllIllIlIIlllIlI() {
        final ArrayList<IlIlIIlIlllIlIlllIIIIllII> list = new ArrayList<IlIlIIlIlllIlIlllIIIIllII>();
        final Iterator<IlIlIIlIlllIlIlllIIIIllII> iterator = this.IlIlIIIlllIIIlIlllIlIllIl().iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().IlllIIIlIlllIllIlIIlllIlI());
        }
        final ArrayList<IllIIlIllIlIllllIIIlIlIIl> list2 = new ArrayList<IllIIlIllIlIllllIIIlIlIIl>();
        final Iterator<IllIIlIllIlIllllIIIlIlIIl> iterator2 = this.IllIIIIIIIlIlIllllIIllIII().iterator();
        while (iterator2.hasNext()) {
            list2.add(iterator2.next().lIIIIIIIIIlIllIIllIlIIlIl());
        }
        return new IIIIIlIllllllIIIIIIIlIlll(list, list2);
    }
    
    @Override
    public ByteBuffer lIIIIlIIllIIlIIlIIIlIIllI(final IFramedata framedata) {
        this.IIIIllIIllIIIIllIllIIIlIl().IlllIIIlIlllIllIlIIlllIlI(framedata);
        if (IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            System.out.println("afterEnconding(" + framedata.IIIIllIlIIIllIlllIlllllIl().remaining() + "): {" + ((framedata.IIIIllIlIIIllIlllIlllllIl().remaining() > 1000) ? "too big to display" : new String(framedata.IIIIllIlIIIllIlllIlllllIl().array())) + '}');
        }
        return this.lIIIIIIIIIlIllIIllIlIIlIl(framedata);
    }
    
    private ByteBuffer lIIIIIIIIIlIllIIllIlIIlIl(final IFramedata framedata) {
        final ByteBuffer iiiIllIlIIIllIlllIlllllIl = framedata.IIIIllIlIIIllIlllIlllllIl();
        final boolean b = this.IlllIIIlIlllIllIlIIlllIlI == IIIlIlIlIIIIIlIlllllIIIlI.lIIIIlIIllIIlIIlIIIlIIllI;
        final int n = (iiiIllIlIIIllIlllIlllllIl.remaining() <= 125) ? 1 : ((iiiIllIlIIIllIlllIlllllIl.remaining() <= 65535) ? 2 : 8);
        final ByteBuffer allocate = ByteBuffer.allocate(1 + ((n > 1) ? (n + 1) : n) + (b ? 4 : 0) + iiiIllIlIIIllIlllIlllllIl.remaining());
        allocate.put((byte)((byte)(framedata.IIIIllIIllIIIIllIllIIIlIl() ? -128 : 0) | this.lIIIIlIIllIIlIIlIIIlIIllI(framedata.IlllIllIlIIIIlIIlIIllIIIl())));
        final byte[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl.remaining(), n);
        if (!IIIIIlIllllllIIIIIIIlIlll.IIIIllIIllIIIIllIllIIIlIl && liiiIlIIllIIlIIlIIIlIIllI.length != n) {
            throw new AssertionError();
        }
        if (n == 1) {
            allocate.put((byte)(liiiIlIIllIIlIIlIIIlIIllI[0] | (b ? -128 : 0)));
        }
        else if (n == 2) {
            allocate.put((byte)(0x7E | (b ? -128 : 0)));
            allocate.put(liiiIlIIllIIlIIlIIIlIIllI);
        }
        else {
            if (n != 8) {
                throw new RuntimeException("Size representation not supported/specified");
            }
            allocate.put((byte)(0x7F | (b ? -128 : 0)));
            allocate.put(liiiIlIIllIIlIIlIIIlIIllI);
        }
        if (b) {
            final ByteBuffer allocate2 = ByteBuffer.allocate(4);
            allocate2.putInt(this.lIIlIlIllIIlIIIlIIIlllIII.nextInt());
            allocate.put(allocate2.array());
            int n2 = 0;
            while (iiiIllIlIIIllIlllIlllllIl.hasRemaining()) {
                allocate.put((byte)(iiiIllIlIIIllIlllIlllllIl.get() ^ allocate2.get(n2 % 4)));
                ++n2;
            }
        }
        else {
            allocate.put(iiiIllIlIIIllIlllIlllllIl);
            iiiIllIlIIIllIlllIlllllIl.flip();
        }
        if (!IIIIIlIllllllIIIIIIIlIlll.IIIIllIIllIIIIllIllIIIlIl && allocate.remaining() != 0) {
            throw new AssertionError(allocate.remaining());
        }
        allocate.flip();
        return allocate;
    }
    
    public IFramedata IIIIllIIllIIIIllIllIIIlIl(final ByteBuffer byteBuffer) {
        final int remaining = byteBuffer.remaining();
        int n = 2;
        if (remaining < n) {
            throw new IIlIIIIIlIlIIIlIIIIlIlIlI(n);
        }
        final byte value = byteBuffer.get();
        final boolean b = value >> 8 != 0;
        boolean b2 = false;
        boolean b3 = false;
        boolean b4 = false;
        if ((value & 0x40) != 0x0) {
            b2 = true;
        }
        if ((value & 0x20) != 0x0) {
            b3 = true;
        }
        if ((value & 0x10) != 0x0) {
            b4 = true;
        }
        final byte value2 = byteBuffer.get();
        final boolean b5 = (value2 & 0xFFFFFF80) != 0x0;
        int intValue = (byte)(value2 & 0x7F);
        final DELETE_ME_E liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI((byte)(value & 0xF));
        if (intValue < 0 || intValue > 125) {
            if (liiiIlIIllIIlIIlIIIlIIllI == DELETE_ME_E.IIIIllIlIIIllIlllIlllllIl || liiiIlIIllIIlIIlIIIlIIllI == DELETE_ME_E.IIIIllIIllIIIIllIllIIIlIl || liiiIlIIllIIlIIlIIIlIIllI == DELETE_ME_E.IlIlIIIlllIIIlIlllIlIllIl) {
                throw new llIIIIIIllIlllIIlIlIlIlIl("more than 125 octets");
            }
            if (intValue == 126) {
                n += 2;
                if (remaining < n) {
                    throw new IIlIIIIIlIlIIIlIIIIlIlIlI(n);
                }
                intValue = new BigInteger(new byte[] { 0, byteBuffer.get(), byteBuffer.get() }).intValue();
            }
            else {
                n += 8;
                if (remaining < n) {
                    throw new IIlIIIIIlIlIIIlIIIIlIlIlI(n);
                }
                final byte[] val = new byte[8];
                for (int i = 0; i < 8; ++i) {
                    val[i] = byteBuffer.get();
                }
                final long longValue = new BigInteger(val).longValue();
                if (longValue > 2147483647L) {
                    throw new IllIlllIlllIIllllIlIlIIIl("Payloadsize is to big...");
                }
                intValue = (int)longValue;
            }
        }
        final int n2 = n + (b5 ? 4 : 0) + intValue;
        if (remaining < n2) {
            throw new IIlIIIIIlIlIIIlIIIIlIlIlI(n2);
        }
        final ByteBuffer allocate = ByteBuffer.allocate(this.lIIIIlIIllIIlIIlIIIlIIllI(intValue));
        if (b5) {
            final byte[] dst = new byte[4];
            byteBuffer.get(dst);
            for (int j = 0; j < intValue; ++j) {
                allocate.put((byte)(byteBuffer.get() ^ dst[j % 4]));
            }
        }
        else {
            allocate.put(byteBuffer.array(), byteBuffer.position(), allocate.limit());
            byteBuffer.position(byteBuffer.position() + allocate.limit());
        }
        final Framedata liiiIlIIllIIlIIlIIIlIIllI2 = Framedata.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(b);
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl(b2);
        liiiIlIIllIIlIIlIIIlIIllI2.IlllIIIlIlllIllIlIIlllIlI(b3);
        liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl(b4);
        allocate.flip();
        liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(allocate);
        this.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2);
        this.IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2);
        if (IlIIlIllIlIIlllllIllIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            System.out.println("afterDecoding(" + liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl().remaining() + "): {" + ((liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl().remaining() > 1000) ? "too big to display" : new String(liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl().array())) + '}');
        }
        liiiIlIIllIIlIIlIIIlIIllI2.IlllIIIlIlllIllIlIIlllIlI();
        return liiiIlIIllIIlIIlIIIlIIllI2;
    }
    
    @Override
    public List IlllIIIlIlllIllIlIIlllIlI(final ByteBuffer src) {
        LinkedList<IFramedata> list;
        while (true) {
            list = new LinkedList<IFramedata>();
            if (this.llIIlllIIIIlllIllIlIlllIl != null) {
                try {
                    src.mark();
                    final int remaining = src.remaining();
                    final int remaining2 = this.llIIlllIIIIlllIllIlIlllIl.remaining();
                    if (remaining2 > remaining) {
                        this.llIIlllIIIIlllIllIlIlllIl.put(src.array(), src.position(), remaining);
                        src.position(src.position() + remaining);
                        return Collections.emptyList();
                    }
                    this.llIIlllIIIIlllIllIlIlllIl.put(src.array(), src.position(), remaining2);
                    src.position(src.position() + remaining2);
                    list.add(this.IIIIllIIllIIIIllIllIIIlIl((ByteBuffer)this.llIIlllIIIIlllIllIlIlllIl.duplicate().position(0)));
                    this.llIIlllIIIIlllIllIlIlllIl = null;
                }
                catch (IIlIIIIIlIlIIIlIIIIlIlIlI ilIIIIIlIlIIIlIIIIlIlIlI) {
                    final ByteBuffer allocate = ByteBuffer.allocate(this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIlIIIlIIIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()));
                    if (!IIIIIlIllllllIIIIIIIlIlll.IIIIllIIllIIIIllIllIIIlIl && allocate.limit() <= this.llIIlllIIIIlllIllIlIlllIl.limit()) {
                        throw new AssertionError();
                    }
                    this.llIIlllIIIIlllIllIlIlllIl.rewind();
                    allocate.put(this.llIIlllIIIIlllIllIlIlllIl);
                    this.llIIlllIIIIlllIllIlIlllIl = allocate;
                    continue;
                }
                break;
            }
            break;
        }
        while (src.hasRemaining()) {
            src.mark();
            try {
                list.add(this.IIIIllIIllIIIIllIllIIIlIl(src));
                continue;
            }
            catch (IIlIIIIIlIlIIIlIIIIlIlIlI ilIIIIIlIlIIIlIIIIlIlIlI2) {
                src.reset();
                (this.llIIlllIIIIlllIllIlIlllIl = ByteBuffer.allocate(this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIIlIlIIIlIIIIlIlIlI2.lIIIIlIIllIIlIIlIIIlIIllI()))).put(src);
            }
            break;
        }
        return list;
    }
    
    @Override
    public List lIIIIlIIllIIlIIlIIIlIIllI(final ByteBuffer byteBuffer, final boolean b) {
        final lIIllIllllIlIIIIlIIIIIIIl o = new lIIllIllllIlIIIIlIIIIIIIl();
        o.lIIIIlIIllIIlIIlIIIlIIllI(byteBuffer);
        o.IIIIllIIllIIIIllIllIIIlIl(b);
        try {
            o.IlllIIIlIlllIllIlIIlllIlI();
        }
        catch (lIlllllIllllIIlIIIlllllll lIlllllIllllIIlIIIlllllll) {
            throw new llIIIlIIllIIlllllIIllIIlI(lIlllllIllllIIlIIIlllllll);
        }
        return Collections.singletonList(o);
    }
    
    @Override
    public List lIIIIlIIllIIlIIlIIIlIIllI(final String s, final boolean b) {
        final lllllllIllIlllIIlIllllIll o = new lllllllIllIlllIIlIllllIll();
        o.lIIIIlIIllIIlIIlIIIlIIllI(ByteBuffer.wrap(IlllllIIlIIIllIllllIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(s)));
        o.IIIIllIIllIIIIllIllIIIlIl(b);
        try {
            o.IlllIIIlIlllIllIlIIlllIlI();
        }
        catch (lIlllllIllllIIlIIIlllllll lIlllllIllllIIlIIIlllllll) {
            throw new llIIIlIIllIIlllllIIllIIlI(lIlllllIllllIIlIIIlllllll);
        }
        return Collections.singletonList(o);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.llIIlllIIIIlllIllIlIlllIl = null;
        if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            this.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl();
        }
        this.IlIlIIIlllIIIlIlllIlIllIl = new llIlIIIlllIIIllIllllIIIll();
        this.IllIIIIIIIlIlIllllIIllIII = null;
    }
    
    private String lIIIIllIIlIlIllIIIlIllIlI() {
        final Calendar instance = Calendar.getInstance();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return simpleDateFormat.format(instance.getTime());
    }
    
    private String lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        final String string = s.trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        MessageDigest instance;
        try {
            instance = MessageDigest.getInstance("SHA1");
        }
        catch (NoSuchAlgorithmException cause) {
            throw new IllegalStateException(cause);
        }
        return lIllIIlllIIIlIlIIIlllIlIl.lIIIIlIIllIIlIIlIIIlIIllI(instance.digest(string.getBytes()));
    }
    
    private byte[] lIIIIlIIllIIlIIlIIIlIIllI(final long n, final int n2) {
        final byte[] array = new byte[n2];
        final int n3 = 8 * n2 - 8;
        for (int i = 0; i < n2; ++i) {
            array[i] = (byte)(n >>> n3 - 8 * i);
        }
        return array;
    }
    
    private byte lIIIIlIIllIIlIIlIIIlIIllI(final DELETE_ME_E delete_ME_E) {
        if (delete_ME_E == DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI) {
            return 0;
        }
        if (delete_ME_E == DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl) {
            return 1;
        }
        if (delete_ME_E == DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI) {
            return 2;
        }
        if (delete_ME_E == DELETE_ME_E.IlIlIIIlllIIIlIlllIlIllIl) {
            return 8;
        }
        if (delete_ME_E == DELETE_ME_E.IIIIllIlIIIllIlllIlllllIl) {
            return 9;
        }
        if (delete_ME_E == DELETE_ME_E.IIIIllIIllIIIIllIllIIIlIl) {
            return 10;
        }
        throw new IllegalArgumentException("Don't know how to handle " + delete_ME_E.toString());
    }
    
    private DELETE_ME_E lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        switch (b) {
            case 0: {
                return DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI;
            }
            case 1: {
                return DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl;
            }
            case 2: {
                return DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI;
            }
            case 8: {
                return DELETE_ME_E.IlIlIIIlllIIIlIlllIlIllIl;
            }
            case 9: {
                return DELETE_ME_E.IIIIllIlIIIllIlllIlllllIl;
            }
            case 10: {
                return DELETE_ME_E.IIIIllIIllIIIIllIllIIIlIl;
            }
            default: {
                throw new llIIIIIIllIlllIIlIlIlIlIl("Unknown opcode " + b);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIllIlIIlllllIllIlIlI ilIIlIllIlIIlllllIllIlIlI, final IFramedata illlIllIlIIIIlIIlIIllIIIl) {
        final DELETE_ME_E illlIllIlIIIIlIIlIIllIIIl2 = illlIllIlIIIIlIIlIIllIIIl.IlllIllIlIIIIlIIlIIllIIIl();
        if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.IlIlIIIlllIIIlIlllIlIllIl) {
            int liiiIlIIllIIlIIlIIIlIIllI = 1005;
            String liiiiiiiiIlIllIIllIlIIlIl = "";
            if (illlIllIlIIIIlIIlIIllIIIl instanceof llIlIIlllIIlIlIlIlIlIIIIl) {
                final llIlIIlllIIlIlIlIlIlIIIIl llIlIIlllIIlIlIlIlIlIIIIl = (llIlIIlllIIlIlIlIlIlIIIIl)illlIllIlIIIIlIIlIIllIIIl;
                liiiIlIIllIIlIIlIIIlIIllI = llIlIIlllIIlIlIlIlIlIIIIl.lIIIIlIIllIIlIIlIIIlIIllI();
                liiiiiiiiIlIllIIllIlIIlIl = llIlIIlllIIlIlIlIlIlIIIIl.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            if (ilIIlIllIlIIlllllIllIlIlI.llIlIIIlIIIIlIlllIlIIIIll() == IlIlllIIIlIlIlIllllllIlII.IIIIllIlIIIllIlllIlllllIl) {
                ilIIlIllIlIIlllllIllIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl, true);
            }
            else if (this.lIIIIIIIIIlIllIIllIlIIlIl() == IIIIIIIIIIIIIIlllIlIlIlll.IlllIIIlIlllIllIlIIlllIlI) {
                ilIIlIllIlIIlllllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl, true);
            }
            else {
                ilIIlIllIlIIlllllIllIlIlI.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl, false);
            }
        }
        else if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.IIIIllIlIIIllIlllIlllllIl) {
            ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIIIIIIlIllIIllIlIIlIl(ilIIlIllIlIIlllllIllIlIlI, illlIllIlIIIIlIIlIIllIIIl);
        }
        else if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.IIIIllIIllIIIIllIllIIIlIl) {
            ilIIlIllIlIIlllllIllIlIlI.runTick();
            ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().IlllIIIlIlllIllIlIIlllIlI(ilIIlIllIlIIlllllIllIlIlI, illlIllIlIIIIlIIlIIllIIIl);
        }
        else if (!illlIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl() || illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (illlIllIlIIIIlIIlIIllIIIl2 != DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI) {
                if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                    throw new lIlllllIllllIIlIIIlllllll(1002, "Previous continuous frame sequence not completed.");
                }
                this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
                this.IlIlllIIIIllIllllIllIIlIl.add(illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
            }
            else if (illlIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl()) {
                if (this.IlllIllIlIIIIlIIlIIllIIIl == null) {
                    throw new lIlllllIllllIIlIIIlllllll(1002, "Continuous frame sequence was not started.");
                }
                this.IlIlllIIIIllIllllIllIIlIl.add(illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
                if (this.IlllIllIlIIIIlIIlIIllIIIl.IlllIllIlIIIIlIIlIIllIIIl() == DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl) {
                    ((Framedata)this.IlllIllIlIIIIlIIlIIllIIIl).lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl());
                    ((Framedata)this.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI();
                    try {
                        ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, IlllllIIlIIIllIllllIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl()));
                    }
                    catch (RuntimeException ex) {
                        ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, ex);
                    }
                }
                else if (this.IlllIllIlIIIIlIIlIIllIIIl.IlllIllIlIIIIlIIlIIllIIIl() == DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI) {
                    ((Framedata)this.IlllIllIlIIIIlIIlIIllIIIl).lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl());
                    ((Framedata)this.IlllIllIlIIIIlIIlIIllIIIl).IlllIIIlIlllIllIlIIlllIlI();
                    try {
                        ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
                    }
                    catch (RuntimeException ex2) {
                        ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, ex2);
                    }
                }
                this.IlllIllIlIIIIlIIlIIllIIIl = null;
                this.IlIlllIIIIllIllllIllIIlIl.clear();
            }
            else if (this.IlllIllIlIIIIlIIlIIllIIIl == null) {
                throw new lIlllllIllllIIlIIIlllllll(1002, "Continuous frame sequence was not started.");
            }
            if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl && !IlllllIIlIIIllIllllIlIlIl.lIIIIIIIIIlIllIIllIlIIlIl(illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl())) {
                throw new lIlllllIllllIIlIIIlllllll(1007);
            }
            if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.lIIIIlIIllIIlIIlIIIlIIllI && this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                this.IlIlllIIIIllIllllIllIIlIl.add(illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
            }
        }
        else {
            if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
                throw new lIlllllIllllIIlIIIlllllll(1002, "Continuous frame sequence not completed.");
            }
            if (illlIllIlIIIIlIIlIIllIIIl2 == DELETE_ME_E.lIIIIIIIIIlIllIIllIlIIlIl) {
                try {
                    ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, IlllllIIlIIIllIllllIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl()));
                }
                catch (RuntimeException ex3) {
                    ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, ex3);
                }
            }
            else {
                if (illlIllIlIIIIlIIlIIllIIIl2 != DELETE_ME_E.IlllIIIlIlllIllIlIIlllIlI) {
                    throw new lIlllllIllllIIlIIIlllllll(1002, "non control or continious frame expected");
                }
                try {
                    ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, illlIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
                }
                catch (RuntimeException ex4) {
                    ilIIlIllIlIIlllllIllIlIlI.IIIIIIlIlIlIllllllIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIllIlIIlllllIllIlIlI, ex4);
                }
            }
        }
    }
    
    @Override
    public IIIIIIIIIIIIIIlllIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl() {
        return IIIIIIIIIIIIIIlllIlIlIlll.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public String toString() {
        String s = super.toString();
        if (this.IIIIllIIllIIIIllIllIIIlIl() != null) {
            s = s + " extension: " + this.IIIIllIIllIIIIllIllIIIlIl().toString();
        }
        if (this.IIIllIllIlIlllllllIlIlIII() != null) {
            s = s + " protocol: " + this.IIIllIllIlIlllllllIlIlIII().toString();
        }
        return s;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final IIIIIlIllllllIIIIIIIlIlll iiiiIlIllllllIIIIIIIlIlll = (IIIIIlIllllllIIIIIIIlIlll)o;
        if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            if (this.IlIlIIIlllIIIlIlllIlIllIl.equals(iiiiIlIllllllIIIIIIIlIlll.IlIlIIIlllIIIlIlllIlIllIl)) {
                return (this.IllIIIIIIIlIlIllllIIllIII != null) ? this.IllIIIIIIIlIlIllllIIllIII.equals(iiiiIlIllllllIIIIIIIlIlll.IllIIIIIIIlIlIllllIIllIII) : (iiiiIlIllllllIIIIIIIlIlll.IllIIIIIIIlIlIllllIIllIII == null);
            }
        }
        else if (iiiiIlIllllllIIIIIIIlIlll.IlIlIIIlllIIIlIlllIlIllIl == null) {
            return (this.IllIIIIIIIlIlIllllIIllIII != null) ? this.IllIIIIIIIlIlIllllIIllIII.equals(iiiiIlIllllllIIIIIIIlIlll.IllIIIIIIIlIlIllllIIllIII) : (iiiiIlIllllllIIIIIIIlIlll.IllIIIIIIIlIlIllllIIllIII == null);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return 31 * ((this.IlIlIIIlllIIIlIlllIlIllIl != null) ? this.IlIlIIIlllIIIlIlllIlIllIl.hashCode() : 0) + ((this.IllIIIIIIIlIlIllllIIllIII != null) ? this.IllIIIIIIIlIlIllllIIllIII.hashCode() : 0);
    }
    
    private ByteBuffer IlllIllIlIIIIlIIlIIllIIIl() {
        long n = 0L;
        final Iterator<ByteBuffer> iterator = this.IlIlllIIIIllIllllIllIIlIl.iterator();
        while (iterator.hasNext()) {
            n += iterator.next().limit();
        }
        if (n > 2147483647L) {
            throw new IllIlllIlllIIllllIlIlIIIl("Payloadsize is to big...");
        }
        final ByteBuffer allocate = ByteBuffer.allocate((int)n);
        final Iterator<ByteBuffer> iterator2 = this.IlIlllIIIIllIllllIllIIlIl.iterator();
        while (iterator2.hasNext()) {
            allocate.put(iterator2.next());
        }
        allocate.flip();
        return allocate;
    }
    
    static {
        IIIIllIIllIIIIllIllIIIlIl = !IIIIIlIllllllIIIIIIIlIlll.class.desiredAssertionStatus();
    }
}
