// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIIIIlllllIlIllIlIIl
{
    private IlllIIIllIlIIlIllIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI;
    private double lIIIIIIIIIlIllIIllIlIIlIl;
    private double IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private double IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIIIIIIIIlllllIlIllIlIIl(final IlllIIIllIlIIlIllIIlIlllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll;
        this.IlllIIIlIlllIllIlIIlllIlI = liiiIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI;
        this.IIIIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public double lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double liiiiiiiiIlIllIIllIlIIlIl, final double illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl, final double iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = true;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IllIIIIIIIlIlIllllIIllIII(0.0f);
        if (this.IlIlIIIlllIIIlIlllIlIllIl) {
            this.IlIlIIIlllIIIlIlllIlIllIl = false;
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 0.6142857362542842 * 0.8139534592628479);
            final double x = this.lIIIIIIIIIlIllIIllIlIIlIl - this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll;
            final double y = this.IIIIllIlIIIllIlllIlllllIl - this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll;
            final double n = this.IlllIIIlIlllIllIlIIlllIlI - illlIIIlIlllIllIlIIlllIlI;
            if (x * x + n * n + y * y >= 1.9117649452098763E-7 * 1.307692289352417) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll = this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll, (float)(Math.atan2(y, x) * 180 / (2.75 * 1.1423973285781066)) - 90, 30);
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIllIIlIlIllIIIlIllIlI((float)(this.IIIIllIIllIIIIllIllIIIlIl * this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).IIIIllIIllIIIIllIllIIIlIl()));
                if (n > 0.0 && x * x + y * y < 1.0) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll().lIIIIlIIllIIlIIlIIIlIIllI();
                }
            }
        }
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3) {
        float iiIllIllIlIlllllllIlIlIII = MathHelper.IIIllIllIlIlllllllIlIlIII(n2 - n);
        if (iiIllIllIlIlllllllIlIlIII > n3) {
            iiIllIllIlIlllllllIlIlIII = n3;
        }
        if (iiIllIllIlIlllllllIlIlIII < -n3) {
            iiIllIllIlIlllllllIlIlIII = -n3;
        }
        return n + iiIllIllIlIlllllllIlIlIII;
    }
}
