import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIllIIlllllIIIIlIlll implements Comparator
{
    @Override
    public int compare(final Object o, final Object o2) {
        final llllIllllIlIlIIIlllIllIIl llllIllllIlIlIIIlllIllIIl = (llllIllllIlIlIIIlllIllIIl)o;
        final llllIllllIlIlIIIlllIllIIl llllIllllIlIlIIIlllIllIIl2 = (llllIllllIlIlIIIlllIllIIl)o2;
        return (llllIllllIlIlIIIlllIllIIl.IIIIIIlIlIlIllllllIlllIlI != llllIllllIlIlIIIlllIllIIl2.IIIIIIlIlIlIllllllIlllIlI) ? (llllIllllIlIlIIIlllIllIIl2.IIIIIIlIlIlIllllllIlllIlI - llllIllllIlIlIIIlllIllIIl.IIIIIIlIlIlIllllllIlllIlI) : (lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(llllIllllIlIlIIIlllIllIIl.lIIIIIIIIIlIllIIllIlIIlIl, (Object)llllIllllIlIlIIIlllIllIIl2.lIIIIIIIIIlIllIIllIlIIlIl) ? llllIllllIlIlIIIlllIllIIl.lIIIIlIIllIIlIIlIIIlIIllI.compareTo(llllIllllIlIlIIIlllIllIIl2.lIIIIlIIllIIlIIlIIIlIIllI) : llllIllllIlIlIIIlllIllIIl.lIIIIIIIIIlIllIIllIlIIlIl.compareTo(llllIllllIlIlIIIlllIllIIl2.lIIIIIIIIIlIllIIllIlIIlIl));
    }
}
