import java.util.HashSet;
import java.util.Set;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllllIIIIIlllllllllII
{
    private transient lllIllllllIIlIIllllIIllIl[] lIIIIlIIllIIlIIlIIIlIIllI;
    private transient int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private final float IIIIllIlIIIllIlllIlllllIl = 0.75f;
    private transient volatile int IIIIllIIllIIIIllIllIIIlIl;
    private Set IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIlIIllllIIIIIlllllllllII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new lllIllllllIIlIIllllIIllIl[16];
        this.IlllIIIlIlllIllIlIIlllIlI = 12;
        this.IlIlIIIlllIIIlIlllIlIllIl = new HashSet();
    }
    
    private static int IIIllIllIlIlllllllIlIlIII(int n) {
        n ^= (n >>> 20 ^ n >>> 12);
        return n ^ n >>> 7 ^ n >>> 4;
    }
    
    private static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return n & n2 - 1;
    }
    
    public Object lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        for (lllIllllllIIlIIllllIIllIl illlIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[lIIIIlIIllIIlIIlIIIlIIllI(IIIllIllIlIlllllllIlIlIII(n), this.lIIIIlIIllIIlIIlIIIlIIllI.length)]; illlIIIlIlllIllIlIIlllIlI != null; illlIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI) {
            if (illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI == n) {
                return illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            }
        }
        return null;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return this.IlllIIIlIlllIllIlIIlllIlI(n) != null;
    }
    
    final lllIllllllIIlIIllllIIllIl IlllIIIlIlllIllIlIIlllIlI(final int n) {
        for (lllIllllllIIlIIllllIIllIl illlIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[lIIIIlIIllIIlIIlIIIlIIllI(IIIllIllIlIlllllllIlIlIII(n), this.lIIIIlIIllIIlIIlIIIlIIllI.length)]; illlIIIlIlllIllIlIIlllIlI != null; illlIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI) {
            if (illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI == n) {
                return illlIIIlIlllIllIlIIlllIlI;
            }
        }
        return null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int i, final Object liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl.add(i);
        final int iiIllIllIlIlllllllIlIlIII = IIIllIllIlIlllllllIlIlIII(i);
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII, this.lIIIIlIIllIIlIIlIIIlIIllI.length);
        for (lllIllllllIIlIIllllIIllIl illlIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI]; illlIIIlIlllIllIlIIlllIlI != null; illlIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI) {
            if (illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI == i) {
                illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                return;
            }
        }
        ++this.IIIIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiIllIllIlIlllllllIlIlIII, i, liiiiiiiiIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI);
    }
    
    private void IllIIIIIIIlIlIllllIIllIII(final int n) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.length == 1073741824) {
            this.IlllIIIlIlllIllIlIIlllIlI = Integer.MAX_VALUE;
        }
        else {
            final lllIllllllIIlIIllllIIllIl[] liiiIlIIllIIlIIlIIIlIIllI = new lllIllllllIIlIIllllIIllIl[n];
            this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
            final float n2 = (float)n;
            this.getClass();
            this.IlllIIIlIlllIllIlIIlllIlI = (int)(n2 * (1.25f * 0.6f));
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final lllIllllllIIlIIllllIIllIl[] array) {
        final lllIllllllIIlIIllllIIllIl[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        final int length = array.length;
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.length; ++i) {
            lllIllllllIIlIIllllIIllIl lllIllllllIIlIIllllIIllIl = liiiIlIIllIIlIIlIIIlIIllI[i];
            if (lllIllllllIIlIIllllIIllIl != null) {
                liiiIlIIllIIlIIlIIIlIIllI[i] = null;
                lllIllllllIIlIIllllIIllIl illlIIIlIlllIllIlIIlllIlI;
                do {
                    illlIIIlIlllIllIlIIlllIlI = lllIllllllIIlIIllllIIllIl.IlllIIIlIlllIllIlIIlllIlI;
                    final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIIIlIIllIIlIIlIIIlIIllI(lllIllllllIIlIIllllIIllIl.IIIIllIlIIIllIlllIlllllIl, length);
                    lllIllllllIIlIIllllIIllIl.IlllIIIlIlllIllIlIIlllIlI = array[liiiIlIIllIIlIIlIIIlIIllI2];
                    array[liiiIlIIllIIlIIlIIIlIIllI2] = lllIllllllIIlIIllllIIllIl;
                } while ((lllIllllllIIlIIllllIIllIl = illlIIIlIlllIllIlIIlllIlI) != null);
            }
        }
    }
    
    public Object IIIIllIlIIIllIlllIlllllIl(final int i) {
        this.IlIlIIIlllIIIlIlllIlIllIl.remove(i);
        final lllIllllllIIlIIllllIIllIl iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(i);
        return (iiiIllIIllIIIIllIllIIIlIl == null) ? null : iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    final lllIllllllIIlIIllllIIllIl IIIIllIIllIIIIllIllIIIlIl(final int n) {
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(IIIllIllIlIlllllllIlIlIII(n), this.lIIIIlIIllIIlIIlIIIlIIllI.length);
        lllIllllllIIlIIllllIIllIl lllIllllllIIlIIllllIIllIl2;
        lllIllllllIIlIIllllIIllIl illlIIIlIlllIllIlIIlllIlI;
        for (lllIllllllIIlIIllllIIllIl lllIllllllIIlIIllllIIllIl = lllIllllllIIlIIllllIIllIl2 = this.lIIIIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI]; lllIllllllIIlIIllllIIllIl2 != null; lllIllllllIIlIIllllIIllIl2 = illlIIIlIlllIllIlIIlllIlI) {
            illlIIIlIlllIllIlIIlllIlI = lllIllllllIIlIIllllIIllIl2.IlllIIIlIlllIllIlIIlllIlI;
            if (lllIllllllIIlIIllllIIllIl2.lIIIIlIIllIIlIIlIIIlIIllI == n) {
                ++this.IIIIllIIllIIIIllIllIIIlIl;
                --this.lIIIIIIIIIlIllIIllIlIIlIl;
                if (lllIllllllIIlIIllllIIllIl == lllIllllllIIlIIllllIIllIl2) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI[liiiIlIIllIIlIIlIIIlIIllI] = illlIIIlIlllIllIlIIlllIlI;
                }
                else {
                    lllIllllllIIlIIllllIIllIl.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
                }
                return lllIllllllIIlIIllllIIllIl2;
            }
            lllIllllllIIlIIllllIIllIl = lllIllllllIIlIIllllIIllIl2;
        }
        return lllIllllllIIlIIllllIIllIl2;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        ++this.IIIIllIIllIIIIllIllIIIlIl;
        final lllIllllllIIlIIllllIIllIl[] liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI;
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.length; ++i) {
            liiiIlIIllIIlIIlIIIlIIllI[i] = null;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = 0;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final Object o, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI[n3] = new lllIllllllIIlIIllllIIllIl(n, n2, o, this.lIIIIlIIllIIlIIlIIIlIIllI[n3]);
        if (this.lIIIIIIIIIlIllIIllIlIIlIl++ >= this.IlllIIIlIlllIllIlIIlllIlI) {
            this.IllIIIIIIIlIlIllllIIllIII(2 * this.lIIIIlIIllIIlIIlIIIlIIllI.length);
        }
    }
}
