import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlllllllIIlIlIIlIll extends IIllIIlIllIllIllIIIIIlIII
{
    protected IIIlIIIlllllllIIlIlIIlIll() {
        final float n = 1.025f * 0.4878049f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.82978725f * 0.6025641f - n, 0.0f, 1.6363636f * 0.30555555f - n, 0.39130434f * 1.2777778f + n, 0.11830357f * 0.13207547f, 0.3043478f * 1.6428572f + n);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 23;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final List list, final Entity entity) {
        if (entity == null || !(entity instanceof IIlllIlIlIIIlIIIlIlIlIIIl)) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, ilIllIIlIlIllIlIllllllllI, list, entity);
        }
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + this.lIllIlIlllIIlIIllIIlIIlII, n2 + this.IIIlIIlIlIIIlllIIlIllllll, n3 + this.IllIlIIIIlllIIllIIlllIIlI, n + this.IllIlIlIllllIlIIllllIIlll, n2 + this.IllIIlIIlllllIllIIIlllIII, n3 + this.lIlIlIllIIIIIIIIllllIIllI);
    }
    
    @Override
    public int lIllIllIlIIllIllIlIlIIlIl() {
        return 2129968;
    }
    
    @Override
    public int IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        return 2129968;
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return 2129968;
    }
    
    @Override
    protected boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl;
    }
    
    @Override
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return n2 >= 0 && n2 < 256 && (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3).IlIlIIIlllIIIlIlllIlIllIl() == Material.IllIIIIIIIlIlIllllIIllIII && iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2 - 1, n3) == 0);
    }
}
