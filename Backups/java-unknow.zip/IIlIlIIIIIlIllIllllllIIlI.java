import java.security.GeneralSecurityException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import javax.crypto.Cipher;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;
import java.security.PublicKey;
import java.security.KeyPairGenerator;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIIIlIllIllllllIIlI
{
    public static SecretKey lIIIIlIIllIIlIIlIIIlIIllI() {
        try {
            final KeyGenerator instance = KeyGenerator.getInstance("AES");
            instance.init(128);
            return instance.generateKey();
        }
        catch (NoSuchAlgorithmException cause) {
            throw new Error(cause);
        }
    }
    
    public static KeyPair lIIIIIIIIIlIllIIllIlIIlIl() {
        try {
            final KeyPairGenerator instance = KeyPairGenerator.getInstance("RSA");
            instance.initialize(1024);
            return instance.generateKeyPair();
        }
        catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
            System.err.println("Key pair generation failed!");
            return null;
        }
    }
    
    public static byte[] lIIIIlIIllIIlIIlIIIlIIllI(final String s, final PublicKey publicKey, final SecretKey secretKey) {
        try {
            return lIIIIlIIllIIlIIlIIIlIIllI("SHA-1", new byte[][] { s.getBytes("ISO_8859_1"), secretKey.getEncoded(), publicKey.getEncoded() });
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    private static byte[] lIIIIlIIllIIlIIlIIIlIIllI(final String algorithm, final byte[]... array) {
        try {
            final MessageDigest instance = MessageDigest.getInstance(algorithm);
            for (int length = array.length, i = 0; i < length; ++i) {
                instance.update(array[i]);
            }
            return instance.digest();
        }
        catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static PublicKey lIIIIlIIllIIlIIlIIIlIIllI(final byte[] encodedKey) {
        try {
            return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(encodedKey));
        }
        catch (NoSuchAlgorithmException ex) {}
        catch (InvalidKeySpecException ex2) {}
        System.err.println("Public key reconstitute failed!");
        return null;
    }
    
    public static SecretKey lIIIIlIIllIIlIIlIIIlIIllI(final PrivateKey privateKey, final byte[] array) {
        return new SecretKeySpec(lIIIIIIIIIlIllIIllIlIIlIl(privateKey, array), "AES");
    }
    
    public static byte[] lIIIIlIIllIIlIIlIIIlIIllI(final Key key, final byte[] array) {
        return lIIIIlIIllIIlIIlIIIlIIllI(1, key, array);
    }
    
    public static byte[] lIIIIIIIIIlIllIIllIlIIlIl(final Key key, final byte[] array) {
        return lIIIIlIIllIIlIIlIIIlIIllI(2, key, array);
    }
    
    private static byte[] lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Key key, final byte[] input) {
        try {
            return lIIIIlIIllIIlIIlIIIlIIllI(n, key.getAlgorithm(), key).doFinal(input);
        }
        catch (IllegalBlockSizeException ex) {
            ex.printStackTrace();
        }
        catch (BadPaddingException ex2) {
            ex2.printStackTrace();
        }
        System.err.println("Cipher data failed!");
        return null;
    }
    
    private static Cipher lIIIIlIIllIIlIIlIIIlIIllI(final int opmode, final String transformation, final Key key) {
        try {
            final Cipher instance = Cipher.getInstance(transformation);
            instance.init(opmode, key);
            return instance;
        }
        catch (InvalidKeyException ex) {
            ex.printStackTrace();
        }
        catch (NoSuchAlgorithmException ex2) {
            ex2.printStackTrace();
        }
        catch (NoSuchPaddingException ex3) {
            ex3.printStackTrace();
        }
        System.err.println("Cipher creation failed!");
        return null;
    }
    
    public static Cipher lIIIIlIIllIIlIIlIIIlIIllI(final int opmode, final Key key) {
        try {
            final Cipher instance = Cipher.getInstance("AES/CFB8/NoPadding");
            instance.init(opmode, key, new IvParameterSpec(key.getEncoded()));
            return instance;
        }
        catch (GeneralSecurityException cause) {
            throw new RuntimeException(cause);
        }
    }
}
