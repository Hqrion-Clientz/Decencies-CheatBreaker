import org.apache.commons.lang3.StringUtils;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllIlIIlIlIIIlIlIlIll extends IIllIlllIIlllllIlllIIIlIl
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIlIllIlIIlIlIIIlIlIlIll() {
    }
    
    public IIIlIllIlIIlIlIIIlIlIlIll(final String liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32767);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(StringUtils.substring(this.lIIIIlIIllIIlIIlIIIlIIllI, 0, 32767));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIllllIllIllIlIlIllIlllIl illllIllIllIlIlIllIlllIl) {
        illllIllIllIlIlIllIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return String.format("message='%s'", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIllllIllIllIlIlIllIlllIl)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
