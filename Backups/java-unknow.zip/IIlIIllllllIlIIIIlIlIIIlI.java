// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllllllIlIIIIlIlIIIlI implements IllIllllllIlllIIIlllIIlII
{
    private final Minecraft lIIIIlIIllIIlIIlIIIlIIllI;
    private final lIIlIIIIlIIIIIllIIIIlIIll lIIIIIIIIIlIllIIllIlIIlIl;
    private final lIIlIIIIlIIIIIllIIIIlIIll IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIllllllIlIIIIlIlIIIlI(final lIIlIIIIlIIIIIllIIIIlIIll liiiiiiiiIlIllIIllIlIIlIl, final lIIlIIIIlIIIIIllIIIIlIIll illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Minecraft.getMinecraft();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final Tessellator tessellator, final int n6, final int n7, final boolean b) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII = n3;
            this.lIIIIIIIIIlIllIIllIlIIlIl.setWorldAndResolution(this.lIIIIlIIllIIlIIlIIIlIIllI, n6, n7);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            this.IlllIIIlIlllIllIlIIlllIlI.IIIllIllIlIlllllllIlIlIII = n3;
            this.IlllIIIlIlllIllIlIIlllIlI.setWorldAndResolution(this.lIIIIlIIllIIlIIlIIIlIIllI, n6, n7);
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI, n2, n3)) {
            if (this.lIIIIIIIIIlIllIIllIlIIlIl instanceof llIllIlIlIIIllllIlIlIlIIl) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI(((llIllIlIlIIIllllIlIlIlIIl)this.lIIIIIIIIIlIllIIllIlIIlIl).lIIIIlIIllIIlIIlIIIlIIllI(), 1);
                this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.gameSettings.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIllIIlIlIllIIIlIllIlI));
            }
            return true;
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI != null && this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI, n2, n3)) {
            if (this.IlllIIIlIlllIllIlIIlllIlI instanceof llIllIlIlIIIllllIlIlIlIIl) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.gameSettings.lIIIIlIIllIIlIIlIIIlIIllI(((llIllIlIlIIIllllIlIlIlIIl)this.IlllIIIlIlllIllIlIIlllIlI).lIIIIlIIllIIlIIlIIIlIIllI(), 1);
                this.IlllIIIlIlllIllIlIIlllIlI.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.gameSettings.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI.lIIIIllIIlIlIllIIIlIllIlI));
            }
            return true;
        }
        return false;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.resize(n2, n3);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            this.IlllIIIlIlllIllIlIIlllIlI.resize(n2, n3);
        }
    }
}
