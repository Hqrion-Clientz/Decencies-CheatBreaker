import java.util.Iterator;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIIlllllIIllIllIlllIllI
{
    private final IIIlIIIIlIllIlIllIlllIlll lIIIIIIIIIlIllIIllIlIIlIl;
    private final DynamicTexture IlllIIIlIlllIllIlIIlllIlI;
    private final ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private final int[] IIIIllIIllIIIIllIllIIIlIl;
    final /* synthetic */ lIlIlIlIIlIIIIIlIllIlIlII lIIIIlIIllIIlIIlIIIlIIllI;
    
    private IIlIIlllllIIllIllIlllIllI(final lIlIlIlIIlIIIIIlIllIlIlII liiiIlIIllIIlIIlIIIlIIllI, final IIIlIIIIlIllIlIllIlllIlll liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = new DynamicTexture(128, 128);
        this.IIIIllIIllIIIIllIllIIIlIl = this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl();
        this.IIIIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl.getDynamicTextureLocation("map/" + liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IlllIIIlIlllIllIlIIlllIlI);
        for (int i = 0; i < this.IIIIllIIllIIIIllIllIIIlIl.length; ++i) {
            this.IIIIllIIllIIIIllIllIIIlIl[i] = 0;
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI() {
        for (int i = 0; i < 16384; ++i) {
            final int n = this.lIIIIIIIIIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl[i] & 0xFF;
            if (n / 4 == 0) {
                this.IIIIllIIllIIIIllIllIIIlIl[i] = (i + i / 128 & 0x1) * 8 + 16 << 24;
            }
            else {
                this.IIIIllIIllIIIIllIllIIIlIl[i] = llIllllIlIlIlllIllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI[n / 4].lIIIIIIIIIlIllIIllIlIIlIl(n & 0x3);
            }
        }
        this.IlllIIIlIlllIllIlIIlllIlI.tick();
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        final int n = 0;
        final int n2 = 0;
        final Tessellator instance = Tessellator.instance;
        final float n3 = 0.0f;
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl.bindTexture(this.IIIIllIlIIIllIlllIlllllIl);
        GL11.glEnable(3042);
        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(1, 771, 0, 1);
        GL11.glDisable(3008);
        instance.startDrawingQuads();
        instance.addVertexWithUV(n + 0 + n3, n2 + 128 - n3, -0.008367346385334864 * 1.1951220035552979, 0.0, 1.0);
        instance.addVertexWithUV(n + 128 - n3, n2 + 128 - n3, -0.10555555074947127 * 0.09473684430122375, 1.0, 1.0);
        instance.addVertexWithUV(n + 128 - n3, n2 + 0 + n3, -0.013802816361141602 * 0.7244898080825806, 1.0, 0.0);
        instance.addVertexWithUV(n + 0 + n3, n2 + 0 + n3, 1.3600000143051147 * -0.0073529409347778815, 0.0, 0.0);
        instance.draw();
        GL11.glEnable(3008);
        GL11.glDisable(3042);
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl.bindTexture(lIlIlIlIIlIIIIIlIllIlIlII.lIIIIlIIllIIlIIlIIIlIIllI);
        int n4 = 0;
        for (final IIIlIlIllIIIlIlIIllllIlIl iiIlIlIllIIIlIlIIllllIlIl : this.lIIIIIIIIIlIllIIllIlIIlIl.IllIIIIIIIlIlIllllIIllIII.values()) {
            if (!b || iiIlIlIllIIIlIlIIllllIlIl.lIIIIlIIllIIlIIlIIIlIIllI == 1) {
                GL11.glPushMatrix();
                GL11.glTranslatef(n + iiIlIlIllIIIlIlIIllllIlIl.lIIIIIIIIIlIllIIllIlIIlIl / 2.0f + 64, n2 + iiIlIlIllIIIlIlIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI / 2.0f + 64, -0.025714284f * 0.7777778f);
                GL11.glRotatef(iiIlIlIllIIIlIlIIllllIlIl.IIIIllIlIIIllIlllIlllllIl * 360 / (float)16, 0.0f, 0.0f, 1.0f);
                GL11.glScalef((float)4, (float)4, (float)3);
                GL11.glTranslatef(0.88297874f * -0.14156626f, 9.4f * 0.013297873f, 0.0f);
                final float n5 = (iiIlIlIllIIIlIlIIllllIlIl.lIIIIlIIllIIlIIlIIIlIIllI % 4 + 0) / (float)4;
                final float n6 = (iiIlIlIllIIIlIlIIllllIlIl.lIIIIlIIllIIlIIlIIIlIIllI / 4 + 0) / (float)4;
                final float n7 = (iiIlIlIllIIIlIlIIllllIlIl.lIIIIlIIllIIlIIlIIIlIIllI % 4 + 1) / (float)4;
                final float n8 = (iiIlIlIllIIIlIlIIllllIlIl.lIIIIlIIllIIlIIlIIIlIIllI / 4 + 1) / (float)4;
                instance.startDrawingQuads();
                instance.addVertexWithUV(-1, 1.0, n4 * (7.68116E-4f * 1.3018868f), n5, n6);
                instance.addVertexWithUV(1.0, 1.0, n4 * (3.9393944E-4f * 2.5384614f), n7, n6);
                instance.addVertexWithUV(1.0, -1, n4 * (0.08219178f * 0.012166668f), n7, n8);
                instance.addVertexWithUV(-1, -1, n4 * (0.0018500001f * 0.5405405f), n5, n8);
                instance.draw();
                GL11.glPopMatrix();
                ++n4;
            }
        }
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, 0.0f, -0.055428572f * 0.72164947f);
        GL11.glScalef(1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    IIlIIlllllIIllIllIlllIllI(final lIlIlIlIIlIIIIIlIllIlIlII lIlIlIlIIlIIIIIlIllIlIlII, final IIIlIIIIlIllIlIllIlllIlll iiIlIIIIlIllIlIllIlllIlll, final Object o) {
        this(lIlIlIlIIlIIIIIlIllIlIlII, iiIlIIIIlIllIlIllIlllIlll);
    }
}
