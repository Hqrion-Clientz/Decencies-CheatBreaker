// 
// Decompiled by Procyon v0.5.36
// 

public enum EnumMinimapOptions
{
    lIIIIlIIllIIlIIlIIIlIIllI("COORDS", 0, "options.minimap.showcoordinates", false, true, false), 
    lIIIIIIIIIlIllIIllIlIIlIl("HIDE", 1, "options.minimap.hideminimap", false, true, false), 
    IlllIIIlIlllIllIlIIlllIlI("CAVEMODE", 2, "options.minimap.cavemode", false, true, false), 
    IIIIllIlIIIllIlllIlllllIl("LIGHTING", 3, "options.minimap.dynamiclighting", false, true, false), 
    IIIIllIIllIIIIllIllIIIlIl("TERRAIN", 4, "options.minimap.terraindepth", false, false, true), 
    IlIlIIIlllIIIlIlllIlIllIl("SQUARE", 5, "options.minimap.squaremap", false, true, false), 
    IIIllIllIlIlllllllIlIlIII("OLDNORTH", 6, "options.minimap.oldnorth", false, true, false), 
    IllIIIIIIIlIlIllllIIllIII("BEACONS", 7, "options.minimap.ingamewaypoints", false, false, true), 
    lIIIIllIIlIlIllIIIlIllIlI("WELCOME", 8, "Welcome Screen", false, true, false), 
    IlllIllIlIIIIlIIlIIllIIIl("ZOOM", 9, "option.minimapZoom", false, true, false), 
    IlIlllIIIIllIllllIllIIlIl("LOCATION", 10, "options.minimap.location", false, false, true), 
    llIIlllIIIIlllIllIlIlllIl("SIZE", 11, "options.minimap.size", false, false, true), 
    lIIlIlIllIIlIIIlIIIlllIII("FILTERING", 12, "options.minimap.filtering", false, true, false), 
    IIIlllIIIllIllIlIIIIIIlII("WATERTRANSPARENCY", 13, "options.minimap.watertransparency", false, true, false), 
    llIlIIIlIIIIlIlllIlIIIIll("BLOCKTRANSPARENCY", 14, "options.minimap.blocktransparency", false, true, false), 
    IIIlIIllllIIllllllIlIIIll("BIOMES", 15, "options.minimap.biomes", false, true, false), 
    lllIIIIIlIllIlIIIllllllII("BIOMEOVERLAY", 16, "options.minimap.biomeoverlay", false, false, true), 
    lIIIIIllllIIIIlIlIIIIlIlI("CHUNKGRID", 17, "options.minimap.chunkgrid", false, true, false), 
    IIIIIIlIlIlIllllllIlllIlI("SHOWRADAR", 18, "options.minimap.radar.showradar", false, true, false), 
    IllIllIIIlIIlllIIIllIllII("SHOWHOSTILES", 19, "options.minimap.radar.showhostiles", false, true, false), 
    IlIIlIIIIlIIIIllllIIlIllI("SHOWPLAYERS", 20, "options.minimap.radar.showplayers", false, true, false), 
    lIIlIIllIIIIIlIllIIIIllII("SHOWNEUTRALS", 21, "options.minimap.radar.showneutrals", false, true, false), 
    lIIlllIIlIlllllllllIIIIIl("SHOWPLAYERHELMETS", 22, "options.minimap.radar.showplayerhelmets", false, true, false), 
    lIllIllIlIIllIllIlIlIIlIl("SHOWMOBHELMETS", 23, "options.minimap.radar.showmobhelmets", false, true, false), 
    llIlIIIllIIIIlllIlIIIIIlI("SHOWPLAYERNAMES", 24, "options.minimap.radar.showplayernames", false, true, false), 
    lIllIlIlllIIlIIllIIlIIlII("RADAROUTLINES", 25, "options.minimap.radar.iconoutlines", false, true, false), 
    IIIlIIlIlIIIlllIIlIllllll("RADARFILTERING", 26, "options.minimap.radar.iconfiltering", false, true, false), 
    IllIlIIIIlllIIllIIlllIIlI("RANDOMOBS", 27, "options.minimap.radar.randomobs", false, true, false), 
    IllIlIlIllllIlIIllllIIlll("WAYPOINTDISTANCE", 28, "options.minimap.waypoints.distance", true, false, false), 
    IllIIlIIlllllIllIIIlllIII("DEATHPOINTS", 29, "options.minimap.waypoints.deathpoints", false, false, true);
    
    private final boolean lIlIlIllIIIIIIIIllllIIllI;
    private final boolean IlllIIlllIIIIllIIllllIlIl;
    private final boolean IllllIllllIlIIIlIIIllllll;
    private final String IllIIlllIllIlIllIlIIIIIII;
    
    public static EnumMinimapOptions lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        for (final EnumMinimapOptions enumMinimapOptions : values()) {
            if (enumMinimapOptions.IIIIllIlIIIllIlllIlllllIl() == n) {
                return enumMinimapOptions;
            }
        }
        return null;
    }
    
    private EnumMinimapOptions(final String name, final int ordinal, final String illIIlllIllIlIllIlIIIIIII, final boolean lIlIlIllIIIIIIIIllllIIllI, final boolean illlIIlllIIIIllIIllllIlIl, final boolean illllIllllIlIIIlIIIllllll) {
        this.IllIIlllIllIlIllIlIIIIIII = illIIlllIllIlIllIlIIIIIII;
        this.lIlIlIllIIIIIIIIllllIIllI = lIlIlIllIIIIIIIIllllIIllI;
        this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
        this.IllllIllllIlIIIlIIIllllll = illllIllllIlIIIlIIIllllll;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIlIlIllIIIIIIIIllllIIllI;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIlllIIIIllIIllllIlIl;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.IllllIllllIlIIIlIIIllllll;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.ordinal();
    }
    
    public String IIIIllIIllIIIIllIllIIIlIl() {
        return this.IllIIlllIllIlIllIlIIIIIII;
    }
}
