import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIlIIIIIIIIllIIllIIl extends IlIllIIlIIllllllIIlIllIlI
{
    private final lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private float lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIlIlIIIIIIIIllIIllIIl(final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI, final int n) {
        super(n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        final lIlIlIlIlIllllIlllIIIlIlI llIIlllIIIIlllIllIlIlllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
        if (this.lIIIIIIIIIlIllIIllIlIIlIl > 0.0f) {
            final int bound = (int)(this.lIIIIIIIIIlIllIIllIlIIlIl * this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIllIllllIllIIlIl());
            int n = llIIlllIIIIlllIllIlIlllIl.IlIlllIIIIllIllllIllIIlIl() - random.nextInt(random.nextInt(bound) + 1);
            if (n > bound) {
                n = bound;
            }
            if (n < 1) {
                n = 1;
            }
            llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl(n);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI) {
            lIIlllIlIllIIIIIlIlllIIII.lIIIIlIIllIIlIIlIIIlIIllI(random, llIIlllIIIIlllIllIlIlllIl, 30);
        }
        return llIIlllIIIIlllIllIlIlllIl;
    }
    
    public IIIlIlIlIIIIIIIIllIIllIIl lIIIIlIIllIIlIIlIIIlIIllI(final float liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        return this;
    }
    
    public IIIlIlIlIIIIIIIIllIIllIIl lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IlllIIIlIlllIllIlIIlllIlI = true;
        return this;
    }
}
