import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIlIIlIIlllIllIlIIl
{
    private List lIIIIlIIllIIlIIlIIIlIIllI;
    private IIIIllIllllIIlIlIIIIlllIl lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIIIIlIIlIIlllIllIlIIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (n > 0 && n <= 16384) {
            if (this.lIIIIIIIIIlIllIIllIlIIlIl == null || !this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n)) {
                if (this.IlllIIIlIlllIllIlIIlllIlI + 1 < this.lIIIIlIIllIIlIIlIIIlIIllI.size()) {
                    ++this.IlllIIIlIlllIllIlIIlllIlI;
                    this.lIIIIIIIIIlIllIIllIlIIlIl = this.lIIIIlIIllIIlIIlIIIlIIllI.get(this.IlllIIIlIlllIllIlIIlllIlI);
                }
                else {
                    this.lIIIIIIIIIlIllIIllIlIIlIl = new IIIIllIllllIIlIlIIIIlllIl();
                    this.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.size();
                    this.lIIIIlIIllIIlIIlIIIlIIllI.add(this.lIIIIIIIIIlIllIIllIlIIlIl);
                }
                if (!this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n)) {
                    throw new IllegalArgumentException("Can not allocate: " + n);
                }
            }
            return this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(n);
        }
        throw new IllegalArgumentException("Invalid display list length: " + n);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
        for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
            ((IIIIllIllllIIlIlIIIIlllIl)this.lIIIIlIIllIIlIIlIIIlIIllI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI();
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
            ((IIIIllIllllIIlIlIIIIlllIl)this.lIIIIlIIllIIlIIlIIIlIIllI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl();
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IlllIIIlIlllIllIlIIlllIlI = -1;
    }
}
