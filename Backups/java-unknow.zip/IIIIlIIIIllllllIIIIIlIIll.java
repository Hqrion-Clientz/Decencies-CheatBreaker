import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlIIIIllllllIIIIIlIIll implements Callable
{
    final /* synthetic */ IllIlIlllIIIIIIlIIllIIIll lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIIIlIIIIllllllIIIIIlIIll(final IllIlIlllIIIIIIlIIllIIIll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "";
    }
}
