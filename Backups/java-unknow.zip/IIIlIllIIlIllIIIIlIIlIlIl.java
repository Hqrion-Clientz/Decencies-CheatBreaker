import java.util.concurrent.Callable;
import org.lwjgl.opengl.GL11;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIllIIlIllIIIIlIIlIlIl extends lIIlIllIIIlllllIllIlIlIlI
{
    private static final ResourceLocation IllIIIIIIIlIlIllllIIllIII;
    private RenderBlocks lIIIIllIIlIlIllIIIlIllIlI;
    private Random IlllIllIlIIIIlIIlIIllIIIl;
    public boolean lIIIIlIIllIIlIIlIIIlIIllI;
    public float IlIlIIIlllIIIlIlllIlIllIl;
    public static boolean IIIllIllIlIlllllllIlIlIII;
    
    public IIIlIllIIlIllIIIIlIIlIlIl() {
        this.lIIIIllIIlIlIllIIIlIllIlI = new RenderBlocks();
        this.IlllIllIlIIIIlIIlIIllIIIl = new Random();
        this.lIIIIlIIllIIlIIlIIIlIIllI = true;
        this.IIIIllIlIIIllIlllIlllllIl = 0.024626868f * 6.090909f;
        this.IIIIllIIllIIIIllIllIIIlIl = 4.0f * 0.1875f;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        final lIlIlIlIlIllllIlllIIIlIlI iiiIllIlIIIllIlllIlllllIl = lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl();
        if (iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() != null) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(lllIIIIIlIllllIIIlllIllIl);
            lllllIIIIIlllIIIlIIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(false, false, 1.0f);
            this.IlllIllIlIIIIlIIlIIllIIIl.setSeed(187L);
            GL11.glPushMatrix();
            final float n6 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((lllIIIIIlIllllIIIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI + n5) / 10 + lllIIIIIlIllllIIIlllIllIl.IlllIIIlIlllIllIlIIlllIlI) * (0.25333333f * 0.39473686f) + 0.14285715f * 0.7f;
            final float n7 = ((lllIIIIIlIllllIIIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI + n5) / 20 + lllIIIIIlIllllIIIlllIllIl.IlllIIIlIlllIllIlIIlllIlI) * (57.295776f * 1.0f);
            int n8 = 1;
            if (lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().lIIIIIIIIIlIllIIllIlIIlIl > 1) {
                n8 = 2;
            }
            if (lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().lIIIIIIIIIlIllIIllIlIIlIl > 5) {
                n8 = 3;
            }
            if (lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().lIIIIIIIIIlIllIIllIlIIlIl > 20) {
                n8 = 4;
            }
            if (lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().lIIIIIIIIIlIllIIllIlIIlIl > 40) {
                n8 = 5;
            }
            GL11.glTranslatef((float)n, (float)n2 + n6, (float)n3);
            GL11.glEnable(32826);
            if (iiiIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI() == 0 && iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() instanceof llIllIlIlIIIIlIIIIllIllll && RenderBlocks.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI()).IlIlllIIIIllIllllIllIIlIl())) {
                final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI());
                GL11.glRotatef(n7, 0.0f, 1.0f, 0.0f);
                if (IIIlIllIIlIllIIIIlIIlIlIl.IIIllIllIlIlllllllIlIlIII) {
                    GL11.glScalef(0.5084746f * 2.4583333f, 0.64044946f * 1.9517543f, 1.5081967f * 0.8288044f);
                    GL11.glTranslatef(0.0f, 1.2542373f * 0.039864864f, 0.0f);
                    GL11.glRotatef((float)(-90), 0.0f, 1.0f, 0.0f);
                }
                float n9 = 0.08712121f * 2.8695652f;
                final int ilIlllIIIIllIllllIllIIlIl = liiiIlIIllIIlIIlIIIlIIllI.IlIlllIIIIllIllllIllIIlIl();
                if (ilIlllIIIIllIllllIllIIlIl == 1 || ilIlllIIIIllIllllIllIIlIl == 19 || ilIlllIIIIllIllllIllIIlIl == 12 || ilIlllIIIIllIllllIllIIlIl == 2) {
                    n9 = 0.9756098f * 0.5125f;
                }
                if (liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() > 0) {
                    GL11.glAlphaFunc(516, 0.8955224f * 0.111666664f);
                    GL11.glEnable(3042);
                    OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                }
                GL11.glScalef(n9, n9, n9);
                for (int i = 0; i < n8; ++i) {
                    GL11.glPushMatrix();
                    if (i > 0) {
                        GL11.glTranslatef((this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (1.1111112f * 0.17999999f) / n9, (this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (0.82954544f * 0.2410959f) / n9, (this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (0.5964912f * 0.33529413f) / n9);
                    }
                    this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, iiiIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl(), 1.0f);
                    GL11.glPopMatrix();
                }
                if (liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() > 0) {
                    GL11.glDisable(3042);
                }
            }
            else if (iiiIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI() == 1 && iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI().IIIlIIllllIIllllllIlIIIll()) {
                if (IIIlIllIIlIllIIIIlIIlIlIl.IIIllIllIlIlllllllIlIlIII) {
                    GL11.glScalef(0.7894737f * 0.6495726f, 2.909091f * 0.17628203f, 0.9424809f * 0.5441176f);
                    GL11.glTranslatef(0.0f, -0.05277778f * 0.94736844f, 0.0f);
                }
                else {
                    GL11.glScalef(1.2857143f * 0.3888889f, 8.75f * 0.057142857f, 0.13636364f * 3.6666667f);
                }
                for (int j = 0; j <= 1; ++j) {
                    this.IlllIllIlIIIIlIIlIIllIIIl.setSeed(187L);
                    final IlllIllIIIIlllIllIIIIIlII liiiIlIIllIIlIIlIIIlIIllI2 = iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl(), j);
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                        final int liiiIlIIllIIlIIlIIIlIIllI3 = iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, j);
                        final float n10 = (liiiIlIIllIIlIIlIIIlIIllI3 >> 16 & 0xFF) / (float)255;
                        final float n11 = (liiiIlIIllIIlIIlIIIlIIllI3 >> 8 & 0xFF) / (float)255;
                        final float n12 = (liiiIlIIllIIlIIlIIIlIIllI3 & 0xFF) / (float)255;
                        GL11.glColor4f(n10, n11, n12, 1.0f);
                        this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl, liiiIlIIllIIlIIlIIIlIIllI2, n8, n5, n10, n11, n12);
                    }
                    else {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl, liiiIlIIllIIlIIlIIIlIIllI2, n8, n5, 1.0f, 1.0f, 1.0f);
                    }
                }
            }
            else {
                if (iiiIllIlIIIllIlllIlllllIl != null && iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() instanceof IlIIllIIIllIIIlIIIIlIlIll) {
                    GL11.glAlphaFunc(516, 0.5681818f * 0.176f);
                    GL11.glEnable(3042);
                    OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                }
                if (IIIlIllIIlIllIIIIlIIlIlIl.IIIllIllIlIlllllllIlIlIII) {
                    GL11.glScalef(0.039960038f * 12.833333f, 0.10137149f * 5.0588236f, 3.4166667f * 0.1500938f);
                    GL11.glTranslatef(0.0f, -0.014864866f * 3.3636363f, 0.0f);
                }
                else {
                    GL11.glScalef(0.38f * 1.3157895f, 1.5789474f * 0.31666666f, 2.9333334f * 0.17045455f);
                }
                final IlllIllIIIIlllIllIIIIIlII liiiiiiiiIlIllIIllIlIIlIl = iiiIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl();
                if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                    final int liiiIlIIllIIlIIlIIIlIIllI4 = iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, 0);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl, liiiiiiiiIlIllIIllIlIIlIl, n8, n5, (liiiIlIIllIIlIIlIIIlIIllI4 >> 16 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI4 >> 8 & 0xFF) / (float)255, (liiiIlIIllIIlIIlIIIlIIllI4 & 0xFF) / (float)255);
                }
                else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl, liiiiiiiiIlIllIIllIlIIlIl, n8, n5, 1.0f, 1.0f, 1.0f);
                }
                if (iiiIllIlIIIllIlllIlllllIl != null && iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() instanceof IlIIllIIIllIIIlIIIIlIlIll) {
                    GL11.glDisable(3042);
                }
            }
            GL11.glDisable(32826);
            GL11.glPopMatrix();
            this.lIIIIIIIIIlIllIIllIlIIlIl(lllIIIIIlIllllIIIlllIllIl);
            lllllIIIIIlllIIIlIIIllIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        }
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().IlllIIIlIlllIllIlIIlllIlI());
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl, IlllIllIIIIlllIllIIIIIlII liiiiiiiiIlIllIIllIlIIlIl, final int n, final float n2, final float n3, final float n4, final float n5) {
        final Tessellator instance = Tessellator.instance;
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            final TextureManager llIlIlIllIlIIlIlllIllIIlI = Minecraft.getMinecraft().llIlIlIllIlIIlIlllIllIIlI();
            liiiiiiiiIlIllIIllIlIIlIl = ((TextureMap)llIlIlIllIlIIlIlllIllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl().IlllIIIlIlllIllIlIIlllIlI()))).lIIIIIIIIIlIllIIllIlIIlIl("missingno");
        }
        final float illlIIIlIlllIllIlIIlllIlI = liiiiiiiiIlIllIIllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI();
        final float iiiIllIlIIIllIlllIlllllIl = liiiiiiiiIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl();
        final float iiiIllIIllIIIIllIllIIIlIl = liiiiiiiiIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl();
        final float ilIlIIIlllIIIlIlllIlIllIl = liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl();
        final float n6 = 1.0f;
        final float n7 = 0.18055555f * 2.7692308f;
        final float n8 = 0.20408162f * 1.225f;
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.llIIlllIIIIlllIllIlIlllIl.fancyGraphics) {
            GL11.glPushMatrix();
            if (IIIlIllIIlIllIIIIlIIlIlIl.IIIllIllIlIlllllllIlIlIII) {
                GL11.glRotatef((float)180, 0.0f, 1.0f, 0.0f);
            }
            else {
                GL11.glRotatef(((lllIIIIIlIllllIIIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI + n2) / 20 + lllIIIIIlIllllIIIlllIllIl.IlllIIIlIlllIllIlIIlllIlI) * (35.80986f * 1.6f), 0.0f, 1.0f, 0.0f);
            }
            final float n9 = 0.06172839f * 1.0125f;
            final float n10 = 0.014417614f * 1.5172414f;
            final lIlIlIlIlIllllIlllIIIlIlI iiiIllIlIIIllIlllIlllllIl2 = lllIIIIIlIllllIIIlllIllIl.IIIIllIlIIIllIlllIlllllIl();
            final int liiiiiiiiIlIllIIllIlIIlIl2 = iiiIllIlIIIllIlllIlllllIl2.lIIIIIIIIIlIllIIllIlIIlIl;
            int n11;
            if (liiiiiiiiIlIllIIllIlIIlIl2 < 2) {
                n11 = 1;
            }
            else if (liiiiiiiiIlIllIIllIlIIlIl2 < 16) {
                n11 = 2;
            }
            else if (liiiiiiiiIlIllIIllIlIIlIl2 < 32) {
                n11 = 3;
            }
            else {
                n11 = 4;
            }
            GL11.glTranslatef(-n7, -n8, -((n9 + n10) * n11 / 2.0f));
            for (int i = 0; i < n11; ++i) {
                GL11.glTranslatef(0.0f, 0.0f, n9 + n10);
                if (iiiIllIlIIIllIlllIlllllIl2.IlllIIIlIlllIllIlIIlllIlI() == 0) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(TextureMap.locationBlocksTexture);
                }
                else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(TextureMap.locationItemsTexture);
                }
                GL11.glColor4f(n3, n4, n5, 1.0f);
                ItemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(instance, iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, illlIIIlIlllIllIlIIlllIlI, ilIlIIIlllIIIlIlllIlIllIl, liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(), liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(), n9);
                if (iiiIllIlIIIllIlllIlllllIl2.lIIlIIllIIIIIlIllIIIIllII()) {
                    GL11.glDepthFunc(514);
                    GL11.glDisable(2896);
                    this.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl.bindTexture(IIIlIllIIlIllIIIIlIIlIlIl.IllIIIIIIIlIlIllllIIllIII);
                    GL11.glEnable(3042);
                    GL11.glBlendFunc(768, 1);
                    final float n12 = 0.35076922f * 2.1666667f;
                    GL11.glColor4f(0.42391303f * 1.1794872f * n12, 0.054347828f * 4.6f * n12, 1.3199999f * 0.6060606f * n12, 1.0f);
                    GL11.glMatrixMode(5890);
                    GL11.glPushMatrix();
                    final float n13 = 0.14117648f * 0.8854166f;
                    GL11.glScalef(n13, n13, n13);
                    GL11.glTranslatef(Minecraft.getSystemTime() % 3000L / (float)3000 * 8, 0.0f, 0.0f);
                    GL11.glRotatef((float)(-50), 0.0f, 0.0f, 1.0f);
                    ItemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(instance, 0.0f, 0.0f, 1.0f, 1.0f, 255, 255, n9);
                    GL11.glPopMatrix();
                    GL11.glPushMatrix();
                    GL11.glScalef(n13, n13, n13);
                    GL11.glTranslatef(-(Minecraft.getSystemTime() % 4873L / (float)4873 * 8), 0.0f, 0.0f);
                    GL11.glRotatef((float)10, 0.0f, 0.0f, 1.0f);
                    ItemRenderer.lIIIIlIIllIIlIIlIIIlIIllI(instance, 0.0f, 0.0f, 1.0f, 1.0f, 255, 255, n9);
                    GL11.glPopMatrix();
                    GL11.glMatrixMode(5888);
                    GL11.glDisable(3042);
                    GL11.glEnable(2896);
                    GL11.glDepthFunc(515);
                }
            }
            GL11.glPopMatrix();
        }
        else {
            for (int j = 0; j < n; ++j) {
                GL11.glPushMatrix();
                if (j > 0) {
                    GL11.glTranslatef((this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (1.0f * 0.3f), (this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (0.11868133f * 2.5277777f), (this.IlllIllIlIIIIlIIlIIllIIIl.nextFloat() * 2.0f - 1.0f) * (0.083333336f * 3.6000001f));
                }
                if (!IIIlIllIIlIllIIIIlIIlIlIl.IIIllIllIlIlllllllIlIlIII) {
                    GL11.glRotatef(180 - this.lIIIIIIIIIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl, 0.0f, 1.0f, 0.0f);
                }
                GL11.glColor4f(n3, n4, n5, 1.0f);
                instance.startDrawingQuads();
                instance.IlllIIIlIlllIllIlIIlllIlI(0.0f, 1.0f, 0.0f);
                instance.addVertexWithUV(0.0f - n7, 0.0f - n8, 0.0, illlIIIlIlllIllIlIIlllIlI, ilIlIIIlllIIIlIlllIlIllIl);
                instance.addVertexWithUV(n6 - n7, 0.0f - n8, 0.0, iiiIllIlIIIllIlllIlllllIl, ilIlIIIlllIIIlIlllIlIllIl);
                instance.addVertexWithUV(n6 - n7, 1.0f - n8, 0.0, iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl);
                instance.addVertexWithUV(0.0f - n7, 1.0f - n8, 0.0, illlIIIlIlllIllIlIIlllIlI, iiiIllIIllIIIIllIllIIIlIl);
                instance.draw();
                GL11.glPopMatrix();
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final FontRenderer fontRenderer, final TextureManager textureManager, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2) {
        final int illlIllIlIIIIlIIlIIllIIIl = lIlIlIlIlIllllIlllIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl();
        IlllIllIIIIlllIllIIIIIlII illlIllIIIIlllIllIIIIIlII = lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        if (lIlIlIlIlIllllIlllIIIlIlI.IlllIIIlIlllIllIlIIlllIlI() == 0 && RenderBlocks.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI()).IlIlllIIIIllIllllIllIIlIl())) {
            textureManager.bindTexture(TextureMap.locationBlocksTexture);
            final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI());
            GL11.glEnable(3008);
            if (liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() != 0) {
                GL11.glAlphaFunc(516, 0.43076923f * 0.23214285f);
                GL11.glEnable(3042);
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            }
            else {
                GL11.glAlphaFunc(516, 1.3720931f * 0.36440676f);
                GL11.glDisable(3042);
            }
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(n - 2), (float)(n2 + 3), -3 + this.IlIlIIIlllIIIlIlllIlIllIl);
            GL11.glScalef((float)10, (float)10, (float)10);
            GL11.glTranslatef(1.0f, 0.9157895f * 0.545977f, 1.0f);
            GL11.glScalef(1.0f, 1.0f, (float)(-1));
            GL11.glRotatef((float)210, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef((float)45, 0.0f, 1.0f, 0.0f);
            final int liiiIlIIllIIlIIlIIIlIIllI2 = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, 0);
            final float n3 = (liiiIlIIllIIlIIlIIIlIIllI2 >> 16 & 0xFF) / (float)255;
            final float n4 = (liiiIlIIllIIlIIlIIIlIIllI2 >> 8 & 0xFF) / (float)255;
            final float n5 = (liiiIlIIllIIlIIlIIIlIIllI2 & 0xFF) / (float)255;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                GL11.glColor4f(n3, n4, n5, 1.0f);
            }
            GL11.glRotatef((float)(-90), 0.0f, 1.0f, 0.0f);
            this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI;
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, illlIllIlIIIIlIIlIIllIIIl, 1.0f);
            this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = true;
            if (liiiIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == 0) {
                GL11.glAlphaFunc(516, 0.09250001f * 1.081081f);
            }
            GL11.glPopMatrix();
        }
        else if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().IIIlIIllllIIllllllIlIIIll()) {
            GL11.glDisable(2896);
            GL11.glEnable(3008);
            textureManager.bindTexture(TextureMap.locationItemsTexture);
            GL11.glDisable(3008);
            GL11.glDisable(3553);
            GL11.glEnable(3042);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(0, 0, 0, 0);
            GL11.glColorMask(false, false, false, true);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            final Tessellator instance = Tessellator.instance;
            instance.startDrawingQuads();
            instance.setColorOpaque_I(-1);
            instance.addVertex(n - 2, n2 + 18, this.IlIlIIIlllIIIlIlllIlIllIl);
            instance.addVertex(n + 18, n2 + 18, this.IlIlIIIlllIIIlIlllIlIllIl);
            instance.addVertex(n + 18, n2 - 2, this.IlIlIIIlllIIIlIlllIlIllIl);
            instance.addVertex(n - 2, n2 - 2, this.IlIlIIIlllIIIlIlllIlIllIl);
            instance.draw();
            GL11.glColorMask(true, true, true, true);
            GL11.glEnable(3553);
            GL11.glEnable(3008);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            for (int i = 0; i <= 1; ++i) {
                final IlllIllIIIIlllIllIIIIIlII liiiIlIIllIIlIIlIIIlIIllI3 = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(illlIllIlIIIIlIIlIIllIIIl, i);
                final int liiiIlIIllIIlIIlIIIlIIllI4 = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, i);
                final float n6 = (liiiIlIIllIIlIIlIIIlIIllI4 >> 16 & 0xFF) / (float)255;
                final float n7 = (liiiIlIIllIIlIIlIIIlIIllI4 >> 8 & 0xFF) / (float)255;
                final float n8 = (liiiIlIIllIIlIIlIIIlIIllI4 & 0xFF) / (float)255;
                if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                    GL11.glColor4f(n6, n7, n8, 1.0f);
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, liiiIlIIllIIlIIlIIIlIIllI3, 16, 16);
            }
            GL11.glEnable(2896);
        }
        else {
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
            final ResourceLocation liiiIlIIllIIlIIlIIIlIIllI5 = textureManager.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.IlllIIIlIlllIllIlIIlllIlI());
            textureManager.bindTexture(liiiIlIIllIIlIIlIIIlIIllI5);
            if (illlIllIIIIlllIllIIIIIlII == null) {
                illlIllIIIIlllIllIIIIIlII = ((TextureMap)Minecraft.getMinecraft().llIlIlIllIlIIlIlllIllIIlI().lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI5)).lIIIIIIIIIlIllIIllIlIIlIl("missingno");
            }
            final int liiiIlIIllIIlIIlIIIlIIllI6 = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, 0);
            final float n9 = (liiiIlIIllIIlIIlIIIlIIllI6 >> 16 & 0xFF) / (float)255;
            final float n10 = (liiiIlIIllIIlIIlIIIlIIllI6 >> 8 & 0xFF) / (float)255;
            final float n11 = (liiiIlIIllIIlIIlIIIlIIllI6 & 0xFF) / (float)255;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                GL11.glColor4f(n9, n10, n11, 1.0f);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, illlIllIIIIlllIllIIIIIlII, 16, 16);
            GL11.glEnable(2896);
            GL11.glDisable(3042);
        }
        GL11.glEnable(2884);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final FontRenderer fontRenderer, final TextureManager textureManager, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2) {
        if (lIlIlIlIlIllllIlllIIIlIlI != null) {
            this.IlIlIIIlllIIIlIlllIlIllIl += 50;
            try {
                this.lIIIIlIIllIIlIIlIIIlIIllI(fontRenderer, textureManager, lIlIlIlIlIllllIlllIIIlIlI, n, n2);
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Rendering item");
                final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Item being rendered");
                category.addCrashSectionCallable("Item Type", new IlIIlllllIIlIIIIlIIlIlllI(this, lIlIlIlIlIllllIlllIIIlIlI));
                category.addCrashSectionCallable("Item Aux", new lllIlIllllIlllIIIIIIlllII(this, lIlIlIlIlIllllIlllIIIlIlI));
                category.addCrashSectionCallable("Item NBT", new IIllIlIIIllllIIIlllIlllII(this, lIlIlIlIlIllllIlllIIIlIlI));
                category.addCrashSectionCallable("Item Foil", new lllllIlIIIlIIIlllIIllIIlI(this, lIlIlIlIlIllllIlllIIIlIlI));
                throw new ReportedException(crashReport);
            }
            if (lIlIlIlIlIllllIlllIIIlIlI.lIIlIIllIIIIIlIllIIIIllII() && CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().lIIIIlIIllIIlIIlIIIlIIllI()) {
                GL11.glDepthFunc(514);
                GL11.glDisable(2896);
                GL11.glDepthMask(false);
                textureManager.bindTexture(IIIlIllIIlIllIIIIlIIlIlIl.IllIIIIIIIlIlIllllIIllIII);
                GL11.glEnable(3008);
                GL11.glEnable(3042);
                GL11.glColor4f(0.6f * 0.8333333f, 0.34848484f * 0.7173913f, 0.33170733f * 2.4117646f, 1.0f);
                this.lIIIIlIIllIIlIIlIIIlIIllI(n * 431278612 + n2 * 32178161, n - 2, n2 - 2, 20, 20);
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
                GL11.glDepthMask(true);
                GL11.glEnable(2896);
                GL11.glDepthFunc(515);
            }
            this.IlIlIIIlllIIIlIlllIlIllIl -= 50;
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5) {
        for (int i = 0; i < 2; ++i) {
            OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(((boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IllIIlllIllIlIllIlIIIIIII.IIIIllIlIIIllIlllIlllllIl()) ? 773 : 772, 1, 0, 0);
            final float n6 = 1.2727273f * 0.0030691966f;
            final float n7 = 0.0063920454f * 0.6111111f;
            final float n8 = Minecraft.getSystemTime() % (3000 + i * 1873) / (3000 + (float)(i * 1873)) * 256;
            final float n9 = 0.0f;
            final Tessellator instance = Tessellator.instance;
            float n10 = 4;
            if (i == 1) {
                n10 = -1;
            }
            instance.startDrawingQuads();
            instance.addVertexWithUV(n2 + 0, n3 + n5, this.IlIlIIIlllIIIlIlllIlIllIl, (n8 + n5 * n10) * n6, (n9 + n5) * n7);
            instance.addVertexWithUV(n2 + n4, n3 + n5, this.IlIlIIIlllIIIlIlllIlIllIl, (n8 + n4 + n5 * n10) * n6, (n9 + n5) * n7);
            instance.addVertexWithUV(n2 + n4, n3 + 0, this.IlIlIIIlllIIIlIlllIlIllIl, (n8 + n4) * n6, (n9 + 0.0f) * n7);
            instance.addVertexWithUV(n2 + 0, n3 + 0, this.IlIlIIIlllIIIlIlllIlIllIl, (n8 + 0.0f) * n6, (n9 + 0.0f) * n7);
            instance.draw();
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final FontRenderer fontRenderer, final TextureManager textureManager, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(fontRenderer, textureManager, lIlIlIlIlIllllIlllIIIlIlI, n, n2, null);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final FontRenderer fontRenderer, final TextureManager textureManager, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final int n, final int n2, final String s) {
        if (lIlIlIlIlIllllIlllIIIlIlI != null) {
            if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl > 1 || s != null) {
                final String s2 = (s == null) ? String.valueOf(lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl) : s;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                GL11.glDisable(3042);
                fontRenderer.drawStringWithShadow(s2, (float)(n + 19 - 2 - fontRenderer.getStringWidth(s2)), (float)(n2 + 6 + 3), 16777215);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
            if (lIlIlIlIlIllllIlllIIIlIlI.IllIIIIIIIlIlIllllIIllIII()) {
                final int n3 = (int)Math.round(13 - lIlIlIlIlIllllIlllIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI() * (double)13 / lIlIlIlIlIllllIlllIIIlIlI.IlIlllIIIIllIllllIllIIlIl());
                final int n4 = (int)Math.round(255 - lIlIlIlIlIllllIlllIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI() * (double)255 / lIlIlIlIlIllllIlllIIIlIlI.IlIlllIIIIllIllllIllIIlIl());
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glDisable(3042);
                final Tessellator instance = Tessellator.instance;
                final int n5 = 255 - n4 << 16 | n4 << 8;
                final int n6 = (255 - n4) / 4 << 16 | 0x3F00;
                this.lIIIIlIIllIIlIIlIIIlIIllI(instance, n + 2, n2 + 13, 13, 2, 0);
                this.lIIIIlIIllIIlIIlIIIlIIllI(instance, n + 2, n2 + 13, 12, 1, n6);
                this.lIIIIlIIllIIlIIlIIIlIIllI(instance, n + 2, n2 + 13, n3, 1, n5);
                GL11.glEnable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final Tessellator tessellator, final int n, final int n2, final int n3, final int n4, final int colorOpaque_I) {
        tessellator.startDrawingQuads();
        tessellator.setColorOpaque_I(colorOpaque_I);
        tessellator.addVertex(n + 0, n2 + 0, 0.0);
        tessellator.addVertex(n + 0, n2 + n4, 0.0);
        tessellator.addVertex(n + n3, n2 + n4, 0.0);
        tessellator.addVertex(n + n3, n2 + 0, 0.0);
        tessellator.draw();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final IlllIllIIIIlllIllIIIIIlII illlIllIIIIlllIllIIIIIlII, final int n3, final int n4) {
        final Tessellator instance = Tessellator.instance;
        instance.startDrawingQuads();
        instance.addVertexWithUV(n + 0, n2 + n4, this.IlIlIIIlllIIIlIlllIlIllIl, illlIllIIIIlllIllIIIIIlII.IlllIIIlIlllIllIlIIlllIlI(), illlIllIIIIlllIllIIIIIlII.IlIlIIIlllIIIlIlllIlIllIl());
        instance.addVertexWithUV(n + n3, n2 + n4, this.IlIlIIIlllIIIlIlllIlIllIl, illlIllIIIIlllIllIIIIIlII.IIIIllIlIIIllIlllIlllllIl(), illlIllIIIIlllIllIIIIIlII.IlIlIIIlllIIIlIlllIlIllIl());
        instance.addVertexWithUV(n + n3, n2 + 0, this.IlIlIIIlllIIIlIlllIlIllIl, illlIllIIIIlllIllIIIIIlII.IIIIllIlIIIllIlllIlllllIl(), illlIllIIIIlllIllIIIIIlII.IIIIllIIllIIIIllIllIIIlIl());
        instance.addVertexWithUV(n + 0, n2 + 0, this.IlIlIIIlllIIIlIlllIlIllIl, illlIllIIIIlllIllIIIIIlII.IlllIIIlIlllIllIlIIlllIlI(), illlIllIIIIlllIllIIIIIlII.IIIIllIIllIIIIllIllIIIlIl());
        instance.draw();
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((lllIIIIIlIllllIIIlllIllIl)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lllIIIIIlIllllIIIlllIllIl)entity, n, n2, n3, n4, n5);
    }
    
    static {
        IllIIIIIIIlIlIllllIIllIII = new ResourceLocation("textures/misc/enchanted_item_glint.png");
    }
}
