// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlllIllIlIlIlIIllIllII
{
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI;
    public String lIIIIIIIIIlIllIIllIlIIlIl;
    public String IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIIlllIllIlIlIlIIllIllII(final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI, final String liiiiiiiiIlIllIIllIlIIlIl, final String illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
