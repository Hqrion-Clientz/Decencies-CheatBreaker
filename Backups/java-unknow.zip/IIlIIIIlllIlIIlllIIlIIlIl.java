// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIlllIlIIlllIIlIIlIl implements Comparable
{
    private static long IlIlIIIlllIIIlIlllIlIllIl;
    private final IIlllllllIlllIIllllIIlIll IIIllIllIlIlllllllIlIlIII;
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public long IIIIllIlIIIllIlllIlllllIl;
    public int IIIIllIIllIIIIllIllIIIlIl;
    private long IllIIIIIIIlIlIllllIIllIII;
    
    public IIlIIIIlllIlIIlllIIlIIlIl(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final IIlllllllIlllIIllllIIlIll iiIllIllIlIlllllllIlIlIII) {
        this.IllIIIIIIIlIlIllllIIllIII = IIlIIIIlllIlIIlllIIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl++;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof IIlIIIIlllIlIIlllIIlIIlIl)) {
            return false;
        }
        final IIlIIIIlllIlIIlllIIlIIlIl ilIIIIlllIlIIlllIIlIIlIl = (IIlIIIIlllIlIIlllIIlIIlIl)o;
        return this.lIIIIlIIllIIlIIlIIIlIIllI == ilIIIIlllIlIIlllIIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI && this.lIIIIIIIIIlIllIIllIlIIlIl == ilIIIIlllIlIIlllIIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl && this.IlllIIIlIlllIllIlIIlllIlI == ilIIIIlllIlIIlllIIlIIlIl.IlllIIIlIlllIllIlIIlllIlI && IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII, ilIIIIlllIlIIlllIIlIIlIl.IIIllIllIlIlllllllIlIlIII);
    }
    
    @Override
    public int hashCode() {
        return (this.lIIIIlIIllIIlIIlIIIlIIllI * 1024 * 1024 + this.IlllIIIlIlllIllIlIIlllIlI * 1024 + this.lIIIIIIIIIlIllIIllIlIIlIl) * 256;
    }
    
    public IIlIIIIlllIlIIlllIIlIIlIl lIIIIlIIllIIlIIlIIIlIIllI(final long iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        return this;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int iiiIllIIllIIIIllIllIIIlIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIIlllIlIIlllIIlIIlIl ilIIIIlllIlIIlllIIlIIlIl) {
        return (this.IIIIllIlIIIllIlllIlllllIl < ilIIIIlllIlIIlllIIlIIlIl.IIIIllIlIIIllIlllIlllllIl) ? -1 : ((this.IIIIllIlIIIllIlllIlllllIl > ilIIIIlllIlIIlllIIlIIlIl.IIIIllIlIIIllIlllIlllllIl) ? 1 : ((this.IIIIllIIllIIIIllIllIIIlIl != ilIIIIlllIlIIlllIIlIIlIl.IIIIllIIllIIIIllIllIIIlIl) ? (this.IIIIllIIllIIIIllIllIIIlIl - ilIIIIlllIlIIlllIIlIIlIl.IIIIllIIllIIIIllIllIIIlIl) : ((this.IllIIIIIIIlIlIllllIIllIII < ilIIIIlllIlIIlllIIlIIlIl.IllIIIIIIIlIlIllllIIllIII) ? -1 : ((this.IllIIIIIIIlIlIllllIIllIII > ilIIIIlllIlIIlllIIlIIlIl.IllIIIIIIIlIlIllllIIllIII) ? 1 : 0))));
    }
    
    @Override
    public String toString() {
        return IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII) + ": (" + this.lIIIIlIIllIIlIIlIIIlIIllI + ", " + this.lIIIIIIIIIlIllIIllIlIIlIl + ", " + this.IlllIIIlIlllIllIlIIlllIlI + "), " + this.IIIIllIlIIIllIlllIlllllIl + ", " + this.IIIIllIIllIIIIllIllIIIlIl + ", " + this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public IIlllllllIlllIIllllIIlIll lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public int compareTo(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIIlllIlIIlllIIlIIlIl)o);
    }
}
