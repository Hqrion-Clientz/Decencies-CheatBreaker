// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlIlIlllIIIlIlllIl implements lIllIlllIIllIllllIIIlIllI
{
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        int n = 0;
        lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = null;
        for (int i = 0; i < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++i) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(i);
            if (liIlIlIllIIlIIIlIIIlllIII != null) {
                if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llllllIIIIIlllllIllIlIllI) {
                    if (lIlIlIlIlIllllIlllIIIlIlI != null) {
                        return false;
                    }
                    lIlIlIlIlIllllIlllIIIlIlI = liIlIlIllIIlIIIlIIIlllIII;
                }
                else {
                    if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() != IIlIlIllIlIIllIllIllIIIll.lIllIllIIlIlIIIIllIllllll) {
                        return false;
                    }
                    ++n;
                }
            }
        }
        return lIlIlIlIlIllllIlllIIIlIlI != null && n > 0;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final IIlIlllIlIlIIlIlIIlIIllIl ilIlllIlIlIIlIlIIlIIllIl) {
        int n = 0;
        lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = null;
        for (int i = 0; i < ilIlllIlIlIIlIlIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(); ++i) {
            final lIlIlIlIlIllllIlllIIIlIlI liIlIlIllIIlIIIlIIIlllIII = ilIlllIlIlIIlIlIIlIIllIl.lIIlIlIllIIlIIIlIIIlllIII(i);
            if (liIlIlIllIIlIIIlIIIlllIII != null) {
                if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.llllllIIIIIlllllIllIlIllI) {
                    if (lIlIlIlIlIllllIlllIIIlIlI != null) {
                        return null;
                    }
                    lIlIlIlIlIllllIlllIIIlIlI = liIlIlIllIIlIIIlIIIlllIII;
                }
                else {
                    if (liIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI() != IIlIlIllIlIIllIllIllIIIll.lIllIllIIlIlIIIIllIllllll) {
                        return null;
                    }
                    ++n;
                }
            }
        }
        if (lIlIlIlIlIllllIlllIIIlIlI != null && n >= 1) {
            final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI2 = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.llllllIIIIIlllllIllIlIllI, n + 1);
            lIlIlIlIlIllllIlllIIIlIlI2.IIIIllIlIIIllIlllIlllllIl((IlIIIllIIlIIlllIllllIIIIl)lIlIlIlIlIllllIlllIIIlIlI.lllIIIIIlIllIlIIIllllllII().lIIIIIIIIIlIllIIllIlIIlIl());
            if (lIlIlIlIlIllllIlllIIIlIlI.IlIIlIIIIlIIIIllllIIlIllI()) {
                lIlIlIlIlIllllIlllIIIlIlI2.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI.IIIIIIlIlIlIllllllIlllIlI());
            }
            return lIlIlIlIlIllllIlllIIIlIlI2;
        }
        return null;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return 9;
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIIIIIIlIllIIllIlIIlIl() {
        return null;
    }
}
