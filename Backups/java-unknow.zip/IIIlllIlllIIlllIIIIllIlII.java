import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlllIlllIIlllIIIIllIlII implements Comparator
{
    final /* synthetic */ IlIIIlllIIIlIlIlllIIlllII lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ IIIlIllIlllIIlIIIIlIIIlIl lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIlllIlllIIlllIIIIllIlII(final IIIlIllIlllIIlIIIIlIIIlIl liiiiiiiiIlIllIIllIlIIlIl, final IlIIIlllIIIlIlIlllIIlllII liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final llIIllllIlllIlllIllIIllll llIIllllIlllIlllIllIIllll, final llIIllllIlllIlllIllIIllll llIIllllIlllIlllIllIIllll2) {
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(llIIllllIlllIlllIllIIllll.lIIIIlIIllIIlIIlIIIlIIllI());
        final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(llIIllllIlllIlllIllIIllll2.lIIIIlIIllIIlIIlIIIlIIllI());
        lIIIlIlIlIIlIIllIIIIIllll liiIlIlIlIIlIIllIIIIIllll = null;
        lIIIlIlIlIIlIIllIIIIIllll liiIlIlIlIIlIIllIIIIIllll2 = null;
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlllIIIllIllIlIIIIIIlII == 2) {
            liiIlIlIlIIlIIllIIIIIllll = lIIlIIIllIlIIllIIllIllIIl.IllIlIlIllllIlIIllllIIlll[liiiIlIIllIIlIIlIIIlIIllI];
            liiIlIlIlIIlIIllIIIIIllll2 = lIIlIIIllIlIIllIIllIllIIl.IllIlIlIllllIlIIllllIIlll[liiiIlIIllIIlIIlIIIlIIllI2];
        }
        else if (this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlllIIIllIllIlIIIIIIlII == 0) {
            liiIlIlIlIIlIIllIIIIIllll = lIIlIIIllIlIIllIIllIllIIl.IllIIlIIlllllIllIIIlllIII[liiiIlIIllIIlIIlIIIlIIllI];
            liiIlIlIlIIlIIllIIIIIllll2 = lIIlIIIllIlIIllIIllIllIIl.IllIIlIIlllllIllIIIlllIII[liiiIlIIllIIlIIlIIIlIIllI2];
        }
        else if (this.lIIIIIIIIIlIllIIllIlIIlIl.IIIlllIIIllIllIlIIIIIIlII == 1) {
            liiIlIlIlIIlIIllIIIIIllll = lIIlIIIllIlIIllIIllIllIIl.lIlIlIllIIIIIIIIllllIIllI[liiiIlIIllIIlIIlIIIlIIllI];
            liiIlIlIlIIlIIllIIIIIllll2 = lIIlIIIllIlIIllIIllIllIIl.lIlIlIllIIIIIIIIllllIIllI[liiiIlIIllIIlIIlIIIlIIllI2];
        }
        if (liiIlIlIlIIlIIllIIIIIllll != null || liiIlIlIlIIlIIllIIIIIllll2 != null) {
            if (liiIlIlIlIIlIIllIIIIIllll == null) {
                return 1;
            }
            if (liiIlIlIlIIlIIllIIIIIllll2 == null) {
                return -1;
            }
            final int liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIIIIIIlIllIIllIlIIlIl.lllIIIIIlIllIlIIIllllllII.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIlIIlIIllIIIIIllll);
            final int liiiIlIIllIIlIIlIIIlIIllI4 = this.lIIIIIIIIIlIllIIllIlIIlIl.lllIIIIIlIllIlIIIllllllII.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIlIIlIIllIIIIIllll2);
            if (liiiIlIIllIIlIIlIIIlIIllI3 != liiiIlIIllIIlIIlIIIlIIllI4) {
                return (liiiIlIIllIIlIIlIIIlIIllI3 - liiiIlIIllIIlIIlIIIlIIllI4) * this.lIIIIIIIIIlIllIIllIlIIlIl.llIlIIIlIIIIlIlllIlIIIIll;
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI - liiiIlIIllIIlIIlIIIlIIllI2;
    }
    
    @Override
    public int compare(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((llIIllllIlllIlllIllIIllll)o, (llIIllllIlllIlllIllIIllll)o2);
    }
}
