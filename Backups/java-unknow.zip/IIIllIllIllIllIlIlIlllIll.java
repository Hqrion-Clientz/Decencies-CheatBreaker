// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIllIllIllIlIlIlllIll extends llIllIlIlIIIIlIIIIllIllll
{
    private IIlllllllIlllIIllllIIlIll IlllIllIlIIIIlIIlIIllIIIl;
    
    public IIIllIllIllIllIlIlIlllIll(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final IIlllllllIlllIIllllIIlIll illlIllIlIIIIlIIlIIllIIIl) {
        super(illlllllIlllIIllllIIlIll);
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IIIIllIIllIIIIllIllIIIlIl(0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(2, n);
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl(final int n) {
        return n;
    }
}
