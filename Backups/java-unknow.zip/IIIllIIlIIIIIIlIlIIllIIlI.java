import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIllIIlIIIIIIlIlIIllIIlI implements Callable
{
    final /* synthetic */ IIlllIllIlIllIIlIIIlIIlll lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ EffectRenderer lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIllIIlIIIIIIlIlIIllIIlI(final EffectRenderer liiiiiiiiIlIllIIllIlIIlIl, final IIlllIllIlIllIIlIIIlIIlll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.toString();
    }
}
