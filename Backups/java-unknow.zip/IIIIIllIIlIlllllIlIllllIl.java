import java.util.UUID;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIIllIIlIlllllIlIllllIl extends IIIIlIIlIIIllllIIIlllIIll implements llllIIIlIlIIIIIIlllllllll
{
    protected IlIIlIlIIllIIIIIlIIIIIllI llIIIlllllIlllIIllIlIIlII;
    
    public IIIIIllIIlIlllllIlIllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.llIIIlllllIlllIIllIlIIlII = new IlIIlIlIIllIIIIIlIIIIIllI(this);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(17, "");
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        if (this.IlllIIIlIlllIllIlIIlllIlI() == null) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("OwnerUUID", "");
        }
        else {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("OwnerUUID", this.IlllIIIlIlllIllIlIIlllIlI());
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Sitting", this.llIllllIIIIIlIllIlIIIllIl());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        String s;
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("OwnerUUID", 8)) {
            s = ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("OwnerUUID");
        }
        else {
            s = lllIllIlIlIIlIIIIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("Owner"));
        }
        if (s.length() > 0) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(s);
            this.IlllIllIlIIIIlIIlIIllIIIl(true);
        }
        this.llIIIlllllIlllIIllIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Sitting"));
        this.IlIlllIIIIllIllllIllIIlIl(ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Sitting"));
    }
    
    protected void lIIIIllIIlIlIllIIIlIllIlI(final boolean b) {
        String s = "heart";
        if (!b) {
            s = "smoke";
        }
        for (int i = 0; i < 7; ++i) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(s, this.IIIlIIlIlIIIlllIIlIllllll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IllIlIIIIlllIIllIIlllIIlI + 0.3552631590092281 * 1.4074074029922485 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.llllIIIIlIlIllIIIllllIIll, this.IllIlIlIllllIlIIllllIIlll + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * this.IlIIlIIlIllIIIIllIIllIlIl * 2.0f - this.IlIIlIIlIllIIIIllIIllIlIl, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.027407408072951743 * 0.7297297120094299), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (1.2692307233810425 * 0.015757576326802872), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.9081632494926453 * 0.022022472293580703));
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        if (b == 7) {
            this.lIIIIllIIlIlIllIIIlIllIlI(true);
        }
        else if (b == 6) {
            this.lIIIIllIIlIlIllIIIlIllIlI(false);
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(b);
        }
    }
    
    public boolean llllIIllIIlIIllIIIllIlIlI() {
        return (this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16) & 0x4) != 0x0;
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl(final boolean b) {
        final byte liiiIlIIllIIlIIlIIIlIIllI = this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16);
        if (b) {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(liiiIlIIllIIlIIlIIIlIIllI | 0x4));
        }
        else {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(liiiIlIIllIIlIIlIIIlIIllI & 0xFFFFFFFB));
        }
    }
    
    public boolean llIllllIIIIIlIllIlIIIllIl() {
        return (this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16) & 0x1) != 0x0;
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final boolean b) {
        final byte liiiIlIIllIIlIIlIIIlIIllI = this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16);
        if (b) {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(liiiIlIIllIIlIIlIIIlIIllI | 0x1));
        }
        else {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)(liiiIlIIllIIlIIlIIIlIIllI & 0xFFFFFFFE));
        }
    }
    
    @Override
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.IIIIllIIllIIIIllIllIIIlIl(17);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(17, s);
    }
    
    public EntityLivingBase llIlllIIllIlllIlIlIlIIIll() {
        try {
            final UUID fromString = UUID.fromString(this.IlllIIIlIlllIllIlIIlllIlI());
            return (fromString == null) ? null : this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(fromString);
        }
        catch (IllegalArgumentException ex) {
            return null;
        }
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final EntityLivingBase entityLivingBase) {
        return entityLivingBase == this.llIlllIIllIlllIlIlIlIIIll();
    }
    
    public IlIIlIlIIllIIIIIlIIIIIllI lIlIlIIllIlIIIIIlllIllIII() {
        return this.llIIIlllllIlllIIllIlIIlII;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final EntityLivingBase entityLivingBase2) {
        return true;
    }
    
    @Override
    public lIlllllllllIlIIIlIIIIlIIl IlIlIIlllIIIIIlIlIlIIIllI() {
        if (this.llllIIllIIlIIllIIIllIlIlI()) {
            final EntityLivingBase llIlllIIllIlllIlIlIlIIIll = this.llIlllIIllIlllIlIlIlIIIll();
            if (llIlllIIllIlllIlIlIlIIIll != null) {
                return llIlllIIllIlllIlIlIlIIIll.IlIlIIlllIIIIIlIlIlIIIllI();
            }
        }
        return super.IlIlIIlllIIIIIlIlIlIIIllI();
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final EntityLivingBase entityLivingBase) {
        if (this.llllIIllIIlIIllIIIllIlIlI()) {
            final EntityLivingBase llIlllIIllIlllIlIlIlIIIll = this.llIlllIIllIlllIlIlIlIIIll();
            if (entityLivingBase == llIlllIIllIlllIlIlIlIIIll) {
                return true;
            }
            if (llIlllIIllIlllIlIlIlIIIll != null) {
                return llIlllIIllIlllIlIlIlIIIll.IIIIllIlIIIllIlllIlllllIl(entityLivingBase);
            }
        }
        return super.IIIIllIlIIIllIlllIlllllIl(entityLivingBase);
    }
}
