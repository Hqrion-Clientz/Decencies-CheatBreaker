// 
// Decompiled by Procyon v0.5.36
// 

public interface IIlIIlIIllIllllllllIllIII
{
    int IIIIllIIllIIIIllIllIIIlIl();
    
    lIlIlIlIlIllllIlllIIIlIlI lIIlIlIllIIlIIIlIIIlllIII(final int p0);
    
    lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final int p0, final int p1);
    
    lIlIlIlIlIllllIlllIIIlIlI IIIlllIIIllIllIlIIIIIIlII(final int p0);
    
    void lIIIIIIIIIlIllIIllIlIIlIl(final int p0, final lIlIlIlIlIllllIlllIIIlIlI p1);
    
    String IIIlIIlIlIIIlllIIlIllllll();
    
    boolean lIIlIIllIIIIIlIllIIIIllII();
    
    int IllIlIIIIlllIIllIIlllIIlI();
    
    void lIllIllIlIIllIllIlIlIIlIl();
    
    boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll p0);
    
    void sendHorseInteraction();
    
    void lIllIlIlllIIlIIllIIlIIlII();
    
    boolean IlllIIIlIlllIllIlIIlllIlI(final int p0, final lIlIlIlIlIllllIlllIIIlIlI p1);
}
