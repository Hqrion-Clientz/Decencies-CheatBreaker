import java.util.Iterator;
import java.util.Comparator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIlllllIIlIllIIIIII implements lIlllIIlIIlllllIIIllIIIlI
{
    IIllIllIIllIlIIlIIIllllII lIIIIlIIllIIlIIlIIIlIIllI;
    public ArrayList lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIIlllIlllllIIlIllIIIIII(final IIllIllIIllIlIIlIIIllllII liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
    }
    
    @Override
    public ArrayList lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.clear();
        for (int i = -1; i <= 1; ++i) {
            IlIIlIllllllIlIIllIlIlIlI liiiIlIIllIIlIIlIIIlIIllI;
            try {
                liiiIlIIllIIlIIlIIIlIIllI = IlIIlIllllllIlIIllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(i);
            }
            catch (Exception ex) {
                liiiIlIIllIIlIIlIIIlIIllI = null;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                String llIIlllIIIIlllIllIlIlllIl;
                try {
                    llIIlllIIIIlllIllIlIlllIl = liiiIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl();
                }
                catch (Exception ex2) {
                    llIIlllIIIIlllIllIlIlllIl = "failedToLoad";
                }
                this.lIIIIIIIIIlIllIIllIlIIlIl.add(new llIIIIlllIllIIllllIllIlIl(llIIlllIIIIlllIllIlIlllIl, i));
            }
        }
        final Iterator<lIIllIllIlIllIIIlIlllllIl> iterator = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().iterator();
        while (iterator.hasNext()) {
            for (final Integer n : iterator.next().IllIIIIIIIlIlIllllIIllIII) {
                if (this.lIIIIlIIllIIlIIlIIIlIIllI(n) == null) {
                    IlIIlIllllllIlIIllIlIlIlI liiiIlIIllIIlIIlIIIlIIllI2;
                    try {
                        liiiIlIIllIIlIIlIIIlIIllI2 = IlIIlIllllllIlIIllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n);
                    }
                    catch (Exception ex3) {
                        liiiIlIIllIIlIIlIIIlIIllI2 = null;
                    }
                    if (liiiIlIIllIIlIIlIIIlIIllI2 == null) {
                        continue;
                    }
                    String llIIlllIIIIlllIllIlIlllIl2;
                    try {
                        llIIlllIIIIlllIllIlIlllIl2 = liiiIlIIllIIlIIlIIIlIIllI2.llIIlllIIIIlllIllIlIlllIl();
                    }
                    catch (Exception ex4) {
                        llIIlllIIIIlllIllIlIlllIl2 = "failedToLoad";
                    }
                    this.lIIIIIIIIIlIllIIllIlIIlIl.add(new llIIIIlllIllIIllllIllIlIl(llIIlllIIIIlllIllIlIlllIl2, n));
                }
            }
        }
        Collections.sort((List<Object>)this.lIIIIIIIIIlIllIIllIlIIlIl, new IIlllIlIIIlIlIlIIIlllIIIl(this));
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int i) {
        llIIIIlllIllIIllllIllIlIl liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(i);
        if (liiiIlIIllIIlIIlIIIlIIllI == null) {
            liiiIlIIllIIlIIlIIIlIIllI = new llIIIIlllIllIIllllIllIlIl("notLoaded", i);
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(liiiIlIIllIIlIIlIIIlIIllI);
            Collections.sort((List<Object>)this.lIIIIIIIIIlIllIIllIlIIlIl, new IlIlllIIIllIllIIllIIlIlll(this));
        }
        if (!liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI.equals("notLoaded")) {
            if (!liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI.equals("failedToLoad")) {
                return;
            }
        }
        try {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = Minecraft.getMinecraft().theWorld.lIIIIIllllIIIIlIlIIIIlIlI.llIIlllIIIIlllIllIlIlllIl();
        }
        catch (Exception ex) {
            liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = "dimension " + i + "(" + Minecraft.getMinecraft().theWorld.lIIIIIllllIIIIlIlIIIIlIlI.getClass().getSimpleName() + ")";
        }
    }
    
    @Override
    public llIIIIlllIllIIllllIllIlIl lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        for (final llIIIIlllIllIIllllIllIlIl llIIIIlllIllIIllllIllIlIl : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (llIIIIlllIllIIllllIllIlIl.lIIIIIIIIIlIllIIllIlIIlIl == n) {
                return llIIIIlllIllIIllllIllIlIl;
            }
        }
        return null;
    }
    
    public llIIIIlllIllIIllllIllIlIl lIIIIlIIllIIlIIlIIIlIIllI(final String anObject) {
        for (final llIIIIlllIllIIllllIllIlIl llIIIIlllIllIIllllIllIlIl : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (llIIIIlllIllIIllllIllIlIl.lIIIIlIIllIIlIIlIIIlIIllI.equals(anObject)) {
                return llIIIIlllIllIIllllIllIlIl;
            }
        }
        return null;
    }
}
