import org.apache.logging.log4j.LogManager;
import java.util.UUID;
import java.util.Collection;
import java.util.Iterator;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIlIlllIIlIIlIIllIIl
{
    private static final Logger IlIlIIIlllIIIlIlllIlIllIl;
    public static final llIIllIlllllIIIlIIIIlIlll lIIIIlIIllIIlIIlIIIlIIllI;
    public static final llIIllIlllllIIIlIIIIlIlll lIIIIIIIIIlIllIIllIlIIlIl;
    public static final llIIllIlllllIIIlIIIIlIlll IlllIIIlIlllIllIlIIlllIlI;
    public static final llIIllIlllllIIIlIIIIlIlll IIIIllIlIIIllIlllIlllllIl;
    public static final llIIllIlllllIIIlIIIIlIlll IIIIllIIllIIIIllIllIIIlIl;
    
    public static IllIlllIlIllIIIIIIllIllll lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIIlllIIllIIIllIIllIlI ilIlIIlllIIllIIIllIIllIlI) {
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
        final Iterator<IlIlIlllIIllIIllIllllllII> iterator = ilIlIIlllIIllIIIllIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI().iterator();
        while (iterator.hasNext()) {
            illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI(iterator.next()));
        }
        return illIlllIlIllIIIIIIllIllll;
    }
    
    private static IlIIIllIIlIIlllIllllIIIIl lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIlllIIllIIllIllllllII ilIlIlllIIllIIllIllllllII) {
        final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Name", ilIlIlllIIllIIllIllllllII.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Base", ilIlIlllIIllIIllIllllllII.lIIIIIIIIIlIllIIllIlIIlIl());
        final Collection illlIIIlIlllIllIlIIlllIlI = ilIlIlllIIllIIllIllllllII.IlllIIIlIlllIllIlIIlllIlI();
        if (illlIIIlIlllIllIlIIlllIlI != null && !illlIIIlIlllIllIlIIlllIlI.isEmpty()) {
            final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
            for (final IllIIlIIllIlllIIIIIllllII illIIlIIllIlllIIIIIllllII : illlIIIlIlllIllIlIIlllIlI) {
                if (illIIlIIllIlllIIIIIllllII.IIIIllIIllIIIIllIllIIIlIl()) {
                    illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(lIIIIlIIllIIlIIlIIIlIIllI(illIIlIIllIlllIIIIIllllII));
                }
            }
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Modifiers", illIlllIlIllIIIIIIllIllll);
        }
        return ilIIIllIIlIIlllIllllIIIIl;
    }
    
    private static IlIIIllIIlIIlllIllllIIIIl lIIIIlIIllIIlIIlIIIlIIllI(final IllIIlIIllIlllIIIIIllllII illIIlIIllIlllIIIIIllllII) {
        final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Name", illIIlIIllIlllIIIIIllllII.lIIIIIIIIIlIllIIllIlIIlIl());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Amount", illIIlIIllIlllIIIIIllllII.IIIIllIlIIIllIlllIlllllIl());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Operation", illIIlIIllIlllIIIIIllllII.IlllIIIlIlllIllIlIIlllIlI());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("UUIDMost", illIIlIIllIlllIIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI().getMostSignificantBits());
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("UUIDLeast", illIIlIIllIlllIIIIIllllII.lIIIIlIIllIIlIIlIIIlIIllI().getLeastSignificantBits());
        return ilIIIllIIlIIlllIllllIIIIl;
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIIlllIIllIIIllIIllIlI ilIlIIlllIIllIIIllIIllIlI, final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll) {
        for (int i = 0; i < illIlllIlIllIIIIIIllIllll.IIIIllIlIIIllIlllIlllllIl(); ++i) {
            final IlIIIllIIlIIlllIllllIIIIl liiiiiiiiIlIllIIllIlIIlIl = illIlllIlIllIIIIIIllIllll.lIIIIIIIIIlIllIIllIlIIlIl(i);
            final IlIlIlllIIllIIllIllllllII liiiIlIIllIIlIIlIIIlIIllI = ilIlIIlllIIllIIIllIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl("Name"));
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl);
            }
            else {
                IIlIlIIlIlllIIlIIlIIllIIl.IlIlIIIlllIIIlIlllIlIllIl.warn("Ignoring unknown attribute '" + liiiiiiiiIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl("Name") + "'");
            }
        }
    }
    
    private static void lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIlllIIllIIllIllllllII ilIlIlllIIllIIllIllllllII, final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIlIlllIIllIIllIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.lIIIIllIIlIlIllIIIlIllIlI("Base"));
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Modifiers", 9)) {
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Modifiers", 10);
            for (int i = 0; i < illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
                final IllIIlIIllIlllIIIIIllllII liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(i));
                final IllIIlIIllIlllIIIIIllllII liiiIlIIllIIlIIlIIIlIIllI2 = ilIlIlllIIllIIllIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI());
                if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                    ilIlIlllIIllIIllIllllllII.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2);
                }
                ilIlIlllIIllIIllIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            }
        }
    }
    
    public static IllIIlIIllIlllIIIIIllllII lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        return new IllIIlIIllIlllIIIIIllllII(new UUID(ilIIIllIIlIIlllIllllIIIIl.IIIllIllIlIlllllllIlIlIII("UUIDMost"), ilIIIllIIlIIlllIllllIIIIl.IIIllIllIlIlllllllIlIlIII("UUIDLeast")), ilIIIllIIlIIlllIllllIIIIl.IlllIllIlIIIIlIIlIIllIIIl("Name"), ilIIIllIIlIIlllIllllIIIIl.lIIIIllIIlIlIllIIIlIllIlI("Amount"), ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Operation"));
    }
    
    static {
        IlIlIIIlllIIIlIlllIlIllIl = LogManager.getLogger();
        lIIIIlIIllIIlIIlIIIlIIllI = new IIlIllllllIlIlIlIllIllIlI("generic.maxHealth", 20, 0.0, 1.2790697813034058 * 1.4054691629337213E308).lIIIIlIIllIIlIIlIIIlIIllI("Max Health").lIIIIlIIllIIlIIlIIIlIIllI(true);
        lIIIIIIIIIlIllIIllIlIIlIl = new IIlIllllllIlIlIlIllIllIlI("generic.followRange", 32, 0.0, 2048).lIIIIlIIllIIlIIlIIIlIIllI("Follow Range");
        IlllIIIlIlllIllIlIIlllIlI = new IIlIllllllIlIlIlIllIllIlI("generic.knockbackResistance", 0.0, 0.0, 1.0).lIIIIlIIllIIlIIlIIIlIIllI("Knockback Resistance");
        IIIIllIlIIIllIlllIlllllIl = new IIlIllllllIlIlIlIllIllIlI("generic.movementSpeed", 1.1818181276321411 * 0.592307709377899, 0.0, 1.382840923693315E308 * 1.2999999523162842).lIIIIlIIllIIlIIlIIIlIIllI("Movement Speed").lIIIIlIIllIIlIIlIIIlIIllI(true);
        IIIIllIIllIIIIllIllIIIlIl = new IIlIllllllIlIlIlIllIllIlI("generic.attackDamage", 2, 0.0, 8.5 * 2.1149330998380184E307);
    }
}
