import org.apache.logging.log4j.LogManager;
import java.util.List;
import java.io.FileWriter;
import java.io.File;
import java.util.Date;
import java.text.SimpleDateFormat;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIllIlIIlIllIllIllI extends IlIIIllllllIllIlllllIIllI
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private long lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    
    @Override
    public String getIdentifier() {
        return "debug";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 3;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.debug.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length == 1) {
            if (array[0].equals("start")) {
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.debug.start", new Object[0]);
                llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIllIIllllllIIlllIlllIIl();
                this.lIIIIIIIIIlIllIIllIlIIlIl = llllIlIlllllIIlIIllllIIII.IllllllllIlIIIIIIIIllIIII();
                this.IlllIIIlIlllIllIlIIlllIlI = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IIIIIlIllIllIlIIllIIlIllI();
                return;
            }
            if (array[0].equals("stop")) {
                if (!llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl.profilingEnabled) {
                    throw new lIllllIllIIIllIlIlIlIIIII("commands.debug.notStarted", new Object[0]);
                }
                final long illllllllIlIIIIIIIIllIIII = llllIlIlllllIIlIIllllIIII.IllllllllIlIIIIIIIIllIIII();
                final int iiiiIlIllIllIlIIllIIlIllI = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IIIIIlIllIllIlIIllIIlIllI();
                final long n = illllllllIlIIIIIIIIllIIII - this.lIIIIIIIIIlIllIIllIlIIlIl;
                final int i = iiiiIlIllIllIlIIllIIlIllI - this.IlllIIIlIlllIllIlIIlllIlI;
                this.lIIIIlIIllIIlIIlIIIlIIllI(n, i);
                llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl.profilingEnabled = false;
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.debug.stop", n / (float)1000, i);
                return;
            }
        }
        throw new IIllllIlIlIIlllIlIIllIIll("commands.debug.usage", new Object[0]);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final long n, final int n2) {
        final File file = new File(llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IlllIIIlIlllIllIlIIlllIlI("debug"), "profile-results-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + ".txt");
        file.getParentFile().mkdirs();
        try {
            final FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2));
            fileWriter.close();
        }
        catch (Throwable t) {
            IIIllIIIllIlIIlIllIllIllI.lIIIIlIIllIIlIIlIIIlIIllI.error("Could not save profiler results to " + file, t);
        }
    }
    
    private String lIIIIIIIIIlIllIIllIlIIlIl(final long lng, final int i) {
        final StringBuilder sb = new StringBuilder();
        sb.append("---- Minecraft Profiler Results ----\n");
        sb.append("// ");
        sb.append(IIIIllIlIIIllIlllIlllllIl());
        sb.append("\n\n");
        sb.append("Time span: ").append(lng).append(" ms\n");
        sb.append("Tick span: ").append(i).append(" ticks\n");
        sb.append("// This is approximately ").append(String.format("%.2f", i / (lng / (float)1000))).append(" ticks per second. It should be ").append(20).append(" ticks per second\n\n");
        sb.append("--- BEGIN PROFILE DUMP ---\n\n");
        this.lIIIIlIIllIIlIIlIIIlIIllI(0, "root", sb);
        sb.append("--- END PROFILE DUMP ---\n\n");
        return sb.toString();
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final int i, final String str, final StringBuilder sb) {
        final List profilingData = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl.getProfilingData(str);
        if (profilingData != null && profilingData.size() >= 3) {
            for (int j = 1; j < profilingData.size(); ++j) {
                final IllIIIlIIIIllIIIlIllIIIlI illIIIlIIIIllIIIlIllIIIlI = profilingData.get(j);
                sb.append(String.format("[%02d] ", i));
                for (int k = 0; k < i; ++k) {
                    sb.append(" ");
                }
                sb.append(illIIIlIIIIllIIIlIllIIIlI.field_76331_c);
                sb.append(" - ");
                sb.append(String.format("%.2f", illIIIlIIIIllIIIlIllIIIlI.field_76332_a));
                sb.append("%/");
                sb.append(String.format("%.2f", illIIIlIIIIllIIIlIllIIIlI.field_76330_b));
                sb.append("%\n");
                if (!illIIIlIIIIllIIIlIllIIIlI.field_76331_c.equals("unspecified")) {
                    try {
                        this.lIIIIlIIllIIlIIlIIIlIIllI(i + 1, str + "." + illIIIlIIIIllIIIlIllIIIlI.field_76331_c, sb);
                    }
                    catch (Exception obj) {
                        sb.append("[[ EXCEPTION " + obj + " ]]");
                    }
                }
            }
        }
    }
    
    private static String IIIIllIlIIIllIlllIlllllIl() {
        final String[] array = { "Shiny numbers!", "Am I not running fast enough? :(", "I'm working as hard as I can!", "Will I ever be good enough for you? :(", "Speedy. Zoooooom!", "Hello world", "40% better than a crash report.", "Now with extra numbers", "Now with less numbers", "Now with the same numbers", "You should add flames to things, it makes them go faster!", "Do you feel the need for... optimization?", "*cracks redstone whip*", "Maybe if you treated it better then it'll have more motivation to work faster! Poor server." };
        try {
            return array[(int)(System.nanoTime() % array.length)];
        }
        catch (Throwable t) {
            return "Witty comment unavailable :(";
        }
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, "start", "stop") : null;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
