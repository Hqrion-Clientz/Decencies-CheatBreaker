import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIlIIlIlllIlIlIIIIlll
{
    public static float lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final double n, final double n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, n, n2);
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        return MathHelper.IlIlIIIlllIIIlIlllIlIllIl(n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    public static float IlllIIIlIlllIllIlIIlllIlI(final float n) {
        return MathHelper.IIIIllIIllIIIIllIllIIIlIl(n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
        return MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final double n) {
        return MathHelper.IlIlIIIlllIIIlIlllIlIllIl(n);
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public static long IlllIIIlIlllIllIlIIlllIlI(final double n) {
        return MathHelper.IIIIllIlIIIllIlllIlllllIl(n);
    }
    
    public static float IIIIllIlIIIllIlllIlllllIl(final double n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    public static double lIIIIIIIIIlIllIIllIlIIlIl(final double n, final double n2, final double n3) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(s, n);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final String s, final double n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(s, n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(n);
    }
    
    public static int IIIIllIIllIIIIllIllIIIlIl(final double n) {
        return MathHelper.IIIIllIIllIIIIllIllIIIlIl(n);
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    public static float IIIIllIlIIIllIlllIlllllIl(final float n) {
        return MathHelper.IlllIIIlIlllIllIlIIlllIlI(n);
    }
    
    public static float IIIIllIIllIIIIllIllIIIlIl(final float n) {
        return MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2);
    }
    
    public static int IlIlIIIlllIIIlIlllIlIllIl(final double n) {
        return MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    public static float lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final float n, final float n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, n, n2);
    }
    
    public static double IIIllIllIlIlllllllIlIlIII(final double n) {
        return MathHelper.IIIllIllIlIlllllllIlIlIII(n);
    }
    
    public static float IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        return MathHelper.IIIllIllIlIlllllllIlIlIII(n);
    }
    
    public static float lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final String s, final double n, final double n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2);
    }
    
    public static int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
    }
    
    public static double lIIIIlIIllIIlIIlIIIlIIllI(final long[] array) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(array);
    }
    
    public static int IIIllIllIlIlllllllIlIlIII(final float n) {
        return MathHelper.IIIIllIlIIIllIlllIlllllIl(n);
    }
    
    public static int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final int n, final int n2) {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, n, n2);
    }
}
