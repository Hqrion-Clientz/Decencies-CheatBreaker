// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllllIIIIIlllllIIllIIl extends IllegalArgumentException
{
    public IIlIllllIIIIIlllllIIllIIl(final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl, final String s) {
        super(String.format("Error parsing: %s: %s", iiIlIlIIIlllllIIlllIIIlIl, s));
    }
    
    public IIlIllllIIIIIlllllIIllIIl(final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl, final int i) {
        super(String.format("Invalid index %d requested for %s", i, iiIlIlIIIlllllIIlllIIIlIl));
    }
    
    public IIlIllllIIIIIlllllIIllIIl(final IIIlIlIIIlllllIIlllIIIlIl iiIlIlIIIlllllIIlllIIIlIl, final Throwable cause) {
        super(String.format("Error while parsing: %s", iiIlIlIIIlllllIIlllIIIlIl), cause);
    }
}
