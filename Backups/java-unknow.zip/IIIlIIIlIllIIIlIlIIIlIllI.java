// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlIllIIIlIlIIIlIllI
{
    private IlIlIIlIlIlIIIIlIlllIIIIl lIIIIlIIllIIlIIlIIIlIIllI;
    private IIllIIlIIIIllIlllIlllIIIl lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIIIlIllIIIlIlIIIlIllI(final IlIlIIlIlIlIIIIlIlllIIIIl liiiIlIIllIIlIIlIIIlIIllI, final IIllIIlIIIIllIlllIlllIIIl liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IlllIIIlIlllIllIlIIlllIlI = false;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public IlIlIIlIlIlIIIIlIlllIIIIl lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIllIIlIIIIllIlllIlllIIIl lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
