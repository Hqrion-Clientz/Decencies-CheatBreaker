import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIIIlIIIlIllIIIlIll extends llIlIllIlIIllIIlIIlIlIIll
{
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIllIlIIIIlIIIlIllIIIlIll() {
    }
    
    public IIllIlIIIIlIIIlIllIIIlIll(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIIIIIIlIllIIllIlIIlIl = (random.nextInt(3) == 0);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("Chest");
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Chest", this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        this.lIIIIIIIIIlIllIIllIlIIlIl((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, 1, true);
    }
    
    public static IIllIlIIIIlIIIlIllIIIlIll lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -1, 0, 0, 5, 7, 5, n4);
        return (llIlIllIlIIllIIlIIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIllIlIIIIlIIIlIllIIIlIll(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 4, 1, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 4, 5, 4, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 2, 0, 4, 5, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 3, 1, 4, 4, 1, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 3, 3, 4, 4, 3, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 0, 5, 0, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 4, 3, 5, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 3, 4, 1, 4, 4, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 3, 3, 4, 3, 4, 4, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        if (this.lIIIIIIIIIlIllIIllIlIIlIl && iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI(3, 3), this.lIIIIlIIllIIlIIlIIIlIIllI(2), this.lIIIIIIIIIlIllIIllIlIIlIl(3, 3))) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = false;
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 3, 2, 3, IIllIlIIIIlIIIlIllIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI, 2 + random.nextInt(4));
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 6, 0, 4, 6, 4, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        for (int i = 0; i <= 4; ++i) {
            for (int j = 0; j <= 4; ++j) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, i, -1, j, iiIllllIIllllIIIIIlllllIl);
            }
        }
        return true;
    }
}
