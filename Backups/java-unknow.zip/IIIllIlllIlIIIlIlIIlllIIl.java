// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIllIlllIlIIIlIlIIlllIIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    
    public abstract boolean lIIIIlIIllIIlIIlIIIlIIllI();
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl() {
        return true;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl() {
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
