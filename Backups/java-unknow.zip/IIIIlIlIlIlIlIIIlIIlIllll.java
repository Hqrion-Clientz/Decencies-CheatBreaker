// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIlIlIlIIIlIIlIllll extends IIIlllIIlIIlllIIIIlIlllIl
{
    protected IIIIlIlIlIlIlIIIlIIlIllll() {
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    @Override
    public lIlIlIlIlIllllIlllIIIlIlI lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI2 = new lIlIlIlIlIllllIlllIIIlIlI(IIlIlIllIlIIllIllIllIIIll.IlIlIIIIIllIlIlIIllIlIIIl, 1, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI("map"));
        final String string = "map_" + lIlIlIlIlIllllIlllIIIlIlI2.IlllIllIlIIIIlIIlIIllIIIl();
        final IIIlIIIIlIllIlIllIlllIlll iiIlIIIIlIllIlIllIlllIlll = new IIIlIIIIlIllIlIllIlllIlll(string);
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(string, iiIlIIIIlIllIlIllIlllIlll);
        iiIlIIIIlIllIlIllIlllIlll.IIIIllIIllIIIIllIllIIIlIl = 0;
        final int n = 128 * (1 << iiIlIIIIlIllIlIllIlllIlll.IIIIllIIllIIIIllIllIIIlIl);
        iiIlIIIIlIllIlIllIlllIlll.lIIIIIIIIIlIllIIllIlIIlIl = (int)(Math.round(lIllIIIIlIIlIllIIIlIlIlll.IIIlIIlIlIIIlllIIlIllllll / n) * n);
        iiIlIIIIlIllIlIllIlllIlll.IlllIIIlIlllIllIlIIlllIlI = (int)(Math.round(lIllIIIIlIIlIllIIIlIlIlll.IllIlIlIllllIlIIllllIIlll / n) * n);
        iiIlIIIIlIllIlIllIlllIlll.IIIIllIlIIIllIlllIlllllIl = (byte)iiiiiIllIlIIIIlIlllIllllI.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI;
        iiIlIIIIlIllIlIllIlllIlll.IIIIllIlIIIllIlllIlllllIl();
        --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
            return lIlIlIlIlIllllIlllIIIlIlI2;
        }
        if (!lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI2.llIIlllIIIIlllIllIlIlllIl())) {
            lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI2, false);
        }
        return lIlIlIlIlIllllIlllIIIlIlI;
    }
}
