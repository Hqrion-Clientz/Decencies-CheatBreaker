// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllllIlIIlllIllIlllllI extends IlIlIIllIlIIlIllIIIIllllI
{
    private int llIIIlllllIlllIIllIlIIlII;
    private int lIIIlIlIIIlIlIlllIlIlllII;
    private int llIlIlIIIIIIIlllIIIllIlll;
    private int IllIIIIIIlIlIlllllllIIllI;
    
    public IIIIllllIlIIlllIllIlllllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.llIlIlIIIIIIIlllIIIllIlll = 30;
        this.IllIIIIIIlIlIlllllllIIllI = 3;
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(1, new IIllIIIIllIlIIlIllIIIlllI(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(2, new lIlllIIlIIlIllIIIIIlIIIlI(this));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(3, new IIlIllIIIlIlllIllIIIIIIll(this, IIlIIIlIIlIIlIlllllIIIlIl.class, 6, 1.0, 1.7599999860127766 * 0.6818181872367859));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(4, new lIlIIIIIIIIllIlIIlIIIIlII(this, 1.0, false));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(5, new IllIIllIIlIlIlIllIlIIIlll(this, 1.6372092660147808 * 0.4886363744735718));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(6, new IlIIllIllIllIlllIlIlllIIl(this, lIllIIIIlIIlIllIIIlIlIlll.class, 8));
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(6, new IllIIIlIllIIIIlllIlllIIIl(this));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(1, new lllIIIllIIllIlllIIlllIlll(this, lIllIIIIlIIlIllIIIlIlIlll.class, 0, true));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(2, new lIIIIIIllIllllllllIllIIlI(this, false));
    }
    
    @Override
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.IIIIllIlIIIllIlllIlllllIl).lIIIIlIIllIIlIIlIIIlIIllI(6.199999809265137 * 0.040322581885632605);
    }
    
    public boolean IIllIllIlIIlllllIlIIIlIll() {
        return true;
    }
    
    @Override
    public int IIlIlIlllIllIIlIllIIlIIlI() {
        return (this.IllllIllllIlIIIlIIIllllll() == null) ? 3 : (3 + (int)(this.getHealth() - 1.0f));
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        super.IlIlIIIlllIIIlIlllIlIllIl(n);
        this.lIIIlIlIIIlIlIlllIlIlllII += (int)(n * (2.235294f * 0.67105263f));
        if (this.lIIIlIlIIIlIlIlllIlIlllII > this.llIlIlIIIIIIIlllIIIllIlll - 5) {
            this.lIIIlIlIIIlIlIlllIlIlllII = this.llIlIlIIIIIIIlllIIIllIlll - 5;
        }
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16, (Object)(-1));
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(17, (Object)0);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(18, (Object)0);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        if (this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(17) == 1) {
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("powered", true);
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Fuse", (short)this.llIlIlIIIIIIIlllIIIllIlll);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ExplosionRadius", (byte)this.IllIIIIIIlIlIlllllllIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ignited", this.IlIllIllllIIIlIIIllIIIllI());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(17, (byte)(byte)(ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("powered") ? 1 : 0));
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Fuse", 99)) {
            this.llIlIlIIIIIIIlllIIIllIlll = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Fuse");
        }
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("ExplosionRadius", 99)) {
            this.IllIIIIIIlIlIlllllllIIllI = ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("ExplosionRadius");
        }
        if (ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("ignited")) {
            this.llllIIllIIlIIllIIIllIlIlI();
        }
    }
    
    @Override
    public void x_() {
        if (this.IlIlllIIIIlIllIlllIlIIIll()) {
            this.llIIIlllllIlllIIllIlIIlII = this.lIIIlIlIIIlIlIlllIlIlllII;
            if (this.IlIllIllllIIIlIIIllIIIllI()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(1);
            }
            final int illIIIIIllllIlllIIlIIllIl = this.IllIIIIIllllIlllIIlIIllIl();
            if (illIIIIIllllIlllIIlIIllIl > 0 && this.lIIIlIlIIIlIlIlllIlIlllII == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI("creeper.primed", 1.0f, 1.3409091f * 0.37288135f);
            }
            this.lIIIlIlIIIlIlIlllIlIlllII += illIIIIIllllIlllIIlIIllIl;
            if (this.lIIIlIlIIIlIlIlllIlIlllII < 0) {
                this.lIIIlIlIIIlIlIlllIlIlllII = 0;
            }
            if (this.lIIIlIlIIIlIlIlllIlIlllII >= this.llIlIlIIIIIIIlllIIIllIlll) {
                this.lIIIlIlIIIlIlIlllIlIlllII = this.llIlIlIIIIIIIlllIIIllIlll;
                this.llIllllIIIIIlIllIlIIIllIl();
            }
        }
        super.x_();
    }
    
    @Override
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "mob.creeper.say";
    }
    
    @Override
    protected String IllIIIIIIlIlIlllllllIIllI() {
        return "mob.creeper.death";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll);
        if (lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl() instanceof IlIllIIIllIIIIIlIlllIllII) {
            final int liiiIlIIllIIlIIlIIIlIIllI = lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.lIllIlIlIIlIllIllllIllIIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI(lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIllIlIIllIllIllIIIll.IlIIlIIlIIlllIlIIIlIllIIl) - liiiIlIIllIIlIIlIIIlIIllI + 1)), 1);
        }
    }
    
    @Override
    public boolean lIIlIlIllIIlIIIlIIIlllIII(final Entity entity) {
        return true;
    }
    
    public boolean IIIlIllIIIlllIIlIIllIlIII() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(17) == 1;
    }
    
    public float IIIIllIlIIIllIlllIlllllIl(final float n) {
        return (this.llIIIlllllIlllIIllIlIIlII + (this.lIIIlIlIIIlIlIlllIlIlllII - this.llIIIlllllIlllIIllIlIIlII) * n) / (this.llIlIlIIIIIIIlllIIIllIlll - 2);
    }
    
    @Override
    protected lIIlllIIIlIllllllIlIlIIII lllIIlIIllIllIIllIIlIIIIl() {
        return IIlIlIllIlIIllIllIllIIIll.IllIIlllIllIlIllIlIIIIIII;
    }
    
    public int IllIIIIIllllIlllIIlIIllIl() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(16);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(16, (byte)n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIIIllIllIIIIlIlllIIl lllIlIIIllIllIIIIlIlllIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIllIllIIIIlIlllIIl);
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(17, 1);
    }
    
    @Override
    protected boolean IIIIllIlIIIllIlllIlllllIl(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlIIlIllIIIlIlIlll.inventory.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() == IIlIlIllIlIIllIllIllIIIll.IIIIllIlIIIllIlllIlllllIl) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + 0.08433734625577927 * 5.9285716494279335, this.IllIlIIIIlllIIllIIlllIIlI + 1.7586207389831543 * 0.28431371751541107, this.IllIlIlIllllIlIIllllIIlll + 0.18902438309914607 * 2.6451613903045654, "fire.ignite", 1.0f, this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.05263158f * 7.6f) + 1.5428572f * 0.5185185f);
            lIllIIIIlIIlIllIIIlIlIlll.swingItem();
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                this.llllIIllIIlIIllIIIllIlIlI();
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(1, lIllIIIIlIIlIllIIIlIlIlll);
                return true;
            }
        }
        return super.IIIIllIlIIIllIlllIlllllIl(lIllIIIIlIIlIllIIIlIlIlll);
    }
    
    private void llIllllIIIIIlIllIlIIIllIl() {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final boolean liiiiiiiiIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing");
            if (this.IIIlIllIIIlllIIlIIllIlIII()) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, (float)(this.IllIIIIIIlIlIlllllllIIllI * 2), liiiiiiiiIlIllIIllIlIIlIl);
            }
            else {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, (float)this.IllIIIIIIlIlIlllllllIIllI, liiiiiiiiIlIllIIllIlIIlIl);
            }
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    public boolean IlIllIllllIIIlIIIllIIIllI() {
        return this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(18) != 0;
    }
    
    public void llllIIllIIlIIllIIIllIlIlI() {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(18, 1);
    }
}
