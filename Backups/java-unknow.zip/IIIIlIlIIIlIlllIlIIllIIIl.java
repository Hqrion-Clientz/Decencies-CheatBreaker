import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlIlIIIlIlllIlIIllIIIl implements Callable
{
    final /* synthetic */ lllIlllIlIllIIlIlIIIlIIII lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ TextureMap lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIIlIlIIIlIlllIlIIllIIIl(final TextureMap liiiiiiiiIlIllIIllIlIIlIl, final lllIlllIlIllIIlIlIIIlIIII liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI() + " x " + this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl();
    }
}
