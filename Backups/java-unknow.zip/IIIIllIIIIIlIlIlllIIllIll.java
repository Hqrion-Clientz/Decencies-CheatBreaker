// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIIllIIIIIlIlIlllIIllIll
{
    lIIIIlIIllIIlIIlIIIlIIllI("COOL_WARM", 0, "COOL_WARM", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("HEAT_ICE", 1, "HEAT_ICE", 1), 
    IlllIIIlIlllIllIlIIlllIlI("SPECIAL", 2, "SPECIAL", 2);
    
    private static final IIIIllIIIIIlIlIlllIIllIll[] IIIIllIlIIIllIlllIlllllIl;
    
    private IIIIllIIIIIlIlIlllIIllIll(final String name, final int ordinal, final String s, final int n) {
    }
    
    static {
        IIIIllIlIIIllIlllIlllllIl = new IIIIllIIIIIlIlIlllIIllIll[] { IIIIllIIIIIlIlIlllIIllIll.lIIIIlIIllIIlIIlIIIlIIllI, IIIIllIIIIIlIlIlllIIllIll.lIIIIIIIIIlIllIIllIlIIlIl, IIIIllIIIIIlIlIlllIIllIll.IlllIIIlIlllIllIlIIlllIlI };
    }
}
