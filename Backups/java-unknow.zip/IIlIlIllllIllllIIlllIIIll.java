import java.util.List;
import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllllIllllIIlllIIIll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "testforblock";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.testforblock.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length < 4) {
            throw new IIllllIlIlIIlllIlIIllIIll("commands.testforblock.usage", new Object[0]);
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI;
        final int liiiiiiiiIlIllIIllIlIIlIl = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl;
        final int illlIIIlIlllIllIlIIlllIlI = lIlllllIIIIIIllIlIIlIlIII.IIIlllIIIllIllIlIIIIIIlII().IlllIIIlIlllIllIlIIlllIlI;
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI, array[0]));
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiiiiiiIlIllIIllIlIIlIl, array[1]));
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, illlIIIlIlllIllIlIIlllIlI, array[2]));
        final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI2 = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(array[3]);
        if (liiiIlIIllIIlIIlIIIlIIllI2 == null) {
            throw new IlIlllIllllllIlIIIIIIllII("commands.setblock.notFound", new Object[] { array[3] });
        }
        int liiiIlIIllIIlIIlIIIlIIllI3 = -1;
        if (array.length >= 5) {
            liiiIlIIllIIlIIlIIIlIIllI3 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[4], -1, 15);
        }
        final IIIIIIllIlIIIIlIlllIllllI lllIlIIllllIIIIlIllIlIIII = lIlllllIIIIIIllIlIIlIlIII.lllIlIIllllIIIIlIllIlIIII();
        if (!lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4)) {
            throw new lIllllIllIIIllIlIlIlIIIII("commands.testforblock.outOfWorld", new Object[0]);
        }
        IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = new IlIIIllIIlIIlllIllllIIIIl();
        boolean b = false;
        if (array.length >= 6 && liiiIlIIllIIlIIlIIIlIIllI2.IIIlllIIIllIllIlIIIIIIlII()) {
            final String illlIIIlIlllIllIlIIlllIlI5 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array, 5).IlllIIIlIlllIllIlIIlllIlI();
            try {
                final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI4 = lIlllIllllIlIlllIIIIllIll.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI5);
                if (!(liiiIlIIllIIlIIlIIIlIIllI4 instanceof IlIIIllIIlIIlllIllllIIIIl)) {
                    throw new lIllllIllIIIllIlIlIlIIIII("commands.setblock.tagError", new Object[] { "Not a valid tag" });
                }
                ilIIIllIIlIIlllIllllIIIIl = (IlIIIllIIlIIlllIllllIIIIl)liiiIlIIllIIlIIlIIIlIIllI4;
                b = true;
            }
            catch (IIIlIlIlIIlIIllllIIlIIIlI iiIlIlIlIIlIIllllIIlIIIlI) {
                throw new lIllllIllIIIllIlIlIlIIIII("commands.setblock.tagError", new Object[] { iiIlIlIlIIlIIllllIIlIIIlI.getMessage() });
            }
        }
        final IIlllllllIlllIIllllIIlIll block = lllIlIIllllIIIIlIllIlIIII.getBlock(illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4);
        if (block != liiiIlIIllIIlIIlIIIlIIllI2) {
            throw new lIllllIllIIIllIlIlIlIIIII("commands.testforblock.failed.tile", new Object[] { illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4, block.IllIlIIIIlllIIllIIlllIIlI(), liiiIlIIllIIlIIlIIIlIIllI2.IllIlIIIIlllIIllIIlllIIlI() });
        }
        if (liiiIlIIllIIlIIlIIIlIIllI3 > -1) {
            final int illlIIIlIlllIllIlIIlllIlI6 = lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4);
            if (illlIIIlIlllIllIlIIlllIlI6 != liiiIlIIllIIlIIlIIIlIIllI3) {
                throw new lIllllIllIIIllIlIlIlIIIII("commands.testforblock.failed.data", new Object[] { illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI6, liiiIlIIllIIlIIlIIIlIIllI3 });
            }
        }
        if (b) {
            final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl2 = lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4);
            if (liiiiiiiiIlIllIIllIlIIlIl2 == null) {
                throw new lIllllIllIIIllIlIlIlIIIII("commands.testforblock.failed.tileEntity", new Object[] { illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4 });
            }
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
            liiiiiiiiIlIllIIllIlIIlIl2.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl2);
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl, ilIIIllIIlIIlllIllllIIIIl2)) {
                throw new lIllllIllIIIllIlIlIlIIIII("commands.testforblock.failed.nbt", new Object[] { illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4 });
            }
        }
        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.testforblock.success", new Object[] { illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI4 }));
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIIlIIllIIIIlIIllII lIllIIIIIlIIllIIIIlIIllII, final lIllIIIIIlIIllIIIIlIIllII lIllIIIIIlIIllIIIIlIIllII2) {
        if (lIllIIIIIlIIllIIIIlIIllII == lIllIIIIIlIIllIIIIlIIllII2) {
            return true;
        }
        if (lIllIIIIIlIIllIIIIlIIllII == null) {
            return true;
        }
        if (lIllIIIIIlIIllIIIIlIIllII2 == null) {
            return false;
        }
        if (!lIllIIIIIlIIllIIIIlIIllII.getClass().equals(lIllIIIIIlIIllIIIIlIIllII2.getClass())) {
            return false;
        }
        if (lIllIIIIIlIIllIIIIlIIllII instanceof IlIIIllIIlIIlllIllllIIIIl) {
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl = (IlIIIllIIlIIlllIllllIIIIl)lIllIIIIIlIIllIIIIlIIllII;
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = (IlIIIllIIlIIlllIllllIIIIl)lIllIIIIIlIIllIIIIlIIllII2;
            for (final String s : ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl()) {
                if (!this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(s), ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI(s))) {
                    return false;
                }
            }
            return true;
        }
        return lIllIIIIIlIIllIIIIlIIllII.equals(lIllIIIIIlIIllIIIIlIIllII2);
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 4) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI()) : null;
    }
}
