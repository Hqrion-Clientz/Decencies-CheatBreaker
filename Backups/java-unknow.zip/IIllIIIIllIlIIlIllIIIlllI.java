// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIIllIlIIlIllIIIlllI extends IIIllIlllIlIIIlIlIIlllIIl
{
    private IlllIIIllIlIIlIllIIlIlllI lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIllIIIIllIlIIlIllIIIlllI(final IlllIIIllIlIIlIllIIlIlllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIlIIllIIlIIlIIIlIIllI(4);
        liiiIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll().IIIIllIIllIIIIllIllIIIlIl(true);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlIIIIIIIIllIIllIIlllIl() || this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIllIlIllIlllIlllIll();
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIllIllIIIIIlllIIlll().nextFloat() < 0.28444445f * 2.8125f) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll().lIIIIlIIllIIlIIlIIIlIIllI();
        }
    }
}
