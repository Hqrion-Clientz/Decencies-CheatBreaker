import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIlllIIllllIIIllllII extends IIllIlllIIlllllIlllIIIlIl
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private String lIIIIIIIIIlIllIIllIlIIlIl;
    private String IlllIIIlIlllIllIlIIlllIlI;
    private String IIIIllIlIIIllIlllIlllllIl;
    private Collection IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    
    public IIlIllIlllIIllllIIIllllII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.IlllIIIlIlllIllIlIIlllIlI = "";
        this.IIIIllIlIIIllIlllIlllllIl = "";
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
    }
    
    public IIlIllIlllIIllllIIIllllII(final lIIllllIllIIllIlIlllIllIl liIllllIllIIllIlIlllIllIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.IlllIIIlIlllIllIlIIlllIlI = "";
        this.IIIIllIlIIIllIlllIlllllIl = "";
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liIllllIllIIllIlIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        if (ilIlIIIlllIIIlIlllIlIllIl == 0 || ilIlIIIlllIIIlIlllIlIllIl == 2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = liIllllIllIIllIlIlllIllIl.lIIIIIIIIIlIllIIllIlIIlIl();
            this.IlllIIIlIlllIllIlIIlllIlI = liIllllIllIIllIlIlllIllIl.IIIIllIlIIIllIlllIlllllIl();
            this.IIIIllIlIIIllIlllIlllllIl = liIllllIllIIllIlIlllIllIl.IIIIllIIllIIIIllIllIIIlIl();
            this.IIIllIllIlIlllllllIlIlIII = liIllllIllIIllIlIlllIllIl.IllIIIIIIIlIlIllllIIllIII();
        }
        if (ilIlIIIlllIIIlIlllIlIllIl == 0) {
            this.IIIIllIIllIIIIllIllIIIlIl.addAll(liIllllIllIIllIlIlllIllIl.IlllIIIlIlllIllIlIIlllIlI());
        }
    }
    
    public IIlIllIlllIIllllIIIllllII(final lIIllllIllIIllIlIlllIllIl liIllllIllIIllIlIlllIllIl, final Collection collection, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "";
        this.lIIIIIIIIIlIllIIllIlIIlIl = "";
        this.IlllIIIlIlllIllIlIIlllIlI = "";
        this.IIIIllIlIIIllIlllIlllllIl = "";
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        if (ilIlIIIlllIIIlIlllIlIllIl != 3 && ilIlIIIlllIIIlIlllIlIllIl != 4) {
            throw new IllegalArgumentException("Method must be join or leave for player constructor");
        }
        if (collection != null && !collection.isEmpty()) {
            this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
            this.lIIIIlIIllIIlIIlIIIlIIllI = liIllllIllIIllIlIlllIllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            this.IIIIllIIllIIIIllIllIIIlIl.addAll(collection);
            return;
        }
        throw new IllegalArgumentException("Players cannot be null/empty");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(16);
        this.IlIlIIIlllIIIlIlllIlIllIl = lIlIllllllllIlIIIllIIllII.readByte();
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 0 || this.IlIlIIIlllIIIlIlllIlIllIl == 2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32);
            this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(16);
            this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(16);
            this.IIIllIllIlIlllllllIlIlIII = lIlIllllllllIlIIIllIIllII.readByte();
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 0 || this.IlIlIIIlllIIIlIlllIlIllIl == 3 || this.IlIlIIIlllIIIlIlllIlIllIl == 4) {
            for (short short1 = lIlIllllllllIlIIIllIIllII.readShort(), n = 0; n < short1; ++n) {
                this.IIIIllIIllIIIIllIllIIIlIl.add(lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(40));
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IlIlIIIlllIIIlIlllIlIllIl);
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 0 || this.IlIlIIIlllIIIlIlllIlIllIl == 2) {
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl);
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl);
            lIlIllllllllIlIIIllIIllII.writeByte(this.IIIllIllIlIlllllllIlIlIII);
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 0 || this.IlIlIIIlllIIIlIlllIlIllIl == 3 || this.IlIlIIIlllIIIlIlllIlIllIl == 4) {
            lIlIllllllllIlIIIllIIllII.writeShort(this.IIIIllIIllIIIIllIllIIIlIl.size());
            final Iterator<String> iterator = this.IIIIllIIllIIIIllIllIIIlIl.iterator();
            while (iterator.hasNext()) {
                lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next());
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public String IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public String IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public Collection IIIllIllIlIlllllllIlIlIII() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int IllIIIIIIIlIlIllllIIllIII() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public int lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
