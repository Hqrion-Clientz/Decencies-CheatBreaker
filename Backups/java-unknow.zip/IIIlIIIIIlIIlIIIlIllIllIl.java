import java.util.ArrayList;
import java.util.HashSet;
import java.util.Enumeration;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.Set;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.io.InputStream;
import java.io.File;
import java.util.zip.ZipFile;
import com.google.common.base.Splitter;
import java.io.Closeable;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIIlIIlIIIlIllIllIl extends IIIIllIIlIIlIIIIIIIlllIlI implements Closeable
{
    public static final Splitter lIIIIIIIIIlIllIIllIlIIlIl;
    private ZipFile IlllIIIlIlllIllIlIIlllIlI;
    
    public IIIlIIIIIlIIlIIIlIllIllIl(final File file) {
        super(file);
    }
    
    private ZipFile IIIIllIlIIIllIlllIlllllIl() {
        if (this.IlllIIIlIlllIllIlIIlllIlI == null) {
            this.IlllIIIlIlllIllIlIIlllIlI = new ZipFile(this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    protected InputStream lIIIIlIIllIIlIIlIIIlIIllI(final String name) {
        final ZipFile iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl();
        final ZipEntry entry = iiiIllIlIIIllIlllIlllllIl.getEntry(name);
        if (entry == null) {
            throw new llIIllIlllIIIllIlllIlIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI, name);
        }
        return iiiIllIlIIIllIlllIlllllIl.getInputStream(entry);
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final String name) {
        try {
            return this.IIIIllIlIIIllIlllIlllllIl().getEntry(name) != null;
        }
        catch (IOException ex) {
            return false;
        }
    }
    
    @Override
    public Set lIIIIlIIllIIlIIlIIIlIIllI() {
        ZipFile iiiIllIlIIIllIlllIlllllIl;
        try {
            iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl();
        }
        catch (IOException ex) {
            return Collections.emptySet();
        }
        final Enumeration<? extends ZipEntry> entries = iiiIllIlIIIllIlllIlllllIl.entries();
        final HashSet hashSet = Sets.newHashSet();
        while (entries.hasMoreElements()) {
            final String name = ((ZipEntry)entries.nextElement()).getName();
            if (name.startsWith("assets/")) {
                final ArrayList arrayList = Lists.newArrayList(IIIlIIIIIlIIlIIIlIllIllIl.lIIIIIIIIIlIllIIllIlIIlIl.split((CharSequence)name));
                if (arrayList.size() <= 1) {
                    continue;
                }
                final String e = arrayList.get(1);
                if (!e.equals(e.toLowerCase())) {
                    this.IlllIIIlIlllIllIlIIlllIlI(e);
                }
                else {
                    hashSet.add(e);
                }
            }
        }
        return hashSet;
    }
    
    @Override
    protected void finalize() {
        this.close();
        super.finalize();
    }
    
    @Override
    public void close() {
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            this.IlllIIIlIlllIllIlIIlllIlI.close();
            this.IlllIIIlIlllIllIlIIlllIlI = null;
        }
    }
    
    static {
        lIIIIIIIIIlIllIIllIlIIlIl = Splitter.on('/').omitEmptyStrings().limit(3);
    }
}
