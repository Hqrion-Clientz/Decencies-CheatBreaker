// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIIIlllllIIlllIIIIl extends Entity
{
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private lIllIIIIlIIlIllIIIlIlIlll IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    
    public IIIIlllIIIlllllIIlllIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final int iiiIllIIllIIIIllIllIIIlIl) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIlIIIllIlllIlllllIl = 5;
        this.IIIIllIIllIIIIllIllIIIlIl(0.6865672f * 0.7282609f, 1.5f * 0.33333334f);
        this.lIlIllIlIlIIIllllIlIllIll = this.llllIIIIlIlIllIIIllllIIll / 2.0f;
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        this.IllllIllllIlIIIlIIIllllll = (float)(Math.random() * 360);
        this.IllIIlIIlllllIllIIIlllIII = (float)(Math.random() * (0.026470589372216656 * 7.55555534362793) - 0.019148936067004182 * 5.222222328186035) * 2.0f;
        this.lIlIlIllIIIIIIIIllllIIllI = (float)(Math.random() * (1.1129032373428345 * 0.17971014306465638)) * 2.0f;
        this.IlllIIlllIIIIllIIllllIlIl = (float)(Math.random() * (1.1666666269302368 * 0.17142857982187884) - 1.3181818723678589 * 0.0758620669775146) * 2.0f;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected boolean IIIllIllIlIlllllllIlIlIII() {
        return false;
    }
    
    public IIIIlllIIIlllllIIlllIIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIlIIIllIlllIlllllIl = 5;
        this.IIIIllIIllIIIIllIllIIIlIl(0.8552631f * 0.2923077f, 1.4166666f * 0.1764706f);
        this.lIlIllIlIlIIIllllIlIllIll = this.llllIIIIlIlIllIIIllllIIll / 2.0f;
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        float n2 = 78.0f * 0.0064102565f;
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = super.lIIIIlIIllIIlIIlIIIlIIllI(n);
        final int n3 = liiiIlIIllIIlIIlIIIlIIllI & 0xFF;
        final int n4 = liiiIlIIllIIlIIlIIIlIIllI >> 16 & 0xFF;
        int n5 = n3 + (int)(n2 * 15 * 16);
        if (n5 > 240) {
            n5 = 240;
        }
        return n5 | n4 << 16;
    }
    
    @Override
    public void x_() {
        super.x_();
        if (this.IlllIIIlIlllIllIlIIlllIlI > 0) {
            --this.IlllIIIlIlllIllIlIIlllIlI;
        }
        this.lIllIllIlIIllIllIlIlIIlIl = this.IIIlIIlIlIIIlllIIlIllllll;
        this.llIlIIIllIIIIlllIlIIIIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIllIlIlllIIlIIllIIlIIlII = this.IllIlIlIllllIlIIllllIIlll;
        this.lIlIlIllIIIIIIIIllllIIllI -= 0.02903225830873392 * 1.0333333015441895;
        if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)).IlIlIIIlllIIIlIlllIlIllIl() == Material.lIIIIllIIlIlIllIIIlIllIlI) {
            this.lIlIlIllIIIIIIIIllllIIllI = 0.22272727876162735 * 0.8979591727256775;
            this.IllIIlIIlllllIllIIIlllIII = (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (3.76f * 0.05319149f);
            this.IlllIIlllIIIIllIIllllIlIl = (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (0.3157895f * 0.6333333f);
            this.lIIIIlIIllIIlIIlIIIlIIllI("random.fizz", 0.35555556f * 1.125f, 2.0f + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (7.9f * 0.050632913f));
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, (this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + this.lllIlIIllllIIIIlIllIlIIII.IIIIllIIllIIIIllIllIIIlIl) / 2, this.IllIlIlIllllIlIIllllIIlll);
        final double n = 8;
        if (this.IIIllIllIlIlllllllIlIlIII < this.lIIIIlIIllIIlIIlIIIlIIllI - 20 + this.lIIIIlllIIlIlllllIlIllIII() % 100) {
            if (this.IlIlIIIlllIIIlIlllIlIllIl == null || this.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIIllIIIIllIllIIIlIl(this) > n * n) {
                this.IlIlIIIlllIIIlIlllIlIllIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, n);
            }
            this.IIIllIllIlIlllllllIlIlIII = this.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            final double n2 = (this.IlIlIIIlllIIIlIlllIlIllIl.IIIlIIlIlIIIlllIIlIllllll - this.IIIlIIlIlIIIlllIIlIllllll) / n;
            final double n3 = (this.IlIlIIIlllIIIlIlllIlIllIl.IllIlIIIIlllIIllIIlllIIlI + this.IlIlIIIlllIIIlIlllIlIllIl.lIIlIlIllIIlIIIlIIIlllIII() - this.IllIlIIIIlllIIllIIlllIIlI) / n;
            final double n4 = (this.IlIlIIIlllIIIlIlllIlIllIl.IllIlIlIllllIlIIllllIIlll - this.IllIlIlIllllIlIIllllIIlll) / n;
            final double sqrt = Math.sqrt(n2 * n2 + n3 * n3 + n4 * n4);
            final double n5 = 1.0 - sqrt;
            if (n5 > 0.0) {
                final double n6 = n5 * n5;
                this.IllIIlIIlllllIllIIIlllIII += n2 / sqrt * n6 * (1.0579710006713867 * 0.09452054918002493);
                this.lIlIlIllIIIIIIIIllllIIllI += n3 / sqrt * n6 * (0.8611111044883728 * 0.11612903315120385);
                this.IlllIIlllIIIIllIIllllIlIl += n4 / sqrt * n6 * (0.6760563254356384 * 0.14791666942182935);
            }
        }
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        float n7 = 1.3125f * 0.74666667f;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            n7 = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) - 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)).IlIlIIIlllllIIIlIlIlIllII * (0.7580645f * 1.292766f);
        }
        this.IllIIlIIlllllIllIIIlllIII *= n7;
        this.lIlIlIllIIIIIIIIllllIIllI *= 5.245882349281369 * 0.18681319057941437;
        this.IlllIIlllIIIIllIIllllIlIl *= n7;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            this.lIlIlIllIIIIIIIIllllIIllI *= -1.124999953433872 * 0.800000011920929;
        }
        ++this.lIIIIlIIllIIlIIlIIIlIIllI;
        ++this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (this.lIIIIIIIIIlIllIIllIlIIlIl >= 6000) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    @Override
    public boolean IllllllIllllIIlllIllllllI() {
        return this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lllIlIIllllIIIIlIllIlIIII, Material.IllIIIIIIIlIlIllllIIllIII, this);
    }
    
    @Override
    protected void IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI, (float)n);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        this.llIIIllIIllllIlIlIlIlIIll();
        this.IIIIllIlIIIllIlllIlllllIl -= (int)n;
        if (this.IIIIllIlIIIllIlllIlllllIl <= 0) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
        return false;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Health", (short)(byte)this.IIIIllIlIIIllIlllIlllllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Age", (short)this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Value", (short)this.IIIIllIIllIIIIllIllIIIlIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.IIIIllIlIIIllIlllIlllllIl = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Health") & 0xFF);
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Age");
        this.IIIIllIIllIIIIllIllIIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("Value");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.IlllIIIlIlllIllIlIIlllIlI == 0 && lIllIIIIlIIlIllIIIlIlIlll.lIllIllIIlIlIIIIllIllllll == 0) {
            lIllIIIIlIIlIllIIIlIlIlll.lIllIllIIlIlIIIIllIllllll = 2;
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI((Entity)lIllIIIIlIIlIllIIIlIlIlll, "random.orb", 0.6333333f * 0.15789475f, 1.325f * 0.37735847f * ((this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - this.IlIlllIIIIlIllIlllIlIIIll.nextFloat()) * (1.5f * 0.46666667f) + 10.333333f * 0.17419355f));
            lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(this, 1);
            lIllIIIIlIIlIllIIIlIlIlll.IllIllIIIlIIlllIIIllIllII(this.IIIIllIIllIIIIllIllIIIlIl);
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return (this.IIIIllIIllIIIIllIllIIIlIl >= 2477) ? 10 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 1237) ? 9 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 617) ? 8 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 307) ? 7 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 149) ? 6 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 73) ? 5 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 37) ? 4 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 17) ? 3 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 7) ? 2 : ((this.IIIIllIIllIIIIllIllIIIlIl >= 3) ? 1 : 0)))))))));
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return (n >= 2477) ? 2477 : ((n >= 1237) ? 1237 : ((n >= 617) ? 617 : ((n >= 307) ? 307 : ((n >= 149) ? 149 : ((n >= 73) ? 73 : ((n >= 37) ? 37 : ((n >= 17) ? 17 : ((n >= 7) ? 7 : ((n >= 3) ? 3 : 1)))))))));
    }
    
    @Override
    public boolean r_() {
        return false;
    }
}
