import java.util.Comparator;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIllllIIllllIllllIIIllI implements Comparator
{
    final /* synthetic */ lllllIIllllIllllIIIlIIllI lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIllllIIllllIllllIIIllI(final lllllIIllllIllllIIIlIIllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final ResourceLocation resourceLocation, final ResourceLocation resourceLocation2) {
        return resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI().compareTo(resourceLocation2.lIIIIlIIllIIlIIlIIIlIIllI());
    }
}
