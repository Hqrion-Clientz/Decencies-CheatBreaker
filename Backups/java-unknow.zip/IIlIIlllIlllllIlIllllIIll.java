import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlllIlllllIlIllllIIll
{
    private final IIlIllIIlIlIIIlIlIllIIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private long lIIIIIIIIIlIllIIllIlIIlIl;
    private lIlIlIlIlIIlIIlIIllIIIIIl IlllIIIlIlllIllIlIIlllIlI;
    private List IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIIlllIlllllIlIllllIIll(final IIlIllIIlIlIIIlIlIllIIIlI liiiIlIIllIIlIIlIIIlIIllI) {
        this.IlllIIIlIlllIllIlIIlllIlI = new lIlIlIlIlIIlIIlIIllIIIIIl();
        this.IIIIllIlIIIllIlllIlllllIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public lIlIIIlIllIIIIlIllIIIllII lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2) {
        n >>= 4;
        n2 >>= 4;
        final long n3 = ((long)n & 0xFFFFFFFFL) | ((long)n2 & 0xFFFFFFFFL) << 32;
        lIlIIIlIllIIIIlIllIIIllII lIlIIIlIllIIIIlIllIIIllII = (lIlIIIlIllIIIIlIllIIIllII)this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n3);
        if (lIlIIIlIllIIIIlIllIIIllII == null) {
            lIlIIIlIllIIIIlIllIIIllII = new lIlIIIlIllIIIIlIllIIIllII(this, n, n2);
            this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n3, lIlIIIlIllIIIIlIllIIIllII);
            this.IIIIllIlIIIllIlllIlllllIl.add(lIlIIIlIllIIIIlIllIIIllII);
        }
        lIlIIIlIllIIIIlIllIIIllII.IIIIllIIllIIIIllIllIIIlIl = llllIlIlllllIIlIIllllIIII.IllllllllIlIIIIIIIIllIIII();
        return lIlIIIlIllIIIIlIllIIIllII;
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2).lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        final long illllllllIlIIIIIIIIllIIII = llllIlIlllllIIlIIllllIIII.IllllllllIlIIIIIIIIllIIII();
        final long n = illllllllIlIIIIIIIIllIIII - this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n > 7500L || n < 0L) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = illllllllIlIIIIIIIIllIIII;
            for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl.size(); ++i) {
                final lIlIIIlIllIIIIlIllIIIllII lIlIIIlIllIIIIlIllIIIllII = this.IIIIllIlIIIllIlllIlllllIl.get(i);
                final long n2 = illllllllIlIIIIIIIIllIIII - lIlIIIlIllIIIIlIllIIIllII.IIIIllIIllIIIIllIllIIIlIl;
                if (n2 > 30000L || n2 < 0L) {
                    this.IIIIllIlIIIllIlllIlllllIl.remove(i--);
                    this.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(((long)lIlIIIlIllIIIIlIllIIIllII.IlllIIIlIlllIllIlIIlllIlI & 0xFFFFFFFFL) | ((long)lIlIIIlIllIIIIlIllIIIllII.IIIIllIlIIIllIlllIlllllIl & 0xFFFFFFFFL) << 32);
                }
            }
        }
    }
    
    public IIlIIlIIllIIllIlIIIIIIIlI[] IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2).lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
