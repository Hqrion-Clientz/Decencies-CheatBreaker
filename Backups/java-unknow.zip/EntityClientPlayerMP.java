import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class EntityClientPlayerMP extends IllIllIllIllllIllllIlIlll
{
    public final lIIIIIlIlIIIIIIIlIlIlllIl lIIIIIIIIIlIllIIllIlIIlIl;
    private final lllllIlllIIIlIIIIIIIIlllI IllIIIIIllllIlllIIlIIllIl;
    private double IlIllIllllIIIlIIIllIIIllI;
    private double llllIIllIIlIIllIIIllIlIlI;
    private double llIllllIIIIIlIllIlIIIllIl;
    private double llIlllIIllIlllIlIlIlIIIll;
    private float lIlIlIIllIlIIIIIlllIllIII;
    private float lllIIlIlIllIIlIllIIIIIlII;
    private boolean IlIIIlIIllIIIIllllIlIlIlI;
    private boolean lIIIIlllIlIlllIIIlllllIlI;
    private boolean lIllIlIlIIlIllIllllIllIIl;
    private int IIIlllIllIIllIllIlIIIllII;
    private boolean lllIlIIIllIIlIIlIlIllIIlI;
    private String IIlIIlIlIlIlllIIlIIlIIlII;
    List IlllIIIlIlllIllIlIIlllIlI;
    private boolean lIllIlllIIllIllllIllIIlll;
    
    public EntityClientPlayerMP(final Minecraft minecraft, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Session session, final lIIIIIlIlIIIIIIIlIlIlllIl liiiiiiiiIlIllIIllIlIIlIl, final lllllIlllIIIlIIIIIIIIlllI illIIIIIllllIlllIIlIIllIl) {
        super(minecraft, iiiiiIllIlIIIIlIlllIllllI, session, 0);
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IllIIIIIllllIlllIIlIIllIl = illIIIIIllllIlllIIlIIllIl;
    }
    
    @Override
    public void setProgress(final float n, final float n2) {
        if (IIlIIlIlIlIlllIIlIIlIIlII.lIllIllIlIIllIllIlIlIIlIl()) {
            final double iiIlIIlIlIIIlllIIlIllllll = this.IIIlIIlIlIIIlllIIlIllllll;
            final double illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
            final double illIlIlIllllIlIIllllIIlll = this.IllIlIlIllllIlIIllllIIlll;
            if (this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl && this.IlIIlIIIIlIIIIllllIIlIllI == null) {
                super.setProgress(n, n2);
            }
            else {
                this.IIIIllIlIIIllIlllIlllllIl(n, n2);
            }
            this.IlIlllIIIIllIllllIllIIlIl(this.IIIlIIlIlIIIlllIIlIllllll - iiIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI - illIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll - illIlIlIllllIlIIllllIIlll);
        }
        else {
            super.setProgress(n, n2);
        }
    }
    
    public void resetSize() {
        this.llIIllIllIlIlIlIllllllIII = false;
        if (!this.IlllIIIlIlllIllIlIIlllIlI.isEmpty()) {
            this.IlllIIIlIlllIllIlIIlllIlI.clear();
        }
    }
    
    @Override
    public void i_() {
        if (IIlIIlIlIlIlllIIlIIlIIlII.lIllIllIlIIllIllIlIlIIlIl()) {
            this.resetSize();
        }
        super.i_();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, float n3) {
        if (IIlIIlIlIlIlllIIlIIlIIlII.lIllIllIlIIllIllIlIlIIlIl()) {
            if ((this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl && this.IlIIlIIIIlIIIIllllIIlIllI == null) || this.lIIlIIIIIIIIllIIllIIlllIl()) {
                super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
                return;
            }
            n3 *= 1.5438596f * 1.3926138f;
            final float[] a_ = this.a_(n, n2);
            this.IlllIIIlIlllIllIlIIlllIlI.add(new float[] { a_[0] * n3, a_[1] * n3 });
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        }
    }
    
    @Override
    public void k_() {
        if (IIlIIlIlIlIlllIIlIIlIIlII.lIllIllIlIIllIllIlIlIIlIl()) {
            if (this.IllIIIIllllllIlllllIlIlll()) {
                final float n = this.IllllIllllIlIIIlIIIllllll * (0.016018774f * 1.0895523f);
                this.IllIIlIIlllllIllIIIlllIII += MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n) * (0.12380953f * 1.6153846f);
                this.IlllIIlllIIIIllIIllllIlIl -= MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n) * (0.23611112f * 0.84705883f);
            }
            this.lIllIlIlIIlIllIllllIllIIl();
            this.lIllIlllIIllIllllIllIIlll = true;
        }
        super.k_();
    }
    
    public double n_() {
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl);
    }
    
    public float o_() {
        float n = 1.0f;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            n = 1.0f - this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) - 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll)).IlIlIIIlllllIIIlIlIlIllII;
        }
        return n;
    }
    
    public float p_() {
        float n = 0.79505265f * 1.1445783f;
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            n = 19.4f * 0.028144334f;
            final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl) - 1, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll));
            if (block != null) {
                n = block.IlIlIIIlllllIIIlIlIlIllII * (2.142857f * 0.4246667f);
            }
        }
        return n;
    }
    
    public float llIlIIIlIIIIlIlllIlIIIIll() {
        final float p_ = this.p_();
        return this.IIIIIlIIIlllIIlIIllllIlll() * (0.5409836f * 0.30088037f / (p_ * p_ * p_));
    }
    
    public float[] a_(float n, float n2) {
        final float n3 = n * n + n2 * n2;
        final float[] array = { 0.0f, 0.0f };
        if (n3 >= 1.1111112f * 8.9999994E-5f) {
            float illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(n3);
            if (illlIIIlIlllIllIlIIlllIlI < 1.0f) {
                illlIIIlIlllIllIlIIlllIlI = 1.0f;
            }
            final float n4 = 1.0f / illlIIIlIlllIllIlIIlllIlI;
            n *= n4;
            n2 *= n4;
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll * (2.1470587f * 1.4632076f) / 180);
            final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll * (9.74977f * 0.32222223f) / 180);
            array[0] = n * liiiiiiiiIlIllIIllIlIIlIl - n2 * liiiIlIIllIIlIIlIIIlIIllI;
            array[1] = n2 * liiiiiiiiIlIllIIllIlIIlIl + n * liiiIlIIllIIlIIlIIIlIIllI;
        }
        return array;
    }
    
    public float IIIlIIllllIIllllllIlIIIll() {
        final float iiiiIlIIIlllIIlIIllllIlll = this.IIIIIlIIIlllIIlIIllllIlll();
        return this.lIlIlIllIIIIIIIIllllIIllI() ? (iiiiIlIIIlllIIlIIllllIlll * (2.1f * 0.5285715f)) : (iiiiIlIIIlllIIlIIllllIlll * (1.0f * 2.15f));
    }
    
    public float lllIIIIIlIllIlIIIllllllII() {
        return this.IIIIIlIIIlllIIlIIllllIlll() * (13.333333f * 0.16125001f);
    }
    
    private void lIIlIIllIIIIIlIllIIIIllII(final int n) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIIIIlllIIllIIlllIIlI - 3.133333387805356 * 0.06382978707551956 - this.lIlIllIlIlIIIllllIlIllIll);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll);
        final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3);
        if (block != null && block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
            for (int i = 0; i < n; ++i) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("blockcrack_" + IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(block) + "_" + this.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3), this.IIIlIIlIlIIIlllIIlIllllll + (new Random().nextFloat() - 0.41011236009987867 * 1.2191780805587769) * this.IlIIlIIlIllIIIIllIIllIlIl, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + 0.5199999809265137 * 0.1923076993614967, this.IllIlIlIllllIlIIllllIIlll + (new Random().nextFloat() - 0.7090908885002136 * 0.7051282256038316) * this.IlIIlIIlIllIIIIllIIllIlIl, -this.IllIIlIIlllllIllIIIlllIII * 4, 1.4220778824487261 * 1.0547945499420166, -this.IlllIIlllIIIIllIIllllIlIl * 4);
            }
        }
    }
    
    private void lIlIlIIllIlIIIIIlllIllIII() {
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && (!this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl((int)this.IIIlIIlIlIIIlllIIlIllllll, 0, (int)this.IllIlIlIllllIlIIllllIIlll) || !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl((int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIlIllllIlIIllllIIlll).IIIIllIlIIIllIlllIlllllIl)) {
            if (this.IllIlIIIIlllIIllIIlllIIlI > 0.0) {
                this.lIlIlIllIIIIIIIIllllIIllI = -0.17307691553817026 * 0.5777778029441833;
            }
            else {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
            }
        }
        else {
            this.lIlIlIllIIIIIIIIllllIIllI -= 0.12285714050336764 * 0.6511628031730652;
        }
        this.lIlIlIllIIIIIIIIllllIIllI *= 0.367499996200204 * 2.6666667461395264;
    }
    
    private void IllIIIIIIIlIlIllllIIllIII(final float n) {
        this.IllIIlIIlllllIllIIIlllIII *= n;
        this.IlllIIlllIIIIllIIllllIlIl *= n;
    }
    
    private void lllIIlIlIllIIlIllIIIIIlII() {
        if (this.m_()) {
            final float n = 1.0819672f * 0.13863637f;
            if (this.IllIIlIIlllllIllIIIlllIII < -n) {
                this.IllIIlIIlllllIllIIIlllIII = -n;
            }
            if (this.IllIIlIIlllllIllIIIlllIII > n) {
                this.IllIIlIIlllllIllIIIlllIII = n;
            }
            if (this.IlllIIlllIIIIllIIllllIlIl < -n) {
                this.IlllIIlllIIIIllIIllllIlIl = -n;
            }
            if (this.IlllIIlllIIIIllIIllllIlIl > n) {
                this.IlllIIlllIIIIllIIllllIlIl = n;
            }
            this.IllllllIllllIIlllIllllllI = 0.0f;
            if (this.lIlIlIllIIIIIIIIllllIIllI < -0.15937499940628186 * 0.9411764740943909) {
                this.lIlIlIllIIIIIIIIllllIIllI = -0.024999999999999998 * 6.0;
            }
            if (this.lIlIlIllIIIIIIIIllllIIllI() && this.lIlIlIllIIIIIIIIllllIIllI < 0.0) {
                this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
            }
        }
    }
    
    private void IlIIIlIIllIIIIllllIlIlIlI() {
        if (this.lIIIlllIlIlllIIIIIIIIIlII && this.m_()) {
            this.lIlIlIllIIIIIIIIllllIIllI = 0.07111111111111111 * 2.8125;
        }
    }
    
    private void lIIIIlllIlIlllIIIlllllIlI() {
        this.IIllIllIlIIlllllIlIIIlIll = this.IlIlIIIlllIlIllIlIIIlllIl;
        final double n = this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl;
        final double n2 = this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII;
        float n3 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n2 * n2) * 4;
        if (n3 > 1.0f) {
            n3 = 1.0f;
        }
        this.IlIlIIIlllIlIllIlIIIlllIl += (n3 - this.IlIlIIIlllIlIllIlIIIlllIl) * (0.45714286f * 0.875f);
        this.llIIlllIlIIlIIIIIlIllllll += this.IlIlIIIlllIlIllIlIIIlllIl;
    }
    
    private void IllIIIIIIIlIlIllllIIllIII(final float n, final float n2) {
        final double illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, 0.040727273f * 0.98214287f);
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        this.IllIIlIIlllllIllIIIlllIII *= 2.9090908893868948 * 0.2750000059604645;
        this.lIlIlIllIIIIIIIIllllIIllI *= 1.7407407760620117 * 0.4595744656081004;
        this.IlllIIlllIIIIllIIllllIlIl *= 0.5797101259231567 * 1.38000006580353;
        this.lIlIlIllIIIIIIIIllllIIllI -= 7.833333492279053 * 0.0025531914375550406;
        if (this.lIIIlllIlIlllIIIIIIIIIlII && this.IIIIllIlIIIllIlllIlllllIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI + 3.21052622795105 * 0.18688525844088072 - this.IllIlIIIIlllIIllIIlllIIlI + illIlIIIIlllIIllIIlllIIlI, this.IlllIIlllIIIIllIIllllIlIl)) {
            this.lIlIlIllIIIIIIIIllllIIllI = 1.7297297716140747 * 0.17343750269210426;
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final float n, final float n2) {
        if ((this.lIIlIIIIIIIIllIIllIIlllIl() && !this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl) || (this.IlIlllIllIlIllIlllIlllIll() && !this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl)) {
            super.setProgress(n, n2);
        }
        else {
            final float p_ = this.p_();
            this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, this.llIlIIIlIIIIlIlllIlIIIIll());
            this.lllIIlIlIllIIlIllIIIIIlII();
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.IlIIIlIIllIIIIllllIlIlIlI();
            this.lIlIlIIllIlIIIIIlllIllIII();
            this.IllIIIIIIIlIlIllllIIllIII(p_);
            this.lIIIIlllIlIlllIIIlllllIlI();
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final float n, final float n2) {
        if (this.IlIlllIllIlIllIlllIlllIll() && !this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl) {
            super.setProgress(n, n2);
            return;
        }
        if (this.lIIlIIIIIIIIllIIllIIlllIl() && !this.IlllIIIllIlIlIIIllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (!(boolean)IIlIIlIlIlIlllIIlIIlIIlII.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl()) {
                super.setProgress(n, n2);
                return;
            }
            this.lIIIIllIIlIlIllIIIlIllIlI(n, n2);
        }
        else {
            final float n3 = (n != 0.0f || n2 != 0.0f) ? this.IIIlIIllllIIllllllIlIIIll() : 0.0f;
            final float[] a_ = this.a_(n, n2);
            final boolean b = this.lIIIIlllIIlIlllllIlIllIII && !this.llIIllIllIlIlIlIllllllIII;
            final float p_ = this.p_();
            if (b) {
                this.IllIIIIIIIlIlIllllIIllIII(p_);
                final double doubleValue = (double)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl();
                if (n3 != 0.0f) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(n3, a_[0], a_[1], doubleValue * (this.llIlIIIlIIIIlIlllIlIIIIll() * (1.2989583f * 1.6551725f) / n3));
                }
                if (!this.IlllIIIlIlllIllIlIIlllIlI.isEmpty()) {
                    final float n4 = n3 / this.lllIIIIIlIllIlIIIllllllII();
                    for (final float[] array : this.IlllIIIlIlllIllIlIIlllIlI) {
                        this.IllIIlIIlllllIllIIIlllIII += array[0] * n4;
                        this.IlllIIlllIIIIllIIllllIlIl += array[1] * n4;
                    }
                }
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n3, a_[0], a_[1], (double)IIlIIlIlIlIlllIIlIIlIIlII.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIlIIIllIlllIlllllIl());
                if ((boolean)IIlIIlIlIlIlllIIlIIlIIlII.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl() && (double)IIlIIlIlIlIlllIIlIIlIIlII.IIIllIllIlIlllllllIlIlIII.IIIIllIlIIIllIlllIlllllIl() > 0.0 && this.llIIllIllIlIlIlIllllllIII && this.lIlIlIllIIIIIIIIllllIIllI < 0.0 && this.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(this.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl))) {
                    this.lIlIlIllIIIIIIIIllllIIllI *= (double)IIlIIlIlIlIlllIIlIIlIIlII.IIIllIllIlIlllllllIlIlIII.IIIIllIlIIIllIlllIlllllIl();
                }
            }
            this.lllIIlIlIllIIlIllIIIIIlII();
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.IlIIIlIIllIIIIllllIlIlIlI();
            this.lIlIlIIllIlIIIIIlllIllIII();
        }
        this.lIIIIlllIlIlllIIIlllllIlI();
    }
    
    private void lIllIlIlIIlIllIllllIllIIl() {
        this.IIIlIIllllIIllllllIlIIIll(this.lllIIIIIlIllIlIIIllllllII());
        if (!this.IIIlllIllIIllIllIlIIIllII()) {
            this.lllIIIIIlIllIlIIIllllllII(this.lllIIIIIlIllIlIIIllllllII());
        }
    }
    
    private boolean IIIlllIllIIllIllIlIIIllII() {
        if ((boolean)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl() && this.lIlIlIllIIIIIIIIllllIIllI()) {
            final double n_ = this.n_();
            final float lllIIIIIlIllIlIIIllllllII = this.lllIIIIIlIllIlIIIllllllII();
            if (n_ > lllIIIIIlIllIlIIIllllllII) {
                double n = n_ / lllIIIIIlIllIlIIIllllllII * (0.4166666567325592 * 1.2000000286102301);
                if (n > 1.0) {
                    n = 1.0;
                }
                this.lIlIlIllIIIIIIIIllllIIllI += n * n_ * (float)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl();
                if ((float)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl() > 0.0f) {
                    final float n2 = 1.0f / (float)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl();
                    this.IllIIlIIlllllIllIIIlllIII *= n2;
                    this.IlllIIlllIIIIllIIllllIlIl *= n2;
                }
                this.lIIlIIllIIIIIlIllIIIIllII(30);
                return true;
            }
        }
        return false;
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final double n) {
        this.IllIIlIIlllllIllIIIlllIII *= n;
        this.lIlIlIllIIIIIIIIllllIIllI *= n;
        this.IlllIIlllIIIIllIIllllIlIl *= n;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final double n3, final double n4, final double n5) {
        final float n6 = n - n2;
        if (n6 > 0.0f) {
            float n7 = (float)(n5 * n * (6.0714287757873535 * 0.008235293963169974));
            if (n7 > n6) {
                n7 = n6;
            }
            this.IllIIlIIlllllIllIIIlllIII += n7 * n3;
            this.IlllIIlllIIIIllIIllllIlIl += n7 * n4;
        }
    }
    
    private void lIIIIllIIlIlIllIIIlIllIlI(final float n, final float n2) {
        final double illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        final float n3 = (n != 0.0f || n2 != 0.0f) ? this.lllIIIIIlIllIlIIIllllllII() : 0.0f;
        final float[] a_ = this.a_(n, n2);
        final boolean b = this.llIIllIllIlIlIlIllllllIII && this.IIIIllIlIIIllIlllIlllllIl(0.0, 1.0, 0.0);
        final double n_ = this.n_();
        if (!b || n_ < 0.0566526315393012 * 1.3768116235733032) {
            this.IllIIIIIIIlIlIllllIIllIII(n, n2);
        }
        else {
            if (n_ > 0.03947368264198303 * 2.2800000905990636) {
                this.lIIIIIIIIIlIllIIllIlIIlIl((double)IIlIIlIlIlIlllIIlIIlIIlII.IllIIIIIIIlIlIllllIIllIII.IIIIllIlIIIllIlllIlllllIl());
            }
            if (n_ > 0.17241379618644714 * 0.5683999898362162) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n3, a_[0], a_[1], (double)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl());
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI(12.2f * 0.008032787f, a_[0], a_[1], (double)IIlIIlIlIlIlllIIlIIlIIlII.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl());
            }
            this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
            this.lIlIlIllIIIIIIIIllllIIllI = 0.0;
        }
        if (this.lIIIlllIlIlllIIIIIIIIIlII && this.IIIIllIlIIIllIlllIlllllIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI + 2.188235327364251 * 0.27419355511665344 - this.IllIlIIIIlllIIllIIlllIIlI + illIlIIIIlllIIllIIlllIIlI, this.IlllIIlllIIIIllIIllllIlIl)) {
            this.lIlIlIllIIIIIIIIllllIIllI = 1.600000023841858 * 0.18750000465661282;
        }
        if (!this.IlllIIIlIlllIllIlIIlllIlI.isEmpty()) {
            final float n4 = n3 / this.lllIIIIIlIllIlIIIllllllII();
            for (final float[] array : this.IlllIIIlIlllIllIlIIlllIlI) {
                this.IllIIlIIlllllIllIIIlllIII += array[0] * n4;
                this.IlllIIlllIIIIllIIllllIlIl += array[1] * n4;
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final double n2, final double n3, final double n4) {
        final double n5 = n - (this.IllIIlIIlllllIllIIIlllIII * n2 + this.IlllIIlllIIIIllIIllllIlIl * n3);
        if (n5 <= 0.0) {
            return;
        }
        double n6 = n4 * n / this.p_() * (1.121212124824524 * 0.04459459511542773);
        if (n6 > n5) {
            n6 = n5;
        }
        this.IllIIlIIlllllIllIIIlllIII += n6 * n2;
        this.IlllIIlllIIIIllIIllllIlIl += n6 * n3;
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final double n2, final double n3, final double n4) {
        float n5 = n;
        final float n6 = (float)(double)IIlIIlIlIlIlllIIlIIlIIlII.lIIlIlIllIIlIIIlIIIlllIII.IIIIllIlIIIllIlllIlllllIl();
        if (n5 > n6) {
            n5 = n6;
        }
        final double n7 = n5 - (this.IllIIlIIlllllIllIIIlllIII * n2 + this.IlllIIlllIIIIllIIllllIlIl * n3);
        if (n7 <= 0.0) {
            return;
        }
        double n8 = n4 * n * (0.4054054021835327 * 0.12333333615130851);
        if (n8 > n7) {
            n8 = n7;
        }
        this.IllIIlIIlllllIllIIIlllIII += n8 * n2;
        this.IlllIIlllIIIIllIIllllIlIl += n8 * n3;
    }
    
    private void lllIlIIIllIIlIIlIlIllIIlI() {
        final double n_ = this.n_();
        if (n_ <= 0.0) {
            return;
        }
        final float n = 0.0f;
        final float n2 = 1.0f;
        final float n3 = 1.7560976f * 0.0028472221f;
        double n4 = n_ - (float)(n + ((n_ < n3) ? n3 : n_) * (n2 * this.o_()) * (0.0026666667064030964 * 18.75));
        if (n4 < 0.0) {
            n4 = 0.0;
        }
        if (n4 != n_) {
            final double n5 = n4 / n_;
            this.IllIIlIIlllllIllIIIlllIII *= n5;
            this.IlllIIlllIIIIllIIllllIlIl *= n5;
        }
    }
    
    private void IIIlIIllllIIllllllIlIIIll(final float n) {
        float floatValue = (float)IIlIIlIlIlIlllIIlIIlIIlII.IIIIllIlIIIllIlllIlllllIl.IIIIllIlIIIllIlllIlllllIl();
        float floatValue2 = (float)IIlIIlIlIlIlllIIlIIlIIlII.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl();
        if (IIlIIlIlIlIlllIIlIIlIIlII.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl()) {
            floatValue = 1.0f;
            floatValue2 = 1.0f;
        }
        final float n2 = (float)this.n_();
        final float n3 = n * floatValue;
        if (n2 > n3) {
            if (floatValue2 != 1.0f) {
                final float n4 = ((n2 - n3) * floatValue2 + n3) / n2;
                this.IllIIlIIlllllIllIIIlllIII *= n4;
                this.IlllIIlllIIIIllIIllllIlIl *= n4;
            }
            this.lIIlIIllIIIIIlIllIIIIllII(10);
        }
    }
    
    private void lllIIIIIlIllIlIIIllllllII(final float n) {
        if (IIlIIlIlIlIlllIIlIIlIIlII.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl()) {
            return;
        }
        final float floatValue = (float)IIlIIlIlIlIlllIIlIIlIIlII.IlllIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl();
        final float n2 = (float)this.n_();
        final float n3 = n * floatValue;
        if (n2 > n3 && n3 != 0.0f) {
            final float n4 = n3 / n2;
            this.IllIIlIIlllllIllIIIlllIII *= n4;
            this.IlllIIlllIIIIllIIllllIlIl *= n4;
            this.lIIlIIllIIIIIlIllIIIIllII(30);
        }
    }
    
    private void IIlIIlIlIlIlllIIlIIlIIlII() {
        this.lIllIlllIIllIllllIllIIlll = false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        return false;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final float n) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(entity);
        if (entity instanceof lllIllIIIllllIlIlllllllll) {
            this.IIIIllIIllIIIIllIllIIIlIl.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(new IlllllIIIlIIlIlIlIIllIlIl(this, (lllIllIIIllllIlIlllllllll)entity));
        }
    }
    
    @Override
    public void x_() {
        if (this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), 0, MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll))) {
            super.x_();
            if (this.llllIIIIIlIlIlIlIllIIIIII()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new lIIllllllIlllIlllIIIIIlll(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII, this.lIIIIlllIIlIlllllIlIllIII));
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IllllIIlllIIIlIlllllIlIII(this.IlIIlIIllIllIIIIIlllIIlll, this.llIIIIlIlIIIllIllIIIIllII, this.IIIIllIlIIIllIlllIlllllIl.lIIIIllIIlIlIllIIIlIllIlI, this.IIIIllIlIIIllIlllIlllllIl.IlllIllIlIIIIlIIlIIllIIIl));
            }
            else {
                this.runTick();
            }
        }
    }
    
    public void runTick() {
        final boolean illIIIIllllllIlllllIlIlll = this.IllIIIIllllllIlllllIlIlll();
        if (illIIIIllllllIlllllIlIlll != this.lIllIlIlIIlIllIllllIllIIl) {
            if (illIIIIllllllIlllllIlIlll) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 4));
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 5));
            }
            this.lIllIlIlIIlIllIllllIllIIl = illIIIIllllllIlllllIlIlll;
        }
        final boolean lIlIlIllIIIIIIIIllllIIllI = this.lIlIlIllIIIIIIIIllllIIllI();
        if (lIlIlIllIIIIIIIIllllIIllI != this.lIIIIlllIlIlllIIIlllllIlI) {
            if (lIlIlIllIIIIIIIIllllIIllI) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 1));
            }
            else {
                this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 2));
            }
            this.lIIIIlllIlIlllIIIlllllIlI = lIlIlIllIIIIIIIIllllIIllI;
        }
        final double n = this.IIIlIIlIlIIIlllIIlIllllll - this.IlIllIllllIIIlIIIllIIIllI;
        final double n2 = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl - this.llllIIllIIlIIllIIIllIlIlI;
        final double n3 = this.IllIlIlIllllIlIIllllIIlll - this.llIlllIIllIlllIlIlIlIIIll;
        final double n4 = this.IllllIllllIlIIIlIIIllllll - this.lIlIlIIllIlIIIIIlllIllIII;
        final double n5 = this.IllIIlllIllIlIllIlIIIIIII - this.lllIIlIlIllIIlIllIIIIIlII;
        boolean b = n * n + n2 * n2 + n3 * n3 > 4.4999999999999996E-5 * 20.0 || this.IIIlllIllIIllIllIlIIIllII >= 20;
        final boolean b2 = n4 != 0.0 || n5 != 0.0;
        if (this.IlIIlIIIIlIIIIllllIIlIllI != null) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IllIIIIIllllIlIlllllIIIIl(this.IllIIlIIlllllIllIIIlllIII, -999, -999, this.IlllIIlllIIIIllIIllllIlIl, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII, this.lIIIIlllIIlIlllllIlIllIII));
            b = false;
        }
        else if (b && b2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IllIIIIIllllIlIlllllIIIIl(this.IIIlIIlIlIIIlllIIlIllllll, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII, this.lIIIIlllIIlIlllllIlIllIII));
        }
        else if (b) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new lIIIIllllIIllllIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.lIIIIlllIIlIlllllIlIllIII));
        }
        else if (b2) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new lIIllllllIlllIlllIIIIIlll(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII, this.lIIIIlllIIlIlllllIlIllIII));
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IlIIllIIIIIIlIIIllIIllIIl(this.lIIIIlllIIlIlllllIlIllIII));
        }
        ++this.IIIlllIllIIllIllIlIIIllII;
        this.IlIIIlIIllIIIIllllIlIlIlI = this.lIIIIlllIIlIlllllIlIllIII;
        if (b) {
            this.IlIllIllllIIIlIIIllIIIllI = this.IIIlIIlIlIIIlllIIlIllllll;
            this.llllIIllIIlIIllIIIllIlIlI = this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl;
            this.llIllllIIIIIlIllIlIIIllIl = this.IllIlIIIIlllIIllIIlllIIlI;
            this.llIlllIIllIlllIlIlIlIIIll = this.IllIlIlIllllIlIIllllIIlll;
            this.IIIlllIllIIllIllIlIIIllII = 0;
        }
        if (b2) {
            this.lIlIlIIllIlIIIIIlllIllIII = this.IllllIllllIlIIIlIIIllllll;
            this.lllIIlIlIllIIlIllIIIIIlII = this.IllIIlllIllIlIllIlIIIIIII;
        }
    }
    
    @Override
    public lllIIIIIlIllllIIIlllIllIl lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new lIllIIIIllllIlIlIIIIllIIl(b ? 3 : 4, 0, 0, 0, 0));
        return null;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllllIIIlllIllIl lllIIIIIlIllllIIIlllIllIl) {
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        if (s.equals("/debug")) {
            CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIllIllIlIlllllllIlIlIII = !CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIllIllIlIlllllllIlIlIII;
            final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI = new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "[C" + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + "B" + IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "] " + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII);
            lIlIIllIIlIIIIIlIllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.IllIIIIIIIlIlIllllIIllIII + "Debug: " + CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIllIllIlIlllllllIlIlIII));
            Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIIllIIlIIIIIlIllIllllI);
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IlllIIIIIIIlIIIlIIIlllIlI(s));
        }
    }
    
    @Override
    public void swingItem() {
        super.swingItem();
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new llIIIllIlIIIIlIllIlllIlII(this, 1));
    }
    
    @Override
    public void IllIllIIIlIIlllIIIllIllII() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IlIIIIIlIlllllIlIlllIIlll(IIIlIlIIllllIlllllllIIlll.lIIIIlIIllIIlIIlIIIlIIllI));
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (!this.llllIIlIlIllIllllIIIIllll()) {
            this.IlllIllIlIIIIlIIlIIllIIIl(this.getHealth() - n);
        }
    }
    
    @Override
    public void handleInput() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IlIIIllIllllllIlIIIlIIlll(this.llIIIlllllIlllIIllIlIIlII.IIIIllIlIIIllIlllIlllllIl));
        this.lIIlIIllIIIIIlIllIIIIllII();
    }
    
    public void lIIlIIllIIIIIlIllIIIIllII() {
        this.inventory.lIIIIIIIIIlIllIIllIlIIlIl((lIlIlIlIlIllllIlllIIIlIlI)null);
        super.handleInput();
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final float n) {
        if (this.lllIlIIIllIIlIIlIlIllIIlI) {
            super.IIIIllIlIIIllIlllIlllllIl(n);
        }
        else {
            this.IlllIllIlIIIIlIIlIIllIIIl(n);
            this.lllIlIIIllIIlIIlIlIllIIlI = true;
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIlIIlIIllIIIIIllll liiIlIlIlIIlIIllIIIIIllll, final int n) {
        if (liiIlIlIlIIlIIllIIIIIllll != null && liiIlIlIlIIlIIllIIIIIllll.IlIlIIIlllIIIlIlllIlIllIl) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIlIIlIIllIIIIIllll, n);
        }
    }
    
    @Override
    public void lIIlllIIlIlllllllllIIIIIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new llIlIllIIllllllllllIIIIlI(this.IlllIIIllIlIlIIIllIIIlIlI));
    }
    
    @Override
    protected void q_() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 6, (int)(this.IllIIlllIllIlIllIlIIIIIII() * 100)));
    }
    
    public void sendHorseInteraction() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new IIIIIIIIIIIIllIllIIIlIllI(this, 7));
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final String iIlIIlIlIlIlllIIlIIlIIlII) {
        this.IIlIIlIlIlIlllIIlIIlIIlII = iIlIIlIlIlIlllIIlIIlIIlII;
    }
    
    public String lIllIlIlllIIlIIllIIlIIlII() {
        return this.IIlIIlIlIlIlllIIlIIlIIlII;
    }
    
    public lllllIlllIIIlIIIIIIIIlllI IIIlIIlIlIIIlllIIlIllllll() {
        return this.IllIIIIIllllIlllIIlIIllIl;
    }
}
