// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIllIlllIllIlIlIllII extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private String[] IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIlIIllIlllIllIlIlIllII() {
    }
    
    public IIlIlIIllIlllIllIlIlIllII(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final String[] array) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = new String[] { array[0], array[1], array[2], array[3] };
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readInt();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readShort();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readInt();
        this.IIIIllIlIIIllIlllIlllllIl = new String[4];
        for (int i = 0; i < 4; ++i) {
            this.IIIIllIlIIIllIlllIlllllIl[i] = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(15);
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeShort(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI);
        for (int i = 0; i < 4; ++i) {
            lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl[i]);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public String[] IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
