import org.apache.logging.log4j.LogManager;
import javax.vecmath.Matrix4f;
import org.lwjgl.BufferUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllIIIllIIIIIIIllIIl
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final int IIIIllIlIIIllIlllIlllllIl;
    private final IntBuffer IIIIllIIllIIIIllIllIIIlIl;
    private final FloatBuffer IlIlIIIlllIIIlIlllIlIllIl;
    private final String IIIllIllIlIlllllllIlIlIII;
    private boolean IllIIIIIIIlIlIllllIIllIII;
    private final lIIIllIllIllIIIIllllIIlII lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIlIlIllIIIllIIIIIIIllIIl(final String iiIllIllIlIlllllllIlIlIII, final int iiiIllIlIIIllIlllIlllllIl, final int illlIIIlIlllIllIlIIlllIlI, final lIIIllIllIllIIIIllllIIlII liiiIllIIlIlIllIIIlIllIlI) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        if (iiiIllIlIIIllIlllIlllllIl <= 3) {
            this.IIIIllIIllIIIIllIllIIIlIl = BufferUtils.createIntBuffer(illlIIIlIlllIllIlIIlllIlI);
            this.IlIlIIIlllIIIlIlllIlIllIl = null;
        }
        else {
            this.IIIIllIIllIIIIllIllIIIlIl = null;
            this.IlIlIIIlllIIIlIlllIlIllIl = BufferUtils.createFloatBuffer(illlIIIlIlllIllIlIIlllIlI);
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = -1;
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    private void IlllIIIlIlllIllIlIIlllIlI() {
        this.IllIIIIIIIlIlIllllIIllIII = true;
        if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
            this.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl();
        }
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        int n = -1;
        if (s.equals("int")) {
            n = 0;
        }
        else if (s.equals("float")) {
            n = 4;
        }
        else if (s.startsWith("matrix")) {
            if (s.endsWith("2x2")) {
                n = 8;
            }
            else if (s.endsWith("3x3")) {
                n = 9;
            }
            else if (s.endsWith("4x4")) {
                n = 10;
            }
        }
        return n;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(0, n);
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(0, n);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(1, n2);
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(0, n);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(1, n2);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(2, n3);
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(n);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(n2);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(n3);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(n4);
        this.IlIlIIIlllIIIlIlllIlIllIl.flip();
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float n, final float n2, final float n3, final float n4) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        if (this.IIIIllIlIIIllIlllIlllllIl >= 4) {
            this.IlIlIIIlllIIIlIlllIlIllIl.put(0, n);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 5) {
            this.IlIlIIIlllIIIlIlllIlIllIl.put(1, n2);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 6) {
            this.IlIlIIIlllIIIlIlllIlIllIl.put(2, n3);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 7) {
            this.IlIlIIIlllIIIlIlllIlIllIl.put(3, n4);
        }
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        this.IIIIllIIllIIIIllIllIIIlIl.position(0);
        if (this.IIIIllIlIIIllIlllIlllllIl >= 0) {
            this.IIIIllIIllIIIIllIllIIIlIl.put(0, n);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 1) {
            this.IIIIllIIllIIIIllIllIIIlIl.put(1, n2);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 2) {
            this.IIIIllIIllIIIIllIllIIIlIl.put(2, n3);
        }
        if (this.IIIIllIlIIIllIlllIlllllIl >= 3) {
            this.IIIIllIIllIIIIllIllIIIlIl.put(3, n4);
        }
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float[] src) {
        if (src.length < this.IlllIIIlIlllIllIlIIlllIlI) {
            IIlIlIllIIIllIIIIIIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI.warn("Uniform.set called with a too-small value array (expected " + this.IlllIIIlIlllIllIlIIlllIlI + ", got " + src.length + "). Ignoring.");
        }
        else {
            this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
            this.IlIlIIIlllIIIlIlllIlIllIl.put(src);
            this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
            this.IlllIIIlIlllIllIlIIlllIlI();
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final float n9, final float n10, final float n11, final float n12, final float n13, final float n14, final float n15, final float n16) {
        this.IlIlIIIlllIIIlIlllIlIllIl.position(0);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(0, n);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(1, n2);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(2, n3);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(3, n4);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(4, n5);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(5, n6);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(6, n7);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(7, n8);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(8, n9);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(9, n10);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(10, n11);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(11, n12);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(12, n13);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(13, n14);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(14, n15);
        this.IlIlIIIlllIIIlIlllIlIllIl.put(15, n16);
        this.IlllIIIlIlllIllIlIIlllIlI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Matrix4f matrix4f) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(matrix4f.m00, matrix4f.m01, matrix4f.m02, matrix4f.m03, matrix4f.m10, matrix4f.m11, matrix4f.m12, matrix4f.m13, matrix4f.m20, matrix4f.m21, matrix4f.m22, matrix4f.m23, matrix4f.m30, matrix4f.m31, matrix4f.m32, matrix4f.m33);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (!this.IllIIIIIIIlIlIllllIIllIII) {}
        this.IllIIIIIIIlIlIllllIIllIII = false;
        if (this.IIIIllIlIIIllIlllIlllllIl <= 3) {
            this.IIIIllIlIIIllIlllIlllllIl();
        }
        else if (this.IIIIllIlIIIllIlllIlllllIl <= 7) {
            this.IIIIllIIllIIIIllIllIIIlIl();
        }
        else {
            if (this.IIIIllIlIIIllIlllIlllllIl > 10) {
                IIlIlIllIIIllIIIIIIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI.warn("Uniform.upload called, but type value (" + this.IIIIllIlIIIllIlllIlllllIl + ") is not a valid type. Ignoring.");
                return;
            }
            this.IlIlIIIlllIIIlIlllIlIllIl();
        }
    }
    
    private void IIIIllIlIIIllIlllIlllllIl() {
        switch (this.IIIIllIlIIIllIlllIlllllIl) {
            case 0: {
                OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl);
                break;
            }
            case 1: {
                OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl);
                break;
            }
            case 2: {
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl);
                break;
            }
            case 3: {
                OpenGlHelper.IIIIllIlIIIllIlllIlllllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl);
                break;
            }
            default: {
                IIlIlIllIIIllIIIIIIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI.warn("Uniform.upload called, but count value (" + this.IlllIIIlIlllIllIlIIlllIlI + ") is  not in the range of 1 to 4. Ignoring.");
                break;
            }
        }
    }
    
    private void IIIIllIIllIIIIllIllIIIlIl() {
        switch (this.IIIIllIlIIIllIlllIlllllIl) {
            case 4: {
                OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            case 5: {
                OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            case 6: {
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            case 7: {
                OpenGlHelper.IIIIllIlIIIllIlllIlllllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            default: {
                IIlIlIllIIIllIIIIIIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI.warn("Uniform.upload called, but count value (" + this.IlllIIIlIlllIllIlIIlllIlI + ") is not in the range of 1 to 4. Ignoring.");
                break;
            }
        }
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        switch (this.IIIIllIlIIIllIlllIlllllIl) {
            case 8: {
                OpenGlHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, true, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            case 9: {
                OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, true, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
            case 10: {
                OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(this.lIIIIIIIIIlIllIIllIlIIlIl, true, this.IlIlIIIlllIIIlIlllIlIllIl);
                break;
            }
        }
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
