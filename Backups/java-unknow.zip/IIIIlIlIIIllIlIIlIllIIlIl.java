// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIIIllIlIIlIllIIlIl extends IllllIllIllIIIIIIlIllIIll
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIlIlIIIllIlIIlIllIIlIl(final boolean liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIIIlIlIIIllIlIIlIllIIlIl() {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeBoolean(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readBoolean();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll liIlllIIlllIlIllIIlIIIIll) {
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
}
