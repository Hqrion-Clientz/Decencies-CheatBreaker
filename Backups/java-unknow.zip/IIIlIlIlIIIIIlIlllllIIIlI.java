// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIlIlIlIIIIIlIlllllIIIlI
{
    lIIIIlIIllIIlIIlIIIlIIllI("CLIENT", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("SERVER", 1);
    
    private IIIlIlIlIIIIIlIlllllIIIlI(final String name, final int ordinal) {
    }
}
