// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIIlIllIIlIllIllIlll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "playsound";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.playsound.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length < 2) {
            throw new IIllllIlIlIIlllIlIIllIIll(this.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII), new Object[0]);
        }
        final int n = 0;
        int n2 = n + 1;
        final String s = array[n];
        final llIIIIIIlIlllllIIllllIlII iiiIllIlIIIllIlllIlllllIl = IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[n2++]);
        double liiiIlIIllIIlIIlIIIlIIllI = iiiIllIlIIIllIlllIlllllIl.IIIlllIIIllIllIlIIIIIIlII().lIIIIlIIllIIlIIlIIIlIIllI;
        double liiiIlIIllIIlIIlIIIlIIllI2 = iiiIllIlIIIllIlllIlllllIl.IIIlllIIIllIllIlIIIIIIlII().lIIIIIIIIIlIllIIllIlIIlIl;
        double liiiIlIIllIIlIIlIIIlIIllI3 = iiiIllIlIIIllIlllIlllllIl.IIIlllIIIllIllIlIIIIIIlII().IlllIIIlIlllIllIlIIlllIlI;
        double liiiIlIIllIIlIIlIIIlIIllI4 = 1.0;
        double liiiIlIIllIIlIIlIIIlIIllI5 = 1.0;
        double liiiIlIIllIIlIIlIIIlIIllI6 = 0.0;
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI, array[n2++]);
        }
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI2 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI2, array[n2++], 0, 0);
        }
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI3 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, liiiIlIIllIIlIIlIIIlIIllI3, array[n2++]);
        }
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI4 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[n2++], 0.0, 1.954813441024413E38 * 1.7407407760620117);
        }
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI5 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[n2++], 0.0, 2);
        }
        if (array.length > n2) {
            liiiIlIIllIIlIIlIIIlIIllI6 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[n2++], 0.0, 1.0);
        }
        if (iiiIllIlIIIllIlllIlllllIl.IIIllIllIlIlllllllIlIlIII(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3) > ((liiiIlIIllIIlIIlIIIlIIllI4 > 1.0) ? (liiiIlIIllIIlIIlIIIlIIllI4 * 16) : 16)) {
            if (liiiIlIIllIIlIIlIIIlIIllI6 <= 0.0) {
                throw new lIllllIllIIIllIlIlIlIIIII("commands.playsound.playerTooFar", new Object[] { iiiIllIlIIIllIlllIlllllIl.IlIlIIIlllllIIIlIlIlIllII() });
            }
            final double n3 = liiiIlIIllIIlIIlIIIlIIllI - iiiIllIlIIIllIlllIlllllIl.IIIlIIlIlIIIlllIIlIllllll;
            final double n4 = liiiIlIIllIIlIIlIIIlIIllI2 - iiiIllIlIIIllIlllIlllllIl.IllIlIIIIlllIIllIIlllIIlI;
            final double n5 = liiiIlIIllIIlIIlIIIlIIllI3 - iiiIllIlIIIllIlllIlllllIl.IllIlIlIllllIlIIllllIIlll;
            final double sqrt = Math.sqrt(n3 * n3 + n4 * n4 + n5 * n5);
            double iiIlIIlIlIIIlllIIlIllllll = iiiIllIlIIIllIlllIlllllIl.IIIlIIlIlIIIlllIIlIllllll;
            double illIlIIIIlllIIllIIlllIIlI = iiiIllIlIIIllIlllIlllllIl.IllIlIIIIlllIIllIIlllIIlI;
            double illIlIlIllllIlIIllllIIlll = iiiIllIlIIIllIlllIlllllIl.IllIlIlIllllIlIIllllIIlll;
            if (sqrt > 0.0) {
                iiIlIIlIlIIIlllIIlIllllll += n3 / sqrt * 2;
                illIlIIIIlllIIllIIlllIIlI += n4 / sqrt * 2;
                illIlIlIllllIlIIllllIIlll += n5 / sqrt * 2;
            }
            iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI.addToSendQueue(new IlllIlIlIllIlllIlIlIlIIll(s, iiIlIIlIlIIIlllIIlIllllll, illIlIIIIlllIIllIIlllIIlI, illIlIlIllllIlIIllllIIlll, (float)liiiIlIIllIIlIIlIIIlIIllI6, (float)liiiIlIIllIIlIIlIIIlIIllI5));
        }
        else {
            iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI.addToSendQueue(new IlllIlIlIllIlllIlIlIlIIll(s, liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI3, (float)liiiIlIIllIIlIIlIIIlIIllI4, (float)liiiIlIIllIIlIIlIIIlIIllI5));
        }
        IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.playsound.success", s, iiiIllIlIIIllIlllIlllllIl.IlIlIIIlllllIIIlIlIlIllII());
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 1;
    }
}
