import java.util.Iterator;
import java.util.Objects;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIlIIlIIIlIlIlllIII extends IlIIlllIlIIIlIIIlIlIlIlIl
{
    private IlIIIIlllIIIlIIllllIIIlll lIIIIlIIllIIlIIlIIIlIIllI;
    private llllIIIIIlIlIlIlIllIIIIII IllIIIIIIIlIlIllllIIllIII;
    private llllIIIIIlIlIlIlIllIIIIII lIIIIllIIlIlIllIIIlIllIlI;
    private llllIIIIIlIlIlIlIllIIIIII IlllIllIlIIIIlIIlIIllIIIl;
    private lllIllIllIlIllIlIIllllIIl IlIlllIIIIllIllllIllIIlIl;
    
    public IIIllllIlIIlIIIlIlIlllIII(final lllIllIllIlIllIlIIllllIIl ilIlllIIIIllIllllIllIIlIl, final IlIIIIlllIIIlIIllllIIIlll liiiIlIIllIIlIIlIIIlIIllI, final float n) {
        super(n);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
        final lIlIllIlIlIIIllllIlIllIll illlIllIlIIIIlIIlIIllIIIl = CheatBreaker.getInstance().IlllIllIlIIIIlIIlIIllIIIl;
        final lIlIllIlIlIIIllllIlIllIll liIlIlIllIIlIIIlIIIlllIII = CheatBreaker.getInstance().lIIlIlIllIIlIIIlIIIlllIII;
        this.IllIIIIIIIlIlIllllIIllIII = new llllIIIIIlIlIlIlIllIIIIII(illlIllIlIIIIlIIlIIllIIIl, null, "Options", this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 20, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 6, -12418828, n);
        (this.lIIIIllIIlIlIllIIIlIllIlI = new llllIIIIIlIlIlIlIllIIIIII(liIlIlIllIIlIIIlIIIlllIII, null, (liiiIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) ? (liiiIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() ? "Disable" : "Enable") : (liiiIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() ? "Hide from HUD" : "Add to HUD"), this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24, liiiIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() ? -5756117 : -13916106, n)).lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI != CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl && liiiIlIIllIIlIIlIIIlIIllI != CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIlllIIIIllIllllIllIIlIl);
        this.IlllIllIlIIIIlIIlIIllIIIl = new llllIIIIIlIlIlIlIllIIIIII(liIlIlIllIIlIIIlIIIlllIII, null, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? "Disable" : "Enable", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? -5756117 : -13916106, n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)this.IIIIllIlIIIllIlllIlllllIl, (float)this.IIIIllIIllIIIIllIllIIIlIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII), -13916106);
        }
        else {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)this.IIIIllIlIIIllIlllIlllllIl, (float)this.IIIIllIIllIIIIllIllIIIlIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII), -1347374928);
        }
        final lIlIllIlIlIIIllllIlIllIll illlIllIlIIIIlIIlIIllIIIl = CheatBreaker.getInstance().IlllIllIlIIIIlIIlIIllIIIl;
        GL11.glPushMatrix();
        int n4 = 0;
        int n5 = 0;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IIIllIllIlIlllllllIlIlIII) {
            n4 = -10;
            final String s = "329/329";
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s, (float)(int)(this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - Minecraft.getMinecraft().fontRendererObj.getStringWidth(s) / 2.0f), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18), -1);
        }
        else if (this.lIIIIlIIllIIlIIlIIIlIIllI == CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIlIIIlllIIIlIlllIlIllIl) {
            n5 = -30;
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow("Speed II", (float)(this.IIIIllIlIIIllIlllIlllllIl + 8 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 20), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 36), -1);
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow("0:42", (float)(this.IIIIllIlIIIllIlllIlllllIl + 8 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 20), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 26), -1);
        }
        else if (this.lIIIIlIIllIIlIIlIIIlIIllI == CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIllIIlIlIllIIIlIllIlI) {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.IIIIllIlIIIllIlllIlllllIl + 20), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 44), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 20), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 6), 1862270976);
            Minecraft.getMinecraft().fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI("Score", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 40, -1);
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow("Steve", (float)(this.IIIIllIlIIIllIlllIlllllIl + 24), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 28), -1);
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow("Alex", (float)(this.IIIIllIlIIIllIlllIlllllIl + 24), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18), -1);
            Minecraft.getMinecraft().fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "0", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18, -1);
            Minecraft.getMinecraft().fontRendererObj.lIIIIlIIllIIlIIlIIIlIIllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "1", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 28, -1);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlllIllIlIIIIlIIlIIllIIIl) {
            new llIlllIIllIlllIlIlIlIIIll("EnderPearl", 368, 9000L).lIIIIlIIllIIlIIlIIIlIIllI(CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 18), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 26 - 18), -1);
        }
        else if ((this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == null || this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == IlIllIllllIIIlIIIllIIIllI.lIIIIlIIllIIlIIlIIIlIIllI) && this.lIIIIlIIllIIlIIlIIIlIIllI != CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIllIIlIlIllIIIlIllIlI) {
            String s2 = "";
            float liIlIIllIIIIIlIllIIIIllII;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == null) {
                liIlIIllIIIIIlIllIIIIllII = 2.0f;
                final String[] split = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().split(" ");
                for (int length = split.length, i = 0; i < length; ++i) {
                    final String substring = split[i].substring(0, 1);
                    s2 += (Objects.equals(s2, "") ? substring : substring.toLowerCase());
                }
            }
            else {
                liIlIIllIIIIIlIllIIIIllII = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlIIllIIIIIlIllIIIIllII();
                s2 = this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIIIlIIIIllllIIlIllI();
            }
            GL11.glScalef(liIlIIllIIIIIlIllIIIIllII, liIlIIllIIIIIlIllIIIIllII, liIlIIllIIIIIlIllIIIIllII);
            final float n6 = Minecraft.getMinecraft().fontRendererObj.getStringWidth(s2) * liIlIIllIIIIIlIllIIIIllII;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == null) {
                Minecraft.getMinecraft().fontRendererObj.lIIIIIIIIIlIllIIllIlIIlIl(s2, (int)((this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - n6 / 2.0f) / liIlIIllIIIIIlIllIIIIllII), (int)((this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 32) / liIlIIllIIIIIlIllIIIIllII), -13750738);
            }
            else {
                Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s2, (float)(int)((this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - n6 / 2.0f) / liIlIIllIIIIIlIllIIIIllII), (float)(int)((this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 32) / liIlIIllIIIIIlIllIIIIllII), -1);
            }
        }
        else if (this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII() == IlIllIllllIIIlIIIllIIIllI.lIIIIIIIIIlIllIIllIlIIlIl) {
            final float iiiiiIlIlIlIllllllIlllIlI = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI();
            final float illIllIIIlIIlllIIIllIllII = this.lIIIIlIIllIIlIIlIIIlIIllI.IllIllIIIlIIlllIIIllIllII();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIllllIIIIlIlIIIIlIlI(), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - iiiiiIlIlIlIllllllIlllIlI / 2.0f + n5, this.IIIIllIIllIIIIllIllIIIlIl + n4 + this.IIIllIllIlIlllllllIlIlIII / 2 - 26 - illIllIIIlIIlllIIIllIllII / 2.0f, iiiiiIlIlIlIllllllIlllIlI, illIllIIIlIIlllIIIllIllII);
        }
        GL11.glPopMatrix();
        illlIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII(), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 1.0681819f * 0.46808508f, (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 4 + 1), 1593835520);
        illlIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII(), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 1.125f * 1.3333334f, (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 4), -1);
        this.IlllIllIlIIIIlIIlIIllIIIl.IllIIIIIIIlIlIllllIIllIII = (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? "Disable" : "Enable");
        this.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI = (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? -5756117 : -13916106);
        this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = ((this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) ? ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? "Disable" : "Enable") : ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? "Hide from HUD" : "Add to HUD"));
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? -5756117 : -13916106);
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 20, this.IlIlIIIlllIIIlIlllIlIllIl - 8, 16);
        this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll ? (this.IlIlIIIlllIIIlIlllIlIllIl - 8) : (this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 2), this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24 - (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38));
        this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll) {
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 8, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 12, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24 - (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38));
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            ((lIlIIllIIIlllIIllIIlIIllI)lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl).llIlIIIlIIIIlIlllIlIIIIll = false;
            ((lIlIIllIIIlllIIllIIlIIllI)lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl).IIIlllIIIllIllIlIIIIIIlII = this.IlIlllIIIIllIllllIllIIlIl;
            ((lIlIIllIIIlllIIllIIlIIllI)lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl).IIIlIIllllIIllllllIlIIIll = this.lIIIIlIIllIIlIIlIIIlIIllI;
            lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI.IlllIllIlIIIIlIIlIIllIIIl = lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl;
        }
        else if (!this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll && this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(!this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl());
            this.IlllIllIlIIIIlIIlIIllIIIl.IllIIIIIIIlIlIllllIIllIII = (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? "Disable" : "Enable");
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI = (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl() ? -5756117 : -13916106);
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true);
            }
        }
        else if (this.lIIIIllIIlIlIllIIIlIllIlI.IlllIllIlIIIIlIIlIIllIIIl && this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(true);
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true);
                }
                else {
                    Minecraft.getMinecraft().displayGuiScreen(new IIIlllllIIlIlIIIllllllIII(lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIlIIllIIlIIlIIIlIIllI));
                }
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(!this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII());
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII()) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl();
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true);
                    }
                    else {
                        Minecraft.getMinecraft().displayGuiScreen(new IIIlllllIIlIlIIIllllllIII(lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIlIIllIIlIIlIIIlIIllI));
                    }
                }
                else if (this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(false);
                }
            }
            this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = ((this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll() == null) ? ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? "Disable" : "Enable") : ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? "Hide from HUD" : "Add to HUD"));
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = ((this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlllIIIllIllIlIIIIIIlII() && this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl()) ? -5756117 : -13916106);
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().llIIlllIIIIlllIllIlIlllIl) {
            return;
        }
        for (final lIIlIlllIIIIlIIIllIlIIIII liIlIlllIIIIlIIIllIlIIIII : this.lIIIIlIIllIIlIIlIIIlIIllI.llIIlllIIIIlllIllIlIlllIl()) {
            if (liIlIlllIIIIlIIIllIlIIIII.IlllIllIlIIIIlIIlIIllIIIl() == llllllIIlIlIIlllIIIIlIllI.IIIIllIlIIIllIlllIlllllIl && liIlIlllIIIIlIIIllIlIIIII.IlIlIIIlllIIIlIlllIlIllIl().toLowerCase().contains("color") && !liIlIlllIIIIlIIIllIlIIIII.IlIlIIIlllIIIlIlllIlIllIl().toLowerCase().contains("background") && !liIlIlllIIIIlIIIllIlIIIII.IlIlIIIlllIIIlIlllIlIllIl().toLowerCase().contains("pressed")) {
                Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                liIlIlllIIIIlIIIllIlIIIII.lIIIIIIIIIlIllIIllIlIIlIl(CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIllIlIllIlIllIIlIllIlIII.IIIIllIlIIIllIlllIlllllIl());
            }
        }
    }
}
