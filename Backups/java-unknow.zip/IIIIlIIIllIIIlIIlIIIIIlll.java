import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIllIIIlIIlIIIIIlll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "give";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 2;
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.give.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length < 2) {
            throw new IIllllIlIlIIlllIlIIllIIll("commands.give.usage", new Object[0]);
        }
        final llIIIIIIlIlllllIIllllIlII iiiIllIlIIIllIlllIlllllIl = IlIIIllllllIllIlllllIIllI.IIIIllIlIIIllIlllIlllllIl(lIlllllIIIIIIllIlIIlIlIII, array[0]);
        final lIIlllIIIlIllllllIlIlIIII ilIlIIIlllIIIlIlllIlIllIl = IlIIIllllllIllIlllllIIllI.IlIlIIIlllIIIlIlllIlIllIl(lIlllllIIIIIIllIlIIlIlIII, array[1]);
        int liiiIlIIllIIlIIlIIIlIIllI = 1;
        int liiiIlIIllIIlIIlIIIlIIllI2 = 0;
        if (array.length >= 3) {
            liiiIlIIllIIlIIlIIIlIIllI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[2], 1, 64);
        }
        if (array.length >= 4) {
            liiiIlIIllIIlIIlIIIlIIllI2 = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array[3]);
        }
        final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI = new lIlIlIlIlIllllIlllIIIlIlI(ilIlIIIlllIIIlIlllIlIllIl, liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2);
        if (array.length >= 5) {
            final String illlIIIlIlllIllIlIIlllIlI = IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, array, 4).IlllIIIlIlllIllIlIIlllIlI();
            try {
                final lIllIIIIIlIIllIIIIlIIllII liiiIlIIllIIlIIlIIIlIIllI3 = lIlllIllllIlIlllIIIIllIll.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI);
                if (!(liiiIlIIllIIlIIlIIIlIIllI3 instanceof IlIIIllIIlIIlllIllllIIIIl)) {
                    IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.give.tagError", "Not a valid tag");
                    return;
                }
                lIlIlIlIlIllllIlllIIIlIlI.IIIIllIlIIIllIlllIlllllIl((IlIIIllIIlIIlllIllllIIIIl)liiiIlIIllIIlIIlIIIlIIllI3);
            }
            catch (IIIlIlIlIIlIIllllIIlIIIlI iiIlIlIlIIlIIllllIIlIIIlI) {
                IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.give.tagError", iiIlIlIlIIlIIllllIIlIIIlI.getMessage());
                return;
            }
        }
        final lllIIIIIlIllllIIIlllIllIl liiiIlIIllIIlIIlIIIlIIllI4 = iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(lIlIlIlIlIllllIlllIIIlIlI, false);
        liiiIlIIllIIlIIlIIIlIIllI4.lIIIIIIIIIlIllIIllIlIIlIl = 0;
        liiiIlIIllIIlIIlIIIlIIllI4.setSection(iiiIllIlIIIllIlllIlllllIl.IlIlIIIlllllIIIlIlIlIllII());
        IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.give.success", lIlIlIlIlIllllIlllIIIlIlI.lIlIlIllIIIIIIIIllllIIllI(), liiiIlIIllIIlIIlIIIlIIllI, iiiIllIlIIIllIlllIlllllIl.IlIlIIIlllllIIIlIlIlIllII());
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, this.IIIIllIlIIIllIlllIlllllIl()) : ((array.length == 2) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI()) : null);
    }
    
    protected String[] IIIIllIlIIIllIlllIlllllIl() {
        return llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final String[] array, final int n) {
        return n == 0;
    }
}
