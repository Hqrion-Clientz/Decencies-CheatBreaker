// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIIllIIlIlllllIlllIII extends IlIllIIlIIllllllIIlIllIlI
{
    public final lllIIllIlIIlIIlllllIIIllI lIIIIlIIllIIlIIlIIIlIIllI;
    public final int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIllIIIllIIlIlllllIlllIII(final lllIIllIlIIlIIlllllIIIllI liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl) {
        super(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI());
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public IIllIIIllIIlIlllllIlllIII(final int n, final int n2) {
        this(lllIIllIlIIlIIlllllIIIllI.lIIIIlIIllIIlIIlIIIlIIllI[n], n2);
    }
}
