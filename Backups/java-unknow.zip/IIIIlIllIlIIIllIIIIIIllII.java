// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIllIlIIIllIIIIIIllII extends IllllIllIllIIIIIIlIllIIll
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private String IlllIIIlIlllIllIlIIlllIlI;
    private long IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIlIllIlIIIllIIIIIIllII() {
    }
    
    public IIIIlIllIlIIIllIIIIIIllII(final String liiiIlIIllIIlIIlIIIlIIllI, final String illlIIIlIlllIllIlIIlllIlI, final long iiiIllIlIIIllIlllIlllllIl, final boolean iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
        lIlIllllllllIlIIIllIIllII.writeLong(this.IIIIllIlIIIllIlllIlllllIl);
        lIlIllllllllIlIIIllIIllII.writeBoolean(this.IIIIllIIllIIIIllIllIIIlIl);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(52);
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32);
        this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.readLong();
        this.IIIIllIIllIIIIllIllIIIlIl = lIlIllllllllIlIIIllIIllII.readBoolean();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll liIlllIIlllIlIllIIlIIIIll) {
        liIlllIIlllIlIllIIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public long IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
}
