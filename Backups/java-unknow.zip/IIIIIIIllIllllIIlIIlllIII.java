// 
// Decompiled by Procyon v0.5.36
// 

@Deprecated
public class IIIIIIIllIllllIIlIIlllIII extends IlIllIllIllIllIllllIIIlII
{
    public IIIIIIIllIllllIIlIIlllIII(final int n, final float n2, final int n3, final int n4, final int n5, final int n6) {
        super(n, n2, n3, n4, n5, n6);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll) {
        return !ilIIIIlllIIIlIIllllIIIlll.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll) {
        if (ilIIIIlllIIIlIIllllIIIlll.llIlIIIlIIIIlIlllIlIIIIll() == null || ilIIIIlllIIIlIIllllIIIlll.IIIllIllIlIlllllllIlIlIII().equalsIgnoreCase("Zans Minimap")) {
            if (!ilIIIIlllIIIlIIllllIIIlll.IlIlIIIlllIIIlIlllIlIllIl()) {
                Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                ilIIIIlllIIIlIIllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(true);
            }
        }
        else if (!ilIIIIlllIIIlIIllllIIIlll.IlIlIIIlllIIIlIlllIlIllIl()) {
            Minecraft.getMinecraft().displayGuiScreen(new IIIlllllIIlIlIIIllllllIII(lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI, ilIIIIlllIIIlIIllllIIIlll));
        }
    }
}
