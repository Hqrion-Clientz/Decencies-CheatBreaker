import java.io.File;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIlIIIllIIIlIlllIlIIIlII
{
    IllIlIlllIIIIIIlIIllIIIll IlllIIIlIlllIllIlIIlllIlI();
    
    void IIIIllIlIIIllIlllIlllllIl();
    
    IllIIlllIlllIIlIlIIIIIlll lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIllllllIlIIllIlIlIlI p0);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIlllIIIIIIlIIllIIIll p0, final IlIIIllIIlIIlllIllllIIIIl p1);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIlllIIIIIIlIIllIIIll p0);
    
    IIIlIIllIlIIIIllIllIIlIIl IIIIllIIllIIIIllIllIIIlIl();
    
    void lIIIIlIIllIIlIIlIIIlIIllI();
    
    File IlIlIIIlllIIIlIlllIlIllIl();
    
    File lIIIIlIIllIIlIIlIIIlIIllI(final String p0);
    
    String IIIllIllIlIlllllllIlIlIII();
}
