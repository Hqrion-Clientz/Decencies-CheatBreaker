import java.util.ListIterator;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Collection;
import java.util.RandomAccess;
import java.io.Serializable;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIlIlIllIIIIlIIIIIl extends lIIllIIlIIIIIllIlIIllIIIl implements Serializable, Cloneable, RandomAccess
{
    private static final long IIIIllIIllIIIIllIllIIIlIl = -7046029254386353131L;
    public static final int lIIIIlIIllIIlIIlIIIlIIllI = 16;
    protected final boolean lIIIIIIIIIlIllIIllIlIIlIl;
    protected transient Object[] IlllIIIlIlllIllIlIIlllIlI;
    protected int IIIIllIlIIIllIlllIlllllIl;
    private static final boolean IlIlIIIlllIIIlIlllIlIllIl = false;
    
    protected IIlIIlIIlIlIllIIIIlIIIIIl(final Object[] illlIIIlIlllIllIlIIlllIlI, final boolean b) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = true;
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Initial capacity (" + i + ") is negative");
        }
        this.IlllIIIlIlllIllIlIIlllIlI = new Object[i];
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl() {
        this(16);
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final Collection collection) {
        this(collection.size());
        this.IIIIllIlIIIllIlllIlllllIl = lIIIIlIlIllIIIIIIIlIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(collection.iterator(), this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final IlIIIlIIlIllIIllllIlIIlIl ilIIIlIIlIllIIllllIlIIlIl) {
        this(ilIIIlIIlIllIIllllIlIIlIl.size());
        this.IIIIllIlIIIllIlllIlllllIl = lIIIIlIlIllIIIIIIIlIlIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIlIIlIllIIllllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(), this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final lIlllIllIlllIlllIlIIIlIIl lIlllIllIlllIlllIlIIIlIIl) {
        this(lIlllIllIlllIlllIlIIIlIIl.size());
        lIlllIllIlllIlllIlIIIlIIl.lIIIIIIIIIlIllIIllIlIIlIl(0, this.IlllIIIlIlllIllIlIIlllIlI, 0, this.IIIIllIlIIIllIlllIlllllIl = lIlllIllIlllIlllIlIIIlIIl.size());
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final Object[] array) {
        this(array, 0, array.length);
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final Object[] array, final int n, final int iiiIllIlIIIllIlllIlllllIl) {
        this(iiiIllIlIIIllIlllIlllllIl);
        System.arraycopy(array, n, this.IlllIIIlIlllIllIlIIlllIlI, 0, iiiIllIlIIIllIlllIlllllIl);
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final Iterator iterator) {
        this();
        while (iterator.hasNext()) {
            this.add(iterator.next());
        }
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl(final lllllIllIlIIllIIIlllllIIl lllllIllIlIIllIIIlllllIIl) {
        this();
        while (lllllIllIlIIllIIIlllllIIl.hasNext()) {
            this.add(lllllIllIlIIllIIIlllllIIl.next());
        }
    }
    
    public Object[] IIIllIllIlIlllllllIlIlIII() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public static IIlIIlIIlIlIllIIIIlIIIIIl lIIIIlIIllIIlIIlIIIlIIllI(final Object[] array, final int n) {
        if (n > array.length) {
            throw new IllegalArgumentException("The specified length (" + n + ") is greater than the array size (" + array.length + ")");
        }
        final IIlIIlIIlIlIllIIIIlIIIIIl ilIIlIIlIlIllIIIIlIIIIIl = new IIlIIlIIlIlIllIIIIlIIIIIl(array, false);
        ilIIlIIlIlIllIIIIlIIIIIl.IIIIllIlIIIllIlllIlllllIl = n;
        return ilIIlIIlIlIllIIIIlIIIIIl;
    }
    
    public static IIlIIlIIlIlIllIIIIlIIIIIl lIIIIlIIllIIlIIlIIIlIIllI(final Object[] array) {
        return lIIIIlIIllIIlIIlIIIlIIllI(array, array.length);
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final int n) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IlllIIIlIlllIllIlIIlllIlI = IlIIlIlIlIIlllIIIllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI, n, this.IIIIllIlIIIllIlllIlllllIl);
        }
        else if (n > this.IlllIIIlIlllIllIlIIlllIlI.length) {
            final Object[] array = new Object[n];
            System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, 0, array, 0, this.IIIIllIlIIIllIlllIlllllIl);
            this.IlllIIIlIlllIllIlIIlllIlI = array;
        }
    }
    
    private void lIIIIllIIlIlIllIIIlIllIlI(final int n) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IlllIIIlIlllIllIlIIlllIlI = IlIIlIlIlIIlllIIIllIIIlII.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI, n, this.IIIIllIlIIIllIlllIlllllIl);
        }
        else if (n > this.IlllIIIlIlllIllIlIIlllIlI.length) {
            final Object[] array = new Object[(int)Math.max(Math.min(2L * this.IlllIIIlIlllIllIlIIlllIlI.length, 2147483639L), n)];
            System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, 0, array, 0, this.IIIIllIlIIIllIlllIlllllIl);
            this.IlllIIIlIlllIllIlIIlllIlI = array;
        }
    }
    
    @Override
    public void add(final int n, final Object o) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(n);
        this.lIIIIllIIlIlIllIIIlIllIlI(this.IIIIllIlIIIllIlllIlllllIl + 1);
        if (n != this.IIIIllIlIIIllIlllIlllllIl) {
            System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, n, this.IlllIIIlIlllIllIlIIlllIlI, n + 1, this.IIIIllIlIIIllIlllIlllllIl - n);
        }
        this.IlllIIIlIlllIllIlIIlllIlI[n] = o;
        ++this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public boolean add(final Object o) {
        this.lIIIIllIIlIlIllIIIlIllIlI(this.IIIIllIlIIIllIlllIlllllIl + 1);
        this.IlllIIIlIlllIllIlIIlllIlI[this.IIIIllIlIIIllIlllIlllllIl++] = o;
        return true;
    }
    
    @Override
    public Object get(final int i) {
        if (i >= this.IIIIllIlIIIllIlllIlllllIl) {
            throw new IndexOutOfBoundsException("Index (" + i + ") is greater than or equal to list size (" + this.IIIIllIlIIIllIlllIlllllIl + ")");
        }
        return this.IlllIIIlIlllIllIlIIlllIlI[i];
    }
    
    @Override
    public int indexOf(final Object o) {
        for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl; ++i) {
            if (o == null) {
                if (this.IlllIIIlIlllIllIlIIlllIlI[i] == null) {
                    return i;
                }
            }
            else if (o.equals(this.IlllIIIlIlllIllIlIIlllIlI[i])) {
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public int lastIndexOf(final Object o) {
        int iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        while (iiiIllIlIIIllIlllIlllllIl-- != 0) {
            if (o == null) {
                if (this.IlllIIIlIlllIllIlIIlllIlI[iiiIllIlIIIllIlllIlllllIl] != null) {
                    continue;
                }
            }
            else if (!o.equals(this.IlllIIIlIlllIllIlIIlllIlI[iiiIllIlIIIllIlllIlllllIl])) {
                continue;
            }
            return iiiIllIlIIIllIlllIlllllIl;
        }
        return -1;
    }
    
    @Override
    public Object remove(final int i) {
        if (i >= this.IIIIllIlIIIllIlllIlllllIl) {
            throw new IndexOutOfBoundsException("Index (" + i + ") is greater than or equal to list size (" + this.IIIIllIlIIIllIlllIlllllIl + ")");
        }
        final Object o = this.IlllIIIlIlllIllIlIIlllIlI[i];
        --this.IIIIllIlIIIllIlllIlllllIl;
        if (i != this.IIIIllIlIIIllIlllIlllllIl) {
            System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, i + 1, this.IlllIIIlIlllIllIlIIlllIlI, i, this.IIIIllIlIIIllIlllIlllllIl - i);
        }
        this.IlllIIIlIlllIllIlIIlllIlI[this.IIIIllIlIIIllIlllIlllllIl] = null;
        return o;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final Object o) {
        final int index = this.indexOf(o);
        if (index == -1) {
            return false;
        }
        this.remove(index);
        return true;
    }
    
    @Override
    public boolean remove(final Object o) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(o);
    }
    
    @Override
    public Object set(final int i, final Object o) {
        if (i >= this.IIIIllIlIIIllIlllIlllllIl) {
            throw new IndexOutOfBoundsException("Index (" + i + ") is greater than or equal to list size (" + this.IIIIllIlIIIllIlllIlllllIl + ")");
        }
        final Object o2 = this.IlllIIIlIlllIllIlIIlllIlI[i];
        this.IlllIIIlIlllIllIlIIlllIlI[i] = o;
        return o2;
    }
    
    @Override
    public void clear() {
        Arrays.fill(this.IlllIIIlIlllIllIlIIlllIlI, 0, this.IIIIllIlIIIllIlllIlllllIl, null);
        this.IIIIllIlIIIllIlllIlllllIl = 0;
    }
    
    @Override
    public int size() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void IlIlIIIlllIIIlIlllIlIllIl(final int iiiIllIlIIIllIlllIlllllIl) {
        if (iiiIllIlIIIllIlllIlllllIl > this.IlllIIIlIlllIllIlIIlllIlI.length) {
            this.IIIllIllIlIlllllllIlIlIII(iiiIllIlIIIllIlllIlllllIl);
        }
        if (iiiIllIlIIIllIlllIlllllIl > this.IIIIllIlIIIllIlllIlllllIl) {
            Arrays.fill(this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, iiiIllIlIIIllIlllIlllllIl, null);
        }
        else {
            Arrays.fill(this.IlllIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl, this.IIIIllIlIIIllIlllIlllllIl, null);
        }
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public boolean isEmpty() {
        return this.IIIIllIlIIIllIlllIlllllIl == 0;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII() {
        this.IllIIIIIIIlIlIllllIIllIII(0);
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int a) {
        if (a >= this.IlllIIIlIlllIllIlIIlllIlI.length || this.IIIIllIlIIIllIlllIlllllIl == this.IlllIIIlIlllIllIlIIlllIlI.length) {
            return;
        }
        final Object[] illlIIIlIlllIllIlIIlllIlI = new Object[Math.max(a, this.IIIIllIlIIIllIlllIlllllIl)];
        System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, 0, illlIIIlIlllIllIlIIlllIlI, 0, this.IIIIllIlIIIllIlllIlllllIl);
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final Object[] array, final int n2, final int n3) {
        IlIIlIlIlIIlllIIIllIIIlII.IIIIllIIllIIIIllIllIIIlIl(array, n2, n3);
        System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, n, array, n2, n3);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2) {
        lIIlIIlllIIlIIlIIIlIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl, n, n2);
        System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, n2, this.IlllIIIlIlllIllIlIIlllIlI, n, this.IIIIllIlIIIllIlllIlllllIl - n2);
        this.IIIIllIlIIIllIlllIlllllIl -= n2 - n;
        int n3 = n2 - n;
        while (n3-- != 0) {
            this.IlllIIIlIlllIllIlIIlllIlI[this.IIIIllIlIIIllIlllIlllllIl + n3] = null;
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Object[] array, final int n2, final int n3) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(n);
        IlIIlIlIlIIlllIIIllIIIlII.IIIIllIIllIIIIllIllIIIlIl(array, n2, n3);
        this.lIIIIllIIlIlIllIIIlIllIlI(this.IIIIllIlIIIllIlllIlllllIl + n3);
        System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, n, this.IlllIIIlIlllIllIlIIlllIlI, n + n3, this.IIIIllIlIIIllIlllIlllllIl - n);
        System.arraycopy(array, n2, this.IlllIIIlIlllIllIlIIlllIlI, n, n3);
        this.IIIIllIlIIIllIlllIlllllIl += n3;
    }
    
    @Override
    public boolean removeAll(final Collection collection) {
        final Object[] illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        int n = 0;
        for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl; ++i) {
            if (!collection.contains(illlIIIlIlllIllIlIIlllIlI[i])) {
                illlIIIlIlllIllIlIIlllIlI[n++] = illlIIIlIlllIllIlIIlllIlI[i];
            }
        }
        Arrays.fill(illlIIIlIlllIllIlIIlllIlI, n, this.IIIIllIlIIIllIlllIlllllIl, null);
        final boolean b = this.IIIIllIlIIIllIlllIlllllIl != n;
        this.IIIIllIlIIIllIlllIlllllIl = n;
        return b;
    }
    
    @Override
    public llllllllllllIlIIIIIIIIlll IIIIllIIllIIIIllIllIIIlIl(final int n) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(n);
        return new llIIlIlIIIlIlIIlIllllIllI(this, n);
    }
    
    public IIlIIlIIlIlIllIIIIlIIIIIl lIIIIllIIlIlIllIIIlIllIlI() {
        final IIlIIlIIlIlIllIIIIlIIIIIl ilIIlIIlIlIllIIIIlIIIIIl = new IIlIIlIIlIlIllIIIIlIIIIIl(this.IIIIllIlIIIllIlllIlllllIl);
        System.arraycopy(this.IlllIIIlIlllIllIlIIlllIlI, 0, ilIIlIIlIlIllIIIIlIIIIIl.IlllIIIlIlllIllIlIIlllIlI, 0, this.IIIIllIlIIIllIlllIlllllIl);
        ilIIlIIlIlIllIIIIlIIIIIl.IIIIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        return ilIIlIIlIlIllIIIIlIIIIIl;
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final Object o, final Object obj) {
        return (o == null) ? (obj == null) : o.equals(obj);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIlIIlIlIllIIIIlIIIIIl ilIIlIIlIlIllIIIIlIIIIIl) {
        if (ilIIlIIlIlIllIIIIlIIIIIl == this) {
            return true;
        }
        int size = this.size();
        if (size != ilIIlIIlIlIllIIIIlIIIIIl.size()) {
            return false;
        }
        final Object[] illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        final Object[] illlIIIlIlllIllIlIIlllIlI2 = ilIIlIIlIlIllIIIIlIIIIIl.IlllIIIlIlllIllIlIIlllIlI;
        while (size-- != 0) {
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI[size], illlIIIlIlllIllIlIIlllIlI2[size])) {
                return false;
            }
        }
        return true;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final IIlIIlIIlIlIllIIIIlIIIIIl ilIIlIIlIlIllIIIIlIIIIIl) {
        final int size = this.size();
        final int size2 = ilIIlIIlIlIllIIIIlIIIIIl.size();
        final Object[] illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        final Object[] illlIIIlIlllIllIlIIlllIlI2 = ilIIlIIlIlIllIIIIlIIIIIl.IlllIIIlIlllIllIlIIlllIlI;
        int n;
        for (n = 0; n < size && n < size2; ++n) {
            final int compareTo;
            if ((compareTo = ((Comparable<Object>)illlIIIlIlllIllIlIIlllIlI[n]).compareTo(illlIIIlIlllIllIlIIlllIlI2[n])) != 0) {
                return compareTo;
            }
        }
        return (n < size2) ? -1 : (n < size);
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final ObjectOutputStream objectOutputStream) {
        objectOutputStream.defaultWriteObject();
        for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl; ++i) {
            objectOutputStream.writeObject(this.IlllIIIlIlllIllIlIIlllIlI[i]);
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final ObjectInputStream objectInputStream) {
        objectInputStream.defaultReadObject();
        this.IlllIIIlIlllIllIlIIlllIlI = new Object[this.IIIIllIlIIIllIlllIlllllIl];
        for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl; ++i) {
            this.IlllIIIlIlllIllIlIIlllIlI[i] = objectInputStream.readObject();
        }
    }
}
