import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIllIllIllIIllIIlll extends llIlIllIlIIllIIlIIlIlIIll
{
    public IIIIllIIllIllIllIIllIIlll() {
    }
    
    public IIIIllIIllIllIllIIllIIlll(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        int n = 1;
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 1 || this.IlIlIIIlllIIIlIlllIlIllIl == 2) {
            n = 5;
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, n, random.nextInt(8) > 0);
        this.IlllIIIlIlllIllIlIIlllIlI((llllIlIlIIIllIlIllllllIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, n, random.nextInt(8) > 0);
    }
    
    public static IIIIllIIllIllIllIIllIIlll lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -3, 0, 0, 9, 7, 9, n4);
        return (llIlIllIlIIllIIlIIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIIIllIIllIllIllIIllIIlll(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 8, 1, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 8, 5, 8, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 6, 0, 8, 6, 5, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 0, 2, 5, 0, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 6, 2, 0, 8, 5, 0, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 3, 0, 1, 4, 0, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 7, 3, 0, 7, 4, 0, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, 4, 8, 2, 8, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 1, 4, 2, 2, 4, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 6, 1, 4, 7, 2, 4, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, 8, 8, 3, 8, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, 6, 0, 3, 7, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 3, 6, 8, 3, 7, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, 4, 0, 5, 5, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 3, 4, 8, 5, 5, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 3, 5, 2, 5, 5, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 6, 3, 5, 7, 5, 5, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 4, 5, 1, 5, 5, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 7, 4, 5, 7, 5, 5, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, IllllllIllIIlllIllIIlIIll.IIlllllIIlIIlIlIIlIIlIlII, false);
        for (int i = 0; i <= 5; ++i) {
            for (int j = 0; j <= 8; ++j) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIIlIllIllllIIlIllllIlII, 0, j, -1, i, iiIllllIIllllIIIIIlllllIl);
            }
        }
        return true;
    }
}
