// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIlIIlIIlIIIlIIllIII extends lllIIllIlIIlIIlllllIIIllI
{
    protected IIIlIlIlIIlIIlIIIlIIllIII(final int n, final int n2) {
        super(n, n2, lIIIlIIIlIllIlllIIIIIlIlI.IIIllIllIlIlllllllIlIlIII);
        this.lIIIIlIIllIIlIIlIIIlIIllI("fire");
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return 10 + 20 * (n - 1);
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(n) + 50;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 2;
    }
}
