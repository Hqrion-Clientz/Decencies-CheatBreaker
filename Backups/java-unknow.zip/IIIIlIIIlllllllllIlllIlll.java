import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIlllllllllIlllIlll extends lIIIlllIlIlllIIIIIIIIIlII
{
    private double lIIIIIIIIIlIllIIllIlIIlIl;
    private float IlllIIIlIlllIllIlIIlllIlI;
    private ResourceLocation IIIIllIlIIIllIlllIlllllIl;
    private ResourceLocation IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIlIIIlllllllllIlllIlll() {
        this.IlllIIIlIlllIllIlIIlllIlI = 0.0f;
        this.IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("client/logo_outer.png");
        this.IIIIllIIllIIIIllIllIIIlIl = new ResourceLocation("client/logo_inner.png");
    }
    
    @Override
    public void s_() {
        this.resize(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 48, 24);
        super.s_();
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        this.lIIIIIIIIIlIllIIllIlIIlIl += 0.9110618729350101 * 0.06896551698446274;
        this.IlllIIIlIlllIllIlIIlllIlI = (float)((Math.sin(this.lIIIIIIIIIlIllIIllIlIIlIl) / 2 + 1.8846154364608463 * 0.26530611515045166) * 180);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        final Tessellator instance = Tessellator.instance;
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, (float)20, 0.0f);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 40), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 110), -1342177281);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 73), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 42), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 112), 1073741823);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 42), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 73), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 112), 1073741823);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 110), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 + 112), 1073741823);
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 42), (float)(this.lIIIIIllllIIIIlIlIIIIlIlI / 2 + 71), (float)(this.IIIIIIlIlIlIllllllIlllIlI / 4 - 40), 1073741823);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.5858586f * 1.5362068f);
        GL11.glPushMatrix();
        final float n4 = 0.8648649f * 0.7515625f;
        GL11.glScalef(n4, n4, n4);
        GL11.glPushMatrix();
        GL11.glTranslatef((this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 40 * n4) / n4, (this.IIIIIIlIlIlIllllllIlllIlI / 4 - 40 * n4) / n4, 0.0f);
        final int n5 = 40;
        GL11.glTranslatef((float)n5, (float)n5, (float)n5);
        GL11.glRotatef(this.IlllIIIlIlllIllIlIIlllIlI, 0.0f, 0.0f, 1.0f);
        GL11.glTranslatef((float)(-n5), (float)(-n5), (float)(-n5));
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl, (float)n5, 0.0f, 0.0f);
        GL11.glPopMatrix();
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl, 40, (this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 40 * n4) / n4, (this.IIIIIIlIlIlIllllllIlllIlI / 4 - 39 * n4) / n4);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        instance.setColorOpaque_I(-1);
        super.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
    }
}
