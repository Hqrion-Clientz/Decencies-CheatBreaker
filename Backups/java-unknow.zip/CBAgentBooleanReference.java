import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;

// 
// Decompiled by Procyon v0.5.36
// 

@Retention(RetentionPolicy.RUNTIME)
public @interface CBAgentBooleanReference {
}
