import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.awt.image.BufferedImage;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonElement;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlllllIIIlIlIIllIIIll
{
    private String IIIIllIlIIIllIlllIlllllIl;
    public static final String lIIIIlIIllIIlIIlIIIlIIllI = "items";
    public static final String lIIIIIIIIIlIllIIllIlIIlIl = "type";
    public static final String IlllIIIlIlllIllIlIIlllIlI = "active";
    
    public IIlIIlllllIIIlIlIIllIIIll(final String iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = null;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    public lIIIlIllIlIlllIlIlIIllIll lIIIIlIIllIIlIIlIIIlIIllI(final JsonElement jsonElement) {
        if (jsonElement == null) {
            throw new JsonParseException("JSON object is null, player: " + this.IIIIllIlIIIllIlllIlllllIl);
        }
        final JsonObject jsonObject = (JsonObject)jsonElement;
        final lIIIlIllIlIlllIlIlIIllIll liiIlIllIlIlllIlIlIIllIll = new lIIIlIllIlIlllIlIlIIllIll();
        final JsonArray jsonArray = (JsonArray)jsonObject.get("items");
        if (jsonArray != null) {
            for (int i = 0; i < jsonArray.size(); ++i) {
                final JsonObject jsonObject2 = (JsonObject)jsonArray.get(i);
                if (IIlIlIIIIIllIllIIIlllllll.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject2, "active", true)) {
                    final String liiiIlIIllIIlIIlIIIlIIllI = IIlIlIIIIIllIllIIIlllllll.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject2, "type");
                    if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                        lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Item type is null, player: " + this.IIIIllIlIIIllIlllIlllllIl);
                    }
                    else {
                        String s = IIlIlIIIIIllIllIIIlllllll.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject2, "model");
                        if (s == null) {
                            s = "items/" + liiiIlIIllIIlIIlIIIlIIllI + "/model.cfg";
                        }
                        final IIlllIllIIlIlIlIlllIlIIIl liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(s);
                        if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                            if (!liiiiiiiiIlIllIIllIlIIlIl.IIIIllIlIIIllIlllIlllllIl()) {
                                String s2 = IIlIlIIIIIllIllIIIlllllll.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject2, "texture");
                                if (s2 == null) {
                                    s2 = "items/" + liiiIlIIllIIlIIlIIIlIIllI + "/users/" + this.IIIIllIlIIIllIlllIlllllIl + ".png";
                                }
                                final BufferedImage liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(s2);
                                if (liiiIlIIllIIlIIlIIIlIIllI2 == null) {
                                    continue;
                                }
                                liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2);
                                liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("optifine.net", s2));
                            }
                            liiIlIllIlIlllIlIlIIllIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl);
                        }
                    }
                }
            }
        }
        return liiIlIllIlIlllIlIlIIllIll;
    }
    
    private BufferedImage lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        final String string = "http://s.optifine.net/" + s;
        try {
            return ImageIO.read(new ByteArrayInputStream(lIIIIIIlllIIIIIIllIlIllll.lIIIIIIIIIlIllIIllIlIIlIl(string, Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI())));
        }
        catch (IOException ex) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Error loading item texture " + s + ": " + ex.getClass().getName() + ": " + ex.getMessage());
            return null;
        }
    }
    
    private IIlllIllIIlIlIlIlllIlIIIl lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        final String string = "http://s.optifine.net/" + s;
        try {
            final JsonObject jsonObject = (JsonObject)new JsonParser().parse(new String(lIIIIIIlllIIIIIIllIlIllll.lIIIIIIIIIlIllIIllIlIIlIl(string, Minecraft.getMinecraft().IlIIIIllIIIIIlllIIlIIlllI()), "ASCII"));
            final lllllIlIIIIIIllIlIlllIIII lllllIlIIIIIIllIlIlllIIII = new lllllIlIIIIIIllIlIlllIIII();
            return lllllIlIIIIIIllIlIlllIIII.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject);
        }
        catch (Exception ex) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Error loading item model " + s + ": " + ex.getClass().getName() + ": " + ex.getMessage());
            return null;
        }
    }
}
