// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIlIIIlIlllllIIIlI
{
    public boolean lIIIIlIIllIIlIIlIIIlIIllI;
    public boolean lIIIIIIIIIlIllIIllIlIIlIl;
    public boolean IlllIIIlIlllIllIlIIlllIlI;
    public boolean IIIIllIlIIIllIlllIlllllIl;
    public boolean IIIIllIIllIIIIllIllIIIlIl;
    private float IlIlIIIlllIIIlIlllIlIllIl;
    private float IIIllIllIlIlllllllIlIlIII;
    
    public IIlIllIIIlIIIlIlllllIIIlI() {
        this.IIIIllIIllIIIIllIllIIIlIl = true;
        this.IlIlIIIlllIIIlIlllIlIllIl = 0.2967033f * 0.16851851f;
        this.IIIllIllIlIlllllllIlIlIII = 0.03846154f * 2.6f;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("invulnerable", this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("flying", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("mayfly", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("instabuild", this.IIIIllIlIIIllIlllIlllllIl);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("mayBuild", this.IIIIllIIllIIIIllIllIIIlIl);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("flySpeed", this.IlIlIIIlllIIIlIlllIlIllIl);
        ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("walkSpeed", this.IIIllIllIlIlllllllIlIlIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("abilities", ilIIIllIIlIIlllIllllIIIIl2);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("abilities", 10)) {
            final IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII = ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("abilities");
            this.lIIIIlIIllIIlIIlIIIlIIllI = liIlIlIllIIlIIIlIIIlllIII.IIIlllIIIllIllIlIIIIIIlII("invulnerable");
            this.lIIIIIIIIIlIllIIllIlIIlIl = liIlIlIllIIlIIIlIIIlllIII.IIIlllIIIllIllIlIIIIIIlII("flying");
            this.IlllIIIlIlllIllIlIIlllIlI = liIlIlIllIIlIIIlIIIlllIII.IIIlllIIIllIllIlIIIIIIlII("mayfly");
            this.IIIIllIlIIIllIlllIlllllIl = liIlIlIllIIlIIIlIIIlllIII.IIIlllIIIllIllIlIIIIIIlII("instabuild");
            if (liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl("flySpeed", 99)) {
                this.IlIlIIIlllIIIlIlllIlIllIl = liIlIlIllIIlIIIlIIIlllIII.IllIIIIIIIlIlIllllIIllIII("flySpeed");
                this.IIIllIllIlIlllllllIlIlIII = liIlIlIllIIlIIIlIIIlllIII.IllIIIIIIIlIlIllllIIllIII("walkSpeed");
            }
            if (liIlIlIllIIlIIIlIIIlllIII.lIIIIIIIIIlIllIIllIlIIlIl("mayBuild", 1)) {
                this.IIIIllIIllIIIIllIllIIIlIl = liIlIlIllIIlIIIlIIIlllIII.IIIlllIIIllIllIlIIIIIIlII("mayBuild");
            }
        }
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float ilIlIIIlllIIIlIlllIlIllIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public float lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float iiIllIllIlIlllllllIlIlIII) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
}
