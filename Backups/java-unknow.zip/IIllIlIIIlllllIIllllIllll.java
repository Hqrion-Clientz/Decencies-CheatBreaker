import java.util.concurrent.ForkJoinTask;
import java.util.Comparator;
import java.util.concurrent.RecursiveAction;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIlIIIlllllIIllllIllll extends RecursiveAction
{
    private static final long lIIIIlIIllIIlIIlIIIlIIllI = 1L;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final Object[] IIIIllIlIIIllIlllIlllllIl;
    private final Comparator IIIIllIIllIIIIllIllIIIlIl;
    
    public IIllIlIIIlllllIIllllIllll(final Object[] iiiIllIlIIIllIlllIlllllIl, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final Comparator iiiIllIIllIIIIllIllIIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected void compute() {
        final Object[] iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        final int n = this.IlllIIIlIlllIllIlIIlllIlI - this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n < 8192) {
            IlIIlIlIlIIlllIIIllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIIllIIIIllIllIIIlIl);
            return;
        }
        final int n2 = this.lIIIIIIIIIlIllIIllIlIIlIl + n / 2;
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        final int n3 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        final int n4 = n / 8;
        final Object o = iiiIllIlIIIllIlllIlllllIl[lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl, lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl, liiiiiiiiIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl + n4, liiiiiiiiIlIllIIllIlIIlIl + 2 * n4, this.IIIIllIIllIIIIllIllIIIlIl), lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl, n2 - n4, n2, n2 + n4, this.IIIIllIIllIIIIllIllIIIlIl), lIIIIIIIIIlIllIIllIlIIlIl(iiiIllIlIIIllIlllIlllllIl, n3 - 2 * n4, n3 - n4, n3, this.IIIIllIIllIIIIllIllIIIlIl), this.IIIIllIIllIIIIllIllIIIlIl)];
        int liiiiiiiiIlIllIIllIlIIlIl2;
        int n5 = liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl;
        int n7;
        int n6 = n7 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        while (true) {
            final int compare;
            if (liiiiiiiiIlIllIIllIlIIlIl2 <= n6 && (compare = this.IIIIllIIllIIIIllIllIIIlIl.compare(iiiIllIlIIIllIlllIlllllIl[liiiiiiiiIlIllIIllIlIIlIl2], o)) <= 0) {
                if (compare == 0) {
                    IlIIlIlIlIIlllIIIllIIIlII.IlIlIIIlllIIIlIlllIlIllIl(iiiIllIlIIIllIlllIlllllIl, n5++, liiiiiiiiIlIllIIllIlIIlIl2);
                }
                ++liiiiiiiiIlIllIIllIlIIlIl2;
            }
            else {
                int compare2;
                while (n6 >= liiiiiiiiIlIllIIllIlIIlIl2 && (compare2 = this.IIIIllIIllIIIIllIllIIIlIl.compare(iiiIllIlIIIllIlllIlllllIl[n6], o)) >= 0) {
                    if (compare2 == 0) {
                        IlIIlIlIlIIlllIIIllIIIlII.IlIlIIIlllIIIlIlllIlIllIl(iiiIllIlIIIllIlllIlllllIl, n6, n7--);
                    }
                    --n6;
                }
                if (liiiiiiiiIlIllIIllIlIIlIl2 > n6) {
                    break;
                }
                IlIIlIlIlIIlllIIIllIIIlII.IlIlIIIlllIIIlIlllIlIllIl(iiiIllIlIIIllIlllIlllllIl, liiiiiiiiIlIllIIllIlIIlIl2++, n6--);
            }
        }
        final int min = Math.min(n5 - this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl2 - n5);
        IlIIlIlIlIIlllIIIllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl2 - min, min);
        final int min2 = Math.min(n7 - n6, this.IlllIIIlIlllIllIlIIlllIlI - n7 - 1);
        IlIIlIlIlIIlllIIIllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, liiiiiiiiIlIllIIllIlIIlIl2, this.IlllIIIlIlllIllIlIIlllIlI - min2, min2);
        final int n8 = liiiiiiiiIlIllIIllIlIIlIl2 - n5;
        final int n9 = n7 - n6;
        if (n8 > 1 && n9 > 1) {
            ForkJoinTask.invokeAll(new IIllIlIIIlllllIIllllIllll(iiiIllIlIIIllIlllIlllllIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n8, this.IIIIllIIllIIIIllIllIIIlIl), new IIllIlIIIlllllIIllllIllll(iiiIllIlIIIllIlllIlllllIl, this.IlllIIIlIlllIllIlIIlllIlI - n9, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIIllIIIIllIllIIIlIl));
        }
        else if (n8 > 1) {
            ForkJoinTask.invokeAll(new IIllIlIIIlllllIIllllIllll(iiiIllIlIIIllIlllIlllllIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n8, this.IIIIllIIllIIIIllIllIIIlIl));
        }
        else {
            ForkJoinTask.invokeAll(new IIllIlIIIlllllIIllllIllll(iiiIllIlIIIllIlllIlllllIl, this.IlllIIIlIlllIllIlIIlllIlI - n9, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIIllIIIIllIllIIIlIl));
        }
    }
}
