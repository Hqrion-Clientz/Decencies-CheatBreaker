import java.util.Random;
import java.util.Iterator;
import java.util.Collection;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllllIlIlllllllIIllIl
{
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final Collection collection) {
        int n = 0;
        final Iterator<IlIllIIlIIllllllIIlIllIlI> iterator = collection.iterator();
        while (iterator.hasNext()) {
            n += iterator.next().IIIIllIlIIIllIlllIlllllIl;
        }
        return n;
    }
    
    public static IlIllIIlIIllllllIIlIllIlI lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final Collection collection, final int bound) {
        if (bound <= 0) {
            throw new IllegalArgumentException();
        }
        int nextInt = random.nextInt(bound);
        for (final IlIllIIlIIllllllIIlIllIlI ilIllIIlIIllllllIIlIllIlI : collection) {
            nextInt -= ilIllIIlIIllllllIIlIllIlI.IIIIllIlIIIllIlllIlllllIl;
            if (nextInt < 0) {
                return ilIllIIlIIllllllIIlIllIlI;
            }
        }
        return null;
    }
    
    public static IlIllIIlIIllllllIIlIllIlI lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final Collection collection) {
        return lIIIIlIIllIIlIIlIIIlIIllI(random, collection, lIIIIlIIllIIlIIlIIIlIIllI(collection));
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIIllllllIIlIllIlI[] array) {
        int n = 0;
        for (int length = array.length, i = 0; i < length; ++i) {
            n += array[i].IIIIllIlIIIllIlllIlllllIl;
        }
        return n;
    }
    
    public static IlIllIIlIIllllllIIlIllIlI lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final IlIllIIlIIllllllIIlIllIlI[] array, final int bound) {
        if (bound <= 0) {
            throw new IllegalArgumentException();
        }
        int nextInt = random.nextInt(bound);
        for (final IlIllIIlIIllllllIIlIllIlI ilIllIIlIIllllllIIlIllIlI : array) {
            nextInt -= ilIllIIlIIllllllIIlIllIlI.IIIIllIlIIIllIlllIlllllIl;
            if (nextInt < 0) {
                return ilIllIIlIIllllllIIlIllIlI;
            }
        }
        return null;
    }
    
    public static IlIllIIlIIllllllIIlIllIlI lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final IlIllIIlIIllllllIIlIllIlI[] array) {
        return lIIIIlIIllIIlIIlIIIlIIllI(random, array, lIIIIlIIllIIlIIlIIIlIIllI(array));
    }
}
