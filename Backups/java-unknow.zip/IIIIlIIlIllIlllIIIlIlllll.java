import java.util.HashMap;
import java.util.List;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public interface IIIIlIIlIllIlllIIIlIlllll
{
    public static final Map lIIIIlIIllIIlIIlIIIlIIllI = new HashMap();
    public static final IIIIlIIlIllIlllIIIlIlllll lIIIIIIIIIlIllIIllIlIIlIl = new lIIIlIllIlIIlIIIllIIlIlll("dummy");
    public static final IIIIlIIlIllIlllIIIlIlllll IlllIIIlIlllIllIlIIlllIlI = new lIIIlIllIlIIlIIIllIIlIlll("deathCount");
    public static final IIIIlIIlIllIlllIIIlIlllll IIIIllIlIIIllIlllIlllllIl = new lIIIlIllIlIIlIIIllIIlIlll("playerKillCount");
    public static final IIIIlIIlIllIlllIIIlIlllll IIIIllIIllIIIIllIllIIIlIl = new lIIIlIllIlIIlIIIllIIlIlll("totalKillCount");
    public static final IIIIlIIlIllIlllIIIlIlllll IlIlIIIlllIIIlIlllIlIllIl = new IllIIllIIlIIlllIIllIlIIll("health");
    
    String lIIIIlIIllIIlIIlIIIlIIllI();
    
    int lIIIIlIIllIIlIIlIIIlIIllI(final List p0);
    
    boolean lIIIIIIIIIlIllIIllIlIIlIl();
}
