import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIIlIIIlllIllIlllIIIl extends llIIIlIIIlllIllIIIIlIlIlI
{
    private static final ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI;
    private static final ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
    private static final ResourceLocation IIIllIllIlIlllllllIlIlIII;
    private static final ResourceLocation IllIIIIIIIlIlIllllIIllIII;
    
    public IIIlIIIlIIIlllIllIlllIIIl(final lllllIlIIllIIlIIlIIIllIIl lllllIlIIllIIlIIlIIIllIIl, final float n) {
        super(lllllIlIIllIIlIIlIIIllIIl, n);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl, final double n, final double n2, final double n3, final float n4, final float n5) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIlIIlIIlIlllllIIIlIl, n, n2, n3, n4, n5);
    }
    
    protected ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl) {
        switch (ilIIIlIIlIIlIlllllIIIlIl.IlIllIllllIIIlIIIllIIIllI()) {
            default: {
                return IIIlIIIlIIIlllIllIlllIIIl.IlIlIIIlllIIIlIlllIlIllIl;
            }
            case 1: {
                return IIIlIIIlIIIlllIllIlllIIIl.lIIIIlIIllIIlIIlIIIlIIllI;
            }
            case 2: {
                return IIIlIIIlIIIlllIllIlllIIIl.IIIllIllIlIlllllllIlIlIII;
            }
            case 3: {
                return IIIlIIIlIIIlllIllIlllIIIl.IllIIIIIIIlIlIllllIIllIII;
            }
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIIlIIlIIlIlllllIIIlIl ilIIIlIIlIIlIlllllIIIlIl, final float n) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIlIIlIIlIlllllIIIlIl, n);
        if (ilIIIlIIlIIlIlllllIIIlIl.llllIIllIIlIIllIIIllIlIlI()) {
            GL11.glScalef(0.21000001f * 3.8095238f, 0.859375f * 0.9309091f, 1.0f * 0.8f);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIlIIlIIlIlllllIIIlIl)illlIIIllIlIIlIllIIlIlllI, n, n2, n3, n4, n5);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIlIIlIIlIlllllIIIlIl)entityLivingBase, n);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIlIIlIIlIlllllIIIlIl)entityLivingBase, n, n2, n3, n4, n5);
    }
    
    @Override
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIlIIlIIlIlllllIIIlIl)entity);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final float n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IIlIIIlIIlIIlIlllllIIIlIl)entity, n, n2, n3, n4, n5);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = new ResourceLocation("textures/entity/cat/black.png");
        IlIlIIIlllIIIlIlllIlIllIl = new ResourceLocation("textures/entity/cat/ocelot.png");
        IIIllIllIlIlllllllIlIlIII = new ResourceLocation("textures/entity/cat/red.png");
        IllIIIIIIIlIlIllllIIllIII = new ResourceLocation("textures/entity/cat/siamese.png");
    }
}
