// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIllIIllllIIIllllIIIlIIII extends lllllIlIllIlIlIllIIIIIIIl
{
    public IIllIIllllIIIllllIIIlIIII() {
    }
    
    protected IIllIIllllIIIllllIIIlIIII(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final int n) {
        super(llIllllIIIIIIIlllIIIIlIlI, n);
    }
}
