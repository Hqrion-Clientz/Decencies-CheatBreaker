import org.lwjgl.opengl.GL11;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIllIlIIllIIllIlIlll extends lIIIlIlIIllIIlllIIIlIIllI
{
    private final List IIIIllIlIIIllIlllIlllllIl;
    private ResourceLocation IIIIllIIllIIIIllIllIIIlIl;
    private ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
    private final lIIIllIIIIlIIllIIIIIIIlll IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    
    public IIIlllIllIlIIllIIllIlIlll() {
        this.IIIIllIlIIIllIlllIlllllIl = new ArrayList();
        this.IIIIllIIllIIIIllIllIIIlIl = new ResourceLocation("client/icons/left.png");
        this.IlIlIIIlllIIIlIlllIlIllIl = new ResourceLocation("client/icons/right.png");
        this.IllIIIIIIIlIlIllllIIllIII = 0;
        this.IIIllIllIlIlllllllIlIlIII = new lIIIllIIIIlIIllIIIIIIIlll("BACK");
        final Iterator<IlIlIIIlllIIIlIlllIlIllIl> iterator = CheatBreaker.getInstance().IIIlIIllllIIllllllIlIIIll().iterator();
        while (iterator.hasNext()) {
            this.IIIIllIlIIIllIlllIlllllIl.add(new llIlIlIllIlIIlIlllIllIIlI(iterator.next(), 1.0f));
        }
    }
    
    @Override
    public void setProgress(final float n, final float n2) {
        super.setProgress(n, n2);
        if (!CheatBreaker.getInstance().lIllIllIlIIllIllIlIlIIlIl().IlllIllIlIIIIlIIlIIllIIIl()) {
            CheatBreaker.getInstance().IIIlllIIIllIllIlIIIIIIlII.IlllIIIlIlllIllIlIIlllIlI("Unable to connect to the server.", this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f, this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 10, -1);
            CheatBreaker.getInstance().IIIlllIIIllIllIlIIIIIIlII.IlllIIIlIlllIllIlIIlllIlI("Please try again later.", this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 4, -1);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 30, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 28, 60, 12);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true);
        }
        else {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 80, this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 78, this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 80, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 100, 788529152);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 30, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 105, 60, 12);
            this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, true);
            if (this.IIIIllIlIIIllIlllIlllllIl.isEmpty()) {
                CheatBreaker.getInstance().IIIlllIIIllIllIlIIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl("You don't own any cosmetics.", this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 4, -6381922);
            }
            else {
                final float n3 = this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 68;
                final float n4 = this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 92;
                final float n5 = this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 68;
                final float n6 = this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 74;
                CheatBreaker.getInstance().IlllIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl("Cosmetics (" + this.IIIIllIlIIIllIlllIlllllIl.size() + ")", this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f, this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 90, -1);
                int n7 = 0;
                float n8 = 0.0f;
                for (final llIlIlIllIlIIlIlllIllIIlI llIlIlIllIlIIlIlllIllIIlI : this.IIIIllIlIIIllIlllIlllllIl) {
                    if (++n7 - 1 >= this.IllIIIIIIIlIlIllllIIllIII * 5) {
                        if (n7 - 1 >= (this.IllIIIIIIIlIlIllllIIllIII + 1) * 5) {
                            continue;
                        }
                        llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI((int)this.IlIlIIIlllIIIlIlllIlIllIl() / 2 - 76, (int)(this.IIIllIllIlIlllllllIlIlIII() / 2.0f - 72 + n8), 152, llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI());
                        llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI((int)n, (int)n2, 1.0f);
                        n8 += llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI();
                    }
                }
                if (this.IIIIllIlIIIllIlllIlllllIl.size() > 5) {
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, (n > this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 40 && n < this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 1.0f && n2 > this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 80 && n2 < this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 100) ? (0.37499997f * 1.2f) : (0.8958333f * 0.27906978f));
                    lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl, 4, this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 10, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 84);
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, (n > this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 1.0f && n < this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 40 && n2 > this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 80 && n2 < this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 100) ? (0.012658228f * 35.55f) : (0.7083333f * 0.3529412f));
                    lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl, 4, this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 10, this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 84);
                }
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final float n2, final int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        if (this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlIlIIIIIllIlIlIIllIlIIIl());
        }
        else {
            if (this.IIIIllIlIIIllIlllIlllllIl.size() > 5) {
                final boolean b = n > this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 40 && n < this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - 1.0f && n2 > this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 80 && n2 < this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 100;
                final boolean b2 = n > this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 1.0f && n < this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f + 40 && n2 > this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 80 && n2 < this.IIIllIllIlIlllllllIlIlIII() / 2.0f + 100;
                if (this.IllIIIIIIIlIlIllllIIllIII > 0 && b) {
                    --this.IllIIIIIIIlIlIllllIIllIII;
                    Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                }
                else if (b2 && this.IllIIIIIIIlIlIllllIIllIII + 1 < this.IIIIllIlIIIllIlllIlllllIl.size() / (float)5) {
                    ++this.IllIIIIIIIlIlIllllIIllIII;
                    Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                }
            }
            int n4 = 0;
            for (final llIlIlIllIlIIlIlllIllIIlI llIlIlIllIlIIlIlllIllIIlI : this.IIIIllIlIIIllIlllIlllllIl) {
                if (++n4 - 1 >= this.IllIIIIIIIlIlIllllIIllIII * 5) {
                    if (n4 - 1 >= (this.IllIIIIIIIlIlIllllIIllIII + 1) * 5) {
                        continue;
                    }
                    llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI((int)n, (int)n2, n3);
                }
            }
        }
    }
}
