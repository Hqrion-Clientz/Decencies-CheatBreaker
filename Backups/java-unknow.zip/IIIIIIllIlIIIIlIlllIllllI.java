import java.util.UUID;
import java.util.Iterator;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.Calendar;
import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIIIIllIlIIIIlIlllIllllI implements lIIllIIIllIIIIllIllIIllIl
{
    public boolean lIIIIIIIIIlIllIIllIlIIlIl;
    public List IlllIIIlIlllIllIlIIlllIlI;
    protected List IIIIllIlIIIllIlllIlllllIl;
    public List IIIIllIIllIIIIllIllIIIlIl;
    private List lIIIIlIIllIIlIIlIIIlIIllI;
    private List IllIIlllIllIlIllIlIIIIIII;
    public List IlIlIIIlllIIIlIlllIlIllIl;
    public List IIIllIllIlIlllllllIlIlIII;
    private long IlIlIIIlllllIIIlIlIlIllII;
    public int IllIIIIIIIlIlIllllIIllIII;
    protected int lIIIIllIIlIlIllIIIlIllIlI;
    protected final int IlllIllIlIIIIlIIlIIllIIIl = 1013904223;
    protected float IlIlllIIIIllIllllIllIIlIl;
    protected float llIIlllIIIIlllIllIlIlllIl;
    protected float lIIlIlIllIIlIIIlIIIlllIII;
    protected float IIIlllIIIllIllIlIIIIIIlII;
    public int llIlIIIlIIIIlIlllIlIIIIll;
    public lIIlIlIIllIIllllIIIlIlIlI IIIlIIllllIIllllllIlIIIll;
    public Random lllIIIIIlIllIlIIIllllllII;
    public final IlIIlIllllllIlIIllIlIlIlI lIIIIIllllIIIIlIlIIIIlIlI;
    protected List IIIIIIlIlIlIllllllIlllIlI;
    protected IllIlIIIlIIlllIIIlIIlIllI IllIllIIIlIIlllIIIllIllII;
    protected final IIIlIIIllIIIlIlllIlIIIlII IlIIlIIIIlIIIIllllIIlIllI;
    protected IllIlIlllIIIIIIlIIllIIIll lIIlIIllIIIIIlIllIIIIllII;
    public boolean lIIlllIIlIlllllllllIIIIIl;
    public IlIllIIIllIlIlIIlIIlIllIl lIllIllIlIIllIllIlIlIIlIl;
    public final lllIIlIIllIIIIIllIlllIlII llIlIIIllIIIIlllIlIIIIIlI;
    protected final IIlllIlllllllllIIIllIIIlI lIllIlIlllIIlIIllIIlIIlII;
    public final Profiler IIIlIIlIlIIIlllIIlIllllll;
    private final Calendar IIlIIllIIIllllIIlllIllIIl;
    protected IlIIIIllIlIlIIIlIIIllIIlI IllIlIIIIlllIIllIIlllIIlI;
    public boolean IllIlIlIllllIlIIllllIIlll;
    protected Set IllIIlIIlllllIllIIIlllIII;
    private int lllIlIIllllIIIIlIllIlIIII;
    protected boolean lIlIlIllIIIIIIIIllllIIllI;
    protected boolean IlllIIlllIIIIllIIllllIlIl;
    private ArrayList lIIIIlllIIlIlllllIlIllIII;
    private boolean lIIIlllIlIlllIIIIIIIIIlII;
    int[] IllllIllllIlIIIlIIIllllll;
    
    @Override
    public IIlIIlIIllIIllIlIIIIIIIlI a_(final int n, final int n2) {
        if (this.IIIIllIIllIIIIllIllIIIlIl(n, 0, n2)) {
            final lIlllllIIllIlIlIlllIIIIII iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl(n, n2);
            try {
                return iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n & 0xF, n2 & 0xF, this.lIIIIIllllIIIIlIlIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl);
            }
            catch (Throwable t) {
                return IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIllllIIllllllIlIIIll;
            }
        }
        return this.lIIIIIllllIIIIlIlIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    public IIlIllIIlIlIIIlIlIllIIIlI lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public IIIIIIllIlIIIIlIlllIllllI(final IIIlIIIllIIIlIlllIlIIIlII ilIIlIIIIlIIIIllllIIlIllI, final String s, final IlIIlIllllllIlIIllIlIlIlI liiiiIllllIIIIlIlIIIIlIlI, final lIIIlIlllllIIlIIlIlIIlllI liiIlIlllllIIlIIlIlIIlllI, final Profiler iiIlIIlIlIIIlllIIlIllllll) {
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.IIIIllIlIIIllIlllIlllllIl = new ArrayList();
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.IllIIlllIllIlIllIlIIIIIII = new ArrayList();
        this.IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
        this.IIIllIllIlIlllllllIlIlIII = new ArrayList();
        this.IlIlIIIlllllIIIlIlIlIllII = 16777215L;
        this.lIIIIllIIlIlIllIIIlIllIlI = new Random().nextInt();
        this.lllIIIIIlIllIlIIIllllllII = new Random();
        this.IIIIIIlIlIlIllllllIlllIlI = new ArrayList();
        this.lIllIlIlllIIlIIllIIlIIlII = new IIlllIlllllllllIIIllIIIlI(this);
        this.IIlIIllIIIllllIIlllIllIIl = Calendar.getInstance();
        this.IllIlIIIIlllIIllIIlllIIlI = new IlIIIIllIlIlIIIlIIIllIIlI();
        this.IllIIlIIlllllIllIIIlllIII = new HashSet();
        this.lllIlIIllllIIIIlIllIlIIII = this.lllIIIIIlIllIlIIIllllllII.nextInt(12000);
        this.lIlIlIllIIIIIIIIllllIIllI = true;
        this.IlllIIlllIIIIllIIllllIlIl = true;
        this.lIIIIlllIIlIlllllIlIllIII = new ArrayList();
        this.IllllIllllIlIIIlIIIllllll = new int[32768];
        this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
        this.IIIlIIlIlIIIlllIIlIllllll = iiIlIIlIlIIIlllIIlIllllll;
        this.lIIlIIllIIIIIlIllIIIIllII = new IllIlIlllIIIIIIlIIllIIIll(liiIlIlllllIIlIIlIlIIlllI, s);
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        this.lIllIllIlIIllIllIlIlIIlIl = new IlIllIIIllIlIlIIlIIlIllIl(ilIIlIIIIlIIIIllllIIlIllI);
        final lllIIlIIllIIIIIllIlllIlII llIlIIIllIIIIlllIlIIIIIlI = (lllIIlIIllIIIIIllIlllIlII)this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIlIIllIIIIIllIlllIlII.class, "villages");
        if (llIlIIIllIIIIlllIlIIIIIlI == null) {
            this.llIlIIIllIIIIlllIlIIIIIlI = new lllIIlIIllIIIIIllIlllIlII(this);
            this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("villages", this.llIlIIIllIIIIlllIlIIIIIlI);
        }
        else {
            (this.llIlIIIllIIIIlllIlIIIIIlI = llIlIIIllIIIIlllIlIIIIIlI).lIIIIlIIllIIlIIlIIIlIIllI(this);
        }
        liiiiIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
        this.IllIllIIIlIIlllIIIllIllII = this.lIIIIIIIIIlIllIIllIlIIlIl();
        this.lllIIIIIlIllIlIIIllllllII();
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    public IIIIIIllIlIIIIlIlllIllllI(final IIIlIIIllIIIlIlllIlIIIlII ilIIlIIIIlIIIIllllIIlIllI, final String s, final lIIIlIlllllIIlIIlIlIIlllI liiIlIlllllIIlIIlIlIIlllI, final IlIIlIllllllIlIIllIlIlIlI liiiiIllllIIIIlIlIIIIlIlI, final Profiler iiIlIIlIlIIIlllIIlIllllll) {
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.IIIIllIlIIIllIlllIlllllIl = new ArrayList();
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.IllIIlllIllIlIllIlIIIIIII = new ArrayList();
        this.IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
        this.IIIllIllIlIlllllllIlIlIII = new ArrayList();
        this.IlIlIIIlllllIIIlIlIlIllII = 16777215L;
        this.lIIIIllIIlIlIllIIIlIllIlI = new Random().nextInt();
        this.lllIIIIIlIllIlIIIllllllII = new Random();
        this.IIIIIIlIlIlIllllllIlllIlI = new ArrayList();
        this.lIllIlIlllIIlIIllIIlIIlII = new IIlllIlllllllllIIIllIIIlI(this);
        this.IIlIIllIIIllllIIlllIllIIl = Calendar.getInstance();
        this.IllIlIIIIlllIIllIIlllIIlI = new IlIIIIllIlIlIIIlIIIllIIlI();
        this.IllIIlIIlllllIllIIIlllIII = new HashSet();
        this.lllIlIIllllIIIIlIllIlIIII = this.lllIIIIIlIllIlIIIllllllII.nextInt(12000);
        this.lIlIlIllIIIIIIIIllllIIllI = true;
        this.IlllIIlllIIIIllIIllllIlIl = true;
        this.lIIIIlllIIlIlllllIlIllIII = new ArrayList();
        this.IllllIllllIlIIIlIIIllllll = new int[32768];
        this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
        this.IIIlIIlIlIIIlllIIlIllllll = iiIlIIlIlIIIlllIIlIllllll;
        this.lIllIllIlIIllIllIlIlIIlIl = new IlIllIIIllIlIlIIlIIlIllIl(ilIIlIIIIlIIIIllllIIlIllI);
        this.lIIlIIllIIIIIlIllIIIIllII = ilIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI();
        if (liiiiIllllIIIIlIlIIIIlIlI != null) {
            this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        }
        else if (this.lIIlIIllIIIIIlIllIIIIllII != null && this.lIIlIIllIIIIIlIllIIIIllII.IlllIllIlIIIIlIIlIIllIIIl() != 0) {
            this.lIIIIIllllIIIIlIlIIIIlIlI = IlIIlIllllllIlIIllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIllIIIIIlIllIIIIllII.IlllIllIlIIIIlIIlIIllIIIl());
        }
        else {
            this.lIIIIIllllIIIIlIlIIIIlIlI = IlIIlIllllllIlIIllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(0);
        }
        if (this.lIIlIIllIIIIIlIllIIIIllII == null) {
            this.lIIlIIllIIIIIlIllIIIIllII = new IllIlIlllIIIIIIlIIllIIIll(liiIlIlllllIIlIIlIlIIlllI, s);
        }
        else {
            this.lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(s);
        }
        this.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this);
        this.IllIllIIIlIIlllIIIllIllII = this.lIIIIIIIIIlIllIIllIlIIlIl();
        if (!this.lIIlIIllIIIIIlIllIIIIllII.lIIlllIIlIlllllllllIIIIIl()) {
            try {
                this.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlllllIIlIIlIlIIlllI);
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Exception initializing level");
                try {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(crashReport);
                }
                catch (Throwable t2) {}
                throw new ReportedException(crashReport);
            }
            this.lIIlIIllIIIIIlIllIIIIllII.IlllIIIlIlllIllIlIIlllIlI(true);
        }
        final lllIIlIIllIIIIIllIlllIlII llIlIIIllIIIIlllIlIIIIIlI = (lllIIlIIllIIIIIllIlllIlII)this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIlIIllIIIIIllIlllIlII.class, "villages");
        if (llIlIIIllIIIIlllIlIIIIIlI == null) {
            this.llIlIIIllIIIIlllIlIIIIIlI = new lllIIlIIllIIIIIllIlllIlII(this);
            this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("villages", this.llIlIIIllIIIIlllIlIIIIIlI);
        }
        else {
            (this.llIlIIIllIIIIlllIlIIIIIlI = llIlIIIllIIIIlllIlIIIIIlI).lIIIIlIIllIIlIIlIIIlIIllI(this);
        }
        this.lllIIIIIlIllIlIIIllllllII();
        this.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    protected abstract IllIlIIIlIIlllIIIlIIlIllI lIIIIIIIIIlIllIIllIlIIlIl();
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlllllIIlIIlIlIIlllI liiIlIlllllIIlIIlIlIIlllI) {
        this.lIIlIIllIIIIIlIllIIIIllII.IlllIIIlIlllIllIlIIlllIlI(true);
    }
    
    public void IlllIllIlIIIIlIIlIIllIIIl() {
        this.IlIIlIIIIlIIIIllllIIlIllI(8, 64, 8);
    }
    
    public IIlllllllIlllIIllllIIlIll lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        int n3;
        for (n3 = 63; !this.IIIIllIlIIIllIlllIlllllIl(n, n3 + 1, n2); ++n3) {}
        return this.getBlock(n, n3, n2);
    }
    
    @Override
    public IIlllllllIlllIIllllIIlIll getBlock(final int n, final int n2, final int n3) {
        if (n >= -30000000 && n3 >= -30000000 && n < 30000000 && n3 < 30000000 && n2 >= 0 && n2 < 256) {
            lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = null;
            try {
                iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
                return iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(n & 0xF, n2, n3 & 0xF);
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Exception getting block type in world");
                crashReport.makeCategory("Requested block coordinates").lIIIIlIIllIIlIIlIIIlIIllI("Found chunk", iiiIllIIllIIIIllIllIIIlIl == null);
                throw new ReportedException(crashReport);
            }
        }
        return IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3) {
        return this.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() == Material.air;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3) {
        return n2 >= 0 && n2 < 256 && this.IlllIIIlIlllIllIlIIlllIlI(n >> 4, n3 >> 4);
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final int n4) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(n - n4, n2 - n4, n3 - n4, n + n4, n2 + n4, n3 + n4);
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(int n, final int n2, int n3, int n4, final int n5, int n6) {
        if (n5 >= 0 && n2 < 256) {
            n >>= 4;
            n3 >>= 4;
            n4 >>= 4;
            n6 >>= 4;
            for (int i = n; i <= n4; ++i) {
                for (int j = n3; j <= n6; ++j) {
                    if (!this.IlllIIIlIlllIllIlIIlllIlI(i, j)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    protected boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2) {
        return this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
    }
    
    public lIlllllIIllIlIlIlllIIIIII IIIIllIlIIIllIlllIlllllIl(final int n, final int n2) {
        return this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n2 >> 4);
    }
    
    public lIlllllIIllIlIlIlllIIIIII IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2) {
        return this.IllIllIIIlIIlllIIIllIllII.IIIIllIlIIIllIlllIlllllIl(n, n2);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4, final int n5) {
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return false;
        }
        if (n2 < 0) {
            return false;
        }
        if (n2 >= 256) {
            return false;
        }
        final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
        IIlllllllIlllIIllllIIlIll liiiiiiiiIlIllIIllIlIIlIl = null;
        if ((n5 & 0x1) != 0x0) {
            liiiiiiiiIlIllIIllIlIIlIl = iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(n & 0xF, n2, n3 & 0xF);
        }
        final boolean liiiIlIIllIIlIIlIIIlIIllI = iiiIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n & 0xF, n2, n3 & 0xF, illlllllIlllIIllllIIlIll, n4);
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("checkLight");
        this.lllIIIIIlIllIlIIIllllllII(n, n2, n3);
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        if (liiiIlIIllIIlIIlIIIlIIllI) {
            if ((n5 & 0x2) != 0x0 && (!this.IllIlIlIllllIlIIllllIIlll || (n5 & 0x4) == 0x0) && iiiIllIIllIIIIllIllIIIlIl.lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IIIllIllIlIlllllllIlIlIII(n, n2, n3);
            }
            if (!this.IllIlIlIllllIlIIllllIIlll && (n5 & 0x1) != 0x0) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, liiiiiiiiIlIllIIllIlIIlIl);
                if (illlllllIlllIIllllIIlIll.lllIlIIllllIIIIlIllIlIIII()) {
                    this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3, illlllllIlllIIllllIIlIll);
                }
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI(int n, final int n2, int n3) {
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return 0;
        }
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 256) {
            return 0;
        }
        final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
        n &= 0xF;
        n3 &= 0xF;
        return iiiIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5) {
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return false;
        }
        if (n2 < 0) {
            return false;
        }
        if (n2 >= 256) {
            return false;
        }
        final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
        final int n6 = n & 0xF;
        final int n7 = n3 & 0xF;
        final boolean liiiIlIIllIIlIIlIIIlIIllI = iiiIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n6, n2, n7, n4);
        if (liiiIlIIllIIlIIlIIIlIIllI) {
            final IIlllllllIlllIIllllIIlIll liiiiiiiiIlIllIIllIlIIlIl = iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(n6, n2, n7);
            if ((n5 & 0x2) != 0x0 && (!this.IllIlIlIllllIlIIllllIIlll || (n5 & 0x4) == 0x0) && iiiIllIIllIIIIllIllIIIlIl.lIIIIllIIlIlIllIIIlIllIlI()) {
                this.IIIllIllIlIlllllllIlIlIII(n, n2, n3);
            }
            if (!this.IllIlIlIllllIlIIllllIIlll && (n5 & 0x1) != 0x0) {
                this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, liiiiiiiiIlIllIIllIlIIlIl);
                if (liiiiiiiiIlIllIIllIlIIlIl.lllIlIIllllIIIIlIllIlIIII()) {
                    this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3, liiiiiiiiIlIllIIllIlIIlIl);
                }
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final int n, final int n2, final int n3) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, 0, 3);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final boolean b) {
        final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
        if (block.IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            return false;
        }
        final int illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        this.IlllIIIlIlllIllIlIIlllIlI(2001, n, n2, n3, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(block) + (illlIIIlIlllIllIlIIlllIlI << 12));
        if (b) {
            block.lIIIIlIIllIIlIIlIIIlIIllI(this, n, n2, n3, illlIIIlIlllIllIlIIlllIlI, 0);
        }
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, 0, 3);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlllllIlllIIllllIIlIll, 0, 3);
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final int n, final int n2, final int n3) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, illlllllIlllIIllllIIlIll);
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, int n3, int n4) {
        if (n3 > n4) {
            final int n5 = n4;
            n4 = n3;
            n3 = n5;
        }
        if (!this.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII) {
            for (int i = n3; i <= n4; ++i) {
                this.IlllIIIlIlllIllIlIIlllIlI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI, n, i, n2);
            }
        }
        this.IlllIIIlIlllIllIlIIlllIlI(n, n3, n2, n, n4, n2);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, n4, n5, n6);
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        this.IIIIllIlIIIllIlllIlllllIl(n - 1, n2, n3, illlllllIlllIIllllIIlIll);
        this.IIIIllIlIIIllIlllIlllllIl(n + 1, n2, n3, illlllllIlllIIllllIIlIll);
        this.IIIIllIlIIIllIlllIlllllIl(n, n2 - 1, n3, illlllllIlllIIllllIIlIll);
        this.IIIIllIlIIIllIlllIlllllIl(n, n2 + 1, n3, illlllllIlllIIllllIIlIll);
        this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 - 1, illlllllIlllIIllllIIlIll);
        this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 + 1, illlllllIlllIIllllIIlIll);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        if (n4 != 4) {
            this.IIIIllIlIIIllIlllIlllllIl(n - 1, n2, n3, illlllllIlllIIllllIIlIll);
        }
        if (n4 != 5) {
            this.IIIIllIlIIIllIlllIlllllIl(n + 1, n2, n3, illlllllIlllIIllllIIlIll);
        }
        if (n4 != 0) {
            this.IIIIllIlIIIllIlllIlllllIl(n, n2 - 1, n3, illlllllIlllIIllllIIlIll);
        }
        if (n4 != 1) {
            this.IIIIllIlIIIllIlllIlllllIl(n, n2 + 1, n3, illlllllIlllIIllllIIlIll);
        }
        if (n4 != 2) {
            this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 - 1, illlllllIlllIIllllIIlIll);
        }
        if (n4 != 3) {
            this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3 + 1, illlllllIlllIIllllIIlIll);
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!this.IllIlIlIllllIlIIllllIIlll) {
            final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
            try {
                block.lIIIIlIIllIIlIIlIIIlIIllI(this, n, n2, n3, illlllllIlllIIllllIIlIll);
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Exception while updating neighbours");
                final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Block being updated");
                int illlIIIlIlllIllIlIIlllIlI;
                try {
                    illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
                }
                catch (Throwable t2) {
                    illlIIIlIlllIllIlIIlllIlI = -1;
                }
                category.addCrashSectionCallable("Source block type", new IIIIIlllIIlIIIlIIIIIlIIll(this, illlllllIlllIIllllIIlIll));
                lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(category, n, n2, n3, block, illlIIIlIlllIllIlIIlllIlI);
                throw new ReportedException(crashReport);
            }
        }
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return false;
    }
    
    public boolean IllIIIIIIIlIlIllllIIllIII(final int n, final int n2, final int n3) {
        return this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4).IIIIllIlIIIllIlllIlllllIl(n & 0xF, n2, n3 & 0xF);
    }
    
    public int lIIIIllIIlIlIllIIIlIllIlI(final int n, int n2, final int n3) {
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 256) {
            n2 = 255;
        }
        return this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4).lIIIIIIIIIlIllIIllIlIIlIl(n & 0xF, n2, n3 & 0xF, 0);
    }
    
    public int IlllIllIlIIIIlIIlIIllIIIl(final int n, final int n2, final int n3) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, true);
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(int n, int n2, int n3, final boolean b) {
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return 15;
        }
        if (b && this.getBlock(n, n2, n3).IIIIllIIllIIIIllIllIIIlIl()) {
            int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2 + 1, n3, false);
            final int liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl(n + 1, n2, n3, false);
            final int liiiiiiiiIlIllIIllIlIIlIl3 = this.lIIIIIIIIIlIllIIllIlIIlIl(n - 1, n2, n3, false);
            final int liiiiiiiiIlIllIIllIlIIlIl4 = this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 + 1, false);
            final int liiiiiiiiIlIllIIllIlIIlIl5 = this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 - 1, false);
            if (liiiiiiiiIlIllIIllIlIIlIl2 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl2;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl3 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl3;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl4 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl4;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl5 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl5;
            }
            return liiiiiiiiIlIllIIllIlIIlIl;
        }
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 256) {
            n2 = 255;
        }
        final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
        n &= 0xF;
        n3 &= 0xF;
        return iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, this.IllIIIIIIIlIlIllllIIllIII);
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl(final int n, final int n2) {
        if (n < -30000000 || n2 < -30000000 || n >= 30000000 || n2 >= 30000000) {
            return 64;
        }
        if (!this.IlllIIIlIlllIllIlIIlllIlI(n >> 4, n2 >> 4)) {
            return 0;
        }
        return this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n2 >> 4).lIIIIIIIIIlIllIIllIlIIlIl(n & 0xF, n2 & 0xF);
    }
    
    public int IIIllIllIlIlllllllIlIlIII(final int n, final int n2) {
        if (n < -30000000 || n2 < -30000000 || n >= 30000000 || n2 >= 30000000) {
            return 64;
        }
        if (!this.IlllIIIlIlllIllIlIIlllIlI(n >> 4, n2 >> 4)) {
            return 0;
        }
        return this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n2 >> 4).lIIIIIllllIIIIlIlIIIIlIlI;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, int n2, final int n3) {
        if (this.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII && liiIlIlIllllIIIlIlIlIIIlI == lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            return 0;
        }
        if (n2 < 0) {
            n2 = 0;
        }
        if (n2 >= 256) {
            return liiIlIlIllllIIIlIlIlIIIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return liiIlIlIllllIIIlIlIlIIIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        final int n4 = n >> 4;
        final int n5 = n3 >> 4;
        if (!this.IlllIIIlIlllIllIlIIlllIlI(n4, n5)) {
            return liiIlIlIllllIIIlIlIlIIIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        if (this.getBlock(n, n2, n3).IIIIllIIllIIIIllIllIIIlIl()) {
            int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n, n2 + 1, n3);
            final int liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n + 1, n2, n3);
            final int liiiiiiiiIlIllIIllIlIIlIl3 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n - 1, n2, n3);
            final int liiiiiiiiIlIllIIllIlIIlIl4 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n, n2, n3 + 1);
            final int liiiiiiiiIlIllIIllIlIIlIl5 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n, n2, n3 - 1);
            if (liiiiiiiiIlIllIIllIlIIlIl2 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl2;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl3 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl3;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl4 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl4;
            }
            if (liiiiiiiiIlIllIIllIlIIlIl5 > liiiiiiiiIlIllIIllIlIIlIl) {
                liiiiiiiiIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl5;
            }
            return liiiiiiiiIlIllIIllIlIIlIl;
        }
        return this.IIIIllIIllIIIIllIllIIIlIl(n4, n5).lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIllllIIIlIlIlIIIlI, n & 0xF, n2, n3 & 0xF);
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, int n2, final int n3) {
        if (n2 < 0) {
            n2 = 0;
        }
        if (n2 >= 256) {
            n2 = 255;
        }
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return liiIlIlIllllIIIlIlIlIIIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        final int n4 = n >> 4;
        final int n5 = n3 >> 4;
        if (!this.IlllIIIlIlllIllIlIIlllIlI(n4, n5)) {
            return liiIlIlIllllIIIlIlIlIIIlI.IlllIIIlIlllIllIlIIlllIlI;
        }
        return this.IIIIllIIllIIIIllIllIIIlIl(n4, n5).lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIllllIIIlIlIlIIIlI, n & 0xF, n2, n3 & 0xF);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, final int n2, final int n3, final int n4) {
        if (n >= -30000000 && n3 >= -30000000 && n < 30000000 && n3 < 30000000 && n2 >= 0 && n2 < 256 && this.IlllIIIlIlllIllIlIIlllIlI(n >> 4, n3 >> 4)) {
            this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4).lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIllllIIIlIlIlIIIlI, n & 0xF, n2, n3 & 0xF, n4);
            for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
                ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
            }
        }
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final int n, final int n2, final int n3) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        }
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI, n, n2, n3);
        int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl, n, n2, n3);
        if (liiiIlIIllIIlIIlIIIlIIllI2 < n4) {
            liiiIlIIllIIlIIlIIIlIIllI2 = n4;
        }
        return liiiIlIIllIIlIIlIIIlIIllI << 20 | liiiIlIIllIIlIIlIIIlIIllI2 << 4;
    }
    
    public float llIIlllIIIIlllIllIlIlllIl(final int n, final int n2, final int n3) {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.IllIIIIIIIlIlIllllIIllIII[this.IlllIllIlIIIIlIIlIIllIIIl(n, n2, n3)];
    }
    
    public boolean IlIlllIIIIllIllllIllIIlIl() {
        return this.IllIIIIIIIlIlIllllIIllIII < 4;
    }
    
    public MovingObjectPosition lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII, lIllIIIIlllllIIlIllIIIIII2, false, false, false);
    }
    
    public MovingObjectPosition lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2, final boolean b) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII, lIllIIIIlllllIIlIllIIIIII2, b, false, false);
    }
    
    public MovingObjectPosition lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII2, final boolean b, final boolean b2, final boolean b3) {
        if (Double.isNaN(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI) || Double.isNaN(lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl) || Double.isNaN(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI)) {
            return null;
        }
        if (!Double.isNaN(lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI) && !Double.isNaN(lIllIIIIlllllIIlIllIIIIII2.lIIIIIIIIIlIllIIllIlIIlIl) && !Double.isNaN(lIllIIIIlllllIIlIllIIIIII2.IlllIIIlIlllIllIlIIlllIlI)) {
            final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI);
            final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII2.lIIIIIIIIIlIllIIllIlIIlIl);
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII2.IlllIIIlIlllIllIlIIlllIlI);
            int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI);
            int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl);
            int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI);
            final IIlllllllIlllIIllllIIlIll block = this.getBlock(illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6);
            final int illlIIIlIlllIllIlIIlllIlI7 = this.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6);
            if ((!b2 || block.IlllIIIlIlllIllIlIIlllIlI(this, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6) != null) && block.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI7, b)) {
                final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = block.lIIIIlIIllIIlIIlIIIlIIllI(this, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6, lIllIIIIlllllIIlIllIIIIII, lIllIIIIlllllIIlIllIIIIII2);
                if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                    return liiiIlIIllIIlIIlIIIlIIllI;
                }
            }
            MovingObjectPosition movingObjectPosition = null;
            int n = 200;
            while (n-- >= 0) {
                if (Double.isNaN(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI) || Double.isNaN(lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl) || Double.isNaN(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI)) {
                    return null;
                }
                if (illlIIIlIlllIllIlIIlllIlI4 == illlIIIlIlllIllIlIIlllIlI && illlIIIlIlllIllIlIIlllIlI5 == illlIIIlIlllIllIlIIlllIlI2 && illlIIIlIlllIllIlIIlllIlI6 == illlIIIlIlllIllIlIIlllIlI3) {
                    return b3 ? movingObjectPosition : null;
                }
                boolean b4 = true;
                boolean b5 = true;
                boolean b6 = true;
                double liiiIlIIllIIlIIlIIIlIIllI2 = 999;
                double liiiiiiiiIlIllIIllIlIIlIl = 999;
                double illlIIIlIlllIllIlIIlllIlI8 = 999;
                if (illlIIIlIlllIllIlIIlllIlI > illlIIIlIlllIllIlIIlllIlI4) {
                    liiiIlIIllIIlIIlIIIlIIllI2 = illlIIIlIlllIllIlIIlllIlI4 + 1.0;
                }
                else if (illlIIIlIlllIllIlIIlllIlI < illlIIIlIlllIllIlIIlllIlI4) {
                    liiiIlIIllIIlIIlIIIlIIllI2 = illlIIIlIlllIllIlIIlllIlI4 + 0.0;
                }
                else {
                    b4 = false;
                }
                if (illlIIIlIlllIllIlIIlllIlI2 > illlIIIlIlllIllIlIIlllIlI5) {
                    liiiiiiiiIlIllIIllIlIIlIl = illlIIIlIlllIllIlIIlllIlI5 + 1.0;
                }
                else if (illlIIIlIlllIllIlIIlllIlI2 < illlIIIlIlllIllIlIIlllIlI5) {
                    liiiiiiiiIlIllIIllIlIIlIl = illlIIIlIlllIllIlIIlllIlI5 + 0.0;
                }
                else {
                    b5 = false;
                }
                if (illlIIIlIlllIllIlIIlllIlI3 > illlIIIlIlllIllIlIIlllIlI6) {
                    illlIIIlIlllIllIlIIlllIlI8 = illlIIIlIlllIllIlIIlllIlI6 + 1.0;
                }
                else if (illlIIIlIlllIllIlIIlllIlI3 < illlIIIlIlllIllIlIIlllIlI6) {
                    illlIIIlIlllIllIlIIlllIlI8 = illlIIIlIlllIllIlIIlllIlI6 + 0.0;
                }
                else {
                    b6 = false;
                }
                double n2 = 999;
                double n3 = 999;
                double n4 = 999;
                final double n5 = lIllIIIIlllllIIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI;
                final double n6 = lIllIIIIlllllIIlIllIIIIII2.lIIIIIIIIIlIllIIllIlIIlIl - lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl;
                final double n7 = lIllIIIIlllllIIlIllIIIIII2.IlllIIIlIlllIllIlIIlllIlI - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI;
                if (b4) {
                    n2 = (liiiIlIIllIIlIIlIIIlIIllI2 - lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI) / n5;
                }
                if (b5) {
                    n3 = (liiiiiiiiIlIllIIllIlIIlIl - lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl) / n6;
                }
                if (b6) {
                    n4 = (illlIIIlIlllIllIlIIlllIlI8 - lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI) / n7;
                }
                int n8;
                if (n2 < n3 && n2 < n4) {
                    if (illlIIIlIlllIllIlIIlllIlI > illlIIIlIlllIllIlIIlllIlI4) {
                        n8 = 4;
                    }
                    else {
                        n8 = 5;
                    }
                    lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI2;
                    lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl += n6 * n2;
                    lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI += n7 * n2;
                }
                else if (n3 < n4) {
                    if (illlIIIlIlllIllIlIIlllIlI2 > illlIIIlIlllIllIlIIlllIlI5) {
                        n8 = 0;
                    }
                    else {
                        n8 = 1;
                    }
                    lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI += n5 * n3;
                    lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                    lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI += n7 * n3;
                }
                else {
                    if (illlIIIlIlllIllIlIIlllIlI3 > illlIIIlIlllIllIlIIlllIlI6) {
                        n8 = 2;
                    }
                    else {
                        n8 = 3;
                    }
                    lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI += n5 * n4;
                    lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl += n6 * n4;
                    lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI8;
                }
                final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI3;
                final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII3 = liiiIlIIllIIlIIlIIIlIIllI3 = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI, lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl, lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI);
                final double liiiIlIIllIIlIIlIIIlIIllI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI);
                liiiIlIIllIIlIIlIIIlIIllI3.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI4;
                illlIIIlIlllIllIlIIlllIlI4 = (int)liiiIlIIllIIlIIlIIIlIIllI4;
                if (n8 == 5) {
                    --illlIIIlIlllIllIlIIlllIlI4;
                    final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII4 = lIllIIIIlllllIIlIllIIIIII3;
                    ++lIllIIIIlllllIIlIllIIIIII4.lIIIIlIIllIIlIIlIIIlIIllI;
                }
                final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII5 = lIllIIIIlllllIIlIllIIIIII3;
                final double liiiiiiiiIlIllIIllIlIIlIl2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl);
                lIllIIIIlllllIIlIllIIIIII5.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl2;
                illlIIIlIlllIllIlIIlllIlI5 = (int)liiiiiiiiIlIllIIllIlIIlIl2;
                if (n8 == 1) {
                    --illlIIIlIlllIllIlIIlllIlI5;
                    final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII6 = lIllIIIIlllllIIlIllIIIIII3;
                    ++lIllIIIIlllllIIlIllIIIIII6.lIIIIIIIIIlIllIIllIlIIlIl;
                }
                final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII7 = lIllIIIIlllllIIlIllIIIIII3;
                final double illlIIIlIlllIllIlIIlllIlI9 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlllllIIlIllIIIIII.IlllIIIlIlllIllIlIIlllIlI);
                lIllIIIIlllllIIlIllIIIIII7.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI9;
                illlIIIlIlllIllIlIIlllIlI6 = (int)illlIIIlIlllIllIlIIlllIlI9;
                if (n8 == 3) {
                    --illlIIIlIlllIllIlIIlllIlI6;
                    final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII8 = lIllIIIIlllllIIlIllIIIIII3;
                    ++lIllIIIIlllllIIlIllIIIIII8.IlllIIIlIlllIllIlIIlllIlI;
                }
                final IIlllllllIlllIIllllIIlIll block2 = this.getBlock(illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6);
                final int illlIIIlIlllIllIlIIlllIlI10 = this.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6);
                if (b2 && block2.IlllIIIlIlllIllIlIIlllIlI(this, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6) == null) {
                    continue;
                }
                if (block2.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI10, b)) {
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI5 = block2.lIIIIlIIllIIlIIlIIIlIIllI(this, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6, lIllIIIIlllllIIlIllIIIIII, lIllIIIIlllllIIlIllIIIIII2);
                    if (liiiIlIIllIIlIIlIIIlIIllI5 != null) {
                        return liiiIlIIllIIlIIlIIIlIIllI5;
                    }
                    continue;
                }
                else {
                    movingObjectPosition = new MovingObjectPosition(illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI6, n8, lIllIIIIlllllIIlIllIIIIII, false);
                }
            }
            return b3 ? movingObjectPosition : null;
        }
        return null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final String s, final float n, final float n2) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(s, entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIIIIlllIIllIIlllIIlI - entity.lIlIllIlIlIIIllllIlIllIll, entity.IllIlIlIllllIlIIllllIIlll, n, n2);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final String s, final float n, final float n2) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, s, lIllIIIIlIIlIllIIIlIlIlll.IIIlIIlIlIIIlllIIlIllllll, lIllIIIIlIIlIllIIIlIlIlll.IllIlIIIIlllIIllIIlllIIlI - lIllIIIIlIIlIllIIIlIlIlll.lIlIllIlIlIIIllllIlIllIll, lIllIIIIlIIlIllIIIlIlIlll.IllIlIlIllllIlIIllllIIlll, n, n2);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final String s, final float n4, final float n5) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2, n3, n4, n5);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final String s, final float n4, final float n5, final boolean b) {
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2, final int n3) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2, n3);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(s, n, n2, n3, n4, n5, n6);
        }
    }
    
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final Entity entity) {
        this.IIIllIllIlIlllllllIlIlIII.add(entity);
        return true;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll / 16);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll / 16);
        boolean liIlIIllIIIIIlIllIIIIllII = entity.lIIlIIllIIIIIlIllIIIIllII;
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            liIlIIllIIIIIlIllIIIIllII = true;
        }
        if (!liIlIIllIIIIIlIllIIIIllII && !this.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2)) {
            return false;
        }
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            this.IlIlIIIlllIIIlIlllIlIllIl.add(entity);
            this.IllIlIIIIlllIIllIIlllIIlI();
        }
        this.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2).lIIIIlIIllIIlIIlIIIlIIllI(entity);
        this.IlllIIIlIlllIllIlIIlllIlI.add(entity);
        this.IlllIIIlIlllIllIlIIlllIlI(entity);
        return true;
    }
    
    protected void IlllIIIlIlllIllIlIIlllIlI(final Entity entity) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(entity);
        }
    }
    
    protected void IIIIllIlIIIllIlllIlllllIl(final Entity entity) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl(entity);
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity) {
        if (entity.IllIllIIIlIIlllIIIllIllII != null) {
            entity.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI((Entity)null);
        }
        if (entity.IlIIlIIIIlIIIIllllIIlIllI != null) {
            entity.lIIIIlIIllIIlIIlIIIlIIllI((Entity)null);
        }
        entity.IlIllllIIIlIllllIIIIIllII();
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            this.IlIlIIIlllIIIlIlllIlIllIl.remove(entity);
            this.IllIlIIIIlllIIllIIlllIIlI();
            this.IIIIllIlIIIllIlllIlllllIl(entity);
        }
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final Entity entity) {
        entity.IlIllllIIIlIllllIIIIIllII();
        if (entity instanceof lIllIIIIlIIlIllIIIlIlIlll) {
            this.IlIlIIIlllIIIlIlllIlIllIl.remove(entity);
            this.IllIlIIIIlllIIllIIlllIIlI();
        }
        final int llIIIlIlIIlIlIIlIllIllIll = entity.llIIIlIlIIlIlIIlIllIllIll;
        final int iiIlllllIIlIlIIIllllllIII = entity.IIIlllllIIlIlIIIllllllIII;
        if (entity.lIIIIIIlIIllllllIIIlIlIIl && this.IlllIIIlIlllIllIlIIlllIlI(llIIIlIlIIlIlIIlIllIllIll, iiIlllllIIlIlIIIllllllIII)) {
            this.IIIIllIIllIIIIllIllIIIlIl(llIIIlIlIIlIlIIlIllIllIll, iiIlllllIIlIlIIIllllllIII).lIIIIIIIIIlIllIIllIlIIlIl(entity);
        }
        this.IlllIIIlIlllIllIlIIlllIlI.remove(entity);
        this.IIIIllIlIIIllIlllIlllllIl(entity);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llllIlllIlIIlIllllIIlllIl llllIlllIlIIlIllllIIlllIl) {
        this.IIIIIIlIlIlIllllllIlllIlI.add(llllIlllIlIIlIllllIIlllIl);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final llllIlllIlIIlIllllIIlllIl llllIlllIlIIlIllllIIlllIl) {
        this.IIIIIIlIlIlIllllllIlllIlI.remove(llllIlllIlIIlIllllIIlllIl);
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        this.lIIIIlllIIlIlllllIlIllIII.clear();
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI5; j < illlIIIlIlllIllIlIIlllIlI6; ++j) {
                if (this.IIIIllIIllIIIIllIllIIIlIl(i, 64, j)) {
                    for (int k = illlIIIlIlllIllIlIIlllIlI3 - 1; k < illlIIIlIlllIllIlIIlllIlI4; ++k) {
                        IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll;
                        if (i >= -30000000 && i < 30000000 && j >= -30000000 && j < 30000000) {
                            illlllllIlllIIllllIIlIll = this.getBlock(i, k, j);
                        }
                        else {
                            illlllllIlllIIllllIIlIll = IllllllIllIIlllIllIIlIIll.lIIIIIIIIIlIllIIllIlIIlIl;
                        }
                        illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this, i, k, j, ilIllIIlIlIllIlIllllllllI, this.lIIIIlllIIlIlllllIlIllIII, entity);
                    }
                }
            }
        }
        final double n = 0.125 * 2.0;
        final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(entity, ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl(n, n, n));
        for (int l = 0; l < liiiiiiiiIlIllIIllIlIIlIl.size(); ++l) {
            final IlIllIIlIlIllIlIllllllllI illlIllIlIIIIlIIlIIllIIIl = liiiiiiiiIlIllIIllIlIIlIl.get(l).IlllIllIlIIIIlIIlIIllIIIl();
            if (illlIllIlIIIIlIIlIIllIIIl != null && illlIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl(ilIllIIlIlIllIlIllllllllI)) {
                this.lIIIIlllIIlIlllllIlIllIII.add(illlIllIlIIIIlIIlIIllIIIl);
            }
            final IlIllIIlIlIllIlIllllllllI iiIllIllIlIlllllllIlIlIII = entity.IIIllIllIlIlllllllIlIlIII(liiiiiiiiIlIllIIllIlIIlIl.get(l));
            if (iiIllIllIlIlllllllIlIlIII != null && iiIllIllIlIlllllllIlIlIII.lIIIIIIIIIlIllIIllIlIIlIl(ilIllIIlIlIllIlIllllllllI)) {
                this.lIIIIlllIIlIlllllIlIllIII.add(iiIllIllIlIlllllllIlIlIII);
            }
        }
        return this.lIIIIlllIIlIlllllIlIllIII;
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        this.lIIIIlllIIlIlllllIlIllIII.clear();
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI5; j < illlIIIlIlllIllIlIIlllIlI6; ++j) {
                if (this.IIIIllIIllIIIIllIllIIIlIl(i, 64, j)) {
                    for (int k = illlIIIlIlllIllIlIIlllIlI3 - 1; k < illlIIIlIlllIllIlIIlllIlI4; ++k) {
                        IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll;
                        if (i >= -30000000 && i < 30000000 && j >= -30000000 && j < 30000000) {
                            illlllllIlllIIllllIIlIll = this.getBlock(i, k, j);
                        }
                        else {
                            illlllllIlllIIllllIIlIll = IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII;
                        }
                        illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this, i, k, j, ilIllIIlIlIllIlIllllllllI, this.lIIIIlllIIlIlllllIlIllIII, null);
                    }
                }
            }
        }
        return this.lIIIIlllIIlIlllllIlIllIII;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        float n2 = 1.0f - (MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) * (6.7115846f * 0.4680851f) * 2.0f) * 2.0f + 1.7619047f * 0.2837838f);
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        return (int)((1.0f - (float)((float)((1.0f - n2) * (1.0 - this.IlllIllIlIIIIlIIlIIllIIIl(n) * 5 / (double)16)) * (1.0 - this.IllIIIIIIIlIlIllllIIllIII(n) * 5 / (double)16))) * 11);
    }
    
    public float lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        float n2 = 1.0f - (MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) * (2.3407946f * 1.3421053f) * 2.0f) * 2.0f + 0.011267606f * 17.75f);
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        return (float)((float)((1.0f - n2) * (1.0 - this.IlllIllIlIIIIlIIlIIllIIIl(n) * 5 / (double)16)) * (1.0 - this.IllIIIIIIIlIlIllllIIllIII(n) * 5 / (double)16)) * (1.0f * 0.8f) + 1.2941177f * 0.15454546f;
    }
    
    public lIllIIIIlllllIIlIllIIIIII lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final float n) {
        float n2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) * (0.20238096f * 15.523164f) * 2.0f) * 2.0f + 0.36842108f * 1.3571428f;
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIIIIlllIIllIIlllIIlI);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll);
        final IIlIIlIIllIIllIlIIIIIIIlI a_ = this.a_(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI3);
        final int liiiIlIIllIIlIIlIIIlIIllI = a_.lIIIIlIIllIIlIIlIIIlIIllI(a_.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI3));
        final float n3 = (liiiIlIIllIIlIIlIIIlIIllI >> 16 & 0xFF) / (float)255;
        final float n4 = (liiiIlIIllIIlIIlIIIlIIllI >> 8 & 0xFF) / (float)255;
        final float n5 = (liiiIlIIllIIlIIlIIIlIIllI & 0xFF) / (float)255;
        float n6 = n3 * n2;
        float n7 = n4 * n2;
        float n8 = n5 * n2;
        final float illlIllIlIIIIlIIlIIllIIIl = this.IlllIllIlIIIIlIIlIIllIIIl(n);
        if (illlIllIlIIIIlIIlIIllIIIl > 0.0f) {
            final float n9 = (n6 * (0.06666667f * 4.5f) + n7 * (9.538333f * 0.06185567f) + n8 * (0.53846157f * 0.2042857f)) * (0.083333336f * 7.2000003f);
            final float n10 = 1.0f - illlIllIlIIIIlIIlIIllIIIl * (0.44178084f * 1.6976744f);
            n6 = n6 * n10 + n9 * (1.0f - n10);
            n7 = n7 * n10 + n9 * (1.0f - n10);
            n8 = n8 * n10 + n9 * (1.0f - n10);
        }
        final float illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII(n);
        if (illIIIIIIIlIlIllllIIllIII > 0.0f) {
            final float n11 = (n6 * (0.8333333f * 0.36f) + n7 * (5.117647f * 0.11528735f) + n8 * (6.0f * 0.018333333f)) * (0.05357143f * 3.7333333f);
            final float n12 = 1.0f - illIIIIIIIlIlIllllIIllIII * (5.3f * 0.14150943f);
            n6 = n6 * n12 + n11 * (1.0f - n12);
            n7 = n7 * n12 + n11 * (1.0f - n12);
            n8 = n8 * n12 + n11 * (1.0f - n12);
        }
        if (this.llIlIIIlIIIIlIlllIlIIIIll > 0) {
            float n13 = this.llIlIIIlIIIIlIlllIlIIIIll - n;
            if (n13 > 1.0f) {
                n13 = 1.0f;
            }
            final float n14 = n13 * (0.42804876f * 1.051282f);
            n6 = n6 * (1.0f - n14) + 2.1842105f * 0.36626506f * n14;
            n7 = n7 * (1.0f - n14) + 0.25882354f * 3.090909f * n14;
            n8 = n8 * (1.0f - n14) + 1.0f * n14;
        }
        return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n6, n7, n8);
    }
    
    public float IlllIIIlIlllIllIlIIlllIlI(final float n) {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIllIIIIIlIllIIIIllII.IIIllIllIlIlllllllIlIlIII(), n);
    }
    
    public int llIIlllIIIIlllIllIlIlllIl() {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIllIIIIIlIllIIIIllII.IIIllIllIlIlllllllIlIlIII());
    }
    
    public float lIIlIlIllIIlIIIlIIIlllIII() {
        return IlIIlIllllllIlIIllIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI[this.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIIllIIIIIlIllIIIIllII.IIIllIllIlIlllllllIlIlIII())];
    }
    
    public float IIIIllIlIIIllIlllIlllllIl(final float n) {
        return this.IlllIIIlIlllIllIlIIlllIlI(n) * (4.3125f * 0.7284853f) * 2.0f;
    }
    
    public lIllIIIIlllllIIlIllIIIIII IIIIllIIllIIIIllIllIIIlIl(final float n) {
        float n2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) * (0.36249146f * 8.666667f) * 2.0f) * 2.0f + 0.13207547f * 3.7857141f;
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        float n3 = (this.IlIlIIIlllllIIIlIlIlIllII >> 16 & 0xFFL) / (float)255;
        float n4 = (this.IlIlIIIlllllIIIlIlIlIllII >> 8 & 0xFFL) / (float)255;
        float n5 = (this.IlIlIIIlllllIIIlIlIlIllII & 0xFFL) / (float)255;
        final float illlIllIlIIIIlIIlIIllIIIl = this.IlllIllIlIIIIlIIlIIllIIIl(n);
        if (illlIllIlIIIIlIIlIIllIIIl > 0.0f) {
            final float n6 = (n3 * (0.59318185f * 0.50574714f) + n4 * (0.10989011f * 5.3689995f) + n5 * (0.49315068f * 0.22305556f)) * (0.077142864f * 7.7777777f);
            final float n7 = 1.0f - illlIllIlIIIIlIIlIIllIIIl * (1.4858974f * 0.6393443f);
            n3 = n3 * n7 + n6 * (1.0f - n7);
            n4 = n4 * n7 + n6 * (1.0f - n7);
            n5 = n5 * n7 + n6 * (1.0f - n7);
        }
        float n8 = n3 * (n2 * (0.68225807f * 1.3191489f) + 0.025f * 4.0f);
        float n9 = n4 * (n2 * (0.7276595f * 1.2368422f) + 0.071428575f * 1.4f);
        float n10 = n5 * (n2 * (0.87428576f * 0.9722222f) + 0.61904764f * 0.2423077f);
        final float illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII(n);
        if (illIIIIIIIlIlIllllIIllIII > 0.0f) {
            final float n11 = (n8 * (0.18f * 1.6666666f) + n9 * (0.5421687f * 1.0882221f) + n10 * (0.64166665f * 0.17142858f)) * (0.08247423f * 2.425f);
            final float n12 = 1.0f - illIIIIIIIlIlIllllIIllIII * (2.074074f * 0.4580357f);
            n8 = n8 * n12 + n11 * (1.0f - n12);
            n9 = n9 * n12 + n11 * (1.0f - n12);
            n10 = n10 * n12 + n11 * (1.0f - n12);
        }
        return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n8, n9, n10);
    }
    
    public lIllIIIIlllllIIlIllIIIIII IlIlIIIlllIIIlIlllIlIllIl(final float n) {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n), n);
    }
    
    public int IllIIIIIIIlIlIllllIIllIII(final int n, final int n2) {
        return this.IIIIllIlIIIllIlllIlllllIl(n, n2).IlllIIIlIlllIllIlIIlllIlI(n & 0xF, n2 & 0xF);
    }
    
    public int lIIIIllIIlIlIllIIIlIllIlI(int n, int n2) {
        final lIlllllIIllIlIlIlllIIIIII iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl(n, n2);
        int i = iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI() + 15;
        n &= 0xF;
        n2 &= 0xF;
        while (i > 0) {
            final IIlllllllIlllIIllllIIlIll liiiiiiiiIlIllIIllIlIIlIl = iiiIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(n, i, n2);
            if (liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl().IIIIllIlIIIllIlllIlllllIl() && liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl() != Material.IlllIllIlIIIIlIIlIIllIIIl) {
                return i + 1;
            }
            --i;
        }
        return -1;
    }
    
    public float IIIllIllIlIlllllllIlIlIII(final float n) {
        float n2 = 1.0f - (MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(n) * (7.6183624f * 0.41237113f) * 2.0f) * 2.0f + 3.5f * 0.071428575f);
        if (n2 < 0.0f) {
            n2 = 0.0f;
        }
        if (n2 > 1.0f) {
            n2 = 1.0f;
        }
        return n2 * n2 * (1.390625f * 0.35955057f);
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4, final int n5) {
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4, final int n5) {
    }
    
    public void IIIlllIIIllIllIlIIIIIIlII() {
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("entities");
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("global");
        for (int i = 0; i < this.IIIllIllIlIlllllllIlIlIII.size(); ++i) {
            final Entity entity = this.IIIllIllIlIlllllllIlIlIII.get(i);
            try {
                final Entity entity2 = entity;
                ++entity2.IIIlIllIlllIlIllIllllllll;
                entity.x_();
            }
            catch (Throwable t) {
                final CrashReport crashReport = CrashReport.makeCrashReport(t, "Ticking entity");
                final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Entity being ticked");
                if (entity == null) {
                    category.lIIIIlIIllIIlIIlIIIlIIllI("Entity", "~~NULL~~");
                }
                else {
                    entity.lIIIIlIIllIIlIIlIIIlIIllI(category);
                }
                throw new ReportedException(crashReport);
            }
            if (entity.IIllIlIllIlIllIIlIllIlIII) {
                this.IIIllIllIlIlllllllIlIlIII.remove(i--);
            }
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("remove");
        this.IlllIIIlIlllIllIlIIlllIlI.removeAll(this.IIIIllIlIIIllIlllIlllllIl);
        for (int j = 0; j < this.IIIIllIlIIIllIlllIlllllIl.size(); ++j) {
            final Entity entity3 = this.IIIIllIlIIIllIlllIlllllIl.get(j);
            final int llIIIlIlIIlIlIIlIllIllIll = entity3.llIIIlIlIIlIlIIlIllIllIll;
            final int iiIlllllIIlIlIIIllllllIII = entity3.IIIlllllIIlIlIIIllllllIII;
            if (entity3.lIIIIIIlIIllllllIIIlIlIIl && this.IlllIIIlIlllIllIlIIlllIlI(llIIIlIlIIlIlIIlIllIllIll, iiIlllllIIlIlIIIllllllIII)) {
                this.IIIIllIIllIIIIllIllIIIlIl(llIIIlIlIIlIlIIlIllIllIll, iiIlllllIIlIlIIIllllllIII).lIIIIIIIIIlIllIIllIlIIlIl(entity3);
            }
        }
        for (int k = 0; k < this.IIIIllIlIIIllIlllIlllllIl.size(); ++k) {
            this.IIIIllIlIIIllIlllIlllllIl((Entity)this.IIIIllIlIIIllIlllIlllllIl.get(k));
        }
        this.IIIIllIlIIIllIlllIlllllIl.clear();
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("regular");
        for (int l = 0; l < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++l) {
            final Entity entity4 = this.IlllIIIlIlllIllIlIIlllIlI.get(l);
            if (entity4.IlIIlIIIIlIIIIllllIIlIllI != null) {
                if (!entity4.IlIIlIIIIlIIIIllllIIlIllI.IIllIlIllIlIllIIlIllIlIII && entity4.IlIIlIIIIlIIIIllllIIlIllI.IllIllIIIlIIlllIIIllIllII == entity4) {
                    continue;
                }
                entity4.IlIIlIIIIlIIIIllllIIlIllI.IllIllIIIlIIlllIIIllIllII = null;
                entity4.IlIIlIIIIlIIIIllllIIlIllI = null;
            }
            this.IIIlIIlIlIIIlllIIlIllllll.startSection("tick");
            if (!entity4.IIllIlIllIlIllIIlIllIlIII) {
                try {
                    this.IIIIllIIllIIIIllIllIIIlIl(entity4);
                }
                catch (Throwable t2) {
                    final CrashReport crashReport2 = CrashReport.makeCrashReport(t2, "Ticking entity");
                    entity4.lIIIIlIIllIIlIIlIIIlIIllI(crashReport2.makeCategory("Entity being ticked"));
                    throw new ReportedException(crashReport2);
                }
            }
            this.IIIlIIlIlIIIlllIIlIllllll.endSection();
            this.IIIlIIlIlIIIlllIIlIllllll.startSection("remove");
            if (entity4.IIllIlIllIlIllIIlIllIlIII) {
                final int llIIIlIlIIlIlIIlIllIllIll2 = entity4.llIIIlIlIIlIlIIlIllIllIll;
                final int iiIlllllIIlIlIIIllllllIII2 = entity4.IIIlllllIIlIlIIIllllllIII;
                if (entity4.lIIIIIIlIIllllllIIIlIlIIl && this.IlllIIIlIlllIllIlIIlllIlI(llIIIlIlIIlIlIIlIllIllIll2, iiIlllllIIlIlIIIllllllIII2)) {
                    this.IIIIllIIllIIIIllIllIIIlIl(llIIIlIlIIlIlIIlIllIllIll2, iiIlllllIIlIlIIIllllllIII2).lIIIIIIIIIlIllIIllIlIIlIl(entity4);
                }
                this.IlllIIIlIlllIllIlIIlllIlI.remove(l--);
                this.IIIIllIlIIIllIlllIlllllIl(entity4);
            }
            this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("blockEntities");
        this.lIIIlllIlIlllIIIIIIIIIlII = true;
        final Iterator iterator = this.IIIIllIIllIIIIllIllIIIlIl.iterator();
        while (iterator.hasNext()) {
            final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl = iterator.next();
            if (!illIllIlIIlllIllIIllIlIIl.lIIIIllIIlIlIllIIIlIllIlI() && illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl() && this.IIIIllIIllIIIIllIllIIIlIl(illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl, illIllIlIIlllIllIIllIlIIl.IlllIIIlIlllIllIlIIlllIlI, illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl)) {
                try {
                    illIllIlIIlllIllIIllIlIIl.updateScreen();
                }
                catch (Throwable t3) {
                    final CrashReport crashReport3 = CrashReport.makeCrashReport(t3, "Ticking block entity");
                    illIllIlIIlllIllIIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(crashReport3.makeCategory("Block entity being ticked"));
                    throw new ReportedException(crashReport3);
                }
            }
            if (illIllIlIIlllIllIIllIlIIl.lIIIIllIIlIlIllIIIlIllIlI()) {
                iterator.remove();
                if (!this.IlllIIIlIlllIllIlIIlllIlI(illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl >> 4, illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl >> 4)) {
                    continue;
                }
                final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl >> 4, illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl >> 4);
                if (iiiIllIIllIIIIllIllIIIlIl == null) {
                    continue;
                }
                iiiIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl(illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl & 0xF, illIllIlIIlllIllIIllIlIIl.IlllIIIlIlllIllIlIIlllIlI, illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl & 0xF);
            }
        }
        this.lIIIlllIlIlllIIIIIIIIIlII = false;
        if (!this.IllIIlllIllIlIllIlIIIIIII.isEmpty()) {
            this.IIIIllIIllIIIIllIllIIIlIl.removeAll(this.IllIIlllIllIlIllIlIIIIIII);
            this.IllIIlllIllIlIllIlIIIIIII.clear();
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("pendingBlockEntities");
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.isEmpty()) {
            for (int n = 0; n < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++n) {
                final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl2 = this.lIIIIlIIllIIlIIlIIIlIIllI.get(n);
                if (!illIllIlIIlllIllIIllIlIIl2.lIIIIllIIlIlIllIIIlIllIlI()) {
                    if (!this.IIIIllIIllIIIIllIllIIIlIl.contains(illIllIlIIlllIllIIllIlIIl2)) {
                        this.IIIIllIIllIIIIllIllIIIlIl.add(illIllIlIIlllIllIIllIlIIl2);
                    }
                    if (this.IlllIIIlIlllIllIlIIlllIlI(illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl >> 4, illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl >> 4)) {
                        final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl2 = this.IIIIllIIllIIIIllIllIIIlIl(illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl >> 4, illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl >> 4);
                        if (iiiIllIIllIIIIllIllIIIlIl2 != null) {
                            iiiIllIIllIIIIllIllIIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI(illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl & 0xF, illIllIlIIlllIllIIllIlIIl2.IlllIIIlIlllIllIlIIlllIlI, illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl & 0xF, illIllIlIIlllIllIIllIlIIl2);
                        }
                    }
                    this.IIIllIllIlIlllllllIlIlIII(illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl, illIllIlIIlllIllIIllIlIIl2.IlllIIIlIlllIllIlIIlllIlI, illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl);
                }
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Collection collection) {
        if (this.lIIIlllIlIlllIIIIIIIIIlII) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.addAll(collection);
        }
        else {
            this.IIIIllIIllIIIIllIllIIIlIl.addAll(collection);
        }
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final Entity entity) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(entity, true);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final boolean b) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll);
        final int n = 32;
        if (!b || this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI - n, 0, illlIIIlIlllIllIlIIlllIlI2 - n, illlIIIlIlllIllIlIIlllIlI + n, 0, illlIIIlIlllIllIlIIlllIlI2 + n)) {
            entity.lIlIlIIIlIIllllllllIIlllI = entity.IIIlIIlIlIIIlllIIlIllllll;
            entity.IlIlllIllIlIllIlllIlllIll = entity.IllIlIIIIlllIIllIIlllIIlI;
            entity.llIIIllIIllllIlIlIlIlIIll = entity.IllIlIlIllllIlIIllllIIlll;
            entity.IlIlIIIlllllIIIlIlIlIllII = entity.IllllIllllIlIIIlIIIllllll;
            entity.IIlIIllIIIllllIIlllIllIIl = entity.IllIIlllIllIlIllIlIIIIIII;
            if (b && entity.lIIIIIIlIIllllllIIIlIlIIl) {
                ++entity.IIIlIllIlllIlIllIllllllll;
                if (entity.IlIIlIIIIlIIIIllllIIlIllI != null) {
                    entity.IllllllllIlIIIIIIIIllIIII();
                }
                else {
                    entity.x_();
                }
            }
            this.IIIlIIlIlIIIlllIIlIllllll.startSection("chunkCheck");
            if (Double.isNaN(entity.IIIlIIlIlIIIlllIIlIllllll) || Double.isInfinite(entity.IIIlIIlIlIIIlllIIlIllllll)) {
                entity.IIIlIIlIlIIIlllIIlIllllll = entity.lIlIlIIIlIIllllllllIIlllI;
            }
            if (Double.isNaN(entity.IllIlIIIIlllIIllIIlllIIlI) || Double.isInfinite(entity.IllIlIIIIlllIIllIIlllIIlI)) {
                entity.IllIlIIIIlllIIllIIlllIIlI = entity.IlIlllIllIlIllIlllIlllIll;
            }
            if (Double.isNaN(entity.IllIlIlIllllIlIIllllIIlll) || Double.isInfinite(entity.IllIlIlIllllIlIIllllIIlll)) {
                entity.IllIlIlIllllIlIIllllIIlll = entity.llIIIllIIllllIlIlIlIlIIll;
            }
            if (Double.isNaN(entity.IllIIlllIllIlIllIlIIIIIII) || Double.isInfinite(entity.IllIIlllIllIlIllIlIIIIIII)) {
                entity.IllIIlllIllIlIllIlIIIIIII = entity.IIlIIllIIIllllIIlllIllIIl;
            }
            if (Double.isNaN(entity.IllllIllllIlIIIlIIIllllll) || Double.isInfinite(entity.IllllIllllIlIIIlIIIllllll)) {
                entity.IllllIllllIlIIIlIIIllllll = entity.IlIlIIIlllllIIIlIlIlIllII;
            }
            final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll / 16);
            final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIIIIlllIIllIIlllIIlI / 16);
            final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll / 16);
            if (!entity.lIIIIIIlIIllllllIIIlIlIIl || entity.llIIIlIlIIlIlIIlIllIllIll != illlIIIlIlllIllIlIIlllIlI3 || entity.IlIIlllIlIIIlIIIlIlIlIlIl != illlIIIlIlllIllIlIIlllIlI4 || entity.IIIlllllIIlIlIIIllllllIII != illlIIIlIlllIllIlIIlllIlI5) {
                if (entity.lIIIIIIlIIllllllIIIlIlIIl && this.IlllIIIlIlllIllIlIIlllIlI(entity.llIIIlIlIIlIlIIlIllIllIll, entity.IIIlllllIIlIlIIIllllllIII)) {
                    this.IIIIllIIllIIIIllIllIIIlIl(entity.llIIIlIlIIlIlIIlIllIllIll, entity.IIIlllllIIlIlIIIllllllIII).lIIIIlIIllIIlIIlIIIlIIllI(entity, entity.IlIIlllIlIIIlIIIlIlIlIlIl);
                }
                if (this.IlllIIIlIlllIllIlIIlllIlI(illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI5)) {
                    entity.lIIIIIIlIIllllllIIIlIlIIl = true;
                    this.IIIIllIIllIIIIllIllIIIlIl(illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI5).lIIIIlIIllIIlIIlIIIlIIllI(entity);
                }
                else {
                    entity.lIIIIIIlIIllllllIIIlIlIIl = false;
                }
            }
            this.IIIlIIlIlIIIlllIIlIllllll.endSection();
            if (b && entity.lIIIIIIlIIllllllIIIlIlIIl && entity.IllIllIIIlIIlllIIIllIllII != null) {
                if (!entity.IllIllIIIlIIlllIIIllIllII.IIllIlIllIlIllIIlIllIlIII && entity.IllIllIIIlIIlllIIIllIllII.IlIIlIIIIlIIIIllllIIlIllI == entity) {
                    this.IIIIllIIllIIIIllIllIIIlIl(entity.IllIllIIIlIIlllIIIllIllII);
                }
                else {
                    entity.IllIllIIIlIIlllIIIllIllII.IlIIlIIIIlIIIIllllIIlIllI = null;
                    entity.IllIllIIIlIIlllIIIllIllII = null;
                }
            }
        }
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(ilIllIIlIlIllIlIllllllllI, (Entity)null);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final Entity entity) {
        final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(null, ilIllIIlIlIllIlIllllllllI);
        for (int i = 0; i < liiiiiiiiIlIllIIllIlIIlIl.size(); ++i) {
            final Entity entity2 = liiiiiiiiIlIllIIllIlIIlIl.get(i);
            if (!entity2.IIllIlIllIlIllIIlIllIlIII && entity2.IIIIIIlIlIlIllllllIlllIlI && entity2 != entity) {
                return false;
            }
        }
        return true;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        if (ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI;
        }
        if (ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI3;
        }
        if (ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI5;
        }
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    if (this.getBlock(i, j, k).IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        if (ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI;
        }
        if (ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI3;
        }
        if (ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI < 0.0) {
            --illlIIIlIlllIllIlIIlllIlI5;
        }
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    if (this.getBlock(i, j, k).IlIlIIIlllIIIlIlllIlIllIl().lIIIIlIIllIIlIIlIIIlIIllI()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        if (this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI6)) {
            for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
                for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                    for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                        final IIlllllllIlllIIllllIIlIll block = this.getBlock(i, j, k);
                        if (block == IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll || block == IllllllIllIIlllIllIIlIIll.IlIlllIIIIllIllllIllIIlIl || block == IllllllIllIIlllIllIIlIIll.llIIlllIIIIlllIllIlIlllIl) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final Material material, final Entity entity) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        if (!this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI, illlIIIlIlllIllIlIIlllIlI3, illlIIIlIlllIllIlIIlllIlI5, illlIIIlIlllIllIlIIlllIlI2, illlIIIlIlllIllIlIIlllIlI4, illlIIIlIlllIllIlIIlllIlI6)) {
            return false;
        }
        boolean b = false;
        final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 0.0, 0.0);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    final IIlllllllIlllIIllllIIlIll block = this.getBlock(i, j, k);
                    if (block.IlIlIIIlllIIIlIlllIlIllIl() == material && illlIIIlIlllIllIlIIlllIlI4 >= (double)(j + 1 - lllIlIIIIIllllIIIlIIlIIIl.IllIIIIIIIlIlIllllIIllIII(this.IlllIIIlIlllIllIlIIlllIlI(i, j, k)))) {
                        b = true;
                        block.lIIIIlIIllIIlIIlIIIlIIllI(this, i, j, k, entity, liiiIlIIllIIlIIlIIIlIIllI);
                    }
                }
            }
        }
        if (liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl() > 0.0 && entity.IllIlIIIIlIlllIlllllllIIl()) {
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI();
            final double n = 1.399999976158142 * 0.010000000170298989;
            entity.IllIIlIIlllllIllIIIlllIII += liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI * n;
            entity.lIlIlIllIIIIIIIIllllIIllI += liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl * n;
            entity.IlllIIlllIIIIllIIllllIlIl += liiiIlIIllIIlIIlIIIlIIllI2.IlllIIIlIlllIllIlIIlllIlI * n;
        }
        return b;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final Material material) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    if (this.getBlock(i, j, k).IlIlIIIlllIIIlIlllIlIllIl() == material) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final Material material) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 1.0);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i < illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j < illlIIIlIlllIllIlIIlllIlI4; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI5; k < illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    if (this.getBlock(i, j, k).IlIlIIIlllIIIlIlllIlIllIl() == material) {
                        final int illlIIIlIlllIllIlIIlllIlI7 = this.IlllIIIlIlllIllIlIIlllIlI(i, j, k);
                        double n = j + 1;
                        if (illlIIIlIlllIllIlIIlllIlI7 < 8) {
                            n = j + 1 - illlIIIlIlllIllIlIIlllIlI7 / (double)8;
                        }
                        if (n >= ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public lIlIlIlllIlllIlIIlIllllll lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final boolean b) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(entity, n, n2, n3, n4, false, b);
    }
    
    public lIlIlIlllIlllIlIIlIllllll lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n, final double n2, final double n3, final float n4, final boolean liiiIlIIllIIlIIlIIIlIIllI, final boolean liiiiiiiiIlIllIIllIlIIlIl) {
        final lIlIlIlllIlllIlIIlIllllll lIlIlIlllIlllIlIIlIllllll = new lIlIlIlllIlllIlIIlIllllll(this, entity, n, n2, n3, n4);
        lIlIlIlllIlllIlIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        lIlIlIlllIlllIlIIlIllllll.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        lIlIlIlllIlllIlIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI();
        lIlIlIlllIlllIlIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(true);
        return lIlIlIlllIlllIlIIlIllllll;
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        final double n = 1.0 / ((ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl - ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI) * 2 + 1.0);
        final double n2 = 1.0 / ((ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl - ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl) * 2 + 1.0);
        final double n3 = 1.0 / ((ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl - ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI) * 2 + 1.0);
        if (n >= 0.0 && n2 >= 0.0 && n3 >= 0.0) {
            int n4 = 0;
            int n5 = 0;
            for (float n6 = 0.0f; n6 <= 1.0f; n6 += (float)n) {
                for (float n7 = 0.0f; n7 <= 1.0f; n7 += (float)n2) {
                    for (float n8 = 0.0f; n8 <= 1.0f; n8 += (float)n3) {
                        if (this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI + (ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl - ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI) * n6, ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl + (ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl - ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl) * n7, ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI + (ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl - ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI) * n8), lIllIIIIlllllIIlIllIIIIII) == null) {
                            ++n4;
                        }
                        ++n5;
                    }
                }
            }
            return n4 / (float)n5;
        }
        return 0.0f;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, int n, int n2, int n3, final int n4) {
        if (n4 == 0) {
            --n2;
        }
        if (n4 == 1) {
            ++n2;
        }
        if (n4 == 2) {
            --n3;
        }
        if (n4 == 3) {
            ++n3;
        }
        if (n4 == 4) {
            --n;
        }
        if (n4 == 5) {
            ++n;
        }
        if (this.getBlock(n, n2, n3) == IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, 1004, n, n2, n3, 0);
            this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            return true;
        }
        return false;
    }
    
    public String llIlIIIlIIIIlIlllIlIIIIll() {
        return "All: " + this.IlllIIIlIlllIllIlIIlllIlI.size();
    }
    
    public String IIIlIIllllIIllllllIlIIIll() {
        return this.IllIllIIIlIIlllIIIllIllII.IIIIllIlIIIllIlllIlllllIl();
    }
    
    @Override
    public IllIllIlIIlllIllIIllIlIIl lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        if (n2 >= 0 && n2 < 256) {
            IllIllIlIIlllIllIIllIlIIl iiiIllIIllIIIIllIllIIIlIl = null;
            if (this.lIIIlllIlIlllIIIIIIIIIlII) {
                for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                    final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
                    if (!illIllIlIIlllIllIIllIlIIl.lIIIIllIIlIlIllIIIlIllIlI() && illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl == n && illIllIlIIlllIllIIllIlIIl.IlllIIIlIlllIllIlIIlllIlI == n2 && illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl == n3) {
                        iiiIllIIllIIIIllIllIIIlIl = illIllIlIIlllIllIIllIlIIl;
                        break;
                    }
                }
            }
            if (iiiIllIIllIIIIllIllIIIlIl == null) {
                final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl2 = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
                if (iiiIllIIllIIIIllIllIIIlIl2 != null) {
                    iiiIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl2.IIIIllIIllIIIIllIllIIIlIl(n & 0xF, n2, n3 & 0xF);
                }
            }
            if (iiiIllIIllIIIIllIllIIIlIl == null) {
                for (int j = 0; j < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++j) {
                    final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl2 = this.lIIIIlIIllIIlIIlIIIlIIllI.get(j);
                    if (!illIllIlIIlllIllIIllIlIIl2.lIIIIllIIlIlIllIIIlIllIlI() && illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl == n && illIllIlIIlllIllIIllIlIIl2.IlllIIIlIlllIllIlIIlllIlI == n2 && illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl == n3) {
                        iiiIllIIllIIIIllIllIIIlIl = illIllIlIIlllIllIIllIlIIl2;
                        break;
                    }
                }
            }
            return iiiIllIIllIIIIllIllIIIlIl;
        }
        return null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl) {
        if (illIllIlIIlllIllIIllIlIIl != null && !illIllIlIIlllIllIIllIlIIl.lIIIIllIIlIlIllIIIlIllIlI()) {
            if (this.lIIIlllIlIlllIIIIIIIIIlII) {
                illIllIlIIlllIllIIllIlIIl.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
                illIllIlIIlllIllIIllIlIIl.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
                illIllIlIIlllIllIIllIlIIl.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
                final Iterator<IllIllIlIIlllIllIIllIlIIl> iterator = (Iterator<IllIllIlIIlllIllIIllIlIIl>)this.lIIIIlIIllIIlIIlIIIlIIllI.iterator();
                while (iterator.hasNext()) {
                    final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl2 = iterator.next();
                    if (illIllIlIIlllIllIIllIlIIl2.lIIIIIIIIIlIllIIllIlIIlIl == liiiiiiiiIlIllIIllIlIIlIl && illIllIlIIlllIllIIllIlIIl2.IlllIIIlIlllIllIlIIlllIlI == illlIIIlIlllIllIlIIlllIlI && illIllIlIIlllIllIIllIlIIl2.IIIIllIlIIIllIlllIlllllIl == iiiIllIlIIIllIlllIlllllIl) {
                        illIllIlIIlllIllIIllIlIIl2.IlllIllIlIIIIlIIlIIllIIIl();
                        iterator.remove();
                    }
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI.add(illIllIlIIlllIllIIllIlIIl);
            }
            else {
                this.IIIIllIIllIIIIllIllIIIlIl.add(illIllIlIIlllIllIIllIlIIl);
                final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(liiiiiiiiIlIllIIllIlIIlIl >> 4, iiiIllIlIIIllIlllIlllllIl >> 4);
                if (iiiIllIIllIIIIllIllIIIlIl != null) {
                    iiiIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl & 0xF, illlIIIlIlllIllIlIIlllIlI, iiiIllIlIIIllIlllIlllllIl & 0xF, illIllIlIIlllIllIIllIlIIl);
                }
            }
        }
    }
    
    public void lIIlIlIllIIlIIIlIIIlllIII(final int n, final int n2, final int n3) {
        final IllIllIlIIlllIllIIllIlIIl liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        if (liiiiiiiiIlIllIIllIlIIlIl != null && this.lIIIlllIlIlllIIIIIIIIIlII) {
            liiiiiiiiIlIllIIllIlIIlIl.IlllIllIlIIIIlIIlIIllIIIl();
            this.lIIIIlIIllIIlIIlIIIlIIllI.remove(liiiiiiiiIlIllIIllIlIIlIl);
        }
        else {
            if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.remove(liiiiiiiiIlIllIIllIlIIlIl);
                this.IIIIllIIllIIIIllIllIIIlIl.remove(liiiiiiiiIlIllIIllIlIIlIl);
            }
            final lIlllllIIllIlIlIlllIIIIII iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl(n >> 4, n3 >> 4);
            if (iiiIllIIllIIIIllIllIIIlIl != null) {
                iiiIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl(n & 0xF, n2, n3 & 0xF);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl) {
        this.IllIIlllIllIlIllIlIIIIIII.add(illIllIlIIlllIllIIllIlIIl);
    }
    
    public boolean IIIlllIIIllIllIlIIIIIIlII(final int n, final int n2, final int n3) {
        final IlIllIIlIlIllIlIllllllllI illlIIIlIlllIllIlIIlllIlI = this.getBlock(n, n2, n3).IlllIIIlIlllIllIlIIlllIlI(this, n, n2, n3);
        return illlIIIlIlllIllIlIIlllIlI != null && illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI() >= 1.0;
    }
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final IIlllllllIlllIIllllIIlIll block = liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3);
        final int illlIIIlIlllIllIlIIlllIlI = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        return (block.IlIlIIIlllIIIlIlllIlIllIl().IlllIllIlIIIIlIIlIIllIIIl() && block.IlllIllIlIIIIlIIlIIllIIIl()) || ((block instanceof lIIIIllIIIIIllIlllllIIIIl) ? ((illlIIIlIlllIllIlIIlllIlI & 0x4) == 0x4) : ((block instanceof lIlIIllIIIIIIIIllIIIIlIII) ? ((illlIIIlIlllIllIlIIlllIlI & 0x8) == 0x8) : (block instanceof lIllllllIlllIllIIlIIIlIIl || (block instanceof IllIlIllIIllllIllIIIIllll && (illlIIIlIlllIllIlIIlllIlI & 0x7) == 0x7))));
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final boolean b) {
        if (n < -30000000 || n3 < -30000000 || n >= 30000000 || n3 >= 30000000) {
            return b;
        }
        final lIlllllIIllIlIlIlllIIIIII iiiIllIlIIIllIlllIlllllIl = this.IllIllIIIlIIlllIIIllIllII.IIIIllIlIIIllIlllIlllllIl(n >> 4, n3 >> 4);
        if (iiiIllIlIIIllIlllIlllllIl != null && !iiiIllIlIIIllIlllIlllllIl.IllIIIIIIIlIlIllllIIllIII()) {
            final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
            return block.IlIlIIIlllIIIlIlllIlIllIl().IlllIllIlIIIIlIIlIIllIIIl() && block.IlllIllIlIIIIlIIlIIllIIIl();
        }
        return b;
    }
    
    public void lllIIIIIlIllIlIIIllllllII() {
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(1.0f);
        if (liiiIlIIllIIlIIlIIIlIIllI != this.IllIIIIIIIlIlIllllIIllIII) {
            this.IllIIIIIIIlIlIllllIIllIII = liiiIlIIllIIlIIlIIIlIIllI;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean lIlIlIllIIIIIIIIllllIIllI, final boolean illlIIlllIIIIllIIllllIlIl) {
        this.lIlIlIllIIIIIIIIllllIIllI = lIlIlIllIIIIIIIIllllIIllI;
        this.IlllIIlllIIIIllIIllllIlIl = illlIIlllIIIIllIIllllIlIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlIIllllIIllllllIlIIIll()) {
            this.llIIlllIIIIlllIllIlIlllIl = 1.0f;
            if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlllIIIllIllIlIIIIIIlII()) {
                this.IIIlllIIIllIllIlIIIIIIlII = 1.0f;
            }
        }
    }
    
    protected void IIIIllIIllIIIIllIllIIIlIl() {
        if (!this.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII && !this.IllIlIlIllllIlIIllllIIlll) {
            int llIlIIIlIIIIlIlllIlIIIIll = this.lIIlIIllIIIIIlIllIIIIllII.llIlIIIlIIIIlIlllIlIIIIll();
            if (llIlIIIlIIIIlIlllIlIIIIll <= 0) {
                if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlllIIIllIllIlIIIIIIlII()) {
                    this.lIIlIIllIIIIIlIllIIIIllII.IIIIllIIllIIIIllIllIIIlIl(this.lllIIIIIlIllIlIIIllllllII.nextInt(12000) + 3600);
                }
                else {
                    this.lIIlIIllIIIIIlIllIIIIllII.IIIIllIIllIIIIllIllIIIlIl(this.lllIIIIIlIllIlIIIllllllII.nextInt(168000) + 12000);
                }
            }
            else {
                --llIlIIIlIIIIlIlllIlIIIIll;
                this.lIIlIIllIIIIIlIllIIIIllII.IIIIllIIllIIIIllIllIIIlIl(llIlIIIlIIIIlIlllIlIIIIll);
                if (llIlIIIlIIIIlIlllIlIIIIll <= 0) {
                    this.lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(!this.lIIlIIllIIIIIlIllIIIIllII.IIIlllIIIllIllIlIIIIIIlII());
                }
            }
            this.lIIlIlIllIIlIIIlIIIlllIII = this.IIIlllIIIllIllIlIIIIIIlII;
            if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlllIIIllIllIlIIIIIIlII()) {
                this.IIIlllIIIllIllIlIIIIIIlII += (float)(0.0029411763880904593 * 3.4000000953674316);
            }
            else {
                this.IIIlllIIIllIllIlIIIIIIlII -= (float)(0.0032835821362905667 * 3.045454502105713);
            }
            this.IIIlllIIIllIllIlIIIIIIlII = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlllIIIllIllIlIIIIIIlII, 0.0f, 1.0f);
            int lllIIIIIlIllIlIIIllllllII = this.lIIlIIllIIIIIlIllIIIIllII.lllIIIIIlIllIlIIIllllllII();
            if (lllIIIIIlIllIlIIIllllllII <= 0) {
                if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlIIllllIIllllllIlIIIll()) {
                    this.lIIlIIllIIIIIlIllIIIIllII.IlIlIIIlllIIIlIlllIlIllIl(this.lllIIIIIlIllIlIIIllllllII.nextInt(12000) + 12000);
                }
                else {
                    this.lIIlIIllIIIIIlIllIIIIllII.IlIlIIIlllIIIlIlllIlIllIl(this.lllIIIIIlIllIlIIIllllllII.nextInt(168000) + 12000);
                }
            }
            else {
                --lllIIIIIlIllIlIIIllllllII;
                this.lIIlIIllIIIIIlIllIIIIllII.IlIlIIIlllIIIlIlllIlIllIl(lllIIIIIlIllIlIIIllllllII);
                if (lllIIIIIlIllIlIIIllllllII <= 0) {
                    this.lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl(!this.lIIlIIllIIIIIlIllIIIIllII.IIIlIIllllIIllllllIlIIIll());
                }
            }
            this.IlIlllIIIIllIllllIllIIlIl = this.llIIlllIIIIlllIllIlIlllIl;
            if (this.lIIlIIllIIIIIlIllIIIIllII.IIIlIIllllIIllllllIlIIIll()) {
                this.llIIlllIIIIlllIllIlIlllIl += (float)(0.006666666666666667 * 1.5);
            }
            else {
                this.llIIlllIIIIlllIllIlIlllIl -= (float)(0.008749999608844537 * 1.1428571939468384);
            }
            this.llIIlllIIIIlllIllIlIlllIl = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.llIIlllIIIIlllIllIlIlllIl, 0.0f, 1.0f);
        }
    }
    
    protected void w_() {
        this.IllIIlIIlllllIllIIIlllIII.clear();
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("buildList");
        if (!this.IllIlIlIllllIlIIllllIIlll) {
            for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
                final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
                final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll.IIIlIIlIlIIIlllIIlIllllll / 16);
                final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll.IllIlIlIllllIlIIllllIIlll / 16);
                for (int iiIllIllIlIlllllllIlIlIII = this.IIIllIllIlIlllllllIlIlIII(), j = -iiIllIllIlIlllllllIlIlIII; j <= iiIllIllIlIlllllllIlIlIII; ++j) {
                    for (int k = -iiIllIllIlIlllllllIlIlIII; k <= iiIllIllIlIlllllllIlIlIII; ++k) {
                        this.IllIIlIIlllllIllIIIlllIII.add(new IlIlIlIIlIlIlIlllIlllIIII(j + illlIIIlIlllIllIlIIlllIlI, k + illlIIIlIlllIllIlIIlllIlI2));
                    }
                }
            }
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        if (this.lllIlIIllllIIIIlIllIlIIII > 0) {
            --this.lllIlIIllllIIIIlIllIlIIII;
        }
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("playerCheckLight");
        if (!this.IlIlIIIlllIIIlIlllIlIllIl.isEmpty()) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll2 = this.IlIlIIIlllIIIlIlllIlIllIl.get(this.lllIIIIIlIllIlIIIllllllII.nextInt(this.IlIlIIIlllIIIlIlllIlIllIl.size()));
            this.lllIIIIIlIllIlIIIllllllII(MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll2.IIIlIIlIlIIIlllIIlIllllll) + this.lllIIIIIlIllIlIIIllllllII.nextInt(11) - 5, MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll2.IllIlIIIIlllIIllIIlllIIlI) + this.lllIIIIIlIllIlIIIllllllII.nextInt(11) - 5, MathHelper.IlllIIIlIlllIllIlIIlllIlI(lIllIIIIlIIlIllIIIlIlIlll2.IllIlIlIllllIlIIllllIIlll) + this.lllIIIIIlIllIlIIIllllllII.nextInt(11) - 5);
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
    }
    
    protected abstract int IIIllIllIlIlllllllIlIlIII();
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final lIlllllIIllIlIlIlllIIIIII lIlllllIIllIlIlIlllIIIIII) {
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("moodSound");
        if (this.lllIlIIllllIIIIlIllIlIIII == 0 && !this.IllIlIlIllllIlIIllllIIlll) {
            this.lIIIIllIIlIlIllIIIlIllIlI = this.lIIIIllIIlIlIllIIIlIllIlI * 3 + 1013904223;
            final int n3 = this.lIIIIllIIlIlIllIIIlIllIlI >> 2;
            final int n4 = n3 & 0xF;
            final int n5 = n3 >> 8 & 0xF;
            final int n6 = n3 >> 16 & 0xFF;
            final IIlllllllIlllIIllllIIlIll liiiiiiiiIlIllIIllIlIIlIl = lIlllllIIllIlIlIlllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl(n4, n6, n5);
            final int n7 = n4 + n;
            final int n8 = n5 + n2;
            if (liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl() == Material.air && this.lIIIIllIIlIlIllIIIlIllIlI(n7, n6, n8) <= this.lllIIIIIlIllIlIIIllllllII.nextInt(8) && this.lIIIIIIIIIlIllIIllIlIIlIl(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI, n7, n6, n8) <= 0) {
                final lIllIIIIlIIlIllIIIlIlIlll liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(n7 + 0.13414634764194489 * 3.7272725556015063, n6 + 0.16981132228249715 * 2.944444417953491, n8 + 0.07692307978868484 * 6.4999997578561395, 8);
                if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(n7 + 0.7352941099128922 * 0.6800000071525574, n6 + 0.695652186870575 * 0.7187499866122382, n8 + 3.4999998435378146 * 0.1428571492433548) > 4) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(n7 + 2.02439022064209 * 0.24698795464513337, n6 + 0.6964285969734192 * 0.7179486916145169, n8 + 2.299999952316284 * 0.21739130885479366, "ambient.cave.cave", 0.30927834f * 2.2633333f, 0.7813953f * 1.0238096f + this.lllIIIIIlIllIlIIIllllllII.nextFloat() * (0.38285717f * 0.52238804f));
                    this.lllIlIIllllIIIIlIllIlIIII = this.lllIIIIIlIllIlIIIllllllII.nextInt(12000) + 6000;
                }
            }
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endStartSection("checkLight");
        lIlllllIIllIlIlIlllIIIIII.lIIlIlIllIIlIIIlIIIlllIII();
    }
    
    protected void u_() {
        this.w_();
    }
    
    public boolean llIlIIIlIIIIlIlllIlIIIIll(final int n, final int n2, final int n3) {
        return this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3, false);
    }
    
    public boolean IIIlIIllllIIllllllIlIIIll(final int n, final int n2, final int n3) {
        return this.IIIIllIlIIIllIlllIlllllIl(n, n2, n3, true);
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3, final boolean b) {
        if (this.a_(n, n3).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3) > 1.451613f * 0.10333333f) {
            return false;
        }
        if (n2 >= 0 && n2 < 256 && this.lIIIIIIIIIlIllIIllIlIIlIl(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl, n, n2, n3) < 10) {
            final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
            if ((block == IllllllIllIIlllIllIIlIIll.IlllIllIlIIIIlIIlIIllIIIl || block == IllllllIllIIlllIllIIlIIll.lIIIIllIIlIlIllIIIlIllIlI) && this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) == 0) {
                if (!b) {
                    return true;
                }
                int n4 = 1;
                if (n4 != 0 && this.getBlock(n - 1, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.IllIIIIIIIlIlIllllIIllIII) {
                    n4 = 0;
                }
                if (n4 != 0 && this.getBlock(n + 1, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() != Material.IllIIIIIIIlIlIllllIIllIII) {
                    n4 = 0;
                }
                if (n4 != 0 && this.getBlock(n, n2, n3 - 1).IlIlIIIlllIIIlIlllIlIllIl() != Material.IllIIIIIIIlIlIllllIIllIII) {
                    n4 = 0;
                }
                if (n4 != 0 && this.getBlock(n, n2, n3 + 1).IlIlIIIlllIIIlIlllIlIllIl() != Material.IllIIIIIIIlIlIllllIIllIII) {
                    n4 = 0;
                }
                if (n4 == 0) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3, final boolean b) {
        return this.a_(n, n3).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3) <= 2.0681818f * 0.072527476f && (!b || (n2 >= 0 && n2 < 256 && this.lIIIIIIIIIlIllIIllIlIIlIl(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl, n, n2, n3) < 10 && this.getBlock(n, n2, n3).IlIlIIIlllIIIlIlllIlIllIl() == Material.air && IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll.IIIIllIIllIIIIllIllIIIlIl(this, n, n2, n3)));
    }
    
    public boolean lllIIIIIlIllIlIIIllllllII(final int n, final int n2, final int n3) {
        boolean b = false;
        if (!this.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII) {
            b |= this.IlllIIIlIlllIllIlIIlllIlI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI, n, n2, n3);
        }
        return b | this.IlllIIIlIlllIllIlIIlllIlI(lIIIlIlIllllIIIlIlIlIIIlI.lIIIIIIIIIlIllIIllIlIIlIl, n, n2, n3);
    }
    
    private int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI) {
        if (liiIlIlIllllIIIlIlIlIIIlI == lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI && this.IllIIIIIIIlIlIllllIIllIII(n, n2, n3)) {
            return 15;
        }
        final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
        int n4 = (liiIlIlIllllIIIlIlIlIIIlI == lIIIlIlIllllIIIlIlIlIIIlI.lIIIIlIIllIIlIIlIIIlIIllI) ? 0 : block.IIIIllIlIIIllIlllIlllllIl();
        int liiiiiiiiIlIllIIllIlIIlIl = block.lIIIIIIIIIlIllIIllIlIIlIl();
        if (liiiiiiiiIlIllIIllIlIIlIl >= 15 && block.IIIIllIlIIIllIlllIlllllIl() > 0) {
            liiiiiiiiIlIllIIllIlIIlIl = 1;
        }
        if (liiiiiiiiIlIllIIllIlIIlIl < 1) {
            liiiiiiiiIlIllIIllIlIIlIl = 1;
        }
        if (liiiiiiiiIlIllIIllIlIIlIl >= 15) {
            return 0;
        }
        if (n4 >= 14) {
            return n4;
        }
        for (int i = 0; i < 6; ++i) {
            final int n5 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n + IIlllIlIIIllIlIIIlIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl[i], n2 + IIlllIlIIIllIlIIIlIlllIIl.IlllIIIlIlllIllIlIIlllIlI[i], n3 + IIlllIlIIIllIlIIIlIlllIIl.IIIIllIlIIIllIlllIlllllIl[i]) - liiiiiiiiIlIllIIllIlIIlIl;
            if (n5 > n4) {
                n4 = n5;
            }
            if (n4 >= 14) {
                return n4;
            }
        }
        return n4;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI(final lIIIlIlIllllIIIlIlIlIIIlI liiIlIlIllllIIIlIlIlIIIlI, final int n, final int n2, final int n3) {
        if ((boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl() && (boolean)CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl()) {
            return true;
        }
        if (!this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, 17)) {
            return false;
        }
        int i = 0;
        int n4 = 0;
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("getBrightness");
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n, n2, n3);
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, liiIlIlIllllIIIlIlIlIIIlI);
        if (liiiIlIIllIIlIIlIIIlIIllI > liiiiiiiiIlIllIIllIlIIlIl) {
            this.IllllIllllIlIIIlIIIllllll[n4++] = 133152;
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI < liiiiiiiiIlIllIIllIlIIlIl) {
            this.IllllIllllIlIIIlIIIllllll[n4++] = (0x20820 | liiiiiiiiIlIllIIllIlIIlIl << 18);
            while (i < n4) {
                final int n5 = this.IllllIllllIlIIIlIIIllllll[i++];
                final int n6 = (n5 & 0x3F) - 32 + n;
                final int n7 = (n5 >> 6 & 0x3F) - 32 + n2;
                final int n8 = (n5 >> 12 & 0x3F) - 32 + n3;
                final int n9 = n5 >> 18 & 0xF;
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n6, n7, n8) == n9) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIllllIIIlIlIlIIIlI, n6, n7, n8, 0);
                    if (n9 <= 0 || MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n6 - n) + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n7 - n2) + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n8 - n3) >= 17) {
                        continue;
                    }
                    for (int j = 0; j < 6; ++j) {
                        final int n10 = n6 + IIlllIlIIIllIlIIIlIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl[j];
                        final int n11 = n7 + IIlllIlIIIllIlIIIlIlllIIl.IlllIIIlIlllIllIlIIlllIlI[j];
                        final int n12 = n8 + IIlllIlIIIllIlIIIlIlllIIl.IIIIllIlIIIllIlllIlllllIl[j];
                        final int max = Math.max(1, this.getBlock(n10, n11, n12).lIIIIIIIIIlIllIIllIlIIlIl());
                        if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n10, n11, n12) == n9 - max && n4 < this.IllllIllllIlIIIlIIIllllll.length) {
                            this.IllllIllllIlIIIlIIIllllll[n4++] = (n10 - n + 32 | n11 - n2 + 32 << 6 | n12 - n3 + 32 << 12 | n9 - max << 18);
                        }
                    }
                }
            }
            i = 0;
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("checkedPosition < toCheckCount");
        while (i < n4) {
            final int n13 = this.IllllIllllIlIIIlIIIllllll[i++];
            final int n14 = (n13 & 0x3F) - 32 + n;
            final int n15 = (n13 >> 6 & 0x3F) - 32 + n2;
            final int n16 = (n13 >> 12 & 0x3F) - 32 + n3;
            final int liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14, n15, n16);
            final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(n14, n15, n16, liiIlIlIllllIIIlIlIlIIIlI);
            if (liiiIlIIllIIlIIlIIIlIIllI2 != liiiiiiiiIlIllIIllIlIIlIl2) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIllllIIIlIlIlIIIlI, n14, n15, n16, liiiIlIIllIIlIIlIIIlIIllI2);
                if (liiiIlIIllIIlIIlIIIlIIllI2 <= liiiiiiiiIlIllIIllIlIIlIl2) {
                    continue;
                }
                final int abs = Math.abs(n14 - n);
                final int abs2 = Math.abs(n15 - n2);
                final int abs3 = Math.abs(n16 - n3);
                final boolean b = n4 < this.IllllIllllIlIIIlIIIllllll.length - 6;
                if (abs + abs2 + abs3 >= 17 || !b) {
                    continue;
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14 - 1, n15, n16) < liiiIlIIllIIlIIlIIIlIIllI2) {
                    this.IllllIllllIlIIIlIIIllllll[n4++] = n14 - 1 - n + 32 + (n15 - n2 + 32 << 6) + (n16 - n3 + 32 << 12);
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14 + 1, n15, n16) < liiiIlIIllIIlIIlIIIlIIllI2) {
                    this.IllllIllllIlIIIlIIIllllll[n4++] = n14 + 1 - n + 32 + (n15 - n2 + 32 << 6) + (n16 - n3 + 32 << 12);
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14, n15 - 1, n16) < liiiIlIIllIIlIIlIIIlIIllI2) {
                    this.IllllIllllIlIIIlIIIllllll[n4++] = n14 - n + 32 + (n15 - 1 - n2 + 32 << 6) + (n16 - n3 + 32 << 12);
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14, n15 + 1, n16) < liiiIlIIllIIlIIlIIIlIIllI2) {
                    this.IllllIllllIlIIIlIIIllllll[n4++] = n14 - n + 32 + (n15 + 1 - n2 + 32 << 6) + (n16 - n3 + 32 << 12);
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14, n15, n16 - 1) < liiiIlIIllIIlIIlIIIlIIllI2) {
                    this.IllllIllllIlIIIlIIIllllll[n4++] = n14 - n + 32 + (n15 - n2 + 32 << 6) + (n16 - 1 - n3 + 32 << 12);
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(liiIlIlIllllIIIlIlIlIIIlI, n14, n15, n16 + 1) >= liiiIlIIllIIlIIlIIIlIIllI2) {
                    continue;
                }
                this.IllllIllllIlIIIlIIIllllll[n4++] = n14 - n + 32 + (n15 - n2 + 32 << 6) + (n16 + 1 - n3 + 32 << 12);
            }
        }
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        return true;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final boolean b) {
        return false;
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIllIlIlIlllIIIIII lIlllllIIllIlIlIlllIIIIII, final boolean b) {
        return null;
    }
    
    public List lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(entity, ilIllIIlIlIllIlIllllllllI, null);
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final lllIIIlllllllIlIIIlIllIIl lllIIIlllllllIlIIIlIllIIl) {
        final ArrayList list = new ArrayList();
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI - 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI - 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 2) / 16);
        for (int i = illlIIIlIlllIllIlIIlllIlI; i <= illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j <= illlIIIlIlllIllIlIIlllIlI4; ++j) {
                if (this.IlllIIIlIlllIllIlIIlllIlI(i, j)) {
                    this.IIIIllIIllIIIIllIllIIIlIl(i, j).lIIIIlIIllIIlIIlIIIlIIllI(entity, ilIllIIlIlIllIlIllllllllI, list, lllIIIlllllllIlIIIlIllIIl);
                }
            }
        }
        return list;
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(clazz, ilIllIIlIlIllIlIllllllllI, (lllIIIlllllllIlIIIlIllIIl)null);
    }
    
    public List lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final lllIIIlllllllIlIIIlIllIIl lllIIIlllllllIlIIIlIllIIl) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI - 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl + 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI - 2) / 16);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI((ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl + 2) / 16);
        final ArrayList list = new ArrayList();
        for (int i = illlIIIlIlllIllIlIIlllIlI; i <= illlIIIlIlllIllIlIIlllIlI2; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI3; j <= illlIIIlIlllIllIlIIlllIlI4; ++j) {
                if (this.IlllIIIlIlllIllIlIIlllIlI(i, j)) {
                    this.IIIIllIIllIIIIllIllIIIlIl(i, j).lIIIIlIIllIIlIIlIIIlIIllI(clazz, ilIllIIlIlIllIlIllllllllI, list, lllIIIlllllllIlIIIlIllIIl);
                }
            }
        }
        return list;
    }
    
    public Entity lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz, final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI, final Entity entity) {
        final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(clazz, ilIllIIlIlIllIlIllllllllI);
        Entity entity2 = null;
        double n = 2.5 * 7.190772539449263E307;
        for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI.size(); ++i) {
            final Entity entity3 = liiiIlIIllIIlIIlIIIlIIllI.get(i);
            if (entity3 != entity) {
                final double iiiIllIIllIIIIllIllIIIlIl = entity.IIIIllIIllIIIIllIllIIIlIl(entity3);
                if (iiiIllIIllIIIIllIllIIIlIl <= n) {
                    entity2 = entity3;
                    n = iiiIllIIllIIIIllIllIIIlIl;
                }
            }
        }
        return entity2;
    }
    
    public abstract Entity lIIIIlIIllIIlIIlIIIlIIllI(final int p0);
    
    public List lIIIIIllllIIIIlIlIIIIlIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final IllIllIlIIlllIllIIllIlIIl illIllIlIIlllIllIIllIlIIl) {
        if (this.IIIIllIIllIIIIllIllIIIlIl(n, n2, n3)) {
            this.IIIIllIlIIIllIlllIlllllIl(n, n3).IIIllIllIlIlllllllIlIlIII();
        }
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz) {
        int n = 0;
        for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++i) {
            final Entity entity = this.IlllIIIlIlllIllIlIIlllIlI.get(i);
            if ((!(entity instanceof IlllIIIllIlIIlIllIIlIlllI) || !((IlllIIIllIlIIlIllIIlIlllI)entity).IlllllIllIIIllIIIllIllIII()) && clazz.isAssignableFrom(((IlllIIIllIlIIlIllIIlIlllI)entity).getClass())) {
                ++n;
            }
        }
        return n;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final List list) {
        this.IlllIIIlIlllIllIlIIlllIlI.addAll(list);
        for (int i = 0; i < list.size(); ++i) {
            this.IlllIIIlIlllIllIlIIlllIlI(list.get(i));
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final List list) {
        this.IIIIllIlIIIllIlllIlllllIl.addAll(list);
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n, final int n2, final int n3, final boolean b, final int n4, final Entity entity, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        final IIlllllllIlllIIllllIIlIll block = this.getBlock(n, n2, n3);
        final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI = b ? null : illlllllIlllIIllllIIlIll.IlllIIIlIlllIllIlIIlllIlI(this, n, n2, n3);
        return (ilIllIIlIlIllIlIllllllllI == null || this.lIIIIlIIllIIlIIlIIIlIIllI(ilIllIIlIlIllIlIllllllllI, entity)) && ((block.IlIlIIIlllIIIlIlllIlIllIl() == Material.lllIIIIIlIllIlIIIllllllII && illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lllIIlIIIllIIlllIlIIIllIl) || (block.IlIlIIIlllIIIlIlllIlIllIl().lIIIIllIIlIlIllIIIlIllIlI() && illlllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this, n, n2, n3, n4, lIlIlIlIlIllllIlllIIIlIlI)));
    }
    
    public lIlIIlIlIIIIIIlIIIlllIIII lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final Entity entity2, final float n, final boolean b, final boolean b2, final boolean b3, final boolean b4) {
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("pathfind");
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIIIIlllIIllIIlllIIlI + 1.0);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll);
        final int n2 = (int)(n + 16);
        final lIlIIlIlIIIIIIlIIIlllIIII liiiIlIIllIIlIIlIIIlIIllI = new lIIIlIllIlIIIlIlIlIIllIIl(new IlIlllIIIIIIllIlIIlIIlIll(this, illlIIIlIlllIllIlIIlllIlI - n2, illlIIIlIlllIllIlIIlllIlI2 - n2, illlIIIlIlllIllIlIIlllIlI3 - n2, illlIIIlIlllIllIlIIlllIlI + n2, illlIIIlIlllIllIlIIlllIlI2 + n2, illlIIIlIlllIllIlIIlllIlI3 + n2, 0), b, b2, b3, b4).lIIIIlIIllIIlIIlIIIlIIllI(entity, entity2, n);
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public lIlIIlIlIIIIIIlIIIlllIIII lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final int n, final int n2, final int n3, final float n4, final boolean b, final boolean b2, final boolean b3, final boolean b4) {
        this.IIIlIIlIlIIIlllIIlIllllll.startSection("pathfind");
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIIIIlllIIllIIlllIIlI);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll);
        final int n5 = (int)(n4 + 8);
        final lIlIIlIlIIIIIIlIIIlllIIII liiiIlIIllIIlIIlIIIlIIllI = new lIIIlIllIlIIIlIlIlIIllIIl(new IlIlllIIIIIIllIlIIlIIlIll(this, illlIIIlIlllIllIlIIlllIlI - n5, illlIIIlIlllIllIlIIlllIlI2 - n5, illlIIIlIlllIllIlIIlllIlI3 - n5, illlIIIlIlllIllIlIIlllIlI + n5, illlIIIlIlllIllIlIIlllIlI2 + n5, illlIIIlIlllIllIlIIlllIlI3 + n5, 0), b, b2, b3, b4).lIIIIlIIllIIlIIlIIIlIIllI(entity, n, n2, n3, n4);
        this.IIIlIIlIlIIIlllIIlIllllll.endSection();
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4) {
        return this.getBlock(n, n2, n3).IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)this, n, n2, n3, n4);
    }
    
    public int lIIIIIllllIIIIlIlIIIIlIlI(final int n, final int n2, final int n3) {
        final int max = Math.max(0, this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2 - 1, n3, 0));
        if (max >= 15) {
            return max;
        }
        final int max2 = Math.max(max, this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2 + 1, n3, 1));
        if (max2 >= 15) {
            return max2;
        }
        final int max3 = Math.max(max2, this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 - 1, 2));
        if (max3 >= 15) {
            return max3;
        }
        final int max4 = Math.max(max3, this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3 + 1, 3));
        if (max4 >= 15) {
            return max4;
        }
        final int max5 = Math.max(max4, this.lIIIIIIIIIlIllIIllIlIIlIl(n - 1, n2, n3, 4));
        if (max5 >= 15) {
            return max5;
        }
        final int max6 = Math.max(max5, this.lIIIIIIIIIlIllIIllIlIIlIl(n + 1, n2, n3, 5));
        return (max6 >= 15) ? max6 : max6;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3, final int n4) {
        return this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3, n4) > 0;
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl(final int n, final int n2, final int n3, final int n4) {
        return this.getBlock(n, n2, n3).lIIIIllIIlIlIllIIIlIllIlI() ? this.lIIIIIllllIIIIlIlIIIIlIlI(n, n2, n3) : this.getBlock(n, n2, n3).IIIIllIlIIIllIlllIlllllIl((lIIllIIIllIIIIllIllIIllIl)this, n, n2, n3, n4);
    }
    
    public boolean IIIIIIlIlIlIllllllIlllIlI(final int n, final int n2, final int n3) {
        return this.IlIlIIIlllIIIlIlllIlIllIl(n, n2 - 1, n3, 0) > 0 || this.IlIlIIIlllIIIlIlllIlIllIl(n, n2 + 1, n3, 1) > 0 || this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3 - 1, 2) > 0 || this.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3 + 1, 3) > 0 || this.IlIlIIIlllIIIlIlllIlIllIl(n - 1, n2, n3, 4) > 0 || this.IlIlIIIlllIIIlIlllIlIllIl(n + 1, n2, n3, 5) > 0;
    }
    
    public int IllIllIIIlIIlllIIIllIllII(final int n, final int n2, final int n3) {
        int n4 = 0;
        for (int i = 0; i < 6; ++i) {
            final int ilIlIIIlllIIIlIlllIlIllIl = this.IlIlIIIlllIIIlIlllIlIllIl(n + IIlllIlIIIllIlIIIlIlllIIl.lIIIIIIIIIlIllIIllIlIIlIl[i], n2 + IIlllIlIIIllIlIIIlIlllIIl.IlllIIIlIlllIllIlIIlllIlI[i], n3 + IIlllIlIIIllIlIIIlIlllIIl.IIIIllIlIIIllIlllIlllllIl[i], i);
            if (ilIlIIIlllIIIlIlllIlIllIl >= 15) {
                return 15;
            }
            if (ilIlIIIlllIIIlIlllIlIllIl > n4) {
                n4 = ilIlIIIlllIIIlIlllIlIllIl;
            }
        }
        return n4;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final double n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIIIIlllIIllIIlllIIlI, entity.IllIlIlIllllIlIIllllIIlll, n);
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final double n4) {
        double n5 = -1;
        lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = null;
        for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll2 = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
            final double ilIlIIIlllIIIlIlllIlIllIl = lIllIIIIlIIlIllIIIlIlIlll2.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            if ((n4 < 0.0 || ilIlIIIlllIIIlIlllIlIllIl < n4 * n4) && (n5 == -1 || ilIlIIIlllIIIlIlllIlIllIl < n5)) {
                n5 = ilIlIIIlllIIIlIlllIlIllIl;
                lIllIIIIlIIlIllIIIlIlIlll = lIllIIIIlIIlIllIIIlIlIlll2;
            }
        }
        return lIllIIIIlIIlIllIIIlIlIlll;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl(final Entity entity, final double n) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl(entity.IIIlIIlIlIIIlllIIlIllllll, entity.IllIlIIIIlllIIllIIlllIIlI, entity.IllIlIlIllllIlIIllllIIlll, n);
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl(final double n, final double n2, final double n3, final double n4) {
        double n5 = -1;
        lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = null;
        for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll2 = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
            if (!lIllIIIIlIIlIllIIIlIlIlll2.IlllIIIllIlIlIIIllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI && lIllIIIIlIIlIllIIIlIlIlll2.IlIlllIIIIlIllIlllIlIIIll()) {
                final double ilIlIIIlllIIIlIlllIlIllIl = lIllIIIIlIIlIllIIIlIlIlll2.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                double n6 = n4;
                if (lIllIIIIlIIlIllIIIlIlIlll2.lIlIlIllIIIIIIIIllllIIllI()) {
                    n6 = n4 * (5.0 * 0.1600000023841858);
                }
                if (lIllIIIIlIIlIllIIIlIlIlll2.IIIllllIlIIlIIIlIlIlllIII()) {
                    float liiIllIIIIlIIllIIIIIIIlll = lIllIIIIlIIlIllIIIlIlIlll2.lIIIllIIIIlIIllIIIIIIIlll();
                    if (liiIllIIIIlIIllIIIIIIIlll < 1.7894737f * 0.055882353f) {
                        liiIllIIIIlIIllIIIIIIIlll = 0.064705886f * 1.5454545f;
                    }
                    n6 *= 0.23529412f * 2.975f * liiIllIIIIlIIllIIIIIIIlll;
                }
                if ((n4 < 0.0 || ilIlIIIlllIIIlIlllIlIllIl < n6 * n6) && (n5 == -1 || ilIlIIIlllIIIlIlllIlIllIl < n5)) {
                    n5 = ilIlIIIlllIIIlIlllIlIllIl;
                    lIllIIIIlIIlIllIIIlIlIlll = lIllIIIIlIIlIllIIIlIlIlll2;
                }
            }
        }
        return lIllIIIIlIIlIllIIIlIlIlll;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
            if (s.equals(lIllIIIIlIIlIllIIIlIlIlll.IlIlIIIlllllIIIlIlIlIllII())) {
                return lIllIIIIlIIlIllIIIlIlIlll;
            }
        }
        return null;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
            if (lIllIIIIlIIlIllIIIlIlIlll.IlIlllIIIIlIllIlllIlIIIll() && (s.equals(lIllIIIIlIIlIllIIIlIlIlll.llllIIllllllIlIIlIlIIIllI().getId().toString()) || s.equals(lIllIIIIlIIlIllIIIlIlIlll.llllIIllllllIlIIlIlIIIllI().getId().toString().replaceAll("-", "")))) {
                return lIllIIIIlIIlIllIIIlIlIlll;
            }
        }
        return null;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll lIIIIlIIllIIlIIlIIIlIIllI(final UUID uuid) {
        for (int i = 0; i < this.IlIlIIIlllIIIlIlllIlIllIl.size(); ++i) {
            final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = this.IlIlIIIlllIIIlIlllIlIllIl.get(i);
            if (uuid.equals(lIllIIIIlIIlIllIIIlIlIlll.llllIIllIIlllllIlIlIIllll())) {
                return lIllIIIIlIIlIllIIIlIlIlll;
            }
        }
        return null;
    }
    
    public void v_() {
    }
    
    public void IIIIIIlIlIlIllllllIlllIlI() {
        this.IlIIlIIIIlIIIIllllIIlIllI.IIIIllIlIIIllIlllIlllllIl();
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final long n) {
        this.lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    public long IllIllIIIlIIlllIIIllIllII() {
        return this.lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public long IlIIlIIIIlIIIIllllIIlIllI() {
        return this.lIIlIIllIIIIIlIllIIIIllII.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    public long lIIlIIllIIIIIlIllIIIIllII() {
        return this.lIIlIIllIIIIIlIllIIIIllII.IIIllIllIlIlllllllIlIlIII();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final long n) {
        this.lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    public IlllIllllIIIIIlIlIlIIIllI lIIlllIIlIlllllllllIIIIIl() {
        return new IlllIllllIIIIIlIlIlIIIllI(this.lIIlIIllIIIIIlIllIIIIllII.IlllIIIlIlllIllIlIIlllIlI(), this.lIIlIIllIIIIIlIllIIIIllII.IIIIllIlIIIllIlllIlllllIl(), this.lIIlIIllIIIIIlIllIIIIllII.IIIIllIIllIIIIllIllIIIlIl());
    }
    
    public void IlIIlIIIIlIIIIllllIIlIllI(final int n, final int n2, final int n3) {
        this.lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final Entity entity) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IIIlIIlIlIIIlllIIlIllllll / 16);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entity.IllIlIlIllllIlIIllllIIlll / 16);
        for (int n = 2, i = illlIIIlIlllIllIlIIlllIlI - n; i <= illlIIIlIlllIllIlIIlllIlI + n; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI2 - n; j <= illlIIIlIlllIllIlIIlllIlI2 + n; ++j) {
                this.IIIIllIIllIIIIllIllIIIlIl(i, j);
            }
        }
        if (!this.IlllIIIlIlllIllIlIIlllIlI.contains(entity)) {
            this.IlllIIIlIlllIllIlIIlllIlI.add(entity);
        }
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n, final int n2, final int n3) {
        return true;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Entity entity, final byte b) {
    }
    
    public IllIlIIIlIIlllIIIlIIlIllI lIllIllIlIIllIllIlIlIIlIl() {
        return this.IllIllIIIlIIlllIIIllIllII;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4, final int n5) {
        illlllllIlllIIllllIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(this, n, n2, n3, n4, n5);
    }
    
    public IIIlIIIllIIIlIlllIlIIIlII llIlIIIllIIIIlllIlIIIIIlI() {
        return this.IlIIlIIIIlIIIIllllIIlIllI;
    }
    
    public IllIlIlllIIIIIIlIIllIIIll lIllIlIlllIIlIIllIIlIIlII() {
        return this.lIIlIIllIIIIIlIllIIIIllII;
    }
    
    public IIlllIllIIlIIIIlllIlIlIII IIIlIIlIlIIIlllIIlIllllll() {
        return this.lIIlIIllIIIIIlIllIIIIllII.lIllIllIlIIllIllIlIlIIlIl();
    }
    
    public void IllIlIIIIlllIIllIIlllIIlI() {
    }
    
    public float IllIIIIIIIlIlIllllIIllIII(final float n) {
        return (this.lIIlIlIllIIlIIIlIIIlllIII + (this.IIIlllIIIllIllIlIIIIIIlII - this.lIIlIlIllIIlIIIlIIIlllIII) * n) * this.IlllIllIlIIIIlIIlIIllIIIl(n);
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(final float n) {
        this.lIIlIlIllIIlIIIlIIIlllIII = n;
        this.IIIlllIIIllIllIlIIIIIIlII = n;
    }
    
    public float IlllIllIlIIIIlIIlIIllIIIl(final float n) {
        return this.IlIlllIIIIllIllllIllIIlIl + (this.llIIlllIIIIlllIllIlIlllIl - this.IlIlllIIIIllIllllIllIIlIl) * n;
    }
    
    public void IlIlllIIIIllIllllIllIIlIl(final float n) {
        this.IlIlllIIIIllIllllIllIIlIl = n;
        this.llIIlllIIIIlllIllIlIlllIl = n;
    }
    
    public boolean IllIlIlIllllIlIIllllIIlll() {
        return this.IllIIIIIIIlIlIllllIIllIII(1.0f) > 1.073493956630956 * 0.8383838534355164;
    }
    
    public boolean IllIIlIIlllllIllIIIlllIII() {
        return this.IlllIllIlIIIIlIIlIIllIIIl(1.0f) > 0.9545454382896423 * 0.20952381309197882;
    }
    
    public boolean lIIlIIllIIIIIlIllIIIIllII(final int n, final int n2, final int n3) {
        if (!this.IllIIlIIlllllIllIIIlllIII()) {
            return false;
        }
        if (!this.IllIIIIIIIlIlIllllIIllIII(n, n2, n3)) {
            return false;
        }
        if (this.IllIIIIIIIlIlIllllIIllIII(n, n3) > n2) {
            return false;
        }
        final IIlIIlIIllIIllIlIIIIIIIlI a_ = this.a_(n, n3);
        return !a_.IIIIllIlIIIllIlllIlllllIl() && !this.IIIIllIIllIIIIllIllIIIlIl(n, n2, n3, false) && a_.IIIIllIIllIIIIllIllIIIlIl();
    }
    
    public boolean lIIlllIIlIlllllllllIIIIIl(final int n, final int n2, final int n3) {
        return this.a_(n, n3).IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final IIIlllIIIIIlIllIIIIIIIlll iiIlllIIIIIlIllIIIIIIIlll) {
        this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(s, iiIlllIIIIIlIllIIIIIIIlll);
    }
    
    public IIIlllIIIIIlIllIIIIIIIlll lIIIIlIIllIIlIIlIIIlIIllI(final Class clazz, final String s) {
        return this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(clazz, s);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final String s) {
        return this.lIllIllIlIIllIllIlIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4, final int n5) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, n5);
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3, final int n4, final int n5) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(null, n, n2, n3, n4, n5);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int i, final int n, final int n2, final int n3, final int j) {
        try {
            for (int k = 0; k < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++k) {
                ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(k)).lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlIIlIllIIIlIlIlll, i, n, n2, n3, j);
            }
        }
        catch (Throwable t) {
            final CrashReport crashReport = CrashReport.makeCrashReport(t, "Playing level event");
            final lIlIllIIIIIlllIlllIIIllIl category = crashReport.makeCategory("Level event being played");
            category.lIIIIlIIllIIlIIlIIIlIIllI("Event source", lIllIIIIlIIlIllIIIlIlIlll);
            category.lIIIIlIIllIIlIIlIIIlIIllI("Event type", i);
            category.lIIIIlIIllIIlIIlIIIlIIllI("Event data", j);
            throw new ReportedException(crashReport);
        }
    }
    
    @Override
    public int IIIIllIlIIIllIlllIlllllIl() {
        return 256;
    }
    
    public int lIlIlIllIIIIIIIIllllIIllI() {
        return this.lIIIIIllllIIIIlIlIIIIlIlI.IIIllIllIlIlllllllIlIlIII ? 128 : 256;
    }
    
    public Random lIllIllIlIIllIllIlIlIIlIl(final int n, final int n2, final int n3) {
        this.lllIIIIIlIllIlIIIllllllII.setSeed(n * 341873128712L + n2 * 132897987541L + this.lIllIlIlllIIlIIllIIlIIlII().lIIIIIIIIIlIllIIllIlIIlIl() + n3);
        return this.lllIIIIIlIllIlIIIllllllII;
    }
    
    public IIlIlIlIlIlIlllIIlIllIIlI lIIIIIIIIIlIllIIllIlIIlIl(final String s, final int n, final int n2, final int n3) {
        return this.lIllIllIlIIllIllIlIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(this, s, n, n2, n3);
    }
    
    @Override
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return false;
    }
    
    public double IlllIIlllIIIIllIIllllIlIl() {
        return (this.lIIlIIllIIIIIlIllIIIIllII.IlIIlIIIIlIIIIllllIIlIllI() == IlIlIlIIlllIIIlIIllllIlII.IlllIIIlIlllIllIlIIlllIlI) ? 0.0 : 63;
    }
    
    public lIlIllIIIIIlllIlllIIIllIl lIIIIlIIllIIlIIlIIIlIIllI(final CrashReport crashReport) {
        final lIlIllIIIIIlllIlllIIIllIl liiiIlIIllIIlIIlIIIlIIllI = crashReport.lIIIIlIIllIIlIIlIIIlIIllI("Affected level", 1);
        liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI("Level name", (this.lIIlIIllIIIIIlIllIIIIllII == null) ? "????" : this.lIIlIIllIIIIIlIllIIIIllII.IlIlllIIIIllIllllIllIIlIl());
        liiiIlIIllIIlIIlIIIlIIllI.addCrashSectionCallable("All players", new IlIIlIIIIllIIIlIIIllIllll(this));
        liiiIlIIllIIlIIlIIIlIIllI.addCrashSectionCallable("Chunk stats", new llIlIlIlIlllIIllllIIIllII(this));
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3, final int n4, final int n5) {
        for (int i = 0; i < this.IIIIIIlIlIlIllllllIlllIlI.size(); ++i) {
            ((llllIlllIlIIlIllllIIlllIl)this.IIIIIIlIlIlIllllllIlllIlI.get(i)).lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, n4, n5);
        }
    }
    
    public Calendar IllllIllllIlIIIlIIIllllll() {
        if (this.IlIIlIIIIlIIIIllllIIlIllI() % 600L == 0L) {
            this.IIlIIllIIIllllIIlllIllIIl.setTimeInMillis(llllIlIlllllIIlIIllllIIII.IllllllllIlIIIIIIIIllIIII());
        }
        return this.IIlIIllIIIllllIIlllIllIIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
    }
    
    public IlIIIIllIlIlIIIlIIIllIIlI IllIIlllIllIlIllIlIIIIIII() {
        return this.IllIlIIIIlllIIllIIlllIIlI;
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        for (int i = 0; i < 4; ++i) {
            final int n4 = n + llIllIlIIIlllllIllllllIIl.lIIIIlIIllIIlIIlIIIlIIllI[i];
            final int n5 = n3 + llIllIlIIIlllllIllllllIIl.lIIIIIIIIIlIllIIllIlIIlIl[i];
            final IIlllllllIlllIIllllIIlIll block = this.getBlock(n4, n2, n5);
            if (IllllllIllIIlllIllIIlIIll.IllIIIIIllllIlllIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(block)) {
                block.lIIIIlIIllIIlIIlIIIlIIllI(this, n4, n2, n5, illlllllIlllIIllllIIlIll);
            }
            else if (block.lIIIIllIIlIlIllIIIlIllIlI()) {
                final int n6 = n4 + llIllIlIIIlllllIllllllIIl.lIIIIlIIllIIlIIlIIIlIIllI[i];
                final int n7 = n5 + llIllIlIIIlllllIllllllIIl.lIIIIIIIIIlIllIIllIlIIlIl[i];
                final IIlllllllIlllIIllllIIlIll block2 = this.getBlock(n6, n2, n7);
                if (IllllllIllIIlllIllIIlIIll.IllIIIIIllllIlllIIlIIllIl.IIIIllIIllIIIIllIllIIIlIl(block2)) {
                    block2.lIIIIlIIllIIlIIlIIIlIIllI(this, n6, n2, n7, illlllllIlllIIllllIIlIll);
                }
            }
        }
    }
    
    public float lIIIIlIIllIIlIIlIIIlIIllI(final double n, final double n2, final double n3) {
        return this.llIlIIIllIIIIlllIlIIIIIlI(MathHelper.IlllIIIlIlllIllIlIIlllIlI(n), MathHelper.IlllIIIlIlllIllIlIIlllIlI(n2), MathHelper.IlllIIIlIlllIllIlIIlllIlI(n3));
    }
    
    public float llIlIIIllIIIIlllIlIIIIIlI(final int n, final int n2, final int n3) {
        float n4 = 0.0f;
        final boolean b = this.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl;
        if (this.IIIIllIIllIIIIllIllIIIlIl(n, n2, n3)) {
            n4 = n4 + MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl(n, n3).IIIIIIlIlIlIllllllIlllIlI / (float)3600000, 0.0f, 1.0f) * (b ? 1.0f : (0.3560606f * 2.106383f)) + this.lIIlIlIllIIlIIIlIIIlllIII() * (0.09574468f * 2.6111112f);
        }
        if (this.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.lIIIIIIIIIlIllIIllIlIIlIl || this.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
            n4 *= this.IIIlIIllllIIllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI() / 2.0f;
        }
        return MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n4, 0.0f, b ? (0.24f * 6.25f) : 1.0f);
    }
    
    public void IlIlIIIlllllIIIlIlIlIllII() {
        final Iterator<llllIlllIlIIlIllllIIlllIl> iterator = this.IIIIIIlIlIlIllllllIlllIlI.iterator();
        while (iterator.hasNext()) {
            iterator.next().IIIIllIlIIIllIlllIlllllIl();
        }
    }
}
