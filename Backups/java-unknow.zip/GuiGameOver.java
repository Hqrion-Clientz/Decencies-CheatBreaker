import org.lwjgl.opengl.GL11;
import java.util.Iterator;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiGameOver extends GuiScreen implements IlIllIlIIllIIIlIIlllllllI
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    
    public GuiGameOver() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.clear();
        if (this.lllIIIIIlIllIlIIIllllllII.theWorld.lIllIlIlllIIlIIllIIlIIlII().IllIllIIIlIIlllIIIllIllII()) {
            if (this.lllIIIIIlIllIlIIIllllllII.IllllIllllIlIIIlIIIllllll()) {
                this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.deleteWorld", new Object[0])));
            }
            else {
                this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.leaveServer", new Object[0])));
            }
        }
        else {
            this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(0, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 72, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.respawn", new Object[0])));
            this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(1, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 100, this.IIIIIIlIlIlIllllllIlllIlI / 4 + 96, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.titleScreen", new Object[0])));
            if (this.lllIIIIIlIllIlIIIllllllII.IIIIlIIIlllllllllIlllIlll() == null) {
                this.IllIllIIIlIIlllIIIllIllII.get(1).IlllIllIlIIIIlIIlIIllIIIl = false;
            }
        }
        final Iterator<lIIlIIIIlIIIIIllIIIIlIIll> iterator = this.IllIllIIIlIIlllIIIllIllII.iterator();
        while (iterator.hasNext()) {
            iterator.next().IlllIllIlIIIIlIIlIIllIIIl = false;
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        switch (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI) {
            case 0: {
                this.lllIIIIIlIllIlIIIllllllII.thePlayer.IllIllIIIlIIlllIIIllIllII();
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
                break;
            }
            case 1: {
                final IIllIlIIlIllIIIIIlIIIIlII illIlIIlIllIIIIIlIIIIlII = new IIllIlIIlIllIIIIIlIIIIlII(this, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.quit.confirm", new Object[0]), "", IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.titleScreen", new Object[0]), IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.respawn", new Object[0]), 0);
                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(illIlIIlIllIIIIIlIIIIlII);
                illIlIIlIllIIIIIlIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(20);
                break;
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final int n) {
        if (b) {
            this.lllIIIIIlIllIlIIIllllllII.theWorld.v_();
            this.lllIIIIIlIllIlIIIllllllII.loadWorld(null);
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new GuiMainMenu());
        }
        else {
            this.lllIIIIIlIllIlIIIllllllII.thePlayer.IllIllIIIlIIlllIIIllIllII();
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(null);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, (float)this.lIIIIIllllIIIIlIlIIIIlIlI, (float)this.IIIIIIlIlIlIllllllIlllIlI, 1615855616, -1602211792);
        GL11.glPushMatrix();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        final boolean illIllIIIlIIlllIIIllIllII = this.lllIIIIIlIllIlIIIllllllII.theWorld.lIllIlIlllIIlIIllIIlIIlII().IllIllIIIlIIlllIIIllIllII();
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, illIllIIIlIIlllIIIllIllII ? IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.title.hardcore", new Object[0]) : IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.title", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2 / 2, 30, 16777215);
        GL11.glPopMatrix();
        if (illIllIIIlIIlllIIIllIllII) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.hardcoreInfo", new Object[0]), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 144, 16777215);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("deathScreen.score", new Object[0]) + ": " + IlIllllIIlIIllIlIlllllIlI.llIlIIIlIIIIlIlllIlIIIIll + this.lllIIIIIlIllIlIIIllllllII.thePlayer.IlIlIIIIIllIlIlIIllIlIIIl(), this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 100, 16777215);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    @Override
    public boolean isUnicode() {
        return false;
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        ++this.lIIIIlIIllIIlIIlIIIlIIllI;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 20) {
            final Iterator<lIIlIIIIlIIIIIllIIIIlIIll> iterator = this.IllIllIIIlIIlllIIIllIllII.iterator();
            while (iterator.hasNext()) {
                iterator.next().IlllIllIlIIIIlIIlIIllIIIl = true;
            }
        }
    }
}
