import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIIlIIlllIIlIIlIlII extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "banlist";
    }
    
    @Override
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return 3;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return (llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI() || llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().IllIIIIIIIlIlIllllIIllIII().lIIIIlIIllIIlIIlIIIlIIllI()) && super.lIIIIIIIIIlIllIIllIlIIlIl(lIlllllIIIIIIllIlIIlIlIII);
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.banlist.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        if (array.length >= 1 && array[0].equalsIgnoreCase("ips")) {
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.banlist.ips", new Object[] { llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIllIIlIlIllIIIlIllIlI().lIIIIIIIIIlIllIIllIlIIlIl().length }));
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI((Object[])llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().lIIIIllIIlIlIllIIIlIllIlI().lIIIIIIIIIlIllIIllIlIIlIl())));
        }
        else {
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.banlist.players", new Object[] { llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl().length }));
            lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI((Object[])llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll().IllllllIllllIIlllIllllllI().IllIIIIIIIlIlIllllIIllIII().lIIIIIIIIIlIllIIllIlIIlIl())));
        }
    }
    
    @Override
    public List lIIIIIIIIIlIllIIllIlIIlIl(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        return (array.length == 1) ? IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(array, "players", "ips") : null;
    }
}
