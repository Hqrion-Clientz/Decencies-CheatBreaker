// 
// Decompiled by Procyon v0.5.36
// 

public interface IIllIlIIllIlIlllllIllIIll extends IllIIIlIlIllIlIllllIIIllI
{
    public static final lllIIIlllllllIlIIIlIllIIl b_ = new lIIIIIlIllIIllIIllllIlIlI();
}
