import java.util.Collections;
import org.lwjgl.input.Mouse;
import java.util.Comparator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

abstract class IIIIIlIlIllIlllIIIIIlIIll extends IllIllllIllIllIllIlllIlII
{
    protected int lIIIIlIIllIIlIIlIIIlIIllI;
    protected List lIIIIIIIIIlIllIIllIlIIlIl;
    protected Comparator lIIlIlIllIIlIIIlIIIlllIII;
    protected int IIIlllIIIllIllIlIIIIIIlII;
    protected int llIlIIIlIIIIlIlllIlIIIIll;
    final /* synthetic */ IlIIIlllIIIlIlIlllIIlllII IIIlIIllllIIllllllIlIIIll;
    
    protected IIIIIlIlIllIlllIIIIIlIIll(final IlIIIlllIIIlIlIlllIIlllII iiIlIIllllIIllllllIlIIIll) {
        this.IIIlIIllllIIllllllIlIIIll = iiIlIIllllIIllllllIlIIIll;
        super(iiIlIIllllIIllllllIlIIIll.lllIIIIIlIllIlIIIllllllII, iiIlIIllllIIllllllIlIIIll.lIIIIIllllIIIIlIlIIIIlIlI, iiIlIIllllIIllllllIlIIIll.IIIIIIlIlIlIllllllIlllIlI, 32, iiIlIIllllIIllllllIlIIIll.IIIIIIlIlIlIllllllIlllIlI - 64, 20);
        this.lIIIIlIIllIIlIIlIIIlIIllI = -1;
        this.IIIlllIIIllIllIlIIIIIIlII = -1;
        this.lIIIIlIIllIIlIIlIIIlIIllI(false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true, 20);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final boolean b, final int n2, final int n3) {
    }
    
    @Override
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return false;
    }
    
    @Override
    protected void IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIlIIllllIIllllllIlIIIll.lIllIllIlIIllIllIlIlIIlIl();
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final Tessellator tessellator) {
        if (!Mouse.isButtonDown(0)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = -1;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 0) {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 115 - 18, n2 + 1, 0, 0);
        }
        else {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 115 - 18, n2 + 1, 0, 18);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 1) {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 165 - 18, n2 + 1, 0, 0);
        }
        else {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 165 - 18, n2 + 1, 0, 18);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 2) {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 215 - 18, n2 + 1, 0, 0);
        }
        else {
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + 215 - 18, n2 + 1, 0, 18);
        }
        if (this.IIIlllIIIllIllIlIIIIIIlII != -1) {
            int n3 = 79;
            int n4 = 18;
            if (this.IIIlllIIIllIllIlIIIIIIlII == 1) {
                n3 = 129;
            }
            else if (this.IIIlllIIIllIllIlIIIIIIlII == 2) {
                n3 = 179;
            }
            if (this.llIlIIIlIIIIlIlllIlIIIIll == 1) {
                n4 = 36;
            }
            this.IIIlIIllllIIllllllIlIIIll.IlllIIIlIlllIllIlIIlllIlI(n + n3, n2 + 1, n4, 0);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = -1;
        if (n >= 79 && n < 115) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = 0;
        }
        else if (n >= 129 && n < 165) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = 1;
        }
        else if (n >= 179 && n < 215) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = 2;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI >= 0) {
            this.IIIllIllIlIlllllllIlIlIII(this.lIIIIlIIllIIlIIlIIIlIIllI);
            this.IIIlIIllllIIllllllIlIIIll.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
        }
    }
    
    @Override
    protected final int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.size();
    }
    
    protected final llIIllllIlllIlllIllIIllll lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.get(n);
    }
    
    protected abstract String IlllIIIlIlllIllIlIIlllIlI(final int p0);
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIlIlIlIIlIIllIIIIIllll liiIlIlIlIIlIIllIIIIIllll, final int n, final int n2, final boolean b) {
        if (liiIlIlIlIIlIIllIIIIIllll != null) {
            final String liiiIlIIllIIlIIlIIIlIIllI = liiIlIlIlIIlIIllIIIIIllll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIllllIIllllllIlIIIll.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(liiIlIlIlIIlIIllIIIIIllll));
            this.IIIlIIllllIIllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl, liiiIlIIllIIlIIlIIIlIIllI, n - this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.getStringWidth(liiiIlIIllIIlIIlIIIlIIllI), n2 + 5, b ? 16777215 : 9474192);
        }
        else {
            final String s = "-";
            this.IIIlIIllllIIllllllIlIIIll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl, s, n - this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.getStringWidth(s), n2 + 5, b ? 16777215 : 9474192);
        }
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        if (n2 >= this.IIIIllIlIIIllIlllIlllllIl && n2 <= this.IIIIllIIllIIIIllIllIIIlIl) {
            final int illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
            final int n3 = this.IlllIIIlIlllIllIlIIlllIlI / 2 - 92 - 16;
            if (illlIIIlIlllIllIlIIlllIlI >= 0) {
                if (n < n3 + 40 || n > n3 + 40 + 20) {
                    return;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl(illlIIIlIlllIllIlIIlllIlI), n, n2);
            }
            else {
                String s;
                if (n >= n3 + 115 - 18 && n <= n3 + 115) {
                    s = this.IlllIIIlIlllIllIlIIlllIlI(0);
                }
                else if (n >= n3 + 165 - 18 && n <= n3 + 165) {
                    s = this.IlllIIIlIlllIllIlIIlllIlI(1);
                }
                else {
                    if (n < n3 + 215 - 18 || n > n3 + 215) {
                        return;
                    }
                    s = this.IlllIIIlIlllIllIlIIlllIlI(2);
                }
                final String trim = ("" + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(s, new Object[0])).trim();
                if (trim.length() > 0) {
                    final int n4 = n + 12;
                    final int n5 = n2 - 12;
                    final int stringWidth = this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.getStringWidth(trim);
                    final IlIIIlllIIIlIlIlllIIlllII iiIlIIllllIIllllllIlIIIll = this.IIIlIIllllIIllllllIlIIIll;
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n4 - 3), (float)(n5 - 3), (float)(n4 + stringWidth + 3), (float)(n5 + 8 + 3), -1073741824, -1073741824);
                    this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.drawStringWithShadow(trim, (float)n4, (float)n5, -1);
                }
            }
        }
    }
    
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final llIIllllIlllIlllIllIIllll llIIllllIlllIlllIllIIllll, final int n, final int n2) {
        if (llIIllllIlllIlllIllIIllll != null) {
            final String trim = ("" + IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIIllllIlllIlllIllIIllll.lIIIIlIIllIIlIIlIIIlIIllI().IlllIllIlIIIIlIIlIIllIIIl() + ".name", new Object[0])).trim();
            if (trim.length() > 0) {
                final int n3 = n + 12;
                final int n4 = n2 - 12;
                final int stringWidth = this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.getStringWidth(trim);
                final IlIIIlllIIIlIlIlllIIlllII iiIlIIllllIIllllllIlIIIll = this.IIIlIIllllIIllllllIlIIIll;
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(n3 - 3), (float)(n4 - 3), (float)(n3 + stringWidth + 3), (float)(n4 + 8 + 3), -1073741824, -1073741824);
                this.IIIlIIllllIIllllllIlIIIll.lIIlllIIlIlllllllllIIIIIl.drawStringWithShadow(trim, (float)n3, (float)n4, -1);
            }
        }
    }
    
    protected void IIIllIllIlIlllllllIlIlIII(final int iiIlllIIIllIllIlIIIIIIlII) {
        if (iiIlllIIIllIllIlIIIIIIlII != this.IIIlllIIIllIllIlIIIIIIlII) {
            this.IIIlllIIIllIllIlIIIIIIlII = iiIlllIIIllIllIlIIIIIIlII;
            this.llIlIIIlIIIIlIlllIlIIIIll = -1;
        }
        else if (this.llIlIIIlIIIIlIlllIlIIIIll == -1) {
            this.llIlIIIlIIIIlIlllIlIIIIll = 1;
        }
        else {
            this.IIIlllIIIllIllIlIIIIIIlII = -1;
            this.llIlIIIlIIIIlIlllIlIIIIll = 0;
        }
        Collections.sort((List<Object>)this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIlIlIllIIlIIIlIIIlllIII);
    }
}
