import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveAction;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIllIIIIlllIlllIIIIII extends RecursiveAction
{
    private static final long lIIIIlIIllIIlIIlIIIlIIllI = 1L;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final Object[] IIIIllIlIIIllIlllIlllllIl;
    private final Object[] IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIlIllIIIIlllIlllIIIIII(final Object[] iiiIllIlIIIllIlllIlllllIl, final Object[] iiiIllIIllIIIIllIllIIIlIl, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    @Override
    protected void compute() {
        final Object[] iiiIllIlIIIllIlllIlllllIl = this.IIIIllIlIIIllIlllIlllllIl;
        final Object[] iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl;
        final int n = this.IlllIIIlIlllIllIlIIlllIlI - this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n < 8192) {
            IlIIlIlIlIIlllIIIllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI);
            return;
        }
        final int n2 = this.lIIIIIIIIIlIllIIllIlIIlIl + n / 2;
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        final int n3 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        final int n4 = n / 8;
        final int liiiIlIIllIIlIIlIIIlIIllI = IlllIIIlIlllIllIlIIlllIlI(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, IlllIIIlIlllIllIlIIlllIlI(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl + n4, liiiiiiiiIlIllIIllIlIIlIl + 2 * n4), IlllIIIlIlllIllIlIIlllIlI(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n2 - n4, n2, n2 + n4), IlllIIIlIlllIllIlIIlllIlI(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n3 - 2 * n4, n3 - n4, n3));
        final Object o = iiiIllIlIIIllIlllIlllllIl[liiiIlIIllIIlIIlIIIlIIllI];
        final Object o2 = iiiIllIIllIIIIllIllIIIlIl[liiiIlIIllIIlIIlIIIlIIllI];
        int liiiiiiiiIlIllIIllIlIIlIl2;
        int n5 = liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl;
        int n7;
        int n6 = n7 = this.IlllIIIlIlllIllIlIIlllIlI - 1;
        while (true) {
            final int compareTo;
            final int n8;
            if (liiiiiiiiIlIllIIllIlIIlIl2 <= n6 && (n8 = (((compareTo = ((Comparable)iiiIllIlIIIllIlllIlllllIl[liiiiiiiiIlIllIIllIlIIlIl2]).compareTo(o)) == 0) ? ((Comparable)iiiIllIIllIIIIllIllIIIlIl[liiiiiiiiIlIllIIllIlIIlIl2]).compareTo(o2) : compareTo)) <= 0) {
                if (n8 == 0) {
                    IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n5++, liiiiiiiiIlIllIIllIlIIlIl2);
                }
                ++liiiiiiiiIlIllIIllIlIIlIl2;
            }
            else {
                int compareTo2;
                int n9;
                while (n6 >= liiiiiiiiIlIllIIllIlIIlIl2 && (n9 = (((compareTo2 = ((Comparable)iiiIllIlIIIllIlllIlllllIl[n6]).compareTo(o)) == 0) ? ((Comparable)iiiIllIIllIIIIllIllIIIlIl[n6]).compareTo(o2) : compareTo2)) >= 0) {
                    if (n9 == 0) {
                        IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, n6, n7--);
                    }
                    --n6;
                }
                if (liiiiiiiiIlIllIIllIlIIlIl2 > n6) {
                    break;
                }
                IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl2++, n6--);
            }
        }
        final int min = Math.min(n5 - this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl2 - n5);
        IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl2 - min, min);
        final int min2 = Math.min(n7 - n6, this.IlllIIIlIlllIllIlIIlllIlI - n7 - 1);
        IIIIllIlIIIllIlllIlllllIl(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, liiiiiiiiIlIllIIllIlIIlIl2, this.IlllIIIlIlllIllIlIIlllIlI - min2, min2);
        final int n10 = liiiiiiiiIlIllIIllIlIIlIl2 - n5;
        final int n11 = n7 - n6;
        if (n10 > 1 && n11 > 1) {
            ForkJoinTask.invokeAll(new IIIIlIllIIIIlllIlllIIIIII(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n10), new IIIIlIllIIIIlllIlllIIIIII(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - n11, this.IlllIIIlIlllIllIlIIlllIlI));
        }
        else if (n10 > 1) {
            ForkJoinTask.invokeAll(new IIIIlIllIIIIlllIlllIIIIII(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.lIIIIIIIIIlIllIIllIlIIlIl + n10));
        }
        else {
            ForkJoinTask.invokeAll(new IIIIlIllIIIIlllIlllIIIIII(iiiIllIlIIIllIlllIlllllIl, iiiIllIIllIIIIllIllIIIlIl, this.IlllIIIlIlllIllIlIIlllIlI - n11, this.IlllIIIlIlllIllIlIIlllIlI));
        }
    }
}
