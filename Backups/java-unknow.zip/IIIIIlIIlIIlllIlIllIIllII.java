import java.util.Random;
import java.util.Iterator;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIIlIIlllIlIllIIllII extends IllIlIllIIIllllllIIIllIlI
{
    private List IIIIllIIllIIIIllIllIIIlIl;
    private boolean IlIlIIIlllIIIlIlllIlIllIl;
    private IlIlIlIIlIlIlIlllIlllIIII[] IIIllIllIlIlllllllIlIlIII;
    private double IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIIIIlIIlIIlllIlIllIIllII() {
        this.IIIllIllIlIlllllllIlIlIII = new IlIlIlIIlIlIlIlllIlllIIII[3];
        this.IllIIIIIIIlIlIllllIIllIII = 32;
        this.lIIIIllIIlIlIllIIIlIllIlI = 3;
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        for (final IIlIIlIIllIIllIlIIIIIIIlI ilIIlIIllIIllIlIIIIIIIlI : IIlIIlIIllIIllIlIIIIIIIlI.IIIlllIIIllIllIlIIIIIIlII()) {
            if (ilIIlIIllIIllIlIIIIIIIlI != null && ilIIlIIllIIllIlIIIIIIIlI.IIlIlllIllIlIlIIIIIlllIll > 0.0f) {
                this.IIIIllIIllIIIIllIllIIIlIl.add(ilIIlIIllIIllIlIIIIIIIlI);
            }
        }
    }
    
    public IIIIIlIIlIIlllIlIllIIllII(final Map map) {
        this();
        for (final Map.Entry<String, V> entry : map.entrySet()) {
            if (entry.getKey().equals("distance")) {
                this.IllIIIIIIIlIlIllllIIllIII = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((String)entry.getValue(), this.IllIIIIIIIlIlIllllIIllIII, 1.0);
            }
            else if (entry.getKey().equals("count")) {
                this.IIIllIllIlIlllllllIlIlIII = new IlIlIlIIlIlIlIlllIlllIIII[MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((String)entry.getValue(), this.IIIllIllIlIlllllllIlIlIII.length, 1)];
            }
            else {
                if (!entry.getKey().equals("spread")) {
                    continue;
                }
                this.lIIIIllIIlIlIllIIIlIllIlI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI((String)entry.getValue(), this.lIIIIllIIlIlIllIIIlIllIlI, 1);
            }
        }
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "Stronghold";
    }
    
    @Override
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (!this.IlIlIIIlllIIIlIlllIlIllIl) {
            final Random random = new Random();
            random.setSeed(this.IlllIIIlIlllIllIlIIlllIlI.IllIllIIIlIIlllIIIllIllII());
            double n3 = random.nextDouble() * (2.307692289352417 * 1.361356827374669) * 2;
            int n4 = 1;
            for (int i = 0; i < this.IIIllIllIlIlllllllIlIlIII.length; ++i) {
                final double n5 = (5.833333275384374 * 0.2142857164144516 * n4 + random.nextDouble()) * this.IllIIIIIIIlIlIllllIIllIII * n4;
                int n6 = (int)Math.round(Math.cos(n3) * n5);
                int n7 = (int)Math.round(Math.sin(n3) * n5);
                final IIlIlIlIlIlIlllIIlIllIIlI liiiIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIllIIlIlIllIIIlIllIlI().lIIIIlIIllIIlIIlIIIlIIllI((n6 << 4) + 8, (n7 << 4) + 8, 112, this.IIIIllIIllIIIIllIllIIIlIl, random);
                if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                    n6 = liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI >> 4;
                    n7 = liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI >> 4;
                }
                this.IIIllIllIlIlllllllIlIlIII[i] = new IlIlIlIIlIlIlIlllIlllIIII(n6, n7);
                n3 += 1.3333333730697632 * 4.712388839944558 * n4 / this.lIIIIllIIlIlIllIIIlIllIlI;
                if (i == this.lIIIIllIIlIlIllIIIlIllIlI) {
                    n4 += 2 + random.nextInt(5);
                    this.lIIIIllIIlIlIllIIIlIllIlI += 1 + random.nextInt(2);
                }
            }
            this.IlIlIIIlllIIIlIlllIlIllIl = true;
        }
        for (final IlIlIlIIlIlIlIlllIlllIIII ilIlIlIIlIlIlIlllIlllIIII : this.IIIllIllIlIlllllllIlIlIII) {
            if (n == ilIlIlIIlIlIlIlllIlllIIII.lIIIIlIIllIIlIIlIIIlIIllI && n2 == ilIlIlIIlIlIlIlllIlllIIII.lIIIIIIIIIlIllIIllIlIIlIl) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    protected List lIIIIIIIIIlIllIIllIlIIlIl() {
        final ArrayList<IIlIlIlIlIlIlllIIlIllIIlI> list = new ArrayList<IIlIlIlIlIlIlllIIlIllIIlI>();
        for (final IlIlIlIIlIlIlIlllIlllIIII ilIlIlIIlIlIlIlllIlllIIII : this.IIIllIllIlIlllllllIlIlIII) {
            if (ilIlIlIIlIlIlIlllIlllIIII != null) {
                list.add(ilIlIlIIlIlIlIlllIlllIIII.lIIIIlIIllIIlIIlIIIlIIllI(64));
            }
        }
        return list;
    }
    
    @Override
    protected IllllIlllIlIlIlllIIIlIlll lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        lIlIlIIllIIlIIllllIlIIlIl lIlIlIIllIIlIIllllIlIIlIl;
        for (lIlIlIIllIIlIIllllIlIIlIl = new lIlIlIIllIIlIIllllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl, n, n2); lIlIlIIllIIlIIllllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI().isEmpty() || ((IlIIlllllllIIIIllIlIllIII)lIlIlIIllIIlIIllllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI().get(0)).lIIIIIIIIIlIllIIllIlIIlIl == null; lIlIlIIllIIlIIllllIlIIlIl = new lIlIlIIllIIlIIllllIlIIlIl(this.IlllIIIlIlllIllIlIIlllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl, n, n2)) {}
        return lIlIlIIllIIlIIllllIlIIlIl;
    }
}
