import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class GuiInventory extends llIlIIllIIlIlllIIlIlIIllI
{
    private float lIIIIlIIllIIlIIlIIIlIIllI;
    private float lIIIIIIIIIlIllIIllIlIIlIl;
    
    public GuiInventory(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        super(lIllIIIIlIIlIllIIIlIlIlll.llIlIIIlIIIIlIlllIlIIIIll);
        this.lIIlIIllIIIIIlIllIIIIllII = true;
    }
    
    @Override
    public void updateScreen() {
        if (this.lllIIIIIlIllIlIIIllllllII.playerController.IllIIIIIIIlIlIllllIIllIII()) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IllIlllllIllIIIlIlIIlIlIl(this.lllIIIIIlIllIlIIIllllllII.thePlayer));
        }
    }
    
    @Override
    public void s_() {
        this.IllIllIIIlIIlllIIIllIllII.clear();
        if (this.lllIIIIIlIllIlIIIllllllII.playerController.IllIIIIIIIlIlIllllIIllIII()) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IllIlllllIllIIIlIlIIlIlIl(this.lllIIIIIlIllIlIIIllllllII.thePlayer));
        }
        else {
            super.s_();
        }
    }
    
    @Override
    protected void resize(final int n, final int n2) {
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("container.crafting", new Object[0]), 86, 16, 4210752);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI = (float)n;
        this.lIIIIIIIIIlIllIIllIlIIlIl = (float)n2;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final float n, final int n2, final int n3) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(GuiInventory.lIIIIllIIlIlIllIIIlIllIlI);
        final int iiIlIIlIlIIIlllIIlIllllll = this.IIIlIIlIlIIIlllIIlIllllll;
        final int illIlIIIIlllIIllIIlllIIlI = this.IllIlIIIIlllIIllIIlllIIlI;
        IlIIIlIIlIIllIllllIlIlIll.scaledTessellator(iiIlIIlIlIIIlllIIlIllllll, illIlIIIIlllIIllIIlllIIlI, 0, 0, this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl);
        lIIIIlIIllIIlIIlIIIlIIllI(iiIlIIlIlIIIlllIIlIllllll + 51, illIlIIIIlllIIllIIlllIIlI + 75, 30, iiIlIIlIlIIIlllIIlIllllll + 51 - this.lIIIIlIIllIIlIIlIIIlIIllI, illIlIIIIlllIIllIIlllIIlI + 75 - 50 - this.lIIIIIIIIIlIllIIllIlIIlIl, this.lllIIIIIlIllIlIIIllllllII.thePlayer);
    }
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final float n4, final float n5, final EntityLivingBase entityLivingBase) {
        GL11.glEnable(2903);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)n, (float)n2, (float)50);
        GL11.glScalef((float)(-n3), (float)n3, (float)n3);
        GL11.glRotatef((float)180, 0.0f, 0.0f, 1.0f);
        final float liiIlIlIIllIIlllIIIlIIllI = entityLivingBase.lIIIlIlIIllIIlllIIIlIIllI;
        final float illllIllllIlIIIlIIIllllll = entityLivingBase.IllllIllllIlIIIlIIIllllll;
        final float illIIlllIllIlIllIlIIIIIII = entityLivingBase.IllIIlllIllIlIllIlIIIIIII;
        final float ilIlIIIIIllIlIlIIllIlIIIl = entityLivingBase.IlIlIIIIIllIlIlIIllIlIIIl;
        final float iiIlllIllIlIIllIIllIlIlll = entityLivingBase.IIIlllIllIlIIllIIllIlIlll;
        GL11.glRotatef((float)135, 0.0f, 1.0f, 0.0f);
        llIlIlllllIIllIIIIllIllII.lIIIIIIIIIlIllIIllIlIIlIl();
        GL11.glRotatef((float)(-135), 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-(float)Math.atan(n5 / 40) * 20, 1.0f, 0.0f, 0.0f);
        entityLivingBase.lIIIlIlIIllIIlllIIIlIIllI = (float)Math.atan(n4 / 40) * 20;
        entityLivingBase.IllllIllllIlIIIlIIIllllll = (float)Math.atan(n4 / 40) * 40;
        entityLivingBase.IllIIlllIllIlIllIlIIIIIII = -(float)Math.atan(n5 / 40) * 20;
        entityLivingBase.IIIlllIllIlIIllIIllIlIlll = entityLivingBase.IllllIllllIlIIIlIIIllllll;
        entityLivingBase.IlIlIIIIIllIlIlIIllIlIIIl = entityLivingBase.IllllIllllIlIIIlIIIllllll;
        GL11.glTranslatef(0.0f, entityLivingBase.lIlIllIlIlIIIllllIlIllIll, 0.0f);
        RenderManager.instance.IlllIllIlIIIIlIIlIIllIIIl = 180;
        RenderManager.instance.lIIIIlIIllIIlIIlIIIlIIllI(entityLivingBase, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        entityLivingBase.lIIIlIlIIllIIlllIIIlIIllI = liiIlIlIIllIIlllIIIlIIllI;
        entityLivingBase.IllllIllllIlIIIlIIIllllll = illllIllllIlIIIlIIIllllll;
        entityLivingBase.IllIIlllIllIlIllIlIIIIIII = illIIlllIllIlIllIlIIIIIII;
        entityLivingBase.IlIlIIIIIllIlIlIIllIlIIIl = ilIlIIIIIllIlIlIIllIlIIIl;
        entityLivingBase.IIIlllIllIlIIllIIllIlIlll = iiIlllIllIlIIllIIllIlIlll;
        GL11.glPopMatrix();
        llIlIlllllIIllIIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI();
        GL11.glDisable(32826);
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI);
        GL11.glDisable(3553);
        OpenGlHelper.IlllIllIlIIIIlIIlIIllIIIl(OpenGlHelper.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 0) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlllIIIIllIlIIIlllIIIIllI(this, this.lllIIIIIlIllIlIIIllllllII.thePlayer.IIIlIIlIlIIIlllIIlIllllll()));
        }
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 1) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlIIIlllIIIlIlIlllIIlllII(this, this.lllIIIIIlIllIlIIIllllllII.thePlayer.IIIlIIlIlIIIlllIIlIllllll()));
        }
    }
}
