import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.concurrent.ConcurrentHashMap;

// 
// Decompiled by Procyon v0.5.36
// 

public class CBEventBus
{
    private final ConcurrentHashMap<Class<? extends CBEvent>, CopyOnWriteArrayList<Consumer<? extends CBEvent>>> map;
    
    public CBEventBus() {
        this.map = new ConcurrentHashMap<>();
    }
    
    public boolean addEvent(final Class<? extends CBEvent> key, final Consumer<? extends CBEvent> e) {
        return this.map.computeIfAbsent(key, p0 -> new CopyOnWriteArrayList<>()).add(e);
    }
    
    public boolean removeEvent(final Class<? extends CBEvent> key, final Consumer<? extends CBEvent> o) {
        final CopyOnWriteArrayList<Consumer<? extends CBEvent>> list = this.map.get(key);
        return list != null && list.remove(o);
    }
    
    public void callEvent(final CBEvent cbEvent) {
        try {
            for (Serializable key = cbEvent.getClass(); key != null && key != CBEvent.class; key = ((Class<CBEvent>)key).getSuperclass()) {
                final CopyOnWriteArrayList<Consumer<? extends CBEvent>> list = this.map.get(key);
                if (list != null) {
                    list.forEach(consumer -> consumer.accept(cbEvent));
                }
            }
        }
        catch (Exception ex) {
            System.out.println("EventBus [" + cbEvent.getClass() + "]");
            ex.printStackTrace();
        }
    }
}
