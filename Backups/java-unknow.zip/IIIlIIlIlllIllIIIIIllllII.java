import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlIlllIllIIIIIllllII extends lllllIIIIllIIlIlIlIIllllI
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    private boolean IllIIIIIIIlIlIllllIIllIII;
    
    public IIIlIIlIlllIllIIIIIllllII() {
    }
    
    public IIIlIIlIlllIllIIIIIllllII(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIlIIIllIlllIlllllIl = this.lIIIIlIIllIIlIIlIIIlIIllI(random);
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = random.nextBoolean();
        this.lIIIIIIIIIlIllIIllIlIIlIl = random.nextBoolean();
        this.IlllIIIlIlllIllIlIIlllIlI = random.nextBoolean();
        this.IllIIIIIIIlIlIllllIIllIII = (random.nextInt(3) > 0);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("leftLow", this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("leftHigh", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("rightLow", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("rightHigh", this.IllIIIIIIIlIlIllllIIllIII);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("leftLow");
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("leftHigh");
        this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("rightLow");
        this.IllIIIIIIIlIlIllllIIllIII = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("rightHigh");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        int n = 3;
        int n2 = 5;
        if (this.IlIlIIIlllIIIlIlllIlIllIl == 1 || this.IlIlIIIlllIIIlIlllIlIllIl == 2) {
            n = 8 - n;
            n2 = 8 - n2;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, 5, 1);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
            this.lIIIIIIIIIlIllIIllIlIIlIl((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, n, 1);
        }
        if (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.lIIIIIIIIIlIllIIllIlIIlIl((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, n2, 7);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI) {
            this.IlllIIIlIlllIllIlIIlllIlI((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, n, 1);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII) {
            this.IlllIIIlIlllIllIlIIlllIlI((IlIIlllllllIIIIllIlIllIII)lllIlIlllIlIIllllllIIIlll, list, random, n2, 7);
        }
    }
    
    public static IIIlIIlIlllIllIIIIIllllII lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, -4, -3, 0, 10, 9, 11, n4);
        return (lllllIIIIllIIlIlIlIIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI) && lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) ? new IIIlIIlIlllIllIIIIIllllII(n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4) : null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl)) {
            return false;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 9, 8, 10, true, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, random, iiIllllIIllllIIIIIlllllIl, this.IIIIllIlIIIllIlllIlllllIl, 4, 3, 0);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 3, 1, 0, 5, 3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        if (this.IlllIIIlIlllIllIlIIlllIlI) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 3, 1, 9, 5, 3, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        if (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 5, 7, 0, 7, 9, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 9, 5, 7, 9, 7, 9, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 1, 10, 7, 3, 10, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 2, 1, 8, 2, 6, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 1, 5, 4, 4, 9, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 1, 5, 8, 4, 9, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 4, 7, 3, 4, 9, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 3, 5, 3, 3, 6, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 3, 4, 3, 3, 4, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 1, 4, 6, 3, 4, 6, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 1, 7, 7, 1, 8, false, random, lIIIllIllIlIlIIIIIlIIlllI.IIIIllIIllIIIIllIllIIIlIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 1, 9, 7, 1, 9, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 2, 7, 7, 2, 7, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 4, 5, 7, 4, 5, 9, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 8, 5, 7, 8, 5, 9, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, IllllllIllIIlllIllIIlIIll.IlIIlIIlIllIIIIllIIllIlIl, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 5, 5, 7, 7, 5, 9, IllllllIllIIlllIllIIlIIll.lIlIllIlIlIIIllllIlIllIll, IllllllIllIIlllIllIIlIIll.lIlIllIlIlIIIllllIlIllIll, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0, 6, 5, 6, iiIllllIIllllIIIIIlllllIl);
        return true;
    }
}
