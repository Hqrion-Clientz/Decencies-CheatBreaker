import java.util.UUID;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlIllIlIIllIIlIlIIII extends IlllIlIIIIlllIlIIIlIIIIII
{
    private final int lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIIIlIlIllIlIIllIIlIlIIII(final GameProfile gameProfile, final int liiiIlIIllIIlIIlIIIlIIllI) {
        super(gameProfile);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public IIIIlIlIllIlIIllIIlIlIIII(final JsonObject jsonObject) {
        super(lIIIIIIIIIlIllIIllIlIIlIl(jsonObject), jsonObject);
        this.lIIIIlIIllIIlIIlIIIlIIllI = (jsonObject.has("level") ? jsonObject.get("level").getAsInt() : 0);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final JsonObject jsonObject) {
        if (this.IIIIllIlIIIllIlllIlllllIl() != null) {
            jsonObject.addProperty("uuid", (((GameProfile)this.IIIIllIlIIIllIlllIlllllIl()).getId() == null) ? "" : ((GameProfile)this.IIIIllIlIIIllIlllIlllllIl()).getId().toString());
            jsonObject.addProperty("name", ((GameProfile)this.IIIIllIlIIIllIlllIlllllIl()).getName());
            super.lIIIIlIIllIIlIIlIIIlIIllI(jsonObject);
            jsonObject.addProperty("level", (Number)this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
    }
    
    private static GameProfile lIIIIIIIIIlIllIIllIlIIlIl(final JsonObject jsonObject) {
        if (jsonObject.has("uuid") && jsonObject.has("name")) {
            final String asString = jsonObject.get("uuid").getAsString();
            UUID fromString;
            try {
                fromString = UUID.fromString(asString);
            }
            catch (Throwable t) {
                return null;
            }
            return new GameProfile(fromString, jsonObject.get("name").getAsString());
        }
        return null;
    }
}
