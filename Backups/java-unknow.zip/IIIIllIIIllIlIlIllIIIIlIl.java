import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIIllIlIlIllIIIIlIl extends lllllIlIllIlIlIllIIIIIIIl
{
    public IIIIllIIIllIlIlIllIIIIlIl() {
    }
    
    public IIIIllIIIllIlIlIllIIIIlIl(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(llIllllIIIIIIIlllIIIIlIlI, n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public static IIIllllIIllllIIIIIlllllIl lIIIIlIIllIIlIIlIIIlIIllI(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final List list, final Random random, final int n, final int n2, final int n3, final int n4) {
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0, 0, 0, 3, 4, 2, n4);
        return (lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) != null) ? null : liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        if (this.IlIlllIIIIllIllllIllIIlIl < 0) {
            this.IlIlllIIIIllIllllIllIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl);
            if (this.IlIlllIIIIllIllllIllIIlIl < 0) {
                return true;
            }
            this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(0, this.IlIlllIIIIllIllllIllIIlIl - this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIIllIIIIllIllIIIlIl + 4 - 1, 0);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 2, 3, 1, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII, 0, 1, 0, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII, 0, 1, 1, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII, 0, 1, 2, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIIIIlllIIlIlllllIlIllIII, 15, 1, 3, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0, 0, 3, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0, 1, 3, 1, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0, 2, 3, 0, iiIllllIIllllIIIIIlllllIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0, 1, 3, -1, iiIllllIIllllIIIIIlllllIl);
        return true;
    }
}
