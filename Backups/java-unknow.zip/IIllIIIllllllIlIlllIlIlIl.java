import io.netty.channel.ChannelHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelOption;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;

// 
// Decompiled by Procyon v0.5.36
// 

class IIllIIIllllllIlIlllIlIlIl extends ChannelInitializer
{
    final /* synthetic */ llIllIIIIlIlIIIIlIIlIllIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIllIIIllllllIlIlllIlIlIl(final llIllIIIIlIlIIIIlIIlIllIl liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    protected void initChannel(final Channel channel) {
        try {
            channel.config().setOption(ChannelOption.IP_TOS, (Object)24);
        }
        catch (ChannelException ex) {}
        try {
            channel.config().setOption(ChannelOption.TCP_NODELAY, (Object)false);
        }
        catch (ChannelException ex2) {}
        channel.pipeline().addLast("timeout", (ChannelHandler)new ReadTimeoutHandler(30)).addLast("legacy_query", (ChannelHandler)new lllllIllIlllIIlIIllIIIlll(this.lIIIIlIIllIIlIIlIIIlIIllI)).addLast("splitter", (ChannelHandler)new lIlIlIlIllllIIIIIlllIIIII()).addLast("decoder", (ChannelHandler)new lIIlIIIlIlllIIIlIIlIlllll(NetworkManager.IllIIIIIIIlIlIllllIIllIII)).addLast("prepender", (ChannelHandler)new IlllIlIIIlIllIllIIIIlIlII()).addLast("encoder", (ChannelHandler)new IIlllIIIIllIIllllIIIlIlll(NetworkManager.IllIIIIIIIlIlIllllIIllIII));
        final NetworkManager networkManager = new NetworkManager(false);
        this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.add(networkManager);
        channel.pipeline().addLast("packet_handler", (ChannelHandler)networkManager);
        networkManager.lIIIIlIIllIIlIIlIIIlIIllI(new llIlIIIllIlIIlIIlIIlIIIII(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl, networkManager));
    }
}
