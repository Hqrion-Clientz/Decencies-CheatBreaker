import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIllIIlIlIlIIlIlIlIllI extends IlIIIlIIlIIllIllllIlIlIll
{
    private final FontRenderer lIIIIlIIllIIlIIlIIIlIIllI;
    private final int lIIIIIIIIIlIllIIllIlIIlIl;
    private final int IlllIIIlIlllIllIlIIlllIlI;
    private final int IIIIllIlIIIllIlllIlllllIl;
    private final int IIIIllIIllIIIIllIllIIIlIl;
    private String IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    private boolean IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    private boolean IIIlIIllllIIllllllIlIIIll;
    private int lllIIIIIlIllIlIIIllllllII;
    private int lIIIIIllllIIIIlIlIIIIlIlI;
    private int IIIIIIlIlIlIllllllIlllIlI;
    private int IllIllIIIlIIlllIIIllIllII;
    private int IlIIlIIIIlIIIIllllIIlIllI;
    private boolean lIIlIIllIIIIIlIllIIIIllII;
    
    public IIIIIllIIlIlIlIIlIlIlIllI(final FontRenderer liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final int iiiIllIIllIIIIllIllIIIlIl) {
        this.IlIlIIIlllIIIlIlllIlIllIl = "";
        this.IIIllIllIlIlllllllIlIlIII = 32;
        this.lIIIIllIIlIlIllIIIlIllIlI = true;
        this.IlllIllIlIIIIlIIlIIllIIIl = true;
        this.IIIlIIllllIIllllllIlIIIll = true;
        this.IllIllIIIlIIlllIIIllIllII = 14737632;
        this.IlIIlIIIIlIIIIllllIIlIllI = 7368816;
        this.lIIlIIllIIIIIlIllIIIIllII = true;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
    }
    
    public void updateTick() {
        ++this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public void setSection(final String ilIlIIIlllIIIlIlllIlIllIl) {
        if (ilIlIIIlllIIIlIlllIlIllIl.length() > this.IIIllIllIlIlllllllIlIlIII) {
            this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl.substring(0, this.IIIllIllIlIlllllllIlIlIII);
        }
        else {
            this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        }
        this.refreshResources();
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlIlIIIlllIIIlIlllIlIllIl.substring((this.lIIIIIllllIIIIlIlIIIIlIlI < this.IIIIIIlIlIlIllllllIlllIlI) ? this.lIIIIIllllIIIIlIlIIIIlIlI : this.IIIIIIlIlIlIllllllIlllIlI, (this.lIIIIIllllIIIIlIlIIIIlIlI < this.IIIIIIlIlIlIllllllIlllIlI) ? this.IIIIIIlIlIlIllllllIlllIlI : this.lIIIIIllllIIIIlIlIIIIlIlI);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        String string = "";
        final String liiiIlIIllIIlIIlIIIlIIllI = IIlllIllIlIllIllIIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(s);
        final int endIndex = (this.lIIIIIllllIIIIlIlIIIIlIlI < this.IIIIIIlIlIlIllllllIlllIlI) ? this.lIIIIIllllIIIIlIlIIIIlIlI : this.IIIIIIlIlIlIllllllIlllIlI;
        final int beginIndex = (this.lIIIIIllllIIIIlIlIIIIlIlI < this.IIIIIIlIlIlIllllllIlllIlI) ? this.IIIIIIlIlIlIllllllIlllIlI : this.lIIIIIllllIIIIlIlIIIIlIlI;
        final int endIndex2 = this.IIIllIllIlIlllllllIlIlIII - this.IlIlIIIlllIIIlIlllIlIllIl.length() - (endIndex - this.IIIIIIlIlIlIllllllIlllIlI);
        if (this.IlIlIIIlllIIIlIlllIlIllIl.length() > 0) {
            string += this.IlIlIIIlllIIIlIlllIlIllIl.substring(0, endIndex);
        }
        String s2;
        int length;
        if (endIndex2 < liiiIlIIllIIlIIlIIIlIIllI.length()) {
            s2 = string + liiiIlIIllIIlIIlIIIlIIllI.substring(0, endIndex2);
            length = endIndex2;
        }
        else {
            s2 = string + liiiIlIIllIIlIIlIIIlIIllI;
            length = liiiIlIIllIIlIIlIIIlIIllI.length();
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl.length() > 0 && beginIndex < this.IlIlIIIlllIIIlIlllIlIllIl.length()) {
            s2 += this.IlIlIIIlllIIIlIlllIlIllIl.substring(beginIndex);
        }
        this.IlIlIIIlllIIIlIlllIlIllIl = s2;
        this.IIIIllIlIIIllIlllIlllllIl(endIndex - this.IIIIIIlIlIlIllllllIlllIlI + length);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl.length() != 0) {
            if (this.IIIIIIlIlIlIllllllIlllIlI != this.lIIIIIllllIIIIlIlIIIIlIlI) {
                this.lIIIIIIIIIlIllIIllIlIIlIl("");
            }
            else {
                this.updateDebugProfilerName(this.IlllIIIlIlllIllIlIIlllIlI(n) - this.lIIIIIllllIIIIlIlIIIIlIlI);
            }
        }
    }
    
    public void updateDebugProfilerName(final int n) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl.length() != 0) {
            if (this.IIIIIIlIlIlIllllllIlllIlI != this.lIIIIIllllIIIIlIlIIIIlIlI) {
                this.lIIIIIIIIIlIllIIllIlIIlIl("");
            }
            else {
                final boolean b = n < 0;
                final int endIndex = b ? (this.lIIIIIllllIIIIlIlIIIIlIlI + n) : this.lIIIIIllllIIIIlIlIIIIlIlI;
                final int beginIndex = b ? this.lIIIIIllllIIIIlIlIIIIlIlI : (this.lIIIIIllllIIIIlIlIIIIlIlI + n);
                String s = "";
                if (endIndex >= 0) {
                    s = this.IlIlIIIlllIIIlIlllIlIllIl.substring(0, endIndex);
                }
                if (beginIndex < this.IlIlIIIlllIIIlIlllIlIllIl.length()) {
                    s += this.IlIlIIIlllIIIlIlllIlIllIl.substring(beginIndex);
                }
                this.IlIlIIIlllIIIlIlllIlIllIl = s;
                if (b) {
                    this.IIIIllIlIIIllIlllIlllllIl(n);
                }
            }
        }
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, this.IllIIIIIIIlIlIllllIIllIII());
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(n, this.IllIIIIIIIlIlIllllIIllIII(), true);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final int a, final int n, final boolean b) {
        int index = n;
        final boolean b2 = a < 0;
        for (int abs = Math.abs(a), i = 0; i < abs; ++i) {
            if (b2) {
                while (b && index > 0 && this.IlIlIIIlllIIIlIlllIlIllIl.charAt(index - 1) == ' ') {
                    --index;
                }
                while (index > 0 && this.IlIlIIIlllIIIlIlllIlIllIl.charAt(index - 1) != ' ') {
                    --index;
                }
            }
            else {
                final int length = this.IlIlIIIlllIIIlIlllIlIllIl.length();
                index = this.IlIlIIIlllIIIlIlllIlIllIl.indexOf(32, index);
                if (index == -1) {
                    index = length;
                }
                else {
                    while (b && index < length && this.IlIlIIIlllIIIlIlllIlIllIl.charAt(index) == ' ') {
                        ++index;
                    }
                }
            }
        }
        return index;
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final int n) {
        this.IIIIllIIllIIIIllIllIIIlIl(this.IIIIIIlIlIlIllllllIlllIlI + n);
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final int liiiiIllllIIIIlIlIIIIlIlI) {
        this.lIIIIIllllIIIIlIlIIIIlIlI = liiiiIllllIIIIlIlIIIIlIlI;
        final int length = this.IlIlIIIlllIIIlIlllIlIllIl.length();
        if (this.lIIIIIllllIIIIlIlIIIIlIlI < 0) {
            this.lIIIIIllllIIIIlIlIIIIlIlI = 0;
        }
        if (this.lIIIIIllllIIIIlIlIIIIlIlI > length) {
            this.lIIIIIllllIIIIlIlIIIIlIlI = length;
        }
        this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIIllllIIIIlIlIIIIlIlI);
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        this.IIIIllIIllIIIIllIllIIIlIl(0);
    }
    
    public void refreshResources() {
        this.IIIIllIIllIIIIllIllIIIlIl(this.IlIlIIIlllIIIlIlllIlIllIl.length());
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        if (!this.IlIlllIIIIllIllllIllIIlIl) {
            return false;
        }
        switch (c) {
            case '\u0001': {
                this.refreshResources();
                this.lIIIIllIIlIlIllIIIlIllIlI(0);
                return true;
            }
            case '\u0003': {
                GuiScreen.IlllIIIlIlllIllIlIIlllIlI(this.IlllIIIlIlllIllIlIIlllIlI());
                return true;
            }
            case '\u0016': {
                if (this.IIIlIIllllIIllllllIlIIIll) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(GuiScreen.IIIIIIlIlIlIllllllIlllIlI());
                }
                return true;
            }
            case '\u0018': {
                GuiScreen.IlllIIIlIlllIllIlIIlllIlI(this.IlllIIIlIlllIllIlIIlllIlI());
                if (this.IIIlIIllllIIllllllIlIIIll) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl("");
                }
                return true;
            }
            default: {
                switch (n) {
                    case 14: {
                        if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            if (this.IIIlIIllllIIllllllIlIIIll) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(-1);
                            }
                        }
                        else if (this.IIIlIIllllIIllllllIlIIIll) {
                            this.updateDebugProfilerName(-1);
                        }
                        return true;
                    }
                    case 199: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            this.lIIIIllIIlIlIllIIIlIllIlI(0);
                        }
                        else {
                            this.IIIIllIlIIIllIlllIlllllIl();
                        }
                        return true;
                    }
                    case 203: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI(-1, this.IlIlllIIIIllIllllIllIIlIl()));
                            }
                            else {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.IlIlllIIIIllIllllIllIIlIl() - 1);
                            }
                        }
                        else if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            this.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(-1));
                        }
                        else {
                            this.IIIIllIlIIIllIlllIlllllIl(-1);
                        }
                        return true;
                    }
                    case 205: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI(1, this.IlIlllIIIIllIllllIllIIlIl()));
                            }
                            else {
                                this.lIIIIllIIlIlIllIIIlIllIlI(this.IlIlllIIIIllIllllIllIIlIl() + 1);
                            }
                        }
                        else if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            this.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIIlIlllIllIlIIlllIlI(1));
                        }
                        else {
                            this.IIIIllIlIIIllIlllIlllllIl(1);
                        }
                        return true;
                    }
                    case 207: {
                        if (GuiScreen.lIllIlIlllIIlIIllIIlIIlII()) {
                            this.lIIIIllIIlIlIllIIIlIllIlI(this.IlIlIIIlllIIIlIlllIlIllIl.length());
                        }
                        else {
                            this.refreshResources();
                        }
                        return true;
                    }
                    case 211: {
                        if (GuiScreen.llIlIIIllIIIIlllIlIIIIIlI()) {
                            if (this.IIIlIIllllIIllllllIlIIIll) {
                                this.lIIIIlIIllIIlIIlIIIlIIllI(1);
                            }
                        }
                        else if (this.IIIlIIllllIIllllllIlIIIll) {
                            this.updateDebugProfilerName(1);
                        }
                        return true;
                    }
                    default: {
                        if (IIlllIllIlIllIllIIllIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(c)) {
                            if (this.IIIlIIllllIIllllllIlIIIll) {
                                this.lIIIIIIIIIlIllIIllIlIIlIl(Character.toString(c));
                            }
                            return true;
                        }
                        return false;
                    }
                }
                break;
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        final boolean b = n >= this.lIIIIIIIIIlIllIIllIlIIlIl && n < this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl && n2 >= this.IlllIIIlIlllIllIlIIlllIlI && n2 < this.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl;
        if (this.IlllIllIlIIIIlIIlIIllIIIl) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(b);
        }
        if (this.IlIlllIIIIllIllllIllIIlIl && n3 == 0) {
            int n4 = n - this.lIIIIIIIIIlIllIIllIlIIlIl;
            if (this.lIIIIllIIlIlIllIIIlIllIlI) {
                n4 -= 4;
            }
            this.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl.substring(this.lllIIIIIlIllIlIIIllllllII), this.llIIlllIIIIlllIllIlIlllIl()), n4).length() + this.lllIIIIIlIllIlIIIllllllII);
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        if (this.lIIlIlIllIIlIIIlIIIlllIII()) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI()) {
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.lIIIIIIIIIlIllIIllIlIIlIl - 1), (float)(this.IlllIIIlIlllIllIlIIlllIlI - 1), (float)(this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl + 1), (float)(this.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl + 1), -6250336);
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)this.lIIIIIIIIIlIllIIllIlIIlIl, (float)this.IlllIIIlIlllIllIlIIlllIlI, (float)(this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl), (float)(this.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl), -16777216);
            }
            final int n = this.IIIlIIllllIIllllllIlIIIll ? this.IllIllIIIlIIlllIIIllIllII : this.IlIIlIIIIlIIIIllllIIlIllI;
            final int n2 = this.lIIIIIllllIIIIlIlIIIIlIlI - this.lllIIIIIlIllIlIIIllllllII;
            int length = this.IIIIIIlIlIlIllllllIlllIlI - this.lllIIIIIlIllIlIIIllllllII;
            final String liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl.substring(this.lllIIIIIlIllIlIIIllllllII), this.llIIlllIIIIlllIllIlIlllIl());
            final boolean b = n2 >= 0 && n2 <= liiiIlIIllIIlIIlIIIlIIllI.length();
            final boolean b2 = this.IlIlllIIIIllIllllIllIIlIl && this.IllIIIIIIIlIlIllllIIllIII / 6 % 2 == 0 && b;
            final int n3 = this.lIIIIllIIlIlIllIIIlIllIlI ? (this.lIIIIIIIIIlIllIIllIlIIlIl + 4) : this.lIIIIIIIIIlIllIIllIlIIlIl;
            final int n4 = this.lIIIIllIIlIlIllIIIlIllIlI ? (this.IlllIIIlIlllIllIlIIlllIlI + (this.IIIIllIIllIIIIllIllIIIlIl - 8) / 2) : this.IlllIIIlIlllIllIlIIlllIlI;
            int drawStringWithShadow = n3;
            if (length > liiiIlIIllIIlIIlIIIlIIllI.length()) {
                length = liiiIlIIllIIlIIlIIIlIIllI.length();
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.length() > 0) {
                drawStringWithShadow = this.lIIIIlIIllIIlIIlIIIlIIllI.drawStringWithShadow(b ? liiiIlIIllIIlIIlIIIlIIllI.substring(0, n2) : liiiIlIIllIIlIIlIIIlIIllI, (float)n3, (float)n4, n);
            }
            final boolean b3 = this.lIIIIIllllIIIIlIlIIIIlIlI < this.IlIlIIIlllIIIlIlllIlIllIl.length() || this.IlIlIIIlllIIIlIlllIlIllIl.length() >= this.IIIllIllIlIlllllllIlIlIII();
            int n5 = drawStringWithShadow;
            if (!b) {
                n5 = ((n2 > 0) ? (n3 + this.IIIIllIlIIIllIlllIlllllIl) : n3);
            }
            else if (b3) {
                n5 = drawStringWithShadow - 1;
                --drawStringWithShadow;
            }
            if (liiiIlIIllIIlIIlIIIlIIllI.length() > 0 && b && n2 < liiiIlIIllIIlIIlIIIlIIllI.length()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.drawStringWithShadow(liiiIlIIllIIlIIlIIIlIIllI.substring(n2), (float)drawStringWithShadow, (float)n4, n);
            }
            if (b2) {
                if (b3) {
                    IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)n5, (float)(n4 - 1), (float)(n5 + 1), (float)(n4 + 1 + this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI), -3092272);
                }
                else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.drawStringWithShadow("_", (float)n5, (float)n4, n);
                }
            }
            if (length != n2) {
                this.IlllIIIlIlllIllIlIIlllIlI(n5, n4 - 1, n3 + this.lIIIIlIIllIIlIIlIIIlIIllI.getStringWidth(liiiIlIIllIIlIIlIIIlIIllI.substring(0, length)) - 1, n4 + 1 + this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI);
            }
        }
    }
    
    private void IlllIIIlIlllIllIlIIlllIlI(int n, int n2, int n3, int n4) {
        if (n < n3) {
            final int n5 = n;
            n = n3;
            n3 = n5;
        }
        if (n2 < n4) {
            final int n6 = n2;
            n2 = n4;
            n4 = n6;
        }
        if (n3 > this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl) {
            n3 = this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl;
        }
        if (n > this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl) {
            n = this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl;
        }
        final Tessellator instance = Tessellator.instance;
        GL11.glColor4f(0.0f, 0.0f, (float)255, (float)255);
        GL11.glDisable(3553);
        GL11.glEnable(3058);
        GL11.glLogicOp(5387);
        instance.startDrawingQuads();
        instance.addVertex(n, n4, 0.0);
        instance.addVertex(n3, n4, 0.0);
        instance.addVertex(n3, n2, 0.0);
        instance.addVertex(n, n2, 0.0);
        instance.draw();
        GL11.glDisable(3058);
        GL11.glEnable(3553);
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl(final int n) {
        this.IIIllIllIlIlllllllIlIlIII = n;
        if (this.IlIlIIIlllIIIlIlllIlIllIl.length() > n) {
            this.IlIlIIIlllIIIlIlllIlIllIl = this.IlIlIIIlllIIIlIlllIlIllIl.substring(0, n);
        }
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public int IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIIllllIIIIlIlIIIIlIlI;
    }
    
    public boolean lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public void sendClickBlockToController(final boolean liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
    }
    
    public void IIIllIllIlIlllllllIlIlIII(final int illIllIIIlIIlllIIIllIllII) {
        this.IllIllIIIlIIlllIIIllIllII = illIllIIIlIIlllIIIllIllII;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII(final int ilIIlIIIIlIIIIllllIIlIllI) {
        this.IlIIlIIIIlIIIIllllIIlIllI = ilIIlIIIIlIIIIllllIIlIllI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean ilIlllIIIIllIllllIllIIlIl) {
        if (ilIlllIIIIllIllllIllIIlIl && !this.IlIlllIIIIllIllllIllIIlIl) {
            this.IllIIIIIIIlIlIllllIIllIII = 0;
        }
        this.IlIlllIIIIllIllllIllIIlIl = ilIlllIIIIllIllllIllIIlIl;
    }
    
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final boolean iiIlIIllllIIllllllIlIIIll) {
        this.IIIlIIllllIIllllllIlIIIll = iiIlIIllllIIllllllIlIIIll;
    }
    
    public int IlIlllIIIIllIllllIllIIlIl() {
        return this.IIIIIIlIlIlIllllllIlllIlI;
    }
    
    public int llIIlllIIIIlllIllIlIlllIl() {
        return this.lIIIIllIIlIlIllIIIlIllIlI() ? (this.IIIIllIlIIIllIlllIlllllIl - 8) : this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI(int iiiiiIlIlIlIllllllIlllIlI) {
        final int length = this.IlIlIIIlllIIIlIlllIlIllIl.length();
        if (iiiiiIlIlIlIllllllIlllIlI > length) {
            iiiiiIlIlIlIllllllIlllIlI = length;
        }
        if (iiiiiIlIlIlIllllllIlllIlI < 0) {
            iiiiiIlIlIlIllllllIlllIlI = 0;
        }
        this.IIIIIIlIlIlIllllllIlllIlI = iiiiiIlIlIlIllllllIlllIlI;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI != null) {
            if (this.lllIIIIIlIllIlIIIllllllII > length) {
                this.lllIIIIIlIllIlIIIllllllII = length;
            }
            final int llIIlllIIIIlllIllIlIlllIl = this.llIIlllIIIIlllIllIlIlllIl();
            final int n = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl.substring(this.lllIIIIIlIllIlIIIllllllII), llIIlllIIIIlllIllIlIlllIl).length() + this.lllIIIIIlIllIlIIIllllllII;
            if (iiiiiIlIlIlIllllllIlllIlI == this.lllIIIIIlIllIlIIIllllllII) {
                this.lllIIIIIlIllIlIIIllllllII -= this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl, llIIlllIIIIlllIllIlIlllIl, true).length();
            }
            if (iiiiiIlIlIlIllllllIlllIlI > n) {
                this.lllIIIIIlIllIlIIIllllllII += iiiiiIlIlIlIllllllIlllIlI - n;
            }
            else if (iiiiiIlIlIlIllllllIlllIlI <= this.lllIIIIIlIllIlIIIllllllII) {
                this.lllIIIIIlIllIlIIIllllllII -= this.lllIIIIIlIllIlIIIllllllII - iiiiiIlIlIlIllllllIlllIlI;
            }
            if (this.lllIIIIIlIllIlIIIllllllII < 0) {
                this.lllIIIIIlIllIlIIIllllllII = 0;
            }
            if (this.lllIIIIIlIllIlIIIllllllII > length) {
                this.lllIIIIIlIllIlIIIllllllII = length;
            }
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl(final boolean illlIllIlIIIIlIIlIIllIIIl) {
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
    }
    
    public boolean lIIlIlIllIIlIIIlIIIlllIII() {
        return this.lIIlIIllIIIIIlIllIIIIllII;
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl(final boolean liIlIIllIIIIIlIllIIIIllII) {
        this.lIIlIIllIIIIIlIllIIIIllII = liIlIIllIIIIIlIllIIIIllII;
    }
}
