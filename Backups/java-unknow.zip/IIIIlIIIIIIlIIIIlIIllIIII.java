// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIIIIlIIIIlIIllIIII extends IllIIIIlllIlllllIIllIllIl
{
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    
    public IIIIlIIIIIIlIIIIlIIllIIII(final IlllIIIllIlIIlIllIIlIlllI illlIIIllIlIIlIllIIlIlllI) {
        super(illlIIIllIlIIlIllIIlIlllI);
        this.IlllIllIlIIIIlIIlIIllIIIl = -1;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return super.lIIIIlIIllIIlIIlIIIlIIllI() && this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing") && !this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl((lIIllIIIllIIIIllIllIIllIl)this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
        super.IIIIllIIllIIIIllIllIIIlIl();
        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        final double ilIlIIIlllIIIlIlllIlIllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
        return this.lIIIIllIIlIlIllIIIlIllIlI <= 240 && !this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl((lIIllIIIllIIIIllIllIIllIl)this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl) && ilIlIIIlllIIIlIlllIlIllIl < 4;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
        super.IlllIIIlIlllIllIlIIlllIlI();
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlllIIlIlllllIlIllIII(), this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, -1);
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
        super.IIIIllIlIIIllIlllIlllllIl();
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.IlIIlIIllIllIIIIIlllIIlll().nextInt(20) == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(1010, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, 0);
        }
        ++this.lIIIIllIIlIlIllIIIlIllIlI;
        final int illlIllIlIIIIlIIlIIllIIIl = (int)(this.lIIIIllIIlIlIllIIIlIllIlI / (float)240 * 10);
        if (illlIllIlIIIIlIIlIIllIIIl != this.IlllIllIlIIIIlIIlIIllIIIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIIllIlIIIllIlllIlllllIl(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlllIIlIlllllIlIllIII(), this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, illlIllIlIIIIlIIlIIllIIIl);
            this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        }
        if (this.lIIIIllIIlIlIllIIIlIllIlI == 240 && this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl(this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl);
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(1012, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIlllIIlIlllllllllIIIIIl.IlllIIIlIlllIllIlIIlllIlI(2001, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl));
        }
    }
}
