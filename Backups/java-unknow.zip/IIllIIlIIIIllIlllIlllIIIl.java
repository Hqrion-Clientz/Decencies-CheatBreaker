// 
// Decompiled by Procyon v0.5.36
// 

public interface IIllIIlIIIIllIlllIlllIIIl
{
    void lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIIlIlIlIIIIlIlllIIIIl p0, final llllIlllIIIlIlIlIIlIllIII p1);
    
    void lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIIlIlIlIIIIlIlllIIIIl p0, final Exception p1);
}
