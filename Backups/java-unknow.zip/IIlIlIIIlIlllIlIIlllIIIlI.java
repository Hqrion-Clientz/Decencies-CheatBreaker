// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIlIlllIlIIlllIIIlI extends IIlllIllIlIllIIlIIIlIIlll
{
    public IIlIlIIIlIlllIlIIlllIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII) {
        this(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, liIlllIIIlIllllllIlIlIIII, 0);
    }
    
    public IIlIlIIIlIlllIlIIlllIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final int n4) {
        super(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, 0.0, 0.0, 0.0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(liIlllIIIlIllllllIlIlIIII.IlllIIIlIlllIllIlIIlllIlI(n4));
        final float illlIllIlIIIIlIIlIIllIIIl = 1.0f;
        this.llIIlllIIIIlllIllIlIlllIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IlIlllIIIIllIllllIllIIlIl = illlIllIlIIIIlIIlIIllIIIl;
        this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
        this.lIIIIllIIlIlIllIIIlIllIlI = IllllllIllIIlllIllIIlIIll.lIlIIllIIIlllIIllIIlIIllI.IllllIllllIlIIIlIIIllllll;
        this.IllIIIIIIIlIlIllllIIllIII /= 2.0f;
    }
    
    public IIlIlIIIlIlllIlIIlllIIIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final int n7) {
        this(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, liIlllIIIlIllllllIlIlIIII, n7);
        this.IllIIlIIlllllIllIIIlllIII *= 0.09423077322719023 * 1.0612244606018066;
        this.lIlIlIllIIIIIIIIllllIIllI *= 0.6404494643211365 * 0.15614034683613032;
        this.IlllIIlllIIIIllIIllllIlIl *= 4.157894611358643 * 0.024050633995612483;
        this.IllIIlIIlllllIllIIIlllIII += n4;
        this.lIlIlIllIIIIIIIIllllIIllI += n5;
        this.IlllIIlllIIIIllIIllllIlIl += n6;
    }
    
    @Override
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return 2;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final Tessellator tessellator, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        float liiiIlIIllIIlIIlIIIlIIllI = (this.lIIIIIIIIIlIllIIllIlIIlIl + this.IIIIllIlIIIllIlllIlllllIl / 4) / 16;
        float liiiIlIIllIIlIIlIIIlIIllI2 = liiiIlIIllIIlIIlIIIlIIllI + 0.014221875f * 1.097561f;
        float liiiiiiiiIlIllIIllIlIIlIl = (this.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl / 4) / 16;
        float liiiiiiiiIlIllIIllIlIIlIl2 = liiiiiiiiIlIllIIllIlIIlIl + 14.2f * 0.0010992518f;
        final float n7 = 0.043661974f * 2.2903225f * this.IllIIIIIIIlIlIllllIIllIII;
        if (this.IIIlllIIIllIllIlIIIIIIlII != null) {
            liiiIlIIllIIlIIlIIIlIIllI = this.IIIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl / 4 * 16);
            liiiIlIIllIIlIIlIIIlIIllI2 = this.IIIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI((this.IIIIllIlIIIllIlllIlllllIl + 1.0f) / 4 * 16);
            liiiiiiiiIlIllIIllIlIIlIl = this.IIIlllIIIllIllIlIIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIIllIIllIIIIllIllIIIlIl / 4 * 16);
            liiiiiiiiIlIllIIllIlIIlIl2 = this.IIIlllIIIllIllIlIIIIIIlII.lIIIIIIIIIlIllIIllIlIIlIl((this.IIIIllIIllIIIIllIllIIIlIl + 1.0f) / 4 * 16);
        }
        final float n8 = (float)(this.lIllIllIlIIllIllIlIlIIlIl + (this.IIIlIIlIlIIIlllIIlIllllll - this.lIllIllIlIIllIllIlIlIIlIl) * n - IIlIlIIIlIlllIlIIlllIIIlI.llIlIIIlIIIIlIlllIlIIIIll);
        final float n9 = (float)(this.llIlIIIllIIIIlllIlIIIIIlI + (this.IllIlIIIIlllIIllIIlllIIlI - this.llIlIIIllIIIIlllIlIIIIIlI) * n - IIlIlIIIlIlllIlIIlllIIIlI.IIIlIIllllIIllllllIlIIIll);
        final float n10 = (float)(this.lIllIlIlllIIlIIllIIlIIlII + (this.IllIlIlIllllIlIIllllIIlll - this.lIllIlIlllIIlIIllIIlIIlII) * n - IIlIlIIIlIlllIlIIlllIIIlI.lllIIIIIlIllIlIIIllllllII);
        tessellator.lIIIIIIIIIlIllIIllIlIIlIl(this.IlllIllIlIIIIlIIlIIllIIIl, this.IlIlllIIIIllIllllIllIIlIl, this.llIIlllIIIIlllIllIlIlllIl);
        tessellator.addVertexWithUV(n8 - n2 * n7 - n5 * n7, n9 - n3 * n7, n10 - n4 * n7 - n6 * n7, liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl2);
        tessellator.addVertexWithUV(n8 - n2 * n7 + n5 * n7, n9 + n3 * n7, n10 - n4 * n7 + n6 * n7, liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl);
        tessellator.addVertexWithUV(n8 + n2 * n7 + n5 * n7, n9 + n3 * n7, n10 + n4 * n7 + n6 * n7, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl);
        tessellator.addVertexWithUV(n8 + n2 * n7 - n5 * n7, n9 - n3 * n7, n10 + n4 * n7 - n6 * n7, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl2);
    }
}
