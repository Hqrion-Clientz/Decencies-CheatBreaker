// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIlIIIllIlllIlllllIl
{
    public static final String lIIIIlIIllIIlIIlIIIlIIllI = "cf2O02b1QJSZOcVHphHucA";
    public static final String lIIIIIIIIIlIllIIllIlIIlIl = "ZB9hEJy5l+u8QARAlX9T0w";
}
