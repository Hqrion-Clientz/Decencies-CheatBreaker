// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIIlIIlllIIIIlIlllIl extends lIIlllIIIlIllllllIlIlIIII
{
    @Override
    public boolean IIIlllIIIllIllIlIIIIIIlII() {
        return true;
    }
    
    public IIllIlllIIlllllIlllIIIlIl IIIIllIlIIIllIlllIlllllIl(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        return null;
    }
}
