// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlllIIllllllIIIlIIIlII
{
    public EntityLivingBase lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    final /* synthetic */ IIIlIlIlllIIlIllllIlIIlll IlllIIIlIlllIllIlIIlllIlI;
    
    IIIIlllIIllllllIIIlIIIlII(final IIIlIlIlllIIlIllllIlIIlll illlIIIlIlllIllIlIIlllIlI, final EntityLivingBase liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
}
