// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIllllllIIIlllIllII extends IIllIlllIIlllllIlllIIIlIl
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private short lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    
    public IIlIIllIllllllIIIlllIllII() {
    }
    
    public IIlIIllIllllllIIIlllIllII(final int liiiIlIIllIIlIIlIIIlIIllI, final short liiiiiiiiIlIllIIllIlIIlIl, final boolean illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = lIlIllllllllIlIIIllIIllII.readUnsignedByte();
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readShort();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readBoolean();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeByte(this.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeShort(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeBoolean(this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return String.format("id=%d, uid=%d, accepted=%b", this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public short IIIIllIlIIIllIlllIlllllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
