// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIllIIIlIlllllllIlI
{
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private float IlllIIIlIlllIllIlIIlllIlI;
    public float lIIIIlIIllIIlIIlIIIlIIllI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    
    public IIIIllIIllIIIlIlllllllIlI() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = 20;
        this.IlllIIIlIlllIllIlIIlllIlI = 5;
        this.IIIIllIIllIIIIllIllIIIlIl = 20;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final float n2) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = Math.min(n + this.lIIIIIIIIIlIllIIllIlIIlIl, 20);
        this.IlllIIIlIlllIllIlIIlllIlI = Math.min(this.IlllIIIlIlllIllIlIIlllIlI + n * n2 * 2.0f, (float)this.lIIIIIIIIIlIllIIllIlIIlIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIIIIIIIlllIIllIlIlIlIII llIIIIIIIlllIIllIlIlIlIII, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(llIIIIIIIlllIIllIlIlIlIII.lIIlIlIllIIlIIIlIIIlllIII(lIlIlIlIlIllllIlllIIIlIlI), llIIIIIIIlllIIllIlIlIlIII.IIIlllIIIllIllIlIIIIIIlII(lIlIlIlIlIllllIlllIIIlIlI));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll) {
        final lIIlIlIIllIIllllIIIlIlIlI iiIlIIllllIIllllllIlIIIll = lIllIIIIlIIlIllIIIlIlIlll.lIIlllIIlIlllllllllIIIIIl.IIIlIIllllIIllllllIlIIIll;
        this.IIIIllIIllIIIIllIllIIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI > 4) {
            this.lIIIIlIIllIIlIIlIIIlIIllI -= 4;
            if (this.IlllIIIlIlllIllIlIIlllIlI > 0.0f) {
                this.IlllIIIlIlllIllIlIIlllIlI = Math.max(this.IlllIIIlIlllIllIlIIlllIlI - 1.0f, 0.0f);
            }
            else if (iiIlIIllllIIllllllIlIIIll != lIIlIlIIllIIllllIIIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI) {
                this.lIIIIIIIIIlIllIIllIlIIlIl = Math.max(this.lIIIIIIIIIlIllIIllIlIIlIl - 1, 0);
            }
        }
        if (lIllIIIIlIIlIllIIIlIlIlll.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("naturalRegeneration") && this.lIIIIIIIIIlIllIIllIlIIlIl >= 18 && lIllIIIIlIIlIllIIIlIlIlll.IlIllIllllIIIlIIIllIIIllI()) {
            ++this.IIIIllIlIIIllIlllIlllllIl;
            if (this.IIIIllIlIIIllIlllIlllllIl >= 80) {
                lIllIIIIlIIlIllIIIlIlIlll.IlllIIIlIlllIllIlIIlllIlI(1.0f);
                this.lIIIIlIIllIIlIIlIIIlIIllI((float)3);
                this.IIIIllIlIIIllIlllIlllllIl = 0;
            }
        }
        else if (this.lIIIIIIIIIlIllIIllIlIIlIl <= 0) {
            ++this.IIIIllIlIIIllIlllIlllllIl;
            if (this.IIIIllIlIIIllIlllIlllllIl >= 80) {
                if (lIllIIIIlIIlIllIIIlIlIlll.getHealth() > 10 || iiIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IIIIllIlIIIllIlllIlllllIl || (lIllIIIIlIIlIllIIIlIlIlll.getHealth() > 1.0f && iiIlIIllllIIllllllIlIIIll == lIIlIlIIllIIllllIIIlIlIlI.IlllIIIlIlllIllIlIIlllIlI)) {
                    lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.IlIlIIIlllIIIlIlllIlIllIl, 1.0f);
                }
                this.IIIIllIlIIIllIlllIlllllIl = 0;
            }
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl = 0;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("foodLevel", 99)) {
            this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("foodLevel");
            this.IIIIllIlIIIllIlllIlllllIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("foodTickTimer");
            this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("foodSaturationLevel");
            this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IllIIIIIIIlIlIllllIIllIII("foodExhaustionLevel");
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("foodLevel", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("foodTickTimer", this.IIIIllIlIIIllIlllIlllllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("foodSaturationLevel", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("foodExhaustionLevel", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl < 20;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Math.min(this.lIIIIlIIllIIlIIlIIIlIIllI + n, 40);
    }
    
    public float IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int liiiiiiiiIlIllIIllIlIIlIl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final float illlIIIlIlllIllIlIIlllIlI) {
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
    }
}
