// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIlIlIIllllIlllllllIIlll
{
    lIIIIlIIllIIlIIlIIIlIIllI("PERFORM_RESPAWN", 0, "PERFORM_RESPAWN", 0, 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("REQUEST_STATS", 1, "REQUEST_STATS", 1, 1), 
    IlllIIIlIlllIllIlIIlllIlI("OPEN_INVENTORY_ACHIEVEMENT", 2, "OPEN_INVENTORY_ACHIEVEMENT", 2, 2);
    
    private final int IIIIllIlIIIllIlllIlllllIl;
    private static final IIIlIlIIllllIlllllllIIlll[] IIIIllIIllIIIIllIllIIIlIl;
    private static final IIIlIlIIllllIlllllllIIlll[] IlIlIIIlllIIIlIlllIlIllIl;
    
    private IIIlIlIIllllIlllllllIIlll(final String name, final int ordinal, final String s, final int n, final int iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    static {
        IIIIllIIllIIIIllIllIIIlIl = new IIIlIlIIllllIlllllllIIlll[values().length];
        IlIlIIIlllIIIlIlllIlIllIl = new IIIlIlIIllllIlllllllIIlll[] { IIIlIlIIllllIlllllllIIlll.lIIIIlIIllIIlIIlIIIlIIllI, IIIlIlIIllllIlllllllIIlll.lIIIIIIIIIlIllIIllIlIIlIl, IIIlIlIIllllIlllllllIIlll.IlllIIIlIlllIllIlIIlllIlI };
        for (final IIIlIlIIllllIlllllllIIlll iiIlIlIIllllIlllllllIIlll : values()) {
            IIIlIlIIllllIlllllllIIlll.IIIIllIIllIIIIllIllIIIlIl[iiIlIlIIllllIlllllllIIlll.IIIIllIlIIIllIlllIlllllIl] = iiIlIlIIllllIlllllllIIlll;
        }
    }
}
