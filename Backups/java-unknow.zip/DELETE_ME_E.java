// 
// Decompiled by Procyon v0.5.36
// 

public enum DELETE_ME_E
{
    lIIIIlIIllIIlIIlIIIlIIllI("CONTINUOUS", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("TEXT", 1), 
    IlllIIIlIlllIllIlIIlllIlI("BINARY", 2), 
    IIIIllIlIIIllIlllIlllllIl("PING", 3), 
    IIIIllIIllIIIIllIllIIIlIl("PONG", 4), 
    IlIlIIIlllIIIlIlllIlIllIl("CLOSING", 5);
    
    private DELETE_ME_E(final String name, final int ordinal) {
    }
}
