import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIlIlIIllIlllIIIllIl extends IIllIIllllIIIllllIIIlIIII
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIlIIlIlIIllIlllIIIllIl() {
    }
    
    public IIlIlIIlIlIIllIlllIIIllIl(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(llIllllIIIIIIIlllIIIIlIlI, n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = Math.max(iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(), iiiIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl());
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Length", this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl);
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Length");
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        boolean b = false;
        for (int i = random.nextInt(5); i < this.lIIIIlIIllIIlIIlIIIlIIllI - 8; i += 2 + random.nextInt(5)) {
            final lllIlIlllIlIIllllllIIIlll liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, i);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                i += Math.max(liiiIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(), liiiIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl());
                b = true;
            }
        }
        for (int j = random.nextInt(5); j < this.lIIIIlIIllIIlIIlIIIlIIllI - 8; j += 2 + random.nextInt(5)) {
            final lllIlIlllIlIIllllllIIIlll liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, 0, j);
            if (liiiiiiiiIlIllIIllIlIIlIl != null) {
                j += Math.max(liiiiiiiiIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(), liiiiiiiiIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl());
                b = true;
            }
        }
        if (b && random.nextInt(3) > 0) {
            switch (this.IlIlIIIlllIIIlIlllIlIllIl) {
                case 0: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - 2, 1, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 1: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, 2, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 2: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, 1, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 3: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - 2, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, 2, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
            }
        }
        if (b && random.nextInt(3) > 0) {
            switch (this.IlIlIIIlllIIIlIlllIlIllIl) {
                case 0: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - 2, 3, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 1: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, 0, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 2: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, 3, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
                case 3: {
                    IIIIllIIllIIIIllIllIIIlIl((llIllllIIIIIIIlllIIIIlIlI)lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - 2, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, 0, this.IlllIIIlIlllIllIlIIlllIlI());
                    break;
                }
            }
        }
    }
    
    public static IIIllllIIllllIIIIIlllllIl lIIIIlIIllIIlIIlIIIlIIllI(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final List list, final Random random, final int n, final int n2, final int n3, final int n4) {
        for (int i = 7 * MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 3, 5); i >= 7; i -= 7) {
            final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0, 0, 0, 3, 3, i, n4);
            if (lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, liiiIlIIllIIlIIlIIIlIIllI) == null) {
                return liiiIlIIllIIlIIlIIIlIIllI;
            }
        }
        return null;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        final IIlllllllIlllIIllllIIlIll liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(IllllllIllIIlllIllIIlIIll.IIIlllIIIllIllIlIIIIIIlII, 0);
        for (int i = this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI; i <= this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl; ++i) {
            for (int j = this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI; j <= this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl; ++j) {
                if (iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(i, 64, j)) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(i, iiiiiIllIlIIIIlIlllIllllI.lIIIIllIIlIlIllIIIlIllIlI(i, j) - 1, j, liiiiiiiiIlIllIIllIlIIlIl, 0, 2);
                }
            }
        }
        return true;
    }
}
