// 
// Decompiled by Procyon v0.5.36
// 

public enum CBStatusEnum
{
    lIIIIlIIllIIlIIlIIIlIIllI("ONLINE", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("AWAY", 1), 
    IlllIIIlIlllIllIlIIlllIlI("BUSY", 2), 
    IIIIllIlIIIllIlllIlllllIl("OFFLINE", 3);
    
    private CBStatusEnum(final String name, final int ordinal) {
    }
}
