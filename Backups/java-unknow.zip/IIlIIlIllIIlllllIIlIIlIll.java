// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIllIIlllllIIlIIlIll extends lIllIlIIIIIlIllIIIlIIIIII
{
    public IIlIIlIllIIlllllIIlIIlIll() {
        this(0.0f);
    }
    
    public IIlIIlIllIIlllllIIlIIlIll(final float n) {
        super(6, n);
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(16, 16).lIIIIlIIllIIlIIlIIIlIIllI(-2, 0.0f, -9, 4, 3, 1, n);
        this.lIIlIlIllIIlIIIlIIIlllIII = 4;
    }
}
