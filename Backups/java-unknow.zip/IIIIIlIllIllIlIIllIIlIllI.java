// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlIllIllIlIIllIIlIllI extends IlIIlIIlIllIIIIllIIllIlIl
{
    public IIIIIlIllIllIlIIllIIlIllI(final long n) {
        super(n, 1.0f);
    }
    
    public IIIIIlIllIllIlIIllIIlIllI(final long n, final float n2) {
        super(n, n2);
    }
    
    @Override
    protected float lIIIIlIIllIIlIIlIIIlIIllI() {
        return (this.IlllIIIlIlllIllIlIIlllIlI - this.llIIlllIIIIlllIllIlIlllIl()) / (float)this.IlllIIIlIlllIllIlIIlllIlI;
    }
}
