// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllIlllllIIIIIIllIlll extends IlIIIllllllIllIlllllIIllI
{
    @Override
    public String getIdentifier() {
        return "save-all";
    }
    
    @Override
    public String lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII) {
        return "commands.save.usage";
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlllllIIIIIIllIlIIlIlIII lIlllllIIIIIIllIlIIlIlIII, final String[] array) {
        final llllIlIlllllIIlIIllllIIII iiIlIIlIlIIIlllIIlIllllll = llllIlIlllllIIlIIllllIIII.IIIlIIlIlIIIlllIIlIllllll();
        lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.save.start", new Object[0]));
        if (iiIlIIlIlIIIlllIIlIllllll.IllllllIllllIIlllIllllllI() != null) {
            iiIlIIlIlIIIlllIIlIllllll.IllllllIllllIIlllIllllllI().IlllIllIlIIIIlIIlIIllIIIl();
        }
        try {
            for (int i = 0; i < iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI.length; ++i) {
                if (iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI[i] != null) {
                    final IllllIllIIlllllIIlIIllIlI illllIllIIlllllIIlIIllIlI = iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI[i];
                    final boolean ilIlIIIlllllIIIlIlIlIllII = illllIllIIlllllIIlIIllIlI.IlIlIIIlllllIIIlIlIlIllII;
                    illllIllIIlllllIIlIIllIlI.IlIlIIIlllllIIIlIlIlIllII = false;
                    illllIllIIlllllIIlIIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(true, null);
                    illllIllIIlllllIIlIIllIlI.IlIlIIIlllllIIIlIlIlIllII = ilIlIIIlllllIIIlIlIlIllII;
                }
            }
            if (array.length > 0 && "flush".equals(array[0])) {
                lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.save.flushStart", new Object[0]));
                for (int j = 0; j < iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI.length; ++j) {
                    if (iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI[j] != null) {
                        final IllllIllIIlllllIIlIIllIlI illllIllIIlllllIIlIIllIlI2 = iiIlIIlIlIIIlllIIlIllllll.IlllIIIlIlllIllIlIIlllIlI[j];
                        final boolean ilIlIIIlllllIIIlIlIlIllII2 = illllIllIIlllllIIlIIllIlI2.IlIlIIIlllllIIIlIlIlIllII;
                        illllIllIIlllllIIlIIllIlI2.IlIlIIIlllllIIIlIlIlIllII = false;
                        illllIllIIlllllIIlIIllIlI2.IlIllllIIIlIllllIIIIIllII();
                        illllIllIIlllllIIlIIllIlI2.IlIlIIIlllllIIIlIlIlIllII = ilIlIIIlllllIIIlIlIlIllII2;
                    }
                }
                lIlllllIIIIIIllIlIIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(new IIIlIlIIIlllllIIlllIIIlIl("commands.save.flushEnd", new Object[0]));
            }
        }
        catch (llllIIllIIllllIlIllIIIlII llllIIllIIllllIlIllIIIlII) {
            IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.save.failed", llllIIllIIllllIlIllIIIlII.getMessage());
            return;
        }
        IlIIIllllllIllIlllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIIIIIllIlIIlIlIII, this, "commands.save.success", new Object[0]);
    }
}
