// 
// Decompiled by Procyon v0.5.36
// 

enum DELETE_ME_D
{
    lIIIIlIIllIIlIIlIIIlIIllI("TOP_LEFT", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("TOP_RIGHT", 1), 
    IlllIIIlIlllIllIlIIlllIlI("BOTTOM_LEFT", 2), 
    IIIIllIlIIIllIlllIlllllIl("BOTTOM_RIGHT", 3);
    
    private DELETE_ME_D(final String name, final int ordinal) {
    }
}
