import java.util.Collection;
import java.util.Set;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIIIIlIlllIlIlIIIIIlI implements Map
{
    private final Map lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIlIIIIlIlllIlIlIIIIIlI() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new LinkedHashMap();
    }
    
    @Override
    public int size() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.isEmpty();
    }
    
    @Override
    public boolean containsKey(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.containsKey(o.toString().toLowerCase());
    }
    
    @Override
    public boolean containsValue(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.containsKey(o);
    }
    
    @Override
    public Object get(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.get(o.toString().toLowerCase());
    }
    
    public Object lIIIIlIIllIIlIIlIIIlIIllI(final String s, final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.put(s.toLowerCase(), o);
    }
    
    @Override
    public Object remove(final Object o) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.remove(o.toString().toLowerCase());
    }
    
    @Override
    public void putAll(final Map map) {
        for (final Entry<String, V> entry : map.entrySet()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey(), entry.getValue());
        }
    }
    
    @Override
    public void clear() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
    }
    
    @Override
    public Set keySet() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.keySet();
    }
    
    @Override
    public Collection values() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.values();
    }
    
    @Override
    public Set entrySet() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.entrySet();
    }
    
    @Override
    public Object put(final Object o, final Object o2) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((String)o, o2);
    }
}
