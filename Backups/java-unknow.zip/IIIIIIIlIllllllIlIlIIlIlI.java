import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIIlIllllllIlIlIIlIlI extends IIlllllllIlllIIllllIIlIll
{
    private int[] lIIIIlllIIlIlllllIlIllIII;
    private int[] lIIIlllIlIlllIIIIIIIIIlII;
    private IlllIllIIIIlllIllIIIIIlII[] IIIIlIIIlllllllllIlllIlll;
    
    protected IIIIIIIlIllllllIlIlIIlIlI() {
        super(Material.llIlIIIlIIIIlIlllIlIIIIll);
        this.lIIIIlllIIlIlllllIlIllIII = new int[256];
        this.lIIIlllIlIlllIIIIIIIIIlII = new int[256];
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
    }
    
    public static void IIIIlIIIlllllllllIlllIlll() {
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIlIlIIIlIlIlllIlIlllII), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.llIlIlIIIIIIIlllIIIllIlll), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIIlIllIllIlIIllIIlIllI), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIIIIlIlllIllIlIlIIlIlIl), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlllIlIlllIlIlllIIlllIlIl), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIlIlIllllllIllllIIllllI), 5, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIIIllllIIIIlIlIIIIlIlI), 5, 5);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIIIlIlIlIllllllIlllIlI), 5, 5);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IllIllIIIlIIlllIIIllIllII), 30, 60);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIIlIIIIlIIIIllllIIlIllI), 30, 60);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIlllIIIlIIIIIlIIIIIIII), 30, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIlIlIIlIIIlIlllllIIlIIlI), 15, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IllIIlllIllIlIllIlIIIIIII), 60, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIlIlIIIIllIIIllIlIIIllll), 60, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIIIlIIIlllllllllIlllIlll), 60, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIllllIIIlIllllIIIIIllII), 60, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lIIIIlllIIlIlllllIlIllIII), 30, 60);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.llllIIllllllIlIIlIlIIIllI), 15, 100);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIlllIlIlIIllllIlllIlIII), 5, 5);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.lllIlIIIllIIlIIlIlIllIIlI), 60, 20);
        IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IIlIIlIlIlIlllIIlIIlIIlII), 60, 20);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        this.lIIIIlllIIlIlllllIlIllIII[n] = n2;
        this.lIIIlllIlIlllIIIIIIIIIlII[n] = n3;
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 3;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final Random random) {
        return 0;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        return 30;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (iiiiiIllIlIIIIlIlllIllllI.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("doFireTick")) {
            boolean b = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == IllllllIllIIlllIllIIlIIll.llllIlIlIlllllIllIIllIIIl;
            if (iiiiiIllIlIIIIlIlllIllllI.lIIIIIllllIIIIlIlIIIIlIlI instanceof IlIIIllIIllllllIllIllllIl && iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3) == IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII) {
                b = true;
            }
            if (!this.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
            if (!b && iiiiiIllIlIIIIlIlllIllllI.IllIIlIIlllllIllIIIlllIII() && (iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n, n2, n3) || iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n - 1, n2, n3) || iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n + 1, n2, n3) || iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n, n2, n3 - 1) || iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n, n2, n3 + 1))) {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
            else {
                final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
                if (illlIIIlIlllIllIlIIlllIlI < 15) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, illlIIIlIlllIllIlIIlllIlI + random.nextInt(3) / 2, 4);
                }
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI) + random.nextInt(10));
                if (!b && !this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
                    if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) || illlIIIlIlllIllIlIIlllIlI > 3) {
                        iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                    }
                }
                else if (!b && !this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && illlIIIlIlllIllIlIIlllIlI == 15 && random.nextInt(4) == 0) {
                    iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
                }
                else {
                    final boolean liIlllIIlIlllllllllIIIIIl = iiiiiIllIlIIIIlIlllIllllI.lIIlllIIlIlllllllllIIIIIl(n, n2, n3);
                    int n4 = 0;
                    if (liIlllIIlIlllllllllIIIIIl) {
                        n4 = -50;
                    }
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3, 300 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3, 300 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3, 250 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3, 250 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1, 300 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1, 300 + n4, random, illlIIIlIlllIllIlIIlllIlI);
                    for (int i = n - 1; i <= n + 1; ++i) {
                        for (int j = n3 - 1; j <= n3 + 1; ++j) {
                            for (int k = n2 - 1; k <= n2 + 4; ++k) {
                                if (i != n || k != n2 || j != n3) {
                                    int bound = 100;
                                    if (k > n2 + 1) {
                                        bound += (k - (n2 + 1)) * 100;
                                    }
                                    final int ilIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl(iiiiiIllIlIIIIlIlllIllllI, i, k, j);
                                    if (ilIlllIIIIllIllllIllIIlIl > 0) {
                                        int n5 = (ilIlllIIIIllIllllIllIIlIl + 40 + iiiiiIllIlIIIIlIlllIllllI.IIIlIIllllIIllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI() * 7) / (illlIIIlIlllIllIlIIlllIlI + 30);
                                        if (liIlllIIlIlllllllllIIIIIl) {
                                            n5 /= 2;
                                        }
                                        if (n5 > 0 && random.nextInt(bound) <= n5 && (!iiiiiIllIlIIIIlIlllIllllI.IllIIlIIlllllIllIIIlllIII() || !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(i, k, j)) && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(i - 1, k, n3) && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(i + 1, k, j) && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(i, k, j - 1) && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(i, k, j + 1)) {
                                            int n6 = illlIIIlIlllIllIlIIlllIlI + random.nextInt(5) / 4;
                                            if (n6 > 15) {
                                                n6 = 15;
                                            }
                                            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(i, k, j, this, n6, 3);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public boolean IIlIIllIIIllllIIlllIllIIl() {
        return false;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int bound, final Random random, final int n4) {
        if (random.nextInt(bound) < this.lIIIlllIlIlllIIIIIIIIIlII[IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3))]) {
            final boolean b = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == IllllllIllIIlllIllIIlIIll.IIlIlIIlIIIlIlllllIIlIIlI;
            if (random.nextInt(n4 + 10) < 5 && !iiiiiIllIlIIIIlIlllIllllI.lIIlIIllIIIIIlIllIIIIllII(n, n2, n3)) {
                int n5 = n4 + random.nextInt(5) / 4;
                if (n5 > 15) {
                    n5 = 15;
                }
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this, n5, 3);
            }
            else {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
            if (b) {
                IllllllIllIIlllIllIIlIIll.IIlIlIIlIIIlIlllllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, 1);
            }
        }
    }
    
    private boolean IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3) || this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3) || this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) || this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3) || this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1) || this.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1);
    }
    
    private int IlIlllIIIIllIllllIllIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        final int n4 = 0;
        if (!iiiiiIllIlIIIIlIlllIllllI.IIIIllIlIIIllIlllIlllllIl(n, n2, n3)) {
            return 0;
        }
        return this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1, this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1, this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3, this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3, this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3, this.IIIllIllIlIlllllllIlIlIII(iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3, n4))))));
    }
    
    @Override
    public boolean IIIlIIllllIIllllllIlIIIll() {
        return false;
    }
    
    public boolean IIIIllIIllIIIIllIllIIIlIl(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        return this.lIIIIlllIIlIlllllIlIllIII[IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3))] > 0;
    }
    
    public int IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        final int n5 = this.lIIIIlllIIlIlllllIlIllIII[IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3))];
        return (n5 > n4) ? n5 : n4;
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) || this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && !this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
        }
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (iiiiiIllIlIIIIlIlllIllllI.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI > 0 || !IllllllIllIIlllIllIIlIIll.IlIlIIIlllIlIllIlIIIlllIl.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && !this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
                iiiiiIllIlIIIIlIlllIllllI.IlIlIIIlllIIIlIlllIlIllIl(n, n2, n3);
            }
            else {
                iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3, this, this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI) + iiiiiIllIlIIIIlIlllIllllI.lllIIIIIlIllIlIIIllllllII.nextInt(10));
            }
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (random.nextInt(24) == 0) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 1.3333334f * 0.375f, n2 + 1.44f * 0.3472222f, n3 + 0.472973f * 1.0571429f, "fire.fire", 1.0f + random.nextFloat(), random.nextFloat() * (0.81578946f * 0.85806453f) + 1.735849f * 0.1728261f, false);
        }
        if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3) && !IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2 - 1, n3)) {
            if (IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n - 1, n2, n3)) {
                for (int i = 0; i < 2; ++i) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + random.nextFloat() * (79.0f * 0.0012658228f), n2 + random.nextFloat(), n3 + random.nextFloat(), 0.0, 0.0, 0.0);
                }
            }
            if (IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n + 1, n2, n3)) {
                for (int j = 0; j < 2; ++j) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + 1 - random.nextFloat() * (0.08596491f * 1.1632653f), n2 + random.nextFloat(), n3 + random.nextFloat(), 0.0, 0.0, 0.0);
                }
            }
            if (IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 - 1)) {
                for (int k = 0; k < 2; ++k) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + random.nextFloat(), n2 + random.nextFloat(), n3 + random.nextFloat() * (12.2f * 0.008196722f), 0.0, 0.0, 0.0);
                }
            }
            if (IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2, n3 + 1)) {
                for (int l = 0; l < 2; ++l) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + random.nextFloat(), n2 + random.nextFloat(), n3 + 1 - random.nextFloat() * (0.0125f * 8.0f), 0.0, 0.0, 0.0);
                }
            }
            if (IllllllIllIIlllIllIIlIIll.IlIlllIllIlIllIlllIlllIll.IIIIllIIllIIIIllIllIIIlIl((lIIllIIIllIIIIllIllIIllIl)iiiiiIllIlIIIIlIlllIllllI, n, n2 + 1, n3)) {
                for (int n4 = 0; n4 < 2; ++n4) {
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + random.nextFloat(), n2 + 1 - random.nextFloat() * (0.7012987f * 0.1425926f), n3 + random.nextFloat(), 0.0, 0.0, 0.0);
                }
            }
        }
        else {
            for (int n5 = 0; n5 < 3; ++n5) {
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("largesmoke", n + random.nextFloat(), n2 + random.nextFloat() * (0.4923077f * 1.015625f) + 0.032786883f * 15.250001f, n3 + random.nextFloat(), 0.0, 0.0, 0.0);
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIIIlIIIlllllllllIlllIlll = new IlllIllIIIIlllIllIIIIIlII[] { illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_layer_0"), illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlllIIlIlllllIlIllIII() + "_layer_1") };
    }
    
    public IlllIllIIIIlllIllIIIIIlII IllIIIIIIIlIlIllllIIllIII(final int n) {
        return this.IIIIlIIIlllllllllIlllIlll[n];
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return this.IIIIlIIIlllllllllIlllIlll[0];
    }
    
    @Override
    public llIllllIlIlIlllIllIlIIIll lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return llIllllIlIlIlllIllIlIIIll.IlIlIIIlllIIIlIlllIlIllIl;
    }
}
