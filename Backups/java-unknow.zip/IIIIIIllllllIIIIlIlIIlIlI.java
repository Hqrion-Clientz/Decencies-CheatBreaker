import java.util.HashSet;
import java.io.FileFilter;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import com.google.common.collect.Sets;
import java.util.Set;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.File;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIIllllllIIIIlIlIIlIlI extends IIIIllIIlIIlIIIIIIIlllIlI
{
    public IIIIIIllllllIIIIlIlIIlIlI(final File file) {
        super(file);
    }
    
    @Override
    protected InputStream lIIIIlIIllIIlIIlIIIlIIllI(final String child) {
        return new BufferedInputStream(new FileInputStream(new File(this.lIIIIlIIllIIlIIlIIIlIIllI, child)));
    }
    
    @Override
    protected boolean lIIIIIIIIIlIllIIllIlIIlIl(final String child) {
        return new File(this.lIIIIlIIllIIlIIlIIIlIIllI, child).isFile();
    }
    
    @Override
    public Set lIIIIlIIllIIlIIlIIIlIIllI() {
        final HashSet hashSet = Sets.newHashSet();
        final File file = new File(this.lIIIIlIIllIIlIIlIIIlIIllI, "assets/");
        if (file.isDirectory()) {
            final File[] listFiles = file.listFiles((FileFilter)DirectoryFileFilter.DIRECTORY);
            for (int length = listFiles.length, i = 0; i < length; ++i) {
                final String liiiIlIIllIIlIIlIIIlIIllI = IIIIllIIlIIlIIIIIIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(file, listFiles[i]);
                if (!liiiIlIIllIIlIIlIIIlIIllI.equals(liiiIlIIllIIlIIlIIIlIIllI.toLowerCase())) {
                    this.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI);
                }
                else {
                    hashSet.add(liiiIlIIllIIlIIlIIIlIIllI.substring(0, liiiIlIIllIIlIIlIIIlIIllI.length() - 1));
                }
            }
        }
        return hashSet;
    }
}
