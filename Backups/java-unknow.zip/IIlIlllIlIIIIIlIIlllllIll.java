// 
// Decompiled by Procyon v0.5.36
// 

class IIlIlllIlIIIIIlIIlllllIll
{
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public boolean IlllIIIlIlllIllIlIIlllIlI;
    public boolean IIIIllIlIIIllIlllIlllllIl;
    public boolean IIIIllIIllIIIIllIllIIIlIl;
    public int IlIlIIIlllIIIlIlllIlIllIl;
    public int IIIllIllIlIlllllllIlIlIII;
    final /* synthetic */ llIIIlIllllIIlllllIIllllI IllIIIIIIIlIlIllllIIllIII;
    
    public IIlIlllIlIIIIIlIIlllllIll(final llIIIlIllllIIlllllIIllllI illIIIIIIIlIlIllllIIllIII, final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int iiIllIllIlIlllllllIlIlIII) {
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.IlllIIIlIlllIllIlIIlllIlI = false;
        this.IIIIllIlIIIllIlllIlllllIl = false;
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
    }
}
