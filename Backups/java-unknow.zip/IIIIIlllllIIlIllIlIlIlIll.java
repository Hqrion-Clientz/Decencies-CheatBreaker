// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIIlllllIIlIllIlIlIlIll extends GuiScreen
{
    private static final lllIlIIIIlIIlIlIIlIlIlIll[] IIIIllIlIIIllIlllIlllllIl;
    private GuiScreen IIIIllIIllIIIIllIllIIIlIl;
    protected String lIIIIlIIllIIlIIlIIIlIIllI;
    private GameSettings IlIlIIIlllIIIlIlllIlIllIl;
    public KeyBinding lIIIIIIIIIlIllIIllIlIIlIl;
    public long IlllIIIlIlllIllIlIIlllIlI;
    private IIlIIllIIIllllllIlIIlllll IIIllIllIlIlllllllIlIlIII;
    private lIIlIIIIlIIIIIllIIIIlIIll IllIIIIIIIlIlIllllIIllIII;
    
    public IIIIIlllllIIlIllIlIlIlIll(final GuiScreen iiiIllIIllIIIIllIllIIIlIl, final GameSettings ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = "Controls";
        this.lIIIIIIIIIlIllIIllIlIIlIl = null;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    @Override
    public void s_() {
        this.IIIllIllIlIlllllllIlIlIII = new IIlIIllIIIllllllIlIIlllll(this, this.lllIIIIIlIllIlIIIllllllII);
        this.IllIllIIIlIIlllIIIllIllII.add(new lIIlIIIIlIIIIIllIIIIlIIll(200, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155, this.IIIIIIlIlIlIllllllIlllIlI - 29, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("gui.done", new Object[0])));
        this.IllIllIIIlIIlllIIIllIllII.add(this.IllIIIIIIIlIlIllllIIllIII = new lIIlIIIIlIIIIIllIIIIlIIll(201, this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + 160, this.IIIIIIlIlIlIllllllIlllIlI - 29, 150, 20, IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("controls.resetAll", new Object[0])));
        this.lIIIIlIIllIIlIIlIIIlIIllI = IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI("controls.title", new Object[0]);
        int n = 0;
        for (final lllIlIIIIlIIlIlIIlIlIlIll lllIlIIIIlIIlIlIIlIlIlIll : IIIIIlllllIIlIllIlIlIlIll.IIIIllIlIIIllIlllIlllllIl) {
            if (lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI()) {
                this.IllIllIIIlIIlllIIIllIllII.add(new IllIIllIIllIlIllllIlIllII(lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI(), this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + n % 2 * 160, 18 + 24 * (n >> 1), lllIlIIIIlIIlIlIIlIlIlIll));
            }
            else {
                this.IllIllIIIlIIlllIIIllIllII.add(new llIllIlIlIIIllllIlIlIlIIl(lllIlIIIIlIIlIlIIlIlIlIll.IlllIIIlIlllIllIlIIlllIlI(), this.lIIIIIllllIIIIlIlIIIIlIlI / 2 - 155 + n % 2 * 160, 18 + 24 * (n >> 1), lllIlIIIIlIIlIlIIlIlIlIll, this.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll)));
            }
            ++n;
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIIIlIIIIIllIIIIlIIll liIlIIIIlIIIIIllIIIIlIIll) {
        if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 200) {
            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(this.IIIIllIIllIIIIllIllIIIlIl);
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI == 201) {
            for (final KeyBinding keyBinding : this.lllIIIIIlIllIlIIIllllllII.gameSettings.lllIIlIIIllIIlllIlIIIllIl) {
                keyBinding.lIIIIIIIIIlIllIIllIlIIlIl(keyBinding.IllIIIIIIIlIlIllllIIllIII());
            }
            KeyBinding.lIIIIIIIIIlIllIIllIlIIlIl();
        }
        else if (liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI < 100 && liIlIIIIlIIIIIllIIIIlIIll instanceof llIllIlIlIIIllllIlIlIlIIl) {
            this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(((llIllIlIlIIIllllIlIlIlIIl)liIlIIIIlIIIIIllIIIIlIIll).lIIIIlIIllIIlIIlIIIlIIllI(), 1);
            liIlIIIIlIIIIIllIIIIlIIll.IllIIIIIIIlIlIllllIIllIII = this.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI(lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liIlIIIIlIIIIIllIIIIlIIll.lIIIIllIIlIlIllIIIlIllIlI));
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, -100 + n3);
            this.lIIIIIIIIIlIllIIllIlIIlIl = null;
            KeyBinding.lIIIIIIIIIlIllIIllIlIIlIl();
        }
        else if (n3 != 0 || !this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3)) {
            super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        }
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        if (n3 != 0 || !this.IIIllIllIlIlllllllIlIlIII.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3)) {
            super.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl != null) {
            if (n == 1) {
                this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, 0);
            }
            else {
                this.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, n);
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl = null;
            this.IlllIIIlIlllIllIlIIlllIlI = Minecraft.getSystemTime();
            KeyBinding.lIIIIIIIIIlIllIIllIlIIlIl();
            CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
        }
        else {
            super.lIIIIlIIllIIlIIlIIIlIIllI(c, n);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl, this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIllllIIIIlIlIIIIlIlI / 2, 8, 16777215);
        boolean b = true;
        for (final KeyBinding keyBinding : this.IlIlIIIlllIIIlIlllIlIllIl.lllIIlIIIllIIlllIlIIIllIl) {
            if (keyBinding.lIIIIllIIlIlIllIIIlIllIlI() != keyBinding.IllIIIIIIIlIlIllllIIllIII()) {
                b = false;
                break;
            }
        }
        this.IllIIIIIIIlIlIllllIIllIII.IlllIllIlIIIIlIIlIIllIIIl = !b;
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
    }
    
    static {
        IIIIllIlIIIllIlllIlllllIl = new lllIlIIIIlIIlIlIIlIlIlIll[] { lllIlIIIIlIIlIlIIlIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI, lllIlIIIIlIIlIlIIlIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl, lllIlIIIIlIIlIlIIlIlIlIll.IIIlIIlIlIIIlllIIlIllllll };
    }
}
