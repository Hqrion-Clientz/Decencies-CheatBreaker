// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIlIIlllllIIIIIIIlI
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int[][][] IIIllIllIlIlllllllIlIlIII;
    private int[] IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIlIlIlIlIIlllllIIIIIIIlI(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = 18;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 128;
        this.IlllIIIlIlllIllIlIIlllIlI = 18;
        this.IIIIllIlIIIllIlllIlllllIl = 0;
        this.IIIIllIIllIIIIllIllIIIlIl = 0;
        this.IlIlIIIlllIIIlIlllIlIllIl = 0;
        this.IIIllIllIlIlllllllIlIlIII = null;
        this.IllIIIIIIIlIlIllllIIllIII = null;
        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIllIllIlIlllllllIlIlIII = new int[liiiIlIIllIIlIIlIIIlIIllI][liiiiiiiiIlIllIIllIlIIlIl][illlIIIlIlllIllIlIIlllIlI];
        this.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI; ++i) {
            final int[][] array = this.IIIllIllIlIlllllllIlIlIII[i];
            for (int j = 0; j < this.lIIIIIIIIIlIllIIllIlIIlIl; ++j) {
                final int[] array2 = array[j];
                for (int k = 0; k < this.IlllIIIlIlllIllIlIIlllIlI; ++k) {
                    array2[k] = -1;
                }
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int iiiIllIlIIIllIlllIlllllIl, final int iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI();
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        try {
            this.IllIIIIIIIlIlIllllIIllIII = this.IIIllIllIlIlllllllIlIlIII[n - this.IIIIllIlIIIllIlllIlllllIl][n2 - this.IIIIllIIllIIIIllIllIIIlIl];
            this.lIIIIllIIlIlIllIIIlIllIlI = n3 - this.IlIlIIIlllIIIlIlllIlIllIl;
            return this.IllIIIIIIIlIlIllllIIllIII[this.lIIIIllIIlIlIllIIIlIllIlI];
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            ex.printStackTrace();
            return -1;
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        try {
            this.IllIIIIIIIlIlIllllIIllIII[this.lIIIIllIIlIlIllIIIlIllIlI] = n;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
