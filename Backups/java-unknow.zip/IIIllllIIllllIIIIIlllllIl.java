// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllllIIllllIIIIIlllllIl
{
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public int lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI;
    public int IIIIllIlIIIllIlllIlllllIl;
    public int IIIIllIIllIIIIllIllIIIlIl;
    public int IlIlIIIlllIIIlIlllIlIllIl;
    
    public IIIllllIIllllIIIIIlllllIl() {
    }
    
    public IIIllllIIllllIIIIIlllllIl(final int[] array) {
        if (array.length == 6) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = array[0];
            this.lIIIIIIIIIlIllIIllIlIIlIl = array[1];
            this.IlllIIIlIlllIllIlIIlllIlI = array[2];
            this.IIIIllIlIIIllIlllIlllllIl = array[3];
            this.IIIIllIIllIIIIllIllIIIlIl = array[4];
            this.IlIlIIIlllIIIlIlllIlIllIl = array[5];
        }
    }
    
    public static IIIllllIIllllIIIIIlllllIl lIIIIlIIllIIlIIlIIIlIIllI() {
        return new IIIllllIIllllIIIIIlllllIl(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    }
    
    public static IIIllllIIllllIIIIIlllllIl lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final int n10) {
        switch (n10) {
            case 0: {
                return new IIIllllIIllllIIIIIlllllIl(n + n4, n2 + n5, n3 + n6, n + n7 - 1 + n4, n2 + n8 - 1 + n5, n3 + n9 - 1 + n6);
            }
            case 1: {
                return new IIIllllIIllllIIIIIlllllIl(n - n9 + 1 + n6, n2 + n5, n3 + n4, n + n6, n2 + n8 - 1 + n5, n3 + n7 - 1 + n4);
            }
            case 2: {
                return new IIIllllIIllllIIIIIlllllIl(n + n4, n2 + n5, n3 - n9 + 1 + n6, n + n7 - 1 + n4, n2 + n8 - 1 + n5, n3 + n6);
            }
            case 3: {
                return new IIIllllIIllllIIIIIlllllIl(n + n6, n2 + n5, n3 + n4, n + n9 - 1 + n6, n2 + n8 - 1 + n5, n3 + n7 - 1 + n4);
            }
            default: {
                return new IIIllllIIllllIIIIIlllllIl(n + n4, n2 + n5, n3 + n6, n + n7 - 1 + n4, n2 + n8 - 1 + n5, n3 + n9 - 1 + n6);
            }
        }
    }
    
    public IIIllllIIllllIIIIIlllllIl(final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = iiIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = iiIllllIIllllIIIIIlllllIl.IlllIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiIllllIIllllIIIIIlllllIl.IIIIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public IIIllllIIllllIIIIIlllllIl(final int liiiIlIIllIIlIIlIIIlIIllI, final int liiiiiiiiIlIllIIllIlIIlIl, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final int iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
    }
    
    public IIIllllIIllllIIIIIlllllIl(final int liiiIlIIllIIlIIlIIIlIIllI, final int illlIIIlIlllIllIlIIlllIlI, final int iiiIllIlIIIllIlllIlllllIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 1;
        this.IIIIllIIllIIIIllIllIIIlIl = 512;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        return this.IIIIllIlIIIllIlllIlllllIl >= iiIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI && this.lIIIIlIIllIIlIIlIIIlIIllI <= iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl && this.IlIlIIIlllIIIlIlllIlIllIl >= iiIllllIIllllIIIIIlllllIl.IlllIIIlIlllIllIlIIlllIlI && this.IlllIIIlIlllIllIlIIlllIlI <= iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl && this.IIIIllIIllIIIIllIllIIIlIl >= iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl && this.lIIIIIIIIIlIllIIllIlIIlIl <= iiIllllIIllllIIIIIlllllIl.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        return this.IIIIllIlIIIllIlllIlllllIl >= n && this.lIIIIlIIllIIlIIlIIIlIIllI <= n3 && this.IlIlIIIlllIIIlIlllIlIllIl >= n2 && this.IlllIIIlIlllIllIlIIlllIlI <= n4;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = Math.min(this.lIIIIlIIllIIlIIlIIIlIIllI, iiIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI);
        this.lIIIIIIIIIlIllIIllIlIIlIl = Math.min(this.lIIIIIIIIIlIllIIllIlIIlIl, iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl);
        this.IlllIIIlIlllIllIlIIlllIlI = Math.min(this.IlllIIIlIlllIllIlIIlllIlI, iiIllllIIllllIIIIIlllllIl.IlllIIIlIlllIllIlIIlllIlI);
        this.IIIIllIlIIIllIlllIlllllIl = Math.max(this.IIIIllIlIIIllIlllIlllllIl, iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl);
        this.IIIIllIIllIIIIllIllIIIlIl = Math.max(this.IIIIllIIllIIIIllIllIIIlIl, iiIllllIIllllIIIIIlllllIl.IIIIllIIllIIIIllIllIIIlIl);
        this.IlIlIIIlllIIIlIlllIlIllIl = Math.max(this.IlIlIIIlllIIIlIlllIlIllIl, iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        this.lIIIIlIIllIIlIIlIIIlIIllI += n;
        this.lIIIIIIIIIlIllIIllIlIIlIl += n2;
        this.IlllIIIlIlllIllIlIIlllIlI += n3;
        this.IIIIllIlIIIllIlllIlllllIl += n;
        this.IIIIllIIllIIIIllIllIIIlIl += n2;
        this.IlIlIIIlllIIIlIlllIlIllIl += n3;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        return n >= this.lIIIIlIIllIIlIIlIIIlIIllI && n <= this.IIIIllIlIIIllIlllIlllllIl && n3 >= this.IlllIIIlIlllIllIlIIlllIlI && n3 <= this.IlIlIIIlllIIIlIlllIlIllIl && n2 >= this.lIIIIIIIIIlIllIIllIlIIlIl && n2 <= this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl - this.lIIIIlIIllIIlIIlIIIlIIllI + 1;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIIllIIIIllIllIIIlIl - this.lIIIIIIIIIlIllIIllIlIIlIl + 1;
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl - this.IlllIIIlIlllIllIlIIlllIlI + 1;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI + (this.IIIIllIlIIIllIlllIlllllIl - this.lIIIIlIIllIIlIIlIIIlIIllI + 1) / 2;
    }
    
    public int IlIlIIIlllIIIlIlllIlIllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl + (this.IIIIllIIllIIIIllIllIIIlIl - this.lIIIIIIIIIlIllIIllIlIIlIl + 1) / 2;
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        return this.IlllIIIlIlllIllIlIIlllIlI + (this.IlIlIIIlllIIIlIlllIlIllIl - this.IlllIIIlIlllIllIlIIlllIlI + 1) / 2;
    }
    
    @Override
    public String toString() {
        return "(" + this.lIIIIlIIllIIlIIlIIIlIIllI + ", " + this.lIIIIIIIIIlIllIIllIlIIlIl + ", " + this.IlllIIIlIlllIllIlIIlllIlI + "; " + this.IIIIllIlIIIllIlllIlllllIl + ", " + this.IIIIllIIllIIIIllIllIIIlIl + ", " + this.IlIlIIIlllIIIlIlllIlIllIl + ")";
    }
    
    public IIllIIllIIIllIIlIIIIllIII IllIIIIIIIlIlIllllIIllIII() {
        return new IIllIIllIIIllIIlIIIIllIII(new int[] { this.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl });
    }
}
