import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public abstract class IIIllIlIIlIllIlIllIlIIlIl extends Entity
{
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private IIlllllllIlllIIllllIIlIll IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    public EntityLivingBase lIIIIlIIllIIlIIlIIIlIIllI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private int IlIlllIIIIllIllllIllIIlIl;
    public double lIIIIIIIIIlIllIIllIlIIlIl;
    public double IlllIIIlIlllIllIlIIlllIlI;
    public double IIIIllIlIIIllIlllIlllllIl;
    
    public IIIllIlIIlIllIlIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.IIIIllIIllIIIIllIllIIIlIl(1.0f, 1.0f);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        final double n2 = this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI() * 4 * 64;
        return n < n2 * n2;
    }
    
    public IIIllIlIIlIllIlIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.IIIIllIIllIIIIllIllIIIlIl(1.0f, 1.0f);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3, this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        final double n7 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n4 * n4 + n5 * n5 + n6 * n6);
        this.lIIIIIIIIIlIllIIllIlIIlIl = n4 / n7 * (0.8172042965888977 * 0.12236842172442217);
        this.IlllIIIlIlllIllIlIIlllIlI = n5 / n7 * (0.09175257912375419 * 1.0898876190185547);
        this.IIIIllIlIIIllIlllIlllllIl = n6 / n7 * (3.625 * 0.027586206896551727);
    }
    
    public IIIllIlIIlIllIlIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final EntityLivingBase liiiIlIIllIIlIIlIIIlIIllI, double n, double n2, double n3) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.IlIlIIIlllIIIlIlllIlIllIl = -1;
        this.IIIllIllIlIlllllllIlIlIII = -1;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.IIIIllIIllIIIIllIllIIIlIl(1.0f, 1.0f);
        this.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll, liiiIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI, liiiIlIIllIIlIIlIIIlIIllI.IllIlIlIllllIlIIllllIIlll, liiiIlIIllIIlIIlIIIlIIllI.IllllIllllIlIIIlIIIllllll, liiiIlIIllIIlIIlIIIlIIllI.IllIIlllIllIlIllIlIIIIIII);
        this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        final double illIIlIIlllllIllIIIlllIII = 0.0;
        this.IlllIIlllIIIIllIIllllIlIl = illIIlIIlllllIllIIIlllIII;
        this.lIlIlIllIIIIIIIIllllIIllI = illIIlIIlllllIllIIIlllIII;
        this.IllIIlIIlllllIllIIIlllIII = illIIlIIlllllIllIIIlllIII;
        n += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.10752688348293304 * 3.71999993902445);
        n2 += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.4117647111415863 * 0.9714285590210742);
        n3 += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.028985507786273956 * 13.799999742954975);
        final double n4 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n2 * n2 + n3 * n3);
        this.lIIIIIIIIIlIllIIllIlIIlIl = n / n4 * (0.5777777624718942 * 0.17307692766189575);
        this.IlllIIIlIlllIllIlIIlllIlI = n2 / n4 * (0.08928571390558263 * 1.1200000047683716);
        this.IIIIllIlIIIllIlllIlllllIl = n3 / n4 * (0.08775510609720925 * 1.139534831047058);
    }
    
    @Override
    public void x_() {
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && ((this.lIIIIlIIllIIlIIlIIIlIIllI != null && this.lIIIIlIIllIIlIIlIIIlIIllI.IIllIlIllIlIllIIlIllIlIII) || !this.lIIlllIIlIlllllllllIIIIIl.IIIIllIIllIIIIllIllIIIlIl((int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll))) {
            this.IlIllllIIIlIllllIIIIIllII();
        }
        else {
            super.x_();
            this.IIIIllIIllIIIIllIllIIIlIl(1);
            if (this.lIIIIllIIlIlIllIIIlIllIlI) {
                if (this.lIIlllIIlIlllllllllIIIIIl.getBlock(this.IIIIllIIllIIIIllIllIIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIllIllIlIlllllllIlIlIII) == this.IllIIIIIIIlIlIllllIIllIII) {
                    ++this.IlllIllIlIIIIlIIlIIllIIIl;
                    if (this.IlllIllIlIIIIlIIlIIllIIIl == 600) {
                        this.IlIllllIIIlIllllIIIIIllII();
                    }
                    return;
                }
                this.lIIIIllIIlIlIllIIIlIllIlI = false;
                this.IllIIlIIlllllIllIIIlllIII *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (0.39215687f * 0.51f);
                this.lIlIlIllIIIIIIIIllllIIllI *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (1.0625f * 0.1882353f);
                this.IlllIIlllIIIIllIIllllIlIl *= this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (1.05f * 0.19047621f);
                this.IlllIllIlIIIIlIIlIIllIIIl = 0;
                this.IlIlllIIIIllIllllIllIIlIl = 0;
            }
            else {
                ++this.IlIlllIIIIllIllllIllIIlIl;
            }
            MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll), lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + this.IllIIlIIlllllIllIIIlllIII, this.IllIlIIIIlllIIllIIlllIIlI + this.lIlIlIllIIIIIIIIllllIIllI, this.IllIlIlIllllIlIIllllIIlll + this.IlllIIlllIIIIllIIllllIlIl));
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
            lIllIIIIlllllIIlIllIIIIII lIllIIIIlllllIIlIllIIIIII = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll + this.IllIIlIIlllllIllIIIlllIII, this.IllIlIIIIlllIIllIIlllIIlI + this.lIlIlIllIIIIIIIIllllIIllI, this.IllIlIlIllllIlIIllllIIlll + this.IlllIIlllIIIIllIIllllIlIl);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                lIllIIIIlllllIIlIllIIIIII = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl.IlllIIIlIlllIllIlIIlllIlI);
            }
            Entity entity = null;
            final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl).lIIIIIIIIIlIllIIllIlIIlIl(1.0, 1.0, 1.0));
            double n = 0.0;
            for (int i = 0; i < liiiiiiiiIlIllIIllIlIIlIl.size(); ++i) {
                final Entity entity2 = liiiiiiiiIlIllIIllIlIIlIl.get(i);
                if (entity2.IIIIIlIllIllIlIIllIIlIllI() && (!entity2.IllIIIIIIIlIlIllllIIllIII(this.lIIIIlIIllIIlIIlIIIlIIllI) || this.IlIlllIIIIllIllllIllIIlIl >= 25)) {
                    final float n2 = 0.825f * 0.36363637f;
                    final MovingObjectPosition liiiIlIIllIIlIIlIIIlIIllI3 = entity2.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n2, n2, n2).lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2, lIllIIIIlllllIIlIllIIIIII);
                    if (liiiIlIIllIIlIIlIIIlIIllI3 != null) {
                        final double iiiIllIlIIIllIlllIlllllIl = liiiIlIIllIIlIIlIIIlIIllI2.IIIIllIlIIIllIlllIlllllIl(liiiIlIIllIIlIIlIIIlIIllI3.IlIlIIIlllIIIlIlllIlIllIl);
                        if (iiiIllIlIIIllIlllIlllllIl < n || n == 0.0) {
                            entity = entity2;
                            n = iiiIllIlIIIllIlllIlllllIl;
                        }
                    }
                }
            }
            if (entity != null) {
                liiiIlIIllIIlIIlIIIlIIllI = new MovingObjectPosition(entity);
            }
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            }
            this.IIIlIIlIlIIIlllIIlIllllll += this.IllIIlIIlllllIllIIIlllIII;
            this.IllIlIIIIlllIIllIIlllIIlI += this.lIlIlIllIIIIIIIIllllIIllI;
            this.IllIlIlIllllIlIIllllIIlll += this.IlllIIlllIIIIllIIllllIlIl;
            final float liiiIlIIllIIlIIlIIIlIIllI4 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl);
            this.IllllIllllIlIIIlIIIllllll = (float)(Math.atan2(this.IlllIIlllIIIIllIIllllIlIl, this.IllIIlIIlllllIllIIIlllIII) * 180 / (3.75 * 0.8377580409572781)) + 90;
            this.IllIIlllIllIlIllIlIIIIIII = (float)(Math.atan2(liiiIlIIllIIlIIlIIIlIIllI4, this.lIlIlIllIIIIIIIIllllIIllI) * 180 / (0.4084506928920746 * 7.691485675652654)) - 90;
            while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl < -180) {
                this.IIlIIllIIIllllIIlllIllIIl -= 360;
            }
            while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl >= 180) {
                this.IIlIIllIIIllllIIlllIllIIl += 360;
            }
            while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII < -180) {
                this.IlIlIIIlllllIIIlIlIlIllII -= 360;
            }
            while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII >= 180) {
                this.IlIlIIIlllllIIIlIlIlIllII += 360;
            }
            this.IllIIlllIllIlIllIlIIIIIII = this.IIlIIllIIIllllIIlllIllIIl + (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl) * (1.1875f * 0.16842106f);
            this.IllllIllllIlIIIlIIIllllll = this.IlIlIIIlllllIIIlIlIlIllII + (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII) * (0.72727275f * 0.275f);
            float illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI();
            if (this.lIIlIIIIIIIIllIIllIIlllIl()) {
                for (int j = 0; j < 4; ++j) {
                    final float n3 = 0.12202381f * 2.0487804f;
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("bubble", this.IIIlIIlIlIIIlllIIlIllllll - this.IllIIlIIlllllIllIIIlllIII * n3, this.IllIlIIIIlllIIllIIlllIIlI - this.lIlIlIllIIIIIIIIllllIIllI * n3, this.IllIlIlIllllIlIIllllIIlll - this.IlllIIlllIIIIllIIllllIlIl * n3, this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
                }
                illlIIIlIlllIllIlIIlllIlI = 0.84931505f * 0.94193554f;
            }
            this.IllIIlIIlllllIllIIIlllIII += this.lIIIIIIIIIlIllIIllIlIIlIl;
            this.lIlIlIllIIIIIIIIllllIIllI += this.IlllIIIlIlllIllIlIIlllIlI;
            this.IlllIIlllIIIIllIIllllIlIl += this.IIIIllIlIIIllIlllIlllllIl;
            this.IllIIlIIlllllIllIIIlllIII *= illlIIIlIlllIllIlIIlllIlI;
            this.lIlIlIllIIIIIIIIllllIIllI *= illlIIIlIlllIllIlIIlllIlI;
            this.IlllIIlllIIIIllIIllllIlIl *= illlIIIlIlllIllIlIIlllIlI;
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("smoke", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI + 0.5540540701198792 * 0.9024389982223511, this.IllIlIlIllllIlIIllllIIlll, 0.0, 0.0, 0.0);
            this.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll);
        }
    }
    
    protected float IlllIIIlIlllIllIlIIlllIlI() {
        return 9.875f * 0.09620253f;
    }
    
    protected abstract void lIIIIlIIllIIlIIlIIIlIIllI(final MovingObjectPosition p0);
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("xTile", (short)this.IIIIllIIllIIIIllIllIIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("yTile", (short)this.IlIlIIIlllIIIlIlllIlIllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("zTile", (short)this.IIIllIllIlIlllllllIlIlIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("inTile", (byte)IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("inGround", (byte)(this.lIIIIllIIlIlIllIIIlIllIlI ? 1 : 0));
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("direction", this.lIIIIlIIllIIlIIlIIIlIIllI(new double[] { this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl }));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.IIIIllIIllIIIIllIllIIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("xTile");
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("yTile");
        this.IIIllIllIlIlllllllIlIlIII = ilIIIllIIlIIlllIllllIIIIl.IIIIllIIllIIIIllIllIIIlIl("zTile");
        this.IllIIIIIIIlIlIllllIIllIII = IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("inTile") & 0xFF);
        this.lIIIIllIIlIlIllIIIlIllIlI = (ilIIIllIIlIIlllIllllIIIIl.IIIIllIlIIIllIlllIlllllIl("inGround") == 1);
        if (ilIIIllIIlIIlllIllllIIIIl.lIIIIIIIIIlIllIIllIlIIlIl("direction", 9)) {
            final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("direction", 6);
            this.IllIIlIIlllllIllIIIlllIII = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(0);
            this.lIlIlIllIIIIIIIIllllIIllI = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(1);
            this.IlllIIlllIIIIllIIllllIlIl = illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(2);
        }
        else {
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    @Override
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return true;
    }
    
    @Override
    public float IlIIllIIIlllIIIIlIIIIlIll() {
        return 1.0f;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        if (this.llllIIlIlIllIllllIIIIllll()) {
            return false;
        }
        this.llIIIllIIllllIlIlIlIlIIll();
        if (lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl() != null) {
            final lIllIIIIlllllIIlIllIIIIII liiiiiIlIIllllllIIIlIlIIl = lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl().lIIIIIIlIIllllllIIIlIlIIl();
            if (liiiiiIlIIllllllIIIlIlIIl != null) {
                this.IllIIlIIlllllIllIIIlllIII = liiiiiIlIIllllllIIIlIlIIl.lIIIIlIIllIIlIIlIIIlIIllI;
                this.lIlIlIllIIIIIIIIllllIIllI = liiiiiIlIIllllllIIIlIlIIl.lIIIIIIIIIlIllIIllIlIIlIl;
                this.IlllIIlllIIIIllIIllllIlIl = liiiiiIlIIllllllIIIlIlIIl.IlllIIIlIlllIllIlIIlllIlI;
                this.lIIIIIIIIIlIllIIllIlIIlIl = this.IllIIlIIlllllIllIIIlllIII * (0.37735849618911743 * 0.26499999605119234);
                this.IlllIIIlIlllIllIlIIlllIlI = this.lIlIlIllIIIIIIIIllllIIllI * (0.1624999939464035 * 0.6153846383094788);
                this.IIIIllIlIIIllIlllIlllllIl = this.IlllIIlllIIIIllIIllllIlIl * (0.5999999821186072 * 0.1666666716337204);
            }
            if (lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl() instanceof EntityLivingBase) {
                this.lIIIIlIIllIIlIIlIIIlIIllI = (EntityLivingBase)lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl();
            }
            return true;
        }
        return false;
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    @Override
    public float lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        return 1.0f;
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        return 15728880;
    }
}
