import com.google.gson.JsonElement;
import org.lwjgl.input.Keyboard;
import com.google.common.collect.ImmutableList;
import java.util.Collections;
import java.util.Random;
import java.util.UUID;
import java.util.TreeSet;
import java.awt.Color;
import java.util.Iterator;
import com.google.gson.Gson;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import com.google.common.base.Charsets;
import com.cheatbreaker.client.network.messages.Message;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlllIllllIlIllllII implements llllIIlIIllIIIlllIlIIIllI
{
    final CheatBreaker lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    private boolean IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    private List<llIIIlllllIIllIlllIlIlIll> IlIlIIIlllIIIlIlllIlIllIl;
    private llIIIlllllIIllIlllIlIlIll IIIllIllIlIlllllllIlIlIII;
    private boolean IllIIIIIIIlIlIllllIIllIII;
    private List lIIIIllIIlIlIllIIIlIllIlI;
    private List IlllIllIlIIIIlIIlIIllIIIl;
    private String IlIlllIIIIllIllllIllIIlIl;
    private Map llIIlllIIIIlllIllIlIlllIl;
    
    public IIlIIllIlllIllllIlIllllII() {
        this.lIIIIlIIllIIlIIlIIIlIIllI = CheatBreaker.getInstance();
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
        this.IlllIIIlIlllIllIlIIlllIlI = false;
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.lIIIIllIIlIlIllIIIlIllIlI = new ArrayList();
        this.IlllIllIlIIIIlIIlIIllIIIl = new ArrayList();
        this.IlIlllIIIIllIllllIllIIlIl = "";
        this.llIIlllIIIIlllIllIlIlllIl = new HashMap();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIllIIIIIlIllIIIIllII liIlIIllIIIIIlIllIIIIllII) {
        try {
            Message.s(liIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(), liIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl());
        }
        catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIlIllIlIIIllllllII lllIIIIIlIllIlIIIllllllII) {
        try {
            if (lllIIIIIlIllIlIIIllllllII.lIIIIIIIIIlIllIIllIlIIlIl().equals("REGISTER")) {
                final String s = new String(lllIIIIIlIllIlIIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(), Charsets.UTF_8);
                this.lIIIIIIIIIlIllIIllIlIIlIl = s.contains(CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI());
                this.IlllIIIlIlllIllIlIIlllIlI = s.contains(CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl());
                final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII = new lIlIllllllllIlIIIllIIllII(Unpooled.buffer());
                lIlIllllllllIlIIIllIIllII.writeBytes(CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI().getBytes(Charsets.UTF_8));
                if (Minecraft.getMinecraft().getNetHandler() != null && this.lIIIIIIIIIlIllIIllIlIIlIl) {
                    Minecraft.getMinecraft().getNetHandler().addToSendQueue(new lIIlIlllIlIllIlIlIllllIlI("REGISTER", lIlIllllllllIlIIIllIIllII));
                }
                this.IlIlllIIIIllIllllIllIIlIl();
            }
            else if (lllIIIIIlIllIlIIIllllllII.lIIIIIIIIIlIllIIllIlIIlIl().equals(CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI())) {
                final llIlIIIlIIlIlllIIlIIIIIll liiiIlIIllIIlIIlIIIlIIllI = llIlIIIlIIlIlllIIlIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(this, lllIIIIIlIllIlIIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI());
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(this);
                if (CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIllIllIlIlllllllIlIlIII) {
                    final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI = new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "[C" + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + "B" + IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "] " + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII);
                    final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI2 = new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.IllIIIIIIIlIlIllllIIllIII + "Received: " + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + liiiIlIIllIIlIIlIIIlIIllI.getClass().getSimpleName());
                    lIlIIllIIlIIIIIlIllIllllI2.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(new IIIIIlIIlIIlIlIlIIIIIIlII(llIlIllIllllllIlllllllIII.lIIIIlIIllIIlIIlIIIlIIllI, new lIlIIllIIlIIIIIlIllIllllI(new Gson().toJson((Object)liiiIlIIllIIlIIlIIIlIIllI))));
                    lIlIIllIIlIIIIIlIllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIIllIIlIIIIIlIllIllllI2);
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIIllIIlIIIIIlIllIllllI);
                }
            }
        }
        catch (Exception | AssertionError ex) {
            final Throwable t;
            t.printStackTrace();
        }
    }
    
    private void IlIlllIIIIllIllllIllIIlIl() {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI().IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().removeIf(liIllIllIlIllIIIlIlllllIl -> liIllIllIlIllIIIlIlllllIl.IIIIllIlIIIllIlllIlllllIl);
        this.IIIIllIIllIIIIllIllIIIlIl = false;
        this.IIIIllIlIIIllIlllIlllllIl = false;
        this.IlIlIIIlllIIIlIlllIlIllIl = null;
        this.IIIllIllIlIlllllllIlIlIII = null;
        this.IllIIIIIIIlIlIllllIIllIII = false;
        this.IlIlllIIIIllIllllIllIIlIl = "";
        this.IlllIllIlIIIIlIIlIIllIIIl.clear();
        this.llIIlllIIIIlllIllIlIlllIl = new HashMap();
        final Iterator<IlIIIIlllIIIlIIllllIIIlll> iterator = CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl.iterator();
        while (iterator.hasNext()) {
            ((lIllIlIlIIlIllIllllIllIIl)iterator.next()).lIIlllIIlIlllllllllIIIIIl();
        }
        CheatBreaker.getInstance().IllIlIIIIlllIIllIIlllIIlI().lIIIIlIIllIIlIIlIIIlIIllI();
        this.lIIIIlIIllIIlIIlIIIlIIllI();
        IIIIIlllIllIIIIllIllIIIII.lIIIIlIIllIIlIIlIIIlIIllI = llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI;
        lIIlIlIllllllIllllIIllllI.lIIIIIIIIIlIllIIllIlIIlIl = llIllllIIIIIlIllIlIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI;
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI().clear();
        IIIlIllIIllllIIIllllIllll.IIIllIllIlIlllllllIlIlIII().clear();
        final lIlIIIIIIlIllIlIllIlIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        if (Minecraft.getMinecraft().thePlayer == null || liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII() == null) {
            return;
        }
        liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().removeIf(liIllIllIlIllIIIlIlllllIl2 -> liIllIllIlIllIIIlIlllllIl2.IlIlIIIlllIIIlIlllIlIllIl);
        ((lIlIIIllIlIIIlIlIlIIllIlI)liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()).IlIlllIIIIllIllllIllIIlIl().removeIf(liIllIllIlIllIIIlIlllllIl3 -> liIllIllIlIllIIIlIlllllIl3.IlIlIIIlllIIIlIlllIlIllIl);
        if (((lIlIIIllIlIIIlIlIlIIllIlI)liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()).llIIlllIIIIlllIllIlIlllIl() == null) {
            return;
        }
        ((lIlIIIllIlIIIlIlIlIIllIlI)liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()).llIIlllIIIIlllIllIlIlllIl().lIIIIlIIllIIlIIlIIIlIIllI.removeIf(liIllIllIlIllIIIlIlllllIl4 -> liIllIllIlIllIIIlIlllllIl4.IlIlIIIlllIIIlIlllIlIllIl);
        IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.lIIIIIIIIIlIllIIllIlIIlIl();
        liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().IIIllIllIlIlllllllIlIlIII();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        CheatBreaker.getInstance().IIIlIIlIlIIIlllIIlIllllll().lIIIIlIIllIIlIIlIIIlIIllI().clear();
        IIIlllIllIIllIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI((Map)null);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIIIlIIlIlllIIlIIIIIll llIlIIIlIIlIlllIIlIIIIIll) {
        if (llIlIIIlIIlIlllIIlIIIIIll != null && CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IIIllIllIlIlllllllIlIlIII) {
            final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI = new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "[C" + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + "B" + IlIllllIIlIIllIlIlllllIlI.lIIlIlIllIIlIIIlIIIlllIII + "] " + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII);
            final lIlIIllIIlIIIIIlIllIllllI lIlIIllIIlIIIIIlIllIllllI2 = new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.IllIIIIIIIlIlIllllIIllIII + "Sent: " + IlIllllIIlIIllIlIlllllIlI.IIIlIIllllIIllllllIlIIIll + llIlIIIlIIlIlllIIlIIIIIll.getClass().getSimpleName());
            lIlIIllIIlIIIIIlIllIllllI2.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(new IIIIIlIIlIIlIlIlIIIIIIlII(llIlIllIllllllIlllllllIII.lIIIIlIIllIIlIIlIIIlIIllI, new lIlIIllIIlIIIIIlIllIllllI(new Gson().toJson((Object)llIlIIIlIIlIlllIIlIIIIIll))));
            lIlIIllIIlIIIIIlIllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(lIlIIllIIlIIIIIlIllIllllI2);
            Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(lIlIIllIIlIIIIIlIllIllllI);
        }
        Minecraft.getMinecraft().thePlayer.lIIIIIIIIIlIllIIllIlIIlIl.addToSendQueue(new lIIlIlllIlIllIlIlIllllIlI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(), llIlIIIlIIlIlllIIlIIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIIlIIlIlllIIlIIIIIll)));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final CBDisconnectEvent cbDisconnectEvent) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = false;
        this.IlllIIIlIlllIllIlIIlllIlI = false;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIllllIIIlllIIIllIIIIllll lIllllIIIlllIIIllIIIIllll) {
        final int iiiIllIIllIIIIllIllIIIlIl = lIllllIIIlllIIIllIIIIllll.IIIIllIIllIIIIllIllIIIlIl();
        final int ilIlIIIlllIIIlIlllIlIllIl = lIllllIIIlllIIIllIIIIllll.IlIlIIIlllIIIlIlllIlIllIl();
        final int iiIllIllIlIlllllllIlIlIII = lIllllIIIlllIIIllIIIIllll.IIIllIllIlIlllllllIlIlIII();
        final lIlIIIIIIlIllIlIllIlIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
        if (liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().stream().anyMatch(liIllIllIlIllIIIlIlllllIl -> liIllIllIlIllIIIlIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI.equals(lIllllIIIlllIIIllIIIIllll.lIIIIIIIIIlIllIIllIlIIlIl()) && liIllIllIlIllIIIlIlllllIl.IIIIllIIllIIIIllIllIIIlIl.equals(lIllllIIIlllIIIllIIIIllll.IlllIIIlIlllIllIlIIlllIlI()))) {
            return;
        }
        final Color color = new Color(lIllllIIIlllIIIllIIIIllll.IIIIllIlIIIllIlllIlllllIl());
        final float f = color.getRed() / (float)255;
        final float f2 = color.getGreen() / (float)255;
        final float f3 = color.getBlue() / (float)255;
        final TreeSet<Integer> set = new TreeSet<Integer>();
        set.add(-1);
        set.add(0);
        set.add(1);
        System.out.println("Received waypoint (" + lIllllIIIlllIIIllIIIIllll.lIIIIIIIIIlIllIIllIlIIlIl() + ")[x" + iiiIllIIllIIIIllIllIIIlIl + ",y" + ilIlIIIlllIIIlIlllIlIllIl + ",z" + iiIllIllIlIlllllllIlIlIII + "][r" + f + ",g" + f2 + ",b" + f3 + "]");
        final lIIllIllIlIllIIIlIlllllIl liIllIllIlIllIIIlIlllllIl2 = new lIIllIllIlIllIIIlIlllllIl(lIllllIIIlllIIIllIIIIllll.lIIIIIIIIIlIllIIllIlIIlIl(), iiiIllIIllIIIIllIllIIIlIl, iiIllIllIlIlllllllIlIlIII, ilIlIIIlllIIIlIlllIlIllIl, true, f, f2, f3, "", liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().IlllIIIlIlllIllIlIIlllIlI(), set, true, true);
        liIllIllIlIllIIIlIlllllIl2.lIIlIlIllIIlIIIlIIIlllIII = lIllllIIIlllIIIllIIIIllll.IllIIIIIIIlIlIllllIIllIII();
        liIllIllIlIllIIIlIlllllIl2.IIIIllIIllIIIIllIllIIIlIl = lIllllIIIlllIIIllIIIIllll.IlllIIIlIlllIllIlIIlllIlI();
        liIllIllIlIllIIIlIlllllIl2.IlIlIIIlllIIIlIlllIlIllIl = true;
        liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().lIIIIIIIIIlIllIIllIlIIlIl(liIllIllIlIllIIIlIlllllIl2);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIIlIlIIlIIIllllllIII lIlIlIIlIlIIlIIIllllllIII) {
        try {
            lIlIlIIlIlIIlIIIllllllIII.lIIIIIIIIIlIllIIllIlIIlIl();
            final lIlIIIIIIlIllIlIllIlIlIlI liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI();
            final String anotherString;
            liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().lIIIIlIIllIIlIIlIIIlIIllI().removeIf(liIllIllIlIllIIIlIlllllIl -> liIllIllIlIllIIIlIlllllIl.IIIIllIIllIIIIllIllIIIlIl.equals(lIlIlIIlIlIIlIIIllllllIII.IlllIIIlIlllIllIlIIlllIlI()) && liIllIllIlIllIIIlIlllllIl.IIIIllIlIIIllIlllIlllllIl && liIllIllIlIllIIIlIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI.equalsIgnoreCase(anotherString));
            final String anotherString2;
            ((lIlIIIllIlIIIlIlIlIIllIlI)liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()).IlIlllIIIIllIllllIllIIlIl().removeIf(liIllIllIlIllIIIlIlllllIl2 -> liIllIllIlIllIIIlIlllllIl2.IIIIllIIllIIIIllIllIIIlIl.equals(lIlIlIIlIlIIlIIIllllllIII.IlllIIIlIlllIllIlIIlllIlI()) && liIllIllIlIllIIIlIlllllIl2.IIIIllIlIIIllIlllIlllllIl && liIllIllIlIllIIIlIlllllIl2.lIIIIlIIllIIlIIlIIIlIIllI.equalsIgnoreCase(anotherString2));
            final String anotherString3;
            ((lIlIIIllIlIIIlIlIlIIllIlI)liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()).llIIlllIIIIlllIllIlIlllIl().lIIIIlIIllIIlIIlIIIlIIllI.removeIf(liIllIllIlIllIIIlIlllllIl3 -> liIllIllIlIllIIIlIlllllIl3.IIIIllIIllIIIIllIllIIIlIl.equals(lIlIlIIlIlIIlIIIllllllIII.IlllIIIlIlllIllIlIIlllIlI()) && liIllIllIlIllIIIlIlllllIl3.IIIIllIlIIIllIlllIlllllIl && liIllIllIlIllIIIlIlllllIl3.lIIIIlIIllIIlIIlIIIlIIllI.equalsIgnoreCase(anotherString3));
            IllllIIlIllIIIlIlllIlIIIl.llIlIlIlllIlllllIIIllIIll.lIIIIIIIIIlIllIIllIlIIlIl();
            liiiIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII().IIIllIllIlIlllllllIlIlIII();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIIIIllIIllIIlIIIIlll illllIIIIllIIllIIlIIIIlll) {
        lIIIlIlIIIlIlIlllIlIlllII.lIIIIlIIllIIlIIlIIIlIIllI(illllIIIIllIIllIIlIIIIlll.lIIIIIIIIIlIllIIllIlIIlIl(), illllIIIIllIIllIIlIIIIlll.IlllIIIlIlllIllIlIIlllIlI(), illllIIIIllIIllIIlIIIIlll.IIIIllIlIIIllIlllIlllllIl());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIIllIllIIllllIIIlIlllI ilIIllIllIIllllIIIlIlllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIllIllIIllllIIIlIlllI.IIIIllIlIIIllIlllIlllllIl(), ilIIllIllIIllllIIIlIlllI.lIIIIIIIIIlIllIIllIlIIlIl(), ilIIllIllIIllllIIIlIlllI.IlllIIIlIlllIllIlIIlllIlI());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIIlIIIIlllIlllIlllllIlI llIIlIIIIlllIlllIlllllIlI) {
        for (final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll : this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl) {
            if (ilIIIIlllIIIlIIllllIIIlll.IIIllIllIlIlllllllIlIlIII().equals(llIIlIIIIlllIlllIlllllIlI.lIIIIIIIIIlIllIIllIlIIlIl().replaceAll("_", "").toLowerCase())) {
                ilIIIIlllIIIlIIllllIIIlll.IIIIllIlIIIllIlllIlllllIl(llIIlIIIIlllIlllIlllllIlI.IlllIIIlIlllIllIlIIlllIlI());
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIlIllllllIlIllllllIlIlll ilIllllllIlIllllllIlIlll) {
        if (ilIllllllIlIllllllIlIlll.lIIIIIIIIIlIllIIllIlIIlIl() != null) {
            IIIlllIllIIllIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(new HashMap());
            for (final Map.Entry<UUID, ArrayList<String>> entry : ilIllllllIlIllllllIlIlll.lIIIIIIIIIlIllIIllIlIIlIl().entrySet()) {
                IIIlllIllIIllIllIlIIIllII.lIllIllIlIIllIllIlIlIIlIl().put(entry.getKey().toString(), entry.getValue());
            }
        }
        else {
            IIIlllIllIIllIllIlIIIllII.lIIIIlIIllIIlIIlIIIlIIllI((Map)null);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIlIlIIIlIIlIIIlllllIIlI ilIlIlIIIlIIlIIIlllllIIlI) {
        final Map<UUID, HashMap<String, Double>> iiiIllIlIIIllIlllIlllllIl = ilIlIlIIIlIIlIIIlllllIIlI.IIIIllIlIIIllIlllIlllllIl();
        final UUID liiiiiiiiIlIllIIllIlIIlIl = ilIlIlIIIlIIlIIIlllllIIlI.lIIIIIIIIIlIllIIllIlIIlIl();
        final long illlIIIlIlllIllIlIIlllIlI = ilIlIlIIIlIIlIIIlllllIIlI.IlllIIIlIlllIllIlIIlllIlI();
        if (!(boolean)this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl().llIlIIIllIIIIlllIlIIIIIlI.IIIIllIlIIIllIlllIlllllIl() || iiiIllIlIIIllIlllIlllllIl == null || iiiIllIlIIIllIlllIlllllIl.isEmpty() || (iiiIllIlIIIllIlllIlllllIl.size() == 1 && iiiIllIlIIIllIlllIlllllIl.containsKey(Minecraft.getMinecraft().thePlayer.llllIIllIIlllllIlIlIIllll()))) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI().clear();
            return;
        }
        int n = 0;
        for (final Map.Entry<UUID, HashMap<String, Double>> entry : iiiIllIlIIIllIlllIlllllIl.entrySet()) {
            IlIlllIlIlIIllllIlllIlIII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey().toString());
            if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI().add(liiiIlIIllIIlIIlIIIlIIllI = new IlIlllIlIlIIllllIlllIlIII(entry.getKey().toString(), liiiiiiiiIlIllIIllIlIIlIl != null && liiiiiiiiIlIllIIllIlIIlIl.equals(entry.getKey())));
                final Random random = new Random();
                if (n < this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl().length) {
                    liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(new Color(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIIIIIIlIllIIllIlIIlIl()[n]));
                }
                else {
                    liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(new Color(random.nextFloat(), random.nextFloat(), random.nextFloat() / 2.0f));
                }
            }
            try {
                liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI((entry.getValue()).get("x"), (entry.getValue()).get("y") + 2, ((Map)entry.getValue()).get("z"), illlIIIlIlllIllIlIIlllIlI);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            ++n;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlIIllIIIIIlIllIIIIllII.lIIIIlIIllIIlIIlIIIlIIllI().removeIf(ilIlllIlIlIIllllIlllIlIII -> !iiiIllIlIIIllIlllIlllllIl.containsKey(UUID.fromString(ilIlllIlIlIIllllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI())));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIlllllIIllIIlIIIlIIIl iiIlIlllllIIllIIlIIIlIIIl) {
        if (iiIlIlllllIIllIIlIIIlIIIl.IlllIIIlIlllIllIlIIlllIlI() == null) {
            this.llIIlllIIIIlllIllIlIlllIl.remove(iiIlIlllllIIllIIlIIIlIIIl.lIIIIIIIIIlIllIIllIlIIlIl());
        }
        else {
            Collections.reverse(iiIlIlllllIIllIIlIIIlIIIl.IlllIIIlIlllIllIlIIlllIlI());
            this.llIIlllIIIIlllIllIlIlllIl.put(iiIlIlllllIIllIIlIIIlIIIl.lIIIIIIIIIlIllIIllIlIIlIl(), iiIlIlllllIIllIIlIIIlIIIl.IlllIIIlIlllIllIlIIlllIlI());
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllllIIlllIlIllIIIlIIlI illllllIIlllIlIllIIIlIIlI) {
        final IIIlIllIIllllIIIllllIllll iiIlIllIIllllIIIllllIllll;
        IIIlIllIIllllIIIllllIllll.IIIllIllIlIlllllllIlIlIII().add(iiIlIllIIllllIIIllllIllll = new IIIlIllIIllllIIIllllIllll(illllllIIlllIlIllIIIlIIlI.lIIIIIIIIIlIllIIllIlIIlIl(), illllllIIlllIlIllIIIlIIlI.IlllIIIlIlllIllIlIIlllIlI(), illllllIIlllIlIllIIIlIIlI.IIIIllIlIIIllIlllIlllllIl(), illllllIIlllIlIllIIIlIIlI.IIIIllIIllIIIIllIllIIIlIl()));
        iiIlIllIIllllIIIllllIllll.lIIIIlIIllIIlIIlIIIlIIllI(illllllIIlllIlIllIIIlIIlI.IlIlIIIlllIIIlIlllIlIllIl().toArray(new String[0]));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIIllIIllIlIIlIIlIIIl illIlIIllIIllIlIIlIIlIIIl) {
        IIIlIllIIllllIIIllllIllll.IIIllIllIlIlllllllIlIlIII().stream().filter(iiIlIllIIllllIIIllllIllll -> iiIlIllIIllllIIIllllIllll.lIIIIIIIIIlIllIIllIlIIlIl().equals(illIlIIllIIllIlIIlIIlIIIl.lIIIIIIIIIlIllIIllIlIIlIl())).forEach(iiIlIllIIllllIIIllllIllll2 -> iiIlIllIIllllIIIllllIllll2.lIIIIlIIllIIlIIlIIIlIIllI(illIlIIllIIllIlIIlIIlIIIl.IlllIIIlIlllIllIlIIlllIlI().toArray(new String[0])));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIIIllIlIllIllIIlIIlIlll liiiIllIlIllIllIIlIIlIlll) {
        IIIlIllIIllllIIIllllIllll.IIIllIllIlIlllllllIlIlIII().removeIf(iiIlIllIIllllIIIllllIllll -> iiIlIllIIllllIIIllllIllll.lIIIIIIIIIlIllIIllIlIIlIl().equals(liiiIllIlIllIllIIlIIlIlll.lIIIIIIIIIlIllIIllIlIIlIl()));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIlIlIlIIIIllllIllIIIIll llIlIlIlIIIIllllIllIIIIll) {
        IIIlIIIIllIIIlIIIIIlllllI iiIlIIIIllIIIlIIIIIlllllI = IIIlIIIIllIIIlIIIIIlllllI.lIIIIIIIIIlIllIIllIlIIlIl;
        if (llIlIlIlIIIIllllIllIIIIll.lIIIIIIIIIlIllIIllIlIIlIl().toLowerCase().equals("subtitle")) {
            iiIlIIIIllIIIlIIIIIlllllI = IIIlIIIIllIIIlIIIIIlllllI.lIIIIlIIllIIlIIlIIIlIIllI;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIlIIlIlIIIlllIIlIllllll().lIIIIlIIllIIlIIlIIIlIIllI().add(new llllIlIIIIIllIIlIlllIllll(llIlIlIlIIIIllllIllIIIIll.IlllIIIlIlllIllIlIIlllIlI(), iiIlIIIIllIIIlIIIIIlllllI, llIlIlIlIIIIllllIllIIIIll.IIIllIllIlIlllllllIlIlIII(), llIlIlIlIIIIllllIllIIIIll.IIIIllIlIIIllIlllIlllllIl(), llIlIlIlIIIIllllIllIIIIll.IIIIllIIllIIIIllIllIIIlIl(), llIlIlIlIIIIllllIllIIIIll.IlIlIIIlllIIIlIlllIlIllIl()));
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIllllIllIIlIIIIlllIl illllIllllIllIIlIIIIlllIl) {
        switch (llllIlIlllIIlIlIIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI[illllIllllIllIIlIIIIlllIl.lIIIIIIIIIlIllIIllIlIIlIl().ordinal()]) {
            case 1: {
                final String ilIlIIIlllIIIlIlllIlIllIl = illllIllllIllIIlIIIIlllIl.IlIlIIIlllIIIlIlllIlIllIl();
                switch (ilIlIIIlllIIIlIlllIlIllIl) {
                    case "NEUTRAL": {
                        IIIIIlllIllIIIIllIllIIIII.lIIIIlIIllIIlIIlIIIlIIllI = llIllllIIIIIlIllIlIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI;
                        break;
                    }
                    case "FORCED_OFF": {
                        IIIIIlllIllIIIIllIllIIIII.lIIIIlIIllIIlIIlIIIlIIllI = llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI;
                        break;
                    }
                }
                break;
            }
            case 2: {
                this.IIIIllIlIIIllIlllIlllllIl = illllIllllIllIIlIIIIlllIl.IIIIllIIllIIIIllIllIIIlIl();
                break;
            }
            case 3: {
                this.lIIIIlIIllIIlIIlIIIlIIllI("Voice is: " + (illllIllllIllIIlIIIIlllIl.IIIIllIIllIIIIllIllIIIlIl() ? "enabled" : "disabled"));
                this.IIIIllIIllIIIIllIllIIIlIl = illllIllllIllIIlIIIIlllIl.IIIIllIIllIIIIllIllIIIlIl();
                break;
            }
            case 4: {
                this.IllIIIIIIIlIlIllllIIllIII = illllIllllIllIIlIIIIlllIl.IIIIllIIllIIIIllIllIIIlIl();
                break;
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIlllIIllIIlIlIIll lllIIIIIIlllIIllIIlIlIIll) {
        try {
            Message.f(lllIIIIIIlllIIllIIlIlIIll.lIIIIIIIIIlIllIIllIlIIlIl().toString(), lllIIIIIIlllIIllIIlIlIIll.IlllIIIlIlllIllIlIIlllIlI());
        }
        catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl().lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIlllIIllIIlIlIIll.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llIllllllllIIIIlllIIIllll llIllllllllIIIIlllIIIllll) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("Voice Channel Received: " + llIllllllllIIIIlllIIIllll.IlllIIIlIlllIllIlIIlllIlI());
        this.lIIIIlIIllIIlIIlIIIlIIllI("Channel has " + llIllllllllIIIIlllIIIllll.IIIIllIlIIIllIlllIlllllIl().size() + " members");
        if (this.lIIIIIIIIIlIllIIllIlIIlIl(llIllllllllIIIIlllIIIllll.lIIIIIIIIIlIllIIllIlIIlIl())) {
            return;
        }
        if (this.IlIlIIIlllIIIlIlllIlIllIl == null) {
            this.IlIlIIIlllIIIlIlllIlIllIl = new ArrayList();
        }
        final llIIIlllllIIllIlllIlIlIll llIIIlllllIIllIlllIlIlIll;
        this.IlIlIIIlllIIIlIlllIlIllIl.add(llIIIlllllIIllIlllIlIlIll = new llIIIlllllIIllIlllIlIlIll(llIllllllllIIIIlllIIIllll.lIIIIIIIIIlIllIIllIlIIlIl(), llIllllllllIIIIlllIIIllll.IlllIIIlIlllIllIlIIlllIlI()));
        final ArrayList<llIlIlIlIlIlIllIIIIlIIIII> list = new ArrayList<>();
        for (final Map.Entry<UUID, V> entry : llIllllllllIIIIlllIIIllll.IIIIllIlIIIllIlllIlllllIl().entrySet()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI("Added member [" + (String)entry.getValue() + "]");
            final llIlIlIlIlIlIllIIIIlIIIII liiiIlIIllIIlIIlIIIlIIllI = llIIIlllllIIllIlllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(entry.getKey(), (String)entry.getValue());
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                list.add(liiiIlIIllIIlIIlIIIlIIllI);
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(list);
        for (final Map.Entry<UUID, V> entry2 : llIllllllllIIIIlllIIIllll.IIIIllIIllIIIIllIllIIIlIl().entrySet()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI("Added listener [" + (String)entry2.getValue() + "]");
            llIIIlllllIIllIlllIlIlIll.lIIIIIIIIIlIllIIllIlIIlIl(entry2.getKey(), (String)entry2.getValue());
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIllIlIlllIllIIllllIlIl ilIIllIlIlllIllIIllllIlIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("Channel Update: " + ilIIllIlIlllIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl() + " (" + ilIIllIlIlllIllIIllllIlIl.lIIIIIIIIIlIllIIllIlIIlIl() + ")");
        if (this.IlIlIIIlllIIIlIlllIlIllIl == null) {
            return;
        }
        final llIIIlllllIIllIlllIlIlIll illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI(ilIIllIlIlllIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI());
        if (illlIIIlIlllIllIlIIlllIlI == null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(ilIIllIlIlllIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI().toString());
            return;
        }
        switch (ilIIllIlIlllIllIIllllIlIl.lIIIIIIIIIlIllIIllIlIIlIl()) {
            case 0: {
                final llIlIlIlIlIlIllIIIIlIIIII liiiIlIIllIIlIIlIIIlIIllI = illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl(), ilIIllIlIlllIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl());
                if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI((List)ImmutableList.of((Object)liiiIlIIllIIlIIlIIIlIIllI));
                    break;
                }
                break;
            }
            case 1: {
                illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl());
                break;
            }
            case 2: {
                if (ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl().toString().equals(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl())) {
                    this.IIIllIllIlIlllllllIlIlIII = illlIIIlIlllIllIlIIlllIlI;
                    final Iterator<llIIIlllllIIllIlllIlIlIll> iterator = this.IlIlIIIlllIIIlIlllIlIllIl.iterator();
                    while (iterator.hasNext()) {
                        iterator.next().lIIIIIIIIIlIllIIllIlIIlIl(ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl());
                    }
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl + "Joined " + illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl() + " channel. Press '" + Keyboard.getKeyName(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl().IlllIIIlIlllIllIlIIlllIlI.lIIIIllIIlIlIllIIIlIllIlI()) + "' to talk!" + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII));
                }
                else if (this.IIIllIllIlIlllllllIlIlIII == illlIIIlIlllIllIlIIlllIlI) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl + ilIIllIlIlllIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl() + IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl + " joined " + illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl() + " channel. Press '" + Keyboard.getKeyName(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl.lIIIIllIIlIlIllIIIlIllIlI()) + "'!" + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII));
                }
                illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl(), ilIIllIlIlllIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl());
                break;
            }
            case 3: {
                if (this.IIIllIllIlIlllllllIlIlIII == illlIIIlIlllIllIlIIlllIlI && !ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl().toString().equals(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl())) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI(IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl + ilIIllIlIlllIllIIllllIlIl.IIIIllIIllIIIIllIllIIIlIl() + IlIllllIIlIIllIlIlllllIlI.llIIlllIIIIlllIllIlIlllIl + " left " + illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl() + " channel. Press '" + Keyboard.getKeyName(this.lIIIIlIIllIIlIIlIIIlIIllI.IlIlIIIlllIIIlIlllIlIllIl().lIIIIIIIIIlIllIIllIlIIlIl.lIIIIllIIlIlIllIIIlIllIlI()) + "'!" + IlIllllIIlIIllIlIlllllIlI.lIIlIIllIIIIIlIllIIIIllII));
                }
                illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(ilIIllIlIlllIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl());
                break;
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final List<llIlIlIlIlIlIllIIIIlIIIII> list) {
        for (final llIlIlIlIlIlIllIIIIlIIIII llIlIlIlIlIlIllIIIIlIIIII : list) {
            if (llIlIlIlIlIlIllIIIIlIIIII != null && this.lIIIIllIIlIlIllIIIlIllIlI.contains(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()) && !this.IlllIllIlIIIIlIIlIIllIIIl.contains(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI())) {
                this.IlllIllIlIIIIlIIlIIllIIIl.add(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI());
                this.lIIIIlIIllIIlIIlIIIlIIllI(new lIIlIlIIIIIIlIllIIIlIlIII(llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI()));
            }
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIllIIIlIlIIIlIIllIlI illIIIllIIIlIlIIIlIIllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("Deleted channel: " + illIIIllIIIlIlIIIlIIllIlI.lIIIIIIIIIlIllIIllIlIIlIl().toString());
        if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            this.IlIlIIIlllIIIlIlllIlIllIl.removeIf(llIIIlllllIIllIlllIlIlIll -> llIIIlllllIIllIlllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI().equals(illIIIllIIIlIlIIIlIIllIlI.lIIIIIIIIIlIllIIllIlIIlIl()));
        }
        if (this.IIIllIllIlIlllllllIlIlIII != null && this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI().equals(illIIIllIIIlIlIIIlIIllIlI.lIIIIIIIIIlIllIIllIlIIlIl())) {
            this.IIIllIllIlIlllllllIlIlIII = null;
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIlIIllIllIlllIlllllIII illIlIIllIllIlllIlllllIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("World Update: " + illIlIIllIllIlllIlllllIII.lIIIIIIIIIlIllIIllIlIIlIl());
        this.IlIlllIIIIllIllllIllIIlIl = illIlIIllIllIlllIlllllIII.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIlIlIIlIIlIIlIIlllllII ilIIlIlIIlIIlIIlIIlllllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI("Retrieved " + ilIIlIlIIlIIlIIlIIlllllII.lIIIIIIIIIlIllIIllIlIIlIl());
        CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI(ilIIlIlIIlIIlIIlIIlllllII.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllllIllIIlIIlllllllllIIl illllIllIIlIIlllllllllIIl) {
        CheatBreaker.getInstance().IllIlIIIIlllIIllIIlllIIlI().lIIIIlIIllIIlIIlIIIlIIllI(illllIllIIlIIlllllllllIIl.lIIIIIIIIIlIllIIllIlIIlIl(), illllIllIIlIIlllllllllIIl.IlllIIIlIlllIllIlIIlllIlI(), illllIllIIlIIlllllllllIIl.IlIlIIIlllIIIlIlllIlIllIl(), illllIllIIlIIlllllllllIIl.IIIllIllIlIlllllllIlIlIII(), illllIllIIlIIlllllllllIIl.IllIIIIIIIlIlIllllIIllIII(), illllIllIIlIIlllllllllIIl.lIIIIllIIlIlIllIIIlIllIlI(), illllIllIIlIIlllllllllIIl.IlllIllIlIIIIlIIlIIllIIIl(), illllIllIIlIIlllllllllIIl.IIIIllIIllIIIIllIllIIIlIl(), illllIllIIlIIlllllllllIIl.IIIIllIlIIIllIlllIlllllIl());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIlIIlllIllIIllIIIIlIlI iiiIlIIlllIllIIllIIIIlIlI) {
        CheatBreaker.getInstance().IllIlIIIIlllIIllIIlllIIlI().lIIIIlIIllIIlIIlIIIlIIllI(iiiIlIIlllIllIIllIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl(), iiiIlIIlllIllIIllIIIIlIlI.IlllIIIlIlllIllIlIIlllIlI(), iiiIlIIlllIllIIllIIIIlIlI.IIIIllIlIIIllIlllIlllllIl(), iiiIlIIlllIllIIllIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl(), iiiIlIIlllIllIIllIIIIlIlI.IlIlIIIlllIIIlIlllIlIllIl(), iiiIlIIlllIllIIllIIIIlIlI.IIIllIllIlIlllllllIlIlIII());
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final llllllIIllIIlllllllIIlIlI llllllIIllIIlllllllIIlIlI) {
        CheatBreaker.getInstance().IllIlIIIIlllIIllIIlllIIlI().lIIIIlIIllIIlIIlIIIlIIllI(llllllIIllIIlllllllIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl());
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final UUID uuid) {
        return this.IlllIIIlIlllIllIlIIlllIlI(uuid) != null;
    }
    
    private llIIIlllllIIllIlllIlIlIll IlllIIIlIlllIllIlIIlllIlI(final UUID obj) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl == null) {
            return null;
        }
        for (final llIIIlllllIIllIlllIlIlIll llIIIlllllIIllIlllIlIlIll : this.IlIlIIIlllIIIlIlllIlIllIl) {
            if (llIIIlllllIIllIlllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI().equals(obj)) {
                return llIIIlllllIIllIlllIlIlIll;
            }
        }
        return null;
    }
    
    public llIlIlIlIlIlIllIIIIlIIIII lIIIIlIIllIIlIIlIIIlIIllI(final UUID obj) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl == null || this.IIIllIllIlIlllllllIlIlIII == null) {
            return null;
        }
        for (final llIlIlIlIlIlIllIIIIlIIIII llIlIlIlIlIlIllIIIIlIIIII : this.IIIllIllIlIlllllllIlIlIII.IlllIIIlIlllIllIlIIlllIlI()) {
            if (llIlIlIlIlIlIllIIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI().equals(obj)) {
                return llIlIlIlIlIlIllIIIIlIIIII;
            }
        }
        return null;
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final String str) {
        System.out.println("\u001b[31m[CheatBreaker]\u001b[0m " + str);
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public boolean IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public boolean IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public List<llIIIlllllIIllIlllIlIlIll> IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public llIIIlllllIIllIlllIlIlIll IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public List IllIIIIIIIlIlIllllIIllIII() {
        return this.lIIIIllIIlIlIllIIIlIllIlI;
    }
    
    public String lIIIIllIIlIlIllIIIlIllIlI() {
        return this.IlIlllIIIIllIllllIllIIlIl;
    }
    
    public Map IlllIllIlIIIIlIIlIIllIIIl() {
        return this.llIIlllIIIIlllIllIlIlllIl;
    }
}
