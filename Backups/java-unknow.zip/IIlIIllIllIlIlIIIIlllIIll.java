import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIllIlIlIIIIlllIIll extends lIlIllIlllIIlIllIIllIlllI
{
    public static final double[] lIIIlllIlIlllIIIIIIIIIlII;
    private static final int[] IIIIlIIIlllllllllIlllIlll;
    
    protected IIlIIllIllIlIlIIIIlllIIll(final boolean b) {
        super(b);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, (((illlIIIlIlllIllIlIIlllIlI & 0xC) >> 2) + 1 << 2 & 0xC) | (illlIIIlIlllIllIlIIlllIlI & 0x3), 3);
        return true;
    }
    
    @Override
    protected int IllIIIIIIIlIlIllllIIllIII(final int n) {
        return IIlIIllIllIlIlIIIIlllIIll.IIIIlIIIlllllllllIlllIlll[(n & 0xC) >> 2] * 2;
    }
    
    @Override
    protected lIlIllIlllIIlIllIIllIlllI IIIIlIIIlllllllllIlllIlll() {
        return IllllllIllIIlllIllIIlIIll.IlIllIIllIIIIIllIlIIIIIIl;
    }
    
    @Override
    protected lIlIllIlllIIlIllIIllIlllI IlIllllIIIlIllllIIIIIllII() {
        return IllllllIllIIlllIllIIlIIll.lIllIllIllllllIllIlllIlIl;
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final Random random, final int n2) {
        return IIlIlIllIlIIllIllIllIIIll.lIIIlIIlIIIIIllIIlIlIlIII;
    }
    
    @Override
    public lIIlllIIIlIllllllIlIlIIII IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return IIlIlIllIlIIllIllIllIIIll.lIIIlIIlIIIIIllIIlIlIlIII;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 15;
    }
    
    @Override
    public boolean IIIllIllIlIlllllllIlIlIII(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return this.IllIIIIIIIlIlIllllIIllIII(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4) > 0;
    }
    
    @Override
    protected boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return lIlIllIlllIIlIllIIllIlllI.IIIIllIlIIIllIlllIlllllIl(illlllllIlllIIllllIIlIll);
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        if (this.lIIIIlllIIlIlllllIlIllIII) {
            final int illlIIIlIlllIllIlIIlllIlI = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
            final int illlIllIlIIIIlIIlIIllIIIl = IIlllllIllIIIIIllIlIlIIlI.IlllIllIlIIIIlIIlIIllIIIl(illlIIIlIlllIllIlIIlllIlI);
            final double n4 = n + 0.93333334f * 0.53571427f + (random.nextFloat() - 0.835443f * 0.5984849f) * (0.7124999946914614 * 0.28070175647735596);
            final double n5 = n2 + 2.6842105f * 0.14901961f + (random.nextFloat() - 1.7962962f * 0.27835053f) * (0.23599999437332167 * 0.8474576473236084);
            final double n6 = n3 + 1.6f * 0.3125f + (random.nextFloat() - 1.1756756f * 0.42528737f) * (0.4303797483444214 * 0.4647058807236101);
            double n7 = 0.0;
            double n8 = 0.0;
            if (random.nextInt(2) == 0) {
                switch (illlIllIlIIIIlIIlIIllIIIl) {
                    case 0: {
                        n8 = -0.28952204410444415 * 1.0793651342391968;
                        break;
                    }
                    case 1: {
                        n7 = 2.5 * 0.125;
                        break;
                    }
                    case 2: {
                        n8 = 1.8181818723678589 * 0.17187499487772598;
                        break;
                    }
                    case 3: {
                        n7 = 1.9600000381469727 * -0.15943877240708854;
                        break;
                    }
                }
            }
            else {
                final int n9 = (illlIIIlIlllIllIlIIlllIlI & 0xC) >> 2;
                switch (illlIllIlIIIIlIIlIIllIIIl) {
                    case 0: {
                        n8 = IIlIIllIllIlIlIIIIlllIIll.lIIIlllIlIlllIIIIIIIIIlII[n9];
                        break;
                    }
                    case 1: {
                        n7 = -IIlIIllIllIlIlIIIIlllIIll.lIIIlllIlIlllIIIIIIIIIlII[n9];
                        break;
                    }
                    case 2: {
                        n8 = -IIlIIllIllIlIlIIIIlllIIll.lIIIlllIlIlllIIIIIIIIIlII[n9];
                        break;
                    }
                    case 3: {
                        n7 = IIlIIllIllIlIlIIIIlllIIll.lIIIlllIlIlllIIIIIIIIIlII[n9];
                        break;
                    }
                }
            }
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI("reddust", n4 + n7, n5, n6 + n8, 0.0, 0.0, 0.0);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll, final int n4) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll, n4);
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    static {
        lIIIlllIlIlllIIIIIIIIIlII = new double[] { 36.5 * -0.0017123287671232876, 0.004261363544001069 * 14.666666984558105, 0.807692289352417 * 0.23214286241401633, 0.302083345337047 * 1.034482717514038 };
        IIIIlIIIlllllllllIlllIlll = new int[] { 1, 2, 3, 4 };
    }
}
