// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIllIllllIlIlIlIllI extends llIIIIIIlllIIlIlIIllIIlII
{
    public IIIIlllIllIllllIlIlIlIllI() {
        this.IIIllIllIlIlllllllIlIlIII = true;
    }
    
    public IIIIlllIllIllllIlIlIlIllI(final int n, final byte liiiiiiiiIlIllIIllIlIIlIl, final byte illlIIIlIlllIllIlIIlllIlI, final byte iiiIllIlIIIllIlllIlllllIl, final byte iiiIllIIllIIIIllIllIIIlIl, final byte ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIllIllIlIlllllllIlIlIII = true;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII);
        this.lIIIIIIIIIlIllIIllIlIIlIl = lIlIllllllllIlIIIllIIllII.readByte();
        this.IlllIIIlIlllIllIlIIlllIlI = lIlIllllllllIlIIIllIIllII.readByte();
        this.IIIIllIlIIIllIlllIlllllIl = lIlIllllllllIlIIIllIIllII.readByte();
        this.IIIIllIIllIIIIllIllIIIlIl = lIlIllllllllIlIIIllIIllII.readByte();
        this.IlIlIIIlllIIIlIlllIlIllIl = lIlIllllllllIlIIIllIIllII.readByte();
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        super.lIIIIIIIIIlIllIIllIlIIlIl(lIlIllllllllIlIIIllIIllII);
        lIlIllllllllIlIIIllIIllII.writeByte(this.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IlllIIIlIlllIllIlIIlllIlI);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IIIIllIlIIIllIlllIlllllIl);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IIIIllIIllIIIIllIllIIIlIl);
        lIlIllllllllIlIIIllIIllII.writeByte(this.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return super.lIIIIIIIIIlIllIIllIlIIlIl() + String.format(", xa=%d, ya=%d, za=%d, yRot=%d, xRot=%d", this.lIIIIIIIIIlIllIIllIlIIlIl, this.IlllIIIlIlllIllIlIIlllIlI, this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IlIlIIIlllIIIlIlllIlIllIl);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        super.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
