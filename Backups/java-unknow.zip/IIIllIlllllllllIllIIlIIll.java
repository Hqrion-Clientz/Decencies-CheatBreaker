import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIlllllllllIllIIlIIll extends lIIIIIllIlIIIllllIlIlIIIl
{
    public static final String[] lIIIIlllIIlIlllllIlIllIII;
    private static final String[] IlIllllIIIlIllllIIIIIllII;
    public int lIIIlllIlIlllIIIIIIIIIlII;
    private IlllIllIIIIlllIllIIIIIlII[] IlIIIIllIIIIIlllIIlIIlllI;
    
    protected IIIllIlllllllllIllIIlIIll() {
        super(Material.IIIllIllIlIlllllllIlIlIII);
        this.IlllIIIlIlllIllIlIIlllIlI(0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public IlllIllIIIIlllIllIIIIIlII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        if (this.lIIIlllIlIlllIIIIIIIIIlII == 3 && n == 1) {
            return this.IlIIIIllIIIIIlllIIlIIlllI[(n2 >> 2) % this.IlIIIIllIIIIIlllIIlIIlllI.length];
        }
        return this.IIlIIllIIIllllIIlllIllIIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IllIIIIlllllIllIlIIllllIl illIIIIlllllIllIlIIllllIl) {
        this.IIlIIllIIIllllIIlllIllIIl = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI("anvil_base");
        this.IlIIIIllIIIIIlllIIlIIlllI = new IlllIllIIIIlllIllIIIIIlII[IIIllIlllllllllIllIIlIIll.IlIllllIIIlIllllIIIIIllII.length];
        for (int i = 0; i < this.IlIIIIllIIIIIlllIIlIIlllI.length; ++i) {
            this.IlIIIIllIIIIIlllIIlIIlllI[i] = illIIIIlllllIllIlIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI(IIIllIlllllllllIllIIlIIll.IlIllllIIIlIllllIIIIIllII[i]);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final EntityLivingBase entityLivingBase, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        int n4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(entityLivingBase.IllllIllllIlIIIlIIIllllll * 4 / 360 + 0.11607142264137493 * 4.307692527770996) & 0x3;
        final int n5 = iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) >> 2;
        final int n6 = ++n4 % 4;
        if (n6 == 0) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0x2 | n5 << 2, 2);
        }
        if (n6 == 1) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0x3 | n5 << 2, 2);
        }
        if (n6 == 2) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0x0 | n5 << 2, 2);
        }
        if (n6 == 3) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, 0x1 | n5 << 2, 2);
        }
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final int n4, final float n5, final float n6, final float n7) {
        if (iiiiiIllIlIIIIlIlllIllllI.IllIlIlIllllIlIIllllIIlll) {
            return true;
        }
        lIllIIIIlIIlIllIIIlIlIlll.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3);
        return true;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 35;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl(final int n) {
        return n >> 2;
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3) {
        final int n4 = liIllIIIllIIIIllIllIIllIl.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x3;
        if (n4 != 3 && n4 != 1) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.21428572f * 0.5833333f, 0.0f, 0.0f, 0.8783784f * 0.99615383f, 1.0f, 1.0f);
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, 2.5555556f * 0.048913043f, 1.0f, 1.0f, 0.5833333f * 1.5f);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIIlIllllllIlIlIIII liIlllIIIlIllllllIlIlIIII, final IIllllIllIIllIIllIlIIIIII illllIllIIllIIllIlIIIIII, final List list) {
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 0));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 1));
        list.add(new lIlIlIlIlIllllIlllIIIlIlI(liIlllIIIlIllllllIlIlIIII, 1, 2));
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IIIllllIllIlIllIlIIIIIIlI iiIllllIllIlIllIlIIIIIIlI) {
        iiIllllIllIlIllIlIIIIIIlI.sendClickBlockToController(true);
    }
    
    @Override
    public void IIIllIllIlIlllllllIlIlIII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final int n4) {
        iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(1022, n, n2, n3, 0);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    static {
        lIIIIlllIIlIlllllIlIllIII = new String[] { "intact", "slightlyDamaged", "veryDamaged" };
        IlIllllIIIlIllllIIIIIllII = new String[] { "anvil_top_damaged_0", "anvil_top_damaged_1", "anvil_top_damaged_2" };
    }
}
