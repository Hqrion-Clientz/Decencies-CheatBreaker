// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIlIlIlllIIlIIlIIlII extends lIllIlIlIIlIllIllllIllIIl
{
    public static lIIlIlllIIIIlIIIllIlIIIII lIIIIlIIllIIlIIlIIIlIIllI;
    public static lIIlIlllIIIIlIIIllIlIIIII lIIIIIIIIIlIllIIllIlIIlIl;
    public static lIIlIlllIIIIlIIIllIlIIIII IlllIIIlIlllIllIlIIlllIlI;
    public static lIIlIlllIIIIlIIIllIlIIIII IIIIllIlIIIllIlllIlllllIl;
    public static lIIlIlllIIIIlIIIllIlIIIII IIIIllIIllIIIIllIllIIIlIl;
    public static lIIlIlllIIIIlIIIllIlIIIII IlIlIIIlllIIIlIlllIlIllIl;
    public static lIIlIlllIIIIlIIIllIlIIIII IIIllIllIlIlllllllIlIlIII;
    public static lIIlIlllIIIIlIIIllIlIIIII IllIIIIIIIlIlIllllIIllIII;
    public static lIIlIlllIIIIlIIIllIlIIIII lIIIIllIIlIlIllIIIlIllIlI;
    public static lIIlIlllIIIIlIIIllIlIIIII IlllIllIlIIIIlIIlIIllIIIl;
    public static lIIlIlllIIIIlIIIllIlIIIII IlIlllIIIIllIllllIllIIlIl;
    public static lIIlIlllIIIIlIIIllIlIIIII llIIlllIIIIlllIllIlIlllIl;
    public static lIIlIlllIIIIlIIIllIlIIIII lIIlIlIllIIlIIIlIIIlllIII;
    
    public IIlIIlIlIlIlllIIlIIlIIlII(final String s) {
        super(s);
        this.IlllIIIlIlllIllIlIIlllIlI(true);
        IIlIIlIlIlIlllIIlIIlIIlII.lIIIIlIIllIIlIIlIIIlIIllI = new lIIlIlllIIIIlIIIllIlIIIII(this, "Trimp").lIIIIIIIIIlIllIIllIlIIlIl(true);
        IIlIIlIlIlIlllIIlIIlIIlII.lIIIIIIIIIlIllIIllIlIIlIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Trimp Multiplier").lIIIIIIIIIlIllIIllIlIIlIl(2.0766666f * 0.6741573f).lIIIIlIIllIIlIIlIIIlIIllI((Object)1.0f, 4);
        IIlIIlIlIlIlllIIlIIlIIlII.IlllIIIlIlllIllIlIIlllIlI = new lIIlIlllIIIIlIIIllIlIIIII(this, "Hard cap").lIIIIIIIIIlIllIIllIlIIlIl(2.0f).lIIIIlIIllIIlIIlIIIlIIllI((Object)1.0f, 4);
        IIlIIlIlIlIlllIIlIIlIIlII.IIIIllIlIIIllIlllIlllllIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Soft cap").lIIIIIIIIIlIllIIllIlIIlIl(1.465625f * 0.95522386f).lIIIIlIIllIIlIIlIIIlIIllI((Object)1.0f, 4);
        IIlIIlIlIlIlllIIlIIlIIlII.IIIIllIIllIIIIllIllIIIlIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Soft cap degen").lIIIIIIIIIlIllIIllIlIIlIl(0.45948276f * 1.4146341f).lIIIIlIIllIIlIIlIIIlIIllI((Object)(0.22777778f * 0.4390244f), 4);
        IIlIIlIlIlIlllIIlIIlIIlII.IlIlIIIlllIIIlIlllIlIllIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Sharking").lIIIIIIIIIlIllIIllIlIIlIl(true);
        IIlIIlIlIlIlllIIlIIlIIlII.IIIllIllIlIlllllllIlIlIII = new lIIlIlllIIIIlIIIllIlIIIII(this, "Sharking surface tension").lIIIIIIIIIlIllIIllIlIIlIl(1.7647058963775635 * 0.11333333243264093).lIIIIlIIllIIlIIlIIIlIIllI((Object)0.0, 1.0);
        IIlIIlIlIlIlllIIlIIlIIlII.IllIIIIIIIlIlIllllIIllIII = new lIIlIlllIIIIlIIIllIlIIIII(this, "Sharking water friction").lIIIIIIIIIlIllIIllIlIIlIl(0.3132530152797699 * 0.3192307659375245).lIIIIlIIllIIlIIlIIIlIIllI((Object)0.0, 1.0);
        IIlIIlIlIlIlllIIlIIlIIlII.lIIIIllIIlIlIllIIIlIllIlI = new lIIlIlllIIIIlIIIllIlIIIII(this, "Accelerate").lIIIIIIIIIlIllIIllIlIIlIl(20).lIIIIlIIllIIlIIlIIIlIIllI((Object)5, 100);
        IIlIIlIlIlIlllIIlIIlIIlII.IlllIllIlIIIIlIIlIIllIIIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Air accelerate").lIIIIIIIIIlIllIIllIlIIlIl(28).lIIIIlIIllIIlIIlIIIlIIllI((Object)5, 150);
        IIlIIlIlIlIlllIIlIIlIIlII.lIIlIlIllIIlIIIlIIIlllIII = new lIIlIlllIIIIlIIIllIlIIIII(this, "Max air accel per tick").lIIIIIIIIIlIllIIllIlIIlIl(0.022931034859805844 * 4.142857074737549).lIIIIlIIllIIlIIlIIIlIIllI((Object)0.0, 1.0);
        IIlIIlIlIlIlllIIlIIlIIlII.IlIlllIIIIllIllllIllIIlIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Uncapped BunnyHop").lIIIIIIIIIlIllIIllIlIIlIl(true);
        IIlIIlIlIlIlllIIlIIlIIlII.llIIlllIIIIlllIllIlIlllIl = new lIIlIlllIIIIlIIIllIlIIIII(this, "Increased FallDistance").lIIIIIIIIIlIllIIllIlIIlIl(0.0).lIIIIlIIllIIlIIlIIIlIIllI((Object)0.0, 10);
    }
    
    public static boolean lIllIllIlIIllIllIlIlIIlIl() {
        return CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IllIllIIIlIIlllIIIllIllII.IIIIllIIllIIIIllIllIIIlIl() && CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IllIllIIIlIIlllIIIllIllII.IlIlIIIlllIIIlIlllIlIllIl();
    }
}
