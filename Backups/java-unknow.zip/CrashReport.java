import org.apache.logging.log4j.LogManager;
import java.awt.Component;
import javax.swing.JOptionPane;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.util.UUID;
import java.io.FileWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import org.apache.commons.io.IOUtils;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.apache.commons.lang3.ArrayUtils;
import java.util.concurrent.Callable;
import java.util.ArrayList;
import java.io.File;
import java.util.List;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class CrashReport
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private final String lIIIIIIIIIlIllIIllIlIIlIl;
    private final Throwable IlllIIIlIlllIllIlIIlllIlI;
    private final lIlIllIIIIIlllIlllIIIllIl IIIIllIlIIIllIlllIlllllIl;
    private final List IIIIllIIllIIIIllIllIIIlIl;
    private File IlIlIIIlllIIIlIlllIlIllIl;
    private boolean IIIllIllIlIlllllllIlIlIII;
    private StackTraceElement[] IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI;
    
    public CrashReport(final String liiiiiiiiIlIllIIllIlIIlIl, final Throwable illlIIIlIlllIllIlIIlllIlI) {
        this.IIIIllIlIIIllIlllIlllllIl = new lIlIllIIIIIlllIlllIIIllIl(this, "System Details");
        this.IIIIllIIllIIIIllIllIIIlIl = new ArrayList();
        this.IIIllIllIlIlllllllIlIlIII = true;
        this.IllIIIIIIIlIlIllllIIllIII = new StackTraceElement[0];
        this.lIIIIllIIlIlIllIIIlIllIlI = false;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIllIllIlIlllllllIlIlIII();
    }
    
    private void IIIllIllIlIlllllllIlIlIII() {
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("Minecraft Version", new lIIlIlIlIllIIIIlIIlllIIIl(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("Operating System", new lIIlIIIIIlIlllIlIIlIlIlll(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("Java Version", new IIIlIIIlIIlIIlIIlIlllllIl(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("Java VM Version", new llIIllIlIIlIIllIIIlIIIIll(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("Memory", new IlIIIIllIllIIlIllllIIlIll(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("JVM Flags", new IlIlIlIlIllllIlIIlIlIllll(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("AABB Pool Size", new IIIlllIIIllIlIIllIllIlIII(this));
        this.IIIIllIlIIIllIlllIlllllIl.addCrashSectionCallable("IntCache", new lllIlIIIIIIIIIIlIIIllIIII(this));
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return (this.lIIIIIIIIIlIllIIllIlIIlIl == null) ? "Unknown" : this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public Throwable lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final StringBuilder sb) {
        if ((this.IllIIIIIIIlIlIllllIIllIII == null || this.IllIIIIIIIlIlIllllIIllIII.length <= 0) && this.IIIIllIIllIIIIllIllIIIlIl.size() > 0) {
            this.IllIIIIIIIlIlIllllIIllIII = (StackTraceElement[])ArrayUtils.subarray((Object[])this.IIIIllIIllIIIIllIllIIIlIl.get(0).lIIIIlIIllIIlIIlIIIlIIllI(), 0, 1);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII != null && this.IllIIIIIIIlIlIllllIIllIII.length > 0) {
            sb.append("-- Head --\n");
            sb.append("Stacktrace:\n");
            final StackTraceElement[] illIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII;
            for (int length = illIIIIIIIlIlIllllIIllIII.length, i = 0; i < length; ++i) {
                sb.append("\t").append("at ").append(illIIIIIIIlIlIllllIIllIII[i].toString());
                sb.append("\n");
            }
            sb.append("\n");
        }
        this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(sb);
    }
    
    public String IlllIIIlIlllIllIlIIlllIlI() {
        StringWriter out = null;
        PrintWriter s = null;
        Throwable illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        if (illlIIIlIlllIllIlIIlllIlI.getMessage() == null) {
            if (illlIIIlIlllIllIlIIlllIlI instanceof NullPointerException) {
                illlIIIlIlllIllIlIIlllIlI = new NullPointerException(this.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            else if (illlIIIlIlllIllIlIIlllIlI instanceof StackOverflowError) {
                illlIIIlIlllIllIlIIlllIlI = new StackOverflowError(this.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            else if (illlIIIlIlllIllIlIIlllIlI instanceof OutOfMemoryError) {
                illlIIIlIlllIllIlIIlllIlI = new OutOfMemoryError(this.lIIIIIIIIIlIllIIllIlIIlIl);
            }
            illlIIIlIlllIllIlIIlllIlI.setStackTrace(this.IlllIIIlIlllIllIlIIlllIlI.getStackTrace());
        }
        String s2 = illlIIIlIlllIllIlIIlllIlI.toString();
        try {
            out = new StringWriter();
            s = new PrintWriter(out);
            illlIIIlIlllIllIlIIlllIlI.printStackTrace(s);
            s2 = out.toString();
        }
        finally {
            IOUtils.closeQuietly((Writer)out);
            IOUtils.closeQuietly((Writer)s);
        }
        return s2;
    }
    
    public String getCompleteReport() {
        if (!this.lIIIIllIIlIlIllIIIlIllIlI) {
            this.lIIIIllIIlIlIllIIIlIllIlI = true;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("---- Minecraft Crash Report ----\n");
        sb.append("// ");
        sb.append(IllIIIIIIIlIlIllllIIllIII());
        sb.append("\n\n");
        sb.append("Time: ");
        sb.append(new SimpleDateFormat().format(new Date()));
        sb.append("\n");
        sb.append("Description: ");
        sb.append(this.lIIIIIIIIIlIllIIllIlIIlIl);
        sb.append("\n\n");
        sb.append(this.IlllIIIlIlllIllIlIIlllIlI());
        sb.append("\n\nA detailed walkthrough of the error, its code path and all known details is as follows:\n");
        for (int i = 0; i < 87; ++i) {
            sb.append("-");
        }
        sb.append("\n\n");
        this.lIIIIlIIllIIlIIlIIIlIIllI(sb);
        return sb.toString();
    }
    
    public File getFile() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public boolean saveToFile(final File obj) {
        if (this.IlIlIIIlllIIIlIlllIlIllIl != null) {
            return false;
        }
        if (obj.getParentFile() != null) {
            obj.getParentFile().mkdirs();
        }
        try {
            final FileWriter fileWriter = new FileWriter(obj);
            fileWriter.write(this.getCompleteReport());
            fileWriter.close();
            this.IlIlIIIlllIIIlIlllIlIllIl = obj;
            return true;
        }
        catch (Throwable t) {
            CrashReport.lIIIIlIIllIIlIIlIIIlIIllI.error("Could not save crash report to " + obj, t);
            return false;
        }
    }
    
    public lIlIllIIIIIlllIlllIIIllIl IlIlIIIlllIIIlIlllIlIllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public lIlIllIIIIIlllIlllIIIllIl makeCategory(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s, 1);
    }
    
    public lIlIllIIIIIlllIlllIIIllIl lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n) {
        final lIlIllIIIIIlllIlllIIIllIl lIlIllIIIIIlllIlllIIIllIl = new lIlIllIIIIIlllIlllIIIllIl(this, s);
        if (this.IIIllIllIlIlllllllIlIlIII) {
            final int liiiIlIIllIIlIIlIIIlIIllI = lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(n);
            final StackTraceElement[] stackTrace = this.IlllIIIlIlllIllIlIIlllIlI.getStackTrace();
            StackTraceElement stackTraceElement = null;
            StackTraceElement stackTraceElement2 = null;
            final int n2 = stackTrace.length - liiiIlIIllIIlIIlIIIlIIllI;
            if (n2 < 0) {
                System.out.println("Negative index in crash report handler (" + stackTrace.length + "/" + liiiIlIIllIIlIIlIIIlIIllI + ")");
            }
            if (stackTrace != null && 0 <= n2 && n2 < stackTrace.length) {
                stackTraceElement = stackTrace[n2];
                if (stackTrace.length + 1 - liiiIlIIllIIlIIlIIIlIIllI < stackTrace.length) {
                    stackTraceElement2 = stackTrace[stackTrace.length + 1 - liiiIlIIllIIlIIlIIIlIIllI];
                }
            }
            this.IIIllIllIlIlllllllIlIlIII = lIlIllIIIIIlllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(stackTraceElement, stackTraceElement2);
            if (liiiIlIIllIIlIIlIIIlIIllI > 0 && !this.IIIIllIIllIIIIllIllIIIlIl.isEmpty()) {
                this.IIIIllIIllIIIIllIllIIIlIl.get(this.IIIIllIIllIIIIllIllIIIlIl.size() - 1).lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI);
            }
            else if (stackTrace != null && stackTrace.length >= liiiIlIIllIIlIIlIIIlIIllI && 0 <= n2 && n2 < stackTrace.length) {
                System.arraycopy(stackTrace, 0, this.IllIIIIIIIlIlIllllIIllIII = new StackTraceElement[n2], 0, this.IllIIIIIIIlIlIllllIIllIII.length);
            }
            else {
                this.IIIllIllIlIlllllllIlIlIII = false;
            }
        }
        this.IIIIllIIllIIIIllIllIIIlIl.add(lIlIllIIIIIlllIlllIIIllIl);
        return lIlIllIIIIIlllIlllIIIllIl;
    }
    
    private static String IllIIIIIIIlIlIllllIIllIII() {
        final String[] array = { "Who set us up the TNT?", "Everything's going to plan. No, really, that was supposed to happen.", "Uh... Did I do that?", "Oops.", "Why did you do that?", "I feel sad now :(", "My bad.", "I'm sorry, Dave.", "I let you down. Sorry :(", "On the bright side, I bought you a teddy bear!", "Daisy, daisy...", "Oh - I know what I did wrong!", "Hey, that tickles! Hehehe!", "I blame Dinnerbone.", "You should try our sister game, Minceraft!", "Don't be sad. I'll do better next time, I promise!", "Don't be sad, have a hug! <3", "I just don't know what went wrong :(", "Shall we play a game?", "Quite honestly, I wouldn't worry myself about that.", "I bet Cylons wouldn't have this problem.", "Sorry :(", "Surprise! Haha. Well, this is awkward.", "Would you like a cupcake?", "Hi. I'm Minecraft, and I'm a crashaholic.", "Ooh. Shiny.", "This doesn't make any sense!", "Why is it breaking :(", "Don't do that.", "Ouch. That hurt :(", "You're mean.", "This is a token for 1 free hug. Redeem at your nearest Mojangsta: [~~HUG~~]", "There are four lights!", "But it works on my machine." };
        try {
            return array[(int)(System.nanoTime() % array.length)];
        }
        catch (Throwable t) {
            return "Witty comment unavailable :(";
        }
    }
    
    public static CrashReport makeCrashReport(final Throwable t, final String s) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append(t.getClass().getSimpleName()).append(": ").append(t.getLocalizedMessage());
            final StackTraceElement[] stackTrace = t.getStackTrace();
            for (int length = stackTrace.length, i = 0; i < length; ++i) {
                sb.append("\n").append("\t").append("at ").append(stackTrace[i]);
            }
            final UUID randomUUID = UUID.randomUUID();
            final Runtime runtime = Runtime.getRuntime();
            CheatBreaker.getInstance().lIllIllIlIIllIllIlIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(new IlIIIIllIlIlIllIIIllIlIlI(randomUUID.toString(), CheatBreaker.lIIlIlIllIIlIIIlIIIlllIII(), System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ") version " + System.getProperty("os.version"), runtime.freeMemory() / 1024L / 1024L + "MB/" + runtime.totalMemory() / 1024L / 1024L + "MB of " + runtime.maxMemory() / 1024L / 1024L + "MB", sb.toString()));
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection("CB-" + randomUUID.toString()), null);
            if (t.getClass().getSimpleName().equals("OutOfMemoryError")) {
                new Thread(() -> JOptionPane.showMessageDialog(null, "Your client has ran out of memory.\nYou can increase memory allocation in the launcher. \n\nPlease use the following code (also copied to your clipboard) when submitting a bug report: \n\nCB-" + randomUUID, "Out of Memory", 2)).start();
            }
            else {
                new Thread(() -> JOptionPane.showMessageDialog(null, "Your client has crashed. \n\nPlease use the following code (also copied to your clipboard) when submitting a bug report: \n\nCB-" + randomUUID, "Something went wrong", 2)).start();
            }
            Thread.sleep(4000L);
        }
        catch (Exception ex) {}
        CrashReport crashReport;
        if (t instanceof ReportedException) {
            crashReport = ((ReportedException)t).getCrashReport();
        }
        else {
            crashReport = new CrashReport(s, t);
        }
        return crashReport;
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
