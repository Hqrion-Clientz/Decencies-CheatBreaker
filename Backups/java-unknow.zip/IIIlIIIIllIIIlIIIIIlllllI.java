// 
// Decompiled by Procyon v0.5.36
// 

public enum IIIlIIIIllIIIlIIIIIlllllI
{
    lIIIIlIIllIIlIIlIIIlIIllI("SUBTITLE", 0), 
    lIIIIIIIIIlIllIIllIlIIlIl("TITLE", 1);
    
    private IIIlIIIIllIIIlIIIIIlllllI(final String name, final int ordinal) {
    }
}
