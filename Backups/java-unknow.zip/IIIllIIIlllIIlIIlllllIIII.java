import java.util.List;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIllIIIlllIIlIIlllllIIII
{
    private static IllIllIIIIlIIlIlIlIlIlIll[] lIIIIlIIllIIlIIlIIIlIIllI;
    
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI = new IllIllIIIIlIIlIlIlIlIlIll[0];
        if (lIIIllIIIllIlllllIIlIllII.IIllIllIlIIlllllIlIIIlIll()) {
            final String s = "optifine/natural.properties";
            try {
                final ResourceLocation resourceLocation = new ResourceLocation(s);
                if (!lIIIllIIIllIlllllIIlIllII.IlllIIIlIlllIllIlIIlllIlI(resourceLocation)) {
                    lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("NaturalTextures: configuration \"" + s + "\" not found");
                    IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI = lIIIIIIIIIlIllIIllIlIIlIl();
                    return;
                }
                final InputStream liiiIlIIllIIlIIlIIIlIIllI = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation);
                final ArrayList<IllIllIIIIlIIlIlIlIlIlIll> list = new ArrayList<IllIllIIIIlIIlIlIlIlIlIll>(256);
                final String liiiiiiiiIlIllIIllIlIIlIl = lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI);
                liiiIlIIllIIlIIlIIIlIIllI.close();
                final String[] liiiIlIIllIIlIIlIIIlIIllI2 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl, "\n\r");
                lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("Natural Textures: Parsing configuration \"" + s + "\"");
                for (int i = 0; i < liiiIlIIllIIlIIlIIIlIIllI2.length; ++i) {
                    final String trim = liiiIlIIllIIlIIlIIIlIIllI2[i].trim();
                    if (!trim.startsWith("#")) {
                        final String[] liiiIlIIllIIlIIlIIIlIIllI3 = lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(trim, "=");
                        if (liiiIlIIllIIlIIlIIIlIIllI3.length != 2) {
                            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Natural Textures: Invalid \"" + s + "\" line: " + trim);
                        }
                        else {
                            final String trim2 = liiiIlIIllIIlIIlIIIlIIllI3[0].trim();
                            final String trim3 = liiiIlIIllIIlIIlIIIlIIllI3[1].trim();
                            final lllIlllIlIllIIlIlIIIlIIII iiiIllIlIIIllIlllIlllllIl = TextureMap.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(trim2);
                            if (iiiIllIlIIIllIlllIlllllIl == null) {
                                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Natural Textures: Texture not found: \"" + s + "\" line: " + trim);
                            }
                            else {
                                final int iiIlIIllllIIllllllIlIIIll = iiiIllIlIIIllIlllIlllllIl.IIIlIIllllIIllllllIlIIIll();
                                if (iiIlIIllllIIllllllIlIIIll < 0) {
                                    lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("Natural Textures: Invalid \"" + s + "\" line: " + trim);
                                }
                                else {
                                    final IllIllIIIIlIIlIlIlIlIlIll element = new IllIllIIIIlIIlIlIlIlIlIll(trim3);
                                    if (element.lIIIIlIIllIIlIIlIIIlIIllI()) {
                                        while (list.size() <= iiIlIIllllIIllllllIlIIIll) {
                                            list.add(null);
                                        }
                                        list.set(iiIlIIllllIIllllllIlIIIll, element);
                                        lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("NaturalTextures: " + trim2 + " = " + trim3);
                                    }
                                }
                            }
                        }
                    }
                }
                IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI = list.toArray(new IllIllIIIIlIIlIlIlIlIlIll[list.size()]);
            }
            catch (FileNotFoundException ex2) {
                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("NaturalTextures: configuration \"" + s + "\" not found");
                IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI = lIIIIIIIIIlIllIIllIlIIlIl();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public static IllIllIIIIlIIlIlIlIlIlIll lIIIIlIIllIIlIIlIIIlIIllI(final IlllIllIIIIlllIllIIIIIlII illlIllIIIIlllIllIIIIIlII) {
        if (!(illlIllIIIIlllIllIIIIIlII instanceof lllIlllIlIllIIlIlIIIlIIII)) {
            return null;
        }
        final int iiIlIIllllIIllllllIlIIIll = ((lllIlllIlIllIIlIlIIIlIIII)illlIllIIIIlllIllIIIIIlII).IIIlIIllllIIllllllIlIIIll();
        if (iiIlIIllllIIllllllIlIIIll >= 0 && iiIlIIllllIIllllllIlIIIll < IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI.length) {
            return IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI[iiIlIIllllIIllllllIlIIIll];
        }
        return null;
    }
    
    private static IllIllIIIIlIIlIlIlIlIlIll[] lIIIIIIIIIlIllIIllIlIIlIl() {
        lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("NaturalTextures: Checking default configuration.");
        final ArrayList list = new ArrayList();
        lIIIIlIIllIIlIIlIIIlIIllI(list, "grass_top", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "stone", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "dirt", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "grass_side", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "grass_side_overlay", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "stone_slab_top", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "bedrock", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "sand", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "gravel", "2");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "log_oak", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "log_oak_top", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "gold_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "iron_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "coal_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "diamond_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "redstone_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "lapis_ore", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "obsidian", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_oak", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_oak_opaque", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_jungle", "2");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_jungle_opaque", "2");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "snow", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "grass_side_snowed", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "cactus_side", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "clay", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "mycelium_side", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "mycelium_top", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "farmland_wet", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "farmland_dry", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "netherrack", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "soul_sand", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "glowstone", "4");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "log_spruce", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "log_birch", "F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_spruce", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "leaves_spruce_opaque", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "log_jungle", "2F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "end_stone", "4");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "sandstone_top", "4");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "sandstone_bottom", "4F");
        lIIIIlIIllIIlIIlIIIlIIllI(list, "redstone_lamp_on", "4F");
        return list.toArray(new IllIllIIIIlIIlIlIlIlIlIll[list.size()]);
    }
    
    private static void lIIIIlIIllIIlIIlIIIlIIllI(final List list, final String str, final String str2) {
        final lllIlllIlIllIIlIlIIIlIIII iiiIllIlIIIllIlllIlllllIl = TextureMap.IlIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl(str);
        if (iiiIllIlIIIllIlllIlllllIl == null) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("*** NaturalProperties: Icon not found: " + str + " ***");
        }
        else if (!(iiiIllIlIIIllIlllIlllllIl instanceof lllIlllIlIllIIlIlIIIlIIII)) {
            lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("*** NaturalProperties: Icon is not IconStitched: " + str + ": " + iiiIllIlIIIllIlllIlllllIl.getClass().getName() + " ***");
        }
        else {
            final int i = iiiIllIlIIIllIlllIlllllIl.IIIlIIllllIIllllllIlIIIll();
            if (i < 0) {
                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("*** NaturalProperties: Invalid index for icon: " + str + ": " + i + " ***");
            }
            else if (lIIIllIIIllIlllllIIlIllII.IIIIllIlIIIllIlllIlllllIl(new ResourceLocation("textures/blocks/" + str + ".png"))) {
                while (i >= list.size()) {
                    list.add(null);
                }
                list.set(i, new IllIllIIIIlIIlIlIlIlIlIll(str2));
                lIIIllIIIllIlllllIIlIllII.lIIIIlIIllIIlIIlIIIlIIllI("NaturalTextures: " + str + " = " + str2);
            }
        }
    }
    
    static {
        IIIllIIIlllIIlIIlllllIIII.lIIIIlIIllIIlIIlIIIlIIllI = new IllIllIIIIlIIlIlIlIlIlIll[0];
    }
}
