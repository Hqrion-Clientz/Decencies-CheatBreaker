import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Mouse;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllllIIlIlIIIllllllIII extends GuiScreen
{
    private final IlIIIIlllIIIlIIllllIIIlll lIIIIlIIllIIlIIlIIIlIIllI;
    private lIIlIlIIlIlIlIIlIlIlllIIl lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIIlllllIIlIlIIIllllllIII(final lIIlIlIIlIlIlIIlIlIlllIIl liiiiiiiiIlIllIIllIlIIlIl, final IlIIIIlllIIIlIIllllIIIlll liiiIlIIllIIlIIlIIIlIIllI) {
        liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
    }
    
    @Override
    public void updateScreen() {
    }
    
    @Override
    public void s_() {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        this.lIllIllIlIIllIllIlIlIIlIl();
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(0.0, this.IIIIIIlIlIlIllllllIlllIlI / 3, this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI / 3 + 2.1086957f * 0.23711339f, 0.0, 1862270976);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(0.0, this.IIIIIIlIlIlIllllllIlllIlI / 3 * 2, this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI / 3 * 2 + 1.1388888f * 0.43902442f, 0.0, 1862270976);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIllllIIIIlIlIIIIlIlI / 3, 0.0, this.lIIIIIllllIIIIlIlIIIIlIlI / 3 + 0.42073172f * 1.1884058f, this.IIIIIIlIlIlIllllllIlllIlI, 0.0, 1862270976);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIllllIIIIlIlIIIIlIlI / 3 * 2, 0.0, this.lIIIIIllllIIIIlIlIIIIlIlI / 3 * 2 + 0.28070176f * 1.78125f, this.IIIIIIlIlIlIllllllIlllIlI, 0.0, 1862270976);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIllllIIIIlIlIIIIlIlI / 3 + this.lIIIIIllllIIIIlIlIIIIlIlI / 6, this.IIIIIIlIlIlIllllllIlllIlI / 3 * 2, this.lIIIIIllllIIIIlIlIIIIlIlI / 3 + this.lIIIIIllllIIIIlIlIIIIlIlI / 6 + 6.7000003f * 0.07462686f, this.IIIIIIlIlIlIllllllIlllIlI, 0.0, 1862270976);
        final float n4 = 1.0f / CheatBreaker.IlllIllIlIIIIlIIlIIllIIIl();
        final float n5 = (CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII()) + 6) * n4;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIllIIIIlllIlIIIIIlI < n5) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIllIIIIlllIlIIIIIlI = (float)(int)n5;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII < 18) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII = 18;
        }
        final ScaledResolution scaledResolution = new ScaledResolution(this.lllIIIIIlIllIlIIIllllllII, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
        final float[] liiiiiiiiIlIllIIllIlIIlIl = IllIlIlllIIllIlIIlIIIIIII.lIIIIIIIIIlIllIIllIlIIlIl((float)n, (float)n2, scaledResolution);
        final CBGuiAnchor liiiIlIIllIIlIIlIIIlIIllI = IllIlIlllIIllIlIIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI((float)n, (float)n2, scaledResolution);
        if (liiiIlIIllIIlIIlIIIlIIllI != CBGuiAnchor.MIDDLE_MIDDLE) {
            if (liiiIlIIllIIlIIlIIIlIIllI == CBGuiAnchor.MIDDLE_BOTTOM_LEFT || liiiIlIIllIIlIIlIIIlIIllI == CBGuiAnchor.MIDDLE_BOTTOM_RIGHT) {
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl[0], liiiiiiiiIlIllIIllIlIIlIl[1], liiiiiiiiIlIllIIllIlIIlIl[0] + scaledResolution.getScaledWidth() / 6, liiiiiiiiIlIllIIllIlIIlIl[1] + scaledResolution.getScaledHeight() / 3, 788529152);
            }
            else {
                IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl[0], liiiiiiiiIlIllIIllIlIIlIl[1], liiiiiiiiIlIllIIllIlIIlIl[0] + scaledResolution.getScaledWidth() / 3, liiiiiiiiIlIllIIllIlIIlIl[1] + scaledResolution.getScaledHeight() / 3, 788529152);
            }
        }
        final int scaledWidth = scaledResolution.getScaledWidth();
        final int scaledHeight = scaledResolution.getScaledHeight();
        final float[] liiiIlIIllIIlIIlIIIlIIllI2 = IllIlIlllIIllIlIIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, (float)n, (float)n2, scaledResolution);
        if (liiiIlIIllIIlIIlIIIlIIllI != this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIlIIIIlIlllIlIIIIll()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
            this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f);
        }
        if (!Mouse.isButtonDown(1)) {
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(2, 0.0, 1.8636363192038112 * 1.3414634466171265, scaledHeight, 0.0, -15599126);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(scaledWidth - 1.1197916f * 2.2325583f, 0.0, scaledWidth - 2, scaledHeight, 0.0, -15599126);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 2, scaledWidth, 0.4375 * 5.714285714285714, 0.0, -15599126);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(0.0, scaledHeight - 0.557971f * 6.2727275f, scaledWidth, scaledHeight - 3, 0.0, -15599126);
        }
        float liiiIlIIllIIlIIlIIIlIIllI3 = n - liiiiiiiiIlIllIIllIlIIlIl[0] - liiiIlIIllIIlIIlIIIlIIllI2[0];
        float liiiiiiiiIlIllIIllIlIIlIl2 = n2 - liiiiiiiiIlIllIIllIlIIlIl[1] - liiiIlIIllIIlIIlIIIlIIllI2[1];
        if (!Mouse.isButtonDown(1)) {
            final float[] liiiIlIIllIIlIIlIIIlIIllI4 = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(scaledResolution, false);
            liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI3, liiiIlIIllIIlIIlIIIlIIllI4, (float)(int)(this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIllIIIIlllIlIIIIIlI * (float)this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl()), false);
            liiiiiiiiIlIllIIllIlIIlIl2 = this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl2, liiiIlIIllIIlIIlIIIlIIllI4, (float)(int)(this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII * (float)this.lIIIIlIIllIIlIIlIIIlIIllI.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl()), false);
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI3, liiiiiiiiIlIllIIllIlIIlIl2);
        GL11.glPushMatrix();
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(scaledResolution);
        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(-2, -2, this.lIIIIlIIllIIlIIlIIIlIIllI.llIlIIIllIIIIlllIlIIIIIlI + 2.0f, this.lIIIIlIIllIIlIIlIIIlIIllI.lIllIlIlllIIlIIllIIlIIlII + 2.0f, (double)4, 551805923);
        GL11.glPushMatrix();
        GL11.glScalef(n4, n4, n4);
        CheatBreaker.getInstance().lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.IIIllIllIlIlllllllIlIlIII(), 0.0, -1, -1, 1862270976);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    private float lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll, final float n, final float[] array, final float n2, final boolean b) {
        float n3 = n;
        final int n4 = b ? 0 : 3;
        if (n3 + array[0] < n4) {
            n3 = -array[0] + n4;
        }
        else if (n3 + array[0] * (float)ilIIIIlllIIIlIIllllIIIlll.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl() + n2 > this.lIIIIIllllIIIIlIlIIIIlIlI - n4) {
            n3 = (float)(int)(this.lIIIIIllllIIIIlIlIIIIlIlI - array[0] * (float)ilIIIIlllIIIlIIllllIIIlll.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl() - n2 - n4);
        }
        return n3;
    }
    
    private float lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIIlllIIIlIIllllIIIlll ilIIIIlllIIIlIIllllIIIlll, final float n, final float[] array, final float n2, final boolean b) {
        float n3 = n;
        final int n4 = b ? 0 : 2;
        if (n3 + array[1] < n4) {
            n3 = -array[1] + n4;
        }
        else if (n3 + array[1] * (float)ilIIIIlllIIIlIIllllIIIlll.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl() + n2 > this.IIIIIIlIlIlIllllllIlllIlI - n4) {
            n3 = (float)(int)(this.IIIIIIlIlIlIllllllIlllIlI - array[1] * (float)ilIIIIlllIIIlIIllllIIIlll.IllIlIIIIlllIIllIIlllIIlI.IIIIllIlIIIllIlllIlllllIl() - n2 - n4);
        }
        return n3;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        if (n3 != 0) {
            return;
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IllIlIlllIIllIlIIlIIIIIII.lIIIIlIIllIIlIIlIIIlIIllI((float)n, (float)n2, new ScaledResolution(this.lllIIIIIlIllIlIIIllllllII, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight)));
        Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
        this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(true);
        final lIIlIlIIlIlIlIIlIlIlllIIl liIlIlIIlIlIlIIlIlIlllIIl = new lIIlIlIIlIlIlIIlIlIlllIIl();
        this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(liIlIlIIlIlIlIIlIlIlllIIl);
        liIlIlIIlIlIlIIlIlIlllIIl.IlllIllIlIIIIlIIlIIllIIIl = liIlIlIIlIlIlIIlIlIlllIIl.IIIllIllIlIlllllllIlIlIII;
        liIlIlIIlIlIlIIlIlIlllIIl.IlllIllIlIIIIlIIlIIllIIIl.lIIlIlIllIIlIIIlIIIlllIII = false;
        liIlIlIIlIlIlIIlIlIlllIIl.IlllIllIlIIIIlIIlIIllIIIl.lIIIIllIIlIlIllIIIlIllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII.lIIIIllIIlIlIllIIIlIllIlI;
        liIlIlIIlIlIlIIlIlIlllIIl.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI = 0;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final char c, final int n) {
    }
}
