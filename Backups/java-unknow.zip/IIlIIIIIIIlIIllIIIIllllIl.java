// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIIIIIIlIIllIIIIllllIl extends lllIIIllIIllIlllIIlllIlll
{
    private IIIIIllIIlIlllllIlIllllIl lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIlIIIIIIIlIIllIIIIllllIl(final IIIIIllIIlIlllllIlIllllIl liiiIlIIllIIlIIlIIIlIIllI, final Class clazz, final int n, final boolean b) {
        super(liiiIlIIllIIlIIlIIIlIIllI, clazz, n, b);
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return !this.lIIIIlIIllIIlIIlIIIlIIllI.llllIIllIIlIIllIIIllIlIlI() && super.lIIIIlIIllIIlIIlIIIlIIllI();
    }
}
