import java.util.LinkedList;
import java.util.List;
import org.lwjgl.opengl.Pbuffer;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlllIlIIlIllIlIIlllIIl extends Thread
{
    private Pbuffer lIIIIlIIllIIlIIlIIIlIIllI;
    private Object lIIIIIIIIIlIllIIllIlIIlIl;
    private List IlllIIIlIlllIllIlIIlllIlI;
    private List IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private Tessellator IlIlIIIlllIIIlIlllIlIllIl;
    private Tessellator IIIllIllIlIlllllllIlIlIII;
    private boolean IllIIIIIIIlIlIllllIIllIII;
    private llIlIIlIIlIlIlIIllIIIllIl lIIIIllIIlIlIllIIIlIllIlI;
    private boolean IlllIllIlIIIIlIIlIIllIIIl;
    private boolean IlIlllIIIIllIllllIllIIlIl;
    private boolean llIIlllIIIIlllIllIlIlllIl;
    private static final int lIIlIlIllIIlIIIlIIIlllIII = 10;
    
    public IIIIlllIlIIlIllIlIIlllIIl(final Pbuffer liiiIlIIllIIlIIlIIIlIIllI) {
        super("WrUpdateThread");
        this.lIIIIlIIllIIlIIlIIIlIIllI = null;
        this.lIIIIIIIIIlIllIIllIlIIlIl = new Object();
        this.IlllIIIlIlllIllIlIIlllIlI = new LinkedList();
        this.IIIIllIlIIIllIlllIlllllIl = new LinkedList();
        this.IIIIllIIllIIIIllIllIIIlIl = 0;
        this.IlIlIIIlllIIIlIlllIlIllIl = Tessellator.instance;
        this.IIIllIllIlIlllllllIlIlIII = new Tessellator(2097152);
        this.IllIIIIIIIlIlIllllIIllIII = false;
        this.lIIIIllIIlIlIllIIIlIllIlI = null;
        this.IlllIllIlIIIIlIIlIIllIIIl = false;
        this.IlIlllIIIIllIllllIllIIlIl = false;
        this.llIIlllIIIIlllIllIlIlllIl = false;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void run() {
        try {
            this.lIIIIlIIllIIlIIlIIIlIIllI.makeCurrent();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        final lIIlIlIIIlIlIIlIlIllllIll liIlIlIIIlIlIIlIlIllllIll = new lIIlIlIIIlIlIIlIlIllllIll(this, null);
        while (!Thread.interrupted() && !this.llIIlllIIIIlllIllIlIlllIl) {
            try {
                final llIlIIlIIlIlIlIIllIIIllIl illlIllIlIIIIlIIlIIllIIIl = this.IlllIllIlIIIIlIIlIIllIIIl();
                if (illlIllIlIIIIlIIlIIllIIIl == null) {
                    return;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI((IIIlIllIlllIlIIIlIlIIllII)null);
                try {
                    this.lIIIIllIIlIlIllIIIlIllIlI = illlIllIlIIIIlIIlIIllIIIl;
                    Tessellator.instance = this.IIIllIllIlIlllllllIlIlIII;
                    illlIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIIIlIlIIlIlIllllIll);
                }
                finally {
                    Tessellator.instance = this.IlIlIIIlllIIIlIlllIlIllIl;
                }
                this.lIIIIlIIllIIlIIlIIIlIIllI(illlIllIlIIIIlIIlIIllIIIl);
            }
            catch (Exception ex2) {
                ex2.printStackTrace();
                if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                    this.lIIIIllIIlIlIllIIIlIllIlI.lllIlIIllllIIIIlIllIlIIII = false;
                    this.lIIIIllIIlIlIllIIIlIllIlI.IllIllIIIlIIlllIIIllIllII = true;
                }
                this.lIIIIllIIlIlIllIIIlIllIlI = null;
                this.IllIIIIIIIlIlIllllIIllIII = false;
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final WorldRenderer worldRenderer, final boolean b) {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (worldRenderer.lllIlIIllllIIIIlIllIlIIII) {
                throw new IllegalArgumentException("Renderer already updating");
            }
            if (b) {
                this.IlllIIIlIlllIllIlIIlllIlI.add(0, worldRenderer);
            }
            else {
                this.IlllIIIlIlllIllIlIIlllIlI.add(worldRenderer);
            }
            worldRenderer.lllIlIIllllIIIIlIllIlIIII = true;
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
        }
    }
    
    private llIlIIlIIlIlIlIIllIIIllIl IlllIllIlIIIIlIIlIIllIIIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            while (this.IlllIIIlIlllIllIlIIlllIlI.size() <= 0) {
                try {
                    this.lIIIIIIIIIlIllIIllIlIIlIl.wait(2000L);
                    if (this.llIIlllIIIIlllIllIlIlllIl) {
                        return null;
                    }
                    continue;
                }
                catch (InterruptedException ex) {}
            }
            final llIlIIlIIlIlIlIIllIIIllIl llIlIIlIIlIlIlIIllIIIllIl = this.IlllIIIlIlllIllIlIIlllIlI.remove(0);
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
            return llIlIIlIIlIlIlIIllIIIllIl;
        }
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            return this.IlllIIIlIlllIllIlIIlllIlI.size() > 0 || this.lIIIIllIIlIlIllIIIlIllIlI != null || this.IllIIIIIIIlIlIllllIIllIII;
        }
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            return (this.IlllIIIlIlllIllIlIIlllIlI.size() > 10) ? 0 : (10 - this.IlllIIIlIlllIllIlIIlllIlI.size());
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final WorldRenderer worldRenderer) {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IIIIllIlIIIllIlllIlllllIl.add(worldRenderer);
            ++this.IIIIllIIllIIIIllIllIIIlIl;
            this.lIIIIllIIlIlIllIIIlIllIlI = null;
            this.IllIIIIIIIlIlIllllIIllIII = false;
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
        }
    }
    
    private void IlIlllIIIIllIllllIllIIlIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl.size(); ++i) {
                final llIlIIlIIlIlIlIIllIIIllIl llIlIIlIIlIlIlIIllIIIllIl = this.IIIIllIlIIIllIlllIlllllIl.get(i);
                llIlIIlIIlIlIlIIllIIIllIl.lIIIIllIIlIlIllIIIlIllIlI();
                llIlIIlIIlIlIlIIllIIIllIl.lllIlIIllllIIIIlIllIlIIII = false;
            }
            this.IIIIllIlIIIllIlllIlllllIl.clear();
        }
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IlllIllIlIIIIlIIlIIllIIIl = false;
            this.IlIlllIIIIllIllllIllIIlIl = false;
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
            while (this.IllIIIIIIIlIlIllllIIllIII) {
                try {
                    this.lIIIIIIIIIlIllIIllIlIIlIl.wait();
                }
                catch (InterruptedException ex) {}
            }
            this.IlIlllIIIIllIllllIllIIlIl();
        }
    }
    
    public void IIIIllIlIIIllIlllIlllllIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (this.IllIIIIIIIlIlIllllIIllIII) {
                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("UpdateThread still working in unpause()!!!");
            }
            this.IlllIllIlIIIIlIIlIIllIIIl = true;
            this.IlIlllIIIIllIllllIllIIlIl = false;
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
        }
    }
    
    public void IIIIllIIllIIIIllIllIIIlIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (this.IllIIIIIIIlIlIllllIIllIII) {
                lIIIllIIIllIlllllIIlIllII.lIIIIIIIIIlIllIIllIlIIlIl("UpdateThread still working in unpause()!!!");
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                while (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = false;
                    this.IlIlllIIIIllIllllIllIIlIl = true;
                    this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
                    try {
                        this.lIIIIIIIIIlIllIIllIlIIlIl.wait();
                    }
                    catch (InterruptedException ex) {}
                }
                this.IlllIIIlIlllIllIlIIlllIlI();
            }
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final IIIlIllIlllIlIIIlIlIIllII iiIlIllIlllIlIIIlIlIIllII) {
        Thread.yield();
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            while (!this.IlllIllIlIIIIlIIlIIllIIIl && (!this.IlIlllIIIIllIllllIllIIlIl || this.lIIIIllIIlIlIllIIIlIllIlI == null)) {
                if (iiIlIllIlllIlIIIlIlIIllII != null) {
                    iiIlIllIlllIlIIIlIlIIllII.lIIIIlIIllIIlIIlIIIlIIllI();
                }
                this.IllIIIIIIIlIlIllllIIllIII = false;
                this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
                try {
                    this.lIIIIIIIIIlIllIIllIlIIlIl.wait();
                }
                catch (InterruptedException ex) {}
            }
            this.IllIIIIIIIlIlIllllIIllIII = true;
            if (iiIlIllIlllIlIIIlIlIIllII != null) {
                iiIlIllIlllIlIIIlIlIIllII.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
        }
    }
    
    public void IlIlIIIlllIIIlIlllIlIllIl() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.IIIIllIIllIIIIllIllIIIlIl();
            for (int i = 0; i < this.IlllIIIlIlllIllIlIIlllIlI.size(); ++i) {
                final WorldRenderer worldRenderer = this.IlllIIIlIlllIllIlIIlllIlI.get(i);
                worldRenderer.IllIllIIIlIIlllIIIllIllII = true;
                worldRenderer.lllIlIIllllIIIIlIllIlIIII = false;
            }
            this.IlllIIIlIlllIllIlIIlllIlI.clear();
            this.lIIIIIIIIIlIllIIllIlIIlIl.notifyAll();
        }
    }
    
    public int IIIllIllIlIlllllllIlIlIII() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            int size = this.IlllIIIlIlllIllIlIIlllIlI.size();
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                ++size;
            }
            return size;
        }
    }
    
    public int IllIIIIIIIlIlIllllIIllIII() {
        final Object liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final int iiiIllIIllIIIIllIllIIIlIl = this.IIIIllIIllIIIIllIllIIIlIl;
            this.IIIIllIIllIIIIllIllIIIlIl = 0;
            return iiiIllIIllIIIIllIllIIIlIl;
        }
    }
    
    public void lIIIIllIIlIlIllIIIlIllIlI() {
        this.llIIlllIIIIlllIllIlIlllIl = true;
    }
}
