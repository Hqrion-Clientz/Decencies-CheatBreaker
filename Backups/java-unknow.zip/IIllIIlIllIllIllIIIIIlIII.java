import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIlIllIllIllIIIIIlIII extends IIlllllllIlllIIllllIIlIll
{
    protected IIllIIlIllIllIllIIIIIlIII(final Material material) {
        super(material);
        this.lIIIIlIIllIIlIIlIIIlIIllI(true);
        final float n = 0.4117647f * 0.4857143f;
        this.lIIIIlIIllIIlIIlIIIlIIllI(0.037037037f * 13.5f - n, 0.0f, 0.4047619f * 1.2352941f - n, 0.6956522f * 0.71875f + n, n * 3, 0.05882353f * 8.5f + n);
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIllllIllIIllIIllIlIIIIII.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    protected IIllIIlIllIllIllIIIIIlIII() {
        this(Material.IlIlllIIIIllIllllIllIIlIl);
    }
    
    @Override
    public boolean IIIIllIIllIIIIllIllIIIlIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return super.IIIIllIIllIIIIllIllIIIlIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3) && this.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3));
    }
    
    protected boolean IlllIIIlIlllIllIlIIlllIlI(final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        return illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl || illlllllIlllIIllllIIlIll == IllllllIllIIlllIllIIlIIll.lIIlIlIIlIlIlIIlIlIlllIIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final IIlllllllIlllIIllllIIlIll illlllllIlllIIllllIIlIll) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, illlllllIlllIIllllIIlIll);
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3, final Random random) {
        this.IlllIllIlIIIIlIIlIIllIIIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3);
    }
    
    protected void IlllIllIlIIIIlIIlIIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        if (!this.IlIlIIIlllIIIlIlllIlIllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3)) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3), 0);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(0), 0, 2);
        }
    }
    
    @Override
    public boolean IlIlIIIlllIIIlIlllIlIllIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return this.IlllIIIlIlllIllIlIIlllIlI(iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2 - 1, n3));
    }
    
    @Override
    public IlIllIIlIlIllIlIllllllllI IlllIIIlIlllIllIlIIlllIlI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean IlllIllIlIIIIlIIlIIllIIIl() {
        return false;
    }
    
    @Override
    public int IlIlllIIIIllIllllIllIIlIl() {
        return 1;
    }
}
