import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Collection;
import java.util.HashMap;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIlIIIIlIIIIllIllI
{
    public static final String lIIIIlIIllIIlIIlIIIlIIllI;
    public static final String lIIIIIIIIIlIllIIllIlIIlIl;
    public static final String IlllIIIlIlllIllIlIIlllIlI = "+0-1-2-3&4-4+13";
    public static final String IIIIllIlIIIllIlllIlllllIl;
    public static final String IIIIllIIllIIIIllIllIIIlIl;
    public static final String IlIlIIIlllIIIlIlllIlIllIl;
    public static final String IIIllIllIlIlllllllIlIlIII;
    public static final String IllIIIIIIIlIlIllllIIllIII;
    public static final String lIIIIllIIlIlIllIIIlIllIlI;
    public static final String IlllIllIlIIIIlIIlIIllIIIl;
    public static final String IlIlllIIIIllIllllIllIIlIl;
    public static final String llIIlllIIIIlllIllIlIlllIl;
    public static final String lIIlIlIllIIlIIIlIIIlllIII;
    private static final HashMap IIIlllIIIllIllIlIIIIIIlII;
    private static final HashMap llIlIIIlIIIIlIlllIlIIIIll;
    private static final HashMap IIIlIIllllIIllllllIlIIIll;
    private static final String[] lllIIIIIlIllIlIIIllllllII;
    
    public static boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2) {
        return (n & 1 << n2) != 0x0;
    }
    
    private static int lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        return lIIIIlIIllIIlIIlIIIlIIllI(n, n2) ? 1 : 0;
    }
    
    private static int IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2) {
        return lIIIIlIIllIIlIIlIIIlIIllI(n, n2) ? 0 : 1;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n) {
        return lIIIIlIIllIIlIIlIIIlIIllI(n, 5, 4, 3, 2, 1);
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final Collection collection) {
        final int n = 3694022;
        if (collection != null && !collection.isEmpty()) {
            float n2 = 0.0f;
            float n3 = 0.0f;
            float n4 = 0.0f;
            float n5 = 0.0f;
            for (final llIlIlIIlIlIllllIIlIIIlIl llIlIlIIlIlIllllIIlIIIlIl : collection) {
                final int liiiIllIIlIlIllIIIlIllIlI = IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI()].lIIIIllIIlIlIllIIIlIllIlI();
                for (int i = 0; i <= llIlIlIIlIlIllllIIlIIIlIl.IlllIIIlIlllIllIlIIlllIlI(); ++i) {
                    n2 += (liiiIllIIlIlIllIIIlIllIlI >> 16 & 0xFF) / (float)255;
                    n3 += (liiiIllIIlIlIllIIIlIllIlI >> 8 & 0xFF) / (float)255;
                    n4 += (liiiIllIIlIlIllIIIlIllIlI >> 0 & 0xFF) / (float)255;
                    ++n5;
                }
            }
            return (int)(n2 / n5 * 255) << 16 | (int)(n3 / n5 * 255) << 8 | (int)(n4 / n5 * 255);
        }
        return n;
    }
    
    public static boolean lIIIIIIIIIlIllIIllIlIIlIl(final Collection collection) {
        final Iterator<llIlIlIIlIlIllllIIlIIIlIl> iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (!iterator.next().IIIIllIlIIIllIlllIlllllIl()) {
                return false;
            }
        }
        return true;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int i, final boolean b) {
        if (b) {
            return lIIIIlIIllIIlIIlIIIlIIllI(lIIIIIIIIIlIllIIllIlIIlIl(i, b));
        }
        if (IIlIllIIIlIIIIlIIIIllIllI.IIIlIIllllIIllllllIlIIIll.containsKey(i)) {
            return IIlIllIIIlIIIIlIIIIllIllI.IIIlIIllllIIllllllIlIIIll.get(i);
        }
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(lIIIIIIIIIlIllIIllIlIIlIl(i, false));
        IIlIllIIIlIIIIlIIIIllIllI.IIIlIIllllIIllllllIlIIIll.put(i, liiiIlIIllIIlIIlIIIlIIllI);
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public static String lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return IIlIllIIIlIIIIlIIIIllIllI.lllIIIIIlIllIlIIIllllllII[lIIIIlIIllIIlIIlIIIlIIllI(n)];
    }
    
    private static int lIIIIlIIllIIlIIlIIIlIIllI(final boolean b, final boolean b2, final boolean b3, final int n, final int n2, final int n3, final int n4) {
        int n5 = 0;
        if (b) {
            n5 = IlllIIIlIlllIllIlIIlllIlI(n4, n2);
        }
        else if (n != -1) {
            if (n == 0 && IlllIIIlIlllIllIlIIlllIlI(n4) == n2) {
                n5 = 1;
            }
            else if (n == 1 && IlllIIIlIlllIllIlIIlllIlI(n4) > n2) {
                n5 = 1;
            }
            else if (n == 2 && IlllIIIlIlllIllIlIIlllIlI(n4) < n2) {
                n5 = 1;
            }
        }
        else {
            n5 = lIIIIIIIIIlIllIIllIlIIlIl(n4, n2);
        }
        if (b2) {
            n5 *= n3;
        }
        if (b3) {
            n5 *= -1;
        }
        return n5;
    }
    
    private static int IlllIIIlIlllIllIlIIlllIlI(int i) {
        int n;
        for (n = 0; i > 0; i &= i - 1, ++n) {}
        return n;
    }
    
    private static int lIIIIlIIllIIlIIlIIIlIIllI(final String s, final int n, final int n2, final int n3) {
        if (n >= s.length() || n2 < 0 || n >= n2) {
            return 0;
        }
        final int index = s.indexOf(124, n);
        if (index >= 0 && index < n2) {
            final int liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(s, n, index - 1, n3);
            if (liiiIlIIllIIlIIlIIIlIIllI > 0) {
                return liiiIlIIllIIlIIlIIIlIIllI;
            }
            final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIIIlIIllIIlIIlIIIlIIllI(s, index + 1, n2, n3);
            return (liiiIlIIllIIlIIlIIIlIIllI2 > 0) ? liiiIlIIllIIlIIlIIIlIIllI2 : false;
        }
        else {
            final int index2 = s.indexOf(38, n);
            if (index2 < 0 || index2 >= n2) {
                int n4 = 0;
                boolean b = false;
                int n5 = 0;
                boolean b2 = false;
                boolean b3 = false;
                int n6 = -1;
                int n7 = 0;
                int n8 = 0;
                int n9 = 0;
                for (int i = n; i < n2; ++i) {
                    final char char1 = s.charAt(i);
                    if (char1 >= '0' && char1 <= '9') {
                        if (n4 != 0) {
                            n8 = char1 - '0';
                            b = true;
                        }
                        else {
                            n7 = n7 * 10 + (char1 - '0');
                            n5 = 1;
                        }
                    }
                    else if (char1 == '*') {
                        n4 = 1;
                    }
                    else if (char1 == '!') {
                        if (n5 != 0) {
                            n9 += lIIIIlIIllIIlIIlIIIlIIllI(b2, b, b3, n6, n7, n8, n3);
                            b3 = false;
                            n4 = 0;
                            b = false;
                            n5 = 0;
                            n8 = 0;
                            n7 = 0;
                            n6 = -1;
                        }
                        b2 = true;
                    }
                    else if (char1 == '-') {
                        if (n5 != 0) {
                            n9 += lIIIIlIIllIIlIIlIIIlIIllI(b2, b, b3, n6, n7, n8, n3);
                            b2 = false;
                            n4 = 0;
                            b = false;
                            n5 = 0;
                            n8 = 0;
                            n7 = 0;
                            n6 = -1;
                        }
                        b3 = true;
                    }
                    else if (char1 != '=' && char1 != '<' && char1 != '>') {
                        if (char1 == '+' && n5 != 0) {
                            n9 += lIIIIlIIllIIlIIlIIIlIIllI(b2, b, b3, n6, n7, n8, n3);
                            b2 = false;
                            b3 = false;
                            n4 = 0;
                            b = false;
                            n5 = 0;
                            n8 = 0;
                            n7 = 0;
                            n6 = -1;
                        }
                    }
                    else {
                        if (n5 != 0) {
                            n9 += lIIIIlIIllIIlIIlIIIlIIllI(b2, b, b3, n6, n7, n8, n3);
                            b2 = false;
                            b3 = false;
                            n4 = 0;
                            b = false;
                            n5 = 0;
                            n8 = 0;
                            n7 = 0;
                            n6 = -1;
                        }
                        if (char1 == '=') {
                            n6 = 0;
                        }
                        else if (char1 == '<') {
                            n6 = 2;
                        }
                        else if (char1 == '>') {
                            n6 = 1;
                        }
                    }
                }
                if (n5 != 0) {
                    n9 += lIIIIlIIllIIlIIlIIIlIIllI(b2, b, b3, n6, n7, n8, n3);
                }
                return n9;
            }
            final int liiiIlIIllIIlIIlIIIlIIllI3 = lIIIIlIIllIIlIIlIIIlIIllI(s, n, index2 - 1, n3);
            if (liiiIlIIllIIlIIlIIIlIIllI3 <= 0) {
                return 0;
            }
            final int liiiIlIIllIIlIIlIIIlIIllI4 = lIIIIlIIllIIlIIlIIIlIIllI(s, index2 + 1, n2, n3);
            return (liiiIlIIllIIlIIlIIIlIIllI4 <= 0) ? 0 : ((liiiIlIIllIIlIIlIIIlIIllI3 > liiiIlIIllIIlIIlIIIlIIllI4) ? liiiIlIIllIIlIIlIIIlIIllI3 : liiiIlIIllIIlIIlIIIlIIllI4);
        }
    }
    
    public static List lIIIIIIIIIlIllIIllIlIIlIl(final int n, final boolean b) {
        ArrayList<llIlIlIIlIlIllllIIlIIIlIl> list = null;
        for (final IIIlIlIIIIIIIlllllIlIllIl iiIlIlIIIIIIIlllllIlIllIl : IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (iiIlIlIIIIIIIlllllIlIllIl != null && (!iiIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII() || b)) {
                final String s = IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.get(iiIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI());
                if (s != null) {
                    final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIIIlIIllIIlIIlIIIlIIllI(s, 0, s.length(), n);
                    if (liiiIlIIllIIlIIlIIIlIIllI2 > 0) {
                        int liiiIlIIllIIlIIlIIIlIIllI3 = 0;
                        final String s2 = IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.get(iiIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI());
                        if (s2 != null) {
                            liiiIlIIllIIlIIlIIIlIIllI3 = lIIIIlIIllIIlIIlIIIlIIllI(s2, 0, s2.length(), n);
                            if (liiiIlIIllIIlIIlIIIlIIllI3 < 0) {
                                liiiIlIIllIIlIIlIIIlIIllI3 = 0;
                            }
                        }
                        int n2;
                        if (iiIlIlIIIIIIIlllllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl()) {
                            n2 = 1;
                        }
                        else {
                            n2 = (int)Math.round((1200 * (liiiIlIIllIIlIIlIIIlIIllI2 * 3 + (liiiIlIIllIIlIIlIIIlIIllI2 - 1) * 2) >> liiiIlIIllIIlIIlIIIlIIllI3) * iiIlIlIIIIIIIlllllIlIllIl.IIIllIllIlIlllllllIlIlIII());
                            if ((n & 0x4000) != 0x0) {
                                n2 = (int)Math.round(n2 * (2.9605263529391834 * 0.25333333015441895) + 1.1578947223124414 * 0.4318181872367859);
                            }
                        }
                        if (list == null) {
                            list = new ArrayList<llIlIlIIlIlIllllIIlIIIlIl>();
                        }
                        final llIlIlIIlIlIllllIIlIIIlIl e = new llIlIlIIlIlIllllIIlIIIlIl(iiIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(), n2, liiiIlIIllIIlIIlIIIlIIllI3);
                        if ((n & 0x4000) != 0x0) {
                            e.lIIIIlIIllIIlIIlIIIlIIllI(true);
                        }
                        list.add(e);
                    }
                }
            }
        }
        return list;
    }
    
    private static int lIIIIlIIllIIlIIlIIIlIIllI(int n, final int n2, final boolean b, final boolean b2, final boolean b3) {
        if (b3) {
            if (!lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                return 0;
            }
        }
        else if (b) {
            n &= ~(1 << n2);
        }
        else if (b2) {
            if ((n & 1 << n2) == 0x0) {
                n |= 1 << n2;
            }
            else {
                n &= ~(1 << n2);
            }
        }
        else {
            n |= 1 << n2;
        }
        return n;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(int n, final String s) {
        final int n2 = 0;
        final int length = s.length();
        int n3 = 0;
        boolean b = false;
        boolean b2 = false;
        boolean b3 = false;
        int n4 = 0;
        for (int i = n2; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (char1 >= '0' && char1 <= '9') {
                n4 = n4 * 10 + (char1 - '0');
                n3 = 1;
            }
            else if (char1 == '!') {
                if (n3 != 0) {
                    n = lIIIIlIIllIIlIIlIIIlIIllI(n, n4, b2, b, b3);
                    b3 = false;
                    b2 = false;
                    n3 = 0;
                    n4 = 0;
                }
                b = true;
            }
            else if (char1 == '-') {
                if (n3 != 0) {
                    n = lIIIIlIIllIIlIIlIIIlIIllI(n, n4, b2, b, b3);
                    b3 = false;
                    b = false;
                    n3 = 0;
                    n4 = 0;
                }
                b2 = true;
            }
            else if (char1 == '+') {
                if (n3 != 0) {
                    n = lIIIIlIIllIIlIIlIIIlIIllI(n, n4, b2, b, b3);
                    b3 = false;
                    b = false;
                    b2 = false;
                    n3 = 0;
                    n4 = 0;
                }
            }
            else if (char1 == '&') {
                if (n3 != 0) {
                    n = lIIIIlIIllIIlIIlIIIlIIllI(n, n4, b2, b, b3);
                    b = false;
                    b2 = false;
                    n3 = 0;
                    n4 = 0;
                }
                b3 = true;
            }
        }
        if (n3 != 0) {
            n = lIIIIlIIllIIlIIlIIIlIIllI(n, n4, b2, b, b3);
        }
        return n & 0x7FFF;
    }
    
    public static int lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        return (lIIIIlIIllIIlIIlIIIlIIllI(n, n2) ? 16 : 0) | (lIIIIlIIllIIlIIlIIIlIIllI(n, n3) ? 8 : 0) | (lIIIIlIIllIIlIIlIIIlIIllI(n, n4) ? 4 : 0) | (lIIIIlIIllIIlIIlIIIlIIllI(n, n5) ? 2 : 0) | (lIIIIlIIllIIlIIlIIIlIIllI(n, n6) ? 1 : 0);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = null;
        IIIlllIIIllIllIlIIIIIIlII = new HashMap();
        llIlIIIlIIIIlIlllIlIIIIll = new HashMap();
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(), "0 & !1 & !2 & !3 & 0+6");
        lIIIIIIIIIlIllIIllIlIIlIl = "-0+1-2-3&4-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & 1 & !2 & !3 & 1+6");
        IllIIIIIIIlIlIllllIIllIII = "+0+1-2-3&4-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IIIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(), "0 & 1 & !2 & !3 & 0+6");
        IlIlIIIlllIIIlIlllIlIllIl = "+0-1+2-3&4-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(), "0 & !1 & 2 & !3");
        IIIIllIlIIIllIlllIlllllIl = "-0-1+2-3&4-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & !1 & 2 & !3 & 2+6");
        IIIIllIIllIIIIllIllIIIlIl = "-0+3-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & !1 & !2 & 3 & 3+6");
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & !1 & 2 & 3");
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & 1 & !2 & 3 & 3+6");
        IIIllIllIlIlllllllIlIlIII = "+0-1-2+3&4-4+13";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(), "0 & !1 & !2 & 3 & 3+6");
        llIIlllIIIIlllIllIlIlllIl = "-0+1+2-3+13&4-4";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.lIIIIIllllIIIIlIlIIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & 1 & 2 & !3 & 2+6");
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.IIIlIIllllIIllllllIlIIIll.lIIIIlIIllIIlIIlIIIlIIllI(), "!0 & 1 & 2 & 3 & 2+6");
        lIIlIlIllIIlIIIlIIIlllIII = "+0-1+2+3+13&4-4";
        IIlIllIIIlIIIIlIIIIllIllI.IIIlllIIIllIllIlIIIIIIlII.put(IIIlIlIIIIIIIlllllIlIllIl.llIlIIIlIIIIlIlllIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(), "0 & !1 & 2 & 3 & 2+6");
        IlllIllIlIIIIlIIlIIllIIIl = "+5-6-7";
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        IIlIllIIIlIIIIlIIIIllIllI.llIlIIIlIIIIlIlllIlIIIIll.put(IIIlIlIIIIIIIlllllIlIllIl.IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(), "5");
        lIIIIllIIlIlIllIIIlIllIlI = "-5+6-7";
        IlIlllIIIIllIllllIllIIlIl = "+14&13-13";
        IIIlIIllllIIllllllIlIIIll = new HashMap();
        lllIIIIIlIllIlIIIllllllII = new String[] { "potion.prefix.mundane", "potion.prefix.uninteresting", "potion.prefix.bland", "potion.prefix.clear", "potion.prefix.milky", "potion.prefix.diffuse", "potion.prefix.artless", "potion.prefix.thin", "potion.prefix.awkward", "potion.prefix.flat", "potion.prefix.bulky", "potion.prefix.bungling", "potion.prefix.buttered", "potion.prefix.smooth", "potion.prefix.suave", "potion.prefix.debonair", "potion.prefix.thick", "potion.prefix.elegant", "potion.prefix.fancy", "potion.prefix.charming", "potion.prefix.dashing", "potion.prefix.refined", "potion.prefix.cordial", "potion.prefix.sparkling", "potion.prefix.potent", "potion.prefix.foul", "potion.prefix.odorless", "potion.prefix.rank", "potion.prefix.harsh", "potion.prefix.acrid", "potion.prefix.gross", "potion.prefix.stinky" };
    }
}
