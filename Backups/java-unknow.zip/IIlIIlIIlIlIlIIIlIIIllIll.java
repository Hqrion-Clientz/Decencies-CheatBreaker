// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIlIIlIlIlIIIlIIIllIll extends IIlllllllIlllIIllllIIlIll
{
    protected boolean IlIllllIIIlIllllIIIIIllII;
    
    protected IIlIIlIIlIlIlIIIlIIIllIll(final Material material, final boolean ilIllllIIIlIllllIIIIIllII) {
        super(material);
        this.IlIllllIIIlIllllIIIIIllII = ilIllllIIIlIllllIIIIIllII;
    }
    
    @Override
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIIllIIIllIIIIllIllIIllIl liIllIIIllIIIIllIllIIllIl, final int n, final int n2, final int n3, final int n4) {
        final IIlllllllIlllIIllllIIlIll block = liIllIIIllIIIIllIllIIllIl.getBlock(n, n2, n3);
        return (this.IlIllllIIIlIllllIIIIIllII || block != this) && super.lIIIIlIIllIIlIIlIIIlIIllI(liIllIIIllIIIIllIllIIllIl, n, n2, n3, n4);
    }
}
