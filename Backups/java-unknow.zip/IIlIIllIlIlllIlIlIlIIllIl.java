import org.apache.logging.log4j.LogManager;
import java.util.Iterator;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetAddress;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlIlllIlIlIlIIllIl
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private final List lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIIllIlIlllIlIlIlIIllIl() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = Collections.synchronizedList(new ArrayList<Object>());
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final lllIIIlIIlIlIIllIllIIllll lllIIIlIIlIlIIllIllIIllll) {
        if (s != null && !s.startsWith("0.0.0.0") && !s.isEmpty()) {
            final IllIIIIIlIIllIIIlllllllII liiiIlIIllIIlIIlIIIlIIllI = IllIIIIIlIIllIIIlllllllII.lIIIIlIIllIIlIIlIIIlIIllI(s);
            final NetworkManager liiiIlIIllIIlIIlIIIlIIllI2 = NetworkManager.lIIIIlIIllIIlIIlIIIlIIllI(InetAddress.getByName(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI()), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl());
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(liiiIlIIllIIlIIlIIIlIIllI2);
            liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new llIIllIlIllIIIIllllIIllll(this, lllIIIlIIlIlIIllIllIIllll, liiiIlIIllIIlIIlIIIlIIllI2, s));
            try {
                liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new lllllIlIIIlIlIllIlIIlIIIl(lllIllIlIIllIllIIlIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(), liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl(), EnumConnectionState.IlllIIIlIlllIllIlIIlllIlI), new GenericFutureListener[0]);
                liiiIlIIllIIlIIlIIIlIIllI2.lIIIIlIIllIIlIIlIIIlIIllI(new lIIIIIllIlIlIIIIIIIIlllII(), new GenericFutureListener[0]);
            }
            catch (Throwable t) {
                IIlIIllIlIlllIlIlIlIIllIl.lIIIIlIIllIIlIIlIIIlIIllI.error((Object)t);
            }
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final Iterator<NetworkManager> iterator = (Iterator<NetworkManager>)this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkManager = iterator.next();
                if (networkManager.IIIIllIlIIIllIlllIlllllIl()) {
                    networkManager.lIIIIlIIllIIlIIlIIIlIIllI();
                }
                else {
                    iterator.remove();
                    if (networkManager.IlIlIIIlllIIIlIlllIlIllIl() == null) {
                        continue;
                    }
                    networkManager.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(networkManager.IlIlIIIlllIIIlIlllIlIllIl());
                }
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        final List liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
        synchronized (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final Iterator<NetworkManager> iterator = (Iterator<NetworkManager>)this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator.hasNext()) {
                final NetworkManager networkManager = iterator.next();
                if (networkManager.IIIIllIlIIIllIlllIlllllIl()) {
                    iterator.remove();
                    networkManager.lIIIIlIIllIIlIIlIIIlIIllI(new lIlIIllIIlIIIIIlIllIllllI("Cancelled"));
                }
            }
        }
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
