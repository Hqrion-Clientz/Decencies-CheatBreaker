// 
// Decompiled by Procyon v0.5.36
// 

class IIIlllllllIIlIllIIIIllllI
{
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private int IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    
    public IIIlllllllIIlIllIIIIllllI(final String s) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(s);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = s;
        if (s != null) {
            if (s.equals("false")) {
                this.lIIIIIIIIIlIllIIllIlIIlIl = false;
                return;
            }
            if (s.equals("true")) {
                this.lIIIIIIIIIlIllIIllIlIIlIl = true;
                return;
            }
        }
        this.lIIIIIIIIIlIllIIllIlIIlIl = Boolean.parseBoolean(s);
        try {
            this.IlllIIIlIlllIllIlIIlllIlI = Integer.parseInt(s);
        }
        catch (NumberFormatException ex) {}
        try {
            this.IIIIllIlIIIllIlllIlllllIl = Double.parseDouble(s);
        }
        catch (NumberFormatException ex2) {}
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
