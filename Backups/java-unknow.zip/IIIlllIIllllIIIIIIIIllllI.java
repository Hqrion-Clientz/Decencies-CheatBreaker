import org.apache.logging.log4j.LogManager;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.logging.log4j.Logger;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlllIIllllIIIIIIIIllllI extends IIllIlllIIlllllIlllIIIlIl
{
    private static final Logger lIIIIlIIllIIlIIlIIIlIIllI;
    private IlIlIlIIlIlIlIlllIlllIIII lIIIIIIIIIlIllIIllIlIIlIl;
    private byte[] IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    
    public IIIlllIIllllIIIIIIIIllllI() {
    }
    
    public IIIlllIIllllIIIIIIIIllllI(final int iiiIllIlIIIllIlllIlllllIl, final short[] array, final lIlllllIIllIlIlIlllIIIIII lIlllllIIllIlIlIlllIIIIII) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new IlIlIlIIlIlIlIlllIlllIIII(lIlllllIIllIlIlIlllIIIIII.IIIllIllIlIlllllllIlIlIII, lIlllllIIllIlIlIlllIIIIII.IllIIIIIIIlIlIllllIIllIII);
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        final int n = 4 * iiiIllIlIIIllIlllIlllllIl;
        try {
            final ByteArrayOutputStream out = new ByteArrayOutputStream(n);
            final DataOutputStream dataOutputStream = new DataOutputStream(out);
            for (int i = 0; i < iiiIllIlIIIllIlllIlllllIl; ++i) {
                final int n2 = array[i] >> 12 & 0xF;
                final int n3 = array[i] >> 8 & 0xF;
                final int n4 = array[i] & 0xFF;
                dataOutputStream.writeShort(array[i]);
                dataOutputStream.writeShort((short)((IIlllllllIlllIIllllIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(lIlllllIIllIlIlIlllIIIIII.lIIIIIIIIIlIllIIllIlIIlIl(n2, n4, n3)) & 0xFFF) << 4 | (lIlllllIIllIlIlIlllIIIIII.IlllIIIlIlllIllIlIIlllIlI(n2, n4, n3) & 0xF)));
            }
            this.IlllIIIlIlllIllIlIIlllIlI = out.toByteArray();
            if (this.IlllIIIlIlllIllIlIIlllIlI.length != n) {
                throw new RuntimeException("Expected length " + n + " doesn't match received length " + this.IlllIIIlIlllIllIlIIlllIlI.length);
            }
        }
        catch (IOException ex) {
            IIIlllIIllllIIIIIIIIllllI.lIIIIlIIllIIlIIlIIIlIIllI.error("Couldn't create bulk block update packet", (Throwable)ex);
            this.IlllIIIlIlllIllIlIIlllIlI = null;
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new IlIlIlIIlIlIlIlllIlllIIII(lIlIllllllllIlIIIllIIllII.readInt(), lIlIllllllllIlIIIllIIllII.readInt());
        this.IIIIllIlIIIllIlllIlllllIl = (lIlIllllllllIlIIIllIIllII.readShort() & 0xFFFF);
        final int int1 = lIlIllllllllIlIIIllIIllII.readInt();
        if (int1 > 0) {
            lIlIllllllllIlIIIllIIllII.readBytes(this.IlllIIIlIlllIllIlIIlllIlI = new byte[int1]);
        }
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI);
        lIlIllllllllIlIIIllIIllII.writeInt(this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl);
        lIlIllllllllIlIIIllIIllII.writeShort((short)this.IIIIllIlIIIllIlllIlllllIl);
        if (this.IlllIIIlIlllIllIlIIlllIlI != null) {
            lIlIllllllllIlIIIllIIllII.writeInt(this.IlllIIIlIlllIllIlIIlllIlI.length);
            lIlIllllllllIlIIIllIIllII.writeBytes(this.IlllIIIlIlllIllIlIIlllIlI);
        }
        else {
            lIlIllllllllIlIIIllIIllII.writeInt(0);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlIIlIIIIIIIlllIIIlIIll liIlIIlIIIIIIIlllIIIlIIll) {
        liIlIIlIIIIIIIlllIIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return String.format("xc=%d, zc=%d, count=%d", this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    public IlIlIlIIlIlIlIlllIlllIIII IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public byte[] IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((lIIlIIlIIIIIIIlllIIIlIIll)lIlIIIlIlIllIlIlIIIlIlIII);
    }
    
    static {
        lIIIIlIIllIIlIIlIIIlIIllI = LogManager.getLogger();
    }
}
