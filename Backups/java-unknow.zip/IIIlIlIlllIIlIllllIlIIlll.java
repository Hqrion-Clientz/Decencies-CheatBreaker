import java.util.Iterator;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIlIlllIIlIllllIlIIlll
{
    private IIIIIIllIlIIIIlIlllIllllI lIIIIlIIllIIlIIlIIIlIIllI;
    private final List lIIIIIIIIIlIllIIllIlIIlIl;
    private final IlllIllllIIIIIlIlIlIIIllI IlllIIIlIlllIllIlIIlllIlI;
    private final IlllIllllIIIIIlIlIlIIIllI IIIIllIlIIIllIlllIlllllIl;
    private int IIIIllIIllIIIIllIllIIIlIl;
    private int IlIlIIIlllIIIlIlllIlIllIl;
    private int IIIllIllIlIlllllllIlIlIII;
    private int IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI;
    private TreeMap IlllIllIlIIIIlIIlIIllIIIl;
    private List IlIlllIIIIllIllllIllIIlIl;
    private int llIIlllIIIIlllIllIlIlllIl;
    
    public IIIlIlIlllIIlIllllIlIIlll() {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI = new IlllIllllIIIIIlIlIlIIIllI(0, 0, 0);
        this.IIIIllIlIIIllIlllIlllllIl = new IlllIllllIIIIIlIlIlIIIllI(0, 0, 0);
        this.IlllIllIlIIIIlIIlIIllIIIl = new TreeMap();
        this.IlIlllIIIIllIllllIllIIlIl = new ArrayList();
    }
    
    public IIIlIlIlllIIlIllllIlIIlll(final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI = new IlllIllllIIIIIlIlIlIIIllI(0, 0, 0);
        this.IIIIllIlIIIllIlllIlllllIl = new IlllIllllIIIIIlIlIlIIIllI(0, 0, 0);
        this.IlllIllIlIIIIlIIlIIllIIIl = new TreeMap();
        this.IlIlllIIIIllIllllIllIIlIl = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int iiIllIllIlIlllllllIlIlIII) {
        this.IIIllIllIlIlllllllIlIlIII = iiIllIllIlIlllllllIlIlIII;
        this.lIIlIlIllIIlIIIlIIIlllIII();
        this.llIIlllIIIIlllIllIlIlllIl();
        if (iiIllIllIlIlllllllIlIlIII % 20 == 0) {
            this.IlIlllIIIIllIllllIllIIlIl();
        }
        if (iiIllIllIlIlllllllIlIlIII % 30 == 0) {
            this.IlllIllIlIIIIlIIlIIllIIIl();
        }
        if (this.llIIlllIIIIlllIllIlIlllIl < this.IllIIIIIIIlIlIllllIIllIII / 10 && this.lIIIIIIIIIlIllIIllIlIIlIl.size() > 20 && this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextInt(7000) == 0) {
            final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(MathHelper.IIIIllIlIIIllIlllIlllllIl((float)this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI), MathHelper.IIIIllIlIIIllIlllIlllllIl((float)this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl), MathHelper.IIIIllIlIIIllIlllIlllllIl((float)this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI), 2, 4, 2);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                final llIlIIlIlllIllIlIlIllIlll llIlIIlIlllIllIlIlIllIlll = new llIlIIlIlllIllIlIlIllIlll(this.lIIIIlIIllIIlIIlIIIlIIllI);
                llIlIIlIlllIllIlIlIllIlll.IlllIIIlIlllIllIlIIlllIlI(liiiIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.IlllIIIlIlllIllIlIIlllIlI);
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIlIlllIllIlIlIllIlll);
                ++this.llIIlllIIIIlllIllIlIlllIl;
            }
        }
    }
    
    private lIllIIIIlllllIIlIllIIIIII lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        for (int i = 0; i < 10; ++i) {
            final int n7 = n + this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextInt(16) - 8;
            final int n8 = n2 + this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextInt(6) - 3;
            final int n9 = n3 + this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextInt(16) - 8;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI(n7, n8, n9) && this.lIIIIIIIIIlIllIIllIlIIlIl(n7, n8, n9, n4, n5, n6)) {
                return lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(n7, n8, n9);
            }
        }
        return null;
    }
    
    private boolean lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        if (!IIIIIIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI, n, n2 - 1, n3)) {
            return false;
        }
        final int n7 = n - n4 / 2;
        final int n8 = n3 - n6 / 2;
        for (int i = n7; i < n7 + n4; ++i) {
            for (int j = n2; j < n2 + n5; ++j) {
                for (int k = n8; k < n8 + n6; ++k) {
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI.getBlock(i, j, k).lIIIIllIIlIlIllIIIlIllIlI()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    private void IlllIllIlIIIIlIIlIIllIIIl() {
        this.llIIlllIIIIlllIllIlIlllIl = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIlIlllIllIlIlIllIlll.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI - this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl - 4, this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI - this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI + this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl + 4, this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl)).size();
    }
    
    private void IlIlllIIIIllIllllIllIIlIl() {
        this.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(IlIllIlIlIlIIllIIIlIlIllI.class, IlIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI - this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl - 4, this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI - this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI + this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl + 4, this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI + this.IIIIllIIllIIIIllIllIIIlIl)).size();
        if (this.IllIIIIIIIlIlIllllIIllIII == 0) {
            this.IlllIllIlIIIIlIIlIIllIIIl.clear();
        }
    }
    
    public IlllIllllIIIIIlIlIlIIIllI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public int IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.size();
    }
    
    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIllIllIlIlllllllIlIlIII - this.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.IllIIIIIIIlIlIllllIIllIII;
    }
    
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        return this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3) < this.IIIIllIIllIIIIllIllIIIlIl * this.IIIIllIIllIIIIllIllIIIlIl;
    }
    
    public List IlIlIIIlllIIIlIlllIlIllIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public IlIllIlIIIllIlllIlllIlIII lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2, final int n3) {
        IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII = null;
        int n4 = Integer.MAX_VALUE;
        for (final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII2 : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final int liiiIlIIllIIlIIlIIIlIIllI = ilIllIlIIIllIlllIlllIlIII2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
            if (liiiIlIIllIIlIIlIIIlIIllI < n4) {
                ilIllIlIIIllIlllIlllIlIII = ilIllIlIIIllIlllIlllIlIII2;
                n4 = liiiIlIIllIIlIIlIIIlIIllI;
            }
        }
        return ilIllIlIIIllIlllIlllIlIII;
    }
    
    public IlIllIlIIIllIlllIlllIlIII IlllIIIlIlllIllIlIIlllIlI(final int n, final int n2, final int n3) {
        IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII = null;
        int n4 = Integer.MAX_VALUE;
        for (final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII2 : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final int liiiIlIIllIIlIIlIIIlIIllI = ilIllIlIIIllIlllIlllIlIII2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
            int ilIlIIIlllIIIlIlllIlIllIl;
            if (liiiIlIIllIIlIIlIIIlIIllI > 256) {
                ilIlIIIlllIIIlIlllIlIllIl = liiiIlIIllIIlIIlIIIlIIllI * 1000;
            }
            else {
                ilIlIIIlllIIIlIlllIlIllIl = ilIllIlIIIllIlllIlllIlIII2.IlIlIIIlllIIIlIlllIlIllIl();
            }
            if (ilIlIIIlllIIIlIlllIlIllIl < n4) {
                ilIllIlIIIllIlllIlllIlIII = ilIllIlIIIllIlllIlllIlIII2;
                n4 = ilIlIIIlllIIIlIlllIlIllIl;
            }
        }
        return ilIllIlIIIllIlllIlllIlIII;
    }
    
    public IlIllIlIIIllIlllIlllIlIII IIIIllIlIIIllIlllIlllllIl(final int n, final int n2, final int n3) {
        if (this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, n3) > this.IIIIllIIllIIIIllIllIIIlIl * this.IIIIllIIllIIIIllIllIIIlIl) {
            return null;
        }
        for (final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            if (ilIllIlIIIllIlllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI == n && ilIllIlIIIllIlllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI == n3 && Math.abs(ilIllIlIIIllIlllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl - n2) <= 1) {
                return ilIllIlIIIllIlllIlllIlIII;
            }
        }
        return null;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII) {
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(ilIllIlIIIllIlllIlllIlIII);
        final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI += ilIllIlIIIllIlllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI;
        final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI2 = this.IlllIIIlIlllIllIlIIlllIlI;
        illlIIIlIlllIllIlIIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl += ilIllIlIIIllIlllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl;
        final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI3 = this.IlllIIIlIlllIllIlIIlllIlI;
        illlIIIlIlllIllIlIIlllIlI3.IlllIIIlIlllIllIlIIlllIlI += ilIllIlIIIllIlllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI;
        this.IIIlllIIIllIllIlIIIIIIlII();
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIllIlIIIllIlllIlllIlIII.IlIlIIIlllIIIlIlllIlIllIl;
    }
    
    public boolean IIIllIllIlIlllllllIlIlIII() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl.isEmpty();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final EntityLivingBase entityLivingBase) {
        for (final IIIIlllIIllllllIIIlIIIlII iiiIlllIIllllllIIIlIIIlII : this.IlIlllIIIIllIllllIllIIlIl) {
            if (iiiIlllIIllllllIIIlIIIlII.lIIIIlIIllIIlIIlIIIlIIllI == entityLivingBase) {
                iiiIlllIIllllllIIIlIIIlII.lIIIIIIIIIlIllIIllIlIIlIl = this.IIIllIllIlIlllllllIlIlIII;
                return;
            }
        }
        this.IlIlllIIIIllIllllIllIIlIl.add(new IIIIlllIIllllllIIIlIIIlII(this, entityLivingBase, this.IIIllIllIlIlllllllIlIlIII));
    }
    
    public EntityLivingBase lIIIIIIIIIlIllIIllIlIIlIl(final EntityLivingBase entityLivingBase) {
        double n = 14.142857551574707 * 1.271096119229565E307;
        IIIIlllIIllllllIIIlIIIlII iiiIlllIIllllllIIIlIIIlII = null;
        for (int i = 0; i < this.IlIlllIIIIllIllllIllIIlIl.size(); ++i) {
            final IIIIlllIIllllllIIIlIIIlII iiiIlllIIllllllIIIlIIIlII2 = this.IlIlllIIIIllIllllIllIIlIl.get(i);
            final double iiiIllIIllIIIIllIllIIIlIl = iiiIlllIIllllllIIIlIIIlII2.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(entityLivingBase);
            if (iiiIllIIllIIIIllIllIIIlIl <= n) {
                iiiIlllIIllllllIIIlIIIlII = iiiIlllIIllllllIIIlIIIlII2;
                n = iiiIllIIllIIIIllIllIIIlIl;
            }
        }
        return (iiiIlllIIllllllIIIlIIIlII != null) ? iiiIlllIIllllllIIIlIIIlII.lIIIIlIIllIIlIIlIIIlIIllI : null;
    }
    
    public lIllIIIIlIIlIllIIIlIlIlll IlllIIIlIlllIllIlIIlllIlI(final EntityLivingBase entityLivingBase) {
        double n = 1.042553186416626 * 1.7243179132579237E308;
        lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll = null;
        for (final String s : this.IlllIllIlIIIIlIIlIIllIIIl.keySet()) {
            if (this.lIIIIIIIIIlIllIIllIlIIlIl(s)) {
                final lIllIIIIlIIlIllIIIlIlIlll liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s);
                if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                    continue;
                }
                final double iiiIllIIllIIIIllIllIIIlIl = liiiIlIIllIIlIIlIIIlIIllI.IIIIllIIllIIIIllIllIIIlIl(entityLivingBase);
                if (iiiIllIIllIIIIllIllIIIlIl > n) {
                    continue;
                }
                lIllIIIIlIIlIllIIIlIlIlll = liiiIlIIllIIlIIlIIIlIIllI;
                n = iiiIllIIllIIIIllIllIIIlIl;
            }
        }
        return lIllIIIIlIIlIllIIIlIlIlll;
    }
    
    private void llIIlllIIIIlllIllIlIlllIl() {
        final Iterator<IIIIlllIIllllllIIIlIIIlII> iterator = (Iterator<IIIIlllIIllllllIIIlIIIlII>)this.IlIlllIIIIllIllllIllIIlIl.iterator();
        while (iterator.hasNext()) {
            final IIIIlllIIllllllIIIlIIIlII iiiIlllIIllllllIIIlIIIlII = iterator.next();
            if (!iiiIlllIIllllllIIIlIIIlII.lIIIIlIIllIIlIIlIIIlIIllI.IlIlllIIIIlIllIlllIlIIIll() || Math.abs(this.IIIllIllIlIlllllllIlIlIII - iiiIlllIIllllllIIIlIIIlII.lIIIIIIIIIlIllIIllIlIIlIl) > 300) {
                iterator.remove();
            }
        }
    }
    
    private void lIIlIlIllIIlIIIlIIIlllIII() {
        boolean b = false;
        final boolean b2 = this.lIIIIlIIllIIlIIlIIIlIIllI.lllIIIIIlIllIlIIIllllllII.nextInt(50) == 0;
        final Iterator iterator = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
        while (iterator.hasNext()) {
            final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII = iterator.next();
            if (b2) {
                ilIllIlIIIllIlllIlllIlIII.IIIIllIlIIIllIlllIlllllIl();
            }
            if (!this.IIIIllIIllIIIIllIllIIIlIl(ilIllIlIIIllIlllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI, ilIllIlIIIllIlllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl, ilIllIlIIIllIlllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI) || Math.abs(this.IIIllIllIlIlllllllIlIlIII - ilIllIlIIIllIlllIlllIlIII.IlIlIIIlllIIIlIlllIlIllIl) > 1200) {
                final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
                illlIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI -= ilIllIlIIIllIlllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI;
                final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI2 = this.IlllIIIlIlllIllIlIIlllIlI;
                illlIIIlIlllIllIlIIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl -= ilIllIlIIIllIlllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl;
                final IlllIllllIIIIIlIlIlIIIllI illlIIIlIlllIllIlIIlllIlI3 = this.IlllIIIlIlllIllIlIIlllIlI;
                illlIIIlIlllIllIlIIlllIlI3.IlllIIIlIlllIllIlIIlllIlI -= ilIllIlIIIllIlllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI;
                b = true;
                ilIllIlIIIllIlllIlllIlIII.IIIllIllIlIlllllllIlIlIII = true;
                iterator.remove();
            }
        }
        if (b) {
            this.IIIlllIIIllIllIlIIIIIIlII();
        }
    }
    
    private boolean IIIIllIIllIIIIllIllIIIlIl(final int n, final int n2, final int n3) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI.getBlock(n, n2, n3) == IllllllIllIIlllIllIIlIIll.lIIIIIIlIIllllllIIIlIlIIl;
    }
    
    private void IIIlllIIIllIllIlIIIIIIlII() {
        final int size = this.lIIIIIIIIIlIllIIllIlIIlIl.size();
        if (size == 0) {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(0, 0, 0);
            this.IIIIllIIllIIIIllIllIIIlIl = 0;
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI / size, this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl / size, this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI / size);
            int max = 0;
            final Iterator<IlIllIlIIIllIlllIlllIlIII> iterator = this.lIIIIIIIIIlIllIIllIlIIlIl.iterator();
            while (iterator.hasNext()) {
                max = Math.max(iterator.next().lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI), max);
            }
            this.IIIIllIIllIIIIllIllIIIlIl = Math.max(32, (int)Math.sqrt(max) + 1);
        }
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final String key) {
        final Integer n = this.IlllIllIlIIIIlIIlIIllIIIl.get(key);
        return (n != null) ? n : 0;
    }
    
    public int lIIIIlIIllIIlIIlIIIlIIllI(final String key, final int n) {
        final int liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI(key) + n, -30, 10);
        this.IlllIllIlIIIIlIIlIIllIIIl.put(key, liiiIlIIllIIlIIlIIIlIIllI);
        return liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI(s) <= -15;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.IllIIIIIIIlIlIllllIIllIII = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("PopSize");
        this.IIIIllIIllIIIIllIllIIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Radius");
        this.llIIlllIIIIlllIllIlIlllIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Golems");
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Stable");
        this.IIIllIllIlIlllllllIlIlIII = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Tick");
        this.lIIIIllIIlIlIllIIIlIllIlI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("MTick");
        this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("CX");
        this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("CY");
        this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("CZ");
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("ACX");
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("ACY");
        this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("ACZ");
        final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Doors", 10);
        for (int i = 0; i < illlIIIlIlllIllIlIIlllIlI.IIIIllIlIIIllIlllIlllllIl(); ++i) {
            final IlIIIllIIlIIlllIllllIIIIl liiiiiiiiIlIllIIllIlIIlIl = illlIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl(i);
            this.lIIIIIIIIIlIllIIllIlIIlIl.add(new IlIllIlIIIllIlllIlllIlIII(liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("X"), liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("Y"), liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("Z"), liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("IDX"), liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("IDZ"), liiiiiiiiIlIllIIllIlIIlIl.IlIlIIIlllIIIlIlllIlIllIl("TS")));
        }
        final IllIlllIlIllIIIIIIllIllll illlIIIlIlllIllIlIIlllIlI2 = ilIIIllIIlIIlllIllllIIIIl.IlllIIIlIlllIllIlIIlllIlI("Players", 10);
        for (int j = 0; j < illlIIIlIlllIllIlIIlllIlI2.IIIIllIlIIIllIlllIlllllIl(); ++j) {
            final IlIIIllIIlIIlllIllllIIIIl liiiiiiiiIlIllIIllIlIIlIl2 = illlIIIlIlllIllIlIIlllIlI2.lIIIIIIIIIlIllIIllIlIIlIl(j);
            this.IlllIllIlIIIIlIIlIIllIIIl.put(liiiiiiiiIlIllIIllIlIIlIl2.IlllIllIlIIIIlIIlIIllIIIl("Name"), liiiiiiiiIlIllIIllIlIIlIl2.IlIlIIIlllIIIlIlllIlIllIl("S"));
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("PopSize", this.IllIIIIIIIlIlIllllIIllIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Radius", this.IIIIllIIllIIIIllIllIIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Golems", this.llIIlllIIIIlllIllIlIlllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Stable", this.IlIlIIIlllIIIlIlllIlIllIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Tick", this.IIIllIllIlIlllllllIlIlIII);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("MTick", this.lIIIIllIIlIlIllIIIlIllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CX", this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CY", this.IIIIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("CZ", this.IIIIllIlIIIllIlllIlllllIl.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ACX", this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ACY", this.IlllIIIlIlllIllIlIIlllIlI.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("ACZ", this.IlllIIIlIlllIllIlIIlllIlI.IlllIIIlIlllIllIlIIlllIlI);
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll = new IllIlllIlIllIIIIIIllIllll();
        for (final IlIllIlIIIllIlllIlllIlIII ilIllIlIIIllIlllIlllIlIII : this.lIIIIIIIIIlIllIIllIlIIlIl) {
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("X", ilIllIlIIIllIlllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI);
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("Y", ilIllIlIIIllIlllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl);
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("Z", ilIllIlIIIllIlllIlllIlIII.IlllIIIlIlllIllIlIIlllIlI);
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("IDX", ilIllIlIIIllIlllIlllIlIII.IIIIllIlIIIllIlllIlllllIl);
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("IDZ", ilIllIlIIIllIlllIlllIlIII.IIIIllIIllIIIIllIllIIIlIl);
            ilIIIllIIlIIlllIllllIIIIl2.lIIIIlIIllIIlIIlIIIlIIllI("TS", ilIllIlIIIllIlllIlllIlIII.IlIlIIIlllIIIlIlllIlIllIl);
            illIlllIlIllIIIIIIllIllll.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl2);
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Doors", illIlllIlIllIIIIIIllIllll);
        final IllIlllIlIllIIIIIIllIllll illIlllIlIllIIIIIIllIllll2 = new IllIlllIlIllIIIIIIllIllll();
        for (final String key : this.IlllIllIlIIIIlIIlIIllIIIl.keySet()) {
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl3 = new IlIIIllIIlIIlllIllllIIIIl();
            ilIIIllIIlIIlllIllllIIIIl3.lIIIIlIIllIIlIIlIIIlIIllI("Name", key);
            ilIIIllIIlIIlllIllllIIIIl3.lIIIIlIIllIIlIIlIIIlIIllI("S", this.IlllIllIlIIIIlIIlIIllIIIl.get(key));
            illIlllIlIllIIIIIIllIllll2.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIllIIlIIlllIllllIIIIl3);
        }
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Players", illIlllIlIllIIIIIIllIllll2);
    }
    
    public void IllIIIIIIIlIlIllllIIllIII() {
        this.lIIIIllIIlIlIllIIIlIllIlI = this.IIIllIllIlIlllllllIlIlIII;
    }
    
    public boolean lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIIIllIIlIlIllIIIlIllIlI == 0 || this.IIIllIllIlIlllllllIlIlIII - this.lIIIIllIIlIlIllIIIlIllIlI >= 3600;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        final Iterator<String> iterator = this.IlllIllIlIIIIlIIlIIllIIIl.keySet().iterator();
        while (iterator.hasNext()) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iterator.next(), n);
        }
    }
}
