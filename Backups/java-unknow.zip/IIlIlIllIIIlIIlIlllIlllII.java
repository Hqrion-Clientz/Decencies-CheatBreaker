// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIllIIIlIIlIlllIlllII extends Entity
{
    private int lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    
    public IIlIlIllIIIlIIlIlllIlllII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIIllIIIIllIllIIIlIl(0.92105263f * 0.27142859f, 0.028169014f * 8.875f);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIlIIllIIlIIlIIIlIIllI(8, 5);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final double n) {
        return n < 4096;
    }
    
    public IIlIlIllIIIlIIlIlllIlllII(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final double n, final double n2, final double n3, final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.lIIIIlIIllIIlIIlIIIlIIllI = 0;
        this.IIIIllIIllIIIIllIllIIIlIl(0.40555558f * 0.6164383f, 2.0625f * 0.121212125f);
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
        this.lIlIllIlIlIIIllllIlIllIll = 0.0f;
        int n4 = 1;
        if (lIlIlIlIlIllllIlllIIIlIlI != null && lIlIlIlIlIllllIlllIIIlIlI.IIIlIIllllIIllllllIlIIIll()) {
            this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(8, lIlIlIlIlIllllIlllIIIlIlI);
            final IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII = lIlIlIlIlIllllIlllIIIlIlI.lllIIIIIlIllIlIIIllllllII().lIIlIlIllIIlIIIlIIIlllIII("Fireworks");
            if (liIlIlIllIIlIIIlIIIlllIII != null) {
                n4 += liIlIlIllIIlIIIlIIIlllIII.IIIIllIlIIIllIlllIlllllIl("Flight");
            }
        }
        this.IllIIlIIlllllIllIIIlllIII = this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (3.954545497894287 * 2.5287356044644807E-4);
        this.IlllIIlllIIIIllIIllllIlIl = this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (2.263157844543457 * 4.4186047491606944E-4);
        this.lIlIlIllIIIIIIIIllllIIllI = 0.031428570786300986 * 1.5909091234207153;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 10 * n4 + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(6) + this.IlIlllIIIIlIllIlllIlIIIll.nextInt(7);
    }
    
    @Override
    public void lIIIIllIIlIlIllIIIlIllIlI(final double n, final double n2, final double n3) {
        this.IllIIlIIlllllIllIIIlllIII = n;
        this.lIlIlIllIIIIIIIIllllIIllI = n2;
        this.IlllIIlllIIIIllIIllllIlIl = n3;
        if (this.IIlIIllIIIllllIIlllIllIIl == 0.0f && this.IlIlIIIlllllIIIlIlIlIllII == 0.0f) {
            final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n * n + n3 * n3);
            final float n4 = (float)(Math.atan2(n, n3) * 180 / (0.9555555582046509 * 3.287713233014296));
            this.IllllIllllIlIIIlIIIllllll = n4;
            this.IlIlIIIlllllIIIlIlIlIllII = n4;
            final float n5 = (float)(Math.atan2(n2, liiiIlIIllIIlIIlIIIlIIllI) * 180 / (0.013513513840734959 * 232.47785073633605));
            this.IllIIlllIllIlIllIlIIIIIII = n5;
            this.IIlIIllIIIllllIIlllIllIIl = n5;
        }
    }
    
    @Override
    public void x_() {
        this.lIlIlIIIlIIllllllllIIlllI = this.IIIlIIlIlIIIlllIIlIllllll;
        this.IlIlllIllIlIllIlllIlllIll = this.IllIlIIIIlllIIllIIlllIIlI;
        this.llIIIllIIllllIlIlIlIlIIll = this.IllIlIlIllllIlIIllllIIlll;
        super.x_();
        this.IllIIlIIlllllIllIIIlllIII *= 1.385227252085778 * 0.8301886916160583;
        this.IlllIIlllIIIIllIIllllIlIl *= 2.0000000414641015 * 0.574999988079071;
        this.lIlIlIllIIIIIIIIllllIIllI += 1.2878787517547607 * 0.03105882440058833;
        this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl);
        this.IllllIllllIlIIIlIIIllllll = (float)(Math.atan2(this.IllIIlIIlllllIllIIIlllIII, this.IlllIIlllIIIIllIIllllIlIl) * 180 / (6.9563839402652246 * 0.4516128897666931));
        this.IllIIlllIllIlIllIlIIIIIII = (float)(Math.atan2(this.lIlIlIllIIIIIIIIllllIIllI, liiiIlIIllIIlIIlIIIlIIllI) * 180 / (1.7647058963775635 * 1.780235822886173));
        while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl < -180) {
            this.IIlIIllIIIllllIIlllIllIIl -= 360;
        }
        while (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl >= 180) {
            this.IIlIIllIIIllllIIlllIllIIl += 360;
        }
        while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII < -180) {
            this.IlIlIIIlllllIIIlIlIlIllII -= 360;
        }
        while (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII >= 180) {
            this.IlIlIIIlllllIIIlIlIlIllII += 360;
        }
        this.IllIIlllIllIlIllIlIIIIIII = this.IIlIIllIIIllllIIlllIllIIl + (this.IllIIlllIllIlIllIlIIIIIII - this.IIlIIllIIIllllIIlllIllIIl) * (0.5529412f * 0.3617021f);
        this.IllllIllllIlIIIlIIIllllll = this.IlIlIIIlllllIIIlIlIlIllII + (this.IllllIllllIlIIIlIIIllllll - this.IlIlIIIlllllIIIlIlIlIllII) * (0.25151515f * 0.79518074f);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 0) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, "fireworks.launch", 3, 1.0f);
        }
        ++this.lIIIIlIIllIIlIIlIIIlIIllI;
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.lIIIIlIIllIIlIIlIIIlIIllI % 2 < 2) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("fireworksSpark", this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI - 3.999999841054287 * 0.07500000298023224, this.IllIlIlIllllIlIIllllIIlll, this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (0.374999980442227 * 0.13333334028720856), -this.lIlIlIllIIIIIIIIllllIIllI * (0.6486486196517944 * 0.7708333677922702), this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * (6.857142925262451 * 0.007291666594230467));
        }
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.lIIIIlIIllIIlIIlIIIlIIllI > this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this, (byte)17);
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final byte b) {
        if (b == 17 && this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final lIlIlIlIlIllllIlllIIIlIlI ilIlIIIlllIIIlIlllIlIllIl = this.IlIIllIIIlllIIIIlIIIIlIll.IlIlIIIlllIIIlIlllIlIllIl(8);
            IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII = null;
            if (ilIlIIIlllIIIlIlllIlIllIl != null && ilIlIIIlllIIIlIlllIlIllIl.IIIlIIllllIIllllllIlIIIll()) {
                liIlIlIllIIlIIIlIIIlllIII = ilIlIIIlllIIIlIlllIlIllIl.lllIIIIIlIllIlIIIllllllII().lIIlIlIllIIlIIIlIIIlllIII("Fireworks");
            }
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl, liIlIlIllIIlIIIlIIIlllIII);
        }
        super.lIIIIlIIllIIlIIlIIIlIIllI(b);
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Life", this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("LifeTime", this.lIIIIIIIIIlIllIIllIlIIlIl);
        final lIlIlIlIlIllllIlllIIIlIlI ilIlIIIlllIIIlIlllIlIllIl = this.IlIIllIIIlllIIIIlIIIIlIll.IlIlIIIlllIIIlIlllIlIllIl(8);
        if (ilIlIIIlllIIIlIlllIlIllIl != null) {
            final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl2 = new IlIIIllIIlIIlllIllllIIIIl();
            ilIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl(ilIIIllIIlIIlllIllllIIIIl2);
            ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("FireworksItem", ilIIIllIIlIIlllIllllIIIIl2);
        }
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Life");
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("LifeTime");
        final IlIIIllIIlIIlllIllllIIIIl liIlIlIllIIlIIIlIIIlllIII = ilIIIllIIlIIlllIllllIIIIl.lIIlIlIllIIlIIIlIIIlllIII("FireworksItem");
        if (liIlIlIllIIlIIIlIIIlllIII != null) {
            final lIlIlIlIlIllllIlllIIIlIlI liiiIlIIllIIlIIlIIIlIIllI = lIlIlIlIlIllllIlllIIIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(liIlIlIllIIlIIIlIIIlllIII);
            if (liiiIlIIllIIlIIlIIIlIIllI != null) {
                this.IlIIllIIIlllIIIIlIIIIlIll.lIIIIIIIIIlIllIIllIlIIlIl(8, liiiIlIIllIIlIIlIIIlIIllI);
            }
        }
    }
    
    @Override
    public float llIIlllIIIIlllIllIlIlllIl() {
        return 0.0f;
    }
    
    @Override
    public float lIIIIIIIIIlIllIIllIlIIlIl(final float n) {
        return super.lIIIIIIIIIlIllIIllIlIIlIl(n);
    }
    
    @Override
    public int lIIIIlIIllIIlIIlIIIlIIllI(final float n) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    @Override
    public boolean r_() {
        return false;
    }
}
