import java.util.Arrays;
import org.apache.commons.lang3.ArrayUtils;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIIIllllllIlIIlllll extends llllIlIlIIlIIllllllllllll
{
    private final IIIIIlllllIIlIllIlIlIlIll lIIIIlIIllIIlIIlIIIlIIllI;
    private final Minecraft lIIIIIIIIIlIllIIllIlIIlIl;
    private final IllIllllllIlllIIIlllIIlII[] lIIlIlIllIIlIIIlIIIlllIII;
    private int IIIlllIIIllIllIlIIIIIIlII;
    
    public IIlIIllIIIllllllIlIIlllll(final IIIIIlllllIIlIllIlIlIlIll liiiIlIIllIIlIIlIIIlIIllI, final Minecraft liiiiiiiiIlIllIIllIlIIlIl) {
        super(liiiiiiiiIlIllIIllIlIIlIl, liiiIlIIllIIlIIlIIIlIIllI.lIIIIIllllIIIIlIlIIIIlIlI, liiiIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI, 63, liiiIlIIllIIlIIlIIIlIIllI.IIIIIIlIlIlIllllllIlllIlI - 32, 20);
        this.IIIlllIIIllIllIlIIIIIIlII = 0;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        final KeyBinding[] a = (KeyBinding[])ArrayUtils.clone((Object[])liiiiiiiiIlIllIIllIlIIlIl.gameSettings.lllIIlIIIllIIlllIlIIIllIl);
        this.lIIlIlIllIIlIIIlIIIlllIII = new IllIllllllIlllIIIlllIIlII[a.length + KeyBinding.IlllIIIlIlllIllIlIIlllIlI().size()];
        Arrays.sort(a);
        int n = 0;
        Object anObject = null;
        final KeyBinding[] array = a;
        for (int length = a.length, i = 0; i < length; ++i) {
            final KeyBinding keyBinding = array[i];
            final String iiiIllIIllIIIIllIllIIIlIl = keyBinding.IIIIllIIllIIIIllIllIIIlIl();
            if (!iiiIllIIllIIIIllIllIIIlIl.equals(anObject)) {
                anObject = iiiIllIIllIIIIllIllIIIlIl;
                this.lIIlIlIllIIlIIIlIIIlllIII[n++] = new lIIIIlIIIlIlIlIIllIIlIIIl(this, iiiIllIIllIIIIllIllIIIlIl);
            }
            final int stringWidth = liiiiiiiiIlIllIIllIlIIlIl.fontRendererObj.getStringWidth(IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(keyBinding.IIIllIllIlIlllllllIlIlIII(), new Object[0]));
            if (stringWidth > this.IIIlllIIIllIllIlIIIIIIlII) {
                this.IIIlllIIIllIllIlIIIIIIlII = stringWidth;
            }
            this.lIIlIlIllIIlIIIlIIIlllIII[n++] = new lIIllIlIlIlIllllIllllllll(this, keyBinding, null);
        }
    }
    
    @Override
    protected int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIlIlIllIIlIIIlIIIlllIII.length;
    }
    
    @Override
    public IllIllllllIlllIIIlllIIlII lIIIIIIIIIlIllIIllIlIIlIl(final int n) {
        return this.lIIlIlIllIIlIIIlIIIlllIII[n];
    }
    
    @Override
    protected int IIIIllIlIIIllIlllIlllllIl() {
        return super.IIIIllIlIIIllIlllIlllllIl() + 15;
    }
    
    @Override
    public int IIIIllIIllIIIIllIllIIIlIl() {
        return super.IIIIllIIllIIIIllIllIIIlIl() + 32;
    }
}
