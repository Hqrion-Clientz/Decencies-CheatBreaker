// 
// Decompiled by Procyon v0.5.36
// 

public class IIllIIllIlllIIIIlIIIlIlll extends IIllIlllIIlllllIlllIIIlIl
{
    private IllIllIIlIIlIlllIIllIIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    
    public IIllIIllIlllIIIIlIIIlIlll() {
    }
    
    public IIllIIllIlllIIIIlIIIlIlll(final IllIllIIlIIlIlllIIllIIIlI liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = IllIIlIIlIlllllIllIIlllII.lIIIIlIIllIIlIIlIIIlIIllI(lIlIllllllllIlIIIllIIllII.IlllIIIlIlllIllIlIIlllIlI(32767));
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
        lIlIllllllllIlIIIllIIllII.lIIIIlIIllIIlIIlIIIlIIllI(IllIIlIIlIlllllIllIIlllII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI));
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIlIllIIIIIIlIIl ilIllIIlIlIlIllIIIIIIlIIl) {
        ilIllIIlIlIlIllIIIIIIlIIl.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return true;
    }
    
    public IllIllIIlIIlIlllIIllIIIlI IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIIIlIlIllIlIlIIIlIlIII lIlIIIlIlIllIlIlIIIlIlIII) {
        this.lIIIIlIIllIIlIIlIIIlIIllI((IlIllIIlIlIlIllIIIIIIlIIl)lIlIIIlIlIllIlIlIIIlIlIII);
    }
}
