import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllIIIlIlllIllIIIIIIll extends IIIllIlllIlIIIlIlIIlllIIl
{
    public final lllIIIlllllllIlIIIlIllIIl lIIIIlIIllIIlIIlIIIlIIllI;
    private IIlllIIllIllIlIllIIIIIIlI lIIIIIIIIIlIllIIllIlIIlIl;
    private double IlllIIIlIlllIllIlIIlllIlI;
    private double IIIIllIlIIIllIlllIlllllIl;
    private Entity IIIIllIIllIIIIllIllIIIlIl;
    private float IlIlIIIlllIIIlIlllIlIllIl;
    private lIlIIlIlIIIIIIlIIIlllIIII IIIllIllIlIlllllllIlIlIII;
    private IIIIIllIlIllIIIllIllIllll IllIIIIIIIlIlIllllIIllIII;
    private Class lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIlIllIIIlIlllIllIIIIIIll(final IIlllIIllIllIlIllIIIIIIlI liiiiiiiiIlIllIIllIlIIlIl, final Class liiiIllIIlIlIllIIIlIllIlI, final float ilIlIIIlllIIIlIlllIlIllIl, final double illlIIIlIlllIllIlIIlllIlI, final double iiiIllIlIIIllIlllIlllllIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = new llllIlIIIllIlllIIIIIlllII(this);
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.IllIIIIIIIlIlIllllIIllIII = liiiiiiiiIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll();
        this.lIIIIlIIllIIlIIlIIIlIIllI(1);
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        if (this.lIIIIllIIlIlIllIIIlIllIlI == lIllIIIIlIIlIllIIIlIlIlll.class) {
            if (this.lIIIIIIIIIlIllIIllIlIIlIl instanceof IIIIIllIIlIlllllIlIllllIl && ((IIIIIllIIlIlllllIlIllllIl)this.lIIIIIIIIIlIllIIllIlIIlIl).llllIIllIIlIIllIIIllIlIlI()) {
                return false;
            }
            this.IIIIllIIllIIIIllIllIIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIIIIIIlIllIIllIlIIlIl, (double)this.IlIlIIIlllIIIlIlllIlIllIl);
            if (this.IIIIllIIllIIIIllIllIIIlIl == null) {
                return false;
            }
        }
        else {
            final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIIIIIIlIllIIllIlIIlIl.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, this.lIIIIIIIIIlIllIIllIlIIlIl.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(this.IlIlIIIlllIIIlIlllIlIllIl, 3, this.IlIlIIIlllIIIlIlllIlIllIl), this.lIIIIlIIllIIlIIlIIIlIIllI);
            if (liiiIlIIllIIlIIlIIIlIIllI.isEmpty()) {
                return false;
            }
            this.IIIIllIIllIIIIllIllIIIlIl = liiiIlIIllIIlIIlIIIlIIllI.get(0);
        }
        final lIllIIIIlllllIIlIllIIIIII liiiiiiiiIlIllIIllIlIIlIl = IIllIlIlIIllIIllIlIIIllII.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl, 16, 7, lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIIllIIIIllIllIIIlIl.IIIlIIlIlIIIlllIIlIllllll, this.IIIIllIIllIIIIllIllIIIlIl.IllIlIIIIlllIIllIIlllIIlI, this.IIIIllIIllIIIIllIllIIIlIl.IllIlIlIllllIlIIllllIIlll));
        if (liiiiiiiiIlIllIIllIlIIlIl == null) {
            return false;
        }
        if (this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl(liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI) < this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIIllIIIIllIllIIIlIl(this.lIIIIIIIIIlIllIIllIlIIlIl)) {
            return false;
        }
        this.IIIllIllIlIlllllllIlIlIII = this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, liiiiiiiiIlIllIIllIlIIlIl.IlllIIIlIlllIllIlIIlllIlI);
        return this.IIIllIllIlIlllllllIlIlIII != null && this.IIIllIllIlIlllllllIlIlIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl);
    }
    
    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl() {
        return !this.IllIIIIIIIlIlIllllIIllIII.IlIlIIIlllIIIlIlllIlIllIl();
    }
    
    @Override
    public void IIIIllIIllIIIIllIllIIIlIl() {
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII, this.IlllIIIlIlllIllIlIIlllIlI);
    }
    
    @Override
    public void IlllIIIlIlllIllIlIIlllIlI() {
        this.IIIIllIIllIIIIllIllIIIlIl = null;
    }
    
    @Override
    public void IIIIllIlIIIllIlllIlllllIl() {
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.IIIIllIIllIIIIllIllIIIlIl(this.IIIIllIIllIIIIllIllIIIlIl) < 49) {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll().lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl);
        }
        else {
            this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIlIllllIlIIllllIIlll().lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIIIlIlllIllIlIIlllIlI);
        }
    }
}
