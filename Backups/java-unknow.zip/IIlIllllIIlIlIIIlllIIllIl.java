// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIllllIIlIlIIIlllIIllIl extends IllllIllIllIIIIIIlIllIIll
{
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
    }
    
    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(final lIlIllllllllIlIIIllIIllII lIlIllllllllIlIIIllIIllII) {
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll liIlllIIlllIlIllIIlIIIIll) {
        liIlllIIlllIlIllIIlIIIIll.lIIIIlIIllIIlIIlIIIlIIllI(this);
    }
}
