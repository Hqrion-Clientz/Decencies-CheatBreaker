import java.util.Iterator;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlllIIlIlIlIlIllIIIl extends IlllIIIllIlIIlIllIIlIlllI implements IIllIlIIllIlIlllllIllIIll, IllIlllIllIIlIlIIIlIIlllI, lIIlllIllllIIlIlIllllIIII
{
    public double lIIIIlIIllIIlIIlIIIlIIllI;
    public double lIIIIIIIIIlIllIIllIlIIlIl;
    public double IlllIIIlIlllIllIlIIlllIlI;
    public double[][] IIIIllIlIIIllIlllIlllllIl;
    public int IIIIllIIllIIIIllIllIIIlIl;
    public llIlllIlllllIlIIIlIIlIIII[] llIIIlllllIlllIIllIlIIlII;
    public llIlllIlllllIlIIIlIIlIIII lIIIlIlIIIlIlIlllIlIlllII;
    public llIlllIlllllIlIIIlIIlIIII llIlIlIIIIIIIlllIIIllIlll;
    public llIlllIlllllIlIIIlIIlIIII IllIIIIIIlIlIlllllllIIllI;
    public llIlllIlllllIlIIIlIIlIIII IlIIlllIIlIlIIIlIlllllIll;
    public llIlllIlllllIlIIIlIIlIIII lIllIllIIlIlIIIIllIllllll;
    public llIlllIlllllIlIIIlIIlIIII llllllIIIIIlllllIllIlIllI;
    public llIlllIlllllIlIIIlIIlIIII IlllIIllllllllIlIlIlllllI;
    public float lIllIIIIIlIllIllllIlIllII;
    public float IIlllllllIllIlIllIIIlllIl;
    public boolean IlllIlIlllIlIlllIIlllIlIl;
    public boolean IlIIIIlIlllIllIlIlIIlIlIl;
    private Entity IIIIIlllIllIIIIllIllIIIII;
    public int lIIlIlIllllllIllllIIllllI;
    public IIllIllIlllllIIlIIlIIlIIl llIIllIIIllllIIIllIIIIIIl;
    
    public IIlIlIlllIIlIlIlIlIllIIIl(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI) {
        super(iiiiiIllIlIIIIlIlllIllllI);
        this.IIIIllIlIIIllIlllIlllllIl = new double[64][3];
        this.IIIIllIIllIIIIllIllIIIlIl = -1;
        this.llIIIlllllIlllIIllIlIIlII = new llIlllIlllllIlIIIlIIlIIII[] { this.lIIIlIlIIIlIlIlllIlIlllII = new llIlllIlllllIlIIIlIIlIIII(this, "head", 6, 6), this.llIlIlIIIIIIIlllIIIllIlll = new llIlllIlllllIlIIIlIIlIIII(this, "body", 8, 8), this.IllIIIIIIlIlIlllllllIIllI = new llIlllIlllllIlIIIlIIlIIII(this, "tail", 4, 4), this.IlIIlllIIlIlIIIlIlllllIll = new llIlllIlllllIlIIIlIIlIIII(this, "tail", 4, 4), this.lIllIllIIlIlIIIIllIllllll = new llIlllIlllllIlIIIlIIlIIII(this, "tail", 4, 4), this.llllllIIIIIlllllIllIlIllI = new llIlllIlllllIlIIIlIIlIIII(this, "wing", 4, 4), this.IlllIIllllllllIlIlIlllllI = new llIlllIlllllIlIIIlIIlIIII(this, "wing", 4, 4) };
        this.IlllIllIlIIIIlIIlIIllIIIl(this.IlllIIllllllllIlIlIlllllI());
        this.IIIIllIIllIIIIllIllIIIlIl(16, 8);
        this.lllIIllllIIlIlIlIlIIIlIII = true;
        this.IIlIlllIllIlIlIIIIIlllIll = true;
        this.lIIIIIIIIIlIllIIllIlIIlIl = 100;
        this.IllIIIIllllllIlllllIlIlll = true;
    }
    
    @Override
    protected void lIllIllIlIIllIllIlIlIIlIl() {
        super.lIllIllIlIIllIllIlIlIIlIl();
        this.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlllIIlIIlIIllIIl.lIIIIlIIllIIlIIlIIIlIIllI).lIIIIlIIllIIlIIlIIIlIIllI(200);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl() {
        super.lIIIIIIIIIlIllIIllIlIIlIl();
    }
    
    public double[] lIIIIIIIIIlIllIIllIlIIlIl(final int n, float n2) {
        if (this.getHealth() <= 0.0f) {
            n2 = 0.0f;
        }
        n2 = 1.0f - n2;
        final int n3 = this.IIIIllIIllIIIIllIllIIIlIl - n * 1 & 0x3F;
        final int n4 = this.IIIIllIIllIIIIllIllIIIlIl - n * 1 - 1 & 0x3F;
        final double[] array = new double[3];
        final double n5 = this.IIIIllIlIIIllIlllIlllllIl[n3][0];
        array[0] = n5 + MathHelper.IIIllIllIlIlllllllIlIlIII(this.IIIIllIlIIIllIlllIlllllIl[n4][0] - n5) * n2;
        final double n6 = this.IIIIllIlIIIllIlllIlllllIl[n3][1];
        array[1] = n6 + (this.IIIIllIlIIIllIlllIlllllIl[n4][1] - n6) * n2;
        array[2] = this.IIIIllIlIIIllIlllIlllllIl[n3][2] + (this.IIIIllIlIIIllIlllIlllllIl[n4][2] - this.IIIIllIlIIIllIlllIlllllIl[n3][2]) * n2;
        return array;
    }
    
    @Override
    public void i_() {
        if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IIlllllllIllIlIllIIIlllIl * (0.52307695f * 6.0059857f) * 2.0f);
            if (MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.lIllIIIIIlIllIllllIlIllII * (1.0f * 3.1415927f) * 2.0f) <= -0.92222226f * 0.3253012f && liiiiiiiiIlIllIIllIlIIlIl >= 1.1486486f * -0.2611765f) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, "mob.enderdragon.wings", 5, 4.769231f * 0.16774194f + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * (2.6f * 0.11538462f), false);
            }
        }
        this.lIllIIIIIlIllIllllIlIllII = this.IIlllllllIllIlIllIIIlllIl;
        if (this.getHealth() <= 0.0f) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("largeexplode", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 1.3958334f * 0.35820895f) * 8, this.IllIlIIIIlllIIllIIlllIIlI + 2 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 1.6666666f * 0.3f) * 4, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.35820895f * 1.3958334f) * 8, 0.0, 0.0, 0.0);
        }
        else {
            this.refreshResources();
            final float n = 0.28865978f * 0.6928572f / (MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl) * 10 + 1.0f) * (float)Math.pow(2, this.lIlIlIllIIIIIIIIllllIIllI);
            if (this.IlIIIIlIlllIllIlIlIIlIlIl) {
                this.IIlllllllIllIlIllIIIlllIl += n * (2.3448277f * 0.21323529f);
            }
            else {
                this.IIlllllllIllIlIllIIIlllIl += n;
            }
            this.IllllIllllIlIIIlIIIllllll = MathHelper.IIIllIllIlIlllllllIlIlIII(this.IllllIllllIlIIIlIIIllllll);
            if (this.IIIIllIIllIIIIllIllIIIlIl < 0) {
                for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl.length; ++i) {
                    this.IIIIllIlIIIllIlllIlllllIl[i][0] = this.IllllIllllIlIIIlIIIllllll;
                    this.IIIIllIlIIIllIlllIlllllIl[i][1] = this.IllIlIIIIlllIIllIIlllIIlI;
                }
            }
            if (++this.IIIIllIIllIIIIllIllIIIlIl == this.IIIIllIlIIIllIlllIlllllIl.length) {
                this.IIIIllIIllIIIIllIllIIIlIl = 0;
            }
            this.IIIIllIlIIIllIlllIlllllIl[this.IIIIllIIllIIIIllIllIIIlIl][0] = this.IllllIllllIlIIIlIIIllllll;
            this.IIIIllIlIIIllIlllIlllllIl[this.IIIIllIIllIIIIllIllIIIlIl][1] = this.IllIlIIIIlllIIllIIlllIIlI;
            if (this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                if (this.llIIllllIlIlIllIlIllIlIlI > 0) {
                    final double n2 = this.IIIlIIlIlIIIlllIIlIllllll + (this.IlllIIIIlllllIlIlllllIlll - this.IIIlIIlIlIIIlllIIlIllllll) / this.llIIllllIlIlIllIlIllIlIlI;
                    final double n3 = this.IllIlIIIIlllIIllIIlllIIlI + (this.IIIlIllIIllllIIIllllIllll - this.IllIlIIIIlllIIllIIlllIIlI) / this.llIIllllIlIlIllIlIllIlIlI;
                    final double n4 = this.IllIlIlIllllIlIIllllIIlll + (this.llllIIIllllllIlllIIlIIlll - this.IllIlIlIllllIlIIllllIIlll) / this.llIIllllIlIlIllIlIllIlIlI;
                    this.IllllIllllIlIIIlIIIllllll += (float)(MathHelper.IIIllIllIlIlllllllIlIlIII(this.lIlllIIIlIlIIlIIIIIIlIlII - this.IllllIllllIlIIIlIIIllllll) / this.llIIllllIlIlIllIlIllIlIlI);
                    this.IllIIlllIllIlIllIlIIIIIII += (float)((this.IlIllIIIIIlIlllIIIIlllIIl - this.IllIIlllIllIlIllIlIIIIIII) / this.llIIllllIlIlIllIlIllIlIlI);
                    --this.llIIllllIlIlIllIlIllIlIlI;
                    this.IlllIIIlIlllIllIlIIlllIlI(n2, n3, n4);
                    this.IlIlIIIlllIIIlIlllIlIllIl(this.IllllIllllIlIIIlIIIllllll, this.IllIIlllIllIlIllIlIIIIIII);
                }
            }
            else {
                final double y = this.lIIIIlIIllIIlIIlIIIlIIllI - this.IIIlIIlIlIIIlllIIlIllllll;
                final double n5 = this.lIIIIIIIIIlIllIIllIlIIlIl - this.IllIlIIIIlllIIllIIlllIIlI;
                final double x = this.IlllIIIlIlllIllIlIIlllIlI - this.IllIlIlIllllIlIIllllIIlll;
                final double n6 = y * y + n5 * n5 + x * x;
                if (this.IIIIIlllIllIIIIllIllIIIII != null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI = this.IIIIIlllIllIIIIllIllIIIII.IIIlIIlIlIIIlllIIlIllllll;
                    this.IlllIIIlIlllIllIlIIlllIlI = this.IIIIIlllIllIIIIllIllIIIII.IllIlIlIllllIlIIllllIIlll;
                    final double n7 = this.lIIIIlIIllIIlIIlIIIlIIllI - this.IIIlIIlIlIIIlllIIlIllllll;
                    final double n8 = this.IlllIIIlIlllIllIlIIlllIlI - this.IllIlIlIllllIlIIllllIIlll;
                    double n9 = 1.1538461446762085 * 0.34666667458746175 + Math.sqrt(n7 * n7 + n8 * n8) / 80 - 1.0;
                    if (n9 > 10) {
                        n9 = 10;
                    }
                    this.lIIIIIIIIIlIllIIllIlIIlIl = this.IIIIIlllIllIIIIllIllIIIII.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl + n9;
                }
                else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * 2;
                    this.IlllIIIlIlllIllIlIIlllIlI += this.IlIlllIIIIlIllIlllIlIIIll.nextGaussian() * 2;
                }
                if (this.IlllIlIlllIlIlllIIlllIlIl || n6 < 100 || n6 > 22500 || this.lIIIlllIlIlllIIIIIIIIIlII || this.IIIIlIIIlllllllllIlllIlll) {
                    this.IlIlIIIlllIIIlIlllIlIllIl();
                }
                double n10 = n5 / MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(y * y + x * x);
                final float n11 = 0.4935484f * 1.2156863f;
                if (n10 < -n11) {
                    n10 = -n11;
                }
                if (n10 > n11) {
                    n10 = n11;
                }
                this.lIlIlIllIIIIIIIIllllIIllI += n10 * (0.8837209343910217 * 0.11315789589054696);
                this.IllllIllllIlIIIlIIIllllll = MathHelper.IIIllIllIlIlllllllIlIlIII(this.IllllIllllIlIIIlIIIllllll);
                double iiIllIllIlIlllllllIlIlIII = MathHelper.IIIllIllIlIlllllllIlIlIII(180 - Math.atan2(y, x) * 180 / (2.3271056282276086 * 1.350000023841858) - this.IllllIllllIlIIIlIIIllllll);
                if (iiIllIllIlIlllllllIlIlIII > 50) {
                    iiIllIllIlIlllllllIlIlIII = 50;
                }
                if (iiIllIllIlIlllllllIlIlIII < -50) {
                    iiIllIllIlIlllllllIlIlIII = -50;
                }
                final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI - this.IIIlIIlIlIIIlllIIlIllllll, this.lIIIIIIIIIlIllIIllIlIIlIl - this.IllIlIIIIlllIIllIIlllIIlI, this.IlllIIIlIlllIllIlIIlllIlI - this.IllIlIlIllllIlIIllllIIlll).lIIIIlIIllIIlIIlIIIlIIllI();
                final lIllIIIIlllllIIlIllIIIIII liiiIlIIllIIlIIlIIIlIIllI2 = lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll * (0.95f * 3.3069398f) / 180), this.lIlIlIllIIIIIIIIllllIIllI, -MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll * (0.24096386f * 13.037609f) / 180)).lIIIIlIIllIIlIIlIIIlIIllI();
                float n12 = (float)(liiiIlIIllIIlIIlIIIlIIllI2.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI) + 0.3622448988404685 * 1.380281686782837) / (3.0f * 0.5f);
                if (n12 < 0.0f) {
                    n12 = 0.0f;
                }
                this.llllIllIIIlIIIlIllIlIlIlI *= 0.82461536f * 0.9701493f;
                final float n13 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl) * 1.0f + 1.0f;
                double n14 = Math.sqrt(this.IllIIlIIlllllIllIIIlllIII * this.IllIIlIIlllllIllIIIlllIII + this.IlllIIlllIIIIllIIllllIlIl * this.IlllIIlllIIIIllIIllllIlIl) * 1.0 + 1.0;
                if (n14 > 40) {
                    n14 = 40;
                }
                this.llllIllIIIlIIIlIllIlIlIlI += (float)(iiIllIllIlIlllllllIlIlIII * (2.666666742355108 * 0.26249998807907104 / n14 / n13));
                this.IllllIllllIlIIIlIIIllllll += this.llllIllIIIlIIIlIllIlIlIlI * (0.097826086f * 1.0222223f);
                final float n15 = (float)(2 / (n14 + 1.0));
                this.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, -1, 10.333333f * 0.0058064517f * (n12 * n15 + (1.0f - n15)));
                if (this.IlIIIIlIlllIllIlIlIIlIlIl) {
                    this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII * (0.45517242244676237 * 1.7575757503509521), this.lIlIlIllIIIIIIIIllllIIllI * (1.4193548625887495 * 0.5636363625526428), this.IlllIIlllIIIIllIIllllIlIl * (0.41643837461061795 * 1.9210525751113892));
                }
                else {
                    this.IIIIllIIllIIIIllIllIIIlIl(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl);
                }
                final float n16 = 0.6037736f * 1.325f + 0.025f * 6.0f * ((float)(lIllIIIIlllllIIlIllIIIIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIlIIlllllIllIIIlllIII, this.lIlIlIllIIIIIIIIllllIIllI, this.IlllIIlllIIIIllIIllllIlIl).lIIIIlIIllIIlIIlIIIlIIllI().lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2) + 1.0) / 2.0f);
                this.IllIIlIIlllllIllIIIlllIII *= n16;
                this.IlllIIlllIIIIllIIllllIlIl *= n16;
                this.lIlIlIllIIIIIIIIllllIIllI *= 4.818181991577148 * 0.18886792317451898;
            }
            this.lIIIlIlIIllIIlllIIIlIIllI = this.IllllIllllIlIIIlIIIllllll;
            final llIlllIlllllIlIIIlIIlIIII liiIlIlIIIlIlIlllIlIlllII = this.lIIIlIlIIIlIlIlllIlIlllII;
            final llIlllIlllllIlIIIlIIlIIII liiIlIlIIIlIlIlllIlIlllII2 = this.lIIIlIlIIIlIlIlllIlIlllII;
            final float n17 = 3;
            liiIlIlIIIlIlIlllIlIlllII2.llllIIIIlIlIllIIIllllIIll = n17;
            liiIlIlIIIlIlIlllIlIlllII.IlIIlIIlIllIIIIllIIllIlIl = n17;
            final llIlllIlllllIlIIIlIIlIIII illIIIIIIlIlIlllllllIIllI = this.IllIIIIIIlIlIlllllllIIllI;
            final llIlllIlllllIlIIIlIIlIIII illIIIIIIlIlIlllllllIIllI2 = this.IllIIIIIIlIlIlllllllIIllI;
            final float n18 = 2.0f;
            illIIIIIIlIlIlllllllIIllI2.llllIIIIlIlIllIIIllllIIll = n18;
            illIIIIIIlIlIlllllllIIllI.IlIIlIIlIllIIIIllIIllIlIl = n18;
            final llIlllIlllllIlIIIlIIlIIII ilIIlllIIlIlIIIlIlllllIll = this.IlIIlllIIlIlIIIlIlllllIll;
            final llIlllIlllllIlIIIlIIlIIII ilIIlllIIlIlIIIlIlllllIll2 = this.IlIIlllIIlIlIIIlIlllllIll;
            final float n19 = 2.0f;
            ilIIlllIIlIlIIIlIlllllIll2.llllIIIIlIlIllIIIllllIIll = n19;
            ilIIlllIIlIlIIIlIlllllIll.IlIIlIIlIllIIIIllIIllIlIl = n19;
            final llIlllIlllllIlIIIlIIlIIII lIllIllIIlIlIIIIllIllllll = this.lIllIllIIlIlIIIIllIllllll;
            final llIlllIlllllIlIIIlIIlIIII lIllIllIIlIlIIIIllIllllll2 = this.lIllIllIIlIlIIIIllIllllll;
            final float n20 = 2.0f;
            lIllIllIIlIlIIIIllIllllll2.llllIIIIlIlIllIIIllllIIll = n20;
            lIllIllIIlIlIIIIllIllllll.IlIIlIIlIllIIIIllIIllIlIl = n20;
            this.llIlIlIIIIIIIlllIIIllIlll.llllIIIIlIlIllIIIllllIIll = 3;
            this.llIlIlIIIIIIIlllIIIllIlll.IlIIlIIlIllIIIIllIIllIlIl = 5;
            this.llllllIIIIIlllllIllIlIllI.llllIIIIlIlIllIIIllllIIll = 2.0f;
            this.llllllIIIIIlllllIllIlIllI.IlIIlIIlIllIIIIllIIllIlIl = 4;
            this.IlllIIllllllllIlIlIlllllI.llllIIIIlIlIllIIIllllIIll = 3;
            this.IlllIIllllllllIlIlIlllllI.IlIIlIIlIllIIIIllIIllIlIl = 4;
            final float n21 = (float)(this.lIIIIIIIIIlIllIIllIlIIlIl(5, 1.0f)[1] - this.lIIIIIIIIIlIllIIllIlIIlIl(10, 1.0f)[1]) * 10 / 180 * (0.9264706f * 3.3909256f);
            final float liiiiiiiiIlIllIIllIlIIlIl2 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n21);
            final float n22 = -MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n21);
            final float n23 = this.IllllIllllIlIIIlIIIllllll * (3.6651914f * 0.85714287f) / 180;
            final float liiiIlIIllIIlIIlIIIlIIllI3 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n23);
            final float liiiiiiiiIlIllIIllIlIIlIl3 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n23);
            this.llIlIlIIIIIIIlllIIIllIlll.x_();
            this.llIlIlIIIIIIIlllIIIllIlll.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll + liiiIlIIllIIlIIlIIIlIIllI3 * (0.8648649f * 0.578125f), this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll - liiiiiiiiIlIllIIllIlIIlIl3 * (0.3068182f * 1.6296296f), 0.0f, 0.0f);
            this.llllllIIIIIlllllIllIlIllI.x_();
            this.llllllIIIIIlllllIllIlIllI.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll + liiiiiiiiIlIllIIllIlIIlIl3 * (4.0499997f * 1.1111112f), this.IllIlIIIIlllIIllIIlllIIlI + 2, this.IllIlIlIllllIlIIllllIIlll + liiiIlIIllIIlIIlIIIlIIllI3 * (3.4117646f * 1.3189656f), 0.0f, 0.0f);
            this.IlllIIllllllllIlIlIlllllI.x_();
            this.IlllIIllllllllIlIlIlllllI.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll - liiiiiiiiIlIllIIllIlIIlIl3 * (1.0212766f * 4.40625f), this.IllIlIIIIlllIIllIIlllIIlI + 2, this.IllIlIlIllllIlIIllllIIlll - liiiIlIIllIIlIIlIIIlIIllI3 * (1.0106384f * 4.4526315f), 0.0f, 0.0f);
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll && this.lIlIlIlIIlIlllIIIIIIllllI == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.llllllIIIIIlllllIllIlIllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(4, 2, 4).IIIIllIlIIIllIlllIlllllIl(0.0, -2, 0.0)));
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.IlllIIllllllllIlIlIlllllI.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(4, 2, 4).IIIIllIlIIIllIlllIlllllIl(0.0, -2, 0.0)));
                this.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this, this.lIIIlIlIIIlIlIlllIlIlllII.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(1.0, 1.0, 1.0)));
            }
            final double[] liiiiiiiiIlIllIIllIlIIlIl4 = this.lIIIIIIIIIlIllIIllIlIIlIl(5, 1.0f);
            final double[] liiiiiiiiIlIllIIllIlIIlIl5 = this.lIIIIIIIIIlIllIIllIlIIlIl(0, 1.0f);
            final float liiiIlIIllIIlIIlIIIlIIllI4 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(this.IllllIllllIlIIIlIIIllllll * (3.4705882f * 0.9052047f) / 180 - this.llllIllIIIlIIIlIllIlIlIlI * (0.35714287f * 0.027999999f));
            final float liiiiiiiiIlIllIIllIlIIlIl6 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(this.IllllIllllIlIIIlIIIllllll * (0.58177644f * 5.4f) / 180 - this.llllIllIIIlIIIlIllIlIlIlI * (0.55999994f * 0.017857144f));
            this.lIIIlIlIIIlIlIlllIlIlllII.x_();
            this.lIIIlIlIIIlIlIlllIlIlllII.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll + liiiIlIIllIIlIIlIIIlIIllI4 * (15.62f * 0.35211268f) * liiiiiiiiIlIllIIllIlIIlIl2, this.IllIlIIIIlllIIllIIlllIIlI + (liiiiiiiiIlIllIIllIlIIlIl5[1] - liiiiiiiiIlIllIIllIlIIlIl4[1]) * 1.0 + n22 * (1.2459016f * 4.414474f), this.IllIlIlIllllIlIIllllIIlll - liiiiiiiiIlIllIIllIlIIlIl6 * (1.3174603f * 4.174699f) * liiiiiiiiIlIllIIllIlIIlIl2, 0.0f, 0.0f);
            for (int j = 0; j < 3; ++j) {
                Entity entity = null;
                if (j == 0) {
                    entity = this.IllIIIIIIlIlIlllllllIIllI;
                }
                if (j == 1) {
                    entity = this.IlIIlllIIlIlIIIlIlllllIll;
                }
                if (j == 2) {
                    entity = this.lIllIllIIlIlIIIIllIllllll;
                }
                final double[] liiiiiiiiIlIllIIllIlIIlIl7 = this.lIIIIIIIIIlIllIIllIlIIlIl(12 + j * 2, 1.0f);
                final float n24 = this.IllllIllllIlIIIlIIIllllll * (1.7708334f * 1.7740759f) / 180 + this.lIIIIIIIIIlIllIIllIlIIlIl(liiiiiiiiIlIllIIllIlIIlIl7[0] - liiiiiiiiIlIllIIllIlIIlIl4[0]) * (1.9318181f * 1.6262363f) / 180 * 1.0f;
                final float liiiIlIIllIIlIIlIIIlIIllI5 = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n24);
                final float liiiiiiiiIlIllIIllIlIIlIl8 = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n24);
                final float n25 = 0.35714287f * 4.2f;
                final float n26 = (j + 1) * 2.0f;
                entity.x_();
                entity.lIIIIIIIIIlIllIIllIlIIlIl(this.IIIlIIlIlIIIlllIIlIllllll - (liiiIlIIllIIlIIlIIIlIIllI3 * n25 + liiiIlIIllIIlIIlIIIlIIllI5 * n26) * liiiiiiiiIlIllIIllIlIIlIl2, this.IllIlIIIIlllIIllIIlllIIlI + (liiiiiiiiIlIllIIllIlIIlIl7[1] - liiiiiiiiIlIllIIllIlIIlIl4[1]) * 1.0 - (n26 + n25) * n22 + 0.5876288414001465 * 2.5526316857183895, this.IllIlIlIllllIlIIllllIIlll + (liiiiiiiiIlIllIIllIlIIlIl3 * n25 + liiiiiiiiIlIllIIllIlIIlIl8 * n26) * liiiiiiiiIlIllIIllIlIIlIl2, 0.0f, 0.0f);
            }
            if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                this.IlIIIIlIlllIllIlIlIIlIlIl = (this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIlIlIIIlIlIlllIlIlllII.lllIlIIllllIIIIlIllIlIIII) | this.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIlIIIIIIIlllIIIllIlll.lllIlIIllllIIIIlIllIlIIII));
            }
        }
    }
    
    private void refreshResources() {
        if (this.llIIllIIIllllIIIllIIIIIIl != null) {
            if (this.llIIllIIIllllIIIllIIIIIIl.IIllIlIllIlIllIIlIllIlIII) {
                if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIlIlIIIlIlIlllIlIlllII, lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI((lIlIlIlllIlllIlIIlIllllll)null), 10);
                }
                this.llIIllIIIllllIIIllIIIIIIl = null;
            }
            else if (this.IIIlIllIlllIlIllIllllllll % 10 == 0 && this.getHealth() < this.IlllIIllllllllIlIlIlllllI()) {
                this.IlllIllIlIIIIlIIlIIllIIIl(this.getHealth() + 1.0f);
            }
        }
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(10) == 0) {
            final float n = 32;
            final List liiiIlIIllIIlIIlIIIlIIllI = this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(IIllIllIlllllIIlIIlIIlIIl.class, this.lllIlIIllllIIIIlIllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl(n, n, n));
            IIllIllIlllllIIlIIlIIlIIl llIIllIIIllllIIIllIIIIIIl = null;
            double n2 = 1.807692289352417 * 9.94468552779144E307;
            for (final IIllIllIlllllIIlIIlIIlIIl illIllIlllllIIlIIlIIlIIl : liiiIlIIllIIlIIlIIIlIIllI) {
                final double iiiIllIIllIIIIllIllIIIlIl = illIllIlllllIIlIIlIIlIIl.IIIIllIIllIIIIllIllIIIlIl(this);
                if (iiiIllIIllIIIIllIllIIIlIl < n2) {
                    n2 = iiiIllIIllIIIIllIllIIIlIl;
                    llIIllIIIllllIIIllIIIIIIl = illIllIlllllIIlIIlIIlIIl;
                }
            }
            this.llIIllIIIllllIIIllIIIIIIl = llIIllIIIllllIIIllIIIIIIl;
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final List list) {
        final double n = (this.llIlIlIIIIIIIlllIIIllIlll.lllIlIIllllIIIIlIllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI + this.llIlIlIIIIIIIlllIIIllIlll.lllIlIIllllIIIIlIllIlIIII.IIIIllIlIIIllIlllIlllllIl) / 2;
        final double n2 = (this.llIlIlIIIIIIIlllIIIllIlll.lllIlIIllllIIIIlIllIlIIII.IlllIIIlIlllIllIlIIlllIlI + this.llIlIlIIIIIIIlllIIIllIlll.lllIlIIllllIIIIlIllIlIIII.IlIlIIIlllIIIlIlllIlIllIl) / 2;
        for (final Entity entity : list) {
            if (entity instanceof EntityLivingBase) {
                final double n3 = entity.IIIlIIlIlIIIlllIIlIllllll - n;
                final double n4 = entity.IllIlIlIllllIlIIllllIIlll - n2;
                final double n5 = n3 * n3 + n4 * n4;
                entity.IllIIIIIIIlIlIllllIIllIII(n3 / n5 * 4, 1.350000023841858 * 0.14814814773933715, n4 / n5 * 4);
            }
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final List list) {
        for (int i = 0; i < list.size(); ++i) {
            final Entity entity = list.get(i);
            if (entity instanceof EntityLivingBase) {
                entity.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll.lIIIIlIIllIIlIIlIIIlIIllI(this), 10);
            }
        }
    }
    
    private void IlIlIIIlllIIIlIlllIlIllIl() {
        this.IlllIlIlllIlIlllIIlllIlIl = false;
        if (this.IlIlllIIIIlIllIlllIlIIIll.nextInt(2) == 0 && !this.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl.isEmpty()) {
            this.IIIIIlllIllIIIIllIllIIIII = this.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl.get(this.IlIlllIIIIlIllIlllIlIIIll.nextInt(this.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl.size()));
        }
        else {
            double n;
            double n2;
            double n3;
            do {
                this.lIIIIlIIllIIlIIlIIIlIIllI = 0.0;
                this.lIIIIIIIIIlIllIIllIlIIlIl = 70 + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 50;
                this.IlllIIIlIlllIllIlIIlllIlI = 0.0;
                this.lIIIIlIIllIIlIIlIIIlIIllI += this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 120 - 60;
                this.IlllIIIlIlllIllIlIIlllIlI += this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 120 - 60;
                n = this.IIIlIIlIlIIIlllIIlIllllll - this.lIIIIlIIllIIlIIlIIIlIIllI;
                n2 = this.IllIlIIIIlllIIllIIlllIIlI - this.lIIIIIIIIIlIllIIllIlIIlIl;
                n3 = this.IllIlIlIllllIlIIllllIIlll - this.IlllIIIlIlllIllIlIIlllIlI;
            } while (n * n + n2 * n2 + n3 * n3 <= 100);
            this.IIIIIlllIllIIIIllIllIIIII = null;
        }
    }
    
    private float lIIIIIIIIIlIllIIllIlIIlIl(final double n) {
        return (float)MathHelper.IIIllIllIlIlllllllIlIlIII(n);
    }
    
    private boolean lIIIIlIIllIIlIIlIIIlIIllI(final IlIllIIlIlIllIlIllllllllI ilIllIIlIlIllIlIllllllllI) {
        final int illlIIIlIlllIllIlIIlllIlI = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI);
        final int illlIIIlIlllIllIlIIlllIlI2 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI3 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI);
        final int illlIIIlIlllIllIlIIlllIlI4 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl);
        final int illlIIIlIlllIllIlIIlllIlI5 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl);
        final int illlIIIlIlllIllIlIIlllIlI6 = MathHelper.IlllIIIlIlllIllIlIIlllIlI(ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl);
        boolean b = false;
        boolean b2 = false;
        for (int i = illlIIIlIlllIllIlIIlllIlI; i <= illlIIIlIlllIllIlIIlllIlI4; ++i) {
            for (int j = illlIIIlIlllIllIlIIlllIlI2; j <= illlIIIlIlllIllIlIIlllIlI5; ++j) {
                for (int k = illlIIIlIlllIllIlIIlllIlI3; k <= illlIIIlIlllIllIlIIlllIlI6; ++k) {
                    final IIlllllllIlllIIllllIIlIll block = this.lIIlllIIlIlllllllllIIIIIl.getBlock(i, j, k);
                    if (block.IlIlIIIlllIIIlIlllIlIllIl() != Material.air) {
                        if (block != IllllllIllIIlllIllIIlIIll.IllllllIllllIIlllIllllllI && block != IllllllIllIIlllIllIIlIIll.llllIIIllllllIlllIIlIIlll && block != IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII && this.lIIlllIIlIlllllllllIIIIIl.IIIlIIlIlIIIlllIIlIllllll().lIIIIIIIIIlIllIIllIlIIlIl("mobGriefing")) {
                            b2 = (this.lIIlllIIlIlllllllllIIIIIl.IlIlIIIlllIIIlIlllIlIllIl(i, j, k) || b2);
                        }
                        else {
                            b = true;
                        }
                    }
                }
            }
        }
        if (b2) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("largeexplode", ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI + (ilIllIIlIlIllIlIllllllllI.IIIIllIlIIIllIlllIlllllIl - ilIllIIlIlIllIlIllllllllI.lIIIIlIIllIIlIIlIIIlIIllI) * this.IlIlllIIIIlIllIlllIlIIIll.nextFloat(), ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl + (ilIllIIlIlIllIlIllllllllI.IIIIllIIllIIIIllIllIIIlIl - ilIllIIlIlIllIlIllllllllI.lIIIIIIIIIlIllIIllIlIIlIl) * this.IlIlllIIIIlIllIlllIlIIIll.nextFloat(), ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI + (ilIllIIlIlIllIlIllllllllI.IlIlIIIlllIIIlIlllIlIllIl - ilIllIIlIlIllIlIllllllllI.IlllIIIlIlllIllIlIIlllIlI) * this.IlIlllIIIIlIllIlllIlIIIll.nextFloat(), 0.0, 0.0, 0.0);
        }
        return b;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final llIlllIlllllIlIIIlIIlIIII llIlllIlllllIlIIIlIIlIIII, final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, float n) {
        if (llIlllIlllllIlIIIlIIlIIII != this.lIIIlIlIIIlIlIlllIlIlllII) {
            n = n / 4 + 1.0f;
        }
        final float n2 = this.IllllIllllIlIIIlIIIllllll * (1.5503964f * 2.0263157f) / 180;
        final float liiiIlIIllIIlIIlIIIlIIllI = MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(n2);
        final float liiiiiiiiIlIllIIllIlIIlIl = MathHelper.lIIIIIIIIIlIllIIllIlIIlIl(n2);
        this.lIIIIlIIllIIlIIlIIIlIIllI = this.IIIlIIlIlIIIlllIIlIllllll + liiiIlIIllIIlIIlIIIlIIllI * 5 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 1.2727273f * 0.39285716f) * 2.0f;
        this.lIIIIIIIIIlIllIIllIlIIlIl = this.IllIlIIIIlllIIllIIlllIIlI + this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() * 3 + 1.0;
        this.IlllIIIlIlllIllIlIIlllIlI = this.IllIlIlIllllIlIIllllIIlll - liiiiiiiiIlIllIIllIlIIlIl * 5 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 12.0f * 0.041666668f) * 2.0f;
        this.IIIIIlllIllIIIIllIllIIIII = null;
        if (lllIIIIIIIllIlllllIIlllll.IlllIllIlIIIIlIIlIIllIIIl() instanceof lIllIIIIlIIlIllIIIlIlIlll || lllIIIIIIIllIlllllIIlllll.IlllIIIlIlllIllIlIIlllIlI()) {
            this.IIIIllIIllIIIIllIllIIIlIl(lllIIIIIIIllIlllllIIlllll, n);
        }
        return true;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        return false;
    }
    
    protected boolean IIIIllIIllIIIIllIllIIIlIl(final lllIIIIIIIllIlllllIIlllll lllIIIIIIIllIlllllIIlllll, final float n) {
        return super.lIIIIlIIllIIlIIlIIIlIIllI(lllIIIIIIIllIlllllIIlllll, n);
    }
    
    @Override
    protected void IlIIlIllIllllIIlIllllIlII() {
        ++this.lIIlIlIllllllIllllIIllllI;
        if (this.lIIlIlIllllllIllllIIllllI >= 180 && this.lIIlIlIllllllIllllIIllllI <= 200) {
            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("hugeexplosion", this.IIIlIIlIlIIIlllIIlIllllll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 1.2571429f * 0.39772725f) * 8, this.IllIlIIIIlllIIllIIlllIIlI + 2 + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.046666667f * 10.714286f) * 4, this.IllIlIlIllllIlIIllllIIlll + (this.IlIlllIIIIlIllIlllIlIIIll.nextFloat() - 0.37857142f * 1.3207548f) * 8, 0.0, 0.0, 0.0);
        }
        if (!this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            if (this.lIIlIlIllllllIllllIIllllI > 150 && this.lIIlIlIllllllIllllIIllllI % 5 == 0) {
                int i = 1000;
                while (i > 0) {
                    final int liiiIlIIllIIlIIlIIIlIIllI = IIIIlllIIIlllllIIlllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(i);
                    i -= liiiIlIIllIIlIIlIIIlIIllI;
                    this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new IIIIlllIIIlllllIIlllIIIIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, liiiIlIIllIIlIIlIIIlIIllI));
                }
            }
            if (this.lIIlIlIllllllIllllIIllllI == 1) {
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIIIIIIlIllIIllIlIIlIl(1018, (int)this.IIIlIIlIlIIIlllIIlIllllll, (int)this.IllIlIIIIlllIIllIIlllIIlI, (int)this.IllIlIlIllllIlIIllllIIlll, 0);
            }
        }
        this.IIIIllIIllIIIIllIllIIIlIl(0.0, 1.6545454263687134 * 0.06043956236945969, 0.0);
        final float n = this.IllllIllllIlIIIlIIIllllll + 20;
        this.IllllIllllIlIIIlIIIllllll = n;
        this.lIIIlIlIIllIIlllIIIlIIllI = n;
        if (this.lIIlIlIllllllIllllIIllllI == 200 && !this.lIIlllIIlIlllllllllIIIIIl.IllIlIlIllllIlIIllllIIlll) {
            int j = 2000;
            while (j > 0) {
                final int liiiIlIIllIIlIIlIIIlIIllI2 = IIIIlllIIIlllllIIlllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(j);
                j -= liiiIlIIllIIlIIlIIIlIIllI2;
                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(new IIIIlllIIIlllllIIlllIIIIl(this.lIIlllIIlIlllllllllIIIIIl, this.IIIlIIlIlIIIlllIIlIllllll, this.IllIlIIIIlllIIllIIlllIIlI, this.IllIlIlIllllIlIIllllIIlll, liiiIlIIllIIlIIlIIIlIIllI2));
            }
            this.lIIIIIIIIIlIllIIllIlIIlIl(MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IIIlIIlIlIIIlllIIlIllllll), MathHelper.IlllIIIlIlllIllIlIIlllIlI(this.IllIlIlIllllIlIIllllIIlll));
            this.IlIllllIIIlIllllIIIIIllII();
        }
    }
    
    private void lIIIIIIIIIlIllIIllIlIIlIl(final int n, final int n2) {
        final int n3 = 64;
        lIIlIIIIIIllIIlllIIIIlIII.lIIIIlllIIlIlllllIlIllIII = true;
        final int n4 = 4;
        for (int i = n3 - 1; i <= n3 + 32; ++i) {
            for (int j = n - n4; j <= n + n4; ++j) {
                for (int k = n2 - n4; k <= n2 + n4; ++k) {
                    final double n5 = j - n;
                    final double n6 = k - n2;
                    final double n7 = n5 * n5 + n6 * n6;
                    if (n7 <= (n4 - 0.0736842080950737 * 6.785714509611843) * (n4 - 0.06451612710952759 * 7.750000230968006)) {
                        if (i < n3) {
                            if (n7 <= (n4 - 1 - 1.2051281756589798 * 0.41489362716674805) * (n4 - 1 - 1.1060606241226196 * 0.45205478713847536)) {
                                this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(j, i, k, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
                            }
                        }
                        else if (i > n3) {
                            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(j, i, k, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI);
                        }
                        else if (n7 > (n4 - 1 - 12.833333652052623 * 0.03896103799343109) * (n4 - 1 - 2.159090920790168 * 0.23157894611358643)) {
                            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(j, i, k, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
                        }
                        else {
                            this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(j, i, k, IllllllIllIIlllIllIIlIIll.IlllIIIIlllllIlIlllllIlll);
                        }
                    }
                }
            }
        }
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 0, n2, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 1, n2, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 2, n2, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n - 1, n3 + 2, n2, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n + 1, n3 + 2, n2, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 2, n2 - 1, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 2, n2 + 1, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 3, n2, IllllllIllIIlllIllIIlIIll.IllIIIIIIIlIlIllllIIllIII);
        this.lIIlllIIlIlllllllllIIIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n3 + 4, n2, IllllllIllIIlllIllIIlIIll.lIlllIIIlIlIIlIIIIIIlIlII);
        lIIlIIIIIIllIIlllIIIIlIII.lIIIIlllIIlIlllllIlIllIII = false;
    }
    
    @Override
    public void llIIlllIlIIlIIIIIlIllllll() {
    }
    
    @Override
    public Entity[] IIIIIIIllIllllIIlIIlllIII() {
        return this.llIIIlllllIlllIIllIlIIlII;
    }
    
    @Override
    public boolean IIIIIlIllIllIlIIllIIlIllI() {
        return false;
    }
    
    @Override
    public IIIIIIllIlIIIIlIlllIllllI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIlllIIlIlllllllllIIIIIl;
    }
    
    @Override
    protected String llllIlIlIlllllIllIIllIIIl() {
        return "mob.enderdragon.growl";
    }
    
    @Override
    protected String llIlIlIIIIIIIlllIIIllIlll() {
        return "mob.enderdragon.hit";
    }
    
    @Override
    protected float lIIlIlIllllllIllllIIllllI() {
        return 5;
    }
}
