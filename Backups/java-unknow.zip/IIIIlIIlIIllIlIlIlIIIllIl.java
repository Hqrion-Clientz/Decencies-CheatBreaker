import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIlIIllIlIlIlIIIllIl
{
    public static void lIIIIlIIllIIlIIlIIIlIIllI() {
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lIIlllIlIllIIIIlIIlIlIIll.class, "ViBH");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(IlIllIIllIlIlIIlIlIIIIlll.class, "ViDF");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lllllIIIIllIllIIllIlIllII.class, "ViF");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(IIIIllIIIllIlIlIllIIIIlIl.class, "ViL");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIllIIlIllIIlIllllI.class, "ViPH");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(llIlIIlIlIlIlIIIllIlIllll.class, "ViSH");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(llIIlIlIIlllIlIlIlIlIlIlI.class, "ViSmH");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lIIllIlllIIIlIlllIIIIIlIl.class, "ViST");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(IlIllIllIllIlIIIlIlIlllIl.class, "ViS");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI.class, "ViStart");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(IIlIlIIlIlIIllIlllIIIllIl.class, "ViSR");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIlllIIIllllIIIIIlll.class, "ViTRH");
        IllllIlIlllIllIllllIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIIlIIllIIIIIlIIIlll.class, "ViW");
    }
    
    public static List lIIIIlIIllIIlIIlIIIlIIllI(final Random random, final int n) {
        final ArrayList<IIIIlllIIlIlIIllIlIllIIII> list = new ArrayList<IIIIlllIIlIlIIllIlIllIIII>();
        list.add(new IIIIlllIIlIlIIllIlIllIIII(llIlIIlIlIlIlIIIllIlIllll.class, 4, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 2 + n, 4 + n * 2)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(lIIllIlllIIIlIlllIIIIIlIl.class, 20, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 0 + n, 1 + n)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(lIIlllIlIllIIIIlIIlIlIIll.class, 20, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 0 + n, 2 + n)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(llIIlIlIIlllIlIlIlIlIlIlI.class, 3, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 2 + n, 5 + n * 3)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(lllIlIIIllIIlIllIIlIllllI.class, 15, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 0 + n, 2 + n)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(IlIllIIllIlIlIIlIlIIIIlll.class, 3, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 1 + n, 4 + n)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(lllllIIIIllIllIIllIlIllII.class, 3, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 2 + n, 4 + n * 2)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(IlIllIllIllIlIIIlIlIlllIl.class, 15, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 0, 1 + n)));
        list.add(new IIIIlllIIlIlIIllIlIllIIII(lIIlIIIlllIIIllllIIIIIlll.class, 8, MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(random, 0 + n, 3 + n * 2)));
        final Iterator<IIIIlllIIlIlIIllIlIllIIII> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().IIIIllIlIIIllIlllIlllllIl == 0) {
                iterator.remove();
            }
        }
        return list;
    }
    
    private static int lIIIIlIIllIIlIIlIIIlIIllI(final List list) {
        boolean b = false;
        int n = 0;
        for (final IIIIlllIIlIlIIllIlIllIIII iiiIlllIIlIlIIllIlIllIIII : list) {
            if (iiiIlllIIlIlIIllIlIllIIII.IIIIllIlIIIllIlllIlllllIl > 0 && iiiIlllIIlIlIIllIlIllIIII.IlllIIIlIlllIllIlIIlllIlI < iiiIlllIIlIlIIllIlIllIIII.IIIIllIlIIIllIlllIlllllIl) {
                b = true;
            }
            n += iiiIlllIIlIlIIllIlIllIIII.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        return b ? n : -1;
    }
    
    private static lllllIlIllIlIlIllIIIIIIIl lIIIIlIIllIIlIIlIIIlIIllI(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final IIIIlllIIlIlIIllIlIllIIII iiiIlllIIlIlIIllIlIllIIII, final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final Class liiiIlIIllIIlIIlIIIlIIllI = iiiIlllIIlIlIIllIlIllIIII.lIIIIlIIllIIlIIlIIIlIIllI;
        lllllIlIllIlIlIllIIIIIIIl lllllIlIllIlIlIllIIIIIIIl = null;
        if (liiiIlIIllIIlIIlIIIlIIllI == llIlIIlIlIlIlIIIllIlIllll.class) {
            lllllIlIllIlIlIllIIIIIIIl = llIlIIlIlIlIlIIIllIlIllll.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == lIIllIlllIIIlIlllIIIIIlIl.class) {
            lllllIlIllIlIlIllIIIIIIIl = lIIllIlllIIIlIlllIIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == lIIlllIlIllIIIIlIIlIlIIll.class) {
            lllllIlIllIlIlIllIIIIIIIl = lIIlllIlIllIIIIlIIlIlIIll.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == llIIlIlIIlllIlIlIlIlIlIlI.class) {
            lllllIlIllIlIlIllIIIIIIIl = llIIlIlIIlllIlIlIlIlIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == lllIlIIIllIIlIllIIlIllllI.class) {
            lllllIlIllIlIlIllIIIIIIIl = lllIlIIIllIIlIllIIlIllllI.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == IlIllIIllIlIlIIlIlIIIIlll.class) {
            lllllIlIllIlIlIllIIIIIIIl = IlIllIIllIlIlIIlIlIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == lllllIIIIllIllIIllIlIllII.class) {
            lllllIlIllIlIlIllIIIIIIIl = lllllIIIIllIllIIllIlIllII.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == IlIllIllIllIlIIIlIlIlllIl.class) {
            lllllIlIllIlIlIllIIIIIIIl = IlIllIllIllIlIIIlIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        else if (liiiIlIIllIIlIIlIIIlIIllI == lIIlIIIlllIIIllllIIIIIlll.class) {
            lllllIlIllIlIlIllIIIIIIIl = lIIlIIIlllIIIllllIIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5);
        }
        return lllllIlIllIlIlIllIIIIIIIl;
    }
    
    private static lllllIlIllIlIlIllIIIIIIIl IlllIIIlIlllIllIlIIlllIlI(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        final int liiiIlIIllIIlIIlIIIlIIllI = lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI.IllIIIIIIIlIlIllllIIllIII);
        if (liiiIlIIllIIlIIlIIIlIIllI <= 0) {
            return null;
        }
        int i = 0;
        while (i < 5) {
            ++i;
            int nextInt = random.nextInt(liiiIlIIllIIlIIlIIIlIIllI);
            for (final IIIIlllIIlIlIIllIlIllIIII iiiIllIlIIIllIlllIlllllIl : llIllllIIIIIIIlllIIIIlIlI.IllIIIIIIIlIlIllllIIllIII) {
                nextInt -= iiiIllIlIIIllIlllIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl;
                if (nextInt < 0) {
                    if (!iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n5)) {
                        break;
                    }
                    if (iiiIllIlIIIllIlllIlllllIl == llIllllIIIIIIIlllIIIIlIlI.IIIIllIlIIIllIlllIlllllIl && llIllllIIIIIIIlllIIIIlIlI.IllIIIIIIIlIlIllllIIllIII.size() > 1) {
                        break;
                    }
                    final lllllIlIllIlIlIllIIIIIIIl liiiIlIIllIIlIIlIIIlIIllI2 = lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, iiiIllIlIIIllIlllIlllllIl, list, random, n, n2, n3, n4, n5);
                    if (liiiIlIIllIIlIIlIIIlIIllI2 != null) {
                        final IIIIlllIIlIlIIllIlIllIIII iiiIlllIIlIlIIllIlIllIIII = iiiIllIlIIIllIlllIlllllIl;
                        ++iiiIlllIIlIlIIllIlIllIIII.IlllIIIlIlllIllIlIIlllIlI;
                        llIllllIIIIIIIlllIIIIlIlI.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
                        if (!iiiIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI()) {
                            llIllllIIIIIIIlllIIIIlIlI.IllIIIIIIIlIlIllllIIllIII.remove(iiiIllIlIIIllIlllIlllllIl);
                        }
                        return liiiIlIIllIIlIIlIIIlIIllI2;
                    }
                    continue;
                }
            }
        }
        final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI3 = IIIIllIIIllIlIlIllIIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4);
        if (liiiIlIIllIIlIIlIIIlIIllI3 != null) {
            return new IIIIllIIIllIlIlIllIIIIlIl(llIllllIIIIIIIlllIIIIlIlI, n5, random, liiiIlIIllIIlIIlIIIlIIllI3, n4);
        }
        return null;
    }
    
    private static lllIlIlllIlIIllllllIIIlll IIIIllIlIIIllIlllIlllllIl(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        if (n5 > 50) {
            return null;
        }
        if (Math.abs(n - llIllllIIIIIIIlllIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI) <= 112 && Math.abs(n3 - llIllllIIIIIIIlllIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI) <= 112) {
            final lllllIlIllIlIlIllIIIIIIIl illlIIIlIlllIllIlIIlllIlI = IlllIIIlIlllIllIlIIlllIlI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4, n5 + 1);
            if (illlIIIlIlllIllIlIIlllIlI != null) {
                final int n6 = (illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI + illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl) / 2;
                final int n7 = (illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI + illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl) / 2;
                final int n8 = illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI;
                final int n9 = illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - illlIIIlIlllIllIlIIlllIlI.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI;
                if (llIllllIIIIIIIlllIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(n6, n7, ((n8 > n9) ? n8 : n9) / 2 + 4, lIlllllllIIIIIlIIIlIlIIll.IIIIllIIllIIIIllIllIIIlIl)) {
                    list.add(illlIIIlIlllIllIlIIlllIlI);
                    llIllllIIIIIIIlllIIIIlIlI.lIIIIllIIlIlIllIIIlIllIlI.add(illlIIIlIlllIllIlIIlllIlI);
                    return illlIIIlIlllIllIlIIlllIlI;
                }
            }
            return null;
        }
        return null;
    }
    
    private static lllIlIlllIlIIllllllIIIlll IIIIllIIllIIIIllIllIIIlIl(final llIllllIIIIIIIlllIIIIlIlI llIllllIIIIIIIlllIIIIlIlI, final List list, final Random random, final int n, final int n2, final int n3, final int n4, final int n5) {
        if (n5 > 3 + llIllllIIIIIIIlllIIIIlIlI.IlllIIIlIlllIllIlIIlllIlI) {
            return null;
        }
        if (Math.abs(n - llIllllIIIIIIIlllIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl().lIIIIlIIllIIlIIlIIIlIIllI) <= 112 && Math.abs(n3 - llIllllIIIIIIIlllIIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl().IlllIIIlIlllIllIlIIlllIlI) <= 112) {
            final IIIllllIIllllIIIIIlllllIl liiiIlIIllIIlIIlIIIlIIllI = IIlIlIIlIlIIllIlllIIIllIl.lIIIIlIIllIIlIIlIIIlIIllI(llIllllIIIIIIIlllIIIIlIlI, list, random, n, n2, n3, n4);
            if (liiiIlIIllIIlIIlIIIlIIllI != null && liiiIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl > 10) {
                final IIlIlIIlIlIIllIlllIIIllIl ilIlIIlIlIIllIlllIIIllIl = new IIlIlIIlIlIIllIlllIIIllIl(llIllllIIIIIIIlllIIIIlIlI, n5, random, liiiIlIIllIIlIIlIIIlIIllI, n4);
                final int n6 = (ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI + ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl) / 2;
                final int n7 = (ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI + ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl) / 2;
                final int n8 = ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI;
                final int n9 = ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - ilIlIIlIlIIllIlllIIIllIl.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI;
                if (llIllllIIIIIIIlllIIIIlIlI.IIIIllIIllIIIIllIllIIIlIl().lIIIIlIIllIIlIIlIIIlIIllI(n6, n7, ((n8 > n9) ? n8 : n9) / 2 + 4, lIlllllllIIIIIlIIIlIlIIll.IIIIllIIllIIIIllIllIIIlIl)) {
                    list.add(ilIlIIlIlIIllIlllIIIllIl);
                    llIllllIIIIIIIlllIIIIlIlI.IlllIllIlIIIIlIIlIIllIIIl.add(ilIlIIlIlIIllIlllIIIllIl);
                    return ilIlIIlIlIIllIlllIIIllIl;
                }
            }
            return null;
        }
        return null;
    }
}
