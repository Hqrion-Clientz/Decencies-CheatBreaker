import java.util.Iterator;
import java.util.ArrayList;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIlIllIlllIIlIIIIlIIIlIl extends IIIIIlIlIllIlllIIIIIlIIll
{
    final /* synthetic */ IlIIIlllIIIlIlIlllIIlllII lllIIIIIlIllIlIIIllllllII;
    
    public IIIlIllIlllIIlIIIIlIIIlIl(final IlIIIlllIIIlIlIlllIIlllII lllIIIIIlIllIlIIIllllllII) {
        this.lllIIIIIlIllIlIIIllllllII = lllIIIIIlIllIlIIIllllllII;
        super(lllIIIIIlIllIlIIIllllllII);
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        for (final llIIllllIlllIlllIllIIllll llIIllllIlllIlllIllIIllll : lIIlIIIllIlIIllIIllIllIIl.IIIIllIIllIIIIllIllIIIlIl) {
            boolean b = false;
            final int liiiIlIIllIIlIIlIIIlIIllI = lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(llIIllllIlllIlllIllIIllll.lIIIIlIIllIIlIIlIIIlIIllI());
            if (lllIIIIIlIllIlIIIllllllII.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(llIIllllIlllIlllIllIIllll) > 0) {
                b = true;
            }
            else if (lIIlIIIllIlIIllIIllIllIIl.lIlIlIllIIIIIIIIllllIIllI[liiiIlIIllIIlIIlIIIlIIllI] != null && lllIIIIIlIllIlIIIllllllII.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.lIlIlIllIIIIIIIIllllIIllI[liiiIlIIllIIlIIlIIIlIIllI]) > 0) {
                b = true;
            }
            else if (lIIlIIIllIlIIllIIllIllIIl.IllIIlIIlllllIllIIIlllIII[liiiIlIIllIIlIIlIIIlIIllI] != null && lllIIIIIlIllIlIIIllllllII.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.IllIIlIIlllllIllIIIlllIII[liiiIlIIllIIlIIlIIIlIIllI]) > 0) {
                b = true;
            }
            if (b) {
                this.lIIIIIIIIIlIllIIllIlIIlIl.add(llIIllllIlllIlllIllIIllll);
            }
        }
        this.lIIlIlIllIIlIIIlIIIlllIII = new IIIlllIlllIIlllIIIIllIlII(this, lllIIIIIlIllIlIIIllllllII);
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final Tessellator tessellator) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, tessellator);
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 0) {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 115 - 18 + 1, n2 + 1 + 1, 18, 18);
        }
        else {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 115 - 18, n2 + 1, 18, 18);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 1) {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 165 - 18 + 1, n2 + 1 + 1, 36, 18);
        }
        else {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 165 - 18, n2 + 1, 36, 18);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == 2) {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 215 - 18 + 1, n2 + 1 + 1, 54, 18);
        }
        else {
            this.lllIIIIIlIllIlIIIllllllII.IlllIIIlIlllIllIlIIlllIlI(n + 215 - 18, n2 + 1, 54, 18);
        }
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4, final Tessellator tessellator, final int n5, final int n6) {
        final llIIllllIlllIlllIllIIllll liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(n);
        final lIIlllIIIlIllllllIlIlIIII liiiIlIIllIIlIIlIIIlIIllI = liiiiiiiiIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
        this.lllIIIIIlIllIlIIIllllllII.lIIIIlIIllIIlIIlIIIlIIllI(n2 + 40, n3, liiiIlIIllIIlIIlIIIlIIllI);
        final int liiiIlIIllIIlIIlIIIlIIllI2 = lIIlllIIIlIllllllIlIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.IllIIlIIlllllIllIIIlllIII[liiiIlIIllIIlIIlIIIlIIllI2], n2 + 115, n3, n % 2 == 0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(lIIlIIIllIlIIllIIllIllIIl.lIlIlIllIIIIIIIIllllIIllI[liiiIlIIllIIlIIlIIIlIIllI2], n2 + 165, n3, n % 2 == 0);
        this.lIIIIlIIllIIlIIlIIIlIIllI(liiiiiiiiIlIllIIllIlIIlIl, n2 + 215, n3, n % 2 == 0);
    }
    
    @Override
    protected String IlllIIIlIlllIllIlIIlllIlI(final int n) {
        return (n == 0) ? "stat.crafted" : ((n == 1) ? "stat.used" : "stat.mined");
    }
}
