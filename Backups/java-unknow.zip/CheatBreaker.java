import java.util.UUID;
import java.util.Iterator;
import java.nio.file.Files;
import java.nio.file.CopyOption;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;
import java.net.URI;
import java.time.OffsetDateTime;
import com.cheatbreaker.client.network.messages.Message;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

// 
// Decompiled by Procyon v0.5.36
// 

public class CheatBreaker
{
    private List<ResourceLocation> IIIIIIlIlIlIllllllIlllIlI;
    public List<Session> lIIIIlIIllIIlIIlIIIlIIllI;
    public List<CBCustomProfile> lIIIIIIIIIlIllIIllIlIIlIl;
    public List<CBMojangServiceEntry> IlllIIIlIlllIllIlIIlllIlI;
    public CBCustomProfile IIIIllIlIIIllIlllIlllllIl;
    private static CheatBreaker instance;
    private CBStaffModules IlIIlIIIIlIIIIllllIIlIllI;
    private IIIIllIlIlIIIlIlIIllllllI lIIlIIllIIIIIlIllIIIIllII;
    private IIlIIllIlllIllllIlIllllII lIIlllIIlIlllllllllIIIIIl;
    public lllIlIllIlIlllllllIIIIllI IIIIllIIllIIIIllIllIIIlIl;
    private CBEventBus eventBus;
    private static String llIlIIIllIIIIlllIlIIIIIlI;
    private static String lIllIlIlllIIlIIllIIlIIlII;
    private static String IIIlIIlIlIIIlllIIlIllllll;
    private boolean IllIlIIIIlllIIllIIlllIIlI;
    private boolean IllIlIlIllllIlIIllllIIlll;
    private List<String> IllIIlIIlllllIllIIIlllIII;
    private lIIlllIIlllIlIllIIlIIIIll lIlIlIllIIIIIIIIllllIIllI;
    private List<IlIlIIIlllIIIlIlllIlIllIl> IlllIIlllIIIIllIIllllIlIl;
    private List<IlIlIIIlllIIIlIlllIlIllIl> IllllIllllIlIIIlIIIllllll;
    private final IllIIlIIIllllIIIIllIlIlIl IllIIlllIllIlIllIlIIIIIII;
    private final IllIIIIIIIlIlIllllIIllIII IlIlIIIlllllIIIlIlIlIllII;
    private final long IIlIIllIIIllllIIlllIllIIl;
    private final IIIIIlIIIlllIIlIIllllIlll lllIlIIllllIIIIlIllIlIIII;
    private final IlIIIIlIlIllIIlIIIIllllll lIIIIlllIIlIlllllIlIllIII;
    private static List<IIIIllIIllIIIIllIllIIIlIl> lIIIlllIlIlllIIIIIIIIIlII;
    public static long IlIlIIIlllIIIlIlllIlIllIl;
    private lIlIlIllIllIlIllIIlllIIIl IIIIlIIIlllllllllIlllIlll;
    private String IlIllllIIIlIllllIIIIIllII;
    private CBStatusEnum IlIIIIllIIIIIlllIIlIIlllI;
    public lIlIllIlIlIIIllllIlIllIll IIIllIllIlIlllllllIlIlIII;
    public lIlIllIlIlIIIllllIlIllIll IllIIIIIIIlIlIllllIIllIII;
    public lIlIllIlIlIIIllllIlIllIll lIIIIllIIlIlIllIIIlIllIlI;
    public lIlIllIlIlIIIllllIlIllIll IlllIllIlIIIIlIIlIIllIIIl;
    public lIlIllIlIlIIIllllIlIllIll IlIlllIIIIllIllllIllIIlIl;
    public lIlIllIlIlIIIllllIlIllIll llIIlllIIIIlllIllIlIlllIl;
    public lIlIllIlIlIIIllllIlIllIll lIIlIlIllIIlIIIlIIIlllIII;
    public lIlIllIlIlIIIllllIlIllIll IIIlllIIIllIllIlIIIIIIlII;
    public lIlIllIlIlIIIllllIlIllIll llIlIIIlIIIIlIlllIlIIIIll;
    public lIlIllIlIlIIIllllIlIllIll IIIlIIllllIIllllllIlIIIll;
    public lIlIllIlIlIIIllllIlIllIll lllIIIIIlIllIlIIIllllllII;
    private static final ResourceLocation llIlIlIllIlIIlIlllIllIIlI;
    private static final ResourceLocation llIlIlIlllIlllllIIIllIIll;
    private static final ResourceLocation IIllIlIllIlIllIIlIllIlIII;
    private final ResourceLocation lIlIllIlIlIIIllllIlIllIll;
    private static final ResourceLocation IlIIlIIlIllIIIIllIIllIlIl;
    private final Map llllIIIIlIlIllIIIllllIIll;
    public static byte[] lIIIIIllllIIIIlIlIIIIlIlI;
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "CB-Client";
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return "CB-Binary";
    }
    
    public CheatBreaker() {
        this.IIIIIIlIlIlIllllllIlllIlI = new ArrayList();
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList();
        this.lIIIIIIIIIlIllIIllIlIIlIl = new ArrayList();
        this.IlllIIIlIlllIllIlIIlllIlI = new ArrayList();
        this.IllIlIlIllllIlIIllllIIlll = true;
        this.IllIIlIIlllllIllIIIlllIII = new ArrayList();
        this.IlIIIIllIIIIIlllIIlIIlllI = CBStatusEnum.lIIIIlIIllIIlIIlIIIlIIllI;
        this.lIlIllIlIlIIIllllIlIllIll = new ResourceLocation("client/font/Play-Regular.ttf");
        this.llllIIIIlIlIllIIIllllIIll = new HashMap();
        this.IIlIIllIIIllllIIlllIllIIl = System.currentTimeMillis();
        System.out.println("[CB] Starting CheatBreaker setup");
        this.lllIlIIllllIIIIlIllIlIIII();
        System.out.println("[CB] Created default configuration presets");
        CheatBreaker.instance = this;
        this.lIIlIIllIIIIIlIllIIIIllII = new IIIIllIlIlIIIlIlIIllllllI();
        System.out.println("[CB] Created settings");
        this.eventBus = new CBEventBus();
        System.out.println("[CB] Created EventBus");
        this.IlIIlIIIIlIIIIllllIIlIllI = new CBStaffModules(this.eventBus);
        System.out.println("[CB] Created Mod Manager");
        this.lIIlllIIlIlllllllllIIIIIl = new IIlIIllIlllIllllIlIllllII();
        System.out.println("[CB] Created Network Manager");
        this.IlIlIIIlllllIIIlIlIlIllII = new IllIIIIIIIlIlIllllIIllIII();
        System.out.println("[CB] Created Dash Manager");
        this.IllIIlllIllIlIllIlIIIIIII = new IllIIlIIIllllIIIIllIlIlIl();
        this.lllIlIIllllIIIIlIllIlIIII = new IIIIIlIIIlllIIlIIllllIlll();
        this.lIIIIlllIIlIlllllIlIllIII = new IlIIIIlIlIllIIlIIIIllllll();
        System.out.println("[CB] Created Friend Manager");
        this.eventBus.addEvent(CBDisconnectEvent.class, this.lIIlllIIlIlllllllllIIIIIl::lIIIIlIIllIIlIIlIIIlIIllI);
        this.eventBus.addEvent(lllIIIIIlIllIlIIIllllllII.class, this.lIIlllIIlIlllllllllIIIIIl::lIIIIlIIllIIlIIlIIIlIIllI);
        this.eventBus.addEvent(lIIlIIllIIIIIlIllIIIIllII.class, this.lIIlllIIlIlllllllllIIIIIl::lIIIIlIIllIIlIIlIIIlIIllI);
        this.eventBus.addEvent(lIllIllIlIIllIllIlIlIIlIl.class, this.lllIlIIllllIIIIlIllIlIIII::lIIIIlIIllIIlIIlIIIlIIllI);
        this.eventBus.addEvent(CBTickEvent.class, this.lllIlIIllllIIIIlIllIlIIII::lIIIIlIIllIIlIIlIIIlIIllI);
        System.out.println("[CB] Registered network events");
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI() {
        this.reloadFonts();
        System.out.println("[CB] Loaded all fonts");
        this.loadProfiles();
        System.out.println("[CB] Loaded " + this.lIIIIIIIIIlIllIIllIlIIlIl.size() + " custom profiles");
        this.IlIlIIIlllllIIIlIlIlIllII();
        System.out.println("[CB] Loaded client properties");
        this.IIlIIllIIIllllIIlllIllIIl();
        System.out.println("[CB] Loaded mojang session status entries");
        (this.IIIIllIIllIIIIllIllIIIlIl = new lllIlIllIlIlllllllIIIIllI()).lIIIIIIIIIlIllIIllIlIIlIl();
        System.out.println("[CB] Loaded configuration");
        System.out.println("[CB] Loaded Overlay Gui");
        IlllllIllIIIllIIIllIllIII.lIIIIlIIllIIlIIlIIIlIIllI(new IlllllIllIIIllIIIllIllIII());
        try {
            System.out.println("[CB] Connecting to player assets server");
            this.IllIIIIIIIlIlIllllIIllIII();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(new lllIIlIlIllIIlIllIIIIIlII(), 0L, this.lIIlIIllIIIIIlIllIIIIllII.lIIlIlIllIIlIIIlIIIlllIII, TimeUnit.SECONDS);
        System.out.println("[CB] Scheduled session server status updates");
        this.IlllIIlllIIIIllIIllllIlIl = new ArrayList();
        this.IllllIllllIlIIIlIIIllllll = new ArrayList();
        this.IIIIllIIllIIIIllIllIIIlIl().IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
        System.out.println("[CB] Finished startup in " + (System.currentTimeMillis() - this.IIlIIllIIIllllIIlllIllIIl) + "ms!");
        new Thread(() -> {
            try {
                while (true) {
                    try {
                        Message.k();
                    }
                    catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
                    Thread.sleep(10L);
                }
            }
            catch (Exception ex2) {
                ex2.printStackTrace();
                return;
            }
        }).start();
        new Thread(() -> {
            try {
                while (true) {
                    try {
                        Message.a = Message.i();
                        if (this.lIlIlIllIIIIIIIIllllIIllI != null) {
                            this.lIlIlIllIIIIIIIIllllIIllI.lIIIIlIIllIIlIIlIIIlIIllI(new lIIllIlllIIlllIllIIlllllI());
                        }
                    }
                    catch (Exception ex3) {
                        ex3.printStackTrace();
                    }
                    Thread.sleep(30000L);
                }
            }
            catch (InterruptedException ex4) {
                ex4.printStackTrace();
            }
        }).start();
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        if (this.IlIllllIIIlIllllIIIIIllII.toLowerCase().endsWith("minehq.com")) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIlIIIlllllllllIlllIlll, s, this.IlIllllIIIlIllllIIIIIllII, "cb_minehq", "MineHQ");
        }
        else {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIlIIIlllllllllIlllIlll, s, this.IlIllllIIIlIllllIIIIIllII, "cb_small", "CheatBreaker");
        }
    }
    
    private void IllIIlllIllIlIllIlIIIIIII() {
        try {
            (this.IIIIlIIIlllllllllIlllIlll = new lIlIlIllIllIlIllIIlllIIIl(453362295876354080L)).lIIIIlIIllIIlIIlIIIlIIllI(new lIIIIIIIIIlIllIIllIlIIlIl(this));
            this.IIIIlIIIlllllllllIlllIlll.lIIIIlIIllIIlIIlIIIlIIllI(new IllIlIIIlIIIIllIIIlIlIllI[0]);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private void lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIllIllIlIllIIlllIIIl lIlIlIllIllIlIllIIlllIIIl, final String s, final String s2, final String s3, final String str) {
        try {
            if (lIlIlIllIllIlIllIIlllIIIl != null) {
                final String s4 = (s2 != null && !s2.equals("")) ? ("Playing " + str) : "In Menus";
                final IlIIIIllIllllIIlIIIIIIllI ilIIIIllIllllIIlIIIIIIllI = new IlIIIIllIllllIIlIIIIIIllI();
                ilIIIIllIllllIIlIIIIIIllI.lIIIIlIIllIIlIIlIIIlIIllI(s).lIIIIIIIIIlIllIIllIlIIlIl(s4).lIIIIlIIllIIlIIlIIIlIIllI(OffsetDateTime.now()).lIIIIlIIllIIlIIlIIIlIIllI(s3, str).lIIIIIIIIIlIllIIllIlIIlIl("cb_small", "CheatBreaker");
                lIlIlIllIllIlIllIIlllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(ilIIIIllIllllIIlIIIIIIllI.lIIIIlIIllIIlIIlIIIlIIllI());
            }
        }
        catch (Exception ex) {}
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String ilIllllIIIlIllllIIIIIllII, final String s, final int n) {
        try {
            this.IlIllllIIIlIllllIIIIIllII = ilIllllIIIlIllllIIIIIllII;
            this.lIIIIlIIllIIlIIlIIIlIIllI(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().getUsername());
            if (s.equals("")) {
                Message.b("");
            }
            else {
                Message.b(s + ":" + n);
            }
        }
        catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
        catch (Exception ex) {}
        if (!ilIllllIIIlIllllIIIIIllII.equals(s + ":" + n)) {
            this.lIlIlIllIIIIIIIIllllIIllI.lIIIIIIIIIlIllIIllIlIIlIl(ilIllllIIIlIllllIIIIIllII);
        }
        else {
            this.lIlIlIllIIIIIIIIllllIIllI.lIIIIIIIIIlIllIIllIlIIlIl("server");
        }
    }
    
    public static CheatBreaker getInstance() {
        return CheatBreaker.instance;
    }
    
    public CBStaffModules IIIIllIIllIIIIllIllIIIlIl() {
        return this.IlIIlIIIIlIIIIllllIIlIllI;
    }
    
    public IIIIllIlIlIIIlIlIIllllllI IlIlIIIlllIIIlIlllIlIllIl() {
        return this.lIIlIIllIIIIIlIllIIIIllII;
    }
    
    public String IIIllIllIlIlllllllIlIlIII() {
        String s = null;
        switch (IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI[this.IlIIIIllIIIIIlllIIlIIlllI.ordinal()]) {
            case 1: {
                s = "Away";
                break;
            }
            case 2: {
                s = "Busy";
                break;
            }
            case 3: {
                s = "Hidden";
                break;
            }
            default: {
                s = "Online";
                break;
            }
        }
        return s;
    }
    
    public void IllIIIIIIIlIlIllllIIllIII() {
        final Minecraft minecraft = Minecraft.getMinecraft();
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("username", minecraft.IIIIlIIIlllllllllIlllIlll().getUsername());
        hashMap.put("playerId", minecraft.IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl());
        hashMap.put("version", CheatBreaker.IIIlIIlIlIIIlllIIlIllllll);
        (this.lIlIlIllIIIIIIIIllllIIllI = new lIIlllIIlllIlIllIIlIIIIll(new URI("ws://144.217.77.39:8443"), hashMap)).IllIllIIIlIIlllIIIllIllII();
    }
    
    private void IlIlIIIlllllIIIlIlIlIllII() {
        try {
            final ResourceLocation resourceLocation = new ResourceLocation("client/properties/app.properties");
            final Properties properties = new Properties();
            final InputStream liiiIlIIllIIlIIlIIIlIIllI = Minecraft.getMinecraft().llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation).lIIIIlIIllIIlIIlIIIlIIllI();
            if (liiiIlIIllIIlIIlIIIlIIllI == null) {
                return;
            }
            properties.load(liiiIlIIllIIlIIlIIIlIIllI);
            liiiIlIIllIIlIIlIIIlIIllI.close();
            CheatBreaker.llIlIIIllIIIIlllIlIIIIIlI = properties.getProperty("git.commit.id.abbrev");
            CheatBreaker.IIIlIIlIlIIIlllIIlIllllll = properties.getProperty("git.commit.id");
            CheatBreaker.lIllIlIlllIIlIIllIIlIIlII = properties.getProperty("git.branch");
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void IIlIIllIIIllllIIlllIllIIl() {
        this.IlllIIIlIlllIllIlIIlllIlI.add(new CBMojangServiceEntry("Session", "sessionserver.mojang.com"));
        this.IlllIIIlIlllIllIlIIlllIlI.add(new CBMojangServiceEntry("Login", "authserver.mojang.com"));
    }
    
    private void lllIlIIllllIIIIlIllIlIIII() {
        final File parent = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles");
        if (parent.exists() || parent.mkdirs()) {
            for (final ResourceLocation resourceLocation : this.IIIIIIlIlIlIllllllIlllIlI) {
                final File file = new File(parent, resourceLocation.lIIIIlIIllIIlIIlIIIlIIllI().replaceAll("([a-zA-Z0-9/]+)/", ""));
                if (!file.exists()) {
                    try {
                        final InputStream liiiIlIIllIIlIIlIIIlIIllI = Minecraft.getMinecraft().llIlIlIlllIlllllIIIllIIll().lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation).lIIIIlIIllIIlIIlIIIlIIllI();
                        Files.copy(liiiIlIIllIIlIIlIIIlIIllI, file.toPath(), new CopyOption[0]);
                        liiiIlIIllIIlIIlIIIlIIllI.close();
                    }
                    catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
    
    public IIlIIllIlllIllllIlIllllII lIIIIllIIlIlIllIIIlIllIlI() {
        return this.lIIlllIIlIlllllllllIIIIIl;
    }
    
    public static float IlllIllIlIIIIlIIlIIllIIIl() {
        switch (Minecraft.getMinecraft().gameSettings.IIlIIlIlIlIlllIIlIIlIIlII) {
            case 0: {
                return 2.0f;
            }
            case 1: {
                return 0.2377049f * 2.1034484f;
            }
            case 2: {
                return 1.0f;
            }
            case 3: {
                return 3.3333333f * 0.45000002f;
            }
            default: {
                return 1.0f;
            }
        }
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final String s) {
        this.lIIIIlIIllIIlIIlIIIlIIllI(s, 1.0f);
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, final float n) {
        if (!(boolean)this.lIIlIIllIIIIIlIllIIIIllII.IllIllIIIlIIlllIIIllIllII.IIIIllIlIIIllIlllIlllllIl()) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(s, n);
        }
    }
    
    private void loadProfiles() {
        this.lIIIIIIIIIlIllIIllIlIIlIl.add(new CBCustomProfile("default", true));
        final File file = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles");
        if (file.exists()) {
            for (final File file2 : file.listFiles()) {
                if (file2.getName().endsWith(".cfg")) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl.add(new CBCustomProfile(file2.getName().replace(".cfg", ""), false));
                }
            }
        }
    }
    
    private void reloadFonts() {
        this.IIIllIllIlIlllllllIlIlIII = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.llIlIlIllIlIIlIlllIllIIlI, 22);
        this.IllIIIIIIIlIlIllllIIllIII = new lIlIllIlIlIIIllllIlIllIll(this.lIlIllIlIlIIIllllIlIllIll, 22);
        this.llIIlllIIIIlllIllIlIlllIl = new lIlIllIlIlIIIllllIlIllIll(this.lIlIllIlIlIIIllllIlIllIll, 18);
        this.lIIlIlIllIIlIIIlIIIlllIII = new lIlIllIlIlIIIllllIlIllIll(this.lIlIllIlIlIIIllllIlIllIll, 14);
        this.lllIIIIIlIllIlIIIllllllII = new lIlIllIlIlIIIllllIlIllIll(this.lIlIllIlIlIIIllllIlIllIll, 12);
        this.IIIlllIIIllIllIlIIIIIIlII = new lIlIllIlIlIIIllllIlIllIll(this.lIlIllIlIlIIIllllIlIllIll, 16);
        this.IlllIllIlIIIIlIIlIIllIIIl = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.llIlIlIllIlIIlIlllIllIIlI, 18);
        this.lIIIIllIIlIlIllIIIlIllIlI = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.IlIIlIIlIllIIIIllIIllIlIl, 16);
        this.llIlIIIlIIIIlIlllIlIIIIll = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.llIlIlIlllIlllllIIIllIIll, 13);
        this.IIIlIIllllIIllllllIlIIIll = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.IIllIlIllIlIllIIlIllIlIII, 14);
        this.IlIlllIIIIllIllllIllIIlIl = new lIlIllIlIlIIIllllIlIllIll(CheatBreaker.llIlIlIlllIlllllIIIllIIll, 24);
    }
    
    public static String IlIlllIIIIllIllllIllIIlIl() {
        return CheatBreaker.llIlIIIllIIIIlllIlIIIIIlI;
    }
    
    public static String llIIlllIIIIlllIllIlIlllIl() {
        return CheatBreaker.lIllIlIlllIIlIIllIIlIIlII;
    }
    
    public static String lIIlIlIllIIlIIIlIIIlllIII() {
        return CheatBreaker.IIIlIIlIlIIIlllIIlIllllll;
    }
    
    private String IIIIllIIllIIIIllIllIIIlIl(final String s) {
        final File obj = new File(new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client") + File.separator + "profiles");
        if ((obj.exists() || obj.mkdirs()) && new File(obj + File.separator + s + ".cfg").exists()) {
            return this.IIIIllIIllIIIIllIllIIIlIl(s + "1");
        }
        return s;
    }
    
    public void IIIlllIIIllIllIlIIIIIIlII() {
        if (this.IIIIllIlIIIllIlllIlllllIl == this.lIIIIIIIIIlIllIIllIlIIlIl.get(0)) {
            final CBCustomProfile iiiIllIlIIIllIlllIlllllIl = new CBCustomProfile(this.IIIIllIIllIIIIllIllIIIlIl("Profile 1"), false);
            getInstance().IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
            getInstance().lIIIIIIIIIlIllIIllIlIIlIl.add(iiiIllIlIIIllIlllIlllllIl);
            getInstance().IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            final Minecraft minecraft = Minecraft.getMinecraft();
            if (minecraft.currentScreen instanceof lIIlIlIIlIlIlIIlIlIlllIIl) {
                ((IIlIlIlllIllIIlIllIIlIIlI)((lIIlIlIIlIlIlIIlIlIlllIIl)minecraft.currentScreen).IlIlIIIlllIIIlIlllIlIllIl).lIIIIIIIIIlIllIIllIlIIlIl();
            }
        }
    }
    
    public boolean llIlIIIlIIIIlIlllIlIIIIll() {
        final Iterator<IlIIIIlllIIIlIIllllIIIlll> iterator = this.IIIIllIIllIIIIllIllIIIlIl().lIIIIIIIIIlIllIIllIlIIlIl.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().IIIIllIIllIIIIllIllIIIlIl()) {
                return true;
            }
        }
        return false;
    }
    
    public List IIIlIIllllIIllllllIlIIIll() {
        final ArrayList<IlIlIIIlllIIIlIlllIlIllIl> list = new ArrayList<IlIlIIIlllIIIlIlllIlIllIl>();
        for (final IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl : this.IlllIIlllIIIIllIIllllIlIl) {
            if (ilIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl().equals(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl())) {
                list.add(ilIlIIIlllIIIlIlllIlIllIl);
            }
        }
        for (final IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl2 : this.IllllIllllIlIIIlIIIllllll) {
            if (ilIlIIIlllIIIlIlllIlIllIl2.IIIIllIlIIIllIlllIlllllIl().equals(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl())) {
                list.add(ilIlIIIlllIIIlIlllIlIllIl2);
            }
        }
        return list;
    }
    
    public void IlllIIIlIlllIllIlIIlllIlI(final String s) {
        this.IllllIllllIlIIIlIIIllllll.removeIf(ilIlIIIlllIIIlIlllIlIllIl -> ilIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl().equals(s));
        this.IlllIIlllIIIIllIIllllIlIl.removeIf(ilIlIIIlllIIIlIlllIlIllIl2 -> ilIlIIIlllIIIlIlllIlIllIl2.IIIIllIlIIIllIlllIlllllIl().equals(s));
    }
    
    public List lllIIIIIlIllIlIIIllllllII() {
        return this.IlllIIlllIIIIllIIllllIlIl;
    }
    
    public List lIIIIIllllIIIIlIlIIIIlIlI() {
        return this.IllllIllllIlIIIlIIIllllll;
    }
    
    public IlIlIIIlllIIIlIlllIlIllIl lIIIIlIIllIIlIIlIIIlIIllI(final UUID uuid) {
        for (final IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl : this.IllllIllllIlIIIlIIIllllll) {
            if (ilIlIIIlllIIIlIlllIlIllIl.IlIlIIIlllIIIlIlllIlIllIl() && uuid.toString().equals(ilIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl())) {
                return ilIlIIIlllIIIlIlllIlIllIl;
            }
        }
        return null;
    }
    
    public IlIlIIIlllIIIlIlllIlIllIl lIIIIIIIIIlIllIIllIlIIlIl(final UUID uuid) {
        for (final IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl : this.IlllIIlllIIIIllIIllllIlIl) {
            if (ilIlIIIlllIIIlIlllIlIllIl.IlIlIIIlllIIIlIlllIlIllIl() && uuid.toString().equals(ilIlIIIlllIIIlIlllIlIllIl.IIIIllIlIIIllIlllIlllllIl())) {
                return ilIlIIIlllIIIlIlllIlIllIl;
            }
        }
        return null;
    }
    
    public CBEventBus getEventBus() {
        return this.eventBus;
    }
    
    public ResourceLocation lIIIIlIIllIIlIIlIIIlIIllI(final String str, final String s) {
        final ResourceLocation resourceLocation = this.llllIIIIlIlIllIIIllllIIll.getOrDefault(str, new ResourceLocation("client/heads/" + str + ".png"));
        if (!this.llllIIIIlIlIllIIIllllIIll.containsKey(str)) {
            Minecraft.getMinecraft().renderEngine.lIIIIlIIllIIlIIlIIIlIIllI(resourceLocation, new IIlIlIllIIllllllIIIllIllI(null, "https://minotar.net/avatar/" + str + "/32.png", new ResourceLocation("client/defaults/steve.png"), null));
            this.llllIIIIlIlIllIIIllllIIll.put(str, resourceLocation);
        }
        return resourceLocation;
    }
    
    public static String[] IllIllIIIlIIlllIIIllIllII() {
        final String[] array = new String[CheatBreaker.lIIIlllIlIlllIIIIIIIIIlII.size()];
        int n = 0;
        final Iterator<IIIIllIIllIIIIllIllIIIlIl> iterator = (Iterator<IIIIllIIllIIIIllIllIIIlIl>)CheatBreaker.lIIIlllIlIlllIIIIIIIIIlII.iterator();
        while (iterator.hasNext()) {
            array[n] = iterator.next().lIIIIIIIIIlIllIIllIlIIlIl();
            ++n;
        }
        return array;
    }
    
    public static String IIIIllIlIIIllIlllIlllllIl(final String anObject) {
        for (final IIIIllIIllIIIIllIllIIIlIl iiiIllIIllIIIIllIllIIIlIl : CheatBreaker.lIIIlllIlIlllIIIIIIIIIlII) {
            if (iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl().equals(anObject)) {
                return iiiIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
        }
        return anObject;
    }
    
    public boolean IlIIlIIIIlIIIIllllIIlIllI() {
        return this.IllIlIIIIlllIIllIIlllIIlI;
    }
    
    public boolean lIIlIIllIIIIIlIllIIIIllII() {
        return this.IllIlIlIllllIlIIllllIIlll;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final boolean illIlIIIIlllIIllIIlllIIlI) {
        this.IllIlIIIIlllIIllIIlllIIlI = illIlIIIIlllIIllIIlllIIlI;
    }
    
    public void lIIIIIIIIIlIllIIllIlIIlIl(final boolean illIlIlIllllIlIIllllIIlll) {
        this.IllIlIlIllllIlIIllllIIlll = illIlIlIllllIlIIllllIIlll;
    }
    
    public List<String> lIIlllIIlIlllllllllIIIIIl() {
        return this.IllIIlIIlllllIllIIIlllIII;
    }
    
    public lIIlllIIlllIlIllIIlIIIIll lIllIllIlIIllIllIlIlIIlIl() {
        return this.lIlIlIllIIIIIIIIllllIIllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lIIlllIIlllIlIllIIlIIIIll lIlIlIllIIIIIIIIllllIIllI) {
        this.lIlIlIllIIIIIIIIllllIIllI = lIlIlIllIIIIIIIIllllIIllI;
    }
    
    public IllIIlIIIllllIIIIllIlIlIl llIlIIIllIIIIlllIlIIIIIlI() {
        return this.IllIIlllIllIlIllIlIIIIIII;
    }
    
    public IllIIIIIIIlIlIllllIIllIII lIllIlIlllIIlIIllIIlIIlII() {
        return this.IlIlIIIlllllIIIlIlIlIllII;
    }
    
    public IIIIIlIIIlllIIlIIllllIlll IIIlIIlIlIIIlllIIlIllllll() {
        return this.lllIlIIllllIIIIlIllIlIIII;
    }
    
    public IlIIIIlIlIllIIlIIIIllllll IllIlIIIIlllIIllIIlllIIlI() {
        return this.lIIIIlllIIlIlllllIlIllIII;
    }
    
    public static List IllIlIlIllllIlIIllllIIlll() {
        return CheatBreaker.lIIIlllIlIlllIIIIIIIIIlII;
    }
    
    public CBStatusEnum IllIIlIIlllllIllIIIlllIII() {
        return this.IlIIIIllIIIIIlllIIlIIlllI;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final CBStatusEnum ilIIIIllIIIIIlllIIlIIlllI) {
        this.IlIIIIllIIIIIlllIIlIIlllI = ilIIIIllIIIIIlllIIlIIlllI;
    }
    
    public static ResourceLocation lIlIlIllIIIIIIIIllllIIllI() {
        return CheatBreaker.llIlIlIllIlIIlIlllIllIIlI;
    }
    
    public static ResourceLocation IlllIIlllIIIIllIIllllIlIl() {
        return CheatBreaker.llIlIlIlllIlllllIIIllIIll;
    }
    
    public static ResourceLocation IllllIllllIlIIIlIIIllllll() {
        return CheatBreaker.IlIIlIIlIllIIIIllIIllIlIl;
    }
    
    static {
        CheatBreaker.llIlIIIllIIIIlllIlIIIIIlI = "?";
        CheatBreaker.lIllIlIlllIIlIIllIIlIIlII = "?";
        CheatBreaker.IIIlIIlIlIIIlllIIlIllllll = "?";
        CheatBreaker.lIIIlllIlIlllIIIIIIIIIlII = new ArrayList();
        llIlIlIllIlIIlIlllIllIIlI = new ResourceLocation("client/font/Play-Bold.ttf");
        llIlIlIlllIlllllIIIllIIll = new ResourceLocation("client/font/Roboto-Regular.ttf");
        IIllIlIllIlIllIIlIllIlIII = new ResourceLocation("client/font/Roboto-Bold.ttf");
        IlIIlIIlIllIIIIllIIllIlIl = new ResourceLocation("client/font/Ubuntu-M.ttf");
        CheatBreaker.lIIIIIllllIIIIlIlIIIIlIlI = new byte[] { 86, 79, 84, 69, 32, 84, 82, 85, 77, 80, 32, 50, 48, 50, 48, 33 };
    }
}
