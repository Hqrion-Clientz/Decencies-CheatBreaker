// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIllIIllIIIIIlIIllllIll extends llllIIlIIIIlIIllIIIlllIIl
{
    private llllIIlIIIIlIIllIIIlllIIl IlllIIIlIlllIllIlIIlllIlI;
    private llllIIlIIIIlIIllIIIlllIIl IIIIllIlIIIllIlllIlllllIl;
    
    public IIIIllIIllIIIIIlIIllllIll(final long n, final llllIIlIIIIlIIllIIIlllIIl illlIIIlIlllIllIlIIlllIlI, final llllIIlIIIIlIIllIIIlllIIl iiiIllIlIIIllIlllIlllllIl) {
        super(n);
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final long n) {
        this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n);
        this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n);
        super.lIIIIlIIllIIlIIlIIIlIIllI(n);
    }
    
    @Override
    public int[] lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3, final int n4) {
        final int[] liiiIlIIllIIlIIlIIIlIIllI = this.IlllIIIlIlllIllIlIIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4);
        final int[] liiiIlIIllIIlIIlIIIlIIllI2 = this.IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4);
        final int[] liiiIlIIllIIlIIlIIIlIIllI3 = lIlIllIIIlIlllllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI(n3 * n4);
        for (int i = 0; i < n3 * n4; ++i) {
            if (liiiIlIIllIIlIIlIIIlIIllI[i] != IIlIIlIIllIIllIlIIIIIIIlI.llIlIIIlIIIIlIlllIlIIIIll.IlIllIllIllIllIllllIIIlII && liiiIlIIllIIlIIlIIIlIIllI[i] != IIlIIlIIllIIllIlIIIIIIIlI.lIIIlllIlIlllIIIIIIIIIlII.IlIllIllIllIllIllllIIIlII) {
                if (liiiIlIIllIIlIIlIIIlIIllI2[i] == IIlIIlIIllIIllIlIIIIIIIlI.lIIlIIllIIIIIlIllIIIIllII.IlIllIllIllIllIllllIIIlII) {
                    if (liiiIlIIllIIlIIlIIIlIIllI[i] == IIlIIlIIllIIllIlIIIIIIIlI.IIIlIIlIlIIIlllIIlIllllll.IlIllIllIllIllIllllIIIlII) {
                        liiiIlIIllIIlIIlIIIlIIllI3[i] = IIlIIlIIllIIllIlIIIIIIIlI.lIllIlIlllIIlIIllIIlIIlII.IlIllIllIllIllIllllIIIlII;
                    }
                    else if (liiiIlIIllIIlIIlIIIlIIllI[i] != IIlIIlIIllIIllIlIIIIIIIlI.IllIlIlIllllIlIIllllIIlll.IlIllIllIllIllIllllIIIlII && liiiIlIIllIIlIIlIIIlIIllI[i] != IIlIIlIIllIIllIlIIIIIIIlI.IllIIlIIlllllIllIIIlllIII.IlIllIllIllIllIllllIIIlII) {
                        liiiIlIIllIIlIIlIIIlIIllI3[i] = (liiiIlIIllIIlIIlIIIlIIllI2[i] & 0xFF);
                    }
                    else {
                        liiiIlIIllIIlIIlIIIlIIllI3[i] = IIlIIlIIllIIllIlIIIIIIIlI.IllIIlIIlllllIllIIIlllIII.IlIllIllIllIllIllllIIIlII;
                    }
                }
                else {
                    liiiIlIIllIIlIIlIIIlIIllI3[i] = liiiIlIIllIIlIIlIIIlIIllI[i];
                }
            }
            else {
                liiiIlIIllIIlIIlIIIlIIllI3[i] = liiiIlIIllIIlIIlIIIlIIllI[i];
            }
        }
        return liiiIlIIllIIlIIlIIIlIIllI3;
    }
}
