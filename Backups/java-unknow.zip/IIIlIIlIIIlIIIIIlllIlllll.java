import java.util.Locale;
import java.text.Collator;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIlIIIlIIIIIlllIlllll
{
    public static String lIIIIlIIllIIlIIlIIIlIIllI(final String s) {
        return IllIIIIlIlIllIIllIIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI(s, new Object[0]);
    }
    
    public static Collator lIIIIlIIllIIlIIlIIIlIIllI() {
        String identifier = "en_US";
        try {
            identifier = Minecraft.getMinecraft().lIlIllIlIlIIIllllIlIllIll().IlllIIIlIlllIllIlIIlllIlI().getIdentifier();
        }
        catch (NullPointerException ex) {}
        final String[] split = identifier.split("_");
        return Collator.getInstance(new Locale(split[0], (split.length > 1) ? split[1] : ""));
    }
}
