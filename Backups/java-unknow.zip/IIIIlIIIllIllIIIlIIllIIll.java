import java.util.List;
import java.util.Random;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIIIllIllIIIlIIllIIll extends lllIlIlllIlIIllllllIIIlll
{
    private boolean lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIIIIIlIllIIllIlIIlIl;
    private boolean IlllIIIlIlllIllIlIIlllIlI;
    private int IIIIllIlIIIllIlllIlllllIl;
    
    public IIIIlIIIllIllIIIlIIllIIll() {
    }
    
    @Override
    protected void lIIIIlIIllIIlIIlIIIlIIllI(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("hr", this.lIIIIlIIllIIlIIlIIIlIIllI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("sc", this.lIIIIIIIIIlIllIIllIlIIlIl);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("hps", this.IlllIIIlIlllIllIlIIlllIlI);
        ilIIIllIIlIIlllIllllIIIIl.lIIIIlIIllIIlIIlIIIlIIllI("Num", this.IIIIllIlIIIllIlllIlllllIl);
    }
    
    @Override
    protected void lIIIIIIIIIlIllIIllIlIIlIl(final IlIIIllIIlIIlllIllllIIIIl ilIIIllIIlIIlllIllllIIIIl) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("hr");
        this.lIIIIIIIIIlIllIIllIlIIlIl = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("sc");
        this.IlllIIIlIlllIllIlIIlllIlI = ilIIIllIIlIIlllIllllIIIIl.IIIlllIIIllIllIlIIIIIIlII("hps");
        this.IIIIllIlIIIllIlllIlllllIl = ilIIIllIIlIIlllIllllIIIIl.IlIlIIIlllIIIlIlllIlIllIl("Num");
    }
    
    public IIIIlIIIllIllIIIlIIllIIll(final int n, final Random random, final IIIllllIIllllIIIIIlllllIl iiiIllIIllIIIIllIllIIIlIl, final int ilIlIIIlllIIIlIlllIlIllIl) {
        super(n);
        this.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
        this.IIIIllIIllIIIIllIllIIIlIl = iiiIllIIllIIIIllIllIIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = (random.nextInt(3) == 0);
        this.lIIIIIIIIIlIllIIllIlIIlIl = (!this.lIIIIlIIllIIlIIlIIIlIIllI && random.nextInt(23) == 0);
        if (this.IlIlIIIlllIIIlIlllIlIllIl != 2 && this.IlIlIIIlllIIIlIlllIlIllIl != 0) {
            this.IIIIllIlIIIllIlllIlllllIl = iiiIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl() / 5;
        }
        else {
            this.IIIIllIlIIIllIlllIlllllIl = iiiIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl() / 5;
        }
    }
    
    public static IIIllllIIllllIIIIIlllllIl lIIIIlIIllIIlIIlIIIlIIllI(final List list, final Random random, final int n, final int n2, final int n3, final int n4) {
        final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl = new IIIllllIIllllIIIIIlllllIl(n, n2, n3, n, n2 + 2, n3);
        int i;
        for (i = random.nextInt(3) + 2; i > 0; --i) {
            final int n5 = i * 5;
            switch (n4) {
                case 0: {
                    iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl = n + 2;
                    iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl = n3 + (n5 - 1);
                    break;
                }
                case 1: {
                    iiIllllIIllllIIIIIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI = n - (n5 - 1);
                    iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl = n3 + 2;
                    break;
                }
                case 2: {
                    iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl = n + 2;
                    iiIllllIIllllIIIIIlllllIl.IlllIIIlIlllIllIlIIlllIlI = n3 - (n5 - 1);
                    break;
                }
                case 3: {
                    iiIllllIIllllIIIIIlllllIl.IIIIllIlIIIllIlllIlllllIl = n + (n5 - 1);
                    iiIllllIIllllIIIIIlllllIl.IlIlIIIlllIIIlIlllIlIllIl = n3 + 2;
                    break;
                }
            }
            if (lllIlIlllIlIIllllllIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(list, iiIllllIIllllIIIIIlllllIl) == null) {
                break;
            }
        }
        return (i > 0) ? iiIllllIIllllIIIIIlllllIl : null;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final lllIlIlllIlIIllllllIIIlll lllIlIlllIlIIllllllIIIlll, final List list, final Random random) {
        final int illlIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI();
        final int nextInt = random.nextInt(4);
        switch (this.IlIlIIIlllIIIlIlllIlIllIl) {
            case 0: {
                if (nextInt <= 1) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, this.IlIlIIIlllIIIlIlllIlIllIl, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                if (nextInt == 2) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - 3, 1, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl - 3, 3, illlIIIlIlllIllIlIIlllIlI);
                break;
            }
            case 1: {
                if (nextInt <= 1) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, this.IlIlIIIlllIIIlIlllIlIllIl, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                if (nextInt == 2) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, 2, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, 0, illlIIIlIlllIllIlIIlllIlI);
                break;
            }
            case 2: {
                if (nextInt <= 1) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, this.IlIlIIIlllIIIlIlllIlIllIl, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                if (nextInt == 2) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, 1, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, 3, illlIIIlIlllIllIlIIlllIlI);
                break;
            }
            case 3: {
                if (nextInt <= 1) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI, this.IlIlIIIlllIIIlIlllIlIllIl, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                if (nextInt == 2) {
                    lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - 3, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, 2, illlIIIlIlllIllIlIIlllIlI);
                    break;
                }
                lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl - 3, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl - 1 + random.nextInt(3), this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, 0, illlIIIlIlllIllIlIIlllIlI);
                break;
            }
        }
        if (illlIIIlIlllIllIlIIlllIlI < 8) {
            if (this.IlIlIIIlllIIIlIlllIlIllIl != 2 && this.IlIlIIIlllIIIlIlllIlIllIl != 0) {
                for (int n = this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI + 3; n + 3 <= this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl; n += 5) {
                    final int nextInt2 = random.nextInt(5);
                    if (nextInt2 == 0) {
                        lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, n, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI - 1, 2, illlIIIlIlllIllIlIIlllIlI + 1);
                    }
                    else if (nextInt2 == 1) {
                        lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, n, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl + 1, 0, illlIIIlIlllIllIlIIlllIlI + 1);
                    }
                }
            }
            else {
                for (int n2 = this.IIIIllIIllIIIIllIllIIIlIl.IlllIIIlIlllIllIlIIlllIlI + 3; n2 + 3 <= this.IIIIllIIllIIIIllIllIIIlIl.IlIlIIIlllIIIlIlllIlIllIl; n2 += 5) {
                    final int nextInt3 = random.nextInt(5);
                    if (nextInt3 == 0) {
                        lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI - 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, n2, 1, illlIIIlIlllIllIlIIlllIlI + 1);
                    }
                    else if (nextInt3 == 1) {
                        lIIIIIIIIIlIllIIllIlIIlIl(lllIlIlllIlIIllllllIIIlll, list, random, this.IIIIllIIllIIIIllIllIIIlIl.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl, n2, 3, illlIIIlIlllIllIlIIlllIlI + 1);
                    }
                }
            }
        }
    }
    
    @Override
    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl, final Random random, final int n, final int n2, final int n3, final IIIlllIlllIlIlIIlllIlllll[] array, final int n4) {
        final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(n, n3);
        final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(n2);
        final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(n, n3);
        if (iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl) && iiiiiIllIlIIIIlIlllIllllI.getBlock(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI, liiiIlIIllIIlIIlIIIlIIllI2, liiiiiiiiIlIllIIllIlIIlIl, IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, (int)(random.nextBoolean() ? 1 : 0)), 2);
            final IIllIIllllIIIIIlllllIllIl illIIllllIIIIIlllllIllIl = new IIllIIllllIIIIIlllllIllIl(iiiiiIllIlIIIIlIlllIllllI, liiiIlIIllIIlIIlIIIlIIllI + 0.36309522f * 1.3770492f, liiiIlIIllIIlIIlIIIlIIllI2 + 0.8021978f * 0.6232877f, liiiiiiiiIlIllIIllIlIIlIl + 0.08450705f * 5.9166665f);
            IIIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI(random, array, illIIllllIIIIIlllllIllIl, n4);
            iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(illIIllllIIIIIlllllIllIl);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, final Random random, final IIIllllIIllllIIIIIlllllIl iiIllllIIllllIIIIIlllllIl) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl)) {
            return false;
        }
        final int n = this.IIIIllIlIIIllIlllIlllllIl * 5 - 1;
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, 0, 2, 1, n, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.9489796f * 0.8430107f, 0, 2, 0, 2, 2, n, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        if (this.lIIIIIIIIIlIllIIllIlIIlIl) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 2.6969697f * 0.22247191f, 0, 0, 0, 2, 1, n, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
        }
        for (int i = 0; i < this.IIIIllIlIIIllIlllIlllllIl; ++i) {
            final int n2 = 2 + i * 5;
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 0, n2, 0, 1, n2, IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 0, n2, 2, 1, n2, IllllllIllIIlllIllIIlIIll.IIlllllIIlIlIIlIIlllIIIII, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
            if (random.nextInt(4) == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, n2, 0, 2, n2, IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 2, 2, n2, 2, 2, n2, IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
            }
            else {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, 0, 2, n2, 2, 2, n2, IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl, IllllllIllIIlllIllIIlIIll.lIIIIlIIllIIlIIlIIIlIIllI, false);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 2.5263157f * 0.039583337f, 0, 2, n2 - 1, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 1.2857143f * 0.07777778f, 2, 2, n2 - 1, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.48214287f * 0.2074074f, 0, 2, n2 + 1, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.24324325f * 0.41111112f, 2, 2, n2 + 1, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.8877551f * 0.05632184f, 0, 2, n2 - 2, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.85f * 0.05882353f, 2, 2, n2 - 2, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.21304348f * 0.23469388f, 0, 2, n2 + 2, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 21.75f * 0.0022988506f, 2, 2, n2 + 2, IllllllIllIIlllIllIIlIIll.IllllIllllIlIIIlIIIllllll, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.17884615f * 0.2795699f, 1, 2, n2 - 1, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0);
            this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0.35714287f * 0.14f, 1, 2, n2 + 1, IllllllIllIIlllIllIIlIIll.lIlIlIIIlIIllllllllIIlllI, 0);
            if (random.nextInt(100) == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 2, 0, n2 - 1, IIIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllIlIllllIIlIIIlllll.lIIIIlIIllIIlIIlIIIlIIllI, IIlIlIllIlIIllIllIllIIIll.IlIIIIlIlIllIIlIIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(random)), 3 + random.nextInt(4));
            }
            if (random.nextInt(100) == 0) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 0, 0, n2 + 1, IIIlllIlllIlIlIIlllIlllll.lIIIIlIIllIIlIIlIIIlIIllI(IIlllllIlIllllIIlIIIlllll.lIIIIlIIllIIlIIlIIIlIIllI, IIlIlIllIlIIllIllIllIIIll.IlIIIIlIlIllIIlIIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(random)), 3 + random.nextInt(4));
            }
            if (this.lIIIIIIIIIlIllIIllIlIIlIl && !this.IlllIIIlIlllIllIlIIlllIlI) {
                final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI(0);
                final int n3 = n2 - 1 + random.nextInt(3);
                final int liiiIlIIllIIlIIlIIIlIIllI2 = this.lIIIIlIIllIIlIIlIIIlIIllI(1, n3);
                final int liiiiiiiiIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl(1, n3);
                if (iiIllllIIllllIIIIIlllllIl.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl)) {
                    this.IlllIIIlIlllIllIlIIlllIlI = true;
                    iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl, IllllllIllIIlllIllIIlIIll.llIIIllIIllllIlIlIlIlIIll, 0, 2);
                    final llIIllllllllIllIIIllIIlIl llIIllllllllIllIIIllIIlIl = (llIIllllllllIllIIIllIIlIl)iiiiiIllIlIIIIlIlllIllllI.lIIIIIIIIIlIllIIllIlIIlIl(liiiIlIIllIIlIIlIIIlIIllI2, liiiIlIIllIIlIIlIIIlIIllI, liiiiiiiiIlIllIIllIlIIlIl);
                    if (llIIllllllllIllIIIllIIlIl != null) {
                        llIIllllllllIllIIIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI().lIIIIlIIllIIlIIlIIIlIIllI("CaveSpider");
                    }
                }
            }
        }
        for (int j = 0; j <= 2; ++j) {
            for (int k = 0; k <= n; ++k) {
                if (this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, j, -1, k, iiIllllIIllllIIIIIlllllIl).IlIlIIIlllIIIlIlllIlIllIl() == Material.air) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, IllllllIllIIlllIllIIlIIll.IlIlIIIlllIIIlIlllIlIllIl, 0, j, -1, k, iiIllllIIllllIIIIIlllllIl);
                }
            }
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
            for (int l = 0; l <= n; ++l) {
                final IIlllllllIlllIIllllIIlIll liiiIlIIllIIlIIlIIIlIIllI3 = this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, 1, -1, l, iiIllllIIllllIIIIIlllllIl);
                if (liiiIlIIllIIlIIlIIIlIIllI3.IlIlIIIlllIIIlIlllIlIllIl() != Material.air && liiiIlIIllIIlIIlIIIlIIllI3.lIIIIlIIllIIlIIlIIIlIIllI()) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, iiIllllIIllllIIIIIlllllIl, random, 1.7142857f * 0.40833333f, 1, 0, l, IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, this.lIIIIlIIllIIlIIlIIIlIIllI(IllllllIllIIlllIllIIlIIll.IlIIlllIlIIIlIIIlIlIlIlIl, 0));
                }
            }
        }
        return true;
    }
}
