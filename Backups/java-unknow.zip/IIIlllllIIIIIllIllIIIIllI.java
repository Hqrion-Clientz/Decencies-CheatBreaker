import java.util.Iterator;
import java.net.URLConnection;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import com.google.gson.JsonElement;
import java.util.Map;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.io.BufferedReader;
import java.net.URL;

// 
// Decompiled by Procyon v0.5.36
// 

@Deprecated
public class IIIlllllIIIIIllIllIIIIllI
{
    @Deprecated
    public static void lIIIIlIIllIIlIIlIIIlIIllI(final IIlllIIIIIIlllIllIlIlIlII illlIIIIIIlllIllIlIlIlII, final String str) {
        final URL url;
        final URLConnection urlConnection;
        final BufferedReader bufferedReader2;
        final String str2;
        final Iterator<Map.Entry<String, V>> iterator;
        Map.Entry<String, V> entry;
        final Iterator<JsonElement> iterator2;
        JsonElement jsonElement;
        final String s;
        final float n;
        final boolean b;
        final String s2;
        IlIlIIIlllIIIlIlllIlIllIl ilIlIIIlllIIIlIlllIlIllIl;
        final URL url2;
        boolean b2;
        boolean b3 = false;
        new Thread(() -> {
            if (illlIIIIIIlllIllIlIlIlII.IIlllllIIlIlIIlIIlllIIIII() == null && illlIIIIIIlllIllIlIlIlII.lllIIlIIllIllIIllIIlIIIIl() == null) {
                try {
                    new URL(CheatBreaker.getInstance().IlIlIIIlllIIIlIlllIlIllIl().IlllIllIlIIIIlIIlIIllIIIl + str);
                    url.openConnection();
                    urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
                    urlConnection.connect();
                    new BufferedReader(new InputStreamReader(urlConnection.getInputStream(), Charset.forName("UTF-8")));
                    bufferedReader2.readLine();
                    if (!str2.equalsIgnoreCase("false") && !str2.equalsIgnoreCase("[]")) {
                        new JsonParser().parse("{\"Cosmetic\": " + str2 + "}").getAsJsonObject().entrySet().iterator();
                        while (iterator.hasNext()) {
                            entry = iterator.next();
                            if (entry.getKey().equalsIgnoreCase("Cosmetic")) {
                                ((JsonElement)entry.getValue()).getAsJsonArray().iterator();
                                while (iterator2.hasNext()) {
                                    jsonElement = iterator2.next();
                                    jsonElement.getAsJsonObject().get("name").getAsString();
                                    jsonElement.getAsJsonObject().get("scale").getAsFloat();
                                    jsonElement.getAsJsonObject().get("active").getAsBoolean();
                                    jsonElement.getAsJsonObject().get("resourcelocation").getAsString();
                                    ilIlIIIlllIIIlIlllIlIllIl = new IlIlIIIlllIIIlIlllIlIllIl("", s, n, b, s2);
                                    IIIlllllIIIIIllIllIIIIllI.class.getResource("/assets/minecraft/" + s2);
                                    try {
                                        if (url2 == null) {
                                            b2 = CBAgentResources.existsBytes("/assets/minecraft/" + s2);
                                        }
                                        else {
                                            b2 = Paths.get(url2.toURI()).toFile().exists();
                                        }
                                        if (b2 && b) {
                                            if (s.equalsIgnoreCase("cape")) {
                                                illlIIIIIIlllIllIlIlIlII.lIIIIlIIllIIlIIlIIIlIIllI(ilIlIIIlllIIIlIlllIlIllIl);
                                                illlIIIIIIlllIllIlIlIlII.lIIIIlIIllIIlIIlIIIlIIllI(ilIlIIIlllIIIlIlllIlIllIl.lIIIIIIIIIlIllIIllIlIIlIl());
                                            }
                                            else {
                                                illlIIIIIIlllIllIlIlIlII.lIIIIIIIIIlIllIIllIlIIlIl(ilIlIIIlllIIIlIlllIlIllIl);
                                            }
                                        }
                                        else {
                                            continue;
                                        }
                                    }
                                    catch (URISyntaxException ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                    bufferedReader2.close();
                }
                catch (IOException ex2) {
                    ex2.printStackTrace();
                    b3 = true;
                }
            }
            if (b3) {
                IIIIlIlIlIllIIIlIIIlIIIII.lIIIIlIIllIIlIIlIIIlIIllI(illlIIIIIIlllIllIlIlIlII, illlIIIIIIlllIllIlIlIlII.llllIIllllllIlIIlIlIIIllI().getId());
            }
        }).start();
    }
}
