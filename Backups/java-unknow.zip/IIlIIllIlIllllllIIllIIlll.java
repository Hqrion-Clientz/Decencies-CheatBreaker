// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIIllIlIllllllIIllIIlll extends lIIlllIIIlIllllllIlIlIIII
{
    private IIlllllllIlllIIllllIIlIll lIIIIllIIlIlIllIIIlIllIlI;
    
    public IIlIIllIlIllllllIIllIIlll(final IIlllllllIlllIIllllIIlIll liiiIllIIlIlIllIIIlIllIlI) {
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
    }
    
    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(final lIlIlIlIlIllllIlllIIIlIlI lIlIlIlIlIllllIlllIIIlIlI, final lIllIIIIlIIlIllIIIlIlIlll lIllIIIIlIIlIllIIIlIlIlll, final IIIIIIllIlIIIIlIlllIllllI iiiiiIllIlIIIIlIlllIllllI, int n, int n2, int n3, int n4, final float n5, final float n6, final float n7) {
        final IIlllllllIlllIIllllIIlIll block = iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3);
        if (block == IllllllIllIIlllIllIIlIIll.llllIIlIlIllIllllIIIIllll && (iiiiiIllIlIIIIlIlllIllllI.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3) & 0x7) < 1) {
            n4 = 1;
        }
        else if (block != IllllllIllIIlllIllIIlIIll.llllIIllllllIlIIlIlIIIllI && block != IllllllIllIIlllIllIIlIIll.IllIIlllIllIlIllIlIIIIIII && block != IllllllIllIIlllIllIIlIIll.IlIlIIIlllllIIIlIlIlIllII) {
            if (n4 == 0) {
                --n2;
            }
            if (n4 == 1) {
                ++n2;
            }
            if (n4 == 2) {
                --n3;
            }
            if (n4 == 3) {
                ++n3;
            }
            if (n4 == 4) {
                --n;
            }
            if (n4 == 5) {
                ++n;
            }
        }
        if (!lIllIIIIlIIlIllIIIlIlIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4, lIlIlIlIlIllllIlllIIIlIlI)) {
            return false;
        }
        if (lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl == 0) {
            return false;
        }
        if (iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, n, n2, n3, false, n4, null, lIlIlIlIlIllllIlllIIIlIlI)) {
            final int liiiIlIIllIIlIIlIIIlIIllI = this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, n4, n5, n6, n7, 0);
            if (iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, this.lIIIIllIIlIlIllIIIlIllIlI, liiiIlIIllIIlIIlIIIlIIllI, 3)) {
                if (iiiiiIllIlIIIIlIlllIllllI.getBlock(n, n2, n3) == this.lIIIIllIIlIlIllIIIlIllIlI) {
                    this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, lIllIIIIlIIlIllIIIlIlIlll, lIlIlIlIlIllllIlllIIIlIlI);
                    this.lIIIIllIIlIlIllIIIlIllIlI.IIIIllIlIIIllIlllIlllllIl(iiiiiIllIlIIIIlIlllIllllI, n, n2, n3, liiiIlIIllIIlIIlIIIlIIllI);
                }
                iiiiiIllIlIIIIlIlllIllllI.lIIIIlIIllIIlIIlIIIlIIllI(n + 0.4888889f * 1.0227273f, n2 + 0.15f * 3.3333333f, n3 + 1.6964285f * 0.29473686f, this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIlllIIIIllIIllllIlIl.lIIIIIIIIIlIllIIllIlIIlIl(), (this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIlllIIIIllIIllllIlIl.IlllIIIlIlllIllIlIIlllIlI() + 1.0f) / 2.0f, this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIlllIIIIllIIllllIlIl.IIIIllIlIIIllIlllIlllllIl() * (0.95483875f * 0.8378378f));
                --lIlIlIlIlIllllIlllIIIlIlI.lIIIIIIIIIlIllIIllIlIIlIl;
            }
        }
        return true;
    }
}
