// 
// Decompiled by Procyon v0.5.36
// 

public interface IIllIIIIlllllIllIIllIllIl
{
    void lIIIIlIIllIIlIIlIIIlIIllI(final int p0, final int p1);
}
