// 
// Decompiled by Procyon v0.5.36
// 

public class IIIIlIlllIIlIIIlIIIIIIIIl extends IIlIIlIIllIIllIlIIIIIIIlI
{
    public IIIIlIlllIIlIIIlIIIIIIIIl(final int n) {
        super(n);
        this.IIllllIllllIIIlIIllllIlll.clear();
    }
}
