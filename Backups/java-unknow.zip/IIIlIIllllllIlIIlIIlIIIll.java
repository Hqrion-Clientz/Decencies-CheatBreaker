// 
// Decompiled by Procyon v0.5.36
// 

public class IIIlIIllllllIlIIlIIlIIIll extends IlIlIIlllIlIlllIllllllIII
{
    @Override
    public String IIIlIIlIlIIIlllIIlIllllll() {
        return this.lIIlIIllIIIIIlIllIIIIllII() ? this.IllIIIIIIIlIlIllllIIllIII : "container.dropper";
    }
}
