// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlIlIlIllIlIllIIllIIII
{
    private final IlIIIIllIlIlIIIlIIIllIIlI lIIIIlIIllIIlIIlIIIlIIllI;
    private final String lIIIIIIIIIlIllIIllIlIIlIl;
    private final IIIIlIIlIllIlllIIIlIlllll IlllIIIlIlllIllIlIIlllIlI;
    private String IIIIllIlIIIllIlllIlllllIl;
    
    public IIlIlIlIlIllIlIllIIllIIII(final IlIIIIllIlIlIIIlIIIllIIlI liiiIlIIllIIlIIlIIIlIIllI, final String s, final IIIIlIIlIllIlllIIIlIlllll illlIIIlIlllIllIlIIlllIlI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
        this.lIIIIIIIIIlIllIIllIlIIlIl = s;
        this.IlllIIIlIlllIllIlIIlllIlI = illlIIIlIlllIllIlIIlllIlI;
        this.IIIIllIlIIIllIlllIlllllIl = s;
    }
    
    public IlIIIIllIlIlIIIlIIIllIIlI lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
    
    public IIIIlIIlIllIlllIIIlIlllll IlllIIIlIlllIllIlIIlllIlI() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }
    
    public String IIIIllIlIIIllIlllIlllllIl() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }
    
    public void lIIIIlIIllIIlIIlIIIlIIllI(final String iiiIllIlIIIllIlllIlllllIl) {
        this.IIIIllIlIIIllIlllIlllllIl = iiiIllIlIIIllIlllIlllllIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI.IIIIllIlIIIllIlllIlllllIl(this);
    }
}
