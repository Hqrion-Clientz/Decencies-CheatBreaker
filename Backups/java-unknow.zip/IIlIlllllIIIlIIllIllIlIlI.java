import java.io.File;
import java.util.Collections;
import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.5.36
// 

public class IIlIlllllIIIlIIllIllIlIlI extends IlIIlllIlIIIlIIIlIlIlIlIl
{
    private final int IllIIIIIIIlIlIllllIIllIII;
    public final CBCustomProfile lIIIIlIIllIIlIIlIIIlIIllI;
    private final lllIllIllIlIllIlIIllllIIl lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl;
    private final ResourceLocation IlIlllIIIIllIllllIllIIlIl;
    private final ResourceLocation llIIlllIIIIlllIllIlIlllIl;
    private ResourceLocation lIIlIlIllIIlIIIlIIIlllIII;
    private ResourceLocation IIIlllIIIllIllIlIIIIIIlII;
    
    public IIlIlllllIIIlIIllIllIlIlI(final lllIllIllIlIllIlIIllllIIl liiiIllIIlIlIllIIIlIllIlI, final int illIIIIIIIlIlIllllIIllIII, final CBCustomProfile liiiIlIIllIIlIIlIIIlIIllI, final float n) {
        super(n);
        this.IlllIllIlIIIIlIIlIIllIIIl = 0;
        this.IlIlllIIIIllIllllIllIIlIl = new ResourceLocation("client/icons/delete-64.png");
        this.llIIlllIIIIlllIllIlIlllIl = new ResourceLocation("client/icons/checkmark-64.png");
        this.lIIlIlIllIIlIIIlIIIlllIII = new ResourceLocation("client/icons/right.png");
        this.IIIlllIIIllIllIlIIIIIIlII = new ResourceLocation("client/icons/pencil-64.png");
        this.lIIIIllIIlIlIllIIIlIllIlI = liiiIllIIlIlIllIIIlIllIlI;
        this.IllIIIIIIIlIlIllllIIllIII = illIIIIIIIlIlIllllIIllIII;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final float n3) {
        final boolean b = n > this.IIIIllIlIIIllIlllIlllllIl + 12 && this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        final int illlIllIlIIIIlIIlIIllIIIl = 75;
        IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)this.IIIIllIlIIIllIlllIlllllIl, (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII), 791621423);
        if (b) {
            if (this.IlllIllIlIIIIlIIlIIllIIIl < illlIllIlIIIIlIIlIIllIIIl) {
                this.IlllIllIlIIIIlIIlIIllIIIl += (int)lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI((float)790);
                if (this.IlllIllIlIIIIlIIlIIllIIIl > illlIllIlIIIIlIIlIIllIIIl) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = illlIllIlIIIIlIIlIIllIIIl;
                }
            }
        }
        else if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
            final float liiiIlIIllIIlIIlIIIlIIllI = lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI((float)790);
            if (this.IlllIllIlIIIIlIIlIIllIIIl - liiiIlIIllIIlIIlIIIlIIllI < 0.0f) {
                this.IlllIllIlIIIIlIIlIIllIIIl = 0;
            }
            else {
                this.IlllIllIlIIIIlIIlIIllIIIl -= (int)liiiIlIIllIIlIIlIIIlIIllI;
            }
        }
        if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
            IlIIIlIIlIIllIllllIlIlIll.lIIIIlIIllIIlIIlIIIlIIllI((float)(this.IIIIllIlIIIllIlllIlllllIl + 12), (float)(int)(this.IIIIllIIllIIIIllIllIIIlIl + (this.IIIllIllIlIlllllllIlIlIII - this.IIIllIllIlIlllllllIlIlIII * (this.IlllIllIlIIIIlIIlIIllIIIl / (float)illlIllIlIIIIlIIlIIllIIIl * 100) / 100)), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - (this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl() ? 0 : 30)), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII), this.IllIIIIIIIlIlIllllIIllIII);
        }
        final boolean b2 = n > this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 >= (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 <= (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        final boolean b3 = n > this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.1919192f * 1.8236842f);
        final float n4 = 6.571429f * 0.38043478f;
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl()) {
            boolean b4 = false;
            boolean b5 = false;
            final IIlIlIlllIllIIlIllIIlIIlI ilIlIlllIllIIlIllIIlIIlI = (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI;
            if (ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != 0 && ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) > 1) {
                b4 = true;
                GL11.glPushMatrix();
                if (b2) {
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.14444444f * 4.5f);
                }
                GL11.glTranslatef(this.IIIIllIlIIIllIlllIlllllIl + 6 - n4, this.IIIIllIIllIIIIllIllIIIlIl + (float)7, 0.0f);
                GL11.glRotatef((float)(-90), 0.0f, 0.0f, 1.0f);
                lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, n4, -1, 0.0f);
                GL11.glPopMatrix();
                GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.0952381f * 0.3195652f);
            }
            if (ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1) {
                b5 = true;
                GL11.glPushMatrix();
                if (b3) {
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.2112676f * 0.5366279f);
                }
                GL11.glTranslatef(this.IIIIllIlIIIllIlllIlllllIl + 6 + n4, this.IIIIllIIllIIIIllIllIIIlIl + (float)7, 0.0f);
                GL11.glRotatef((float)90, 0.0f, 0.0f, 1.0f);
                lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, n4, 2.0f, 0.0f);
                GL11.glPopMatrix();
            }
            if (!b4 && !b5) {
                lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, 1.173913f * 2.1296296f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 4), this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
            }
        }
        else {
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIlIlIllIIlIIIlIIIlllIII, 6.6666665f * 0.375f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 4), this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
        }
        if (CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl == this.lIIIIlIIllIIlIIlIIIlIIllI) {
            CheatBreaker.getInstance().IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + (float)16, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3), -818991313);
        }
        else {
            CheatBreaker.getInstance().IIIlllIIIllIllIlIIIIIIlII.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + (float)16, this.IIIIllIIllIIIIllIllIIIlIl + 3.9545455f * 0.88505745f, -818991313);
        }
        if (CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl == this.lIIIIlIIllIIlIIlIIIlIIllI) {
            CheatBreaker.getInstance().lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(" (Active)", this.IIIIllIlIIIllIlllIlllllIl + (float)17 + CheatBreaker.getInstance().IlllIllIlIIIIlIIlIIllIIIl.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI().toUpperCase()), this.IIIIllIIllIIIIllIllIIIlIl + (float)4, 1865363247);
        }
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl()) {
            final boolean b6 = n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 30) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
            GL11.glColor4f(b6 ? 0.0f : (1.1707317f * 0.21354167f), b6 ? 0.0f : (0.101648346f * 2.4594595f), b6 ? (0.48876402f * 1.0229886f) : (0.5647059f * 0.4427083f), 0.5675676f * 1.145238f);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlllIIIllIllIlIIIIIIlII, 5, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26), this.IIIIllIIllIIIIllIllIIIlIl + 5.1916666f * 0.6741573f);
            final boolean b7 = n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
            GL11.glColor4f(b7 ? (1.4181818f * 0.5641026f) : (0.96875f * 0.2580645f), b7 ? 0.0f : (0.17553192f * 1.4242424f), b7 ? 0.0f : (15.250001f * 0.016393442f), 0.44444445f * 1.4625f);
            lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, 5, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13), this.IIIIllIIllIIIIllIllIIIlIl + 0.7653061f * 4.5733333f);
        }
    }
    
    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(final int n, final int n2, final int n3) {
        final boolean b = n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        final boolean b2 = n > (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 30) * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        final boolean b3 = n > this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 >= (this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 <= (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        final boolean b4 = n > this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && n < (this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 > (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && n2 < (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        final IIlIlIlllIllIIlIllIIlIIlI ilIlIlllIllIIlIllIIlIIlI = (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI;
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl() && (b3 || b4)) {
            if (b3 && ((IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != 0 && ((IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) > 1) {
                Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) - 1;
                ((IIlIlllllIIIlIIllIllIlIlI)ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.get(ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) - 1)).lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this);
                Collections.swap(ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI, ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this), ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) - 1);
            }
            if (b4 && ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1) {
                Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
                this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) + 1;
                ((IIlIlllllIIIlIIllIllIlIlI)ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.get(ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) + 1)).lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI = ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this);
                Collections.swap(ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI, ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this), ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) + 1);
            }
        }
        else if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl() && b) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            if (CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl == this.lIIIIlIIllIIlIIlIIIlIIllI) {
                CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl = CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl.get(0);
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI());
                CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl()) {
                final File obj = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles");
                File file;
                if (obj.exists() || obj.mkdirs()) {
                    file = new File(obj + File.separator + this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI().toLowerCase() + ".cfg");
                }
                else {
                    file = null;
                }
                if (file.exists() && file.delete()) {
                    CheatBreaker.getInstance().lIIIIIIIIIlIllIIllIlIIlIl.removeIf(ilIIlIIlIIlllIlIIIlIllIIl -> ilIIlIIlIIlllIlIIIlIllIIl == this.lIIIIlIIllIIlIIlIIIlIIllI);
                    ilIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.removeIf(ilIlllllIIIlIIllIllIlIlI -> ilIlllllIIIlIIllIllIlIlI == this);
                }
            }
        }
        else if (!this.lIIIIlIIllIIlIIlIIIlIIllI.lIIIIIIIIIlIllIIllIlIIlIl() && b2) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            Minecraft.getMinecraft().displayGuiScreen(new llIIIlIlIIlIlIIlIllIllIll(this.lIIIIlIIllIIlIIlIIIlIIllI, lIIlIlIIlIlIlIIlIlIlllIIl.lIIIIlIIllIIlIIlIIIlIIllI, (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI, this.IllIIIIIIIlIlIllllIIllIII, this.lIIIIIIIIIlIllIIllIlIIlIl));
        }
        else if (CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl != this.lIIIIlIIllIIlIIlIIIlIIllI) {
            Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
            CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl.lIIIIIIIIIlIllIIllIlIIlIl(CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI());
            CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl = this.lIIIIlIIllIIlIIlIIIlIIllI;
            CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(CheatBreaker.getInstance().IIIIllIlIIIllIlllIlllllIl.lIIIIlIIllIIlIIlIIIlIIllI());
            CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI();
        }
    }
}
