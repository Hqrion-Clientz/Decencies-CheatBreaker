import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIIIlllIlllllllIllllIIlII implements Callable
{
    final /* synthetic */ ScaledResolution lIIIIlIIllIIlIIlIIIlIIllI;
    final /* synthetic */ EntityRenderer lIIIIIIIIIlIllIIllIlIIlIl;
    
    IIIIlllIlllllllIllllIIlII(final EntityRenderer liiiiiiiiIlIllIIllIlIIlIl, final ScaledResolution liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = liiiiiiiiIlIllIIllIlIIlIl;
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return String.format("Scaled: (%d, %d). Absolute: (%d, %d). Scale factor of %d", this.lIIIIlIIllIIlIIlIIIlIIllI.getScaledWidth(), this.lIIIIlIIllIIlIIlIIIlIIllI.getScaledHeight(), this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI.displayWidth, this.lIIIIIIIIIlIllIIllIlIIlIl.IllIlIIIIlllIIllIIlllIIlI.displayHeight, this.lIIIIlIIllIIlIIlIIIlIIllI.getScaleFactor());
    }
}
