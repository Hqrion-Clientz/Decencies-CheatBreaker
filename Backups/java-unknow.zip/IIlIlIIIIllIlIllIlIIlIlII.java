import java.util.concurrent.Callable;

// 
// Decompiled by Procyon v0.5.36
// 

class IIlIlIIIIllIlIllIlIIlIlII implements Callable
{
    final /* synthetic */ IllIlIlllIIIIIIlIIllIIIll lIIIIlIIllIIlIIlIIIlIIllI;
    
    IIlIlIIIIllIlIllIlIIlIlII(final IllIlIlllIIIIIIlIIllIIIll liiiIlIIllIIlIIlIIIlIIllI) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = liiiIlIIllIIlIIlIIIlIIllI;
    }
    
    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return "";
    }
}
