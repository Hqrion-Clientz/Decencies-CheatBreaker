package com.thevoxelbox.voxelmap.util;

public class Dimension {
	public String name = "notLoaded";
	public int ID = -10;

	public Dimension(String name, int ID) {
		this.name = name;
		this.ID = ID;
	}
}
