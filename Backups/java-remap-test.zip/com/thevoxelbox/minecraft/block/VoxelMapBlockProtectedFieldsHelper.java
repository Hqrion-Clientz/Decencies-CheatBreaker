package com.thevoxelbox.minecraft.block;

import net.minecraft.block.Block;

public class VoxelMapBlockProtectedFieldsHelper {
	public static void setLightOpacity(Block block, int opacity) {
		block.setLightOpacity(opacity);
	}
}
