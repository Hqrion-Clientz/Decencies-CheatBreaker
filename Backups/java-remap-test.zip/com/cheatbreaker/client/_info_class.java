package com.cheatbreaker.client;

/**
 * {@link net.minecraft.client.gui.Gui}
 *  * ├── drawHorizontalLine & drawVerticalLine take floats.
 *  * └── drawRect & drawGradientRect take floats.
 *
 * {@link net.minecraft.client.gui.FontRenderer}
 *  * ├── drawString methods take floats.
 *  * └── colorCode public
 *
 * {@link net.minecraft.client.Minecraft}
 *  * ├── debugFPS public
 *  * ├── Line 263  added cbLoadingScreen field {@link com.cheatbreaker.client.ui.CBLoadingScreen}
 *  * ├── Line 490 [this.field_152350_aA = n...] {@code this.cbLoadingScreen = new CBLoadingScreen(8);}
 *  * ├── Line 491 [this.cbLoadingScreen = n...] {@code this.cbLoadingScreen.drawMenu(0.0f, 0.0f);}
 *  * ├── Line 492 [this.cbLoadingScreen.dra...] {@code this.cbLoadingScreen.newMessage("Sound Handler");}
 *  * ├──
 *  * ├── Line 1732 [if (this.currentScree...] added event call to {@link com.cheatbreaker.client.event.type.CBTickEvent}
 *  * ├── Line 1787 [if (Mouse.getEventB...] added event call to {@link com.cheatbreaker.client.event.type.CBClickEvent}
 *  * ├── Line 1870 [if (Keyboard.getEventK...] added event call to {@link com.cheatbreaker.client.event.type.CBKeyboardEvent}
 *  * └── Line 2234 [if (p_71353_1_ != n...] added event call to {@link com.cheatbreaker.client.event.type.CBLoadWorldEvent}
 *
 * {@link net.minecraft.util.IObjectIntIterable}
 *  * └── now uses {@link net.minecraft.block.Block} as the iterator type.
 *
 * {@link net.minecraft.client.renderer.entity.Render}
 *  * └── getEntityTexture public
 *
 *  {@link net.minecraft.client.renderer.entity.RendererLivingEntity}
 *  * ├── renderPassModel public
 *  * ├── mainModel public
 *  * ├── preRenderCallback public
 *  * └── shouldRenderPass public
 *  {@link net.minecraft.client.renderer.entity.Render}
 *  * ├── func_147906_a (to add xd)
 *
 * {@link net.minecraft.client.settings.KeyBinding}
 *  * ├── isCheatBreaker field added
 *  * └── isCheatBreaker added to accept in a new constructor
 *
 * {@link net.minecraft.client.settings.GameSettings}
 *  * └── Lines 2242 - 2248 added logic to prevent the game from saving CheatBreaker keybindings.
 *
 *
 * @author Decencies
 * @author Freddie
 */
@SuppressWarnings("unused")
class _info_class {}
