package com.cheatbreaker.client.audio;

public class CBAudioDevice {

    private final String name;
    private final String descriptor;

    public CBAudioDevice(String name, String descriptor) {
        this.name = name;
        this.descriptor = descriptor;
    }

    public String getName() {
        return name;
    }

    public String getDescriptor() {
        return descriptor;
    }

}
