package com.cheatbreaker.client.util.font;

import com.cheatbreaker.client.util.LazyLoadBase;
import net.minecraft.util.ResourceLocation;

import java.lang.reflect.Array;
import java.util.Arrays;

/**
 * Fonts go up in increments of 2px.
 * Font size ranges start from 10px and go up to 22px.
 */
public class CBFontProvider {

    private static final LazyLoadBase<CBFontRenderer>[] ubuntu;

    public static CBFontRenderer ubuntu(float size) {
        return ubuntu[0].get();
    }

    static {
        ubuntu = (LazyLoadBase<CBFontRenderer>[]) Array.newInstance(LazyLoadBase.class, 10);
        for (int index = 0; index < ubuntu.length; index++) {
            int finalIndex = index;
            ubuntu[index] = new LazyLoadBase<CBFontRenderer>() {
                @Override
                protected void load() {
                    cache = new CBFontRenderer(new ResourceLocation("client/font/Ubuntu-M.ttf"), 14.0f);
                }
            };
        }
    }

}
