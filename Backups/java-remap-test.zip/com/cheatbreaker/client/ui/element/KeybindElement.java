package com.cheatbreaker.client.ui.element;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class KeybindElement
        extends AbstractElement {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;
    private ButtonElement IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI = false;

    public KeybindElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.height = 12;
        this.IllIIIIIIIlIlIllllIIllIII = new ButtonElement(CBClient.getInstance().playBold18px, null, Keyboard.getKeyName((Integer)cBSetting.getValue()), this.x + this.width - 100, this.y, 96, 18, -9442858, f);
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        boolean bl = (float) mouseX > (float)(this.x + this.width - 48) * this.scale && (float) mouseX < (float)(this.x + this.width - 10) * this.scale && (float) mouseY > (float)(this.y + this.yOffset) * this.scale && (float) mouseY < (float)(this.y + 10 + this.yOffset) * this.scale;
        boolean bl2 = (float) mouseX > (float)(this.x + this.width - 92) * this.scale && (float) mouseX < (float)(this.x + this.width - 48) * this.scale && (float) mouseY > (float)(this.y + this.yOffset) * this.scale && (float) mouseY < (float)(this.y + 10 + this.yOffset) * this.scale;
        CBClient.getInstance().ubuntuMedium16px.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toUpperCase(), this.x + 10, (float)(this.y + 4), bl2 || bl ? -1090519040 : -1895825408);
        if (this.lIIIIllIIlIlIllIIIlIllIlI && Keyboard.getEventKeyState()) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(Keyboard.getEventKey());
            this.IllIIIIIIIlIlIllllIIllIII.displayString = Keyboard.getKeyName((Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue());
            this.lIIIIllIIlIlIllIIIlIllIlI = false;
        }
        this.IllIIIIIIIlIlIllllIIllIII.yOffset = this.yOffset;
        this.IllIIIIIIIlIlIllllIIllIII.setPositionsAndDimensions(this.x + this.width - 100, this.y, 96, 18);
        this.IllIIIIIIIlIlIllllIIllIII.draw(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        if (this.IllIIIIIIIlIlIllllIIllIII.isMouseInside(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            this.lIIIIllIIlIlIllIIIlIllIlI = true;
            this.IllIIIIIIIlIlIllllIIllIII.displayString = "<PRESS ANY KEY>";
        }
    }
}
