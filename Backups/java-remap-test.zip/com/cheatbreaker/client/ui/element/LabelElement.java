package com.cheatbreaker.client.ui.element;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import net.minecraft.client.gui.Gui;

public class LabelElement
        extends AbstractElement {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;

    public LabelElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.height = 12;
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        CBClient.getInstance().ubuntuMedium16px.drawString(((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue()).toUpperCase(), this.x + 2, (float)(this.y + 2), 0x6F000000);
        Gui.drawRect(this.x + 2, this.y + this.height - 1, this.x + this.width / 2 - 20, this.y + this.height, 0x1F2F2F2F);
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
    }
}