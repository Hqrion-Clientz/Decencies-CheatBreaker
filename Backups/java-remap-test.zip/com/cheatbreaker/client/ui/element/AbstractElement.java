package com.cheatbreaker.client.ui.element;

import com.cheatbreaker.client.ui.CBModulesGui;
import net.minecraft.client.Minecraft;

public abstract class AbstractElement {
    public float scale;
    public int yOffset = 0;
    public int x;
    protected int y;
    protected int width;
    protected int height;

    public AbstractElement(float f) {
        this.scale = f;
    }

    public void setPositionsAndDimensions(int n, int n2, int n3, int n4) {
        this.x = n;
        this.y = n2;
        this.width = n3;
        this.height = n4;
    }

    public abstract void draw(int mouseX, int mouseY, float partialTicks);

    public abstract void mouseClicked(int var1, int var2, int var3);

    public boolean isMouseInside(int n, int n2) {
        return (float)n > (float)this.x * this.scale && (float)n < (float)(this.x + this.width) * this.scale && (float)n2 > (float)(this.y + this.yOffset) * this.scale && (float)n2 < (float)(this.y + this.height + this.yOffset) * this.scale && Minecraft.getMinecraft().currentScreen instanceof CBModulesGui;
    }

    public void onScroll(int n) {
    }

    public int getHeight() {
        return this.height;
    }
}

