package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.ui.unknown.CBUnknown_1;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;

import java.util.Arrays;
import java.util.List;

public abstract class CBAbstractGui extends GuiScreen {


    protected ScaledResolution resolution;
    protected float scaledWidth;
    protected float scaledHeight;
    protected List<CBUnknown_1> elements;

    @Override
    public void setWorldAndResolution(final Minecraft mc, final int displayWidth, final int displayHeight) {
        this.mc = mc;
        this.fontRendererObj = mc.fontRenderer;
        this.width = displayWidth;
        this.height = displayHeight;
        this.buttonList.clear();
        this.resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        final float scaleFactor = getScaleFactor();
        this.scaledWidth = width / scaleFactor;
        this.scaledHeight = height / scaleFactor;
        this.initGui();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        final float scaleFactor = getScaleFactor();
        GL11.glPushMatrix();
        GL11.glScalef(scaleFactor, scaleFactor, scaleFactor);
        drawMenu(mouseX / scaleFactor, mouseY / scaleFactor);
        GL11.glPopMatrix();
    }

    protected abstract void drawMenu(float mouseX, float mouseY);

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        final float scaleFactor = getScaleFactor();
        mouseClicked(mouseX / scaleFactor, mouseY / scaleFactor, mouseButton);
    }

    protected abstract void mouseClicked(float mouseX, float mouseY, int mouseButton);

    @Override
    protected void mouseMovedOrUp(int mouseX, int mouseY, int mouseButton) {
        final float scaleFactor = getScaleFactor();
        mouseReleased(mouseX / scaleFactor, mouseY / scaleFactor, mouseButton);
    }

    protected abstract void mouseReleased(float mouseX, float mouseY, int mouseButton);

    public void addElements(CBUnknown_1... elements) {
        this.elements.addAll(Arrays.asList(elements));
        this.initGui();
    }

    public void removeElements(CBUnknown_1... elements) {
        this.elements.removeAll(Arrays.asList(elements));
        this.initGui();
    }


    protected float getScaleFactor() {
        float n;
        switch (resolution.getScaleFactor()) {
            case 1: {
                n = 0.5f;
                break;
            }
            case 3: {
                n = 1.5f;
                break;
            }
            case 4: {
                n = 2.0f;
                break;
            }
            default: {
                n = 1.0f;
                break;
            }
        }
        return 1.0f / n;
    }


}
