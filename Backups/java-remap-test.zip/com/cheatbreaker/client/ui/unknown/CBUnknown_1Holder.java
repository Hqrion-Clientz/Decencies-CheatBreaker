package com.cheatbreaker.client.ui.unknown;

import java.util.ArrayList;
import java.util.List;

public class CBUnknown_1Holder extends CBUnknown_1 {
    protected final List<CBUnknown_1> IIIllIllIlIlllllllIlIlIII = new ArrayList<>();

    public CBUnknown_1Holder(List<CBUnknown_1> list) {
        this.IIIllIllIlIlllllllIlIlIII.addAll(list);
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(float f, float f2, boolean bl) {
        for (CBUnknown_1 cBUnknown1 : this.IIIllIllIlIlllllllIlIlIII) {
            cBUnknown1.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, bl);
        }
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IIIllIllIlIlllllllIlIlIII.forEach(CBUnknown_1::lIIIIIIIIIlIllIIllIlIIlIl);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI() {
        this.IIIllIllIlIlllllllIlIlIII.forEach(CBUnknown_1::lIIIIlIIllIIlIIlIIIlIIllI);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(char c, int n) {
        this.IIIllIllIlIlllllllIlIlIII.forEach(cBUnknown1 -> cBUnknown1.lIIIIlIIllIIlIIlIIIlIIllI(c, n));
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, int n, boolean bl) {
        if (!bl) {
            return false;
        }
        boolean bl2 = false;
        for (CBUnknown_1 cBUnknown1 : this.IIIllIllIlIlllllllIlIlIII) {
            if (bl2) break;
            bl2 = cBUnknown1.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, n, true);
        }
        return bl2;
    }

    @Override
    public boolean lIIIIIIIIIlIllIIllIlIIlIl(float f, float f2, int n, boolean bl) {
        if (!bl) {
            return false;
        }
        boolean bl2 = false;
        for (CBUnknown_1 cBUnknown1 : this.IIIllIllIlIlllllllIlIlIII) {
            if (bl2) break;
            bl2 = cBUnknown1.lIIIIIIIIIlIllIIllIlIIlIl(f, f2, n, true);
        }
        return bl2;
    }

    public List<CBUnknown_1> IllIIIIIIIlIlIllllIIllIII() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
}
