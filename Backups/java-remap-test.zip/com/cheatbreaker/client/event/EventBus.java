package com.cheatbreaker.client.event;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public class EventBus {

    private final ConcurrentHashMap<Class<? extends CBEvent>, CopyOnWriteArrayList<Consumer>> map;

    public EventBus() {
        this.map = new ConcurrentHashMap<>();
    }

    public <T extends CBEvent> boolean addEvent(final Class<T> clazz, final Consumer<T> consumer) {
        return this.map.computeIfAbsent(clazz, p0 -> new CopyOnWriteArrayList<>()).add(consumer);
    }

    public <T extends CBEvent> boolean removeEvent(final Class<T> clazz, final Consumer<T> consumer) {
        final CopyOnWriteArrayList<Consumer> list = this.map.get(clazz);
        return list != null && list.remove(consumer);
    }

    public void callEvent(final CBEvent cbEvent) {
        try {
            for (Serializable s = cbEvent.getClass(); s != null && s != CBEvent.class; s = ((Class<CBEvent>) s).getSuperclass()) {
                final CopyOnWriteArrayList<Consumer> list = this.map.get(s);
                if (list != null) {
                    list.forEach(consumer -> consumer.accept(cbEvent));
                }
            }
        } catch (Exception ex) {
            System.out.println("EventBus [" + cbEvent.getClass() + "]");
            ex.printStackTrace();
        }
    }
}
