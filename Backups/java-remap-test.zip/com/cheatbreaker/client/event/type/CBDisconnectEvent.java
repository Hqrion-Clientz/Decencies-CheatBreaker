package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;

public class CBDisconnectEvent extends CBEvent {
}
