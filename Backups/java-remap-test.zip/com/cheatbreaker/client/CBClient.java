package com.cheatbreaker.client;

import com.cheatbreaker.client.audio.CBAudioDevice;
import com.cheatbreaker.client.config.CBConfigManager;
import com.cheatbreaker.client.config.CBGlobalSettings;
import com.cheatbreaker.client.config.CBProfile;
import com.cheatbreaker.client.event.EventBus;
import com.cheatbreaker.client.event.type.CBKeyboardEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.ModuleManager;
import com.cheatbreaker.client.ui.CBModulesGui;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CBClient {

    @Getter
    public static CBClient instance;

    public List<CBProfile> profiles;
    public CBProfile activeProfile;
    public CBGlobalSettings globalSettings;
    public ModuleManager moduleManager;
    public CBConfigManager configManager;
    public EventBus eventBus;

    public List<ResourceLocation> presetLocations;

    public CBFontRenderer playBold22px;
    public CBFontRenderer playRegular22px;
    public CBFontRenderer ubuntuMedium16px;
    public CBFontRenderer playBold18px;
    public CBFontRenderer robotoRegular24px;
    public CBFontRenderer playRegular18px;
    public CBFontRenderer playRegular14px;
    public CBFontRenderer playRegular16px;
    public CBFontRenderer robotoRegular13px;
    public CBFontRenderer robotoBold14px;
    public CBFontRenderer playRegular12px;

    private static final ResourceLocation playRegular;
    private static final ResourceLocation playBold;
    private static final ResourceLocation robotoRegular;
    private static final ResourceLocation robotoBold;
    private static final ResourceLocation ubuntuMedium;

    static {
        playRegular = new ResourceLocation("client/font/Play-Regular.ttf");
        playBold = new ResourceLocation("client/font/Play-Bold.ttf");
        robotoRegular = new ResourceLocation("client/font/Roboto-Regular.ttf");
        robotoBold = new ResourceLocation("client/font/Roboto-Bold.ttf");
        ubuntuMedium = new ResourceLocation("client/font/Ubuntu-M.ttf");
    }

    public long startTime;

    private static List<CBAudioDevice> audioDevices;

    private static final AudioFormat universalAudioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 16000.0F, 16, 1, 2, 16000.0F, false);

    public CBClient() {
        CBClient.audioDevices = new ArrayList<>();
        this.presetLocations = new ArrayList<>();
        this.profiles = new ArrayList<>();
        this.startTime = System.currentTimeMillis();
        System.out.println("[CB] Starting CheatBreaker setup");
        this.createDefaultConfigPresets();
        System.out.println("[CB] Created default configuration presets");
        CBClient.instance = this;
        this.initAudioDevices();
        this.globalSettings = new CBGlobalSettings();
        System.out.println("[CB] Created settings");
        this.eventBus = new EventBus();
        System.out.println("[CB] Created EventBus");
        this.moduleManager = new ModuleManager();
        System.out.println("[CB] Created Mod Manager");
    }

    public void initialize() {
        this.loadFonts();
        System.out.println("[CB] Loaded all fonts");
        this.loadProfiles();
        System.out.println("[CB] Loaded " + this.profiles.size() + " custom profiles");
        (this.configManager = new CBConfigManager()).read();

        this.eventBus.addEvent(CBKeyboardEvent.class, (e) -> {
            if (e.getKeyboardKey() == Keyboard.KEY_H) {
                for (final CBModule module : this.moduleManager.modules) {
                    module.setState(!module.isEnabled());
                }
            }
            if (e.getKeyboardKey() == Keyboard.KEY_LMENU) {
                this.moduleManager.notifications.queueNotification("Error", "shidded farded and camed", 9000L);
            }
            if (e.getKeyboardKey() == Keyboard.KEY_RSHIFT) {
                if (Minecraft.getMinecraft().currentScreen == null) {
                    Minecraft.getMinecraft().displayGuiScreen(new CBModulesGui());
                }
            }
        });
    }

    private void loadFonts() {
        playBold22px = new CBFontRenderer(playBold, 22);
        playRegular22px = new CBFontRenderer(playRegular, 22);
        playRegular18px = new CBFontRenderer(playRegular, 18);
        playRegular14px = new CBFontRenderer(playRegular, 14);
        playRegular12px = new CBFontRenderer(playRegular, 12);
        playRegular16px = new CBFontRenderer(playRegular, 16);
        playBold18px = new CBFontRenderer(playBold, 18);
        ubuntuMedium16px = new CBFontRenderer(ubuntuMedium, 16);
        robotoRegular13px = new CBFontRenderer(robotoRegular, 13);
        robotoBold14px = new CBFontRenderer(robotoBold, 14);
        robotoRegular24px = new CBFontRenderer(robotoRegular, 24);
    }

    private void createDefaultConfigPresets() {
        File file = CBConfigManager.profilesDir;
        if (file.exists() || file.mkdirs()) {
            for (ResourceLocation resourceLocation : presetLocations) {
                File file2 = new File(file, resourceLocation.getResourcePath().replaceAll("([a-zA-Z0-9/]+)/", ""));
                if (!file2.exists()) {
                    try {
                        InputStream stream = Minecraft.getMinecraft().getResourceManager().getResource(resourceLocation).getInputStream();
                        Files.copy(stream, file2.toPath());
                        stream.close();
                    }
                    catch (final IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }

    private void loadProfiles() {
        this.profiles.add(new CBProfile("default", false));
        final File dir = CBConfigManager.profilesDir;
        final File[] files;
        if (dir.exists() && dir.isDirectory() && (files = dir.listFiles()) != null) {
            for (final File file : files) {
                if (file.getName().endsWith(".cfg")) {
                    this.profiles.add(new CBProfile(file.getName().replace(".cfg", ""), true));
                }
            }
        }
    }

    private String getNewProfileName(final String base) {
        final File dir = CBConfigManager.profilesDir;
        if (dir.exists() || dir.mkdirs()) {
            if (new File(dir + File.separator + base + ".cfg").exists()) {
                return this.getNewProfileName(base + "1");
            }
        }
        return base;
    }

    public void createNewProfile() {
        if (this.activeProfile == this.profiles.get(0)) {
            final CBProfile profile = new CBProfile(this.getNewProfileName("Profile 1"), true);
            this.activeProfile = profile;
            this.profiles.add(profile);
            this.configManager.write();
        }
    }

    private void initAudioDevices() {
        final Mixer.Info[] mixers = AudioSystem.getMixerInfo();
        for (final Mixer.Info info : mixers) {
            final Mixer mixer = AudioSystem.getMixer(info);
            try {
                mixer.getLine(new DataLine.Info(TargetDataLine.class, CBClient.universalAudioFormat));
                if (info != null) {
                    System.out.println("[CB] Added mic option : " + info.getName());
                    CBClient.audioDevices.add(new CBAudioDevice(info.getDescription(), info.getName()));
                }
            } catch (final IllegalArgumentException | LineUnavailableException ignored) {
                // the device was not a microphone.
            }
        }
    }

    public static String[] getAudioDeviceList() {
        final String[] audioDevices = new String[CBClient.audioDevices.size()];
        int var1 = 0;
        for(final Iterator<CBAudioDevice> var2 = CBClient.audioDevices.iterator(); var2.hasNext(); ++var1) {
            final CBAudioDevice var3 = var2.next();
            audioDevices[var1] = var3.getDescriptor();
        }
        return audioDevices;
    }

    public static String getAudioDevice(final String descriptor) {
        final Iterator<CBAudioDevice> var1 = CBClient.audioDevices.iterator();
        if (!var1.hasNext()) {
            return descriptor;
        } else {
            CBAudioDevice var2;
            for(var2 = var1.next(); !var2.getDescriptor().equals(descriptor); var2 = var1.next()) {
                if (!var1.hasNext()) {
                    return descriptor;
                }
            }

            return var2.getDescriptor();
        }
    }

    public static List<CBAudioDevice> getAudioDevices() {
        return CBClient.audioDevices;
    }

    public boolean isUsingStaffModules() {
        for (final CBModule cbModule : this.moduleManager.staffModules) {
            if (cbModule.isStaffEnabledModule()) {
                return true;
            }
        }
        return false;
    }
    public static float getScaleFactor() {
        switch (Minecraft.getMinecraft().gameSettings.guiScale) {
            case 0: {
                return 2.0f;
            }
            case 1: {
                return 0.2377049f * 2.1034484f;
            }
            case 3: {
                return 3.3333333f * 0.45000002f;
            }
            default: {
                return 1.0f;
            }
        }
    }


}
