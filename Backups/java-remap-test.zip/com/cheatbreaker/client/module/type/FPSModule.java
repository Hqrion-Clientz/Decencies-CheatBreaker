package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;

public class FPSModule extends CBModule {

    private final CBSetting showBackground;
    private final CBSetting textColor;
    private final CBSetting backgroundColor;

    public FPSModule() {
        super("FPS");
        this.setDefaultAnchor(CBGuiAnchor.MIDDLE_TOP);
        this.setDefaultTranslations(0.0f, 0.0f);
        this.setDefaultState(false);
        this.showBackground = new CBSetting(this, "Show Background").setValue(true);
        this.textColor = new CBSetting(this, "Text Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.backgroundColor = new CBSetting(this, "Background Color").setValue(0x6F000000).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.setPreviewLabel("[144 FPS]", 1.6978723f * 0.8245614f);
        this.addEvent(CBGuiDrawEvent.class, this::onRender);
    }
    private void onRender(CBGuiDrawEvent drawEvent) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        this.scaleAndTranslate(drawEvent.getResolution());
        if ((Boolean) this.showBackground.getValue()) {
            this.setDimensions(56, 18);
            Gui.drawRect(0.0f, 0.0f, 56, 13, this.backgroundColor.getColorValue());
            String string = Minecraft.debugFPS + " FPS";
            this.minecraft.fontRenderer.drawString(string, (int)(this.width / 2.0f - (float)(this.minecraft.fontRenderer.getStringWidth(string) / 2)), 3, this.textColor.getColorValue());
        } else {
            String string = "[" + Minecraft.debugFPS + " FPS]";
            this.minecraft.fontRenderer.drawString(string, (int)(this.width / 2.0f - (float)(this.minecraft.fontRenderer.getStringWidth(string) / 2)), 3, this.textColor.getColorValue(), true);
            this.setDimensions(this.minecraft.fontRenderer.getStringWidth(string), 18);
        }
        GL11.glPopMatrix();
    }
}
