package com.cheatbreaker.client.module.type.cooldowns;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.event.type.CBTickEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import com.cheatbreaker.client.ui.CBModulesGui;
import com.cheatbreaker.client.ui.CBModulePlaceGui;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class CooldownsModule extends CBModule {

    private static List<CooldownRenderer> real = new ArrayList();
    public CBSetting colorTheme;
    private CBSetting listMode;
    private CBSetting coloredColor;
    private List<CooldownRenderer> fake = new ArrayList();

    public CooldownsModule() {
        super("Cooldowns");
        this.setDefaultAnchor(CBGuiAnchor.MIDDLE_TOP);
        this.setDefaultTranslations(0.0f, 5);
        this.colorTheme = new CBSetting(this, "Color Theme").setValue("Bright").acceptedValues("Bright", "Dark", "Colored");
        this.listMode = new CBSetting(this, "List Mode").setValue("horizontal").acceptedValues("vertical", "horizontal");
        this.coloredColor = new CBSetting(this, "Colored color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.addEvent(CBTickEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
        this.addEvent(CBGuiDrawEvent.class, this::renderPreview);
        this.addEvent(CBGuiDrawEvent.class, this::renderReal);
        this.setDefaultState(true);
    }

    void lIIIIlIIllIIlIIlIIIlIIllI(CBTickEvent cBTickEvent) {
        if (!real.isEmpty()) {
            real.removeIf(CooldownRenderer::lIIIIlIIllIIlIIlIIIlIIllI);
        }
        if (!this.fake.isEmpty()) {
            this.fake.removeIf(CooldownRenderer::lIIIIlIIllIIlIIlIIIlIIllI);
        }
    }

    public void renderPreview(CBGuiDrawEvent lIllIlIlllIIlIIllIIlIIlII2) {
        if (!this.isRenderHud()) {
            return;
        }
        if (real.isEmpty()) {
            GL11.glPushMatrix();
            if (this.fake.isEmpty()) {
                this.fake.add(new CooldownRenderer("CombatTag", 283, 30000L));
                this.fake.add(new CooldownRenderer("EnderPearl", 368, 12000L));
            }
            this.scaleAndTranslate(lIllIlIlllIIlIIllIIlIIlII2.getResolution());
            float f = 1.0f / CBClient.getScaleFactor();
            GL11.glScalef(f, f, f);
            boolean bl = ((String)this.listMode.getValue()).equalsIgnoreCase("vertical");
            int n = 36;
            int n2 = 36;
            int n3 = bl ? n : this.fake.size() * n;
            int n4 = bl ? this.fake.size() * n2 : n2;
            this.setDimensions((int)((float)n3 * f), (int)((float)n4 * f));
            for (int i = 0; i < this.fake.size(); ++i) {
                CooldownRenderer cooldownRenderer2 = (CooldownRenderer)this.fake.get(i);
                if (((String)this.listMode.getValue()).equalsIgnoreCase("vertical")) {
                    cooldownRenderer2.lIIIIlIIllIIlIIlIIIlIIllI(this.colorTheme, this.width / 2.0f - (float)(n / 2), i * n2, this.coloredColor.getColorValue());
                    continue;
                }
                cooldownRenderer2.lIIIIlIIllIIlIIlIIIlIIllI(this.colorTheme, i * n, 0.0f, this.coloredColor.getColorValue());
            }
            GL11.glPopMatrix();
        }
    }

    public void renderReal(CBGuiDrawEvent lIllIllIlIIllIllIlIlIIlIl2) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        if (real.size() > 0) {
            this.scaleAndTranslate(lIllIllIlIIllIllIlIlIIlIl2.getResolution());
            float f = 1.0f / CBClient.getScaleFactor();
            GL11.glScalef(f, f, f);
            boolean bl = ((String)this.listMode.getValue()).equalsIgnoreCase("vertical");
            int n = 36;
            int n2 = 36;
            int n3 = bl ? n : real.size() * n;
            int n4 = bl ? real.size() * n2 : n2;
            this.setDimensions((int)((float)n3 * f), (int)((float)n4 * f));
            for (int i = 0; i < real.size(); ++i) {
                CooldownRenderer cooldownRenderer2 = real.get(i);
                if (((String)this.listMode.getValue()).equalsIgnoreCase("vertical")) {
                    cooldownRenderer2.lIIIIlIIllIIlIIlIIIlIIllI(this.colorTheme, this.width / 2.0f - (float)(n / 2), i * n2, this.coloredColor.getColorValue());
                    continue;
                }
                cooldownRenderer2.lIIIIlIIllIIlIIlIIIlIIllI(this.colorTheme, i * n, 0.0f, this.coloredColor.getColorValue());
            }
        } else if (!(this.minecraft.currentScreen instanceof CBModulesGui) && !(this.minecraft.currentScreen instanceof CBModulePlaceGui)) {
            this.setDimensions(50, 24);
            this.scaleAndTranslate(lIllIllIlIIllIllIlIlIIlIl2.getResolution());
        }
        GL11.glPopMatrix();
    }

    public static void lIIIIlIIllIIlIIlIIIlIIllI(String string, long l, int n) {
        for (CooldownRenderer cooldownRenderer2 : real) {
            if (!cooldownRenderer2.IlllIIIlIlllIllIlIIlllIlI().equalsIgnoreCase(string) || cooldownRenderer2.IIIIllIIllIIIIllIllIIIlIl() != n) continue;
            cooldownRenderer2.lIIIIIIIIIlIllIIllIlIIlIl();
            cooldownRenderer2.lIIIIlIIllIIlIIlIIIlIIllI(l);
            return;
        }
        real.add(new CooldownRenderer(string, n, l));
    }

}
