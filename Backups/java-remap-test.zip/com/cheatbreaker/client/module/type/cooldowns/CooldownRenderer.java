package com.cheatbreaker.client.module.type.cooldowns;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.module.type.armourstatus.ArmourStatusModule;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

public class CooldownRenderer {
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private int lIIIIIIIIIlIllIIllIlIIlIl;
    private long IlllIIIlIlllIllIlIIlllIlI;
    private long IIIIllIlIIIllIlllIlllllIl;
    private Minecraft IIIIllIIllIIIIllIllIIIlIl = Minecraft.getMinecraft();
    private ItemStack IlIlIIIlllIIIlIlllIlIllIl;

    public CooldownRenderer(String string, int n, long l) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = string;
        this.lIIIIIIIIIlIllIIllIlIIlIl = n;
        this.IlllIIIlIlllIllIlIIlllIlI = l;
        this.IIIIllIlIIIllIlllIlllllIl = System.currentTimeMillis();
        this.IlIlIIIlllIIIlIlllIlIllIl = new ItemStack(Item.getItemById(n));
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(CBSetting cBSetting, float f, float f2, int n) {
        float f3;
        int n2 = 17;
        GL11.glPushMatrix();
        float f4 = ArmourStatusModule.renderItem.zLevel;
        ArmourStatusModule.renderItem.zLevel = -200;
        float f5 = 0.69f * 1.9565217f;
        GL11.glTranslatef(0.22580644f * -2.2142859f, -1, 0.0f);
        GL11.glScalef(f5, f5, f5);
        RenderHelper.enableStandardItemLighting();
        ArmourStatusModule.renderItem.renderItemAndEffectIntoGUI(this.IIIIllIIllIIIIllIllIIIlIl.fontRenderer, this.IIIIllIIllIIIIllIllIIIlIl.getTextureManager(), this.IlIlIIIlllIIIlIlllIlIllIl, (int)((f + (float)(n2 / 2)) / f5), (int)((f2 + (float)(n2 / 2)) / f5));
        RenderHelper.disableStandardItemLighting();
        GL11.glPopMatrix();
        ArmourStatusModule.renderItem.zLevel = f4;
        double d = this.IlllIIIlIlllIllIlIIlllIlI - (System.currentTimeMillis() - this.IIIIllIlIIIllIlllIlllllIl);
        if (d <= 0.0) {
            return;
        }
        if (((String)cBSetting.getValue()).equalsIgnoreCase("Bright")) {
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.509434f * 0.39259258f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)n2, 0.0, (float)this.IlllIIIlIlllIllIlIIlllIlI / (0.9574468f * 4.1255555f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
            GL11.glColor4f(1.5945946f * 0.56440675f, 0.275f * 3.272727f, 0.7340425f * 1.226087f, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 1.1688311f * 0.08555556f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (0.625f * 6.32f), (int)this.IlllIIIlIlllIllIlIIlllIlI, this.IlllIIIlIlllIllIlIIlllIlI);
            GL11.glColor4f(2.6249998f * 0.13333334f, 0.16578947f * 2.1111112f, 0.62999994f * 0.5555556f, 1.6315789f * 0.36774194f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 0.886076f * 0.11285714f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (2.5510418f * 1.548387f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
        } else if (((String)cBSetting.getValue()).equalsIgnoreCase("Dark")) {
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.4f * 0.5f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(f + (float)n2, f2 + (float)n2, n2);
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.25773194f * 0.7760001f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)n2, 0.0, (float)this.IlllIIIlIlllIllIlIIlllIlI / (31.161114f * 0.12676056f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
            GL11.glColor4f(0.0f, 1.031746f * 0.87230766f, 0.0f, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 0.19f * 0.5263158f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (0.24074075f * 16.407692f), (int)this.IlllIIIlIlllIllIlIIlllIlI, this.IlllIIIlIlllIllIlIIlllIlI);
            GL11.glColor4f(0.0f, 0.022727273f * 22.0f, 0.0f, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 0.315f * 0.31746033f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (55.3f * 0.071428575f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
        } else if (((String)cBSetting.getValue()).equalsIgnoreCase("Colored")) {
            float f6 = (float)(n >> 24 & 0xFF) / (float)255;
            f3 = (float)(n >> 16 & 0xFF) / (float)255;
            float f7 = (float)(n >> 8 & 0xFF) / (float)255;
            float f8 = (float)(n & 0xFF) / (float)255;
            GL11.glColor4f(f3, f7, f8, 0.26086956f * 0.57500005f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(f + (float)n2, f2 + (float)n2, n2);
            GL11.glColor4f(f3, f7, f8, 0.060606062f * 4.125f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)n2, 0.0, (float)this.IlllIIIlIlllIllIlIIlllIlI / (7.0413046f * 0.5609756f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
            GL11.glColor4f(f3, f7, f8, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 0.10759494f * 0.92941177f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (3.2223685f * 1.2258065f), (int)this.IlllIIIlIlllIllIlIIlllIlI, this.IlllIIIlIlllIllIlIIlllIlI);
            GL11.glColor4f(f3, f7, f8, 0.058333337f * 2.5714285f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(f + (float)n2), (double)(f2 + (float)n2), (double)((float)n2 + 0.31707317f * 0.31538463f), (double)(n2 - 2), (float)this.IlllIIIlIlllIllIlIIlllIlI / (4.761644f * 0.82954544f), (int)this.IlllIIIlIlllIllIlIIlllIlI, d);
        }
        String string = String.format("%.1f", d / (double)1000);
        f3 = CBClient.getInstance().ubuntuMedium16px.getStringWidth(string);
        CBClient.getInstance().ubuntuMedium16px.drawString(string, (float) (f + (float)n2 - f3 / 2.0f), (float)(f2 + (float)(n2 / 2) + (float)7), 0x6F000000);
    }

    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIIllIlIIIllIlllIlllllIl < System.currentTimeMillis() - this.IlllIIIlIlllIllIlIIlllIlI;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(long l) {
        this.IlllIIIlIlllIllIlIIlllIlI = l;
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        this.IIIIllIlIIIllIlllIlllllIl = System.currentTimeMillis();
    }

    public String IlllIIIlIlllIllIlIIlllIlI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }

    public long IIIIllIlIIIllIlllIlllllIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }

    public int IIIIllIIllIIIIllIllIIIlIl() {
        return this.lIIIIIIIIIlIllIIllIlIIlIl;
    }
}
