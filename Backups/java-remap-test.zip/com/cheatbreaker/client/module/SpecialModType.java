package com.cheatbreaker.client.module;

public enum SpecialModType {
    SCOREBOARD,
    lIIIIIIIIIlIllIIllIlIIlIl,
    MINIMAP;

}
