package com.cheatbreaker.client.module;

import com.cheatbreaker.client.module.type.*;
import com.cheatbreaker.client.module.type.armourstatus.ArmourStatusModule;
import com.cheatbreaker.client.module.type.cooldowns.CooldownsModule;
import com.cheatbreaker.client.module.type.keystrokes.KeystrokesModule;
import com.cheatbreaker.client.module.type.notifications.CBNotificationsModule;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    public List<CBModule> modules;
    public List<CBModule> staffModules;
    public MiniMapModule minmap;
    public CBNotificationsModule notifications;
    public ArmourStatusModule armourStatus;
    public CooldownsModule cooldowns;
    public ScoreboardModule scoreboard;
    public XRayModule xray;
    public PotionStatusModule potionStatus;
    public CBModule llIIlllIIIIlllIllIlIlllIl;
    public KeystrokesModule keyStrokes;
    public FPSModule fpsModule;
    public CPSModule cpsModule;
    public CoordinatesModule coordinatesModule;

    public ModuleManager() {
        modules = new ArrayList<>();
        staffModules = new ArrayList<>();
        staffModules.add(xray = new XRayModule());
        modules.add(minmap = new MiniMapModule());
        modules.add(notifications = new CBNotificationsModule());
        modules.add(armourStatus = new ArmourStatusModule());
        modules.add(cooldowns = new CooldownsModule());
        modules.add(scoreboard = new ScoreboardModule());
        modules.add(potionStatus = new PotionStatusModule());
        modules.add(keyStrokes = new KeystrokesModule());
        modules.add(fpsModule = new FPSModule());
        modules.add(cpsModule = new CPSModule());
        modules.add(coordinatesModule = new CoordinatesModule());
        for (CBModule staffModule : staffModules) {
            staffModule.setStaffModuleEnabled(true);
        }
    }

}
