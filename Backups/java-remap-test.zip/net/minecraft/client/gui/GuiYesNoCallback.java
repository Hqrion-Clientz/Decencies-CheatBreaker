package net.minecraft.client.gui;

public interface GuiYesNoCallback
{
    void confirmClicked(boolean p_73878_1_, int p_73878_2_);
}
