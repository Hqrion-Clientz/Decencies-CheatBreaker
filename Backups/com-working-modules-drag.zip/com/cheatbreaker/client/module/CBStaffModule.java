package com.cheatbreaker.client.module;

import com.cheatbreaker.client.config.CBSetting;

public class CBStaffModule extends CBModule {
    private CBSetting staffModule = new CBSetting(this, "Keybind").setValue(0);

    public CBSetting lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.staffModule;
    }

    public CBStaffModule(String string) {
        super(string);
    }

    public void lIIlllIIlIlllllllllIIIIIl() {
        if (this.isEnabled()) {
            this.setState(false);
        }
        this.setStaffModuleEnabled(false);
    }
}
