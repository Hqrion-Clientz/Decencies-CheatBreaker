package com.cheatbreaker.client.module.type.notifications;

enum CBNotificationType {
    INFO,
    ERROR,
    DEFAULT;

}