package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBClickEvent;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.event.type.CBTickEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class CPSModule extends CBModule {

    private final List<Long> clicks;
    private final CBSetting showBackground;
    private final CBSetting textColor;
    private final CBSetting backgroundColor;

    public CPSModule() {
        super("CPS");
        this.setDefaultAnchor(CBGuiAnchor.RIGHT_TOP);
        this.setDefaultTranslations(0.0f, 0.0f);
        this.setState(false);
        this.clicks = new ArrayList<>();
        this.showBackground = new CBSetting(this, "Show Background").setValue(true);
        this.textColor = new CBSetting(this, "Text Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.backgroundColor = new CBSetting(this, "Background Color").setValue(0x6F000000).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.setPreviewLabel("[9 CPS]", 1.1030303f * 1.2692307f);
        this.addEvent(CBGuiDrawEvent.class, this::onDraw);
        this.addEvent(CBTickEvent.class, this::onTick);
        this.addEvent(CBClickEvent.class, this::onClick);
    }

    private void onDraw(CBGuiDrawEvent drawEvent) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        this.scaleAndTranslate(drawEvent.getResolution());
        if ((Boolean) this.showBackground.getValue()) {
            this.setDimensions(56, 18);
            Gui.drawRect(0.0f, 0.0f, 56, 13, this.backgroundColor.getColorValue());
            String string = this.clicks.size() + " CPS";
            this.minecraft.fontRenderer.drawString(string, (int)(this.width / 2.0f - (float)(this.minecraft.fontRenderer.getStringWidth(string) / 2)), 3, this.textColor.getColorValue());
        } else {
            String string = "[" + this.clicks.size() + " CPS]";
            this.minecraft.fontRenderer.drawString(string, (int)(this.width / 2.0f - (float)(this.minecraft.fontRenderer.getStringWidth(string) / 2)), 3, this.textColor.getColorValue(), true);
            this.setDimensions(this.minecraft.fontRenderer.getStringWidth(string), 18);
        }
        GL11.glPopMatrix();
    }

    private void onTick(CBTickEvent cBTickEvent) {
        this.clicks.removeIf(l -> l < System.currentTimeMillis() - 1000L);
    }

    private void onClick(CBClickEvent cBClickEvent) {
        if (cBClickEvent.getMouseButton() == 0) {
            this.clicks.add(System.currentTimeMillis());
        }
    }

}
