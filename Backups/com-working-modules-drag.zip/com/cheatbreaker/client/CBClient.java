package com.cheatbreaker.client;

import com.cheatbreaker.client.audio.CBAudioDevice;
import com.cheatbreaker.client.config.CBConfigManager;
import com.cheatbreaker.client.config.CBGlobalSettings;
import com.cheatbreaker.client.config.CBProfile;
import com.cheatbreaker.client.event.EventBus;
import com.cheatbreaker.client.event.type.CBKeyboardEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.ModuleManager;
import com.cheatbreaker.client.ui.CBModulesGui;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CBClient {

    // we cannot use a one line getter because it will initiate an overflow.
    @Getter
    public static CBClient instance;
    @Getter
    public List<CBProfile> profiles;
    @Getter
    public CBProfile activeProfile;
    @Getter
    public CBGlobalSettings globalSettings;
    @Getter
    public ModuleManager moduleManager;
    @Getter
    public CBConfigManager configManager;
    @Getter
    public EventBus eventBus;

    public List<ResourceLocation> presetLocations;

    public CBFontRenderer playBold22px;
    public CBFontRenderer playRegular22px;
    public CBFontRenderer ubuntuMedium16px;
    public CBFontRenderer playBold18px;
    public CBFontRenderer robotoRegular24px;
    public CBFontRenderer playRegular18px;
    public CBFontRenderer playRegular14px;
    public CBFontRenderer playRegular16px;
    public CBFontRenderer robotoRegular13px;
    public CBFontRenderer robotoBold14px;
    public CBFontRenderer playRegular12px;

    private static final ResourceLocation playRegular;
    private static final ResourceLocation playBold;
    private static final ResourceLocation robotoRegular;
    private static final ResourceLocation robotoBold;
    private static final ResourceLocation ubuntuMedium;

    static {
        playRegular = new ResourceLocation("client/font/Play-Regular.ttf");
        playBold = new ResourceLocation("client/font/Play-Bold.ttf");
        robotoRegular = new ResourceLocation("client/font/Roboto-Regular.ttf");
        robotoBold = new ResourceLocation("client/font/Roboto-Bold.ttf");
        ubuntuMedium = new ResourceLocation("client/font/Ubuntu-M.ttf");
    }

    public long startTime;

    private static List<CBAudioDevice> audioDevices;

    private static final AudioFormat universalAudioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 16000.0F, 16, 1, 2, 16000.0F, false);

    public CBClient() {
        audioDevices = new ArrayList<>();
        presetLocations = new ArrayList<>();
        profiles = new ArrayList<>();
        startTime = System.currentTimeMillis();
        System.out.println("[CB] Starting CheatBreaker setup");
        createDefaultConfigPresets();
        System.out.println("[CB] Created default configuration presets");
        instance = this;
        initAudioDevices();
        globalSettings = new CBGlobalSettings();
        System.out.println("[CB] Created settings");
        eventBus = new EventBus();
        System.out.println("[CB] Created EventBus");
        moduleManager = new ModuleManager();
        System.out.println("[CB] Created Mod Manager");
    }

    public void initialize() {
        loadFonts();
        System.out.println("[CB] Loaded all fonts");
        loadProfiles();
        System.out.println("[CB] Loaded " + profiles.size() + " custom profiles");
        (configManager = new CBConfigManager()).read();

        eventBus.addEvent(CBKeyboardEvent.class, (e) -> {
            if (e.getKeyboardKey() == Keyboard.KEY_H) {
                for (CBModule module : moduleManager.modules) {
                    module.setState(!module.isEnabled());
                }
            }
            if (e.getKeyboardKey() == Keyboard.KEY_LMENU) {
                moduleManager.notifications.queueNotification("Error", "shidded farded and camed", 9000L);
            }
            if (e.getKeyboardKey() == Keyboard.KEY_RSHIFT) {
                if (Minecraft.getMinecraft().currentScreen == null) {
                    Minecraft.getMinecraft().displayGuiScreen(new CBModulesGui());
                }
            }
        });
    }

    private void loadFonts() {
        this.playBold22px = new CBFontRenderer(CBClient.playBold, 22);
        this.playRegular22px = new CBFontRenderer(playRegular, 22);
        this.playRegular18px = new CBFontRenderer(playRegular, 18);
        this.playRegular14px = new CBFontRenderer(playRegular, 14);
        this.playRegular12px = new CBFontRenderer(playRegular, 12);
        this.playRegular16px = new CBFontRenderer(playRegular, 16);
        this.playBold18px = new CBFontRenderer(CBClient.playBold, 18);
        this.ubuntuMedium16px = new CBFontRenderer(CBClient.ubuntuMedium, 16);
        this.robotoRegular13px = new CBFontRenderer(CBClient.robotoRegular, 13);
        this.robotoBold14px = new CBFontRenderer(CBClient.robotoBold, 14);
        this.robotoRegular24px = new CBFontRenderer(CBClient.robotoRegular, 24);
    }

    private void createDefaultConfigPresets() {
        final File file = CBConfigManager.profilesDir;
        if (file.exists() || file.mkdirs()) {
            for (final ResourceLocation resourceLocation : this.presetLocations) {
                final File file2 = new File(file, resourceLocation.getResourcePath().replaceAll("([a-zA-Z0-9/]+)/", ""));
                if (!file2.exists()) {
                    try {
                        final InputStream stream = Minecraft.getMinecraft().getResourceManager().getResource(resourceLocation).getInputStream();
                        Files.copy(stream, file2.toPath());
                        stream.close();
                    }
                    catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }

    private void loadProfiles() {
        profiles.add(new CBProfile("default", false));
        File dir = CBConfigManager.profilesDir;
        File[] files;
        if (dir.exists() && dir.isDirectory() && (files = dir.listFiles()) != null) {
            for (File file : files) {
                if (file.getName().endsWith(".cfg")) {
                    profiles.add(new CBProfile(file.getName().replace(".cfg", ""), true));
                }
            }
        }
    }

    private String getNewProfileName(String base) {
        File dir = CBConfigManager.profilesDir;
        if (dir.exists() || dir.mkdirs()) {
            if (new File(dir + File.separator + base + ".cfg").exists()) {
                return getNewProfileName(base + "1");
            }
        }
        return base;
    }

    public void createNewProfile() {
        if (activeProfile == profiles.get(0)) {
            CBProfile profile = new CBProfile(getNewProfileName("Profile 1"), true);
            activeProfile = profile;
            profiles.add(profile);
            configManager.write();
        }
    }

    private void initAudioDevices() {
        Mixer.Info[] mixers = AudioSystem.getMixerInfo();
        for (Mixer.Info info : mixers) {
            Mixer mixer = AudioSystem.getMixer(info);
            try {
                mixer.getLine(new DataLine.Info(TargetDataLine.class, universalAudioFormat));
                if (info != null) {
                    System.out.println("[CB] Added mic option : " + info.getName());
                    audioDevices.add(new CBAudioDevice(info.getDescription(), info.getName()));
                }
            } catch (IllegalArgumentException | LineUnavailableException ignored) {
                // the device was not a microphone.
            }
        }
    }

    public static String[] getAudioDeviceList() {
        String[] audioDevices = new String[CBClient.audioDevices.size()];
        int var1 = 0;
        for(Iterator<CBAudioDevice> var2 = CBClient.audioDevices.iterator(); var2.hasNext(); ++var1) {
            CBAudioDevice var3 = var2.next();
            audioDevices[var1] = var3.getDescriptor();
        }
        return audioDevices;
    }

    public static String getAudioDevice(String descriptor) {
        Iterator<CBAudioDevice> var1 = audioDevices.iterator();
        if (!var1.hasNext()) {
            return descriptor;
        } else {
            CBAudioDevice var2;
            for(var2 = var1.next(); !var2.getDescriptor().equals(descriptor); var2 = var1.next()) {
                if (!var1.hasNext()) {
                    return descriptor;
                }
            }

            return var2.getDescriptor();
        }
    }

    public static List<CBAudioDevice> getAudioDevices() {
        return audioDevices;
    }

    public boolean isUsingStaffModules() {
        for (CBModule cbModule : moduleManager.staffModules) {
            if (cbModule.isStaffEnabledModule()) {
                return true;
            }
        }
        return false;
    }
    public static float getScaleFactor() {
        switch (Minecraft.getMinecraft().gameSettings.guiScale) {
            case 0: {
                return 2.0f;
            }
            case 1: {
                return 0.2377049f * 2.1034484f;
            }
            case 3: {
                return 3.3333333f * 0.45000002f;
            }
            default: {
                return 1.0f;
            }
        }
    }


}
