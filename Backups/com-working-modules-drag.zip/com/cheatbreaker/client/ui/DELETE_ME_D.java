package com.cheatbreaker.client.ui;

enum DELETE_ME_D {
    lIIIIlIIllIIlIIlIIIlIIllI,
    lIIIIIIIIIlIllIIllIlIIlIl,
    IlllIIIlIlllIllIlIIlllIlI,
    IIIIllIlIIIllIlllIlllllIl;

}
