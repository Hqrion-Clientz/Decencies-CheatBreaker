package com.cheatbreaker.client.ui.element;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.element.ModulePreviewElement;
import com.cheatbreaker.client.ui.element.ScrollableElement;
import com.cheatbreaker.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

public class ModulePreviewContainer
        extends ScrollableElement {
    private final List<ModulePreviewElement> elements = new ArrayList<>();

    public ModulePreviewContainer(float f, int n, int n2, int n3, int n4) {
        super(f, n, n2, n3, n4);
        for (CBModule module : CBClient.getInstance().getModuleManager().modules) {
            if (module == CBClient.getInstance().getModuleManager().notifications) continue;
            ModulePreviewElement element = new ModulePreviewElement(this, module, f);
            this.elements.add(element);
        }
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule) {
        return false;
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        super.draw(mouseX, mouseY, partialTicks);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.x, this.y, this.x + this.width, this.y + this.height + 2, (double)8, -657931);
        this.preDraw(mouseX, mouseY);
        int n3 = 0;
        int n4 = 0;
        for (ModulePreviewElement element : this.elements) {
            element.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
            element.setPositionsAndDimensions(this.x + 4 + n3 * 120, this.y + 4 + n4 * 112, 116, 108);
            element.draw(mouseX, mouseY, partialTicks);
            if (++n3 != 3) continue;
            ++n4;
            n3 = 0;
        }
        this.IlllIllIlIIIIlIIlIIllIIIl = 4 + n4 * 112 + 112;
        this.postDraw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        for (ModulePreviewElement element : this.elements) {
            if (!element.isMouseInside(mouseX, mouseY)) continue;
            element.mouseClicked(mouseX, mouseY, button);
        }
    }
}
