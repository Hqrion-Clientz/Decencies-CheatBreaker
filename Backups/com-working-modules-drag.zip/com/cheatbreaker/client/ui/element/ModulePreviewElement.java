package com.cheatbreaker.client.ui.element;

import java.util.Objects;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.config.SettingType;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBModulesGui;
import com.cheatbreaker.client.ui.CBModulePlaceGui;
import com.cheatbreaker.client.module.type.cooldowns.CooldownRenderer;
import com.cheatbreaker.client.util.RenderUtil;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class ModulePreviewElement extends AbstractElement {
    private final CBModule module;
    private final ButtonElement optionsButton;
    private final ButtonElement toggleOrHideFromHud;
    private final ButtonElement toggle;
    private final ScrollableElement IlIlllIIIIllIllllIllIIlIl;

    public ModulePreviewElement(ScrollableElement parent, CBModule module, float f) {
        super(f);
        this.module = module;
        this.IlIlllIIIIllIllllIllIIlIl = parent;
        CBFontRenderer optionsFontRenderer = CBClient.getInstance().playBold18px;
        CBFontRenderer hideOrToggleFontRenderer = CBClient.getInstance().playRegular14px;
        this.optionsButton = new ButtonElement(optionsFontRenderer, null, "Options", this.x + 4, this.y + this.height - 20, this.x + this.width - 4, this.y + this.height - 6, -12418828, f);
        this.toggleOrHideFromHud = new ButtonElement(hideOrToggleFontRenderer, null, module.getGuiAnchor() == null ? (module.isRenderHud() ? "Disable" : "Enable") : (module.isRenderHud() ? "Hide from HUD" : "Add to HUD"), this.x + 4, this.y + this.height - 38, this.x + this.width / 2 - 2, this.y + this.height - 24, module.isRenderHud() ? -5756117 : -13916106, f);
        this.toggleOrHideFromHud.lIIIIlIIllIIlIIlIIIlIIllI(module != CBClient.getInstance().getModuleManager().minmap && module != CBClient.getInstance().getModuleManager().notifications);
        this.toggle = new ButtonElement(hideOrToggleFontRenderer, null, module.isEnabled() ? "Disable" : "Enable", this.x + this.width / 2 + 2, this.y + this.height - 38, this.x + this.width - 4, this.y + this.height - 24, module.isEnabled() ? -5756117 : -13916106, f);
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        float f2;
        Object object;
        if (this.module.isEnabled()) {
            Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -13916106);
        } else {
            Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -1347374928);
        }
        CBFontRenderer playBold18px = CBClient.getInstance().playBold18px;
        GL11.glPushMatrix();
        int n3 = 0;
        int n4 = 0;
        if (this.module == CBClient.getInstance().getModuleManager().armourStatus) {
            n3 = -10;
            object = "329/329";
            f2 = Minecraft.getMinecraft().fontRenderer.getStringWidth((String)object);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow((String)object, (int)((float)(this.x + 1 + this.width / 2) - f2 / 2.0f), this.y + this.height / 2 - 18, -1);
        } else if (this.module == CBClient.getInstance().getModuleManager().potionStatus) {
            n4 = -30;
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Speed II", this.x + 8 + this.width / 2 - 20, this.y + this.height / 2 - 36, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("0:42", this.x + 8 + this.width / 2 - 20, this.y + this.height / 2 - 26, -1);
        } else if (this.module == CBClient.getInstance().getModuleManager().scoreboard) {
            Gui.drawRect(this.x + 20, this.y + this.height / 2f - 44, this.x + this.width - 20, this.y + this.height / 2 - 6, 0x6F000000);
            Minecraft.getMinecraft().fontRenderer.drawString("Score", this.x + this.width / 2, this.y + this.height / 2 - 40, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Steve", this.x + 24, this.y + this.height / 2 - 28, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Alex", this.x + 24, this.y + this.height / 2 - 18, -1);
            Minecraft.getMinecraft().fontRenderer.drawString(EnumChatFormatting.RED + "0", this.x + this.width - 26, this.y + this.height / 2 - 18, -1);
            Minecraft.getMinecraft().fontRenderer.drawString(EnumChatFormatting.RED + "1", this.x + this.width - 26, this.y + this.height / 2 - 28, -1);
        }
        if (this.module == CBClient.getInstance().getModuleManager().cooldowns) {
            object = new CooldownRenderer("EnderPearl", 368, 9000L);
            ((CooldownRenderer)object).lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getModuleManager().cooldowns.colorTheme, this.x + this.width / 2 - 18, this.y + this.height / 2 - 26 - 18, -1);
        } else if ((this.module.getPreviewType() == null || this.module.getPreviewType() == CBModule.PreviewType.LABEL) && this.module != CBClient.getInstance().getModuleManager().scoreboard) {
            object = "";
            if (this.module.getPreviewType() == null) {
                f2 = 2.0f;
                for (String string : this.module.getName().split(" ")) {
                    String string2 = string.substring(0, 1);
                    object = (String)object + (Objects.equals(object, "") ? string2 : string2.toLowerCase());
                }
            } else {
                f2 = this.module.getPreviewLabelSize();
                object = this.module.getPreviewLabel();
            }
            GL11.glScalef(f2, f2, f2);
            float f3 = (float)Minecraft.getMinecraft().fontRenderer.getStringWidth((String)object) * f2;
            if (this.module.getPreviewType() == null) {
                Minecraft.getMinecraft().fontRenderer.drawString((String)object, (int)(((float)(this.x + 1 + this.width / 2) - f3 / 2.0f) / f2), (int)((float)(this.y + this.height / 2 - 32) / f2), -13750738);
            } else {
                Minecraft.getMinecraft().fontRenderer.drawStringWithShadow((String)object, (int)(((float)(this.x + 1 + this.width / 2) - f3 / 2.0f) / f2), (int)((float)(this.y + this.height / 2 - 32) / f2), -1);
            }
        } else if (this.module.getPreviewType() == CBModule.PreviewType.ICON) {
            float f4 = this.module.getPreviewIconWidth();
            f2 = this.module.getPreviewIconHeight();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.module.getPreviewIcon(), (float)(this.x + this.width / 2) - f4 / 2.0f + (float)n4, (float)(this.y + n3 + this.height / 2 - 26) - f2 / 2.0f, f4, f2);
        }
        GL11.glPopMatrix();
        float moduleNameOffset = this.y + this.height / 2f + 4f;
        playBold18px.drawCenteredString(this.module.getName(), (float)(this.x + this.width / 2) - 1.0681819f * 0.46808508f, moduleNameOffset + 1, 0x5F000000);
        playBold18px.drawCenteredString(this.module.getName(), (float)(this.x + this.width / 2) - 1.125f * 1.3333334f, moduleNameOffset, -1);
        this.toggle.displayString = this.module.isEnabled() ? "Disable" : "Enable";
        this.toggle.yOffset = this.yOffset;
        int n5 = this.toggle.lIIIIlIIllIIlIIlIIIlIIllI = this.module.isEnabled() ? -5756117 : -13916106;
        this.toggleOrHideFromHud.displayString = this.module.getGuiAnchor() == null ? (this.module.isRenderHud() && this.module.isEnabled() ? "Disable" : "Enable") : (this.module.isRenderHud() && this.module.isEnabled() ? "Hide from HUD" : "Add to HUD");
        this.toggleOrHideFromHud.lIIIIlIIllIIlIIlIIIlIIllI = this.module.isRenderHud() && this.module.isEnabled() ? -5756117 : -13916106;
        this.optionsButton.setPositionsAndDimensions(this.x + 4, this.y + this.height - 20, this.width - 8, 16);
        this.optionsButton.yOffset = this.yOffset;
        this.optionsButton.draw(mouseX, mouseY, partialTicks);
        this.toggleOrHideFromHud.setPositionsAndDimensions(this.x + 4, this.y + this.height - 38, this.module.isEditable ? this.width - 8 : this.width / 2 + 2, this.y + this.height - 24 - (this.y + this.height - 38));
        this.toggleOrHideFromHud.yOffset = this.yOffset;
        this.toggleOrHideFromHud.draw(mouseX, mouseY, partialTicks);
        if (!this.module.isEditable) {
            this.toggle.setPositionsAndDimensions(this.x + this.width / 2 + 8, this.y + this.height - 38, this.width / 2 - 12, this.y + this.height - 24 - (this.y + this.height - 38));
            this.toggle.draw(mouseX, mouseY, partialTicks);
        }
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        if (this.optionsButton.isMouseInside(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            ((ModuleListElement) CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).llIlIIIlIIIIlIlllIlIIIIll = false;
            ((ModuleListElement)CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).IIIlllIIIllIllIlIIIIIIlII = this.IlIlllIIIIllIllllIllIIlIl;
            ((ModuleListElement)CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).IIIlIIllllIIllllllIlIIIll = this.module;
            CBModulesGui.instance.currentScrollableElement = CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl;
        } else if (!this.module.isEditable && this.toggle.isMouseInside(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            this.module.setState(!this.module.isEnabled());
            this.toggle.displayString = this.module.isEnabled() ? "Disable" : "Enable";
            int n4 = this.toggle.lIIIIlIIllIIlIIlIIIlIIllI = this.module.isEnabled() ? -5756117 : -13916106;
            if (this.module.isEnabled()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                this.module.setState(true);
            }
        } else if (this.toggleOrHideFromHud.IlllIllIlIIIIlIIlIIllIIIl && this.toggleOrHideFromHud.isMouseInside(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            if (!this.module.isEnabled()) {
                this.module.setRenderHud(true);
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                if (this.module.getGuiAnchor() == null) {
                    this.module.setState(true);
                } else {
                    Minecraft.getMinecraft().displayGuiScreen(new CBModulePlaceGui(CBModulesGui.instance, this.module));
                }
            } else {
                this.module.setRenderHud(!this.module.isRenderHud());
                if (this.module.isRenderHud()) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl();
                    if (this.module.getGuiAnchor() == null) {
                        this.module.setState(true);
                    } else {
                        Minecraft.getMinecraft().displayGuiScreen(new CBModulePlaceGui(CBModulesGui.instance, this.module));
                    }
                } else if (this.module.isEditable && this.module.isEnabled()) {
                    this.module.setState(false);
                }
            }
            this.toggleOrHideFromHud.displayString = this.module.getGuiAnchor() == null ? (this.module.isRenderHud() && this.module.isEnabled() ? "Disable" : "Enable") : (this.module.isRenderHud() && this.module.isEnabled() ? "Hide from HUD" : "Add to HUD");
            this.toggleOrHideFromHud.lIIIIlIIllIIlIIlIIIlIIllI = this.module.isRenderHud() && this.module.isEnabled() ? -5756117 : -13916106;
        }
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.module == CBClient.getInstance().getModuleManager().llIIlllIIIIlllIllIlIlllIl) {
            return;
        }
        for (CBSetting cBSetting : this.module.getSettingsList()) {
            if (cBSetting.getType() != SettingType.INTEGER || !cBSetting.getLabel().toLowerCase().contains("color") || cBSetting.getLabel().toLowerCase().contains("background") || cBSetting.getLabel().toLowerCase().contains("pressed")) continue;
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            cBSetting.setValue(CBClient.getInstance().getGlobalSettings().defaultColor.getValue());
        }
    }
}
