package com.cheatbreaker.client.ui.element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.config.SettingType;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.CBStaffModule;
import com.cheatbreaker.client.ui.*;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class ModuleListElement extends ScrollableElement {
    private final int lllIIIIIlIllIlIIIllllllII;
    protected final List<ModuleSettingsElement> lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIllllIIIIlIlIIIIlIlI;
    private final GlobalSettingsElement IIIIIIlIlIlIllllllIlllIlI;
    public ScrollableElement IIIlllIIIllIllIlIIIIIIlII;
    public boolean llIlIIIlIIIIlIlllIlIIIIll = false;
    public CBModule IIIlIIllllIIllllllIlIIIll;
    private final ButtonElement backButton;
    private final ButtonElement applyToAllTextButton;
    private final Map<CBModule, List<AbstractElement>> lIIlIIllIIIIIlIllIIIIllII;
    private final List<AbstractElement> lIIlllIIlIlllllllllIIIIIl;

    public ModuleListElement(List<CBModule> list, float f, int n, int n2, int n3, int n4) {
        super(f, n, n2, n3, n4);
        this.lIIIIIllllIIIIlIlIIIIlIlI = list == CBClient.getInstance().getModuleManager().staffModules;
        this.lllIIIIIlIllIlIIIllllllII = -12418828;
        this.IIIIIIlIlIlIllllllIlllIlI = new GlobalSettingsElement(this, this.lllIIIIIlIllIlIIIllllllII, f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList<>();
        for (Object object : list) {
            if (((CBModule)object).isStaffModule() && !((CBModule)object).isStaffEnabledModule()) continue;
            this.lIIIIlIIllIIlIIlIIIlIIllI.add(new ModuleSettingsElement(this, this.lllIIIIIlIllIlIIIllllllII, (CBModule)object, f));
        }
        this.backButton = new ButtonElement(null, "arrow-64.png", this.x + 2, this.y + 4, 28, 28, -12418828, f);
        this.IIIlIIllllIIllllllIlIIIll = null;
        this.lIIlIIllIIIIIlIllIIIIllII = new HashMap<>();
        for (CBModule object : list) {
            if (object.isStaffModule() && !object.isStaffEnabledModule() || object == CBClient.getInstance().getModuleManager().minmap) continue;
            ArrayList<AbstractElement> object2 = new ArrayList<>();
            for (CBSetting cBSetting : object.getSettingsList()) {
                switch (cBSetting.getType()) {
                    case BOOLEAN: {
                        object2.add(new ToggleElement(cBSetting, f));
                        break;
                    }
                    case DOUBLE:
                    case INTEGER:
                    case FLOAT: {
                        if (object.isStaffModule() && cBSetting == ((CBStaffModule)object).lIIIIlIIllIIlIIlIIIlIIllI() || object.isStaffModule() && cBSetting == object.scale) break;
                        if (cBSetting.getType().equals(SettingType.INTEGER) && cBSetting.getLabel().toLowerCase().contains("color")) {
                            object2.add(new ColorPickerElement(cBSetting, f));
                            break;
                        }
                        object2.add(new SliderElement(cBSetting, f));
                        break;
                    }
                    case STRING_ARRAY: {
                        object2.add(new ChoiceElement(cBSetting, f));
                        break;
                    }
                    case STRING: {
                        if (!cBSetting.getLabel().equalsIgnoreCase("label")) break;
                        object2.add(new LabelElement(cBSetting, f));
                    }
                }
            }
            if (object.isStaffModule()) {
                object2.add(new KeybindElement(((CBStaffModule)object).lIIIIlIIllIIlIIlIIIlIIllI(), f));
                if (object == CBClient.getInstance().getModuleManager().xray) {
                    object2.add(new XRayOptionsElement(CBClient.getInstance().getModuleManager().xray.lIllIllIlIIllIllIlIlIIlIl(), "Blocks", f));
                }
            }
            this.lIIlIIllIIIIIlIllIIIIllII.put(object, object2);
        }
        this.lIIlllIIlIlllllllllIIIIIl = new ArrayList();
        for (CBSetting object : CBClient.getInstance().getGlobalSettings().settingsList) {
            switch (object.getType()) {
                case BOOLEAN: {
                    if (object == CBClient.getInstance().getGlobalSettings().clearGlass) continue;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new ToggleElement(object, f));
                    break;
                }
                case DOUBLE:
                case INTEGER:
                case FLOAT: {
                    if (object.getType().equals(SettingType.INTEGER) && object.getLabel().toLowerCase().contains("color")) {
                        this.lIIlllIIlIlllllllllIIIIIl.add(new ColorPickerElement((CBSetting)object, f));
                        break;
                    }
                    if (object.getLabel().equals("World Time")) {
                        this.lIIlllIIlIlllllllllIIIIIl.add(new WorldTimeElement((CBSetting)object, f));
                        break;
                    }
                    this.lIIlllIIlIlllllllllIIIIIl.add(new SliderElement((CBSetting)object, f));
                    break;
                }
                case STRING_ARRAY: {
                    if (object == CBClient.getInstance().getGlobalSettings().clearGlass) continue;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new ChoiceElement((CBSetting)object, f));
                    break;
                }
                case STRING: {
                    if (!object.getLabel().equalsIgnoreCase("label")) break;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new LabelElement(object, f));
                    if (!CBClient.getInstance().getGlobalSettings().IIIIllIlIIIllIlllIlllllIl().getValue().equals(object.getValue())) break;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new CrosshairElement(f));
                }
            }
        }
        int n5 = 25;
        for (Object object2 : this.lIIlllIIlIlllllllllIIIIIl) {
            n5 += ((AbstractElement)object2).getHeight();
        }
        this.applyToAllTextButton = new ButtonElement(CBClient.getInstance().playBold18px, null, "Apply to all text", this.x + n3 - 120, this.y + n5 + 4, 110, 28, -12418828, f);
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.x, this.y, this.x + this.width, this.y + this.height + 2, (double)8, -657931);
        this.preDraw(mouseX, mouseY);
        if (this.IIIlIIllllIIllllllIlIIIll == null && !this.llIlIIIlIIIIlIlllIlIIIIll) {
            this.IlllIllIlIIIIlIIlIIllIIIl = 52;
            if (!this.lIIIIIllllIIIIlIlIIIIlIlI) {
                this.IIIIIIlIlIlIllllllIlllIlI.setPositionsAndDimensions(this.x + 4, this.y + 4, this.width - 12, 18);
                this.IIIIIIlIlIlIllllllIlllIlI.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
                this.IIIIIIlIlIlIllllllIlllIlI.draw(mouseX, mouseY, partialTicks);
            }
            for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                ModuleSettingsElement moduleSettingsElement = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
                moduleSettingsElement.setPositionsAndDimensions(this.x + 4, this.y + (this.lIIIIIllllIIIIlIlIIIIlIlI ? 4 : 24) + i * 20, this.width - 12, 18);
                moduleSettingsElement.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
                moduleSettingsElement.draw(mouseX, mouseY, partialTicks);
                this.IlllIllIlIIIIlIIlIIllIIIl += moduleSettingsElement.getHeight();
            }
        } else if (this.llIlIIIlIIIIlIlllIlIIIIll && !this.lIIIIIllllIIIIlIlIIIIlIlI) {
            Gui.drawRect(this.x + 32, this.y + 4, this.x + 33, this.y + this.height - 4, 0x2F2F2F2F);
            this.IlllIllIlIIIIlIIlIIllIIIl = 25;
            this.backButton.setPositionsAndDimensions(this.x + 2, this.y + 2, 28, 28);
            this.backButton.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.backButton.draw(mouseX, mouseY, partialTicks);
            CBClient.getInstance().ubuntuMedium16px.drawString("CheatBreaker Settings".toUpperCase(), this.x + 38, (float)(this.y + 9), -1358954496);
            Gui.drawRect(this.x + 38, this.y + 17, this.x + this.width - 6, this.y + 18, 0x2F2F2F2F);
            int n3 = 0;
            for (AbstractElement abstractElement : this.lIIlllIIlIlllllllllIIIIIl) {
                abstractElement.setPositionsAndDimensions(this.x + 38, this.y + 22 + n3, this.width - 40, abstractElement.getHeight());
                abstractElement.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
                abstractElement.draw(mouseX, mouseY, partialTicks);
                n3 += 2 + abstractElement.getHeight();
                this.IlllIllIlIIIIlIIlIIllIIIl += 2 + abstractElement.getHeight();
            }
            this.applyToAllTextButton.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.applyToAllTextButton.setPositionsAndDimensions(this.x + this.width - 118, this.y + this.IlllIllIlIIIIlIIlIIllIIIl, 100, 20);
            this.applyToAllTextButton.draw(mouseX, mouseY, partialTicks);
            this.IlllIllIlIIIIlIIlIIllIIIl += 24;
        } else {
            Gui.drawRect(this.x + 32, this.y + 4, this.x + 33, this.y + (Math.max(this.height, this.IlllIllIlIIIIlIIlIIllIIIl)) - 4, 0x2F2F2F2F);
            this.IlllIllIlIIIIlIIlIIllIIIl = 37;
            this.backButton.setPositionsAndDimensions(this.x + 2, this.y + 2, 28, 28);
            this.backButton.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.backButton.draw(mouseX, mouseY, partialTicks);
            CBClient.getInstance().ubuntuMedium16px.drawString((this.IIIlIIllllIIllllllIlIIIll.getName() + " Settings").toUpperCase(), this.x + 38, (float)(this.y + 9), -1358954496);
            Gui.drawRect(this.x + 38, this.y + 17, this.x + this.width - 12, this.y + 18, 0x2F2F2F2F);
            if (this.IIIlIIllllIIllllllIlIIIll == CBClient.getInstance().getModuleManager().minmap) {
                try {
                    String string = Keyboard.getKeyName(CBClient.getInstance().getModuleManager().minmap.getVoxelMap().getMapOptions().keyBindMenu.getKeyCode());
                    CBClient.getInstance().ubuntuMedium16px.drawString(("PRESS '" + string + "' INGAME FOR ZAN'S MINIMAP OPTIONS.").toUpperCase(), this.x + 38, (float)(this.y + 22), -1895825408);
                }
                catch (Exception exception) {
                    CBClient.getInstance().ubuntuMedium16px.drawString("PRESS 'M' INGAME FOR ZAN'S MINIMAP OPTIONS.".toUpperCase(), this.x + 38, (float)(this.y + 22), -1895825408);
                }
                this.postDraw(mouseX, mouseY);
                return;
            }
            if (this.IIIlIIllllIIllllllIlIIIll.getSettingsList().isEmpty()) {
                CBClient.getInstance().ubuntuMedium16px.drawString((this.IIIlIIllllIIllllllIlIIIll.getName().toUpperCase() + " DOES NOT HAVE ANY OPTIONS.").toUpperCase(), this.x + 38, (float)(this.y + 22), -1895825408);
            }
            int n4 = 0;
            for (AbstractElement abstractElement : this.lIIlIIllIIIIIlIllIIIIllII.get(this.IIIlIIllllIIllllllIlIIIll)) {
                abstractElement.setPositionsAndDimensions(this.x + 38, this.y + 22 + n4, this.width - 40, abstractElement.getHeight());
                abstractElement.yOffset = this.lIIIIllIIlIlIllIIIlIllIlI;
                abstractElement.draw(mouseX, mouseY, partialTicks);
                n4 += 2 + abstractElement.getHeight();
                this.IlllIllIlIIIIlIIlIIllIIIl += 2 + abstractElement.getHeight();
            }
        }
        this.postDraw(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        block13: {
            block14: {
                block12: {
                    if (this.IIIlIIllllIIllllllIlIIIll != null || this.llIlIIIlIIIIlIlllIlIIIIll) break block12;
                    if (this.IIIIIIlIlIlIllllllIlllIlI.isMouseInside(mouseX, mouseY) && !this.lIIIIIllllIIIIlIlIIIIlIlI) {
                        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                        this.llIlIIIlIIIIlIlllIlIIIIll = true;
                        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
                        this.IllIIIIIIIlIlIllllIIllIII = 0.0;
                        this.yOffset = 0;
                    } else {
                        for (ModuleSettingsElement moduleSettingsElement : this.lIIIIlIIllIIlIIlIIIlIIllI) {
                            if (!moduleSettingsElement.isMouseInside(mouseX, mouseY) || !this.lIIIIlIIllIIlIIlIIIlIIllI(moduleSettingsElement.module)) continue;
                            moduleSettingsElement.mouseClicked(mouseX, mouseY, button);
                        }
                    }
                    break block13;
                }
                if (!this.backButton.isMouseInside(mouseX, mouseY)) break block14;
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.IIIlIIllllIIllllllIlIIIll = null;
                this.llIlIIIlIIIIlIlllIlIIIIll = false;
                if (this.IIIlllIIIllIllIlIIIIIIlII == null) break block13;
                CBModulesGui.instance.currentScrollableElement = this.IIIlllIIIllIllIlIIIIIIlII;
                break block13;
            }
            if (this.IIIlIIllllIIllllllIlIIIll != null) {
                for (AbstractElement abstractElement : this.lIIlIIllIIIIIlIllIIIIllII.get(this.IIIlIIllllIIllllllIlIIIll)) {
                    if (!abstractElement.isMouseInside(mouseX, mouseY)) continue;
                    abstractElement.mouseClicked(mouseX, mouseY, button);
                }
            } else if (this.llIlIIIlIIIIlIlllIlIIIIll) {
                if (this.applyToAllTextButton.isMouseInside(mouseX, mouseY)) {
                    for (CBModule cBModule : CBClient.getInstance().getModuleManager().modules) {
                        for (CBSetting cBSetting : cBModule.getSettingsList()) {
                            if (cBSetting.getType() != SettingType.INTEGER || !cBSetting.getLabel().toLowerCase().contains("color") || cBSetting.getLabel().toLowerCase().contains("background")) continue;
                            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                            cBSetting.setValue(CBClient.getInstance().getGlobalSettings().defaultColor.getValue());
                        }
                    }
                } else {
                    for (AbstractElement abstractElement : this.lIIlllIIlIlllllllllIIIIIl) {
                        if (!abstractElement.isMouseInside(mouseX, mouseY)) continue;
                        abstractElement.mouseClicked(mouseX, mouseY, button);
                    }
                }
            }
        }
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule) {
        return !cBModule.getSettingsList().isEmpty() || cBModule.getName().contains("Zans");
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
        this.IllIIIIIIIlIlIllllIIllIII = 0.0;
        this.yOffset = 0;
        this.IIIlIIllllIIllllllIlIIIll = cBModule;
        this.IIIlllIIIllIllIlIIIIIIlII = null;
    }
}
