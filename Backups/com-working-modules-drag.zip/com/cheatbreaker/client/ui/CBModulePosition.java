package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.module.CBModule;

public class CBModulePosition {

    protected CBModule module;
    protected float x;
    protected float y;

    CBModulePosition(CBModule cBModule, float x, float y) {
        this.module = cBModule;
        this.x = x;
        this.y = y;
    }

}
