package com.cheatbreaker.client.util;

/**
 * Represents a getter for the {@link T} type which doesn't need to be used immediately.
 * @param <T> the type of the object.
 */
public abstract class LazyLoadBase<T> {

    protected T cache;

    /**
     * Returns the object from memory.
     * If the object is null, it will load it using {@link this#load()}.
     * @return the {@link T} object from memory.
     */
    public T get() {
        if (cache == null) load();
        return cache;
    }

    /**
     * Loads the object into memory.
     * Sets {@link this#cache} to the object.
     */
    protected abstract void load();

    /**
     * Unloads the object from memory.
     * Requires {@link this#load()} to be called again.
     */
    public void unload() {
        cache = null;
    }

}
