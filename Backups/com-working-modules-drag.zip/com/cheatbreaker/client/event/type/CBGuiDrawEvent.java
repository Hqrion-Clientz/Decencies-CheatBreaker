package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;
import net.minecraft.client.gui.ScaledResolution;

public class CBGuiDrawEvent extends CBEvent {

    private final ScaledResolution resolution;

    public CBGuiDrawEvent(ScaledResolution resolution) {
        this.resolution = resolution;
    }

    public ScaledResolution getResolution() {
        return resolution;
    }
}
