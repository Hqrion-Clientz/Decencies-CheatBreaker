package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;

public class CBKeyboardEvent extends CBEvent {

    private final int keyboardKey;

    public CBKeyboardEvent(int keyboardKey) {
        this.keyboardKey = keyboardKey;
    }

    public int getKeyboardKey() {
        return keyboardKey;
    }

}
