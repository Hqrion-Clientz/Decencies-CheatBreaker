package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.CBEvent;

public class CBClickEvent extends CBEvent {

    private final int mouseButton;

    public CBClickEvent(int mouseButton) {
        this.mouseButton = mouseButton;
    }

    public int getMouseButton() {
        return mouseButton;
    }
}
