package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class ArmourStatusModule extends CBModule {
    private CBSetting generalOptionsLabel;
    public static CBSetting listMode;
    public static CBSetting itemName;
    public static CBSetting itemCount;
    public static CBSetting showWhileTying;
    public static CBSetting equippedItem;
    private CBSetting damageOptionsLabel;
    public static CBSetting damageOverlay;
    public static CBSetting showItemDamage;
    public static CBSetting showArmourDamage;
    public static CBSetting showMaxDamage;
    private CBSetting damageDisplay;
    public static CBSetting damageDisplayType;
    public static CBSetting damageThreshold;
    public static RenderItem previewType;
    public static final List previewIconLocation;
    private static List<IIllIlIIIIllIIlIlllIlIIII> previewLabel;
    private static ScaledResolution lIIIIIllllIIIIlIlIIIIlIlI;

    public ArmourStatusModule() {
        super("Armor Status");
        this.setDefaultAnchor(CBGuiAnchor.RIGHT_BOTTOM);
        this.setDefaultState(false);
        this.generalOptionsLabel = new CBSetting(this, "label").setValue("General Options");
        listMode = new CBSetting(this, "List Mode").setValue("vertical").acceptedValues("vertical", "horizontal");
        itemName = new CBSetting(this, "Item Name").setValue(false);
        itemCount = new CBSetting(this, "Item Count").setValue(true);
        equippedItem = new CBSetting(this, "Equipped Item").setValue(true);
        showWhileTying = new CBSetting(this, "Show While Typing").setValue(false);
        this.damageOptionsLabel = new CBSetting(this, "label").setValue("Damage Options");
        damageOverlay = new CBSetting(this, "Damage Overlay").setValue(true);
        showItemDamage = new CBSetting(this, "Show Item Damage").setValue(true);
        showArmourDamage = new CBSetting(this, "Show Armor Damage").setValue(true);
        showMaxDamage = new CBSetting(this, "Show Max Damage").setValue(false);
        this.damageDisplay = new CBSetting(this, "label").setValue("Damage Display");
        damageDisplayType = new CBSetting(this, "Damage Display Type").setValue("value").acceptedValues("value", "percent", "none");
        damageThreshold = new CBSetting(this, "Damage Threshold Type").setValue("percent").acceptedValues("percent", "value");
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(10, "4"));
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(25, "c"));
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(40, "6"));
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(60, "e"));
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(80, "7"));
        previewIconLocation.add(new IlllIlllIlIIIIllIlllIlIII(100, "f"));
        this.setPreviewIcon(new ResourceLocation("client/icons/mods/diamond_chestplate.png"), 34, 34);
        this.addEvent(CBGuiDrawEvent.class, this::renderReal);
        this.addEvent(CBGuiDrawEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
    }

    private void renderReal(CBGuiDrawEvent lIllIlIlllIIlIIllIIlIIlII2) {
        if (!this.isRenderHud()) {
            return;
        }
        ArrayList<IIllIlIIIIllIIlIlllIlIIII> arrayList = new ArrayList<IIllIlIIIIllIIlIlllIlIIII>();
        for (int i = 3; i >= 0; --i) {
            ItemStack lIlIlIlIlIllllIlllIIIlIlI2 = this.minecraft.thePlayer.inventory.armorInventory[i];
            if (lIlIlIlIlIllllIlllIIIlIlI2 == null) continue;
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(lIlIlIlIlIllllIlllIIIlIlI2, 16, 16, 2, i > -1));
        }
        if (arrayList.isEmpty()) {
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(new ItemStack(Item.getItemById(310)), 16, 16, 2, true));
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(new ItemStack(Item.getItemById(311)), 16, 16, 2, true));
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(new ItemStack(Item.getItemById(312)), 16, 16, 2, true));
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(new ItemStack(Item.getItemById(313)), 16, 16, 2, true));
        }
        if ((Boolean) equippedItem.getValue() && this.minecraft.thePlayer.getCurrentEquippedItem() != null) {
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(this.minecraft.thePlayer.getCurrentEquippedItem(), 16, 16, 2, false));
        } else if ((Boolean) equippedItem.getValue()) {
            arrayList.add(new IIllIlIIIIllIIlIlllIlIIII(new ItemStack(Item.getItemById(276)), 16, 16, 2, false));
        }
        GL11.glPushMatrix();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        lIIIIIllllIIIIlIlIIIIlIlI = lIllIlIlllIIlIIllIIlIIlII2.getResolution();
        this.scaleAndTranslate(lIIIIIllllIIIIlIlIIIIlIlI);
        this.lIIIIlIIllIIlIIlIIIlIIllI(this.minecraft, arrayList);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(CBGuiDrawEvent lIllIllIlIIllIllIlIlIIlIl2) {
        if (!this.isRenderHud()) {
            return;
        }
        if (!(this.minecraft.currentScreen instanceof CBModulesGui || this.minecraft.currentScreen instanceof IIIlllllIIlIlIIIllllllIII || this.minecraft.currentScreen instanceof GuiChat && !(Boolean) showWhileTying.getValue())) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.minecraft);
            if (!previewLabel.isEmpty()) {
                GL11.glPushMatrix();
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                lIIIIIllllIIIIlIlIIIIlIlI = lIllIllIlIIllIllIlIlIIlIl2.getResolution();
                this.scaleAndTranslate(lIIIIIllllIIIIlIlIIIIlIlI);
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.minecraft, previewLabel);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(Minecraft minecraft) {
        previewLabel.clear();
        for (int i = 3; i >= -1; --i) {
            ItemStack lIlIlIlIlIllllIlllIIIlIlI2 = null;
            if (i == -1 && (Boolean) equippedItem.getValue()) {
                lIlIlIlIlIllllIlllIIIlIlI2 = minecraft.thePlayer.getCurrentEquippedItem();
            } else if (i != -1) {
                lIlIlIlIlIllllIlllIIIlIlI2 = minecraft.thePlayer.inventory.mainInventory[i];
            }
            if (lIlIlIlIlIllllIlllIIIlIlI2 == null) continue;
            previewLabel.add(new IIllIlIIIIllIIlIlllIlIIII(lIlIlIlIlIllllIlllIIIlIlI2, 16, 16, 2, i > -1));
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(Minecraft minecraft, List<IIllIlIIIIllIIlIlllIlIIII> list) {
        if (list.size() > 0) {
            int n = (Boolean) itemName.getValue() ? 18 : 16;
            if (((String) listMode.getValue()).equalsIgnoreCase("vertical")) {
                int n3 = 0;
                int n4 = 0;
                boolean bl = CBAnchorHelper.getHorizontalPositionEnum(this.getGuiAnchor()) == CBPositionEnum.RIGHT;
                for (IIllIlIIIIllIIlIlllIlIIII iIllIlIIIIllIIlIlllIlIIII : list) {
                    iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(bl ? this.width : 0.0f, n3);
                    n3 += n;
                    if (iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI() <= n4) continue;
                    n4 = iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI();
                }
                this.height = n3;
                this.width = n4;
            } else if (((String) listMode.getValue()).equalsIgnoreCase("horizontal")) {
                boolean bl = false;
                int n5 = 0;
                int n6 = 0;
                boolean bl2 = CBAnchorHelper.getHorizontalPositionEnum(this.getGuiAnchor()) == CBPositionEnum.RIGHT;
                for (IIllIlIIIIllIIlIlllIlIIII iIllIlIIIIllIIlIlllIlIIII : list) {
                    if (bl2) {
                        n5 += iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI();
                    }
                    iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI(n5, bl2 ? this.height : 0.0f);
                    if (!bl2) {
                        n5 += iIllIlIIIIllIIlIlllIlIIII.lIIIIlIIllIIlIIlIIIlIIllI();
                    }
                    if (iIllIlIIIIllIIlIlllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl() <= n6) continue;
                    n6 += iIllIlIIIIllIIlIlllIlIIII.lIIIIIIIIIlIllIIllIlIIlIl();
                }
                this.height = n6;
                this.width = n5;
            }
        }
    }

    static {
        previewType = new RenderItem();
        previewIconLocation = new ArrayList();
        previewLabel = new ArrayList();
    }

}
