package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.llIllllIIIIIlIllIlIIIllIl;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import com.thevoxelbox.voxelmap.VoxelMap;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class MiniMapModule extends CBModule {

    private VoxelMap staffModuleEnabled;
    public static llIllllIIIIIlIllIlIIIllIl staffModule = llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI;

    public VoxelMap lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.staffModuleEnabled;
    }

    public MiniMapModule() {
        super("Zans Minimap");
        this.setDefaultState(false);
        this.alwaysTrue = false;
        this.setDefaultAnchor(CBGuiAnchor.RIGHT_TOP);
        this.staffModuleEnabled = new VoxelMap(true, true);
        this.setPreviewIcon(new ResourceLocation("client/icons/mods/zans.png"), 42, 42);
        this.addEvent(CBGuiDrawEvent.class, this::onDraw);
    }

    @Override
    public void addAllEvents() {
        super.addAllEvents();
        if (staffModule == llIllllIIIIIlIllIlIIIllIl.IlllIIIlIlllIllIlIIlllIlI) {
            //CheatBreaker.getInstance().IIIIllIIllIIIIllIllIIIlIl().IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("Error", "&4Minimap &fis not allowed on this server. Some functions may not work.", 4000L);
        }
    }

    private void onDraw(CBGuiDrawEvent lIllIllIlIIllIllIlIlIIlIl2) {
        float f = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        switch (this.staffModuleEnabled.getMapOptions().sizeModifier) {
            case 0: {
                if (this.getGuiAnchor() == CBGuiAnchor.LEFT_TOP) break;
                this.setAnchor(CBGuiAnchor.LEFT_TOP);
                break;
            }
            case 1: {
                if (this.getGuiAnchor() == CBGuiAnchor.RIGHT_TOP) break;
                this.setAnchor(CBGuiAnchor.RIGHT_TOP);
                break;
            }
            case 2: {
                if (this.getGuiAnchor() == CBGuiAnchor.RIGHT_BOTTOM) break;
                this.setAnchor(CBGuiAnchor.RIGHT_BOTTOM);
                break;
            }
            case 3: {
                if (this.getGuiAnchor() == CBGuiAnchor.LEFT_BOTTOM) break;
                this.setAnchor(CBGuiAnchor.LEFT_BOTTOM);
            }
        }
        switch (this.staffModuleEnabled.getMapOptions().mapCorner) {
            case -1: {
                this.setTranslations((int)((float)-5 * f), (int)((float)5 * f));
                this.setDimensions((int)((float)100 * f), (int)((float)100 * f));
                break;
            }
            case 0: {
                this.setTranslations((int)((float)-5 * f), (int)((float)5 * f));
                this.setDimensions((int)((float)135 * f), (int)((float)135 * f));
                break;
            }
            case 1: {
                this.setTranslations((int)((float)-5 * f), (int)((float)5 * f));
                this.setDimensions((int)((float)175 * f), (int)((float)175 * f));
            }
        }
        this.staffModuleEnabled.onTickInGame(Minecraft.getMinecraft());
    }



}
