package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.event.type.CBKeepAliveEvent;
import com.cheatbreaker.client.event.type.CBTickEvent;
import com.cheatbreaker.client.module.CBModule;
import net.minecraft.client.gui.ScaledResolution;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class CBNotificationsModule extends CBModule
{
    public long staffModule;
    private List<Notification> notifications;

    public CBNotificationsModule() {
        super("Notifications");
        this.staffModule = System.currentTimeMillis();
        this.notifications = new ArrayList<>();
        this.addEvent(CBKeepAliveEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
        this.addEvent(CBTickEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
        this.addEvent(CBGuiDrawEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
        this.setDefaultState(true);
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(final CBKeepAliveEvent illIllIIIlIIlllIIIllIllII) {
        this.staffModule = System.currentTimeMillis();
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(final CBTickEvent cbTickEvent) {
        final Iterator<Notification> iterator = this.notifications.iterator();
        while (iterator.hasNext()) {
            final Notification illlIlIlllIlIlllIIlllIlIl = iterator.next();
            illlIlIlllIlIlllIIlllIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            if (illlIlIlllIlIlllIIlllIlIl.IIIIllIlIIIllIlllIlllllIl + illlIlIlllIlIlllIIlllIlIl.IlllIIIlIlllIllIlIIlllIlI - System.currentTimeMillis() <= 0L) {
                int ilIlIIIlllIIIlIlllIlIllIl = illlIlIlllIlIlllIIlllIlIl.IIIIllIIllIIIIllIllIIIlIl;
                for (final Notification illlIlIlllIlIlllIIlllIlIl2 : this.notifications) {
                    if (illlIlIlllIlIlllIIlllIlIl2.IIIIllIIllIIIIllIllIIIlIl < illlIlIlllIlIlllIIlllIlIl.IIIIllIIllIIIIllIllIIIlIl) {
                        illlIlIlllIlIlllIIlllIlIl2.IllIIIIIIIlIlIllllIIllIII = 0;
                        illlIlIlllIlIlllIIlllIlIl2.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
                        ilIlIIIlllIIIlIlllIlIllIl = illlIlIlllIlIlllIIlllIlIl2.IIIIllIIllIIIIllIllIIIlIl;
                    }
                }
                iterator.remove();
            }
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(final CBGuiDrawEvent lIllIllIlIIllIllIlIlIIlIl) {
        for (Notification notification : this.notifications) {
            notification.lIIIIlIIllIIlIIlIIIlIIllI(lIllIllIlIIllIllIlIlIIlIl.getResolution().getScaledWidth());
        }
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(final String s, String replaceAll, long n) {
        final ScaledResolution scaledResolution = new ScaledResolution(this.minecraft, this.minecraft.displayWidth, this.minecraft.displayHeight);
        if (n < 2000L) {
            n = 2000L;
        }
        replaceAll = replaceAll.replaceAll("&([abcdefghijklmrABCDEFGHIJKLMNR0-9])|(&$)", "§$1");
        final String lowerCase = s.toLowerCase();
        IIlllllllIllIlIllIIIlllIl illlllllIllIlIllIIIlllIl = null;
        switch (lowerCase) {
            case "info": {
                illlllllIllIlIllIIIlllIl = IIlllllllIllIlIllIIIlllIl.lIIIIlIIllIIlIIlIIIlIIllI;
                break;
            }
            case "error": {
                illlllllIllIlIllIIIlllIl = IIlllllllIllIlIllIIIlllIl.lIIIIIIIIIlIllIIllIlIIlIl;
                break;
            }
            default: {
                illlllllIllIlIllIIIlllIl = IIlllllllIllIlIllIIIlllIl.IlllIIIlIlllIllIlIIlllIlI;
                break;
            }
        }
        final Notification illlIlIlllIlIlllIIlllIlIl = new Notification(this, scaledResolution, illlllllIllIlIllIIIlllIl, replaceAll, n);
        int ilIlIIIlllIIIlIlllIlIllIl = illlIlIlllIlIlllIIlllIlIl.IlIlIIIlllIIIlIlllIlIllIl - illlIlIlllIlIlllIIlllIlIl.IIIllIllIlIlllllllIlIlIII - 2;
        for (int i = this.notifications.size() - 1; i >= 0; --i) {
            final Notification illlIlIlllIlIlllIIlllIlIl2 = this.notifications.get(i);
            illlIlIlllIlIlllIIlllIlIl2.IllIIIIIIIlIlIllllIIllIII = 0;
            illlIlIlllIlIlllIIlllIlIl2.IlIlIIIlllIIIlIlllIlIllIl = ilIlIIIlllIIIlIlllIlIllIl;
            ilIlIIIlllIIIlIlllIlIllIl -= 2 + illlIlIlllIlIlllIIlllIlIl2.IIIllIllIlIlllllllIlIlIII;
        }
        this.notifications.add(illlIlIlllIlIlllIIlllIlIl);
    }
}
