package com.cheatbreaker.client.module.type;

import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.event.type.CBTickEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import com.cheatbreaker.client.ui.CBPositionEnum;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.util.Collection;
import java.util.HashMap;

public class PotionStatusModule extends CBModule {

    private final CBSetting showWhileTying;
    private final CBSetting showEffectName;
    public final CBSetting showInInventory;
    private final CBSetting colorOptionsLabel;
    private final CBSetting nameColor;
    private final CBSetting durationColor;
    private final CBSetting blink;
    private final CBSetting blinkDuration;
    private final ResourceLocation location = new ResourceLocation("textures/gui/container/inventory.png");
    private int ticks = 0;

    public PotionStatusModule() {
        super("Potion Effects");
        this.setDefaultState(false);
        this.setDefaultAnchor(CBGuiAnchor.LEFT_MIDDLE);

        new CBSetting(this, "label").setValue("General Options");
        {
            this.showWhileTying = new CBSetting(this, "Show While Typing").setValue(true);
            this.showEffectName = new CBSetting(this, "Effect Name").setValue(true);
            this.showInInventory = new CBSetting(this, "Show Potion info in inventory").setValue(false);
        }
        new CBSetting(this, "label").setValue("Blink Options");
        {
            this.blink = new CBSetting(this, "Blink").setValue(true);
            this.blinkDuration = new CBSetting(this, "Blink Duration").setValue(10).setMinMax(2, 20);
            this.colorOptionsLabel = new CBSetting(this, "label").setValue("Color Options");
            this.nameColor = new CBSetting(this, "Name Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
            this.durationColor = new CBSetting(this, "Duration Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        }

        this.setPreviewIcon(new ResourceLocation("client/icons/mods/speed_icon.png"), 28, 28);

        this.addEvent(CBTickEvent.class, this::onTick);
        this.addEvent(CBGuiDrawEvent.class, this::onDraw);
        //this.addEvent(CBGuiDrawEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
    }

    private void onTick(CBTickEvent cBTickEvent) {
        ++this.ticks;
    }

    private void onDraw(CBGuiDrawEvent drawEvent) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        Collection<PotionEffect> collection = this.minecraft.thePlayer.getActivePotionEffects();
        if (collection.isEmpty()) {
            GL11.glPushMatrix();
            this.scaleAndTranslate(drawEvent.getResolution());
            HashMap<Integer, PotionEffect> hashMap = new HashMap<>();
            PotionEffect fireResistance = new PotionEffect(Potion.fireResistance.id, 1200, 3);
            PotionEffect speed = new PotionEffect(Potion.moveSpeed.id, 30, 3);
            hashMap.put(fireResistance.getPotionID(), fireResistance);
            hashMap.put(speed.getPotionID(), speed);
            collection = hashMap.values();
            CBPositionEnum position = this.getPosition();
            int n = 0;
            int n2 = 0;
            int n3 = 22;
            for (PotionEffect potionEffect : collection) {
                Potion potion;
                String string;
                boolean shouldBlink = this.shouldBlink(potionEffect.getDuration());
                int n4 = 0;
                if ((Boolean) this.showEffectName.getValue()) {
                    string = I18n.format(potionEffect.getEffectName()) + this.lIIIIlIIllIIlIIlIIIlIIllI(potionEffect.getAmplifier());
                    n4 = this.minecraft.fontRenderer.getStringWidth(string) + 20;
                    if (position == CBPositionEnum.RIGHT) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r",  (int) width - n4, n, this.nameColor.getColorValue());
                    } else if (position == CBPositionEnum.LEFT) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", 20, n, this.nameColor.getColorValue());
                    } else if (position == CBPositionEnum.CENTER) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", (int) width / 2 - (n4 / 2) + 20, n, this.nameColor.getColorValue());
                    }
                    if (n4 > n2) {
                        n2 = n4;
                    }
                }
                string = Potion.getDurationString(potionEffect);
                int n5 = this.minecraft.fontRenderer.getStringWidth(string) + 20;
                if (shouldBlink) {
                    if (position == CBPositionEnum.RIGHT) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", (int) width - n5, n + ((Boolean) this.showEffectName.getValue() ? 10 : 5), this.durationColor.getColorValue());
                    } else if (position == CBPositionEnum.LEFT) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", 20, n + ((Boolean) this.showEffectName.getValue() ? 10 : 5), this.durationColor.getColorValue());
                    } else if (position == CBPositionEnum.CENTER) {
                        this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", (int) width / 2 - (n5 / 2) + 20, n + ((Boolean) this.showEffectName.getValue() ? 10 : 5), this.durationColor.getColorValue());
                    }
                }
                if ((potion = Potion.potionTypes[potionEffect.getPotionID()]).hasStatusIcon()) {
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    this.minecraft.getTextureManager().bindTexture(this.location);
                    int n6 = potion.getStatusIconIndex();
                    if (position == CBPositionEnum.RIGHT) {
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(width - (float)20, (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
                    } else if (position == CBPositionEnum.LEFT) {
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
                    } else if (position == CBPositionEnum.CENTER) {
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(width / 2.0f - (float)(n4 / 2), (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
                    }
                }
                if (n5 > n2) {
                    n2 = n5;
                }
                n += n3;
            }
            this.setDimensions(n2, n);
            GL11.glPopMatrix();
        } else {
//            if ((Boolean) this.showWhileTying.getValue() || !this.minecraft.ingameGUI.getChatGUI().func_146241_e()) {
//                GL11.glPushMatrix();
//                this.scaleAndTranslate(drawEvent.getResolution());
//                llIIIlIIIllllllIllIIlIIll llIIIlIIIllllllIllIIlIIll2 = this.IIIlIIllllIIllllllIlIIIll();
//                int n = 0;
//                int n2 = 0;
//                int n3 = 22;
//                for (PotionEffect llIlIlIIlIlIllllIIlIIIlIl2 : collection) {
//                    IIIlIlIIIIIIIlllllIlIllIl iIIlIlIIIIIIIlllllIlIllIl;
//                    String string;
//                    boolean bl = this.IlllIIIlIlllIllIlIIlllIlI(llIlIlIIlIlIllllIIlIIIlIl2.lIIIIIIIIIlIllIIllIlIIlIl());
//                    int n4 = 0;
//                    if (((Boolean)this.enabled.getValue()).booleanValue()) {
//                        string = IIllIlIlIlIIIIlIllllllIll.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIlIlIllllIIlIIIlIl2.IIIIllIIllIIIIllIllIIIlIl()) + this.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIlIlIllllIIlIIIlIl2.IlllIIIlIlllIllIlIIlllIlI());
//                        n4 = this.minecraft.fontRenderer.getStringWidth(string) + 20;
//                        if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIIllIIIIllIllIIIlIl) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", this.getWidth() - (float)n4, n, (Integer)this.xTranslation.getValue());
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", 20, n, (Integer)this.xTranslation.getValue());
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", this.getWidth() / 2.0f - (float)(n4 / 2) + (float)20, n, (Integer)this.xTranslation.getValue());
//                        }
//                        if (n4 > n2) {
//                            n2 = n4;
//                        }
//                    }
//                    string = IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI(llIlIlIIlIlIllllIIlIIIlIl2);
//                    int n5 = this.minecraft.fontRenderer.getStringWidth(string) + 20;
//                    if (bl) {
//                        if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIIllIIIIllIllIIIlIl) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", this.getWidth() - (float)n5, n + ((Boolean)this.enabled.getValue() != false ? 10 : 5), this.yTranslation.lIIIIlIIllIIlIIlIIIlIIllI());
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", 20, n + ((Boolean)this.enabled.getValue() != false ? 10 : 5), this.yTranslation.lIIIIlIIllIIlIIlIIIlIIllI());
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI) {
//                            this.minecraft.fontRenderer.drawStringWithShadow(string + "§r", this.getWidth() / 2.0f - (float)(n5 / 2) + (float)20, n + ((Boolean)this.enabled.getValue() != false ? 10 : 5), this.yTranslation.lIIIIlIIllIIlIIlIIIlIIllI());
//                        }
//                    }
//                    if ((iIIlIlIIIIIIIlllllIlIllIl = IIIlIlIIIIIIIlllllIlIllIl.lIIIIlIIllIIlIIlIIIlIIllI[llIlIlIIlIlIllllIIlIIIlIl2.lIIIIlIIllIIlIIlIIIlIIllI()]).IIIIllIlIIIllIlllIlllllIl()) {
//                        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
//                        this.minecraft.getTextureManager().bindTexture(this.location);
//                        int n6 = iIIlIlIIIIIIIlllllIlIllIl.IIIIllIIllIIIIllIllIIIlIl();
//                        if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIIllIIIIllIllIIIlIl) {
//                            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.getWidth() - (float)20, (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IIIIllIlIIIllIlllIlllllIl) {
//                            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
//                        } else if (llIIIlIIIllllllIllIIlIIll2 == llIIIlIIIllllllIllIIlIIll.IlllIIIlIlllIllIlIIlllIlI) {
//                            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.getWidth() / 2.0f - (float)(n4 / 2), (float)n, (float)(n6 % 8 * 18), (float)(198 + n6 / 8 * 18), 18, 18);
//                        }
//                    }
//                    if (n5 > n2) {
//                        n2 = n5;
//                    }
//                    n += n3;
//                }
//                this.setDimensions(n2, n);
//                GL11.glPopMatrix();
//            }
        }
        GL11.glPopMatrix();
    }

    private boolean shouldBlink(float f) {
        if ((Boolean) this.blink.getValue() && f <= (float)((Integer)this.blinkDuration.getValue() * 22)) {
            if (this.ticks > 20) {
                this.ticks = 0;
            }
            return this.ticks <= 10;
        }
        return true;
    }

    private String lIIIIlIIllIIlIIlIIIlIIllI(int n) {
        switch (n) {
            case 1: {
                return " II";
            }
            case 2: {
                return " III";
            }
            case 3: {
                return " IV";
            }
            case 4: {
                return " V";
            }
            case 5: {
                return " VI";
            }
            case 6: {
                return " VII";
            }
            case 7: {
                return " VIII";
            }
            case 8: {
                return " IX";
            }
            case 9: {
                return " X";
            }
        }
        if (n > 9) {
            return " " + n + 1;
        }
        return "";
    }

}
