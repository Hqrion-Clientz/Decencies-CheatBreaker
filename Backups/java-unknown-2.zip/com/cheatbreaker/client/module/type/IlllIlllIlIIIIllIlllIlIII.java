package com.cheatbreaker.client.module.type;

import java.util.List;

public class IlllIlllIlIIIIllIlllIlIII
        implements Comparable {
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public String lIIIIIIIIIlIllIIllIlIIlIl;

    public IlllIlllIlIIIIllIlllIlIII(int n, String string) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        this.lIIIIIIIIIlIllIIllIlIIlIl = string;
    }

    public String toString() {
        return String.valueOf(this.lIIIIlIIllIIlIIlIIIlIIllI) + ", " + this.lIIIIIIIIIlIllIIllIlIIlIl;
    }

    public int lIIIIlIIllIIlIIlIIIlIIllI(IlllIlllIlIIIIllIlllIlIII illlIlllIlIIIIllIlllIlIII) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI > illlIlllIlIIIIllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI) {
            return 1;
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI < illlIlllIlIIIIllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI) {
            return -1;
        }
        return 0;
    }

    public static String lIIIIlIIllIIlIIlIIIlIIllI(List<IlllIlllIlIIIIllIlllIlIII> list, int n) {
        for (IlllIlllIlIIIIllIlllIlIII illlIlllIlIIIIllIlllIlIII : list) {
            if (n > illlIlllIlIIIIllIlllIlIII.lIIIIlIIllIIlIIlIIIlIIllI) continue;
            return illlIlllIlIIIIllIlllIlIII.lIIIIIIIIIlIllIIllIlIIlIl;
        }
        return "f";
    }

    public int compareTo(Object object) {
        return this.lIIIIlIIllIIlIIlIIIlIIllI((IlllIlllIlIIIIllIlllIlIII)object);
    }
}
