package com.cheatbreaker.client.module.type.keystrokes;
import java.awt.Color;

import com.cheatbreaker.client.ui.CBModulesGui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.inventory.GuiContainer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class Key {
    private String lIIIIlIIllIIlIIlIIIlIIllI;
    private int keyCode;
    private float IlllIIIlIlllIllIlIIlllIlI;
    private float IIIIllIlIIIllIlllIlllllIl;
    private boolean IIIIllIIllIIIIllIllIIIlIl;
    private long IlIlIIIlllIIIlIlllIlIllIl;
    private Color IIIllIllIlIlllllllIlIlIII;
    private Color IllIIIIIIIlIlIllllIIllIII;

    public Key(String string, int n, float f, float f2) {
        this.lIIIIlIIllIIlIIlIIIlIIllI = string;
        this.keyCode = n;
        this.IlllIIIlIlllIllIlIIlllIlI = f;
        this.IIIIllIlIIIllIlllIlllllIl = f2;
    }

    public void render(float f, float f2, int n, int n2, int n3, int n4) {
        final Minecraft minecraft = Minecraft.getMinecraft();
        final int n7 = (this.keyCode == -99 || this.keyCode == -100) ? ((this.keyCode == -99) ? 0 : 1) : -1;
        final boolean b = (minecraft.currentScreen == null || minecraft.currentScreen instanceof GuiContainer || minecraft.currentScreen instanceof CBModulesGui) && ((n7 != -1) ? Mouse.isButtonDown(n7) : Keyboard.isKeyDown(this.keyCode));
        if (b && !this.IIIIllIIllIIIIllIllIIIlIl) {
            this.IIIIllIIllIIIIllIllIIIlIl = true;
            this.IlIlIIIlllIIIlIlllIlIllIl = System.currentTimeMillis();
            this.IIIllIllIlIlllllllIlIlIII = new Color(n3, true);
            this.IllIIIIIIIlIlIllllIIllIII = new Color(n4, true);
        }
        else if (this.IIIIllIIllIIIIllIllIIIlIl && !b) {
            this.IIIIllIIllIIIIllIllIIIlIl = false;
            this.IlIlIIIlllIIIlIlllIlIllIl = System.currentTimeMillis();
            this.IIIllIllIlIlllllllIlIlIII = new Color(n3, true);
            this.IllIIIIIIIlIlIllllIIllIII = new Color(n4, true);
        }
        final float n8 = 75;
        int rgb;
        if (System.currentTimeMillis() - this.IlIlIIIlllIIIlIlllIlIllIl < n8) {
            final float n9 = (System.currentTimeMillis() - this.IlIlIIIlllIIIlIlllIlIllIl) / n8;
            rgb = new Color((int)Math.abs(n9 * this.IllIIIIIIIlIlIllllIIllIII.getRed() + (1.0f - n9) * this.IIIllIllIlIlllllllIlIlIII.getRed()), (int)Math.abs(n9 * this.IllIIIIIIIlIlIllllIIllIII.getGreen() + (1.0f - n9) * this.IIIllIllIlIlllllllIlIlIII.getGreen()), (int)Math.abs(n9 * this.IllIIIIIIIlIlIllllIIllIII.getBlue() + (1.0f - n9) * this.IIIllIllIlIlllllllIlIlIII.getBlue()), (int)Math.abs(n9 * this.IllIIIIIIIlIlIllllIIllIII.getAlpha() + (1.0f - n9) * this.IIIllIllIlIlllllllIlIlIII.getAlpha())).getRGB();
        }
        else {
            rgb = (b ? n3 : n4);
        }
        Gui.drawRect(n, n2, n + this.IlllIIIlIlllIllIlIIlllIlI, n2 + this.IIIIllIlIIIllIlllIlllllIl, rgb);
        if (this.keyCode == minecraft.gameSettings.keyBindJump.getKeyCode()) {
            Gui.drawRect(n + this.IlllIIIlIlllIllIlIIlllIlI / 2.0f - this.IlllIIIlIlllIllIlIIlllIlI / 8, n2 + 3, n + this.IlllIIIlIlllIllIlIIlllIlI / 2.0f + this.IlllIIIlIlllIllIlIIlllIlI / 8, n2 + 4, 0xFF000000 | (b ? n4 : n3));
        }
        else {
            minecraft.fontRenderer.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI, n + (int) this.IlllIIIlIlllIllIlIIlllIlI / 2, n2 + (int) this.IIIIllIlIIIllIlllIlllllIl / 2 - minecraft.fontRenderer.FONT_HEIGHT / 2 + 1, b ? n4 : n3);
        }
    }

    public void getKeyCode(int n) {
        this.keyCode = n;
    }

    public String lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.lIIIIlIIllIIlIIlIIIlIIllI;
    }

    public float lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlllIIIlIlllIllIlIIlllIlI;
    }

    public float IlllIIIlIlllIllIlIIlllIlI() {
        return this.IIIIllIlIIIllIlllIlllllIl;
    }

    public int IIIIllIlIIIllIlllIlllllIl() {
        return this.keyCode;
    }
}
