package com.cheatbreaker.client.module.type.keystrokes;

import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.event.type.CBGuiDrawEvent;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.ui.CBGuiAnchor;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class KeystrokesModule
        extends CBModule {
    private CBSetting showClicks;
    private CBSetting showMovementKeys;
    private CBSetting showSpacebar;
    public CBSetting replaceNamesWithArrows;
    private CBSetting textColor;
    private CBSetting textColorPressed;
    private CBSetting backgroundColor;
    private CBSetting backgroundColorPressed;
    public CBSetting boxSize;
    private Key keyUp;
    private Key keyLeft;
    private Key keyRight;
    private Key keyDown;
    private Key previewIconWidth;
    private Key previewIconHeight;
    private Key previewLabelSize;

    public KeystrokesModule() {
        super("Key Strokes");
        this.setDefaultAnchor(CBGuiAnchor.RIGHT_TOP);
        this.setDefaultTranslations(-70, 5);
        this.setDefaultState(false);
        this.showClicks = new CBSetting(this, "Show clicks").setValue(true);
        this.showMovementKeys = new CBSetting(this, "Show movement keys").setValue(true);
        this.showSpacebar = new CBSetting(this, "Show spacebar").setValue(false);
        this.replaceNamesWithArrows = new CBSetting(this, "Replace names with arrows").setValue(false);
        this.boxSize = new CBSetting(this, "Box size").setValue(18).setMinMax(10, 32);
        this.textColor = new CBSetting(this, "Text Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.textColorPressed = new CBSetting(this, "Text Color (Pressed)").setValue(-16777216).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.backgroundColor = new CBSetting(this, "Background Color").setValue(0x6F000000).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.backgroundColorPressed = new CBSetting(this, "Background Color (Pressed)").setValue(0x6FFFFFFF).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.initialize();
        this.setPreviewIcon(new ResourceLocation("client/icons/mods/wasd.png"), 55, 37);
        this.addEvent(CBGuiDrawEvent.class, this::lIIIIlIIllIIlIIlIIIlIIllI);
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(CBGuiDrawEvent lIllIllIlIIllIllIlIlIIlIl2) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        this.scaleAndTranslate(lIllIllIlIIllIllIlIlIIlIl2.getResolution());
        float f = 0.0f;
        float f2 = 0.0f;
        if ((Boolean) this.showMovementKeys.getValue()) {
            this.keyUp.render(this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + 1.0f, 0.0f, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            this.keyLeft.render(0.0f, this.keyUp.IlllIIIlIlllIllIlIIlllIlI() + 1.0f, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            this.keyDown.render(this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + 1.0f, this.keyUp.IlllIIIlIlllIllIlIIlllIlI() + 1.0f, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            this.keyRight.render(this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyDown.lIIIIIIIIIlIllIIllIlIIlIl() + 2.0f, this.keyUp.IlllIIIlIlllIllIlIIlllIlI() + 1.0f, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            f = this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyDown.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyRight.lIIIIIIIIIlIllIIllIlIIlIl() + 2.0f;
            f2 += this.keyUp.IlllIIIlIlllIllIlIIlllIlI() + 2.0f + this.keyDown.IlllIIIlIlllIllIlIIlllIlI();
        }
        if ((Boolean) this.showClicks.getValue()) {
            this.previewIconWidth.render(0.0f, f2, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            this.previewIconHeight.render(this.previewIconWidth.lIIIIIIIIIlIllIIllIlIIlIl() + 1.0f, f2, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            f = this.previewIconWidth.lIIIIIIIIIlIllIIllIlIIlIl() + this.previewIconHeight.lIIIIIIIIIlIllIIllIlIIlIl() + 1.0f;
            f2 += this.previewIconHeight.IlllIIIlIlllIllIlIIlllIlI() + 1.0f;
        }
        if ((Boolean) this.showSpacebar.getValue()) {
            this.previewLabelSize.render(0.0f, f2, this.textColor.getColorValue(), this.textColorPressed.getColorValue(), this.backgroundColor.getColorValue(), this.backgroundColorPressed.getColorValue());
            f2 += this.previewLabelSize.IlllIIIlIlllIllIlIIlllIlI() + 1.0f;
        }
        this.setDimensions(f, f2 < (float)18 ? (float)18 : f2 + 2.0f);
        GL11.glPopMatrix();
    }

    public void initialize() {
        int n = this.minecraft.gameSettings.keyBindForward.getKeyCode();
        int n2 = this.minecraft.gameSettings.keyBindLeft.getKeyCode();
        int n3 = this.minecraft.gameSettings.keyBindBack.getKeyCode();
        int n4 = this.minecraft.gameSettings.keyBindRight.getKeyCode();
        int n5 = (Integer)this.boxSize.getValue();
        String w = Keyboard.getKeyName(n);
        String a = Keyboard.getKeyName(n2);
        String s = Keyboard.getKeyName(n3);
        String d = Keyboard.getKeyName(n4);
        float f = (float)this.minecraft.fontRenderer.getStringWidth(w) * (Float) this.scale.getValue();
        float f2 = (float)this.minecraft.fontRenderer.getStringWidth(a) * (Float) this.scale.getValue();
        float f3 = (float)this.minecraft.fontRenderer.getStringWidth(s) * (Float) this.scale.getValue();
        float f4 = (float)this.minecraft.fontRenderer.getStringWidth(d) * (Float) this.scale.getValue();
        int jump = this.minecraft.gameSettings.keyBindJump.getKeyCode();
        int attack = this.minecraft.gameSettings.keyBindAttack.getKeyCode();
        int use = this.minecraft.gameSettings.keyBindUseItem.getKeyCode();
        boolean bl = (Boolean)this.replaceNamesWithArrows.getValue();
        this.keyUp = new Key(bl ? "▲" : (f > (float)n5 ? w.substring(0, 1) : w), n, n5, n5);
        this.keyLeft = new Key(bl ? "◀" : (f2 > (float)n5 ? a.substring(0, 1) : a), n2, n5, n5);
        this.keyDown = new Key(bl ? "▼" : (f3 > (float)n5 ? s.substring(0, 1) : s), n3, n5, n5);
        this.keyRight = new Key(bl ? "▶" : (f4 > (float)n5 ? d.substring(0, 1) : d), n4, n5, n5);
        float f5 = (this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyDown.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyRight.lIIIIIIIIIlIllIIllIlIIlIl() + 1.0f) / 2.0f;
        this.previewIconWidth = new Key(n5 < 14 ? "L" : "LMB", use, f5, n5);
        this.previewIconHeight = new Key(n5 < 14 ? "R" : "RMB", attack, f5, n5);
        this.previewLabelSize = new Key(Keyboard.getKeyName(jump), jump, this.keyLeft.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyDown.lIIIIIIIIIlIllIIllIlIIlIl() + this.keyRight.lIIIIIIIIIlIllIIllIlIIlIl() + 2.0f, (float)n5 * (0.3597561f * 1.3898305f));
    }
}
