package com.cheatbreaker.client.module.type;

enum IIlllllllIllIlIllIIIlllIl {
    lIIIIlIIllIIlIIlIIIlIIllI,
    lIIIIIIIIIlIllIIllIlIIlIl,
    IlllIIIlIlllIllIlIIlllIlI;

}