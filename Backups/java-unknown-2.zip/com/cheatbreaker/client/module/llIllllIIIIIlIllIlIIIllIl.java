package com.cheatbreaker.client.module;

public enum llIllllIIIIIlIllIlIIIllIl {
    lIIIIlIIllIIlIIlIIIlIIllI,
    lIIIIIIIIIlIllIIllIlIIlIl,
    IlllIIIlIlllIllIlIIlllIlI;

}
