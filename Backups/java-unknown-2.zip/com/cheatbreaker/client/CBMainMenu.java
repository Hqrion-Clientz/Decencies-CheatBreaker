package com.cheatbreaker.client;

import com.cheatbreaker.client.ui.CBAbstractGui;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CBMainMenu extends CBAbstractGui {
    @Override
    protected void drawMenu(float mouseX, float mouseY) {

    }

    @Override
    protected void mouseClicked(float mouseX, float mouseY, int mouseButton) {

    }

    @Override
    protected void mouseReleased(float mouseX, float mouseY, int mouseButton) {

    }

//    private final ResourceLocation IIIIllIlIIIllIlllIlllllIl = new ResourceLocation("client/logo_42.png");
//    private DynamicTexture IIIIllIIllIIIIllIllIIIlIl;
//    private ResourceLocation IlIlIIIlllIIIlIlllIlIllIl;
//    private static int IIIllIllIlIlllllllIlIlIII = 4100;
//    private final lIIlIIIllIIlllIlllIlIIlll IllIIIIIIIlIlIllllIIllIII;
//    private final lIIlIIIllIIlllIlllIlIIlll lIIIIllIIlIlIllIIIlIllIlI;
//    private final llllIIllllllIlIIlIlIIIllI IlllIllIlIIIIlIIlIIllIIIl;
//    private final lllIllIlIllIlIllIIIIIIlll IlIlllIIIIllIllllIllIIlIl;
//    private final lllIllIlIllIlIllIIIIIIlll lIllIlIlllIIlIIllIIlIIlII;
//    private final lllIllIlIllIlIllIIIIIIlll IIIlIIlIlIIIlllIIlIllllll;
//    private final IllllllIllllIIlllIllllllI IllIlIIIIlllIIllIIlllIIlI;
//    private final ResourceLocation[] panoramas = new ResourceLocation[]{new ResourceLocation("client/panorama/0.png"), new ResourceLocation("client/panorama/1.png"), new ResourceLocation("client/panorama/2.png"), new ResourceLocation("client/panorama/3.png"), new ResourceLocation("client/panorama/4.png"), new ResourceLocation("client/panorama/5.png")};
//    private File launcherProfiles;
//    private List lIlIlIllIIIIIIIIllllIIllI;
//    private float IlllIIlllIIIIllIIllllIlIl;
//
//    public lIIIlIlIIllIIlllIIIlIIllI() {
//        this.launcherProfiles = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "launcher_profiles.json");
//        this.lIlIlIllIIIIIIIIllllIIllI = new ArrayList();
//        this.IlIlllIIIIllIllllIllIIlIl = new lllIllIlIllIlIllIIIIIIlll("OPTIONS");
//        this.IIIlIIlIlIIIlllIIlIllllll = new lllIllIlIllIlIllIIIIIIlll("COSMETICS");
//        this.lIllIlIlllIIlIIllIIlIIlII = new lllIllIlIllIlIllIIIIIIlll("CHANGELOG");
//        this.IllIlIIIIlllIIllIIlllIIlI = new IllllllIllllIIlllIllllllI(0xF000000, -16777216);
//        this.IllIIIIIIIlIlIllllIIllIII = new lIIlIIIllIIlllIlllIlIIlll(new ResourceLocation("client/icons/delete-64.png"));
//        this.lIIIIllIIlIlIllIIIlIllIlI = new lIIlIIIllIIlllIlllIlIIlll(6, new ResourceLocation("client/icons/globe-24.png"));
//        this.IlllIIlllIIIIllIIllllIlIl = CBClient.getInstance().llIlIIIlIIIIlIlllIlIIIIll.lIIIIIIIIIlIllIIllIlIIlIl(Minecraft.getMinecraft().getSession().getUsername());
//        this.IlllIllIlIIIIlIIlIIllIIIl = new llllIIllllllIlIIlIlIIIllI(this, Minecraft.getMinecraft().getSession().getUsername(), CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().getUsername(), Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl()));
//        this.setIngameNotInFocus();
//    }
//
//    /*
//     * Could not resolve type clashes
//     */
//    private void setIngameNotInFocus() {
//        Minecraft minecraft = Minecraft.getMinecraft();
//        ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
//        if (this.launcherProfiles.exists()) {
//            try {
//                JsonElement parsed = new JsonParser().parse(new FileReader(this.launcherProfiles));
//                String clientToken = "";
//                for (Map.Entry<String, JsonElement> entry : parsed.getAsJsonObject().entrySet()) {
//                    if (entry.getKey().equalsIgnoreCase("clientToken") && entry.getValue() != null) {
//                        clientToken = entry.getValue().getAsString();
//                    }
//                    if (!entry.getKey().equalsIgnoreCase("authenticationDatabase")) continue;
//                    for (Map.Entry<String, JsonElement> objEntry : entry.getValue().getAsJsonObject().entrySet()) {
//                        HashMap<String, String> hashMap = new HashMap<>();
//                        hashMap.put("clientToken", clientToken);
//                        for (Map.Entry<String, JsonElement> entry3 : objEntry.getValue().getAsJsonObject().entrySet()) {
//                            if (entry3.getKey().equalsIgnoreCase("profiles")) {
//                                for (Map.Entry<String, JsonElement> entry4 : entry3.getValue().getAsJsonObject().entrySet()) {
//                                    hashMap.put("uuid", entry4.getKey());
//                                    for (Map.Entry<String, JsonElement> entry5 : entry4.getValue().getAsJsonObject().entrySet()) {
//                                        if (entry5.getValue() == null) continue;
//                                        hashMap.put("displayName", entry5.getValue().getAsString());
//                                    }
//                                }
//                                continue;
//                            }
//                            if (!entry3.getKey().equalsIgnoreCase("username") && !entry3.getKey().equalsIgnoreCase("displayName") && !entry3.getKey().equalsIgnoreCase("uuid") && !entry3.getKey().equalsIgnoreCase("accessToken")) continue;
//                            hashMap.put(entry3.getKey(), entry3.getValue().getAsString());
//                        }
//                        arrayList.add(hashMap);
//                    }
//                }
//            }
//            catch (Exception exception) {
//                // empty catch block
//            }
//        }
//        this.lIlIlIllIIIIIIIIllllIIllI.clear();
//        this.IlllIIlllIIIIllIIllllIlIl = CheatBreaker.getInstance().llIlIIIlIIIIlIlllIlIIIIll.lIIIIIIIIIlIllIIllIlIIlIl(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().getUsername());
//        for (HashMap<String, String> object3 : arrayList) {
//            String name = object3.get("displayName");
//            object = new IllIIIllIlIIlIllIIIllllIl((String)object3.get("username"), (String)object3.get("clientToken"), (String)object3.get("accessToken"), (String)object3.get("displayName"), (String)object3.get("uuid"));
//            this.lIlIlIllIIIIIIIIllllIIllI.add(object);
//            float f = CheatBreaker.getInstance().llIlIIIlIIIIlIlllIlIIIIll.lIIIIIIIIIlIllIIllIlIIlIl(((IllIIIllIlIIlIllIIIllllIl)object).IIIIllIlIIIllIlllIlllllIl());
//            if (f > this.IlllIIlllIIIIllIIllllIlIl) {
//                this.IlllIIlllIIIIllIIllllIlIl = f;
//            }
//            if (minecraft.IIIIlIIIlllllllllIlllIlll() == null || !((String)object2).equalsIgnoreCase(minecraft.IIIIlIIIlllllllllIlllIlll().getUsername())) continue;
//            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(((IllIIIllIlIIlIllIIIllllIl)object).IIIIllIlIIIllIlllIlllllIl());
//            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI(((IllIIIllIlIIlIllIIIllllIl)object).IIIIllIlIIIllIlllIlllllIl(), ((IllIIIllIlIIlIllIIIllllIl)object).IIIIllIlIIIllIlllIlllllIl()));
//            this.shutdown();
//        }
//    }
//
//    @Override
//    public void handleMouseInput() {
//        super.handleMouseInput();
//        if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
//            this.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI();
//        }
//    }
//
//    @Override
//    public void updateScreen() {
//        super.updateScreen();
//        ++IIIllIllIlIlllllllIlIlIII;
//    }
//
//    @Override
//    public void initGui() {
//        super.initGui();
//        this.IIIIllIIllIIIIllIllIIIlIl = new DynamicTexture(256, 256);
//        this.IlIlIIIlllIIIlIlllIlIllIl = this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().getDynamicTextureLocation("background", this.IIIIllIIllIIIIllIllIIIlIl);
//        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI((float)124, (float)6, (float)42, 20);
//        this.IIIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI((float)167, (float)6, (float)48, 20);
//        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() - (float)30, (float)7, (float)23, 17);
//        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() / 2.0f - (float)13, this.IIIllIllIlIlllllllIlIlIII() - (float)17, (float)26, 18);
//        this.shutdown();
//    }
//
//    public void shutdown() {
//        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlIIIlllIIIlIlllIlIllIl() - (float)35 - this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIlllIIIIllIIllllIlIl), (float)7, this.IlllIllIlIIIIlIIlIIllIIIl.IIIIllIIllIIIIllIllIIIlIl(this.IlllIIlllIIIIllIIllllIlIl), 17);
//    }
//
//    @Override
//    public void drawScreen(int n, int n2, float f) {
//        GL11.glDisable(3008);
//        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2, 1.0f);
//        GL11.glEnable(3008);
//        super.drawScreen(n, n2, f);
//    }
//
//    @Override
//    public void drawMenu(float f, float f2) {
//        lIIIlIlIIllIIlllIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, this.IlIlIIIlllIIIlIlllIlIllIl(), this.IIIllIllIlIlllllllIlIlIII(), 0x5FFFFFFF, 0x2FFFFFFF);
//        lIIIlIlIIllIIlllIIIlIIllI.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, this.IlIlIIIlllIIIlIlllIlIllIl(), 160, -553648128, 0);
//        boolean bl = f < this.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl() && f2 < (float)30;
//        Color color = this.IllIlIIIIlllIIllIIlllIIlI.lIIIIIIIIIlIllIIllIlIIlIl(bl);
//        CheatBreaker.getInstance().IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("CheatBreaker", 37, (float)9, color.getRGB());
//        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
//        lIlIIIlllIllllIlllIIIIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl, (float)10, (float)8, (float)6);
//        CheatBreaker.getInstance().IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI("CheatBreaker", 36, (float)8, -1);
//        String string = "CheatBreaker Dev (" + CheatBreaker.IlIlllIIIIllIllllIllIIlIl() + "/" + CheatBreaker.llIIlllIIIIlllIllIlIlllIl() + ")";
//        CheatBreaker.getInstance().llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(string, (double)5, (double)(this.IIIllIllIlIlllllllIlIlIII() - (float)14), -1879048193);
//        String string2 = "Copyright Mojang AB. Do not distribute!";
//        CheatBreaker.getInstance().llIIlllIIIIlllIllIlIlllIl.lIIIIlIIllIIlIIlIIIlIIllI(string2, (double)(this.IlIlIIIlllIIIlIlllIlIllIl() - (float)CheatBreaker.getInstance().llIIlllIIIIlllIllIlIlllIl.lIIIIIIIIIlIllIIllIlIIlIl(string2) - (float)5), (double)(this.IIIllIllIlIlllllllIlIlIII() - (float)14), -1879048193);
//        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, true);
//        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, true);
//        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, true);
//        this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, true);
//        this.IIIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, true);
//    }
//
//    @Override
//    protected void lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, int n) {
//        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, n, true);
//        this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(f, f2, n, true);
//        if (this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(f, f2)) {
//            this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//            this.lllIIIIIlIllIlIIIllllllII.shutdown();
//        } else if (this.IlIlllIIIIllIllllIllIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(f, f2)) {
//            this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IllIIlIIllIIlIIIIlllIlIlI(this, this.lllIIIIIlIllIlIIIllllllII.gameSettings));
//        } else if (this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(f, f2)) {
//            this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new lIlIlllllllIIlIIIIIlllIIl(this, this.lllIIIIIlIllIlIIIllllllII.gameSettings, this.lllIIIIIlIllIlIIIllllllII.lIlIllIlIlIIIllllIlIllIll()));
//        } else if (this.IIIlIIlIlIIIlllIIlIllllll.lIIIIlIIllIIlIIlIIIlIIllI(f, f2)) {
//            this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//            this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IIIlllIllIlIIllIIllIlIlll());
//        } else {
//            boolean bl;
//            boolean bl2 = bl = f < this.IlIlllIIIIllIllllIllIIlIl.IIIIllIlIIIllIlllIlllllIl() && f2 < (float)30;
//            if (bl && !(this.lllIIIIIlIllIlIIIllllllII.currentScreen instanceof IlIlIIIIIllIlIlIIllIlIIIl)) {
//                this.lllIIIIIlIllIlIIIllllllII.lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//                this.lllIIIIIlIllIlIIIllllllII.displayGuiScreen(new IlIlIIIIIllIlIlIIllIlIIIl());
//            }
//        }
//    }
//
//    @Override
//    public void lIIIIIIIIIlIllIIllIlIIlIl(float f, float f2, int n) {
//    }
//
//    private void lIIIIIIIIIlIllIIllIlIIlIl(int n, int n2, float f) {
//        this.lllIIIIIlIllIlIIIllllllII.getFramebuffer().unbindFramebuffer();
//        GL11.glViewport(0, 0, 256, 256);
//        this.IlllIIIlIlllIllIlIIlllIlI(n, n2, f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lIIIIlIIllIIlIIlIIIlIIllI(f);
//        this.lllIIIIIlIllIlIIIllllllII.getFramebuffer().bindFramebuffer(true);
//        GL11.glViewport(0, 0, this.lllIIIIIlIllIlIIIllllllII.displayWidth, this.lllIIIIIlIllIlIIIllllllII.displayHeight);
//        Tessellator tessellator = Tessellator.instance;
//        tessellator.startDrawingQuads();
//        float f2 = this.lIIIIIllllIIIIlIlIIIIlIlI > this.IIIIIIlIlIlIllllllIlllIlI ? (float)120 / (float)this.lIIIIIllllIIIIlIlIIIIlIlI : (float)120 / (float)this.IIIIIIlIlIlIllllllIlllIlI;
//        float f3 = (float)this.IIIIIIlIlIlIllllllIlllIlI * f2 / (float)256;
//        float f4 = (float)this.lIIIIIllllIIIIlIlIIIIlIlI * f2 / (float)256;
//        tessellator.lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 1.0f, 1.0f, 1.0f);
//        float f5 = this.lIIIIIllllIIIIlIlIIIIlIlI;
//        float f6 = this.IIIIIIlIlIlIllllllIlllIlI;
//        tessellator.addVertexWithUV(0.0, f6, llIlIIIlIIIIlIlllIlIIIIll, 1.3561643f * 0.36868688f - f3, 6.785714f * 0.073684216f + f4);
//        tessellator.addVertexWithUV(f5, f6, llIlIIIlIIIIlIlllIlIIIIll, 1.0f * 0.5f - f3, 0.18041237f * 2.7714286f - f4);
//        tessellator.addVertexWithUV(f5, 0.0, llIlIIIlIIIIlIlllIlIIIIll, 4.9473686f * 0.101063825f + f3, 0.18421052f * 2.7142859f - f4);
//        tessellator.addVertexWithUV(0.0, 0.0, llIlIIIlIIIIlIlllIlIIIIll, 0.45f * 1.1111112f + f3, 3.5454545f * 0.14102565f + f4);
//        tessellator.draw();
//    }
//
//    private void IlllIIIlIlllIllIlIIlllIlI(int n, int n2, float f) {
//        Tessellator tessellator = Tessellator.instance;
//        GL11.glMatrixMode(5889);
//        GL11.glPushMatrix();
//        GL11.glLoadIdentity();
//        Project.gluPerspective(120, 1.0f, 0.0069620255f * 7.181818f, 10);
//        GL11.glMatrixMode(5888);
//        GL11.glPushMatrix();
//        GL11.glLoadIdentity();
//        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
//        GL11.glRotatef(180, 1.0f, 0.0f, 0.0f);
//        GL11.glRotatef(90, 0.0f, 0.0f, 1.0f);
//        GL11.glEnable(3042);
//        GL11.glDisable(3008);
//        GL11.glDisable(2884);
//        GL11.glDepthMask(false);
//        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
//        int n3 = 8;
//        for (int i = 0; i < n3 * n3; ++i) {
//            GL11.glPushMatrix();
//            float f2 = ((float)(i % n3) / (float)n3 - 0.45762712f * 1.0925926f) / (float)64;
//            float f3 = ((float)(i / n3) / (float)n3 - 0.45294115f * 1.1038961f) / (float)64;
//            float f4 = 0.0f;
//            GL11.glTranslatef(f2, f3, f4);
//            GL11.glRotatef(MathHelper.lIIIIlIIllIIlIIlIIIlIIllI(((float)IIIllIllIlIlllllllIlIlIII + f) / (float)400) * (float)25 + (float)20, 1.0f, 0.0f, 0.0f);
//            GL11.glRotatef(-((float)IIIllIllIlIlllllllIlIlIII + f) * (0.39240506f * 0.2548387f), 0.0f, 1.0f, 0.0f);
//            for (int j = 0; j < 6; ++j) {
//                GL11.glPushMatrix();
//                if (j == 1) {
//                    GL11.glRotatef(90, 0.0f, 1.0f, 0.0f);
//                }
//                if (j == 2) {
//                    GL11.glRotatef(180, 0.0f, 1.0f, 0.0f);
//                }
//                if (j == 3) {
//                    GL11.glRotatef(-90, 0.0f, 1.0f, 0.0f);
//                }
//                if (j == 4) {
//                    GL11.glRotatef(90, 1.0f, 0.0f, 0.0f);
//                }
//                if (j == 5) {
//                    GL11.glRotatef(-90, 1.0f, 0.0f, 0.0f);
//                }
//                this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(this.panoramas[j]);
//                tessellator.startDrawingQuads();
//                tessellator.lIIIIlIIllIIlIIlIIIlIIllI(0xFFFFFF, 255 / (i + 1));
//                float f5 = 0.0f;
//                tessellator.addVertexWithUV(-1, -1, 1.0, 0.0f + f5, 0.0f + f5);
//                tessellator.addVertexWithUV(1.0, -1, 1.0, 1.0f - f5, 0.0f + f5);
//                tessellator.addVertexWithUV(1.0, 1.0, 1.0, 1.0f - f5, 1.0f - f5);
//                tessellator.addVertexWithUV(-1, 1.0, 1.0, 0.0f + f5, 1.0f - f5);
//                tessellator.draw();
//                GL11.glPopMatrix();
//            }
//            GL11.glPopMatrix();
//            GL11.glColorMask(true, true, true, false);
//        }
//        tessellator.lIIIIIIIIIlIllIIllIlIIlIl(0.0, 0.0, 0.0);
//        GL11.glColorMask(true, true, true, true);
//        GL11.glMatrixMode(5889);
//        GL11.glPopMatrix();
//        GL11.glMatrixMode(5888);
//        GL11.glPopMatrix();
//        GL11.glDepthMask(true);
//        GL11.glEnable(2884);
//        GL11.glEnable(2929);
//    }
//
//    private void lIIIIlIIllIIlIIlIIIlIIllI(float f) {
//        this.lllIIIIIlIllIlIIIllllllII.llIlIlIllIlIIlIlllIllIIlI().bindTexture(this.IlIlIIIlllIIIlIlllIlIllIl);
//        GL11.glTexParameteri(3553, 10241, 9729);
//        GL11.glTexParameteri(3553, 10240, 9729);
//        GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, 256, 256);
//        GL11.glEnable(3042);
//        OpenGlHelper.IlllIIIlIlllIllIlIIlllIlI(770, 771, 1, 0);
//        GL11.glColorMask(true, true, true, false);
//        Tessellator tessellator = Tessellator.instance;
//        tessellator.startDrawingQuads();
//        GL11.glDisable(3008);
//        int n = 3;
//        for (int i = 0; i < n; ++i) {
//            tessellator.lIIIIlIIllIIlIIlIIIlIIllI(1.0f, 1.0f, 1.0f, 1.0f / (float)(i + 1));
//            float f2 = this.lIIIIIllllIIIIlIlIIIIlIlI;
//            float f3 = this.IIIIIIlIlIlIllllllIlllIlI;
//            float f4 = (float)(i - n / 2) / (float)256;
//            tessellator.addVertexWithUV(f2, f3, llIlIIIlIIIIlIlllIlIIIIll, 0.0f + f4, 1.0);
//            tessellator.addVertexWithUV(f2, 0.0, llIlIIIlIIIIlIlllIlIIIIll, 1.0f + f4, 1.0);
//            tessellator.addVertexWithUV(0.0, 0.0, llIlIIIlIIIIlIlllIlIIIIll, 1.0f + f4, 0.0);
//            tessellator.addVertexWithUV(0.0, f3, llIlIIIlIIIIlIlllIlIIIIll, 0.0f + f4, 0.0);
//        }
//        tessellator.draw();
//        GL11.glEnable(3008);
//        GL11.glColorMask(true, true, true, true);
//    }
//
//    public void setSection(String string) {
//        block21: {
//            try {
//                Session session;
//                Object object2;
//                IllIIIllIlIIlIllIIIllllIl illIIIllIlIIlIllIIIllllIl = null;
//                for (Object object2 : this.lIlIlIllIIIIIIIIllllIIllI) {
//                    if (!((IllIIIllIlIIlIllIIIllllIl)object2).IIIIllIlIIIllIlllIlllllIl().equals(string)) continue;
//                    illIIIllIlIIlIllIIIllllIl = object2;
//                }
//                if (illIIIllIlIIlIllIIIllllIl == null) break block21;
//                if (illIIIllIlIIlIllIIIllllIl.IIIIllIIllIIIIllIllIIIlIl().equalsIgnoreCase(Minecraft.getMinecraft().IIIIlIIIlllllllllIlllIlll().lIIIIIIIIIlIllIIllIlIIlIl())) {
//                    return;
//                }
//                Minecraft.getMinecraft().lIIIlllIIIlIIIIIlIIIIIIII().lIIIIlIIllIIlIIlIIIlIIllI(lllIlIIIIllIIIlIlIllllIll.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("gui.button.press"), 1.0f));
//                for (Object object2 : CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI) {
//                    if (!((Session)object2).IIIIllIIllIIIIllIllIIIlIl().getId().toString().replaceAll("-", "").equalsIgnoreCase(illIIIllIlIIlIllIIIllllIl.IIIIllIIllIIIIllIllIIIlIl().replaceAll("-", ""))) continue;
//                    Minecraft.getMinecraft().lIIIIlIIllIIlIIlIIIlIIllI((Session)object2);
//                    this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl());
//                    this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl.IlIlIIIlllIIIlIlllIlIllIl());
//                    this.shutdown();
//                    try {
//                        CheatBreaker.getInstance().IllIIIIIIIlIlIllllIIllIII();
//                        Message.c(illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl(), illIIIllIlIIlIllIIIllllIl.IIIIllIIllIIIIllIllIIIlIl(), illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI());
//                    }
//                    catch (UnsatisfiedLinkError unsatisfiedLinkError) {
//                        // empty catch block
//                    }
//                    return;
//                }
//                System.out.println("token: " + illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI() + "; accessToken: " + illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI());
//                YggdrasilAuthenticationService yggdrasilAuthenticationService = new YggdrasilAuthenticationService(Proxy.NO_PROXY, illIIIllIlIIlIllIIIllllIl.lIIIIlIIllIIlIIlIIIlIIllI());
//                object2 = (YggdrasilUserAuthentication)((Object)yggdrasilAuthenticationService.createUserAuthentication(Agent.MINECRAFT));
//                HashMap<String, String> hashMap = new HashMap<String, String>();
//                hashMap.put("uuid", illIIIllIlIIlIllIIIllllIl.IIIIllIIllIIIIllIllIIIlIl());
//                hashMap.put("displayName", illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl());
//                hashMap.put("username", illIIIllIlIIlIllIIIllllIl.lIIIIIIIIIlIllIIllIlIIlIl());
//                hashMap.put("accessToken", illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI());
//                ((YggdrasilUserAuthentication)object2).loadFromStorage(hashMap);
//                try {
//                    ((YggdrasilUserAuthentication)object2).logIn();
//                    session = new Session(((YggdrasilUserAuthentication)object2).getSelectedProfile().getName(), ((YggdrasilUserAuthentication)object2).getSelectedProfile().getId().toString(), ((YggdrasilUserAuthentication)object2).getAuthenticatedToken(), "mojang");
//                }
//                catch (AuthenticationException authenticationException) {
//                    authenticationException.printStackTrace();
//                    return;
//                }
//                File file = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "launcher_profiles.json");
//                if (file.exists() && !((YggdrasilUserAuthentication)object2).getAuthenticatedToken().equals(illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI())) {
//                    try {
//                        FileReader fileReader = new FileReader(file);
//                        JsonParser jsonParser = new JsonParser();
//                        JsonElement jsonElement = jsonParser.parse(fileReader);
//                        Map.Entry entry = null;
//                        for (Object object3 : jsonElement.getAsJsonObject().entrySet()) {
//                            if (!((String)object3.getKey()).equalsIgnoreCase("authenticationDatabase")) continue;
//                            for (Map.Entry entry2 : ((JsonElement)object3.getValue()).getAsJsonObject().entrySet()) {
//                                for (Map.Entry entry3 : ((JsonElement)entry2.getValue()).getAsJsonObject().entrySet()) {
//                                    if (!((String)entry3.getKey()).equalsIgnoreCase("profiles")) continue;
//                                    for (Map.Entry entry4 : ((JsonElement)entry3.getValue()).getAsJsonObject().entrySet()) {
//                                        if (!((String)entry4.getKey()).replaceAll("-", "").equalsIgnoreCase(session.lIIIIIIIIIlIllIIllIlIIlIl().replaceAll("-", ""))) continue;
//                                        entry = entry2;
//                                    }
//                                }
//                            }
//                        }
//                        if (entry != null) {
//                            illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI(((YggdrasilUserAuthentication)object2).getAuthenticatedToken());
//                            ((JsonElement)entry.getValue()).getAsJsonObject().remove("accessToken");
//                            ((JsonElement)entry.getValue()).getAsJsonObject().addProperty("accessToken", ((YggdrasilUserAuthentication)object2).getAuthenticatedToken());
//                        }
//                        Gson gson = new GsonBuilder().setPrettyPrinting().create();
//                        try {
//                            Object object3;
//                            object3 = new DataOutputStream(new FileOutputStream(file));
//                            ((DataOutputStream)object3).writeBytes(gson.toJson(jsonElement).replace("\n", "\r\n"));
//                            ((DataOutputStream)object3).flush();
//                            ((FilterOutputStream)object3).close();
//                        }
//                        catch (Exception exception) {
//                            exception.printStackTrace();
//                            return;
//                        }
//                    }
//                    catch (Exception exception) {
//                        exception.printStackTrace();
//                        return;
//                    }
//                }
//                System.out.println("Updated accessToken and logged user in.");
//                this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl());
//                this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(illIIIllIlIIlIllIIIllllIl.IlIlIIIlllIIIlIlllIlIllIl());
//                this.shutdown();
//                try {
//                    CheatBreaker.getInstance().IllIIIIIIIlIlIllllIIllIII();
//                    Message.c(illIIIllIlIIlIllIIIllllIl.IIIIllIlIIIllIlllIlllllIl(), illIIIllIlIIlIllIIIllllIl.IIIIllIIllIIIIllIllIIIlIl(), illIIIllIlIIlIllIIIllllIl.IlllIIIlIlllIllIlIIlllIlI());
//                }
//                catch (UnsatisfiedLinkError unsatisfiedLinkError) {
//                    // empty catch block
//                }
//                CheatBreaker.getInstance().lIIIIlIIllIIlIIlIIIlIIllI.add(session);
//                Minecraft.getMinecraft().lIIIIlIIllIIlIIlIIIlIIllI(session);
//            }
//            catch (Exception exception) {
//                exception.printStackTrace();
//            }
//        }
//    }
//
//    public List IIIlllIIIllIllIlIIIIIIlII() {
//        return this.lIlIlIllIIIIIIIIllllIIllI;
//    }

}
