package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class ChoiceElement
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;
    private ResourceLocation IllIIIIIIIlIlIllllIIllIII = new ResourceLocation("client/icons/left.png");
    private ResourceLocation lIIIIllIIlIlIllIIIlIllIlI = new ResourceLocation("client/icons/right.png");
    private int IlllIllIlIIIIlIIlIIllIIIl = 0;
    private float IlIlllIIIIllIllllIllIIlIl = 0.0f;
    private String llIIlllIIIIlllIllIlIlllIl;

    public ChoiceElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.IIIllIllIlIlllllllIlIlIII = 12;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        boolean bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 10) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 10, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), bl2 || bl ? -1090519040 : -1895825408);
        boolean bl3 = this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toLowerCase().endsWith("color");
        if (!bl3) {
            if (this.IlllIllIlIIIIlIIlIIllIIIl == 0) {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
            } else {
                boolean bl4 = this.IlllIllIlIIIIlIIlIIllIIIl == 1;
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString(this.llIIlllIIIIlllIllIlIlllIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) - (bl4 ? -this.IlIlllIIIIllIllllIllIIlIl : this.IlIlllIIIIllIllllIllIIlIl), this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
                if (bl4) {
                    CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 98) + this.IlIlllIIIIllIllllIllIIlIl, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
                } else {
                    CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 2) - this.IlIlllIIIIllIllllIllIIlIl, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
                }
                if (this.IlIlllIIIIllIllllIllIIlIl >= (float)50) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = 0;
                    this.IlIlllIIIIllIllllIllIIlIl = 0.0f;
                } else {
                    float f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI((float)50 + this.IlIlllIIIIllIllllIllIIlIl * (float)15);
                    this.IlIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl + f2 >= (float)50 ? (float)50 : (this.IlIlllIIIIllIllllIllIIlIl += f2);
                }
                Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 130, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 72, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
                Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 22, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
            }
        } else if (this.IlllIllIlIIIIlIIlIIllIIIl == 0) {
            float f3 = CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getStringWidth((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue());
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl) - 44.738373f * 1.0617284f - f3 / 2.0f, (float)this.IIIIllIIllIIIIllIllIIIlIl + 1.74f * 1.4367816f, -16777216);
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString("§" + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) - f3 / 2.0f, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), -16777216);
        } else {
            boolean bl5 = this.IlllIllIlIIIIlIIlIIllIIIl == 1;
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString(this.llIIlllIIIIlllIllIlIlllIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) - (bl5 ? -this.IlIlllIIIIllIllllIllIIlIl : this.IlIlllIIIIllIllllIllIIlIl), this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
            float f4 = CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getStringWidth((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue());
            if (bl5) {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl) - 110.21739f * 0.88461536f - f4 / 2.0f + this.IlIlllIIIIllIllllIllIIlIl, (float)this.IIIIllIIllIIIIllIllIIIlIl + 0.8095238f * 3.0882351f, -16777216);
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString("§" + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 98) - f4 / 2.0f + this.IlIlllIIIIllIllllIllIIlIl, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), -16777216);
            } else {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl) - 2.6296296f * 0.57042253f - f4 / 2.0f - this.IlIlllIIIIllIllllIllIIlIl, (float)this.IIIIllIIllIIIIllIllIIIlIl + 0.040983606f * 61.0f, -16777216);
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString("§" + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() + (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 2) - f4 / 2.0f - this.IlIlllIIIIllIllllIllIIlIl, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), -16777216);
            }
            if (this.IlIlllIIIIllIllllIllIIlIl >= (float)50) {
                this.IlllIllIlIIIIlIIlIIllIIIl = 0;
                this.IlIlllIIIIllIllllIllIIlIl = 0.0f;
            } else {
                float f5 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI((float)50 + this.IlIlllIIIIllIllllIllIIlIl * (float)15);
                this.IlIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl + f5 >= (float)50 ? (float)50 : (this.IlIlllIIIIllIllllIllIIlIl += f5);
            }
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 130, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 72, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 22, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
        }
        GL11.glColor4f(0.0f, 0.0f, 0.0f, bl2 ? 0.6857143f * 1.1666666f : 0.5416667f * 0.8307692f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, (float)4, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 82), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3));
        GL11.glColor4f(0.0f, 0.0f, 0.0f, bl ? 0.82580644f * 0.96875f : 3.3793104f * 0.13316326f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, (float)4, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 22), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3));
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 10) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl3 = bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if ((bl || bl2) && this.IlllIllIlIIIIlIIlIIllIIIl == 0) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues().length; ++i) {
                if (!((String[])this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues())[i].toLowerCase().equalsIgnoreCase((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue())) continue;
                this.llIIlllIIIIlllIllIlIlllIl = (String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue();
                if (bl2) {
                    if (i + 1 >= this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues().length) {
                        this.IlllIllIlIIIIlIIlIIllIIIl = 2;
                        this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(((String[])this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues())[0]);
                        break;
                    }
                    this.IlllIllIlIIIIlIIlIIllIIIl = 2;
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(((String[])this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues())[i + 1]);
                    break;
                }
                if (!bl) continue;
                if (i - 1 < 0) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = 1;
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(((String[])this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues())[this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues().length - 1]);
                    break;
                }
                this.IlllIllIlIIIIlIIlIIllIIIl = 1;
                this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(((String[])this.lIIIIlIIllIIlIIlIIIlIIllI.getAcceptedValues())[i - 1]);
                break;
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getGlobalSettings().clearGlass) {
                Minecraft.getMinecraft().renderGlobal.loadRenderers();
            }
        }
    }
}