package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.gui.Gui;

public class IllllllllIlIIIIIIIIllIIII
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    private float IllIIIIIIIlIlIllllIIllIII;

    public IllllllllIlIIIIIIIIllIIII(float f, int n, float f2) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = n;
        this.IllIIIIIIIlIlIllllIIllIII = f2;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, -1358954496);
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 1, this.IIIIllIIllIIIIllIllIIIlIl + 1, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 1, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1, this.lIIIIlIIllIIlIIlIIIlIIllI | 0xFF000000);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }
}
