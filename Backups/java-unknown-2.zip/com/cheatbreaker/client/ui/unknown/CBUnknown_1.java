package com.cheatbreaker.client.ui.unknown;

import com.cheatbreaker.client.CBClient;
import net.minecraft.client.Minecraft;

public abstract class CBUnknown_1 {

    protected float xPos;
    protected float yPos;
    protected float width;
    protected float height;
    protected final Minecraft IIIIllIIllIIIIllIllIIIlIl = Minecraft.getMinecraft();
    protected final CBClient IlIlIIIlllIIIlIlllIlIllIl = CBClient.getInstance();

    public boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2) {
        return f > this.xPos && f < this.xPos + this.width && f2 > this.yPos && f2 < this.yPos + this.height;
    }

    public boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, boolean bl) {
        this.lIIIIIIIIIlIllIIllIlIIlIl(f, f2, bl);
        return this.lIIIIlIIllIIlIIlIIIlIIllI(f, f2);
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, float f3, float f4) {
        this.xPos = f;
        this.yPos = f2;
        this.width = f3;
        this.height = f4;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI() {
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl() {
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(char c, int n) {
    }

    public void IlllIIIlIlllIllIlIIlllIlI() {
    }

    protected abstract void lIIIIIIIIIlIllIIllIlIIlIl(float var1, float var2, boolean var3);

    public boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, int n, boolean bl) {
        return false;
    }

    public boolean lIIIIIIIIIlIllIIllIlIIlIl(float f, float f2, int n, boolean bl) {
        return false;
    }

    protected boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, float f2, int n) {
        return false;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(float f) {
        this.xPos = f;
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl(float f) {
        this.yPos = f;
    }

    public void IlllIIIlIlllIllIlIIlllIlI(float f) {
        this.width = f;
    }

    public void IIIIllIlIIIllIlllIlllllIl(float f) {
        this.height = f;
    }

    public float IIIIllIlIIIllIlllIlllllIl() {
        return this.xPos;
    }

    public float IIIIllIIllIIIIllIllIIIlIl() {
        return this.yPos;
    }

    public float IlIlIIIlllIIIlIlllIlIllIl() {
        return this.width;
    }

    public float IIIllIllIlIlllllllIlIlIII() {
        return this.height;
    }

}
