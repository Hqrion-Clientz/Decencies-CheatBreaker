package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.module.CBModule;

class IlIIllIIIlllIIIIlIIIIlIll {
    protected CBModule lIIIIlIIllIIlIIlIIIlIIllI;
    protected float lIIIIIIIIIlIllIIllIlIIlIl;
    protected float IlllIIIlIlllIllIlIIlllIlI;
    protected float IIIIllIlIIIllIlllIlllllIl;
    protected float IIIIllIIllIIIIllIllIIIlIl;
    protected float IlIlIIIlllIIIlIlllIlIllIl;
    protected int IIIllIllIlIlllllllIlIlIII;
    protected int IllIIIIIIIlIlIllllIIllIII;
    protected DELETE_ME_D lIIIIllIIlIlIllIIIlIllIlI;
    protected CBGuiAnchor IlllIllIlIIIIlIIlIIllIIIl;
    final CBModulesGui IlIlllIIIIllIllllIllIIlIl;

    public IlIIllIIIlllIIIIlIIIIlIll(CBModulesGui cBScreen_Interesting, CBModule cBModule, DELETE_ME_D dELETE_ME_D, int n, int n2) {
        this.IlIlllIIIIllIllllIllIIlIl = cBScreen_Interesting;
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBModule;
        this.lIIIIIIIIIlIllIIllIlIIlIl = cBModule.getXTranslation();
        this.IlllIIIlIlllIllIlIIlllIlI = cBModule.getYTranslation();
        this.IIIIllIIllIIIIllIllIIIlIl = cBModule.width * (Float) cBModule.scale.getValue();
        this.IlIlIIIlllIIIlIlllIlIllIl = cBModule.height * (Float) cBModule.scale.getValue();
        this.IllIIIIIIIlIlIllllIIllIII = n;
        this.IIIllIllIlIlllllllIlIlIII = n2;
        this.lIIIIllIIlIlIllIIIlIllIlI = dELETE_ME_D;
        this.IIIIllIlIIIllIlllIlllllIl = (Float) cBModule.scale.getValue();
        this.IlllIllIlIIIIlIIlIIllIIIl = cBModule.getGuiAnchor();
    }
}

