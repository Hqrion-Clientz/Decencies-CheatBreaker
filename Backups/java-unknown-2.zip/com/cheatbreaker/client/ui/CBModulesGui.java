package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CBModulesGui extends GuiScreen {

    public static CBModulesGui instance;
    private final ResourceLocation lIllIlIlllIIlIIllIIlIIlII = new ResourceLocation("client/icons/cog-64.png");
    private final ResourceLocation IIIlIIlIlIIIlllIIlIllllll = new ResourceLocation("client/icons/delete-64.png");
    private final ResourceLocation IllIlIIIIlllIIllIIlllIIlI = new ResourceLocation("client/logo_full_white.png");
    private final List<CBDragCache> CBDragCache = new ArrayList<>();
    private final List<lllIllIllIlIllIlIIllllIIl> IllIIlIIlllllIllIIIlllIII = new ArrayList();
    private final List<llllIIIIIlIlIlIlIllIIIIII> lIlIlIllIIIIIIIIllllIIllI = new ArrayList<>();
    private List<CBModule> IlllIIlllIIIIllIIllllIlIl;
    private llllIIIIIlIlIlIlIllIIIIII IllllIllllIlIIIlIIIllllll;
    public llllIIIIIlIlIlIlIllIIIIII lIIIIIIIIIlIllIIllIlIIlIl;
    @Deprecated
    protected lllIllIllIlIllIlIIllllIIl IlllIIIlIlllIllIlIIlllIlI;
    @Deprecated
    protected lllIllIllIlIllIlIIllllIIl IIIIllIlIIIllIlllIlllllIl;
    public lllIllIllIlIllIlIIllllIIl IIIIllIIllIIIIllIllIIIlIl;
    public lllIllIllIlIllIlIIllllIIl IlIlIIIlllIIIlIlllIlIllIl;
    protected lllIllIllIlIllIlIIllllIIl IIIllIllIlIlllllllIlIlIII;
    protected lllIllIllIlIllIlIIllllIIl IllIIIIIIIlIlIllllIIllIII;
    protected lllIllIllIlIllIlIIllllIIl lIIIIllIIlIlIllIIIlIllIlI = null;
    public lllIllIllIlIllIlIIllllIIl IlllIllIlIIIIlIIlIIllIIIl = null;
    private static CBModule IllIIlllIllIlIllIlIIIIIII;
    private boolean IlIlIIIlllllIIIlIlIlIllII = false;
    private float IIlIIllIIIllllIIlllIllIIl;
    private float lllIlIIllllIIIIlIllIlIIII;
    private List<IIlIlllIllIlIlIIIIIlllIll> lIIIIlllIIlIlllllIlIllIII;
    private List<IIlIlllIllIlIlIIIIIlllIll> lIIIlllIlIlllIIIIIIIIIlII;
    private int IIIIlIIIlllllllllIlllIlll;
    private int IlIllllIIIlIllllIIIIIllII;
    private boolean IlIIIIllIIIIIlllIIlIIlllI = false;
    private IlIIllIIIlllIIIIlIIIIlIll llIlIlIllIlIIlIlllIllIIlI;
    public static boolean IlIlllIIIIllIllllIllIIlIl;
    private int llIlIlIlllIlllllIIIllIIll;
    private int IIllIlIllIlIllIIlIllIlIII = 0;

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        //this.mc.entityRenderer.deactivateShader();
    }

    @Override
    public void initGui() {
        //this.IllIllIIIlIIlllIIIllIllII(); shader shid
        Keyboard.enableRepeatEvents(true);
        this.IlllIIlllIIIIllIIllllIlIl = new ArrayList<>();
        this.IlllIIlllIIIIllIIllllIlIl.addAll(CBClient.getInstance().getModuleManager().modules);
        this.lIIIIlllIIlIlllllIlIllIII = new ArrayList<>();
        this.lIIIlllIlIlllIIIIIIIIIlII = new ArrayList<>();
        this.IIIIlIIIlllllllllIlllIlll = -1;
        this.IlIllllIIIlIllllIIIIIllII = -1;
        this.llIlIlIlllIlllllIIIllIIll = 0;
        instance = this;
        IllIIlllIllIlIllIlIIIIIII = null;
        IlIlllIIIIllIllllIllIIlIl = false;
        this.lIIIIllIIlIlIllIIIlIllIlI = null;
        this.IlllIllIlIIIIlIIlIIllIIIl = null;
        this.llIlIlIllIlIIlIlllIllIIlI = null;
        IlIlllIIIIllIllllIllIIlIl = false;
        float f = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        int n = (int)((float)this.width / f);
        int n2 = (int)((float)this.height / f);
        this.IllIIlIIlllllIllIIIlllIII.clear();
        this.lIlIlIllIIIIIIIIllllIIllI.clear();
        List<CBModule> modules = CBClient.getInstance().getModuleManager().modules;
        List<CBModule> staffModules = CBClient.getInstance().getModuleManager().staffModules;
        this.IIIllIllIlIlllllllIlIlIII = new llllIIlIlIllIllllIIIIllll(f, n / 2 - 565, n2 / 2 + 14, 370, n2 / 2 - 35);
        this.IllIIlIIlllllIllIIIlllIII.add(this.IIIllIllIlIlllllllIlIlIII);
        this.IllIIIIIIIlIlIllllIIllIII = new lIlIIllIIIlllIIllIIlIIllI(staffModules, f, n / 2 + 195, n2 / 2 + 14, 370, n2 / 2 - 35);
        this.IllIIlIIlllllIllIIIlllIII.add(this.IllIIIIIIIlIlIllllIIllIII);
        this.IIIIllIIllIIIIllIllIIIlIl = new lIlIIllIIIlllIIllIIlIIllI(modules, f, n / 2 + 195, n2 / 2 + 14, 370, n2 / 2 - 35);
        this.IllIIlIIlllllIllIIIlllIII.add(this.IIIIllIIllIIIIllIllIIIlIl);
        this.IlIlIIIlllIIIlIlllIlIllIl = new IIlIlIlllIllIIlIllIIlIIlI(f, n / 2 - 565, n2 / 2 + 14, 370, n2 / 2 - 35);
        this.IllIIlIIlllllIllIIIlllIII.add(this.IlIlIIIlllIIIlIlllIlIllIl);
        this.IllllIllllIlIIIlIIIllllll = new llllIIIIIlIlIlIlIllIIIIII(null, "eye-64.png", 4, n2 - 32, 28, 28, -12418828, f);
        this.lIIIIIIIIIlIllIIllIlIIlIl = new llllIIIIIlIlIlIlIllIIIIII(null, "?", 36, n2 - 32, 28, 28, -12418828, f);
        if (CBClient.getInstance().checkSomeSecondBOolean()) {
            this.lIlIlIllIIIIIIIIllllIIllI.add(new llllIIIIIlIlIlIlIllIIIIII(this.IllIIIIIIIlIlIllllIIllIII, "Staff Mods", n / 2 - 50, n2 / 2 - 44, 100, 20, -9442858, f));
        }
        this.lIlIlIllIIIIIIIIllllIIllI.add(new llllIIIIIlIlIlIlIllIIIIII(this.IIIllIllIlIlllllllIlIlIII, "Mods", n / 2 - 50, n2 / 2 - 19, 100, 28, -13916106, f));
        this.lIlIlIllIIIIIIIIllllIIllI.add(new llllIIIIIlIlIlIlIllIIIIII(this.IIIIllIIllIIIIllIllIIIlIl, "cog-64.png", n / 2 + 54, n2 / 2 - 19, 28, 28, -12418828, f));
        this.lIlIlIllIIIIIIIIllllIIllI.add(new llllIIIIIlIlIlIlIllIIIIII(this.IlIlIIIlllIIIlIlllIlIllIl, "profiles-64.png", n / 2 - 82, n2 / 2 - 19, 28, 28, -12418828, f));
        IlIlllIIIIllIllllIllIIlIl = false;
        this.lIIIIllIIlIlIllIIIlIllIlI = null;
        this.IIllIlIllIlIllIIlIllIlIII = 5;
    }

    @Override
    public void updateScreen() {
        float f = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        int n = (int)((float)this.width / f);
        int n2 = (int)((float)this.height / f);
        this.lIIIIlIIllIIlIIlIIIlIIllI(n);
        if (!this.CBDragCache.isEmpty()) {
            boolean bl = Keyboard.isKeyDown(203);
            boolean bl2 = Keyboard.isKeyDown(205);
            boolean bl3 = Keyboard.isKeyDown(200);
            boolean bl4 = Keyboard.isKeyDown(208);
            if (bl || bl2 || bl3 || bl4) {
                ++this.llIlIlIlllIlllllIIIllIIll;
                if (this.llIlIlIlllIlllllIIIllIIll > 10) {
                    for (CBDragCache CBDragCache : this.CBDragCache) {
                        CBModule cBModule = CBDragCache.module;
                        if (cBModule == null) continue;
                        if (bl) {
                            cBModule.setTranslations((int)cBModule.getXTranslation() - 1, (int)cBModule.getYTranslation());
                            continue;
                        }
                        if (bl2) {
                            cBModule.setTranslations((int)cBModule.getXTranslation() + 1, (int)cBModule.getYTranslation());
                            continue;
                        }
                        if (bl3) {
                            cBModule.setTranslations((int)cBModule.getXTranslation(), (int)cBModule.getYTranslation() - 1);
                            continue;
                        }
                        cBModule.setTranslations((int)cBModule.getXTranslation(), (int)cBModule.getYTranslation() + 1);
                    }
                }
            }
        }
        float f2 = this.IIllIlIllIlIllIIlIllIlIII > 30 ? 2.0f + (float)this.IIllIlIllIlIllIIlIllIlIII / 2.0f : (float)4;
        this.IIllIlIllIlIllIIlIllIlIII = (float)this.IIllIlIllIlIllIIlIllIlIII + f2 >= (float)255 ? 255 : (int)((float)this.IIllIlIllIlIllIIlIllIlIII + f2);
    }

    private float lIIIIlIIllIIlIIlIIIlIIllI(Rectangle rectangle, Rectangle rectangle2) {
        float f = Math.max(Math.abs(rectangle.x - rectangle2.x) - rectangle2.width / 2, 0);
        float f2 = Math.max(Math.abs(rectangle.y - rectangle2.y) - rectangle2.height / 2, 0);
        return f * f + f2 * f2;
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        float f2;
        float f3;
        Object object;
        super.drawScreen(n, n2, f);
        ///this.lIIlllIIlIlllllllllIIIIIl(); blur shader
        ScaledResolution scaledResolution = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
        float f4 = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        if (IllIIlllIllIlIllIlIIIIIII != null) {
            if (!Mouse.isButtonDown(1)) {
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(2, 0.0, 2.916666637692187 * 0.8571428656578064, this.height, 0.0, -15599126);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((float)this.width - 5.0f * 0.5f, 0.0, this.width - 2, this.height, 0.0, -15599126);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, 2, this.width, 1.1547619104385376 * 2.164948442965692, 0.0, -15599126);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (float)this.height - 1.3529412f * 2.5869565f, this.width, this.height - 3, 0.0, -15599126);
            }
            this.IlllIIlllIIIIllIIllllIlIl.sort((cBModule, cBModule2) -> {
                if (cBModule == IllIIlllIllIlIllIlIIIIIII || cBModule2 == IllIIlllIllIlIllIlIIIIIII || cBModule.getGuiAnchor() == null || cBModule2.getGuiAnchor() == null) {
                    return 0;
                }
                float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
                float[] arrf2 = cBModule2.getScaledPoints(scaledResolution, true);
                float[] arrf3 = IllIIlllIllIlIllIlIIIIIII.getScaledPoints(scaledResolution, true);
                Rectangle rectangle = new Rectangle((int)(arrf[0] * (Float) cBModule.scale.getValue()), (int)(arrf[1] * ((Float)cBModule.scale.getValue()).floatValue()), (int)(cBModule.width * ((Float)cBModule.scale.getValue()).floatValue()), (int)(cBModule.height * ((Float)cBModule.scale.getValue()).floatValue()));
                Rectangle rectangle2 = new Rectangle((int)(arrf2[0] * (Float) cBModule2.scale.getValue()), (int)(arrf2[1] * ((Float)cBModule2.scale.getValue()).floatValue()), (int)(cBModule2.width * ((Float)cBModule2.scale.getValue()).floatValue()), (int)(cBModule2.height * ((Float)cBModule2.scale.getValue()).floatValue()));
                Rectangle rectangle3 = new Rectangle((int)(arrf3[0] * (Float) IllIIlllIllIlIllIlIIIIIII.scale.getValue()), (int)(arrf3[1] * (Float) CBModulesGui.IllIIlllIllIlIllIlIIIIIII.scale.getValue()), (int)(CBModulesGui.IllIIlllIllIlIllIlIIIIIII.width * (Float) CBModulesGui.IllIIlllIllIlIllIlIIIIIII.scale.getValue()), (int)(CBModulesGui.IllIIlllIllIlIllIlIIIIIII.height * (Float) CBModulesGui.IllIIlllIllIlIllIlIIIIIII.scale.getValue()));
                try {
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI(rectangle, rectangle3) > this.lIIIIlIIllIIlIIlIIIlIIllI(rectangle2, rectangle3)) {
                        return -1;
                    }
                    return 1;
                }
                catch (Exception exception) {
                    return 0;
                }
            });
            CBDragCache CBDragCache = this.getDragCache(IllIIlllIllIlIllIlIIIIIII);
            if (CBDragCache != null) {
                this.CBDragCache.remove(CBDragCache);
                this.CBDragCache.add(CBDragCache);
            }
            for (CBDragCache object2 : this.CBDragCache) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(object2, n, n2, scaledResolution);
                if (!(Boolean) CBClient.getInstance().getGlobalSettings().snapModules.getValue() || !this.IlIlIIIlllllIIIlIlIlIllII || Mouse.isButtonDown(1) || object2.module != IllIIlllIllIlIllIlIIIIIII) continue;
                for (CBModule cBModule3 : this.IlllIIlllIIIIllIIllllIlIl) {
                    if (this.getDragCache(cBModule3) != null || cBModule3.getGuiAnchor() == null || !cBModule3.isEnabled() || cBModule3.getName().contains("Zans") && CBClient.getInstance().getModuleManager().minmap.lIIIIlIIllIIlIIlIIIlIIllI().getMapOptions().hide) continue;
                    float f5 = 18;
                    if (cBModule3.width < f5) {
                        cBModule3.width = (int)f5;
                    }
                    if (cBModule3.height < (float)18) {
                        cBModule3.height = 18;
                    }
                    if (object2.module.width < f5) {
                        object2.module.width = (int)f5;
                    }
                    if (object2.module.height < (float)18) {
                        object2.module.height = 18;
                    }
                    boolean bl = true;
                    boolean bl2 = true;
                    float[] arrf = cBModule3.getScaledPoints(scaledResolution, true);
                    float[] scaledPoints = object2.module.getScaledPoints(scaledResolution, true);
                    float f6 = arrf[0] * (Float) cBModule3.scale.getValue() - scaledPoints[0] * (Float) object2.module.scale.getValue();
                    float f7 = (arrf[0] + cBModule3.width) * (Float) cBModule3.scale.getValue() - (scaledPoints[0] + object2.module.width) * (Float) object2.module.scale.getValue();
                    float f8 = (arrf[0] + cBModule3.width) * (Float) cBModule3.scale.getValue() - scaledPoints[0] * (Float) object2.module.scale.getValue();
                    float f9 = arrf[0] * (Float) cBModule3.scale.getValue() - (scaledPoints[0] + object2.module.width) * (Float) object2.module.scale.getValue();
                    float f10 = arrf[1] * (Float) cBModule3.scale.getValue() - scaledPoints[1] * (Float) object2.module.scale.getValue();
                    f3 = (arrf[1] + cBModule3.height) * (Float) cBModule3.scale.getValue() - (scaledPoints[1] + object2.module.height) * (Float) object2.module.scale.getValue();
                    f2 = (arrf[1] + cBModule3.height) * (Float) cBModule3.scale.getValue() - scaledPoints[1] * (Float) object2.module.scale.getValue();
                    float f11 = arrf[1] * (Float) cBModule3.scale.getValue() - (scaledPoints[1] + object2.module.height) * (Float) object2.module.scale.getValue();
                    int n3 = 2;
                    if (f6 >= (float)(-n3) && f6 <= (float)n3) {
                        bl = false;
                        this.IlllIIIlIlllIllIlIIlllIlI(f6);
                    }
                    if (f7 >= (float)(-n3) && f7 <= (float)n3 && bl) {
                        bl = false;
                        this.IlllIIIlIlllIllIlIIlllIlI(f7);
                    }
                    if (f9 >= (float)(-n3) && f9 <= (float)n3 && bl) {
                        bl = false;
                        this.IlllIIIlIlllIllIlIIlllIlI(f9);
                    }
                    if (f8 >= (float)(-n3) && f8 <= (float)n3 && bl) {
                        this.IlllIIIlIlllIllIlIIlllIlI(f8);
                    }
                    if (f10 >= (float)(-n3) && f10 <= (float)n3) {
                        bl2 = false;
                        this.IIIIllIlIIIllIlllIlllllIl(f10);
                    }
                    if (f3 >= (float)(-n3) && f3 <= (float)n3 && bl2) {
                        bl2 = false;
                        this.IIIIllIlIIIllIlllIlllllIl(f3);
                    }
                    if (f11 >= (float)(-n3) && f11 <= (float)n3 && bl2) {
                        bl2 = false;
                        this.IIIIllIlIIIllIlllIlllllIl(f11);
                    }
                    if (!(f2 >= (float)(-n3)) || !(f2 <= (float)n3) || !bl2) continue;
                    this.IIIIllIlIIIllIlllIlllllIl(f2);
                }
            }
        } else if (this.llIlIlIllIlIIlIlllIllIIlI != null) {
            float f12 = 1.0f;
            switch (this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI) {
                case lIIIIlIIllIIlIIlIIIlIIllI: {
                    int n4 = n2 - this.llIlIlIllIlIIlIlllIllIIlI.IIIllIllIlIlllllllIlIlIII + (n - this.llIlIlIllIlIIlIlllIllIIlI.IllIIIIIIIlIlIllllIIllIII);
                    f12 = this.llIlIlIllIlIIlIlllIllIIlI.IIIIllIlIIIllIlllIlllllIl - (float)n4 / (float)115;
                    break;
                }
                case IIIIllIlIIIllIlllIlllllIl: {
                    int n4 = n2 - this.llIlIlIllIlIIlIlllIllIIlI.IIIllIllIlIlllllllIlIlIII + (n - this.llIlIlIllIlIIlIlllIllIIlI.IllIIIIIIIlIlIllllIIllIII);
                    f12 = this.llIlIlIllIlIIlIlllIllIIlI.IIIIllIlIIIllIlllIlllllIl + (float)n4 / (float)115;
                    break;
                }
                case IlllIIIlIlllIllIlIIlllIlI: {
                    int n4 = n - this.llIlIlIllIlIIlIlllIllIIlI.IllIIIIIIIlIlIllllIIllIII - (n2 - this.llIlIlIllIlIIlIlllIllIIlI.IIIllIllIlIlllllllIlIlIII);
                    f12 = this.llIlIlIllIlIIlIlllIllIIlI.IIIIllIlIIIllIlllIlllllIl - (float)n4 / (float)115;
                    break;
                }
                case lIIIIIIIIIlIllIIllIlIIlIl: {
                    int n4 = n - this.llIlIlIllIlIIlIlllIllIIlI.IllIIIIIIIlIlIllllIIllIII - (n2 - this.llIlIlIllIlIIlIlllIllIIlI.IIIllIllIlIlllllllIlIlIII);
                    f12 = this.llIlIlIllIlIIlIlllIllIIlI.IIIIllIlIIIllIlllIlllllIl + (float)n4 / (float)115;
                }
            }
            if (f12 >= 1.0421053f * 0.47979796f && f12 <= 1.8962264f * 0.7910448f) {
                this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI.scale.setValue((float) ((double) Math.round((double) f12 * (double) 100) / (double) 100));
            }
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI(scaledResolution);
        boolean bl = true;
        for (Object object2 : this.IlllIIlllIIIIllIIllllIlIl) {
            boolean bl3 = this.lIIIIlIIllIIlIIlIIIlIIllI(f4, (CBModule)object2, scaledResolution, n, n2, bl);
            if (bl3) continue;
            bl = false;
        }
        GL11.glPushMatrix();
        GL11.glScalef(f4, f4, f4);
        int n5 = (int)((float)this.width / f4);
        int n6 = (int)((float)this.height / f4);
        this.IllllIllllIlIIIlIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        float f13 = (float)(this.IIllIlIllIlIllIIlIllIlIII * 8) / (float)255;
        GL11.glPushMatrix();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, f13);
        int n7 = 0xFFFFFF;
        if (f13 / (float)4 > 0.0f && f13 / (float)4 < 1.0f) {
            n7 = new Color(1.0f, 1.0f, 1.0f, f13 / (float)4).getRGB();
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, f13);
        if (f13 > 1.0f) {
            GL11.glTranslatef(-((float)(this.IIllIlIllIlIllIIlIllIlIII * 2) - (float)32) / (float)12 - 1.0f, 0.0f, 0.0f);
        }
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("client/logo_white.png"), (float)(n5 / 2 - 14), (float)(n6 / 2 - 47 - (CBClient.getInstance().checkSomeSecondBOolean() ? 22 : 0)), (float)28, 15);
        if (f13 > 2.0f) {
            CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString("| CHEAT", n5 / 2 + 18, (float)(n6 / 2 - 45 - (CBClient.getInstance().checkSomeSecondBOolean() ? 22 : 0)), n7);
            CBClient.getInstance().llIIlllIIIIlllIllIlIlllIl.drawString("BREAKER", n5 / 2 + 53, (float)(n6 / 2 - 45 - (CBClient.getInstance().checkSomeSecondBOolean() ? 22 : 0)), n7);
        }
        GL11.glPopMatrix();
        for (llllIIIIIlIlIlIlIllIIIIII llllIIIIIlIlIlIlIllIIIIII2 : this.lIlIlIllIIIIIIIIllllIIllI) {
            llllIIIIIlIlIlIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        }
        if (IllIIlllIllIlIllIlIIIIIII == null) {
            GL11.glPushMatrix();
            GL11.glEnable(3089);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(n5 / 2 - 185, n6 / 2 + 15, n5 / 2 + 185, n6 - 20, (float)scaledResolution.getScaleFactor() * f4, n6);
            for (lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2 : this.IllIIlIIlllllIllIIIlllIII) {
                if (lllIllIllIlIllIlIIllllIIl2 != this.lIIIIllIIlIlIllIIIlIllIlI && lllIllIllIlIllIlIIllllIIl2 != this.IlllIllIlIIIIlIIlIIllIIIl) continue;
                lllIllIllIlIllIlIIllllIIl2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            }
            GL11.glDisable(3089);
            GL11.glPopMatrix();
        }
        GL11.glPopMatrix();
        if (this.IIIIlIIIlllllllllIlllIlll != -1) {
            if (Mouse.isButtonDown(0)) {
                if (this.IIIIlIIIlllllllllIlllIlll != n && this.IlIllllIIIlIllllIIIIIllII != n2) {
                    Gui.drawRect(n, this.IlIllllIIIlIllllIIIIIllII, (float)n + 1.1538461f * 0.43333334f, n2, -1358888961);
                    Gui.drawRect((float)this.IIIIlIIIlllllllllIlllIlll - 0.4329897f * 1.1547619f, n2, (float)n + 18.2f * 0.027472526f, (float)n2 + 0.121212125f * 4.125f, -1358888961);
                    Gui.drawRect((float)this.IIIIlIIIlllllllllIlllIlll - 0.8666667f * 0.5769231f, this.IlIllllIIIlIllllIIIIIllII, this.IIIIlIIIlllllllllIlllIlll, n2, -1358888961);
                    Gui.drawRect((float)this.IIIIlIIIlllllllllIlllIlll - 0.557971f * 0.8961039f, (float)this.IlIllllIIIlIllllIIIIIllII - 0.3611111f * 1.3846154f, (float)n + 1.2692307f * 0.3939394f, this.IlIllllIIIlIllllIIIIIllII, -1358888961);
                    Gui.drawRect(this.IIIIlIIIlllllllllIlllIlll, this.IlIllllIIIlIllllIIIIIllII, n, n2, 0x1F00FFFF);
                }
            } else {
                this.CBDragCache.clear();
                for (CBModule cBModule4 : this.IlllIIlllIIIIllIIllllIlIl) {
                    int n10;
                    int n11;
                    if (cBModule4.getGuiAnchor() == null || !cBModule4.isEnabled() || cBModule4.getName().contains("Zans") && CBClient.getInstance().getModuleManager().minmap.lIIIIlIIllIIlIIlIIIlIIllI().getMapOptions().hide) continue;
                    float[] arrf = cBModule4.getScaledPoints(scaledResolution, true);
                    float f14 = f4 / (Float) cBModule4.scale.getValue();
                    object = new Rectangle((int)(arrf[0] * ((Float)cBModule4.scale.getValue()).floatValue() - 2.0f), (int)(arrf[1] * ((Float)cBModule4.scale.getValue()).floatValue() - 2.0f), (int)(cBModule4.width * ((Float)cBModule4.scale.getValue()).floatValue() + (float)4), (int)(cBModule4.height * ((Float)cBModule4.scale.getValue()).floatValue() + (float)4));
                    if (!((Rectangle)object).intersects(new Rectangle(n11 = Math.min(this.IIIIlIIIlllllllllIlllIlll, n), n10 = Math.min(this.IlIllllIIIlIllllIIIIIllII, n2), Math.max(this.IIIIlIIIlllllllllIlllIlll, n) - n11, Math.max(this.IlIllllIIIlIllllIIIIIllII, n2) - n10))) continue;
                    f3 = (float)n - cBModule4.getXTranslation();
                    f2 = (float)n2 - cBModule4.getYTranslation();
                    this.CBDragCache.add(new CBDragCache(cBModule4, f3, f2));
                }
                this.IIIIlIIIlllllllllIlllIlll = -1;
                this.IlIllllIIIlIllllIIIIIllII = -1;
            }
        }
        if (this.lIIIIIIIIIlIllIIllIlIIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2) && (this.lIIIIllIIlIlIllIIIlIllIlI == null || !this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2))) {
            this.lIIIIIIIIIlIllIIllIlIIlIl(f4);
        }
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl(float f) {
        GL11.glPushMatrix();
        GL11.glTranslatef(4, (float)this.height - (float)185 * f, 0.0f);
        GL11.glScalef(f, f, f);
        Gui.drawRect(0.0f, 0.0f, 240, 140, -1895825408);
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString("Shortcuts & Movement", 4, 2.0f, -1);
        Gui.drawRect(4, 12, 234, 2.5815217f * 4.8421054f, 0x4FFFFFFF);
        int n = 16;
        this.lIIIIlIIllIIlIIlIIIlIIllI("Mouse1", 6, n);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| " + EnumChatFormatting.LIGHT_PURPLE + "HOLD" + EnumChatFormatting.LIGHT_PURPLE + " Add mods to selected region", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Mouse1", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| " + EnumChatFormatting.LIGHT_PURPLE + "HOLD" + EnumChatFormatting.LIGHT_PURPLE + " Select & drag mods", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Mouse2", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| " + EnumChatFormatting.LIGHT_PURPLE + "CLICK" + EnumChatFormatting.LIGHT_PURPLE + " Reset mod to closest position", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Mouse2", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| " + EnumChatFormatting.LIGHT_PURPLE + "HOLD" + EnumChatFormatting.LIGHT_PURPLE + " Don't lock mods while dragging", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("CTRL", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("+", 30, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Mouse1", 36, n);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| Toggle (multiple) mod selection", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("CTRL", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("+", 30, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Z", 36, n);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| Undo mod movements", 80, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("CTRL", 6, n += 12);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("+", 30, (float)n, -1);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Y", 36, n);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| Redo mod movements", 80, (float)n, -1);
        n = 112;
        this.lIIIIlIIllIIlIIlIIIlIIllI("Up", 31, n);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Left", 6, n += 12);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Down", 26, n);
        this.lIIIIlIIllIIlIIlIIIlIIllI("Right", 51, n);
        CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString("| Move selected mod with precision", 80, (float)n, -1);
        GL11.glPopMatrix();
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(String string, int n, int n2) {
        CBFontRenderer lIlIllIlIlIIIllllIlIllIll2 = CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII;
        float f = lIlIllIlIlIIIllllIlIllIll2.getStringWidth(string);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, (float)n + f + (float)4, n2 + 10, (double)2, -1073741825);
        lIlIllIlIlIIIllllIlIllIll2.drawString(string, n + 2, (float)n2, -16777216);
    }

    @Override
    public void mouseMovedOrUp(int n, int n2, int n3) {
        ScaledResolution scaledResolution = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
        if (this.lIIIIllIIlIlIllIIIlIllIlI != null && this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        } else {
            CBModule iterator;
            if (!(IllIIlllIllIlIllIlIIIIIII != null && this.IlIlIIIlllllIIIlIlIlIllII || (iterator = this.lIIIIlIIllIIlIIlIIIlIIllI(scaledResolution, n, n2)) == null)) {
                boolean bl;
                float[] arrf = iterator.getScaledPoints(scaledResolution, true);
                boolean bl2 = !iterator.getSettingsList().isEmpty() && (float)n >= arrf[0] * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n <= (arrf[0] + (float)10) * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n2 >= (arrf[1] + ((CBModule)iterator).height - (float)10) * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + ((CBModule)iterator).height + 2.0f) * ((Float)((CBModule)iterator).scale.getValue()).floatValue();
                boolean bl3 = bl = (float)n > (arrf[0] + iterator.width - (float)10) * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n < (arrf[0] + ((CBModule)iterator).width + 2.0f) * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n2 > (arrf[1] + ((CBModule)iterator).height - (float)10) * ((Float)((CBModule)iterator).scale.getValue()).floatValue() && (float)n2 < (arrf[1] + ((CBModule)iterator).height + 2.0f) * ((Float)((CBModule)iterator).scale.getValue()).floatValue();
                if (bl2) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                    ((lIlIIllIIIlllIIllIIlIIllI)this.IIIIllIIllIIIIllIllIIIlIl).llIlIIIlIIIIlIlllIlIIIIll = false;
                    ((lIlIIllIIIlllIIllIIlIIllI)this.IIIIllIIllIIIIllIllIIIlIl).IIIlIIllllIIllllllIlIIIll = iterator;
                    this.IlllIllIlIIIIlIIlIIllIIIl = this.IIIIllIIllIIIIllIllIIIlIl;
                } else if (bl) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                    iterator.setState(false);
                }
                return;
            }
            for (Object object : this.IlllIIlllIIIIllIIllllIlIl) {
                CBGuiAnchor cBGuiAnchor;
                DELETE_ME_D dELETE_ME_D;
                boolean bl;
                if (((CBModule)object).getGuiAnchor() == null || !((CBModule)object).isEnabled() || object == CBClient.getInstance().getModuleManager().minmap) continue;
                float[] arrf = ((CBModule)object).getScaledPoints(scaledResolution, true);
                boolean bl4 = (float)n > arrf[0] * (Float) ((CBModule) object).scale.getValue() && (float)n < (arrf[0] + ((CBModule)object).width) * (Float) ((CBModule) object).scale.getValue() && (float)n2 > arrf[1] * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 < (arrf[1] + ((CBModule)object).height) * ((Float)((CBModule)object).scale.getValue()).floatValue();
                boolean bl5 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == object && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.lIIIIIIIIIlIllIIllIlIIlIl || !bl4 && (float)n >= (arrf[0] + ((CBModule)object).width - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n <= (arrf[0] + ((CBModule)object).width + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 >= (arrf[1] - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue();
                boolean bl6 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == object && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.IlllIIIlIlllIllIlIIlllIlI || !bl4 && (float)n >= (arrf[0] - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n <= (arrf[0] + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 >= (arrf[1] + ((CBModule)object).height - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + ((CBModule)object).height + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue();
                boolean bl7 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == object && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.lIIIIlIIllIIlIIlIIIlIIllI || !bl4 && (float)n >= (arrf[0] - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n <= (arrf[0] + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 >= (arrf[1] - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue();
                boolean bl8 = bl = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == object && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.IIIIllIlIIIllIlllIlllllIl || !bl4 && (float)n >= (arrf[0] + ((CBModule)object).width - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n <= (arrf[0] + ((CBModule)object).width + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 >= (arrf[1] + ((CBModule)object).height - (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + ((CBModule)object).height + (float)5) * ((Float)((CBModule)object).scale.getValue()).floatValue();
                if (this.IIIIlIIIlllllllllIlllIlll != -1 || !bl5 && !bl6 && !bl7 && !bl) continue;
                if (bl5) {
                    dELETE_ME_D = DELETE_ME_D.lIIIIIIIIIlIllIIllIlIIlIl;
                    cBGuiAnchor = CBGuiAnchor.LEFT_BOTTOM;
                } else if (bl6) {
                    dELETE_ME_D = DELETE_ME_D.IlllIIIlIlllIllIlIIlllIlI;
                    cBGuiAnchor = CBGuiAnchor.RIGHT_TOP;
                } else if (bl7) {
                    dELETE_ME_D = DELETE_ME_D.lIIIIlIIllIIlIIlIIIlIIllI;
                    cBGuiAnchor = CBGuiAnchor.RIGHT_BOTTOM;
                } else {
                    dELETE_ME_D = DELETE_ME_D.IIIIllIlIIIllIlllIlllllIl;
                    cBGuiAnchor = CBGuiAnchor.LEFT_TOP;
                }
                if (this.lIIIIIIIIIlIllIIllIlIIlIl(scaledResolution, n, n2)) continue;
                if (n3 == 0) {
                    this.lIIIIlllIIlIlllllIlIllIII.add(new IIlIlllIllIlIlIIIIIlllIll(this, this.CBDragCache));
                    this.llIlIlIllIlIIlIlllIllIIlI = new IlIIllIIIlllIIIIlIIIIlIll(this, (CBModule)object, dELETE_ME_D, n, n2);
                    this.lIIIIlIIllIIlIIlIIIlIIllI((CBModule)object, cBGuiAnchor, n, n2, scaledResolution);
                } else if (n3 == 1) {
                    CBGuiAnchor cBGuiAnchor2 = ((CBModule)object).getGuiAnchor();
                    this.lIIIIlIIllIIlIIlIIIlIIllI((CBModule)object, cBGuiAnchor, n, n2, scaledResolution);
                    ((CBModule)object).scale.setValue(1.0f);
                    this.lIIIIlIIllIIlIIlIIIlIIllI((CBModule)object, cBGuiAnchor2, n, n2, scaledResolution);
                }
                return;
            }
            if (IllIIlllIllIlIllIlIIIIIII == null) {
                if (this.IllllIllllIlIIIlIIIllllll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                    this.IlIIIIllIIIIIlllIIlIIlllI = !this.IlIIIIllIIIIIlllIIlIIlllI;
                }
                this.IlllIIIlIlllIllIlIIlllIlI(n, n2, n3);
                this.lIIIIlIIllIIlIIlIIIlIIllI(scaledResolution, n, n2, n3);
            }
            for (Object object : this.lIlIlIllIIIIIIIIllllIIllI) {
                if (!((IlIIlllIlIIIlIIIlIlIlIlIl)object).lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) continue;
                return;
            }
            boolean bl = this.lIIIIIIIIIlIllIIllIlIIlIl(scaledResolution, n, n2);
            if (bl) {
                return;
            }
            if (!this.CBDragCache.isEmpty()) {
                this.CBDragCache.clear();
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            }
            this.IIIIlIIIlllllllllIlllIlll = n;
            this.IlIllllIIIlIllllIIIIIllII = n2;
        }
        if (!this.CBDragCache.isEmpty()) {
            this.llIlIlIlllIlllllIIIllIIll = 0;
        }
    }

    @Override
    public void handleMouseInput() {
        super.handleMouseInput();
        int n = Mouse.getEventDWheel();
        if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n);
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule, CBGuiAnchor cBGuiAnchor, int n, int n2, ScaledResolution scaledResolution) {
        if (cBGuiAnchor != cBModule.getGuiAnchor()) {
            float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
            cBModule.setAnchor(cBGuiAnchor);
            float[] arrf2 = cBModule.getScaledPoints(scaledResolution, false);
            cBModule.setTranslations(arrf[0] * (Float) cBModule.scale.getValue() - arrf2[0] * (Float) cBModule.scale.getValue(), arrf[1] * ((Float)cBModule.scale.getValue()).floatValue() - arrf2[1] * ((Float)cBModule.scale.getValue()).floatValue());
        }
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        ScaledResolution scaledResolution = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
        if (this.llIlIlIllIlIIlIlllIllIIlI != null && n3 == 0) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI, this.llIlIlIllIlIIlIlllIllIIlI.IlllIllIlIIIIlIIlIIllIIIl, n, n2, scaledResolution);
            this.llIlIlIllIlIIlIlllIllIIlI = null;
        }
        if (IllIIlllIllIlIllIlIIIIIII != null && n3 == 0) {
            if (this.IlIlIIIlllllIIIlIlIlIllII) {
                for (CBDragCache CBDragCache : this.CBDragCache) {
                    CBGuiAnchor cBGuiAnchor = CBAnchorHelper.getAnchor(n, n2, scaledResolution);
                    if (cBGuiAnchor == CBGuiAnchor.MIDDLE_MIDDLE || cBGuiAnchor == CBDragCache.module.getGuiAnchor() || !this.IlIlIIIlllllIIIlIlIlIllII) continue;
                    this.lIIIIlIIllIIlIIlIIIlIIllI(CBDragCache.module, cBGuiAnchor, n, n2, scaledResolution);
                    CBDragCache.x = (float)n - CBDragCache.module.getXTranslation();
                    CBDragCache.y = (float)n2 - CBDragCache.module.getYTranslation();
                }
                if (this.getDragCache(IllIIlllIllIlIllIlIIIIIII) == null) {
                    Object object = IllIIlllIllIlIllIlIIIIIII.getScaledPoints(scaledResolution, true);
                    float f = (float)n - IllIIlllIllIlIllIlIIIIIII.getXTranslation();
                    float f2 = (float)n2 - IllIIlllIllIlIllIlIIIIIII.getYTranslation();
                    this.CBDragCache.add(new CBDragCache(IllIIlllIllIlIllIlIIIIIII, f, f2));
                }
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                IllIIlllIllIlIllIlIIIIIII = null;
            } else {
                IllIIlllIllIlIllIlIIIIIII = null;
            }
        }
    }

    @Override
    public void keyTyped(char c, int n) {
        if (n == 1) {
            CBClient.getInstance().configManager.write();
        }
        super.keyTyped(c, n);
        if (n == 44 && CBModulesGui.llIlIIIllIIIIlllIlIIIIIlI()) {
            if (!this.lIIIIlllIIlIlllllIlIllIII.isEmpty()) {
                int n2 = this.lIIIIlllIIlIlllllIlIllIII.size() - 1;
                IIlIlllIllIlIlIIIIIlllIll iIlIlllIllIlIlIIIIIlllIll = this.lIIIIlllIIlIlllllIlIllIII.get(this.lIIIIlllIIlIlllllIlIllIII.size() - 1);
                for (int i = 0; i < iIlIlllIllIlIlIIIIIlllIll.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                    CBModule cBModule = (CBModule)iIlIlllIllIlIlIIIIIlllIll.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
                    float f = ((Float)iIlIlllIllIlIlIIIIIlllIll.IlllIIIlIlllIllIlIIlllIlI.get(i)).floatValue();
                    float f2 = ((Float)iIlIlllIllIlIlIIIIIlllIll.IIIIllIlIIIllIlllIlllllIl.get(i)).floatValue();
                    CBGuiAnchor cBGuiAnchor = (CBGuiAnchor) iIlIlllIllIlIlIIIIIlllIll.lIIIIIIIIIlIllIIllIlIIlIl.get(i);
                    Float f3 = (Float)iIlIlllIllIlIlIIIIIlllIll.IIIIllIIllIIIIllIllIIIlIl.get(i);
                    cBModule.setAnchor(cBGuiAnchor);
                    cBModule.setTranslations(f, f2);
                    cBModule.scale.setValue(f3);
                }
                if (this.lIIIlllIlIlllIIIIIIIIIlII.size() > 50) {
                    this.lIIIlllIlIlllIIIIIIIIIlII.remove(0);
                }
                this.lIIIlllIlIlllIIIIIIIIIlII.add(iIlIlllIllIlIlIIIIIlllIll);
                this.lIIIIlllIIlIlllllIlIllIII.remove(n2);
            }
        } else if (n == 21 && CBModulesGui.llIlIIIllIIIIlllIlIIIIIlI()) {
            if (!this.lIIIlllIlIlllIIIIIIIIIlII.isEmpty()) {
                int n3 = this.lIIIlllIlIlllIIIIIIIIIlII.size() - 1;
                IIlIlllIllIlIlIIIIIlllIll iIlIlllIllIlIlIIIIIlllIll = this.lIIIlllIlIlllIIIIIIIIIlII.get(this.lIIIlllIlIlllIIIIIIIIIlII.size() - 1);
                for (int i = 0; i < iIlIlllIllIlIlIIIIIlllIll.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                    CBModule cBModule = (CBModule)iIlIlllIllIlIlIIIIIlllIll.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
                    float f = (Float) iIlIlllIllIlIlIIIIIlllIll.IlllIIIlIlllIllIlIIlllIlI.get(i);
                    float f4 = (Float) iIlIlllIllIlIlIIIIIlllIll.IIIIllIlIIIllIlllIlllllIl.get(i);
                    CBGuiAnchor cBGuiAnchor = (CBGuiAnchor) iIlIlllIllIlIlIIIIIlllIll.lIIIIIIIIIlIllIIllIlIIlIl.get(i);
                    Float f5 = (Float)iIlIlllIllIlIlIIIIIlllIll.IIIIllIIllIIIIllIllIIIlIl.get(i);
                    cBModule.setAnchor(cBGuiAnchor);
                    cBModule.setTranslations(f, f4);
                    cBModule.scale.setValue(f5);
                }
                if (this.lIIIlllIlIlllIIIIIIIIIlII.size() > 50) {
                    this.lIIIlllIlIlllIIIIIIIIIlII.remove(0);
                }
                this.lIIIIlllIIlIlllllIlIllIII.add(iIlIlllIllIlIlIIIIIlllIll);
                this.lIIIlllIlIlllIIIIIIIIIlII.remove(n3);
            }
        } else {
            this.llIlIlIlllIlllllIIIllIIll = 0;
            for (CBDragCache CBDragCache : this.CBDragCache) {
                CBModule cBModule = CBDragCache.module;
                if (cBModule == null) continue;
                switch (n) {
                    case 203: {
                        cBModule.setTranslations(cBModule.getXTranslation() - 1.0f, cBModule.getYTranslation());
                        break;
                    }
                    case 205: {
                        cBModule.setTranslations(cBModule.getXTranslation() + 1.0f, cBModule.getYTranslation());
                        break;
                    }
                    case 200: {
                        cBModule.setTranslations(cBModule.getXTranslation(), cBModule.getYTranslation() - 1.0f);
                        break;
                    }
                    case 208: {
                        cBModule.setTranslations(cBModule.getXTranslation(), cBModule.getYTranslation() + 1.0f);
                    }
                }
            }
        }
    }

    private void IlllIIIlIlllIllIlIIlllIlI(float f) {
        for (CBDragCache CBDragCache : this.CBDragCache) {
            CBDragCache.module.setTranslations(CBDragCache.module.getXTranslation() + f, CBDragCache.module.getYTranslation());
        }
    }

    private void IIIIllIlIIIllIlllIlllllIl(float f) {
        for (CBDragCache CBDragCache : this.CBDragCache) {
            CBDragCache.module.setTranslations(CBDragCache.module.getXTranslation(), CBDragCache.module.getYTranslation() + f);
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(ScaledResolution scaledResolution, int n, int n2, int n3) {
        for (CBModule cBModule : this.IlllIIlllIIIIllIIllllIlIl) {
            boolean bl;
            float[] arrf;
            boolean bl2;
            if (cBModule.getGuiAnchor() == null || !cBModule.isEnabled() || cBModule.getName().contains("Zans") && CBClient.getInstance().getModuleManager().minmap.lIIIIlIIllIIlIIlIIIlIIllI().getMapOptions().hide) continue;
            float f = cBModule.width;
            float f2 = cBModule.height;
            float f3 = 18;
            if (f < f3) {
                cBModule.width = f3;
            }
            if (f2 < (float)18) {
                cBModule.height = 18;
            }
            if (!(bl2 = (float)n > (arrf = cBModule.getScaledPoints(scaledResolution, true))[0] * (Float) cBModule.scale.getValue() && (float)n < (arrf[0] + cBModule.width) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > arrf[1] * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (arrf[1] + cBModule.height) * ((Float)cBModule.scale.getValue()).floatValue())) continue;
            boolean bl3 = !cBModule.getSettingsList().isEmpty() && (float)n >= arrf[0] * (Float) cBModule.scale.getValue() && (float)n <= (arrf[0] + (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (arrf[1] + cBModule.height - (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + cBModule.height + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue();
            boolean bl4 = bl = (float)n > (arrf[0] + cBModule.width - (float)10) * (Float) cBModule.scale.getValue() && (float)n < (arrf[0] + cBModule.width + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > (arrf[1] + cBModule.height - (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (arrf[1] + cBModule.height + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue();
            if (n3 == 0 && !bl3 && !bl && cBModule != CBClient.getInstance().getModuleManager().minmap) {
                boolean bl5 = true;
                if (this.getDragCache(cBModule) != null) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl(cBModule);
                    bl5 = false;
                }
                float f4 = (float)n - cBModule.getXTranslation() * (Float) cBModule.scale.getValue();
                float f5 = (float)n2 - cBModule.getYTranslation() * (Float) cBModule.scale.getValue();
                this.IIlIIllIIIllllIIlllIllIIl = n;
                this.lllIlIIllllIIIIlIllIlIIII = n2;
                this.IlIlIIIlllllIIIlIlIlIllII = false;
                IllIIlllIllIlIllIlIIIIIII = cBModule;
                if (this.getDragCache(cBModule) == null) {
                    if (!CBModulesGui.llIlIIIllIIIIlllIlIIIIIlI() && bl5) {
                        this.CBDragCache.clear();
                    }
                    if (bl5 || !CBModulesGui.llIlIIIllIIIIlllIlIIIIIlI()) {
                        this.CBDragCache.add(new CBDragCache(cBModule, f4, f5));
                    }
                }
                this.IlllIIIlIlllIllIlIIlllIlI(scaledResolution, n, n2);
            }
            if (!(n3 != 0 || this.lIIIIllIIlIlIllIIIlIllIlI != null && this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2))) {
                if (bl3) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                    ((lIlIIllIIIlllIIllIIlIIllI)this.IIIIllIIllIIIIllIllIIIlIl).llIlIIIlIIIIlIlllIlIIIIll = false;
                    ((lIlIIllIIIlllIIllIIlIIllI)this.IIIIllIIllIIIIllIllIIIlIl).IIIlIIllllIIllllllIlIIIll = cBModule;
                    this.IlllIllIlIIIIlIIlIIllIIIl = this.IIIIllIIllIIIIllIllIIIlIl;
                } else if (bl) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                    cBModule.setState(false);
                }
            } else if (n3 == 1) {
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                float[] arrf2 = CBAnchorHelper.getPositions(cBModule.getGuiAnchor());
                cBModule.setTranslations(arrf2[0], arrf2[1]);
            }
            if (cBModule == CBClient.getInstance().getModuleManager().minmap) continue;
            break;
        }
    }

    private static boolean llIlIIIllIIIIlllIlIIIIIlI() {
        return true; // ?????????????????
    }

    private void IlllIIIlIlllIllIlIIlllIlI(int n, int n2, int n3) {
        for (llllIIIIIlIlIlIlIllIIIIII llllIIIIIlIlIlIlIllIIIIII2 : this.lIlIlIllIIIIIIIIllllIIllI) {
            if (n3 != 0 || !llllIIIIIlIlIlIlIllIIIIII2.lIIIIlIIllIIlIIlIIIlIIllI(n, n2) || IlIlllIIIIllIllllIllIIlIl) continue;
            if (llllIIIIIlIlIlIlIllIIIIII2.lIIIIllIIlIlIllIIIlIllIlI != null && this.lIIIIllIIlIlIllIIIlIllIlI != llllIIIIIlIlIlIlIllIIIIII2.lIIIIllIIlIlIllIIIlIllIlI && this.IlllIllIlIIIIlIIlIIllIIIl == null) {
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.IlllIllIlIIIIlIIlIIllIIIl = llllIIIIIlIlIlIlIllIIIIII2.lIIIIllIIlIlIllIIIlIllIlI;
                continue;
            }
            if (llllIIIIIlIlIlIlIllIIIIII2.lIIIIllIIlIlIllIIIlIllIlI == null || this.IlllIllIlIIIIlIIlIIllIIIl != null) continue;
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            IlIlllIIIIllIllllIllIIlIl = true;
        }
    }

    private CBModule lIIIIlIIllIIlIIlIIIlIIllI(ScaledResolution scaledResolution, int n, int n2) {
        for (CBModule cBModule : this.IlllIIlllIIIIllIIllllIlIl) {
            boolean bl;
            if (cBModule.getGuiAnchor() == null) continue;
            float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
            boolean bl2 = !cBModule.getSettingsList().isEmpty() && (float)n >= arrf[0] * ((Float)cBModule.scale.getValue()).floatValue() && (float)n <= (arrf[0] + (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (arrf[1] + cBModule.height - (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (arrf[1] + cBModule.height + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue();
            boolean bl3 = bl = (float)n > (arrf[0] + cBModule.width - (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n < (arrf[0] + cBModule.width + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > (arrf[1] + cBModule.height - (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (arrf[1] + cBModule.height + 2.0f) * ((Float)cBModule.scale.getValue()).floatValue();
            if (!bl && !bl2) continue;
            return cBModule;
        }
        return null;
    }

    private boolean lIIIIIIIIIlIllIIllIlIIlIl(ScaledResolution scaledResolution, int n, int n2) {
        boolean bl = false;
        for (CBModule cBModule : this.IlllIIlllIIIIllIIllllIlIl) {
            if (cBModule.getGuiAnchor() == null) continue;
            float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
            boolean bl2 = (float)n > arrf[0] * ((Float)cBModule.scale.getValue()).floatValue() && (float)n < (arrf[0] + cBModule.width) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > arrf[1] * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (arrf[1] + cBModule.height) * ((Float)cBModule.scale.getValue()).floatValue();
            bl = bl || bl2;
        }
        return bl;
    }

    private boolean lIIIIlIIllIIlIIlIIIlIIllI(float f, CBModule cBModule, ScaledResolution scaledResolution, int n, int n2, boolean bl) {
        int n3;
        int n4;
        int n5;
        int n6;
        float[] object;
        boolean bl2;
        if (cBModule.getGuiAnchor() == null || !cBModule.isEnabled() || cBModule == CBClient.getInstance().getModuleManager().minmap || !cBModule.alwaysTrue && !cBModule.isRenderHud()) {
            return true;
        }
        boolean bl3 = false;
        float f2 = 18;
        if (cBModule.width < f2) {
            cBModule.width = (int)f2;
        }
        if (cBModule.height < (float)18) {
            cBModule.height = 18;
        }
        GL11.glPushMatrix();
        float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
        cBModule.scaleAndTranslate(scaledResolution);
        boolean bl4 = bl2 = this.IIIIlIIIlllllllllIlllIlll != -1;
        if (bl2) {
            Rectangle rectangle1 = new Rectangle((int)(arrf[0] * (Float) cBModule.scale.getValue() - 2.0f), (int)(arrf[1] * ((Float)cBModule.scale.getValue()).floatValue() - 2.0f), (int)(cBModule.width * ((Float)cBModule.scale.getValue()).floatValue() + (float)4), (int)(cBModule.height * ((Float)cBModule.scale.getValue()).floatValue() + (float)4));
            n6 = Math.min(this.IIIIlIIIlllllllllIlllIlll, n);
            n5 = Math.min(this.IlIllllIIIlIllllIIIIIllII, n2);
            n4 = Math.max(this.IIIIlIIIlllllllllIlllIlll, n) - n6;
            n3 = Math.max(this.IlIllllIIIlIllllIIIIIllII, n2) - n5;
            Rectangle rectangle = new Rectangle(n6, n5, n4, n3);
            bl2 = rectangle1.intersects(rectangle);
        }
        int n7 = n6 = (float)n > (object = cBModule.getScaledPoints(scaledResolution, true))[0] * (Float) cBModule.scale.getValue() && (float)n < (object[0] + cBModule.width) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > object[1] * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (object[1] + cBModule.height) * ((Float)cBModule.scale.getValue()).floatValue() ? 1 : 0;
        if (!this.IlIIIIllIIIIIlllIIlIIlllI) {
            if (this.getDragCache(cBModule) != null || bl2) {
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, cBModule.width, cBModule.height, 2.064516f * 0.2421875f, -1627324417, 0x1AFFFFFF);
            } else {
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, cBModule.width, cBModule.height, 1.2179487f * 0.41052634f, 0x6FFFFFFF, 0x1AFFFFFF);
            }
        }
        if (!this.IlIIIIllIIIIIlllIIlIIlllI && n6 != 0) {
            n5 = !cBModule.getSettingsList().isEmpty() && (float)n >= (object[0] + 2.0f) * (Float) cBModule.scale.getValue() && (float)n <= (object[0] + (float)10) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (object[1] + cBModule.height - (float)8) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (object[1] + cBModule.height - 2.0f) * ((Float)cBModule.scale.getValue()).floatValue() ? 1 : 0;
            int n8 = n4 = (float)n > (object[0] + cBModule.width - (float)10) * (Float) cBModule.scale.getValue() && (float)n < (object[0] + cBModule.width - 2.0f) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 > (object[1] + cBModule.height - (float)8) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 < (object[1] + cBModule.height - 2.0f) * ((Float)cBModule.scale.getValue()).floatValue() ? 1 : 0;
            if (!cBModule.getSettingsList().isEmpty()) {
                GL11.glColor4f(1.0f, 1.0f, 1.0f, n5 != 0 ? 1.0f : 0.20895523f * 2.8714287f);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.lIllIlIlllIIlIIllIIlIIlII, (float)3, 2.0f, cBModule.height - 2.162162f * 3.4687502f);
            }
            GL11.glColor4f(1.2952381f * 0.61764705f, 0.4181818f * 0.47826087f, 0.09268292f * 2.1578948f, n4 != 0 ? 1.0f : 2.025f * 0.2962963f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIlIlIIIlllIIlIllllll, (float)3, cBModule.width - (float)8, cBModule.height - 0.2972973f * 25.227272f);
        }
        GL11.glPushMatrix();
        float f3 = f / (Float) cBModule.scale.getValue();
        GL11.glScalef(f3, f3, f3);
        if (bl) {
            n4 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == cBModule && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.lIIIIIIIIIlIllIIllIlIIlIl || n6 == 0 && (float)n >= (object[0] + cBModule.width - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n <= (object[0] + cBModule.width + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (object[1] - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (object[1] + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() ? 1 : 0;
            n3 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == cBModule && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.IlllIIIlIlllIllIlIIlllIlI || n6 == 0 && (float)n >= (object[0] - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n <= (object[0] + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (object[1] + cBModule.height - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (object[1] + cBModule.height + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() ? 1 : 0;
            boolean bl5 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == cBModule && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.lIIIIlIIllIIlIIlIIIlIIllI || n6 == 0 && (float)n >= (object[0] - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n <= (object[0] + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (object[1] - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (object[1] + (float)5) * ((Float)cBModule.scale.getValue()).floatValue();
            boolean bl6 = this.llIlIlIllIlIIlIlllIllIIlI != null && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIlIIllIIlIIlIIIlIIllI == cBModule && this.llIlIlIllIlIIlIlllIllIIlI.lIIIIllIIlIlIllIIIlIllIlI == DELETE_ME_D.IIIIllIlIIIllIlllIlllllIl || n6 == 0 && (float)n >= (object[0] + cBModule.width - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n <= (object[0] + cBModule.width + (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 >= (object[1] + cBModule.height - (float)5) * ((Float)cBModule.scale.getValue()).floatValue() && (float)n2 <= (object[1] + cBModule.height + (float)5) * ((Float)cBModule.scale.getValue()).floatValue();
            GL11.glPushMatrix();
            float f4 = 4;
            if (this.IIIIlIIIlllllllllIlllIlll == -1 && bl5) {
                GL11.glTranslatef(0.0f, 0.0f, 0.0f);
                Gui.drawRect(-f4 / 2.0f, -f4 / 2.0f, f4 / 2.0f, f4 / 2.0f, -16711936);
            }
            if (this.IIIIlIIIlllllllllIlllIlll == -1 && n4 != 0) {
                GL11.glTranslatef(cBModule.width / f3, 0.0f, 0.0f);
                Gui.drawRect(-f4 / 2.0f, -f4 / 2.0f, f4 / 2.0f, f4 / 2.0f, -16711936);
            }
            if (this.IIIIlIIIlllllllllIlllIlll == -1 && bl6) {
                GL11.glTranslatef(cBModule.width / f3, cBModule.height / f3, 0.0f);
                Gui.drawRect(-f4 / 2.0f, -f4 / 2.0f, f4 / 2.0f, f4 / 2.0f, -16711936);
            }
            if (this.IIIIlIIIlllllllllIlllIlll == -1 && n3 != 0) {
                GL11.glTranslatef(0.0f, cBModule.height / f3, 0.0f);
                Gui.drawRect(-f4 / 2.0f, -f4 / 2.0f, f4 / 2.0f, f4 / 2.0f, -16711936);
            }
            GL11.glPopMatrix();
            bl3 = this.IIIIlIIIlllllllllIlllIlll == -1 && (bl5 || n4 != 0 || n3 != 0 || bl6);
        }
        n4 = arrf[1] - CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getHeight() - (float)6 < 0.0f ? 1 : 0;
        float f5 = n4 != 0 ? cBModule.height * (Float) cBModule.scale.getValue() / f : (float)(-CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getHeight() - 4);
        switch (cBModule.getPosition()) {
            case LEFT: {
                float f6 = 0.0f;
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(cBModule.getName(), f6, (float) f5, -1);
                break;
            }
            case CENTER: {
                float f7 = cBModule.width * (Float) cBModule.scale.getValue() / f / 2.0f;
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(cBModule.getName(), f7, f5, -1);
                break;
            }
            case RIGHT: {
                float f8 = cBModule.width * (Float) cBModule.scale.getValue() / f - (float)CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getStringWidth(cBModule.getName());
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(cBModule.getName(), f8, f5, -1);
            }
        }
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        return !bl3;
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(ScaledResolution scaledResolution) {
        if (!Mouse.isButtonDown(1) && IllIIlllIllIlIllIlIIIIIII != null) {
            for (CBDragCache CBDragCache : this.CBDragCache) {
                if (CBDragCache.module != IllIIlllIllIlIllIlIIIIIII || !(Boolean) CBClient.getInstance().getGlobalSettings().snapModules.getValue()) continue;
                Object var5_5 = null;
                for (CBModule cBModule : this.IlllIIlllIIIIllIIllllIlIl) {
                    if (this.getDragCache(cBModule) != null || cBModule.getGuiAnchor() == null || !cBModule.isEnabled() || cBModule == CBClient.getInstance().getModuleManager().minmap || !cBModule.alwaysTrue && !cBModule.isRenderHud() || var5_5 != null && var5_5 != cBModule) continue;
                    float f = 18;
                    if (cBModule.width < f) {
                        cBModule.width = (int)f;
                    }
                    if (cBModule.height < (float)18) {
                        cBModule.height = 18;
                    }
                    if (CBDragCache.module.width < f) {
                        CBDragCache.module.width = (int)f;
                    }
                    if (CBDragCache.module.height < (float)18) {
                        CBDragCache.module.height = 18;
                    }
                    float[] arrf = cBModule.getScaledPoints(scaledResolution, true);
                    float[] arrf2 = CBDragCache.module.getScaledPoints(scaledResolution, true);
                    boolean bl = false;
                    float f2 = arrf[0] * (Float) cBModule.scale.getValue() - arrf2[0] * (Float) CBDragCache.module.scale.getValue();
                    float f3 = (arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue() - (arrf2[0] + CBDragCache.module.width) * (Float) CBDragCache.module.scale.getValue();
                    float f4 = (arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue() - arrf2[0] * (Float) CBDragCache.module.scale.getValue();
                    float f5 = arrf[0] * (Float) cBModule.scale.getValue() - (arrf2[0] + CBDragCache.module.width) * (Float) CBDragCache.module.scale.getValue();
                    float f6 = arrf[1] * (Float) cBModule.scale.getValue() - arrf2[1] * (Float) CBDragCache.module.scale.getValue();
                    float f7 = (arrf[1] + cBModule.height) * (Float) cBModule.scale.getValue() - (arrf2[1] + CBDragCache.module.height) * (Float) CBDragCache.module.scale.getValue();
                    float f8 = (arrf[1] + cBModule.height) * (Float) cBModule.scale.getValue() - arrf2[1] * (Float) CBDragCache.module.scale.getValue();
                    float f9 = arrf[1] * (Float) cBModule.scale.getValue() - (arrf2[1] + CBDragCache.module.height) * (Float) CBDragCache.module.scale.getValue();
                    int n = 2;
                    if (f2 >= (float)(-n) && f2 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(arrf[0] * (Float) cBModule.scale.getValue() - 0.6666667f * 0.75f, 0.0, arrf[0] * (Float) cBModule.scale.getValue(), this.height, 0.0, -3596854);
                    }
                    if (f3 >= (float)(-n) && f3 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue(), 0.0, (arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue() + 1.7272727f * 0.28947368f, this.height, 0.0, -3596854);
                    }
                    if (f5 >= (float)(-n) && f5 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(arrf[0] * (Float) cBModule.scale.getValue(), 0.0, arrf[0] * (Float) cBModule.scale.getValue() + 0.29775283f * 1.6792452f, this.height, 0.0, -3596854);
                    }
                    if (f4 >= (float)(-n) && f4 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue(), 0.0, (arrf[0] + cBModule.width) * (Float) cBModule.scale.getValue() + 1.5238096f * 0.328125f, this.height, 0.0, -3596854);
                    }
                    if (f6 >= (float)(-n) && f6 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, arrf[1] * (Float) cBModule.scale.getValue(), this.width, arrf[1] * (Float) cBModule.scale.getValue() + 0.3888889f * 1.2857143f, 0.0, -3596854);
                    }
                    if (f7 >= (float)(-n) && f7 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (arrf[1] + cBModule.height) * (Float) cBModule.scale.getValue(), this.width, (arrf[1] + cBModule.height) * (Float) cBModule.scale.getValue() + 0.51724136f * 0.9666667f, 0.0, -3596854);
                    }
                    if (f9 >= (float)(-n) && f9 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, arrf[1] * (Float) cBModule.scale.getValue(), this.width, arrf[1] * (Float) cBModule.scale.getValue() + 0.16666667f * 3.0f, 0.0, -3596854);
                    }
                    if (f8 >= (float)(-n) && f8 <= (float)n) {
                        bl = true;
                        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (arrf[1] + cBModule.height) * ((Float)cBModule.scale.getValue()).floatValue() - 0.5810811f * 0.8604651f, this.width, (arrf[1] + cBModule.height) * ((Float)cBModule.scale.getValue()).floatValue(), 0.0, -3596854);
                    }
                    if (!bl) continue;
                    GL11.glPushMatrix();
                    cBModule.scaleAndTranslate(scaledResolution);
                    RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0f, 0.0f, cBModule.width, cBModule.height, 0.01923077f * 26.0f, 0, 449387978);
                    GL11.glPopMatrix();
                }
            }
        }
    }

    private float lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule, float f, float[] arrf, int n) {
        float f2 = f;
        float padding = 2.0f;
        if (f2 + arrf[0] * (Float) cBModule.scale.getValue() < padding) {
            f2 = -arrf[0] * (Float) cBModule.scale.getValue() + padding;
        } else if (f2 + arrf[0] * (Float) cBModule.scale.getValue() + (float)n > (float)this.width - padding) {
            f2 = (float)this.width - arrf[0] * (Float) cBModule.scale.getValue() - (float)n - padding;
        }
        return f2;
    }

    private float lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule, float f, float[] arrf, int n) {
        float f2 = f;
        float padding = 2.0f;
        if (f2 + arrf[1] * (Float) cBModule.scale.getValue() < padding) {
            f2 = -arrf[1] * (Float) cBModule.scale.getValue() + padding;
        } else if (f2 + arrf[1] * (Float) cBModule.scale.getValue() + (float)n > (float)this.height - padding) {
            f2 = (float)this.height - arrf[1] * (Float) cBModule.scale.getValue() - (float)n - padding;
        }
        return f2;
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(CBDragCache CBDragCache, int n, int n2, ScaledResolution scaledResolution) {
        if (CBDragCache.module.getGuiAnchor() == null || !CBDragCache.module.isEnabled() || CBDragCache.module == CBClient.getInstance().getModuleManager().minmap || !CBDragCache.module.alwaysTrue && !CBDragCache.module.isRenderHud()) {
            return;
        }
        float f = (float)n - CBDragCache.x;
        float f2 = (float)n2 - CBDragCache.y;
        if (!(this.IlIlIIIlllllIIIlIlIlIllII || CBDragCache.module != IllIIlllIllIlIllIlIIIIIII || (float)n == this.IIlIIllIIIllllIIlllIllIIl && (float)n2 == this.lllIlIIllllIIIIlIllIlIIII)) {
            if (this.lIIIIlllIIlIlllllIlIllIII.size() > 50) {
                this.lIIIIlllIIlIlllllIlIllIII.remove(0);
            }
            this.lIIIIlllIIlIlllllIlIllIII.add(new IIlIlllIllIlIlIIIIIlllIll(this, this.CBDragCache));
            CBClient.getInstance().createNewProfile();
            this.IlIlIIIlllllIIIlIlIlIllII = true;
        }
        float[] arrf = CBDragCache.module.getScaledPoints(scaledResolution, false);
        if (!Mouse.isButtonDown(1) && this.IlIlIIIlllllIIIlIlIlIllII && CBDragCache.module == IllIIlllIllIlIllIlIIIIIII) {
            float f3 = f;
            float f4 = f2;
            f = this.lIIIIlIIllIIlIIlIIIlIIllI(CBDragCache.module, f, arrf, (int)(CBDragCache.module.width * (Float) CBDragCache.module.scale.getValue()));
            f2 = this.lIIIIIIIIIlIllIIllIlIIlIl(CBDragCache.module, f2, arrf, (int)(CBDragCache.module.height * (Float) CBDragCache.module.scale.getValue()));
            float f5 = f3 - f;
            float f6 = f4 - f2;
            for (CBDragCache dragCache2 : this.CBDragCache) {
                if (dragCache2 == CBDragCache) continue;
                arrf = dragCache2.module.getScaledPoints(scaledResolution, false);
                float f7 = this.lIIIIlIIllIIlIIlIIIlIIllI(dragCache2.module, dragCache2.module.getXTranslation() - f5, arrf, (int)(dragCache2.module.width * (Float) dragCache2.module.scale.getValue()));
                float f8 = this.lIIIIIIIIIlIllIIllIlIIlIl(dragCache2.module, dragCache2.module.getYTranslation() - f6, arrf, (int)(dragCache2.module.height * (Float) dragCache2.module.scale.getValue()));
                dragCache2.module.setTranslations(f7, f8);
            }
        }
        if (this.IlIlIIIlllllIIIlIlIlIllII) {
            CBDragCache.module.setTranslations(f, f2);
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(int n) {
        if (IlIlllIIIIllIllllIllIIlIl) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, true, n);
            }
        } else if (this.IlllIllIlIIIIlIIlIIllIIIl != null) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI != null) {
                this.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, true, n);
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl, false, n);
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, boolean bl, int n) {
        if (bl) {
            lllIllIllIlIllIlIIllllIIl2.IIIIllIlIIIllIlllIlllllIl = lllIllIllIlIllIlIIllllIIl2.IlIlllIIIIllIllllIllIIlIl;
            IlIlllIIIIllIllllIllIIlIl = false;
            this.lIIIIllIIlIlIllIIIlIllIlI = null;
        } else {
            lllIllIllIlIllIlIIllllIIl2.IIIIllIlIIIllIlllIlllllIl = n / 2 - 185;
            this.IlllIllIlIIIIlIIlIIllIIIl = null;
            this.lIIIIllIIlIlIllIIIlIllIlI = lllIllIllIlIllIlIIllllIIl2;
        }
    }

    public static float lIIIIlIIllIIlIIlIIIlIIllI(float f) {
        float f2 = f / (float)(Minecraft.debugFPS + 1);
        return Math.max(f2, 1.0f);
    }

    private CBDragCache getDragCache(CBModule cBModule) {
        for (CBDragCache CBDragCache : this.CBDragCache) {
            if (cBModule != CBDragCache.module) continue;
            return CBDragCache;
        }
        return null;
    }

    private void IlllIIIlIlllIllIlIIlllIlI(ScaledResolution scaledResolution, int n, int n2) {
        for (CBDragCache CBDragCache : this.CBDragCache) {
            if (CBDragCache.module == null || CBDragCache.module.getGuiAnchor() == null) continue;
            CBDragCache.x = (float)n - CBDragCache.module.getXTranslation();
            CBDragCache.y = (float)n2 - CBDragCache.module.getYTranslation();
        }
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
        this.CBDragCache.removeIf(CBDragCache -> CBDragCache.module == cBModule);
    }

    static {
        IlIlllIIIIllIllllIllIIlIl = false;
    }

}
