package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ColorPickerElement extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;
    private List<IllllllllIlIIIIIIIIllIIII> IllIIIIIIIlIlIllllIIllIII;
    private boolean lIIIIllIIlIlIllIIIlIllIlI = false;
    private boolean IlllIllIlIIIIlIIlIIllIIIl = false;
    private boolean IlIlllIIIIllIllllIllIIlIl = false;
    private boolean llIIlllIIIIlllIllIlIlllIl = false;
    private IllllllllIlIIIIIIIIllIIII lIIlIlIllIIlIIIlIIIlllIII;
    private float IIIlllIIIllIllIlIIIIIIlII = 1.0f;
    private float llIlIIIlIIIIlIlllIlIIIIll = 1.0f;
    private float IIIlIIllllIIllllllIlIIIll;
    private float lllIIIIIlIllIlIIIllllllII;
    private float lIIIIIllllIIIIlIlIIIIlIlI;
    private float IIIIIIlIlIlIllllllIlllIlI;
    private float IllIllIIIlIIlllIIIllIllII;
    private float IlIIlIIIIlIIIIllllIIlIllI;
    private int lIIlIIllIIIIIlIllIIIIllII;
    private int lIIlllIIlIlllllllllIIIIIl;
    private int lIllIllIlIIllIllIlIlIIlIl;
    private int llIlIIIllIIIIlllIlIIIIIlI;

    public ColorPickerElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.lIIlIlIllIIlIIIlIIIlllIII = new IllllllllIlIIIIIIIIllIIII(f, (Integer)cBSetting.getValue(), 1.0f);
        this.IllIIIIIIIlIlIllllIIllIII = new ArrayList();
        for (int i = 0; i < 16; ++i) {
            int n = Minecraft.getMinecraft().fontRenderer.colorCode[i];
            this.IllIIIIIIIlIlIllllIIllIII.add(new IllllllllIlIIIIIIIIllIIII(f, n, 1.0f));
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        String string;
        this.IIIllIllIlIlllllllIlIlIII = this.lIIIIllIIlIlIllIIIlIllIlI ? 130 : 18;
        this.IIIlIIllllIIllllllIlIIIll = this.IIIIllIlIIIllIlllIlllllIl + 56;
        this.lIIIIIllllIIIIlIlIIIIlIlI = this.IIIIllIlIIIllIlllIlllllIl + 176;
        this.lllIIIIIlIllIlIIIllllllII = this.IIIIllIIllIIIIllIllIIIlIl + 25;
        this.IIIIIIlIlIlIllllllIlllIlI = this.IIIIllIIllIIIIllIllIIIlIl + 119;
        this.IllIllIIIlIIlllIIIllIllII = this.lIIIIIllllIIIIlIlIIIIlIlI - this.IIIlIIllllIIllllllIlIIIll;
        this.IlIIlIIIIlIIIIllllIIlIllI = this.IIIIIIlIlIlIllllllIlllIlI - this.lllIIIIIlIllIlIIIllllllII;
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 10, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4), -1895825408);
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.getColorValue();
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 160, this.IIIIllIIllIIIIllIllIIIlIl + 3, 14, 14);
        this.lIIlIlIllIIlIIIlIIIlllIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 186, this.IIIIllIIllIIIIllIllIIIlIl + 16, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 16, this.IIIIllIIllIIIIllIllIIIlIl + 17, 0x7F000000);
        CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString("#", this.IIIIllIlIIIllIlllIlllllIl + 188, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4), -1358954496);
        CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString(Integer.toHexString(this.lIIIIlIIllIIlIIlIIIlIIllI.getColorValue()), this.IIIIllIlIIIllIlllIlllllIl + 194, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4), -1358954496);
        boolean bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 40) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 18 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        string = bl ? "(Favorite)" : "(+)";
        if (CBClient.getInstance().getGlobalSettings().lIIIIlIIllIIlIIlIIIlIIllI((Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue())) {
            string = bl ? "(Un-favorite)" : "(-)";
        }
        CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString(string, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 16 - CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.getStringWidth(string), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4), bl ? -822083584 : -1358954496);
        if (this.lIIIIllIIlIlIllIIIlIllIlI) {
            if (this.IlllIllIlIIIIlIIlIIllIIIl && !Mouse.isButtonDown(0)) {
                this.IlllIllIlIIIIlIIlIIllIIIl = false;
                this.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            if (this.IlIlllIIIIllIllllIllIIlIl && !Mouse.isButtonDown(0)) {
                this.IlIlllIIIIllIllllIllIIlIl = false;
                this.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            if (this.llIIlllIIIIlllIllIlIlllIl && !Mouse.isButtonDown(0)) {
                this.llIIlllIIIIlllIllIlIlllIl = false;
                this.lIIIIIIIIIlIllIIllIlIIlIl();
            }
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 55, this.IIIIllIIllIIIIllIllIIIlIl + 24, this.IIIIllIlIIIllIlllIlllllIl + 177, this.IIIIllIIllIIIIllIllIIIlIl + 120, -822083584);
            Tessellator tessellator = Tessellator.instance;
            GL11.glDisable(3553);
            tessellator.startDrawingQuads();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll, this.IIIIIIlIlIlIllllllIlllIlI, 0.0);
            tessellator.addVertex(this.lIIIIIllllIIIIlIlIIIIlIlI, this.IIIIIIlIlIlIllllllIlllIlI, 0.0);
            tessellator.addVertex(this.lIIIIIllllIIIIlIlIIIIlIlI, this.lllIIIIIlIllIlIIIllllllII, 0.0);
            tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll, this.lllIIIIIlIllIlIIIllllllII, 0.0);
            tessellator.draw();
            int[] arrn = null;
            int n3 = 0;
            while ((float)n3 < this.IllIllIIIlIIlllIIIllIllII) {
                int n4 = 0;
                while ((float)n4 < this.IlIIlIIIIlIIIIllllIIlIllI) {
                    boolean bl2;
                    float f2 = (float)n3 / this.IllIllIIIlIIlllIIIllIllII;
                    float f3 = 1.0f - (float)n4 / this.IlIIlIIIIlIIIIllllIIlIllI;
                    int n5 = (int)this.llIlIIIlIIIIlIlllIlIIIIll << 24 | Color.HSBtoRGB(this.IIIlllIIIllIllIlIIIIIIlII, f2, f3);
                    boolean bl3 = (float)n >= (this.IIIlIIllllIIllllllIlIIIll + (float)n3) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n <= (this.IIIlIIllllIIllllllIlIIIll + (float)n3 + 1.0f) * this.lIIIIIIIIIlIllIIllIlIIlIl;
                    boolean bl4 = (float)n2 <= (this.lllIIIIIlIllIlIIIllllllII + (float)n4 + 1.0f + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII + (float)n4 + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
                    boolean bl5 = bl3 && bl4;
                    boolean bl6 = n3 == 0 && (float)n < this.IIIlIIllllIIllllllIlIIIll * this.lIIIIIIIIIlIllIIllIlIIlIl && bl4;
                    boolean bl7 = n4 == 0 && (float)n2 < (this.lllIIIIIlIllIlIIIllllllII + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && bl3;
                    boolean bl8 = (float)n3 == this.IllIllIIIlIIlllIIIllIllII - 1.0f && (float)n > (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII) * this.lIIIIIIIIIlIllIIllIlIIlIl && bl4;
                    boolean bl9 = bl2 = (float)n4 == this.IlIIlIIIIlIIIIllllIIlIllI - 1.0f && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII + this.IlIIlIIIIlIIIIllllIIlIllI + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && bl3;
                    if (this.IlllIllIlIIIIlIIlIIllIIIl && (bl5 || bl6 || bl7 || bl8 || bl2)) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(n5);
                        this.lIIIIlIIllIIlIIlIIIlIIllI.colorArray = new int[]{n3, n4};
                    }
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI.colorArray != null) {
                        arrn = this.lIIIIlIIllIIlIIlIIIlIIllI.colorArray;
                    } else if (n5 == (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue()) {
                        arrn = new int[]{n3, n4};
                    }
                    tessellator.startDrawingQuads();
                    GL11.glColor4f((float)(n5 >> 16 & 0xFF) / (float)255, (float)(n5 >> 8 & 0xFF) / (float)255, (float)(n5 & 0xFF) / (float)255, 1.0f);
                    tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll + (float)n3, this.lllIIIIIlIllIlIIIllllllII + (float)n4 + 1.0f, 0.0);
                    tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll + (float)n3 + 1.0f, this.lllIIIIIlIllIlIIIllllllII + (float)n4 + 1.0f, 0.0);
                    tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll + (float)n3 + 1.0f, this.lllIIIIIlIllIlIIIllllllII + (float)n4, 0.0);
                    tessellator.addVertex(this.IIIlIIllllIIllllllIlIIIll + (float)n3, this.lllIIIIIlIllIlIIIllllllII + (float)n4, 0.0);
                    tessellator.draw();
                    ++n4;
                }
                ++n3;
            }
            if (arrn != null) {
                GL11.glPushMatrix();
                GL11.glColor4f(0.0f, 0.0f, 0.0f, 3.0f * 0.25f);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIllllIIllllllIlIIIll + (float)arrn[0] + 1.2205882f * 0.913494f, this.lllIIIIIlIllIlIIIllllllII + (float)arrn[1] + 0.097222224f * 11.468572f, 4);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIlIIllllIIllllllIlIIIll + (float)arrn[0] + 0.24193548f * 4.608667f, this.lllIIIIIlIllIlIIIllllllII + (float)arrn[1] + 0.23157895f * 4.8147726f, (double)2.7f * 1.0);
                GL11.glPopMatrix();
            }
            Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll - (float)51, this.lllIIIIIlIllIlIIIllllllII + 1.0f, this.IIIlIIllllIIllllllIlIIIll - (float)43, this.lllIIIIIlIllIlIIIllllllII + (float)9, -16777216);
            Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll - (float)50, this.lllIIIIIlIllIlIIIllllllII + 2.0f, this.IIIlIIllllIIllllllIlIIIll - (float)44, this.lllIIIIIlIllIlIIIllllllII + (float)8, this.lIIIIlIIllIIlIIlIIIlIIllI.rainbow ? -13369549 : -1);
            CBClient.getInstance().IIIlllIIIllIllIlIIIIIIlII.drawString("CHROMA", this.IIIlIIllllIIllllllIlIIIll - (float)40, this.lllIIIIIlIllIlIIIllllllII, -1358954496);
            this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
            this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
            this.lIIlIIllIIIIIlIllIIIIllII = (int)(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)64);
            this.lIIlllIIlIlllllllllIIIIIl = (int)this.lllIIIIIlIllIlIIIllllllII;
            this.lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getGlobalSettings().IlIIlIIlIllIIIIllIIllIlIl, this.lIIlIIllIIIIIlIllIIIIllII, this.lIIlllIIlIlllllllllIIIIIl, n, n2, (int)f);
            this.lIllIllIlIIllIllIlIlIIlIl = (int)(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)94);
            this.llIlIIIllIIIIlllIlIIIIIlI = (int)this.lllIIIIIlIllIlIIIllllllII;
            this.lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getGlobalSettings().lIlIllIlIlIIIllllIlIllIll, this.lIllIllIlIIllIllIlIlIIlIl, this.llIlIIIllIIIIlllIlIIIIIlI, n, n2, (int)f);
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, (int)(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)34), (int)this.lllIIIIIlIllIlIIIllllllII, n, n2, (int)f);
        }
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (CBClient.getInstance().getGlobalSettings().IlIIlIIlIllIIIIllIIllIlIl.size() >= 16) {
            CBClient.getInstance().getGlobalSettings().IlIIlIIlIllIIIIllIIllIlIl.remove(0);
        }
        CBClient.getInstance().getGlobalSettings().IlIIlIIlIllIIIIllIIllIlIl.add(new IllllllllIlIIIIIIIIllIIII(this.lIIIIIIIIIlIllIIllIlIIlIl, (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), 1.0f));
        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl(int n, int n2) {
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)18, this.lllIIIIIlIllIlIIIllllllII - 1.0f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)28, this.lllIIIIIlIllIlIIIllllllII + 1.0f + this.IlIIlIIIIlIIIIllllIIlIllI, -822083584);
        this.IlllIIIlIlllIllIlIIlllIlI();
        int n3 = 0;
        while ((float)n3 < this.IlIIlIIIIlIIIIllllIIlIllI) {
            int n4 = (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue();
            int n5 = new Color(n4 >> 16 & 0xFF, n4 >> 8 & 0xFF, n4 & 0xFF, Math.round((float)255 - (float)n3 / this.IlIIlIIIIlIIIIllllIIlIllI * (float)255)).getRGB();
            if (this.llIIlllIIIIlllIllIlIlllIl && (float)n2 >= ((float)this.IlllIIIlIlllIllIlIIlllIlI + this.lllIIIIIlIllIlIIIllllllII + (float)n3) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 <= ((float)this.IlllIIIlIlllIllIlIIlllIlI + this.lllIIIIIlIllIlIIIllllllII + (float)n3 + 1.0f) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
                this.llIlIIIlIIIIlIlllIlIIIIll = (float)n3 / this.IlIIlIIIIlIIIIllllIIlIllI;
                this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(n5);
            }
            Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)19, this.lllIIIIIlIllIlIIIllllllII + (float)n3, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)27, this.lllIIIIIlIllIlIIIllllllII + (float)n3 + 1.0f, n5);
            ++n3;
        }
        float f = (float)-1 + this.IlIIlIIIIlIIIIllllIIlIllI * this.llIlIIIlIIIIlIlllIlIIIIll;
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)18, this.lllIIIIIlIllIlIIIllllllII + f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)28, this.lllIIIIIlIllIlIIIllllllII + f + (float)3, -822083584);
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)18, this.lllIIIIIlIllIlIIIllllllII + f + 1.0f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)28, this.lllIIIIIlIllIlIIIllllllII + f + 2.0f, -805306369);
    }

    private void IlllIIIlIlllIllIlIIlllIlI(int n, int n2) {
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)4, this.lllIIIIIlIllIlIIIllllllII - 1.0f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)14, this.lllIIIIIlIllIlIIIllllllII + 1.0f + this.IlIIlIIIIlIIIIllllIIlIllI, -822083584);
        int n3 = 0;
        while ((float)n3 < this.IlIIlIIIIlIIIIllllIIlIllI) {
            int n4;
            if (this.IlIlllIIIIllIllllIllIIlIl && (float)n2 >= ((float)this.IlllIIIlIlllIllIlIIlllIlI + this.lllIIIIIlIllIlIIIllllllII + (float)n3) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 <= ((float)this.IlllIIIlIlllIllIlIIlllIlI + this.lllIIIIIlIllIlIIIllllllII + (float)n3 + 1.0f) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
                n4 = (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue();
                float[] arrf = Color.RGBtoHSB(n4 >> 16 & 0xFF, n4 >> 8 & 0xFF, n4 & 0xFF, null);
                this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(Color.HSBtoRGB(this.IIIlllIIIllIllIlIIIIIIlII, arrf[1], arrf[2]));
                this.IIIlllIIIllIllIlIIIIIIlII = (float)n3 / this.IlIIlIIIIlIIIIllllIIlIllI;
            }
            n4 = Color.HSBtoRGB((float)n3 / this.IlIIlIIIIlIIIIllllIIlIllI, 1.0f, 1.0f);
            Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)5, this.lllIIIIIlIllIlIIIllllllII + (float)n3, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)13, this.lllIIIIIlIllIlIIIllllllII + (float)n3 + 1.0f, n4);
            ++n3;
        }
        float f = (float)-1 + this.IlIIlIIIIlIIIIllllIIlIllI * this.IIIlllIIIllIllIlIIIIIIlII;
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)4, this.lllIIIIIlIllIlIIIllllllII + f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)14, this.lllIIIIIlIllIlIIIllllllII + f + (float)3, -822083584);
        Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)4, this.lllIIIIIlIllIlIIIllllllII + f + 1.0f, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)14, this.lllIIIIIlIllIlIIIllllllII + f + 2.0f, -805306369);
    }

    private void IlllIIIlIlllIllIlIIlllIlI() {
        boolean bl = true;
        int n = 2;
        while ((float)n < this.IlIIlIIIIlIIIIllllIIlIllI - (float)4) {
            if (!bl) {
                Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)19, this.lllIIIIIlIllIlIIIllllllII + (float)n, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)23, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)4, -1);
                Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)23, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)4, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)27, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)8, -1);
                Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)23, this.lllIIIIIlIllIlIIIllllllII + (float)n, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)27, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)4, -7303024);
                Gui.drawRect(this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)19, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)4, this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)23, this.lllIIIIIlIllIlIIIllllllII + (float)n + (float)8, -7303024);
            }
            bl = !bl;
            n += 4;
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(List<IllllllllIlIIIIIIIIllIIII> list, int n, int n2, int n3, int n4, int n5) {
        int n6 = 0;
        int n7 = 0;
        int n8 = 8;
        for (IllllllllIlIIIIIIIIllIIII illllllllIlIIIIIIIIllIIII : list) {
            illllllllIlIIIIIIIIllIIII.lIIIIIIIIIlIllIIllIlIIlIl = this.lIIIIIIIIIlIllIIllIlIIlIl;
            if (n6 == n8) {
                ++n7;
                n6 = 0;
            }
            if (list == this.IllIIIIIIIlIlIllllIIllIII) {
                int n9 = n8 * 2 / 8 * 12;
                int var12_12 = n + n9 - n7 * 12 - 12;
                int var13_13 = n2 + n6 * n9 - n6 * 12;
                illllllllIlIIIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
                illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(var12_12, var13_13, 10, 10);
                String string = "0123456789abcdefklmnor";
                int n10 = n6 + n7 * n8;
                String string2 = string.substring(n10, n10 + 1);
                if (illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4)) {
                    Gui.drawRect(var12_12 + 12, var13_13 - 1, var12_12 + 26, var13_13 + 11, -1087492562);
                    CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString("&" + string2, (float) (var12_12 + 14), (float)var13_13, -1);
                }
            } else {
                int var12_12 = n + n7 * 12;
                int var13_13 = n2 + n6 * 12;
                illllllllIlIIIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
                illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(var12_12, var13_13, 10, 10);
            }
            illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4, (float)n5);
            ++n6;
        }
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(List<IllllllllIlIIIIIIIIllIIII> list, int n, int n2, int n3, int n4) {
        int n5 = 0;
        int n6 = 0;
        int n7 = 8;
        for (IllllllllIlIIIIIIIIllIIII illllllllIlIIIIIIIIllIIII : list) {
            int n8;
            if (list != this.IllIIIIIIIlIlIllllIIllIII) {
                if (n5 == n7) {
                    ++n6;
                    n5 = 0;
                }
                int n9 = n + n6 * 12;
                n8 = n2 + n5 * 12;
                illllllllIlIIIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
                //illllllllIlIIIIIIIIllIIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
                illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(n9, n8, 10, 10);
            }
            if (illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI(n3, n4)) {
                if (list == this.IllIIIIIIIlIlIllllIIllIII) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(new Color(illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI).getRGB());
                } else {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(new Color(illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI, true).getRGB());
                }
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                float[] arrf = Color.RGBtoHSB(illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI >> 16 & 0xFF, illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI >> 8 & 0xFF, illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI & 0xFF, null);
                this.IIIlllIIIllIllIlIIIIIIlII = arrf[0];
                n8 = (int)(arrf[1] * this.IllIllIIIlIIlllIIIllIllII);
                int n10 = (int)(this.IlIIlIIIIlIIIIllllIIlIllI - arrf[2] * this.IlIIlIIIIlIIIIllllIIlIllI);
                this.lIIIIlIIllIIlIIlIIIlIIllI.colorArray = new int[]{n8, n10};
            }
            ++n5;
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 40) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 18 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl3 = bl = (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 40) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 18 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (bl) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            float[] arrf = Color.RGBtoHSB((Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() >> 16 & 0xFF, (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() >> 8 & 0xFF, (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() & 0xFF, null);
            this.IIIlllIIIllIllIlIIIIIIlII = arrf[0];
            int n4 = (int)(arrf[1] * this.IllIllIIIlIIlllIIIllIllII);
            int n5 = (int)(this.IlIIlIIIIlIIIIllllIIlIllI - arrf[2] * this.IlIIlIIIIlIIIIllllIIlIllI);
            this.lIIIIlIIllIIlIIlIIIlIIllI.colorArray = new int[]{n4, n5};
            this.lIIIIllIIlIlIllIIIlIllIlI = !this.lIIIIllIIlIlIllIIIlIllIlI;
        } else if (bl2) {
            if (CBClient.getInstance().getGlobalSettings().lIIIIlIIllIIlIIlIIIlIIllI((Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue())) {
                CBClient.getInstance().getGlobalSettings().lIIIIIIIIIlIllIIllIlIIlIl((Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue());
            } else {
                if (CBClient.getInstance().getGlobalSettings().lIlIllIlIlIIIllllIlIllIll.size() >= 16) {
                    CBClient.getInstance().getGlobalSettings().lIlIllIlIlIIIllllIlIllIll.remove(0);
                }
                CBClient.getInstance().getGlobalSettings().lIlIllIlIlIIIllllIlIllIll.add(new IllllllllIlIIIIIIIIllIIII(this.lIIIIIIIIIlIllIIllIlIIlIl, (Integer)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue(), 1.0f));
            }
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
        } else if (this.lIIIIllIIlIlIllIIIlIllIlI) {
            boolean bl4;
            this.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, 0, 0, n, n2);
            this.lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getGlobalSettings().IlIIlIIlIllIIIIllIIllIlIl, this.lIIlIIllIIIIIlIllIIIIllII, this.lIIlllIIlIlllllllllIIIIIl, n, n2);
            this.lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getGlobalSettings().lIlIllIlIlIIIllllIlIllIll, this.lIllIllIlIIllIllIlIlIIlIl, this.llIlIIIllIIIIlllIlIIIIIlI, n, n2);
            boolean bl5 = bl4 = (float)n > (this.IIIlIIllllIIllllllIlIIIll - (float)51) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII + 1.0f + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (this.IIIlIIllllIIllllllIlIIIll - (float)43) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (this.lllIIIIIlIllIlIIIllllllII + (float)9 + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
            if ((float)n > this.IIIlIIllllIIllllllIlIIIll * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (this.lllIIIIIlIllIlIIIllllllII + this.IlIIlIIIIlIIIIllllIIlIllI + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
                this.IlllIllIlIIIIlIIlIIllIIIl = true;
            }
            if ((float)n > (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)4) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)14) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII - 1.0f + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (this.lllIIIIIlIllIlIIIllllllII + 1.0f + this.IlIIlIIIIlIIIIllllIIlIllI + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
                this.IlIlllIIIIllIllllIllIIlIl = true;
            }
            if ((float)n > (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)18) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (this.IIIlIIllllIIllllllIlIIIll + this.IllIllIIIlIIlllIIIllIllII + (float)28) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (this.lllIIIIIlIllIlIIIllllllII - 1.0f + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (this.lllIIIIIlIllIlIIIllllllII + 1.0f + this.IlIIlIIIIlIIIIllllIIlIllI + (float)this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl) {
                this.llIIlllIIIIlllIllIlIlllIl = true;
            }
            if (bl4) {
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.lIIIIlIIllIIlIIlIIIlIIllI.rainbow = !this.lIIIIlIIllIIlIIlIIIlIIllI.rainbow;
            }
        }
    }
}