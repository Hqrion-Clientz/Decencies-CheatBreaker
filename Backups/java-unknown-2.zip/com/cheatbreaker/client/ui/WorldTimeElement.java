package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.config.SettingType;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class WorldTimeElement extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;
    private float IllIIIIIIIlIlIllllIIllIII = -1;
    private float lIIIIllIIlIlIllIIIlIllIlI;
    private boolean IlllIllIlIIIIlIIlIIllIIIl = false;
    private ResourceLocation IlIlllIIIIllIllllIllIIlIl = new ResourceLocation("client/icons/sun-64.png");
    private ResourceLocation llIIlllIIIIlllIllIlIlllIl = new ResourceLocation("client/icons/moon-64.png");

    public WorldTimeElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.IIIllIllIlIlllllllIlIlIII = 22;
        this.IllIIIIIIIlIlIllllIIllIII = Float.parseFloat("" + cBSetting.getValue());
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl;
        int n4 = 170;
        boolean bl2 = bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + 170) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n4 - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 20 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (n3 == 0 && bl) {
            this.IlllIllIlIIIIlIIlIIllIIIl = true;
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        float f2;
        float f3;
        int n3 = 148;
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 8, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 8), -1895825408);
        if (this.IlllIllIlIIIIlIIlIIllIIIl && !Mouse.isButtonDown(0)) {
            this.IlllIllIlIIIIlIIlIIllIIIl = false;
        }
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString("SERVER", this.IIIIllIlIIIllIlllIlllllIl + 172 + n3 / 2f, this.IIIIllIIllIIIIllIllIIIlIl - 2, -1895825408);
        Gui.drawRect((float)(this.IIIIllIlIIIllIlllIlllllIl + 172 + n3 / 2) - 1.2580645f * 0.3974359f, this.IIIIllIIllIIIIllIllIIIlIl + 8, (float)(this.IIIIllIlIIIllIlllIlllllIl + 172 + n3 / 2) + 0.33333334f * 1.5f, this.IIIIllIIllIIIIllIllIIIlIl + 14, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.llIIlllIIIIlllIllIlIlllIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + 180) - 1.3170732f * 2.4675925f, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3), 6.346154f * 1.1818181f, 47.307693f * 0.15853658f);
        Gui.drawRect((float)(this.IIIIllIlIIIllIlllIlllllIl + 180) - 0.4509804f * 1.1086956f, this.IIIIllIIllIIIIllIllIIIlIl + 12, (float)(this.IIIIllIlIIIllIlllIlllllIl + 180) + 0.45652175f * 1.0952381f, this.IIIIllIIllIIIIllIllIIIlIl + 14, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n3 - 10) - (float)5, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), (float)10, 10);
        Gui.drawRect((float)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n3 - 10) - 1.1875f * 0.42105263f, this.IIIIllIIllIIIIllIllIIIlIl + 12, (float)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n3 - 10) + 0.4673913f * 1.0697675f, this.IIIIllIIllIIIIllIllIIIlIl + 14, 0x6F000000);
        boolean bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + 170) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n3 - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + 4 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 20 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.IIIIllIlIIIllIlllIlllllIl + 174), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 16), (double)(this.IIIIllIlIIIllIlllIlllllIl + 170 + n3 - 4), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 18), 1.0, bl ? -1895825408 : 0x6F000000);
        double d = n3 - 18;
        float f4 = Float.parseFloat("" + this.lIIIIlIIllIIlIIlIIIlIIllI.getMinimumValue());
        float f5 = Float.parseFloat("" + this.lIIIIlIIllIIlIIlIIIlIIllI.getMaximumValue());
        if (this.IlllIllIlIIIIlIIlIIllIIIl) {
            this.lIIIIllIIlIlIllIIIlIllIlI = (float)Math.round(((double)f4 + (double)((float)n - (float)(this.IIIIllIlIIIllIlllIlllllIl + 180) * this.lIIIIIIIIIlIllIIllIlIIlIl) * ((double)(f5 - f4) / (d * (double)this.lIIIIIIIIIlIllIIllIlIIlIl))) * (double)100) / (float)100;
            if (this.lIIIIllIIlIlIllIIIlIllIlI < (float)-13490 && this.lIIIIllIIlIlIllIIIlIllIlI > (float)-15490) {
                this.lIIIIllIIlIlIllIIIlIllIlI = -14490;
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.getType().equals((Object) SettingType.INTEGER)) {
                this.lIIIIllIIlIlIllIIIlIllIlI = Math.round(this.lIIIIllIIlIlIllIIIlIllIlI);
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI < f4) {
                this.lIIIIllIIlIlIllIIIlIllIlI = f4;
            } else if (this.lIIIIllIIlIlIllIIIlIllIlI > f5) {
                this.lIIIIllIIlIlIllIIIlIllIlI = f5;
            }
            Minecraft.getMinecraft().theWorld.setWorldTime((long) (Integer) CBClient.getInstance().getGlobalSettings().worldTime.getValue());
            switch (this.lIIIIlIIllIIlIIlIIIlIIllI.getType()) {
                case INTEGER: {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(Integer.parseInt((int)this.lIIIIllIIlIlIllIIIlIllIlI + ""));
                    break;
                }
                case FLOAT: {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(this.lIIIIllIIlIlIllIIIlIllIlI);
                    break;
                }
                case DOUBLE: {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(Double.parseDouble(this.lIIIIllIIlIlIllIIIlIllIlI + ""));
                }
            }
        }
        f3 = (f3 = Float.parseFloat(this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() + "")) < this.IllIIIIIIIlIlIllllIIllIII ? this.IllIIIIIIIlIlIllllIIllIII - f3 : (f3 -= this.IllIIIIIIIlIlIllllIIllIII);
        float f6 = ((f5 - f4) / (float)20 + f3 * (float)8) / (float)(Minecraft.debugFPS + 1);
        if ((double)f6 < (double)0.18f * 5.555555334797621E-4) {
            f6 = 2.1333334f * 4.6874997E-5f;
        }
        if (this.IllIIIIIIIlIlIllllIIllIII < (f2 = Float.parseFloat(this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() + ""))) {
            this.IllIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII + f6 <= f2 ? (this.IllIIIIIIIlIlIllllIIllIII += f6) : f2;
        } else if (this.IllIIIIIIIlIlIllllIIllIII > f2) {
            this.IllIIIIIIIlIlIllllIIllIII = this.IllIIIIIIIlIlIllllIIllIII - f6 >= f2 ? (this.IllIIIIIIIlIlIllllIIllIII -= f6) : f2;
        }
        double d2 = (float)100 * ((this.IllIIIIIIIlIlIllllIIllIII - f4) / (f5 - f4));
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.IIIIllIlIIIllIlllIlllllIl + 174), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 16), (double)(this.IIIIllIlIIIllIlllIlllllIl + 180) + d * d2 / (double)100, (double)(this.IIIIllIIllIIIIllIllIIIlIl + 18), (double)4, -12418828);
        GL11.glColor4f(0.6666667f * 0.375f, 0.45f, 1.0f, 1.0f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)((float)this.IIIIllIlIIIllIlllIlllllIl + 1359.3749f * 0.13333334f) + d * d2 / (double)100, (float)this.IIIIllIIllIIIIllIllIIIlIl + 18.818182f * 0.9166667f, 31.125001159496648 * 0.14457830786705017);
        if (this.IllIIIIIIIlIlIllllIIllIII == (float)-14490) {
            GL11.glColor4f(0.7738095f * 0.32307693f, 0.037499998f * 12.0f, 1.0f, 1.0f);
        } else {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)((float)this.IIIIllIlIIIllIlllIlllllIl + 39.5f * 4.588608f) + d * d2 / (double)100, (float)this.IIIIllIIllIIIIllIllIIIlIl + 1.2763158f * 13.515464f, 1.6875000046566129 * (double)1.6f);
    }
}
