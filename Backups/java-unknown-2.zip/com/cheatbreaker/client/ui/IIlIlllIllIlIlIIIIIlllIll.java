package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.module.CBModule;

import java.util.ArrayList;
import java.util.List;

class IIlIlllIllIlIlIIIIIlllIll {
    protected List lIIIIlIIllIIlIIlIIIlIIllI;
    List lIIIIIIIIIlIllIIllIlIIlIl;
    List IlllIIIlIlllIllIlIIlllIlI;
    List IIIIllIlIIIllIlllIlllllIl;
    List IIIIllIIllIIIIllIllIIIlIl;
    final CBModulesGui IlIlIIIlllIIIlIlllIlIllIl;

    IIlIlllIllIlIlIIIIIlllIll(CBModulesGui cBScreen_Interesting, List<CBDragCache> list) {
        this.IlIlIIIlllIIIlIlllIlIllIl = cBScreen_Interesting;
        ArrayList<CBModule> arrayList = new ArrayList<>();
        ArrayList<CBGuiAnchor> arrayList2 = new ArrayList<>();
        ArrayList<Float> arrayList3 = new ArrayList<>();
        ArrayList<Float> arrayList4 = new ArrayList<>();
        ArrayList<Object> arrayList5 = new ArrayList<>();
        for (CBDragCache dragCache : list) {
            if (dragCache.module.getGuiAnchor() == null) continue;
            arrayList.add(dragCache.module);
            arrayList2.add(dragCache.module.getGuiAnchor());
            arrayList3.add(dragCache.module.getXTranslation());
            arrayList4.add(dragCache.module.getYTranslation());
            arrayList5.add(dragCache.module.scale.getValue());
        }
        this.lIIIIlIIllIIlIIlIIIlIIllI = arrayList;
        this.lIIIIIIIIIlIllIIllIlIIlIl = arrayList2;
        this.IlllIIIlIlllIllIlIIlllIlI = arrayList3;
        this.IIIIllIlIIIllIlllIlllllIl = arrayList4;
        this.IIIIllIIllIIIIllIllIIIlIl = arrayList5;
    }
}