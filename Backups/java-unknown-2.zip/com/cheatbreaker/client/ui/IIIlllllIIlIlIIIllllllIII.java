package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class IIIlllllIIlIlIIIllllllIII extends GuiScreen {
    private final CBModule selectedButton;
    private final CBModulesGui lIIIIIIIIIlIllIIllIlIIlIl;

    public IIIlllllIIlIlIIIllllllIII(CBModulesGui cBScreen_Interesting, CBModule cBModule) {
        cBModule.setState(true);
        this.selectedButton = cBModule;
        this.lIIIIIIIIIlIllIIllIlIIlIl = cBScreen_Interesting;
    }

    @Override
    public void updateScreen() {
    }

    @Override
    public void initGui() {
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        this.drawDefaultBackground();
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (double)(this.height / 3), (double)this.width, (double)((float)(this.height / 3) + 2.1086957f * 0.23711339f), 0.0, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (double)(this.height / 3 * 2), (double)this.width, (double)((float)(this.height / 3 * 2) + 1.1388888f * 0.43902442f), 0.0, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.width / 3), 0.0, (double)((float)(this.width / 3) + 0.42073172f * 1.1884058f), (double)this.height, 0.0, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.width / 3 * 2), 0.0, (double)((float)(this.width / 3 * 2) + 0.28070176f * 1.78125f), (double)this.height, 0.0, 0x6F000000);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.width / 3 + this.width / 6), (double)(this.height / 3 * 2), (double)((float)(this.width / 3 + this.width / 6) + 6.7000003f * 0.07462686f), (double)this.height, 0.0, 0x6F000000);
        float f2 = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        float f3 = (float)(CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getStringWidth(this.selectedButton.getName()) + 6) * f2;
        if (this.selectedButton.width < f3) {
            this.selectedButton.width = (int)f3;
        }
        if (this.selectedButton.height < (float)18) {
            this.selectedButton.height = 18;
        }
        ScaledResolution scaledResolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        float[] arrf = CBAnchorHelper.getPositions(n, n2, scaledResolution);
        CBGuiAnchor cBGuiAnchor = CBAnchorHelper.getAnchor(n, n2, scaledResolution);
        if (cBGuiAnchor != CBGuiAnchor.MIDDLE_MIDDLE) {
            if (cBGuiAnchor == CBGuiAnchor.MIDDLE_BOTTOM_LEFT || cBGuiAnchor == CBGuiAnchor.MIDDLE_BOTTOM_RIGHT) {
                Gui.drawRect(arrf[0], arrf[1], arrf[0] + (float)(scaledResolution.getScaledWidth() / 6), arrf[1] + (float)(scaledResolution.getScaledHeight() / 3), 0x2F000000);
            } else {
                Gui.drawRect(arrf[0], arrf[1], arrf[0] + (float)(scaledResolution.getScaledWidth() / 3), arrf[1] + (float)(scaledResolution.getScaledHeight() / 3), 0x2F000000);
            }
        }
        int n3 = scaledResolution.getScaledWidth();
        int n4 = scaledResolution.getScaledHeight();
        float[] arrf2 = CBAnchorHelper.getPositions(this.selectedButton, n, n2, scaledResolution);
        if (cBGuiAnchor != this.selectedButton.getGuiAnchor()) {
            this.selectedButton.setAnchor(cBGuiAnchor);
            this.selectedButton.setTranslations(0.0f, 0.0f);
        }
        if (!Mouse.isButtonDown(1)) {
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)2, 0.0, 1.8636363192038112 * 1.3414634466171265, (double)n4, 0.0, -15599126);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)((float)n3 - 1.1197916f * 2.2325583f), 0.0, (double)(n3 - 2), (double)n4, 0.0, -15599126);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (double)2, (double)n3, 0.4375 * 5.714285714285714, 0.0, -15599126);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(0.0, (double)((float)n4 - 0.557971f * 6.2727275f), (double)n3, (double)(n4 - 3), 0.0, -15599126);
        }
        float f4 = (float)n - arrf[0] - arrf2[0];
        float f5 = (float)n2 - arrf[1] - arrf2[1];
        if (!Mouse.isButtonDown(1)) {
            float[] arrf3 = this.selectedButton.getScaledPoints(scaledResolution, false);
            f4 = this.lIIIIlIIllIIlIIlIIIlIIllI(this.selectedButton, f4, arrf3, (float)((int)(this.selectedButton.width * (Float) this.selectedButton.scale.getValue())), false);
            f5 = this.lIIIIIIIIIlIllIIllIlIIlIl(this.selectedButton, f5, arrf3, (float)((int)(this.selectedButton.height * (Float) this.selectedButton.scale.getValue())), false);
        }
        this.selectedButton.setTranslations(f4, f5);
        GL11.glPushMatrix();
        this.selectedButton.scaleAndTranslate(scaledResolution);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)-2, (double)-2, (double)(this.selectedButton.width + 2.0f), (double)(this.selectedButton.height + 2.0f), (double)4, 551805923);
        GL11.glPushMatrix();
        GL11.glScalef(f2, f2, f2);
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(this.selectedButton.getName(), 0.0f, (float) -1f, 0x6F000000); // 0x6F000000
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }

    private float lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule, float f, float[] arrf, float f2, boolean bl) {
        int n;
        float f3 = f;
        int n2 = n = bl ? 0 : 3;
        if (f3 + arrf[0] < (float)n) {
            f3 = -arrf[0] + (float)n;
        } else if (f3 + arrf[0] * (Float) cBModule.scale.getValue() + f2 > (float)(this.width - n)) {
            f3 = (int)((float)this.width - arrf[0] * (Float) cBModule.scale.getValue() - f2 - (float)n);
        }
        return f3;
    }

    private float lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule, float f, float[] arrf, float f2, boolean bl) {
        int n;
        float f3 = f;
        int n2 = n = bl ? 0 : 2;
        if (f3 + arrf[1] < (float)n) {
            f3 = -arrf[1] + (float)n;
        } else if (f3 + arrf[1] * (Float) cBModule.scale.getValue() + f2 > (float)(this.height - n)) {
            f3 = (int)((float)this.height - arrf[1] * (Float) cBModule.scale.getValue() - f2 - (float)n);
        }
        return f3;
    }

    @Override
    public void mouseClicked(int n, int n2, int n3) {
        if (n3 != 0) {
            return;
        }
        ScaledResolution scaledResolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        CBGuiAnchor cBGuiAnchor = CBAnchorHelper.getAnchor(n, n2, scaledResolution);
        this.selectedButton.setAnchor(cBGuiAnchor);
        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
        this.selectedButton.setState(true);
        CBModulesGui cBScreen_Interesting = new CBModulesGui();
        this.mc.displayGuiScreen(cBScreen_Interesting);
        cBScreen_Interesting.IlllIllIlIIIIlIIlIIllIIIl = cBScreen_Interesting.IIIllIllIlIlllllllIlIlIII;
        cBScreen_Interesting.IlllIllIlIIIIlIIlIIllIIIl.lIIlIlIllIIlIIIlIIIlllIII = false;
        cBScreen_Interesting.IlllIllIlIIIIlIIlIIllIIIl.lIIIIllIIlIlIllIIIlIllIlI = this.lIIIIIIIIIlIllIIllIlIIlIl.IIIllIllIlIlllllllIlIlIII.lIIIIllIIlIlIllIIIlIllIlI;
        cBScreen_Interesting.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI = 0;
    }

    @Override
    public void mouseMovedOrUp(int n, int n2, int n3) {
    }

    @Override
    public void keyTyped(char c, int n) {
    }
}
