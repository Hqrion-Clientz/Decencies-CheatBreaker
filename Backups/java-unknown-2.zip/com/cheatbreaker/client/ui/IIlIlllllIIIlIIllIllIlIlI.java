package com.cheatbreaker.client.ui;

import java.io.File;
import java.util.Collections;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBProfile;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class IIlIlllllIIIlIIllIllIlIlI
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private final int IllIIIIIIIlIlIllllIIllIII;
    public final CBProfile lIIIIlIIllIIlIIlIIIlIIllI;
    private final lllIllIllIlIllIlIIllllIIl lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl = 0;
    private final ResourceLocation IlIlllIIIIllIllllIllIIlIl = new ResourceLocation("client/icons/delete-64.png");
    private final ResourceLocation llIIlllIIIIlllIllIlIlllIl = new ResourceLocation("client/icons/checkmark-64.png");
    private ResourceLocation rightIcon = new ResourceLocation("client/icons/right.png");
    private ResourceLocation pencilIcon = new ResourceLocation("client/icons/pencil-64.png");

    public IIlIlllllIIIlIIllIllIlIlI(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, int n, CBProfile ilIIlIIlIIlllIlIIIlIllIIl, float f) {
        super(f);
        this.lIIIIllIIlIlIllIIIlIllIlI = lllIllIllIlIllIlIIllllIIl2;
        this.IllIIIIIIIlIlIllllIIllIII = n;
        this.lIIIIlIIllIIlIIlIIIlIIllI = ilIIlIIlIIlllIlIIIlIllIIl;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        boolean bl;
        boolean bl2;
        float f2;
        boolean bl3 = n > this.IIIIllIlIIIllIlllIlllllIl + 12 && this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        int n3 = 75;
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, 0x2F2F2F2F);
        if (bl3) {
            if (this.IlllIllIlIIIIlIIlIIllIIIl < n3) {
                f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
                this.IlllIllIlIIIIlIIlIIllIIIl = (int)((float)this.IlllIllIlIIIIlIIlIIllIIIl + f2);
                if (this.IlllIllIlIIIIlIIlIIllIIIl > n3) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = n3;
                }
            }
        } else if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
            f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
            this.IlllIllIlIIIIlIIlIIllIIIl = (float)this.IlllIllIlIIIIlIIlIIllIIIl - f2 < 0.0f ? 0 : (int)((float)this.IlllIllIlIIIIlIIlIIllIIIl - f2);
        }
        if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
            f2 = (float)this.IlllIllIlIIIIlIIlIIllIIIl / (float)n3 * (float)100;
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 12, (int)((float)this.IIIIllIIllIIIIllIllIIIlIl + ((float)this.IIIllIllIlIlllllllIlIlIII - (float)this.IIIllIllIlIlllllllIlIlIII * f2 / (float)100)), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - (!this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable() ? 0 : 30), this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, this.IllIIIIIIIlIlIllllIIllIII);
        }
        boolean bl4 = (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 >= (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 <= (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl5 = (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.1919192f * 1.8236842f);
        float f3 = 6.571429f * 0.38043478f;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable()) {
            bl2 = false;
            bl = false;
            IIlIlIlllIllIIlIllIIlIIlI iIlIlIlllIllIIlIllIIlIIlI = (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI;
            if (iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != 0 && iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) > 1) {
                bl2 = true;
                GL11.glPushMatrix();
                if (bl4) {
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.14444444f * 4.5f);
                }
                GL11.glTranslatef((float)(this.IIIIllIlIIIllIlllIlllllIl + 6) - f3, (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)7, 0.0f);
                GL11.glRotatef(-90, 0.0f, 0.0f, 1.0f);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.rightIcon, f3, (float)-1, 0.0f);
                GL11.glPopMatrix();
                GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.0952381f * 0.3195652f);
            }
            if (iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1) {
                bl = true;
                GL11.glPushMatrix();
                if (bl5) {
                    GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.2112676f * 0.5366279f);
                }
                GL11.glTranslatef((float)(this.IIIIllIlIIIllIlllIlllllIl + 6) + f3, (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)7, 0.0f);
                GL11.glRotatef(90, 0.0f, 0.0f, 1.0f);
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.rightIcon, f3, 2.0f, 0.0f);
                GL11.glPopMatrix();
            }
            if (!bl2 && !bl) {
                RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.rightIcon, 1.173913f * 2.1296296f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 4), (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
            }
        } else {
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.rightIcon, 6.6666665f * 0.375f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 4), (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
        }
        if (CBClient.getInstance().activeProfile == this.lIIIIlIIllIIlIIlIIIlIIllI) {
            CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getName().toUpperCase(), (float)this.IIIIllIlIIIllIlllIlllllIl + (float)16, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3), -818991313);
        } else {
            CBClient.getInstance().IIIlllIIIllIllIlIIIIIIlII.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getName().toUpperCase(), (float)this.IIIIllIlIIIllIlllIlllllIl + (float)16, (float)this.IIIIllIIllIIIIllIllIIIlIl + 3.9545455f * 0.88505745f, -818991313);
        }
        if (CBClient.getInstance().activeProfile == this.lIIIIlIIllIIlIIlIIIlIIllI) {
            CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.drawString(" (Active)", (float)this.IIIIllIlIIIllIlllIlllllIl + (float)17 + (float)CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.getStringWidth(this.lIIIIlIIllIIlIIlIIIlIIllI.getName().toUpperCase()), (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)4, 0x6F2F2F2F);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable()) {
            bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 30) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
            GL11.glColor4f(bl2 ? 0.0f : 1.1707317f * 0.21354167f, bl2 ? 0.0f : 0.101648346f * 2.4594595f, bl2 ? 0.48876402f * 1.0229886f : 0.5647059f * 0.4427083f, 0.5675676f * 1.145238f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.pencilIcon, (float)5, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26), (float)this.IIIIllIIllIIIIllIllIIIlIl + 5.1916666f * 0.6741573f);
            bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
            GL11.glColor4f(bl ? 1.4181818f * 0.5641026f : 0.96875f * 0.2580645f, bl ? 0.0f : 0.17553192f * 1.4242424f, bl ? 0.0f : 15.250001f * 0.016393442f, 0.44444445f * 1.4625f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, (float)5, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13), (float)this.IIIIllIIllIIIIllIllIIIlIl + 0.7653061f * 4.5733333f);
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 2) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 30) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 13) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl3 = (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 >= (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 <= (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl4 = (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + 12) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        IIlIlIlllIllIIlIllIIlIIlI iIlIlIlllIllIIlIllIIlIIlI = (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable() && (bl3 || bl4)) {
            if (bl3 && ((IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != 0 && ((IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI).lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) > 1) {
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.lIIIIlIIllIIlIIlIIIlIIllI.setIndex(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) - 1);
                iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.get((int)(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf((Object)this) - 1)).lIIIIlIIllIIlIIlIIIlIIllI.setIndex(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this));
                Collections.swap(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI, iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this), iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) - 1);
            }
            if (bl4 && iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) != iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.size() - 1) {
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.lIIIIlIIllIIlIIlIIIlIIllI.setIndex(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) + 1);
                iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.get((int)(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf((Object)this) + 1)).lIIIIlIIllIIlIIlIIIlIIllI.setIndex(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this));
                Collections.swap(iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI, iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this), iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.indexOf(this) + 1);
            }
        } else if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable() && bl) {
            File file;
            File file2;
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            if (CBClient.getInstance().activeProfile == this.lIIIIlIIllIIlIIlIIIlIIllI) {
                CBClient.getInstance().activeProfile = CBClient.getInstance().profiles.get(0);
                CBClient.getInstance().getConfigManager().readProfile(CBClient.getInstance().activeProfile.getName());
                CBClient.getInstance().getModuleManager().keyStrokes.initialize();
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable() && (file2 = (file = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles")).exists() || file.mkdirs() ? new File(file + File.separator + this.lIIIIlIIllIIlIIlIIIlIIllI.getName().toLowerCase() + ".cfg") : null).exists() && file2.delete()) {
                CBClient.getInstance().profiles.removeIf(ilIIlIIlIIlllIlIIIlIllIIl -> ilIIlIIlIIlllIlIIIlIllIIl == this.lIIIIlIIllIIlIIlIIIlIIllI);
                iIlIlIlllIllIIlIllIIlIIlI.lIIIIlIIllIIlIIlIIIlIIllI.removeIf(iIlIlllllIIIlIIllIllIlIlI -> iIlIlllllIIIlIIllIllIlIlI == this);
            }
        } else if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEditable() && bl2) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            Minecraft.getMinecraft().displayGuiScreen(new llIIIlIlIIlIlIIlIllIllIll(this.lIIIIlIIllIIlIIlIIIlIIllI, CBModulesGui.instance, (IIlIlIlllIllIIlIllIIlIIlI)this.lIIIIllIIlIlIllIIIlIllIlI, this.IllIIIIIIIlIlIllllIIllIII, this.lIIIIIIIIIlIllIIllIlIIlIl));
        } else if (CBClient.getInstance().activeProfile != this.lIIIIlIIllIIlIIlIIIlIIllI) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            CBClient.getInstance().getConfigManager().writeProfile(CBClient.getInstance().activeProfile.getName());
            CBClient.getInstance().activeProfile = this.lIIIIlIIllIIlIIlIIIlIIllI;
            CBClient.getInstance().getConfigManager().readProfile(CBClient.getInstance().activeProfile.getName());
            CBClient.getInstance().getModuleManager().keyStrokes.initialize();
        }
    }
}