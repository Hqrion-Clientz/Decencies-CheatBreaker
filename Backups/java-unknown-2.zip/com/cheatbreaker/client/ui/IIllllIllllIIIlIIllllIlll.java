package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class IIllllIllllIIIlIIllllIlll extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private final int IllIIIIIIIlIlIllllIIllIII;
    public final CBModule lIIIIlIIllIIlIIlIIIlIIllI;
    private final lllIllIllIlIllIlIIllllIIl lIIIIllIIlIlIllIIIlIllIlI;
    private int IlllIllIlIIIIlIIlIIllIIIl = 0;
    private ResourceLocation IlIlllIIIIllIllllIllIIlIl = new ResourceLocation("client/icons/right.png");

    public IIllllIllllIIIlIIllllIlll(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, int n, CBModule cBModule, float f) {
        super(f);
        this.lIIIIllIIlIlIllIIIlIllIlI = lllIllIllIlIllIlIIllllIIl2;
        this.IllIIIIIIIlIlIllllIIllIII = n;
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBModule;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        boolean bl = this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        int n3 = 75;
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, 0x2F2F2F2F);
        if (this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI)) {
            float f2;
            if (bl) {
                f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
                if ((float)this.IlllIllIlIIIIlIIlIIllIIIl + f2 < (float)n3) {
                    this.IlllIllIlIIIIlIIlIIllIIIl = (int)((float)this.IlllIllIlIIIIlIIlIIllIIIl + f2);
                    if (this.IlllIllIlIIIIlIIlIIllIIIl > n3) {
                        this.IlllIllIlIIIIlIIlIIllIIIl = n3;
                    }
                }
            } else if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
                f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
                this.IlllIllIlIIIIlIIlIIllIIIl = (float)this.IlllIllIlIIIIlIIlIIllIIIl - f2 < 0.0f ? 0 : (int)((float)this.IlllIllIlIIIIlIIlIIllIIIl - f2);
            }
            if (this.IlllIllIlIIIIlIIlIIllIIIl > 0) {
                f2 = (float)this.IlllIllIlIIIIlIIlIIllIIIl / (float)n3 * (float)100;
                Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, (int)((float)this.IIIIllIIllIIIIllIllIIIlIl + ((float)this.IIIllIllIlIlllllllIlIlIII - (float)this.IIIllIllIlIlllllllIlIlIII * f2 / (float)100)), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, this.IllIIIIIIIlIlIllllIIllIII);
            }
        }
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.4385965f * 0.24329267f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IlIlllIIIIllIllllIllIIlIl, 1.9411765f * 1.2878788f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 6), (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
        CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getName().toUpperCase(), (float)this.IIIIllIlIIIllIlllIlllllIl + (float)14, (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)3, this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI) ? -818991313 : 0x2F2F2F2F);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIIIIIIlIllIIllIlIIlIl(this.lIIIIlIIllIIlIIlIIIlIIllI);
    }
}
