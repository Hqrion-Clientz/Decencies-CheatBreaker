package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import net.minecraft.client.gui.Gui;

public class StringElement
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;

    public StringElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.IIIllIllIlIlllllllIlIlIII = 12;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(((String)this.lIIIIlIIllIIlIIlIIIlIIllI.getValue()).toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 2, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), 0x6F000000);
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 20, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, 0x1F2F2F2F);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }
}