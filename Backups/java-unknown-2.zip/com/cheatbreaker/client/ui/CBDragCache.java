package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.module.CBModule;

public class CBDragCache {

    protected CBModule module;
    protected float x;
    protected float y;

    CBDragCache(CBModule cBModule, float f, float f2) {
        this.module = cBModule;
        this.x = f;
        this.y = f2;
    }

}
