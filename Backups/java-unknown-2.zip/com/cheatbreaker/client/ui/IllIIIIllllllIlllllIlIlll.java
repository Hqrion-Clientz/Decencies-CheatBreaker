package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class IllIIIIllllllIlllllIlIlll
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private final int lIIIIlIIllIIlIIlIIIlIIllI;
    private final lllIllIllIlIllIlIIllllIIl IllIIIIIIIlIlIllllIIllIII;
    private int lIIIIllIIlIlIllIIIlIllIlI = 0;
    private ResourceLocation IlllIllIlIIIIlIIlIIllIIIl = new ResourceLocation("client/icons/right.png");

    public IllIIIIllllllIlllllIlIlll(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, int n, float f) {
        super(f);
        this.IllIIIIIIIlIlIllllIIllIII = lllIllIllIlIllIlIIllllIIl2;
        this.lIIIIlIIllIIlIIlIIIlIIllI = n;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        boolean bl = this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        int n3 = 75;
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 1, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, 0x2F2F2F2F);
        float f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
        if (bl) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI < n3) {
                this.lIIIIllIIlIlIllIIIlIllIlI = (int)((float)this.lIIIIllIIlIlIllIIIlIllIlI + f2);
                if (this.lIIIIllIIlIlIllIIIlIllIlI > n3) {
                    this.lIIIIllIIlIlIllIIIlIllIlI = n3;
                }
            }
        } else if (this.lIIIIllIIlIlIllIIIlIllIlI > 0) {
            this.lIIIIllIIlIlIllIIIlIllIlI = (float)this.lIIIIllIIlIlIllIIIlIllIlI - f2 < 0.0f ? 0 : (int)((float)this.lIIIIllIIlIlIllIIIlIllIlI - f2);
        }
        if (this.lIIIIllIIlIlIllIIIlIllIlI > 0) {
            float f3 = (float)this.lIIIIllIIlIlIllIIIlIllIlI / (float)n3 * (float)100;
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, (int)((float)this.IIIIllIIllIIIIllIllIIIlIl + ((float)this.IIIllIllIlIlllllllIlIlIII - (float)this.IIIllIllIlIlllllllIlIlIII * f3 / (float)100)), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.4666667f * 0.23863636f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IlllIllIlIIIIlIIlIIllIIIl, 2.2f * 1.1363636f, (float)(this.IIIIllIlIIIllIlllIlllllIl + 6), (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)6);
        CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl.drawString("CheatBreaker Settings".toUpperCase(), (float)this.IIIIllIlIIIllIlllIlllllIl + (float)14, (float)this.IIIIllIIllIIIIllIllIIIlIl + (float)3, -818991313);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }
}
