package com.cheatbreaker.client.ui;

import net.minecraft.client.Minecraft;

public abstract class IlIIlllIlIIIlIIIlIlIlIlIl {
    public float lIIIIIIIIIlIllIIllIlIIlIl;
    public int IlllIIIlIlllIllIlIIlllIlI = 0;
    protected int IIIIllIlIIIllIlllIlllllIl;
    protected int IIIIllIIllIIIIllIllIIIlIl;
    protected int IlIlIIIlllIIIlIlllIlIllIl;
    protected int IIIllIllIlIlllllllIlIlIII;

    public IlIIlllIlIIIlIIIlIlIlIlIl(float f) {
        this.lIIIIIIIIIlIllIIllIlIIlIl = f;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3, int n4) {
        this.IIIIllIlIIIllIlllIlllllIl = n;
        this.IIIIllIIllIIIIllIllIIIlIl = n2;
        this.IlIlIIIlllIIIlIlllIlIllIl = n3;
        this.IIIllIllIlIlllllllIlIlIII = n4;
    }

    public abstract void lIIIIlIIllIIlIIlIIIlIIllI(int var1, int var2, float var3);

    public abstract void lIIIIlIIllIIlIIlIIIlIIllI(int var1, int var2, int var3);

    public boolean lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2) {
        return (float)n > (float)this.IIIIllIlIIIllIlllIlllllIl * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && Minecraft.getMinecraft().currentScreen instanceof CBModulesGui;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(int n) {
    }

    public int lIIIIlIIllIIlIIlIIIlIIllI() {
        return this.IIIllIllIlIlllllllIlIlIII;
    }
}

