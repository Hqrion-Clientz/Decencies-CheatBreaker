package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBGlobalSettings;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class CrosshairElement extends IlIIlllIlIIIlIIIlIlIlIlIl {
    public CrosshairElement(float f) {
        super(f);
        this.IIIllIllIlIlllllllIlIlIII = 50;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + (this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 15) - 41, this.IIIIllIIllIIIIllIllIIIlIl + 4, this.IIIIllIlIIIllIlllIlllllIl + (this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 15) + 41, this.IIIIllIIllIIIIllIllIIIlIl + 51, -16777216);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("client/defaults/crosshair.png"), (float)(this.IIIIllIlIIIllIlllIlllllIl + (this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 15) - 40), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 5), (float)80, 45);
        CBGlobalSettings iIIIllIlIlIIIlIlIIllllllI = CBClient.getInstance().getGlobalSettings();
        GL11.glPushMatrix();
        float f2 = 1.0f / CBClient.IlllIllIlIIIIlIIlIIllIIIl();
        GL11.glScalef(f2, f2, f2);
        float f3 = ((Float)iIIIllIlIlIIIlIlIIllllllI.crosshairSize.getValue()).floatValue();
        float f4 = ((Float)iIIIllIlIlIIIlIlIIllllllI.crosshairGap.getValue()).floatValue();
        float f5 = ((Float)iIIIllIlIlIIIlIlIIllllllI.crosshairThickness.getValue()).floatValue();
        int n3 = iIIIllIlIlIIIlIlIIllllllI.crosshairColor.getColorValue();
        boolean bl = (Boolean)iIIIllIlIlIIIlIlIIllllllI.crosshairOutline.getValue();
        int n4 = this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 15;
        int n5 = this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 + 3;
        if (bl) {
            RenderUtil.lIIIIIIIIIlIllIIllIlIIlIl((float)n4 - f4 - f3, (float)n5 - f5 / 2.0f, (float)n4 - f4, (float)n5 + f5 / 2.0f, 0.3380282f * 1.4791666f, -1358954496, n3);
            RenderUtil.lIIIIIIIIIlIllIIllIlIIlIl((float)n4 + f4, (float)n5 - f5 / 2.0f, (float)n4 + f4 + f3, (float)n5 + f5 / 2.0f, 3.909091f * 0.12790698f, -1358954496, n3);
            RenderUtil.lIIIIIIIIIlIllIIllIlIIlIl((float)n4 - f5 / 2.0f, (float)n5 - f4 - f3, (float)n4 + f5 / 2.0f, (float)n5 - f4, 0.39506173f * 1.265625f, -1358954496, n3);
            RenderUtil.lIIIIIIIIIlIllIIllIlIIlIl((float)n4 - f5 / 2.0f, (float)n5 + f4, (float)n4 + f5 / 2.0f, (float)n5 + f4 + f3, 5.5f * 0.09090909f, -1358954496, n3);
        } else {
            Gui.drawRect((float)n4 - f4 - f3, (float)n5 - f5 / 2.0f, (float)n4 - f4, (float)n5 + f5 / 2.0f, n3);
            Gui.drawRect((float)n4 + f4, (float)n5 - f5 / 2.0f, (float)n4 + f4 + f3, (float)n5 + f5 / 2.0f, n3);
            Gui.drawRect((float)n4 - f5 / 2.0f, (float)n5 - f4 - f3, (float)n4 + f5 / 2.0f, (float)n5 - f4, n3);
            Gui.drawRect((float)n4 - f5 / 2.0f, (float)n5 + f4, (float)n4 + f5 / 2.0f, (float)n5 + f4 + f3, n3);
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }
}
