package com.cheatbreaker.client.ui;

import java.util.Objects;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.config.SettingType;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class IIIllllIlIIlIIIlIlIlllIII
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBModule lIIIIlIIllIIlIIlIIIlIIllI;
    private llllIIIIIlIlIlIlIllIIIIII IllIIIIIIIlIlIllllIIllIII;
    private llllIIIIIlIlIlIlIllIIIIII lIIIIllIIlIlIllIIIlIllIlI;
    private llllIIIIIlIlIlIlIllIIIIII IlllIllIlIIIIlIIlIIllIIIl;
    private lllIllIllIlIllIlIIllllIIl IlIlllIIIIllIllllIllIIlIl;

    public IIIllllIlIIlIIIlIlIlllIII(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, CBModule cBModule, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBModule;
        this.IlIlllIIIIllIllllIllIIlIl = lllIllIllIlIllIlIIllllIIl2;
        CBFontRenderer lIlIllIlIlIIIllllIlIllIll2 = CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl;
        CBFontRenderer lIlIllIlIlIIIllllIlIllIll3 = CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII;
        this.IllIIIIIIIlIlIllllIIllIII = new llllIIIIIlIlIlIlIllIIIIII(lIlIllIlIlIIIllllIlIllIll2, null, "Options", this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 20, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 6, -12418828, f);
        this.lIIIIllIIlIlIllIIIlIllIlI = new llllIIIIIlIlIlIlIllIIIIII(lIlIllIlIlIIIllllIlIllIll3, null, cBModule.getGuiAnchor() == null ? (cBModule.isRenderHud() ? "Disable" : "Enable") : (cBModule.isRenderHud() ? "Hide from HUD" : "Add to HUD"), this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24, cBModule.isRenderHud() ? -5756117 : -13916106, f);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(cBModule != CBClient.getInstance().getModuleManager().minmap && cBModule != CBClient.getInstance().getModuleManager().notifications);
        this.IlllIllIlIIIIlIIlIIllIIIl = new llllIIIIIlIlIlIlIllIIIIII(lIlIllIlIlIIIllllIlIllIll3, null, cBModule.isEnabled() ? "Disable" : "Enable", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24, cBModule.isEnabled() ? -5756117 : -13916106, f);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        float f2;
        Object object;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled()) {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, -13916106);
        } else {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, -1347374928);
        }
        CBFontRenderer lIlIllIlIlIIIllllIlIllIll2 = CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl;
        GL11.glPushMatrix();
        int n3 = 0;
        int n4 = 0;
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().armourStatus) {
            n3 = -10;
            object = "329/329";
            f2 = Minecraft.getMinecraft().fontRenderer.getStringWidth((String)object);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow((String)object, (int)((float)(this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - f2 / 2.0f), this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18, -1);
        } else if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().potionStatus) {
            n4 = -30;
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Speed II", this.IIIIllIlIIIllIlllIlllllIl + 8 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 20, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 36, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("0:42", this.IIIIllIlIIIllIlllIlllllIl + 8 + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 20, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 26, -1);
        } else if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().scoreboard) {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 20, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 44, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 20, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 6, 0x6F000000);
            Minecraft.getMinecraft().fontRenderer.drawString("Score", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 40, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Steve", this.IIIIllIlIIIllIlllIlllllIl + 24, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 28, -1);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow("Alex", this.IIIIllIlIIIllIlllIlllllIl + 24, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18, -1);
            Minecraft.getMinecraft().fontRenderer.drawString(EnumChatFormatting.RED + "0", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 18, -1);
            Minecraft.getMinecraft().fontRenderer.drawString(EnumChatFormatting.RED + "1", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 26, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 28, -1);
        }
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().cooldowns) {
            object = new llIlllIIllIlllIlIlIlIIIll("EnderPearl", 368, 9000L);
            ((llIlllIIllIlllIlIlIlIIIll)object).lIIIIlIIllIIlIIlIIIlIIllI(CBClient.getInstance().getModuleManager().cooldowns.colorTheme, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 18, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 26 - 18, -1);
        } else if ((this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewType() == null || this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewType() == CBModule.PreviewType.LABEL) && this.lIIIIlIIllIIlIIlIIIlIIllI != CBClient.getInstance().getModuleManager().scoreboard) {
            object = "";
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewType() == null) {
                f2 = 2.0f;
                for (String string : this.lIIIIlIIllIIlIIlIIIlIIllI.getName().split(" ")) {
                    String string2 = string.substring(0, 1);
                    object = (String)object + (Objects.equals(object, "") ? string2 : string2.toLowerCase());
                }
            } else {
                f2 = this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewLabelSize();
                object = this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewLabel();
            }
            GL11.glScalef(f2, f2, f2);
            float f3 = (float)Minecraft.getMinecraft().fontRenderer.getStringWidth((String)object) * f2;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewType() == null) {
                Minecraft.getMinecraft().fontRenderer.drawString((String)object, (int)(((float)(this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - f3 / 2.0f) / f2), (int)((float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 32) / f2), -13750738);
            } else {
                Minecraft.getMinecraft().fontRenderer.drawStringWithShadow((String)object, (int)(((float)(this.IIIIllIlIIIllIlllIlllllIl + 1 + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - f3 / 2.0f) / f2), (int)((float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - 32) / f2), -1);
            }
        } else if (this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewType() == CBModule.PreviewType.ICON) {
            float f4 = this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewIconWidth();
            f2 = this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewIconHeight();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIlIIllIIlIIlIIIlIIllI.getPreviewIcon(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - f4 / 2.0f + (float)n4, (float)(this.IIIIllIIllIIIIllIllIIIlIl + n3 + this.IIIllIllIlIlllllllIlIlIII / 2 - 26) - f2 / 2.0f, f4, f2);
        }
        GL11.glPopMatrix();
        lIlIllIlIlIIIllllIlIllIll2.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getName(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - 1.0681819f * 0.46808508f, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2f - 4 + 1, 0x5F000000);
        lIlIllIlIlIIIllllIlIllIll2.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getName(), (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2) - 1.125f * 1.3333334f, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2f - 4, -1);
        this.IlllIllIlIIIIlIIlIIllIIIl.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Disable" : "Enable";
        this.IlllIllIlIIIIlIIlIIllIIIl.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        int n5 = this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? -5756117 : -13916106;
        this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.getGuiAnchor() == null ? (this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Disable" : "Enable") : (this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Hide from HUD" : "Add to HUD");
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? -5756117 : -13916106;
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 20, this.IlIlIIIlllIIIlIlllIlIllIl - 8, 16);
        this.IllIIIIIIIlIlIllllIIllIII.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.lIIIIlIIllIIlIIlIIIlIIllI.alwaysTrue ? this.IlIlIIIlllIIIlIlllIlIllIl - 8 : this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24 - (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38));
        this.lIIIIllIIlIlIllIIIlIllIlI.IlllIIIlIlllIllIlIIlllIlI = this.IlllIIIlIlllIllIlIIlllIlI;
        this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        if (!this.lIIIIlIIllIIlIIlIIIlIIllI.alwaysTrue) {
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2 + 8, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38, this.IlIlIIIlllIIIlIlllIlIllIl / 2 - 12, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 24 - (this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 38));
            this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        if (this.IllIIIIIIIlIlIllllIIllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            ((lIlIIllIIIlllIIllIIlIIllI)CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).llIlIIIlIIIIlIlllIlIIIIll = false;
            ((lIlIIllIIIlllIIllIIlIIllI)CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).IIIlllIIIllIllIlIIIIIIlII = this.IlIlllIIIIllIllllIllIIlIl;
            ((lIlIIllIIIlllIIllIIlIIllI)CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl).IIIlIIllllIIllllllIlIIIll = this.lIIIIlIIllIIlIIlIIIlIIllI;
            CBModulesGui.instance.IlllIllIlIIIIlIIlIIllIIIl = CBModulesGui.instance.IIIIllIIllIIIIllIllIIIlIl;
        } else if (!this.lIIIIlIIllIIlIIlIIIlIIllI.alwaysTrue && this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            this.lIIIIlIIllIIlIIlIIIlIIllI.setState(!this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled());
            this.IlllIllIlIIIIlIIlIIllIIIl.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Disable" : "Enable";
            int n4 = this.IlllIllIlIIIIlIIlIIllIIIl.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? -5756117 : -13916106;
            if (this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled()) {
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                this.lIIIIlIIllIIlIIlIIIlIIllI.setState(true);
            }
        } else if (this.lIIIIllIIlIlIllIIIlIllIlI.IlllIllIlIIIIlIIlIIllIIIl && this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            if (!this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled()) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.setRenderHud(true);
                this.lIIIIIIIIIlIllIIllIlIIlIl();
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.getGuiAnchor() == null) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setState(true);
                } else {
                    Minecraft.getMinecraft().displayGuiScreen(new IIIlllllIIlIlIIIllllllIII(CBModulesGui.instance, this.lIIIIlIIllIIlIIlIIIlIIllI));
                }
            } else {
                this.lIIIIlIIllIIlIIlIIIlIIllI.setRenderHud(!this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud());
                if (this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud()) {
                    this.lIIIIIIIIIlIllIIllIlIIlIl();
                    if (this.lIIIIlIIllIIlIIlIIIlIIllI.getGuiAnchor() == null) {
                        this.lIIIIlIIllIIlIIlIIIlIIllI.setState(true);
                    } else {
                        Minecraft.getMinecraft().displayGuiScreen(new IIIlllllIIlIlIIIllllllIII(CBModulesGui.instance, this.lIIIIlIIllIIlIIlIIIlIIllI));
                    }
                } else if (this.lIIIIlIIllIIlIIlIIIlIIllI.alwaysTrue && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled()) {
                    this.lIIIIlIIllIIlIIlIIIlIIllI.setState(false);
                }
            }
            this.lIIIIllIIlIlIllIIIlIllIlI.IllIIIIIIIlIlIllllIIllIII = this.lIIIIlIIllIIlIIlIIIlIIllI.getGuiAnchor() == null ? (this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Disable" : "Enable") : (this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? "Hide from HUD" : "Add to HUD");
            this.lIIIIllIIlIlIllIIIlIllIlI.lIIIIlIIllIIlIIlIIIlIIllI = this.lIIIIlIIllIIlIIlIIIlIIllI.isRenderHud() && this.lIIIIlIIllIIlIIlIIIlIIllI.isEnabled() ? -5756117 : -13916106;
        }
    }

    private void lIIIIIIIIIlIllIIllIlIIlIl() {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().llIIlllIIIIlllIllIlIlllIl) {
            return;
        }
        for (CBSetting cBSetting : this.lIIIIlIIllIIlIIlIIIlIIllI.getSettingsList()) {
            if (cBSetting.getType() != SettingType.INTEGER || !cBSetting.getLabel().toLowerCase().contains("color") || cBSetting.getLabel().toLowerCase().contains("background") || cBSetting.getLabel().toLowerCase().contains("pressed")) continue;
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            cBSetting.setValue(CBClient.getInstance().getGlobalSettings().defaultColor.getValue());
        }
    }
}
