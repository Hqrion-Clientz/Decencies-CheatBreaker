package com.cheatbreaker.client.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.config.SettingType;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.module.CBStaffModule;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class lIlIIllIIIlllIIllIIlIIllI extends lllIllIllIlIllIlIIllllIIl {
    private final int lllIIIIIlIllIlIIIllllllII;
    protected final List<IIllllIllllIIIlIIllllIlll> lIIIIlIIllIIlIIlIIIlIIllI;
    private boolean lIIIIIllllIIIIlIlIIIIlIlI = false;
    private final IllIIIIllllllIlllllIlIlll IIIIIIlIlIlIllllllIlllIlI;
    public lllIllIllIlIllIlIIllllIIl IIIlllIIIllIllIlIIIIIIlII;
    public boolean llIlIIIlIIIIlIlllIlIIIIll = false;
    public CBModule IIIlIIllllIIllllllIlIIIll = null;
    private llllIIIIIlIlIlIlIllIIIIII IllIllIIIlIIlllIIIllIllII;
    private llllIIIIIlIlIlIlIllIIIIII IlIIlIIIIlIIIIllllIIlIllI;
    private final Map<CBModule, List<IlIIlllIlIIIlIIIlIlIlIlIl>> lIIlIIllIIIIIlIllIIIIllII;
    private final List<IlIIlllIlIIIlIIIlIlIlIlIl> lIIlllIIlIlllllllllIIIIIl;

    public lIlIIllIIIlllIIllIIlIIllI(List<CBModule> list, float f, int n, int n2, int n3, int n4) {
        super(f, n, n2, n3, n4);
        this.lIIIIIllllIIIIlIlIIIIlIlI = list == CBClient.getInstance().getModuleManager().staffModules;
        this.lllIIIIIlIllIlIIIllllllII = -12418828;
        this.IIIIIIlIlIlIllllllIlllIlI = new IllIIIIllllllIlllllIlIlll(this, this.lllIIIIIlIllIlIIIllllllII, f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList<>();
        for (Object object : list) {
            if (((CBModule)object).isStaffModule() && !((CBModule)object).isStaffEnabledModule()) continue;
            this.lIIIIlIIllIIlIIlIIIlIIllI.add(new IIllllIllllIIIlIIllllIlll(this, this.lllIIIIIlIllIlIIIllllllII, (CBModule)object, f));
        }
        this.IllIllIIIlIIlllIIIllIllII = new llllIIIIIlIlIlIlIllIIIIII(null, "arrow-64.png", this.IIIIllIlIIIllIlllIlllllIl + 2, this.IIIIllIIllIIIIllIllIIIlIl + 4, 28, 28, -12418828, f);
        this.IIIlIIllllIIllllllIlIIIll = null;
        this.lIIlIIllIIIIIlIllIIIIllII = new HashMap<>();
        for (CBModule object : list) {
            if (object.isStaffModule() && !object.isStaffEnabledModule() || object == CBClient.getInstance().getModuleManager().minmap) continue;
            ArrayList<IlIIlllIlIIIlIIIlIlIlIlIl> object2 = new ArrayList<>();
            for (CBSetting cBSetting : object.getSettingsList()) {
                switch (cBSetting.getType()) {
                    case BOOLEAN: {
                        object2.add(new ToggleElement(cBSetting, f));
                        break;
                    }
                    case DOUBLE:
                    case INTEGER:
                    case FLOAT: {
                        if (object.isStaffModule() && cBSetting == ((CBStaffModule)object).lIIIIlIIllIIlIIlIIIlIIllI() || object.isStaffModule() && cBSetting == object.scale) break;
                        if (cBSetting.getType().equals(SettingType.INTEGER) && cBSetting.getLabel().toLowerCase().contains("color")) {
                            object2.add(new ColorPickerElement(cBSetting, f));
                            break;
                        }
                        object2.add(new SliderElement(cBSetting, f));
                        break;
                    }
                    case STRING_ARRAY: {
                        object2.add(new ChoiceElement(cBSetting, f));
                        break;
                    }
                    case STRING: {
                        if (!cBSetting.getLabel().equalsIgnoreCase("label")) break;
                        object2.add(new StringElement(cBSetting, f));
                    }
                }
            }
            if (object.isStaffModule()) {
                object2.add(new KeybindElement(((CBStaffModule)object).lIIIIlIIllIIlIIlIIIlIIllI(), f));
                if (object == CBClient.getInstance().getModuleManager().xray) {
                    object2.add(new llllIIllIIlllllIlIlIIllll(CBClient.getInstance().getModuleManager().xray.lIllIllIlIIllIllIlIlIIlIl(), "Blocks", f));
                }
            }
            this.lIIlIIllIIIIIlIllIIIIllII.put(object, object2);
        }
        this.lIIlllIIlIlllllllllIIIIIl = new ArrayList();
        for (CBSetting object : CBClient.getInstance().getGlobalSettings().settingsList) {
            switch (object.getType()) {
                case BOOLEAN: {
                    if (object == CBClient.getInstance().getGlobalSettings().clearGlass) continue;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new ToggleElement(object, f));
                    break;
                }
                case DOUBLE:
                case INTEGER:
                case FLOAT: {
                    if (object.getType().equals(SettingType.INTEGER) && object.getLabel().toLowerCase().contains("color")) {
                        this.lIIlllIIlIlllllllllIIIIIl.add(new ColorPickerElement((CBSetting)object, f));
                        break;
                    }
                    if (object.getLabel().equals("World Time")) {
                        this.lIIlllIIlIlllllllllIIIIIl.add(new WorldTimeElement((CBSetting)object, f));
                        break;
                    }
                    this.lIIlllIIlIlllllllllIIIIIl.add(new SliderElement((CBSetting)object, f));
                    break;
                }
                case STRING_ARRAY: {
                    if (object == CBClient.getInstance().getGlobalSettings().clearGlass) continue;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new ChoiceElement((CBSetting)object, f));
                    break;
                }
                case STRING: {
                    if (!object.getLabel().equalsIgnoreCase("label")) break;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new StringElement(object, f));
                    if (!CBClient.getInstance().getGlobalSettings().IIIIllIlIIIllIlllIlllllIl().getValue().equals(object.getValue())) break;
                    this.lIIlllIIlIlllllllllIIIIIl.add(new CrosshairElement(f));
                }
            }
        }
        int n5 = 25;
        for (Object object2 : this.lIIlllIIlIlllllllllIIIIIl) {
            n5 += ((IlIIlllIlIIIlIIIlIlIlIlIl)object2).lIIIIlIIllIIlIIlIIIlIIllI();
        }
        this.IlIIlIIIIlIIIIllllIIlIllI = new llllIIIIIlIlIlIlIllIIIIII(CBClient.getInstance().IlllIllIlIIIIlIIlIIllIIIl, null, "Apply to all text", this.IIIIllIlIIIllIlllIlllllIl + n3 - 120, this.IIIIllIIllIIIIllIllIIIlIl + n5 + 4, 110, 28, -12418828, f);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + 2, (double)8, -657931);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
        if (this.IIIlIIllllIIllllllIlIIIll == null && !this.llIlIIIlIIIIlIlllIlIIIIll) {
            this.IlllIllIlIIIIlIIlIIllIIIl = 52;
            if (!this.lIIIIIllllIIIIlIlIIIIlIlI) {
                this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 4, this.IlIlIIIlllIIIlIlllIlIllIl - 12, 18);
                this.IIIIIIlIlIlIllllllIlllIlI.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
                this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            }
            for (int i = 0; i < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++i) {
                IIllllIllllIIIlIIllllIlll iIllllIllllIIIlIIllllIlll = this.lIIIIlIIllIIlIIlIIIlIIllI.get(i);
                iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + (this.lIIIIIllllIIIIlIlIIIIlIlI ? 4 : 24) + i * 20, this.IlIlIIIlllIIIlIlllIlIllIl - 12, 18);
                iIllllIllllIIIlIIllllIlll.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
                iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
                this.IlllIllIlIIIIlIIlIIllIIIl += iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI();
            }
        } else if (this.llIlIIIlIIIIlIlllIlIIIIll && !this.lIIIIIllllIIIIlIlIIIIlIlI) {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 32, this.IIIIllIIllIIIIllIllIIIlIl + 4, this.IIIIllIlIIIllIlllIlllllIl + 33, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII - 4, 0x2F2F2F2F);
            this.IlllIllIlIIIIlIIlIIllIIIl = 25;
            this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 2, this.IIIIllIIllIIIIllIllIIIlIl + 2, 28, 28);
            this.IllIllIIIlIIlllIIIllIllII.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString("CheatBreaker Settings".toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 38, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 6), -1358954496);
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 38, this.IIIIllIIllIIIIllIllIIIlIl + 17, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6, this.IIIIllIIllIIIIllIllIIIlIl + 18, 0x2F2F2F2F);
            int n3 = 0;
            for (IlIIlllIlIIIlIIIlIlIlIlIl ilIIlllIlIIIlIIIlIlIlIlIl : this.lIIlllIIlIlllllllllIIIIIl) {
                ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 38, this.IIIIllIIllIIIIllIllIIIlIl + 22 + n3, this.IlIlIIIlllIIIlIlllIlIllIl - 40, ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI());
                ilIIlllIlIIIlIIIlIlIlIlIl.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
                ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
                n3 += 2 + ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
                this.IlllIllIlIIIIlIIlIIllIIIl += 2 + ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
            this.IlIIlIIIIlIIIIllllIIlIllI.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 118, this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl, 100, 20);
            this.IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            this.IlllIllIlIIIIlIIlIIllIIIl += 24;
        } else {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 32, this.IIIIllIIllIIIIllIllIIIlIl + 4, this.IIIIllIlIIIllIlllIlllllIl + 33, this.IIIIllIIllIIIIllIllIIIlIl + (Math.max(this.IIIllIllIlIlllllllIlIlIII, this.IlllIllIlIIIIlIIlIIllIIIl)) - 4, 0x2F2F2F2F);
            this.IlllIllIlIIIIlIIlIIllIIIl = 37;
            this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 2, this.IIIIllIIllIIIIllIllIIIlIl + 2, 28, 28);
            this.IllIllIIIlIIlllIIIllIllII.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString((this.IIIlIIllllIIllllllIlIIIll.getName() + " Settings").toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 38, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 6), -1358954496);
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + 38, this.IIIIllIIllIIIIllIllIIIlIl + 17, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 12, this.IIIIllIIllIIIIllIllIIIlIl + 18, 0x2F2F2F2F);
            if (this.IIIlIIllllIIllllllIlIIIll == CBClient.getInstance().getModuleManager().minmap) {
                try {
                    String string = Keyboard.getKeyName(CBClient.getInstance().getModuleManager().minmap.lIIIIlIIllIIlIIlIIIlIIllI().getMapOptions().keyBindMenu.getKeyCode());
                    CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(("PRESS '" + string + "' INGAME FOR ZAN'S MINIMAP OPTIONS.").toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 38, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 22), -1895825408);
                }
                catch (Exception exception) {
                    CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString("PRESS 'M' INGAME FOR ZAN'S MINIMAP OPTIONS.".toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 38, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 22), -1895825408);
                }
                this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
                return;
            }
            if (this.IIIlIIllllIIllllllIlIIIll.getSettingsList().isEmpty()) {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString((this.IIIlIIllllIIllllllIlIIIll.getName().toUpperCase() + " DOES NOT HAVE ANY OPTIONS.").toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 38, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 22), -1895825408);
            }
            int n4 = 0;
            for (IlIIlllIlIIIlIIIlIlIlIlIl ilIIlllIlIIIlIIIlIlIlIlIl : this.lIIlIIllIIIIIlIllIIIIllII.get(this.IIIlIIllllIIllllllIlIIIll)) {
                ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 38, this.IIIIllIIllIIIIllIllIIIlIl + 22 + n4, this.IlIlIIIlllIIIlIlllIlIllIl - 40, ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI());
                ilIIlllIlIIIlIIIlIlIlIlIl.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
                ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
                n4 += 2 + ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
                this.IlllIllIlIIIIlIIlIIllIIIl += 2 + ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI();
            }
        }
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        block13: {
            block14: {
                block12: {
                    if (this.IIIlIIllllIIllllllIlIIIll != null || this.llIlIIIlIIIIlIlllIlIIIIll) break block12;
                    if (this.IIIIIIlIlIlIllllllIlllIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2) && !this.lIIIIIllllIIIIlIlIIIIlIlI) {
                        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                        this.llIlIIIlIIIIlIlllIlIIIIll = true;
                        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
                        this.IllIIIIIIIlIlIllllIIllIII = 0.0;
                        this.IlllIIIlIlllIllIlIIlllIlI = 0;
                    } else {
                        for (IIllllIllllIIIlIIllllIlll iIllllIllllIIIlIIllllIlll : this.lIIIIlIIllIIlIIlIIIlIIllI) {
                            if (!iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2) || !this.lIIIIlIIllIIlIIlIIIlIIllI(iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI)) continue;
                            iIllllIllllIIIlIIllllIlll.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
                        }
                    }
                    break block13;
                }
                if (!this.IllIllIIIlIIlllIIIllIllII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) break block14;
                Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                this.IIIlIIllllIIllllllIlIIIll = null;
                this.llIlIIIlIIIIlIlllIlIIIIll = false;
                if (this.IIIlllIIIllIllIlIIIIIIlII == null) break block13;
                CBModulesGui.instance.IlllIllIlIIIIlIIlIIllIIIl = this.IIIlllIIIllIllIlIIIIIIlII;
                break block13;
            }
            if (this.IIIlIIllllIIllllllIlIIIll != null) {
                for (IlIIlllIlIIIlIIIlIlIlIlIl ilIIlllIlIIIlIIIlIlIlIlIl : this.lIIlIIllIIIIIlIllIIIIllII.get(this.IIIlIIllllIIllllllIlIIIll)) {
                    if (!ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) continue;
                    ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
                }
            } else if (this.llIlIIIlIIIIlIlllIlIIIIll) {
                if (this.IlIIlIIIIlIIIIllllIIlIllI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
                    for (CBModule cBModule : CBClient.getInstance().getModuleManager().modules) {
                        for (CBSetting cBSetting : cBModule.getSettingsList()) {
                            if (cBSetting.getType() != SettingType.INTEGER || !cBSetting.getLabel().toLowerCase().contains("color") || cBSetting.getLabel().toLowerCase().contains("background")) continue;
                            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
                            cBSetting.setValue(CBClient.getInstance().getGlobalSettings().defaultColor.getValue());
                        }
                    }
                } else {
                    for (IlIIlllIlIIIlIIIlIlIlIlIl ilIIlllIlIIIlIIIlIlIlIlIl : this.lIIlllIIlIlllllllllIIIIIl) {
                        if (!ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) continue;
                        ilIIlllIlIIIlIIIlIlIlIlIl.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
                    }
                }
            }
        }
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule) {
        return !cBModule.getSettingsList().isEmpty() || cBModule.getName().contains("Zans");
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
        this.lIIIIllIIlIlIllIIIlIllIlI = 0;
        this.IllIIIIIIIlIlIllllIIllIII = 0.0;
        this.IlllIIIlIlllIllIlIIlllIlI = 0;
        this.IIIlIIllllIIllllllIlIIIll = cBModule;
        this.IIIlllIIIllIllIlIIIIIIlII = null;
    }
}
