package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBSetting;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class ToggleElement
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    private CBSetting lIIIIlIIllIIlIIlIIIlIIllI;
    private ResourceLocation IllIIIIIIIlIlIllllIIllIII = new ResourceLocation("client/icons/left.png");
    private ResourceLocation lIIIIllIIlIlIllIIIlIllIlI = new ResourceLocation("client/icons/right.png");
    private int IlllIllIlIIIIlIIlIIllIIIl = 0;
    private float IlIlllIIIIllIllllIllIIlIl = 0.0f;
    private String llIIlllIIIIlllIllIlIlllIl;

    public ToggleElement(CBSetting cBSetting, float f) {
        super(f);
        this.lIIIIlIIllIIlIIlIIIlIIllI = cBSetting;
        this.IIIllIllIlIlllllllIlIlIII = 12;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        boolean bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 10) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString(this.lIIIIlIIllIIlIIlIIIlIIllI.getLabel().toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + 10, (float)(this.IIIIllIIllIIIIllIllIIIlIl + 2), bl2 || bl ? -1090519040 : -1895825408);
        if (this.IlllIllIlIIIIlIIlIIllIIIl == 0) {
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((Boolean) this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() ? "ON" : "OFF", this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
        } else {
            boolean bl3 = this.IlllIllIlIIIIlIIlIIllIIIl == 1;
            CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString(this.llIIlllIIIIlllIllIlIlllIl, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) - (bl3 ? -this.IlIlllIIIIllIllllIllIIlIl : this.IlIlllIIIIllIllllIllIIlIl), this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
            if (bl3) {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((Boolean) this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() ? "ON" : "OFF", (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 98) + this.IlIlllIIIIllIllllIllIIlIl, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
            } else {
                CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawCenteredString((Boolean) this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() ? "ON" : "OFF", (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 2) - this.IlIlllIIIIllIllllIllIIlIl, this.IIIIllIIllIIIIllIllIIIlIl + 2, -1895825408);
            }
            if (this.IlIlllIIIIllIllllIllIIlIl >= (float)50) {
                this.IlllIllIlIIIIlIIlIIllIIIl = 0;
                this.IlIlllIIIIllIllllIllIIlIl = 0.0f;
            } else {
                float f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI((float)50 + this.IlIlllIIIIllIllllIllIIlIl * (float)15);
                this.IlIlllIIIIllIllllIllIIlIl = this.IlIlllIIIIllIllllIllIIlIl + f2 >= (float)50 ? (float)50 : (this.IlIlllIIIIllIllllIllIIlIl += f2);
            }
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 130, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 72, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 22, this.IIIIllIIllIIIIllIllIIIlIl + 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 12, -723724);
        }
        GL11.glColor4f(0.0f, 0.0f, 0.0f, bl2 ? 0.74000007f * 1.081081f : 0.288f * 1.5625f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.IllIIIIIIIlIlIllllIIllIII, (float)4, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 82), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3));
        GL11.glColor4f(0.0f, 0.0f, 0.0f, bl ? 0.4244898f * 1.8846154f : 0.64285713f * 0.7f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.lIIIIllIIlIlIllIIIlIllIlI, (float)4, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 22), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 3));
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 10) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        boolean bl3 = bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 48) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + 10 + this.IlllIIIlIlllIllIlIIlllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if ((bl || bl2) && this.IlllIllIlIIIIlIIlIIllIIIl == 0) {
            this.IlllIllIlIIIIlIIlIIllIIIl = bl ? 1 : 2;
            this.IlIlllIIIIllIllllIllIIlIl = 0.0f;
            this.llIIlllIIIIlllIllIlIlllIl = (Boolean) this.lIIIIlIIllIIlIIlIIIlIIllI.getValue() ? "ON" : "OFF";
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            this.lIIIIlIIllIIlIIlIIIlIIllI.setValue(!((Boolean) this.lIIIIlIIllIIlIIlIIIlIIllI.getValue()));
            if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getModuleManager().keyStrokes.scale) {
                CBClient.getInstance().getModuleManager().keyStrokes.initialize();
            } else if (this.lIIIIlIIllIIlIIlIIIlIIllI == CBClient.getInstance().getGlobalSettings().enableTeamView && !(Boolean) CBClient.getInstance().getGlobalSettings().enableTeamView.getValue()) {
                CBClient.getInstance().getGlobalSettings().enableTeamView.setValue(false);
            }
        }
    }
}