package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

public class llllIIlIlIllIllllIIIIllll
        extends lllIllIllIlIllIlIIllllIIl {
    private final List<IIIllllIlIIlIIIlIlIlllIII> lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList<>();

    public llllIIlIlIllIllllIIIIllll(float f, int n, int n2, int n3, int n4) {
        super(f, n, n2, n3, n4);
        for (CBModule cBModule : CBClient.getInstance().getModuleManager().modules) {
            if (cBModule == CBClient.getInstance().getModuleManager().notifications) continue;
            IIIllllIlIIlIIIlIlIlllIII iIIllllIlIIlIIIlIlIlllIII = new IIIllllIlIIlIIIlIlIlllIII(this, cBModule, f);
            this.lIIIIlIIllIIlIIlIIIlIIllI.add(iIIllllIlIIlIIIlIlIlllIII);
        }
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule) {
        return false;
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)this.IIIIllIlIIIllIlllIlllllIl, (double)this.IIIIllIIllIIIIllIllIIIlIl, (double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl), (double)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + 2), (double)8, -657931);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
        int n3 = 0;
        int n4 = 0;
        for (IIIllllIlIIlIIIlIlIlllIII iIIllllIlIIlIIIlIlIlllIII : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            iIIllllIlIIlIIIlIlIlllIII.IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            iIIllllIlIIlIIIlIlIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4 + n3 * 120, this.IIIIllIIllIIIIllIllIIIlIl + 4 + n4 * 112, 116, 108);
            iIIllllIlIIlIIIlIlIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            if (++n3 != 3) continue;
            ++n4;
            n3 = 0;
        }
        this.IlllIllIlIIIIlIIlIIllIIIl = 4 + n4 * 112 + 112;
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        super.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        for (IIIllllIlIIlIIIlIlIlllIII iIIllllIlIIlIIIlIlIlllIII : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (!iIIllllIlIIlIIIlIlIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) continue;
            iIIllllIlIIlIIIlIlIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
        }
    }
}
