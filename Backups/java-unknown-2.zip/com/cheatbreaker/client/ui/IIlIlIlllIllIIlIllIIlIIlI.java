package com.cheatbreaker.client.ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.config.CBProfile;
import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class IIlIlIlllIllIIlIllIIlIIlI extends lllIllIllIlIllIlIIllllIIl {
    private final int IIIlllIIIllIllIlIIIIIIlII;
    public final List<IIlIlllllIIIlIIllIllIlIlI> lIIIIlIIllIIlIIlIIIlIIllI;
    private final ResourceLocation llIlIIIlIIIIlIlllIlIIIIll = new ResourceLocation("client/icons/plus-64.png");

    public IIlIlIlllIllIIlIllIIlIIlI(float f, int n, int n2, int n3, int n4) {
        super(f, n, n2, n3, n4);
        this.IIIlllIIIllIllIlIIIIIIlII = -12418828;
        this.lIIIIlIIllIIlIIlIIIlIIllI = new ArrayList<>();
        this.lIIIIIIIIIlIllIIllIlIIlIl();
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        Object object;
        int n3;
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)this.IIIIllIlIIIllIlllIlllllIl, (double)this.IIIIllIIllIIIIllIllIIIlIl, (double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl), (double)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + 2), (double)8, -657931);
        this.lIIIIIIIIIlIllIIllIlIIlIl(n, n2);
        this.IlllIllIlIIIIlIIlIIllIIIl = 15;
        for (n3 = 0; n3 < this.lIIIIlIIllIIlIIlIIIlIIllI.size(); ++n3) {
            object = (IIlIlllllIIIlIIllIllIlIlI)this.lIIIIlIIllIIlIIlIIIlIIllI.get(n3);
            ((IlIIlllIlIIIlIIIlIlIlIlIl)object).lIIIIlIIllIIlIIlIIIlIIllI(this.IIIIllIlIIIllIlllIlllllIl + 4, this.IIIIllIIllIIIIllIllIIIlIl + 4 + n3 * 18, this.IlIlIIIlllIIIlIlllIlIllIl - 12, 18);
            ((IIlIlllllIIIlIIllIllIlIlI)object).IlllIIIlIlllIllIlIIlllIlI = this.lIIIIllIIlIlIllIIIlIllIlI;
            ((IIlIlllllIIIlIIllIllIlIlI)object).lIIIIlIIllIIlIIlIIIlIIllI(n, n2, f);
            this.IlllIllIlIIIIlIIlIIllIIIl += ((IlIIlllIlIIIlIIIlIlIlIlIl)object).lIIIIlIIllIIlIIlIIIlIIllI();
        }
        n3 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 10 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl + 3 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl ? 1 : 0;
        GL11.glColor4f(n3 != 0 ? 0.0f : 0.22590362f * 1.1066667f, n3 != 0 ? 1.4117647f * 0.56666666f : 1.3333334f * 0.1875f, n3 != 0 ? 0.0f : 0.14423077f * 1.7333333f, 1.7058823f * 0.38103446f);
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(this.llIlIIIlIIIIlIlllIlIIIIll, 3.4435484f * 1.0163934f, (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 15), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl) - 0.6506024f * 9.990741f);
        object = (n3 != 0 ? "(COPIES CURRENT PROFILE) " : "") + "ADD NEW PROFILE";
        CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.drawString((String)object, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 17 - CBClient.getInstance().lIIIIllIIlIlIllIIIlIllIlI.getStringWidth((String)object), (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl) - 64.28571f * 0.11666667f, n3 != 0 ? 0x7F007F00 : 0x7F000000);
        this.IlllIllIlIIIIlIIlIIllIIIl += 10;
        this.IlllIIIlIlllIllIlIIlllIlI(n, n2);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
        boolean bl;
        for (IIlIlllllIIIlIIllIllIlIlI iIlIlllllIIIlIIllIllIlIlI : this.lIIIIlIIllIIlIIlIIIlIIllI) {
            if (!iIlIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) continue;
            iIlIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3);
            return;
        }
        boolean bl2 = bl = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 92) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 20 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 < (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IlllIllIlIIIIlIIlIIllIIIl - 7 + this.lIIIIllIIlIlIllIIIlIllIlI) * this.lIIIIIIIIIlIllIIllIlIIlIl;
        if (bl) {
            Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
            Minecraft.getMinecraft().displayGuiScreen(new llIIIlIlIIlIlIIlIllIllIll(CBModulesGui.instance, this, this.IIIlllIIIllIllIlIIIIIIlII, this.lIIIIIIIIIlIllIIllIlIIlIl));
        }
    }

    @Override
    public boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule cBModule) {
        return true;
    }

    @Override
    public void lIIIIIIIIIlIllIIllIlIIlIl(CBModule cBModule) {
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl() {
        new Thread(() -> {
            this.lIIIIlIIllIIlIIlIIIlIIllI.clear();
            File file = new File(Minecraft.getMinecraft().mcDataDir + File.separator + "config" + File.separator + "client" + File.separator + "profiles");
            if (file.exists()) {
                for (File file2 : file.listFiles()) {
                    if (!file2.getName().endsWith(".cfg")) continue;
                    CBProfile ilIIlIIlIIlllIlIIIlIllIIl = null;
                    for (CBProfile ilIIlIIlIIlllIlIIIlIllIIl2 : CBClient.getInstance().profiles) {
                        if (!file2.getName().equals(ilIIlIIlIIlllIlIIIlIllIIl2.getName() + ".cfg")) continue;
                        ilIIlIIlIIlllIlIIIlIllIIl = ilIIlIIlIIlllIlIIIlIllIIl2;
                    }
                    if (ilIIlIIlIIlllIlIIIlIllIIl != null) continue;
                    CBClient.getInstance().profiles.add(new CBProfile(file2.getName().replace(".cfg", ""), false));
                }
            }
            for (CBProfile ilIIlIIlIIlllIlIIIlIllIIl : CBClient.getInstance().profiles) {
                this.lIIIIlIIllIIlIIlIIIlIIllI.add(new IIlIlllllIIIlIIllIllIlIlI(this, this.IIIlllIIIllIllIlIIIIIIlII, ilIIlIIlIIlllIlIIIlIllIIl, this.lIIIIIIIIIlIllIIllIlIIlIl));
            }
            this.lIIIIlIIllIIlIIlIIIlIIllI.sort((iIlIlllllIIIlIIllIllIlIlI, iIlIlllllIIIlIIllIllIlIlI2) -> {
                if (iIlIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.getName().equalsIgnoreCase("default")) {
                    return 0;
                }
                if (iIlIlllllIIIlIIllIllIlIlI.lIIIIlIIllIIlIIlIIIlIIllI.getIndex() < iIlIlllllIIIlIIllIllIlIlI2.lIIIIlIIllIIlIIlIIIlIIllI.getIndex()) {
                    return -1;
                }
                return 1;
            });
        }).start();
    }
}