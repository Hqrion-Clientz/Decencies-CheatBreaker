package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.module.CBModule;
import com.cheatbreaker.client.util.RenderUtil;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public abstract class lllIllIllIlIllIlIIllllIIl
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    protected double IllIIIIIIIlIlIllllIIllIII = 0.0;
    public int lIIIIllIIlIlIllIIIlIllIlI = 0;
    protected int IlllIllIlIIIIlIIlIIllIIIl = 0;
    public int IlIlllIIIIllIllllIllIIlIl;
    protected int llIIlllIIIIlllIllIlIlllIl;
    public boolean lIIlIlIllIIlIIIlIIIlllIII = false;
    private boolean lIIIIlIIllIIlIIlIIIlIIllI = false;
    private float IIIlllIIIllIllIlIIIIIIlII;

    public lllIllIllIlIllIlIIllllIIl(float f, int n, int n2, int n3, int n4) {
        super(f);
        this.IlIlllIIIIllIllllIllIIlIl = n;
        this.llIIlllIIIIlllIllIlIlllIl = n2;
        this.IIIIllIlIIIllIlllIlllllIl = n;
        this.IIIIllIIllIIIIllIllIIIlIl = n2;
        this.IlIlIIIlllIIIlIlllIlIllIl = n3;
        this.IIIllIllIlIlllllllIlIlIII = n4;
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl(int n, int n2) {
        if (this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2)) {
            double d = Math.round(this.IllIIIIIIIlIlIllllIIllIII / (double)25);
            this.IllIIIIIIIlIlIllllIIllIII -= d;
            if (this.IllIIIIIIIlIlIllllIIllIII != 0.0) {
                this.lIIIIllIIlIlIllIIIlIllIlI = (int)((double)this.lIIIIllIIlIlIllIIIlIllIlI + d);
            }
        } else {
            this.IllIIIIIIIlIlIllllIIllIII = 0.0;
        }
        if (this.lIIlIlIllIIlIIIlIIIlllIII) {
            if (this.lIIIIllIIlIlIllIIIlIllIlI < -this.IlllIllIlIIIIlIIlIIllIIIl + this.IIIllIllIlIlllllllIlIlIII) {
                this.lIIIIllIIlIlIllIIIlIllIlI = -this.IlllIllIlIIIIlIIlIIllIIIl + this.IIIllIllIlIlllllllIlIlIII;
                this.IllIIIIIIIlIlIllllIIllIII = 0.0;
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI > 0) {
                this.lIIIIllIIlIlIllIIIlIllIlI = 0;
                this.IllIIIIIIIlIlIllllIIllIII = 0.0;
            }
        }
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, this.lIIIIllIIlIlIllIIIlIllIlI, 0.0f);
    }

    public void IlllIIIlIlllIllIlIIlllIlI(int n, int n2) {
        boolean bl;
        this.lIIlIlIllIIlIIIlIIIlllIII = true;
        GL11.glPopMatrix();
        boolean bl2 = bl = this.IlllIllIlIIIIlIIlIIllIIIl > this.IIIllIllIlIlllllllIlIlIII;
        if (!(!this.lIIIIlIIllIIlIIlIIIlIIllI || Mouse.isButtonDown(0) && this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2))) {
            this.lIIIIlIIllIIlIIlIIIlIIllI = false;
        }
        double d = this.IIIllIllIlIlllllllIlIlIII - 10;
        double d2 = this.IlllIllIlIIIIlIIlIIllIIIl;
        double d3 = d / d2 * (double)100;
        double d4 = d / (double)100 * d3;
        double d5 = (double)this.lIIIIllIIlIlIllIIIlIllIlI / (double)100 * d3;
        if (bl) {
            boolean bl3;
            int n3 = this.IIIllIllIlIlllllllIlIlIII;
            boolean bl4 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 9) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 3) * this.lIIIIIIIIIlIllIIllIlIIlIl && (double)n2 > ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl && (double)n2 < ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 8) + d4 - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl;
            boolean bl5 = bl3 = (float)n > (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 9) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n < (float)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 3) * this.lIIIIIIIIIlIllIIllIlIIlIl && (float)n2 > (float)(this.IIIIllIIllIIIIllIllIIIlIl + 11) * this.lIIIIIIIIIlIllIIllIlIIlIl && (double)n2 < ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 6) + d - (double)3) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl;
            if (Mouse.isButtonDown(0) && !this.lIIIIlIIllIIlIIlIIIlIIllI && bl3) {
                this.lIIIIlIIllIIlIIlIIIlIIllI = true;
            }
            if (this.lIIIIlIIllIIlIIlIIIlIIllI) {
                if ((float)this.lIIIIllIIlIlIllIIIlIllIlI != this.IIIlllIIIllIllIlIIIIIIlII && (double)this.IIIlllIIIllIllIlIIIIIIlII != d4 / (double)2 && (double)this.IIIlllIIIllIllIlIIIIIIlII != d4 / (double)2 + (double)(-this.IlllIllIlIIIIlIIlIIllIIIl) + (double)n3) {
                    if ((double)n2 > ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) + d4 - d4 / (double)4 - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl) {
                        this.lIIIIllIIlIlIllIIIlIllIlI = (int)((double)this.lIIIIllIIlIlIllIIIlIllIlI - d2 / (double)7);
                    } else if ((double)n2 < ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) + d4 / (double)4 - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl) {
                        this.lIIIIllIIlIlIllIIIlIllIlI = (int)((double)this.lIIIIllIIlIlIllIIIlIllIlI + d2 / (double)7);
                    }
                    this.IIIlllIIIllIllIlIIIIIIlII = this.lIIIIllIIlIlIllIIIlIllIlI;
                } else if ((double)n2 > ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) + d4 - d4 / (double)4 - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl || (double)n2 < ((double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) + d4 / (double)4 - d5) * (double)this.lIIIIIIIIIlIllIIllIlIIlIl) {
                    this.IIIlllIIIllIllIlIIIIIIlII = 1.0f;
                }
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI < -this.IlllIllIlIIIIlIIlIIllIIIl + n3) {
                this.lIIIIllIIlIlIllIIIlIllIlI = -this.IlllIllIlIIIIlIIlIIllIIIl + n3;
                this.IllIIIIIIIlIlIllllIIllIII = 0.0;
            }
            if (this.lIIIIllIIlIlIllIIIlIllIlI > 0) {
                this.lIIIIllIIlIlIllIIIlIllIlI = 0;
                this.IllIIIIIIIlIlIllllIIllIII = 0.0;
            }
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 6), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 11), (double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 4), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 6) + d - (double)3, (double)2, bl3 && !bl4 ? 0x6F000000 : 0x3F000000);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI((double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 7), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 11) - d5, (double)(this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl - 3), (double)(this.IIIIllIIllIIIIllIllIIIlIl + 8) + d4 - d5, (double)4, bl4 || this.lIIIIlIIllIIlIIlIIIlIIllI ? -16629505 : -12418828);
        }
        if (!bl && this.lIIIIllIIlIlIllIIIlIllIlI != 0) {
            this.lIIIIllIIlIlIllIIIlIllIlI = 0;
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n) {
        if (n != 0 && this.IlllIllIlIIIIlIIlIIllIIIl >= this.IIIllIllIlIlllllllIlIlIII) {
            this.IllIIIIIIIlIlIllllIIllIII += (double)(n / 2);
        }
    }

    public abstract boolean lIIIIlIIllIIlIIlIIIlIIllI(CBModule var1);

    public abstract void lIIIIIIIIIlIllIIllIlIIlIl(CBModule var1);
}
