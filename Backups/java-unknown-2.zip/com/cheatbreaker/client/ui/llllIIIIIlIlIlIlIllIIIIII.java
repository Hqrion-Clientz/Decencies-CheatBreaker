package com.cheatbreaker.client.ui;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.util.RenderUtil;
import com.cheatbreaker.client.util.font.CBFontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class llllIIIIIlIlIlIlIllIIIIII
        extends IlIIlllIlIIIlIIIlIlIlIlIl {
    public int lIIIIlIIllIIlIIlIIIlIIllI;
    public String IllIIIIIIIlIlIllllIIllIII;
    public final lllIllIllIlIllIlIIllllIIl lIIIIllIIlIlIllIIIlIllIlI;
    private final CBFontRenderer IlIlllIIIIllIllllIllIIlIl;
    public boolean IlllIllIlIIIIlIIlIIllIIIl = true;
    private int llIIlllIIIIlllIllIlIlllIl = 0;

    public llllIIIIIlIlIlIlIllIIIIII(CBFontRenderer lIlIllIlIlIIIllllIlIllIll2, lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, String string, int n, int n2, int n3, int n4, int n5, float f) {
        super(f);
        this.IllIIIIIIIlIlIllllIIllIII = string;
        this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2, n3, n4);
        this.lIIIIlIIllIIlIIlIIIlIIllI = n5;
        this.lIIIIllIIlIlIllIIIlIllIlI = lllIllIllIlIllIlIIllllIIl2;
        this.IlIlllIIIIllIllllIllIIlIl = lIlIllIlIlIIIllllIlIllIll2;
    }

    public llllIIIIIlIlIlIlIllIIIIII(lllIllIllIlIllIlIIllllIIl lllIllIllIlIllIlIIllllIIl2, String string, int n, int n2, int n3, int n4, int n5, float f) {
        this(CBClient.getInstance().IIIllIllIlIlllllllIlIlIII, lllIllIllIlIllIlIIllllIIl2, string, n, n2, n3, n4, n5, f);
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, float f) {
        float f2;
        boolean bl = this.lIIIIlIIllIIlIIlIIIlIIllI(n, n2);
        int n3 = 120;
        if (bl && this.IlllIllIlIIIIlIIlIIllIIIl) {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl - 2, this.IIIIllIIllIIIIllIllIIIlIl - 2, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl + 2, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII + 2, -854025);
            f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
            this.llIIlllIIIIlllIllIlIlllIl = (float)this.llIIlllIIIIlllIllIlIlllIl + f2 < (float)n3 ? (int)((float)this.llIIlllIIIIlllIllIlIlllIl + f2) : n3;
        } else if (this.llIIlllIIIIlllIllIlIlllIl > 0) {
            f2 = CBModulesGui.lIIIIlIIllIIlIIlIIIlIIllI(790);
            this.llIIlllIIIIlllIllIlIlllIl = (float)this.llIIlllIIIIlllIllIlIlllIl - f2 < 0.0f ? 0 : (int)((float)this.llIIlllIIIIlllIllIlIlllIl - f2);
        }
        if (this.IlllIllIlIIIIlIIlIIllIIIl) {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, -723724);
        } else {
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, this.IIIIllIIllIIIIllIllIIIlIl, this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, -1611336460);
        }
        if (this.llIIlllIIIIlllIllIlIlllIl > 0) {
            f2 = (float)this.llIIlllIIIIlllIllIlIlllIl / (float)n3 * (float)100;
            Gui.drawRect(this.IIIIllIlIIIllIlllIlllllIl, (int)((float)this.IIIIllIIllIIIIllIllIIIlIl + ((float)this.IIIllIllIlIlllllllIlIlIII - (float)this.IIIllIllIlIlllllllIlIlIII * f2 / (float)100)), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl, this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII, this.lIIIIlIIllIIlIIlIIIlIIllI);
        }
        if (this.IllIIIIIIIlIlIllllIIllIII.contains(".png")) {
            GL11.glPushMatrix();
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.47368422f * 0.9499999f);
            RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(new ResourceLocation("client/icons/" + this.IllIIIIIIIlIlIllllIIllIII), (float)8, (float)(this.IIIIllIlIIIllIlllIlllllIl + 6), (float)(this.IIIIllIIllIIIIllIllIIIlIl + 6));
            GL11.glPopMatrix();
        } else {
            // IIIllIllIlIlllllllIlIlIII = Fontrenderer
            f2 = this.IlIlllIIIIllIllllIllIIlIl == CBClient.getInstance().IIIllIllIlIlllllllIlIlIII ? 2.0f : 0.54545456f * 0.9166667f;
            this.IlIlllIIIIllIllllIllIIlIl.drawString(this.IllIIIIIIIlIlIllllIIllIII.toUpperCase(), this.IIIIllIlIIIllIlllIlllllIl + this.IlIlIIIlllIIIlIlllIlIllIl / 2, (float)(this.IIIIllIIllIIIIllIllIIIlIl + this.IIIllIllIlIlllllllIlIlIII / 2 - this.IlIlllIIIIllIllllIllIIlIl.getHeight()) + f2, 0x6F000000);
        }
    }

    @Override
    public void lIIIIlIIllIIlIIlIIIlIIllI(int n, int n2, int n3) {
    }

    public int lIIIIIIIIIlIllIIllIlIIlIl() {
        return this.IlIlIIIlllIIIlIlllIlIllIl;
    }

    public void lIIIIlIIllIIlIIlIIIlIIllI(boolean bl) {
        this.IlllIllIlIIIIlIIlIIllIIIl = bl;
    }
}
