package com.cheatbreaker.client.config;

import com.cheatbreaker.client.CBClient;
import com.cheatbreaker.client.ui.IllllllllIlIIIIIIIIllIIII;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import org.apache.commons.lang3.ArrayUtils;

import java.util.ArrayList;
import java.util.List;

public class CBGlobalSettings {

    public KeyBinding openMenu;
    public KeyBinding setValue;
    public KeyBinding voiceMenu;
    public KeyBinding dragLook;
    public KeyBinding hideNames;
    public final List<CBSetting> settingsList = new ArrayList<>();
    private List<String[]> networkAddressPair;
    private List<String> dummyDomainList;
    public boolean IIIllIllIlIlllllllIlIlIII = false;
    public String IllIIIIIIIlIlIllllIIllIII = "https://cheatbreaker.com/crash-report-upload";
    public String lIIIIllIIlIlIllIIIlIllIlI = "https://cheatbreaker.com/debug-upload";
    public String IlllIllIlIIIIlIIlIIllIIIl = "https://cheatbreaker.com/api/cosmetic/";
    public String IlIlllIIIIllIllllIllIIlIl = "https://cheatbreaker.com/api/cosmetic/all";
    public String llIIlllIIIIlllIllIlIlllIl = "https://status.mojang.com/check";
    public int lIIlIlIllIIlIIIlIIIlllIII = 60;
    public boolean IIIlllIIIllIllIlIIIIIIlII = true;
    private CBSetting audioSettingsLabel;
    public CBSetting microphoneSetting;
    public CBSetting radioVolume;
    public CBSetting microphoneVolume;
    public CBSetting speakerVolume;
    public CBSetting pinRadio;
    public CBSetting muteCheatBreakerSounds;
    private CBSetting fpsBoostLabel;
    public CBSetting enableFpsBoost;
    public CBSetting slowChunkLoading;
    public CBSetting fullBright;
    public CBSetting enchantmentGlint;
    private CBSetting teamViewLabel;
    public CBSetting enableTeamView;
    public CBSetting showDistance;
    public CBSetting showOffScreenMarker;
    private CBSetting generalSettingsLabel;
    public CBSetting guiBlur;
    public CBSetting worldTime;
    public CBSetting lookView;
    public CBSetting snapModules;
    private CBSetting renderSettingsLabel;
    public CBSetting showHudInDebug;
    public CBSetting showChatBackground;
    public CBSetting shinyPots;
    public CBSetting showPotionInfo;
    public CBSetting clearGlass;
    public CBSetting redString;
    public CBSetting transparentBackground;
    private CBSetting crosshairSettingsLabel;
    public CBSetting customCrosshair;
    public CBSetting crosshairOutline;
    public CBSetting crosshairColor;
    public CBSetting crosshairThickness;
    public CBSetting crosshairSize;
    public CBSetting crosshairGap;
    private CBSetting colorOptionsLabel;
    public CBSetting defaultColor;
    // what is this xd
    public List<IllllllllIlIIIIIIIIllIIII> lIlIllIlIlIIIllllIlIllIll = new ArrayList<>();
    public List<IllllllllIlIIIIIIIIllIIII> IlIIlIIlIllIIIIllIIllIlIl = new ArrayList<>();

//    public boolean lIIIIlIIllIIlIIlIIIlIIllI() {
//        return (Boolean)this.IlIIlIIIIlIIIIllllIIlIllI.getValue() == false || (Boolean)this.lIllIllIlIIllIllIlIlIIlIl.getValue() != false;
//    }

    public boolean lIIIIlIIllIIlIIlIIIlIIllI(int n) {
        for (IllllllllIlIIIIIIIIllIIII illllllllIlIIIIIIIIllIIII : this.lIlIllIlIlIIIllllIlIllIll) {
            if (illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI != n) continue;
            return true;
        }
        return false;
    }

    public void lIIIIIIIIIlIllIIllIlIIlIl(int n) {
        this.lIlIllIlIlIIIllllIlIllIll.removeIf(illllllllIlIIIIIIIIllIIII -> illllllllIlIIIIIIIIllIIII.lIIIIlIIllIIlIIlIIIlIIllI == n);
    }

    public CBGlobalSettings() {
        String[] audioDevices = CBClient.getAudioDeviceList();
        this.audioSettingsLabel = (new CBSetting(this.settingsList, "label")).setValue("Audio Settings");
        if (audioDevices.length > 0) {
            this.microphoneSetting = (new CBSetting(this.settingsList, "Microphone")).setValue(audioDevices[0]).acceptedValues(audioDevices).onChange((var0) -> {
                try {
                    //Message.h(CBClient.getAudioDevice((String) var0));
                    System.out.println("[CB] Updated audio device!");
                } catch (UnsatisfiedLinkError var2) {
                    System.err.println("[CB] CBAgent.dll is not attached.");

                }

            });
        } else {
            this.microphoneSetting = (new CBSetting(this.settingsList, "Microphone")).setValue("Unknown").acceptedValues("Unknown").onChange((var0) -> {
                try {
                    //Message.h(CBClient.getAudioDevice((String) var0));
                    System.out.println("[CB] Updated audio device!");
                } catch (UnsatisfiedLinkError var2) {
                    System.err.println("[CB] CBAgent.dll is not attached.");
                }
            });
        }

        this.muteCheatBreakerSounds = (new CBSetting(this.settingsList, "Mute CheatBreaker sounds")).setValue(false);
        this.pinRadio = (new CBSetting(this.settingsList, "Pin Radio Player")).setValue(false);
        this.radioVolume = (new CBSetting(this.settingsList, "Radio Volume")).onChange((var0) -> {
//            if (IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI()) {
//                IIIllIIIlIIIlIlllllIIIlll.IIIIllIlIIIllIlllIlllllIl().lIIIIlIIllIIlIIlIIIlIIllI((float)var0);
//            }
        }).setValue(85).setMinMax(55, 100);
        this.microphoneVolume = (new CBSetting(this.settingsList, "Microphone Volume")).onChange((var0) -> {
            try {
               // Message.l((float)var0);
            } catch (UnsatisfiedLinkError var2) {
                System.err.println("[CB] CBAgent.dll is not attached.");
            }

        }).setValue(70).setMinMax(0, 100);
        this.speakerVolume = (new CBSetting(this.settingsList, "Speaker Volume")).onChange((var0) -> {
            try {
                float var1 = (float)20000 / (float)(20000 - Math.max(0, Math.min(19500, (int) var0 * 195)));
                //Message.m(var1);
            } catch (UnsatisfiedLinkError var2) {
                System.err.println("[CB] CBAgent.dll is not attached.");
            }
        }).setValue(85).setMinMax(0, 100);
        this.fpsBoostLabel = new CBSetting(this.settingsList, "label").setValue("FPS Boost");
        this.enableFpsBoost = new CBSetting(this.settingsList, "Enable FPS Boost").setValue(true);
        this.slowChunkLoading = new CBSetting(this.settingsList, "Slow chunk loading (%)").setMinMax(5, 100).setValue(30);
        this.fullBright = new CBSetting(this.settingsList, "Fullbright").setValue(true);
        this.enchantmentGlint = new CBSetting(this.settingsList, "Enchantment Glint").setValue(true);
        this.teamViewLabel = new CBSetting(this.settingsList, "label").setValue("Team View Settings");
        this.enableTeamView = new CBSetting(this.settingsList, "Enable Team View").setValue(true);
        this.showOffScreenMarker = new CBSetting(this.settingsList, "Show off-screen marker").setValue(true);
        this.showDistance = new CBSetting(this.settingsList, "Show distance").setValue(true);
        this.generalSettingsLabel = new CBSetting(this.settingsList, "label").setValue("General Settings");
        this.guiBlur = new CBSetting(this.settingsList, "GUI Blur").setValue(false);
        this.worldTime = new CBSetting(this.settingsList, "World Time").setValue(-14490).setMinMax(-22880, -6100);
        this.lookView = new CBSetting(this.settingsList, "Look View").setValue("Third").acceptedValues("Third", "Reverse", "First");
        this.snapModules = new CBSetting(this.settingsList, "Snap mods to other mods (GUI)").setValue(true);
        this.renderSettingsLabel = new CBSetting(this.settingsList, "label").setValue("Render Settings");
        this.showPotionInfo = new CBSetting(this.settingsList, "Show Potion info in inventory").setValue(true);
        this.showChatBackground = new CBSetting(this.settingsList, "Show chat background").setValue(true);
        this.showHudInDebug = new CBSetting(this.settingsList, "Show HUD while in debug view").setValue(false);
        this.shinyPots = new CBSetting(this.settingsList, "Shiny Pots").setValue(false);
        this.clearGlass = new CBSetting(this.settingsList, "Clear Glass").setValue("OFF").acceptedValues("OFF", "REGULAR", "ALL");
        this.redString = new CBSetting(this.settingsList, "Red String").setValue(false);
        this.transparentBackground = new CBSetting(this.settingsList, "Transparent background").setValue(false);
        this.crosshairSettingsLabel = new CBSetting(this.settingsList, "label").setValue("Crosshair Settings");
        this.customCrosshair = new CBSetting(this.settingsList, "Custom crosshair").setValue(false);
        this.crosshairOutline = new CBSetting(this.settingsList, "Outline").setValue(false);
        this.crosshairColor = new CBSetting(this.settingsList, "Color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.crosshairThickness = new CBSetting(this.settingsList, "Thickness").setValue(2.0F).setMinMax(1.0F, 1.8478261F * 1.3529412F);
        this.crosshairSize = new CBSetting(this.settingsList, "Size").setValue((float)4).setMinMax(1.0F, (float)10);
        this.crosshairGap = new CBSetting(this.settingsList, "Gap").setValue(4.4722223F * 0.39130434F).setMinMax(0.0F, 1.0493827F * 7.147059F);
        this.colorOptionsLabel = new CBSetting(this.settingsList, "label").setValue("Color Options");
        this.defaultColor = new CBSetting(this.settingsList, "Default color").setValue(-1).setMinMax(Integer.MIN_VALUE, Integer.MAX_VALUE);
        this.networkAddressPair = new ArrayList<>();
        this.networkAddressPair.add(new String[]{"MineHQ Network", "minehq.com"});
        this.networkAddressPair.add(new String[]{"VeltPvP", "veltpvp.com"});
        this.dummyDomainList = new ArrayList<>();
        this.dummyDomainList.add("xyz.com");
        GameSettings var2 = Minecraft.getMinecraft().gameSettings;
        this.voiceMenu = new KeyBinding("Voice Chat", 47, "CheatBreaker Client", true);
        this.openMenu = new KeyBinding("Open Menu", 54, "CheatBreaker Client", true);
        this.setValue = new KeyBinding("Open Voice Menu", 25, "CheatBreaker Client", true);
        this.dragLook = new KeyBinding("Drag to look", 56, "CheatBreaker Client", true);
        this.hideNames = new KeyBinding("Hide name plates", 0, "CheatBreaker Client", true);
        var2.keyBindings = ArrayUtils.addAll(var2.keyBindings, this.voiceMenu, this.openMenu, this.setValue, this.dragLook, this.hideNames);
    }

    public CBSetting IIIIllIlIIIllIlllIlllllIl() {
        return crosshairSettingsLabel;
    }
}
