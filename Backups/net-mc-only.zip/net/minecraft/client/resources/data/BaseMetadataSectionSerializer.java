package net.minecraft.client.resources.data;

public abstract class BaseMetadataSectionSerializer implements IMetadataSectionSerializer
{

}
