package com.cheatbreaker.client.util.teammates;

import lombok.Getter;
import lombok.Setter;

public enum IlIlIIlllIIIIIlIlIlIIIllI {
    lIIIIIIIIIlIllIIllIlIIlIl,
    IIIIllIlIIIllIlllIlllllIl,
    IlllIIIlIlllIllIlIIlllIlI,
    lIIIIlIIllIIlIIlIIIlIIllI;
}
