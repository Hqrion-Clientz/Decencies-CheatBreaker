package com.cheatbreaker.client.util.friend;

public enum Status {
    ONLINE,
    AWAY,
    BUSY,
    HIDDEN;
}
