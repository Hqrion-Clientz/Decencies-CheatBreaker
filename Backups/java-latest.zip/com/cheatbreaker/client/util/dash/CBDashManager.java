package com.cheatbreaker.client.util.dash;

import java.util.List;

public class CBDashManager {

    private final List<Station> stations = DashUtil.dashHelpers();
    private final DashQueueThread dashQueueThread = new DashQueueThread();
    private final DashThread dashThread;
    private Station station;

    public CBDashManager() {
        this.dashQueueThread.start();
        this.dashThread = new DashThread();
        this.dashThread.start();
        if (this.stations.size() > 0) {
            this.station = this.stations.get(0);
            this.dashQueueThread.someThing(this.station);
        }
    }

    public void setDashHelper(Station station) {
        station.endStream();
        this.station = station;
    }

    public void endStream() {
        if (this.station != null) {
            this.station.endStream();
        }
    }

    public List<Station> getDashHelpers() {
        return this.stations;
    }

    public DashQueueThread getDashQueueThread() {
        return this.dashQueueThread;
    }

    public DashThread getDashThread() {
        return this.dashThread;
    }

    public Station getDashHelper() {
        return this.station;
    }

    public void getDashHelper(Station station) {
        this.station = station;
    }
}
 