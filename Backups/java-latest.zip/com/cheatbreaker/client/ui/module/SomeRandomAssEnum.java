package com.cheatbreaker.client.ui.module;

enum SomeRandomAssEnum {
    RIGHT_BOTTOM,
    LEFT_BOTTOM,
    RIGHT_TOP,
    LEFT_TOP;

}
