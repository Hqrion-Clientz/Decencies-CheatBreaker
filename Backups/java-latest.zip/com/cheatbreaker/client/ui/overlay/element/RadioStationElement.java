package com.cheatbreaker.client.ui.overlay.element;

import com.cheatbreaker.client.ui.util.RenderUtil;
import com.cheatbreaker.client.util.dash.Station;
import com.cheatbreaker.client.ui.mainmenu.CBAbstractElement;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RadioStationElement
        extends CBAbstractElement {
    private final Station station;
    private final ResourceLocation starIcon = new ResourceLocation("client/icons/star-21.png");
    private final ResourceLocation startFilledIcon = new ResourceLocation("client/icons/star-filled-21.png");
    private final RadioElement parent;

    public RadioStationElement(RadioElement parent, Station station) {
        this.parent = parent;
        this.station = station;
    }

    @Override
    protected void handleElementDraw(float f, float f2, boolean bl) {
        if (this.isMouseInsideElement(f, f2) && bl) {
            Gui.drawRect(this.x, this.y, this.x + (float)22, this.y + this.height, -13158601);
        } else if (this.isMouseInside(f, f2) && bl) {
            Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -13158601);
        }
        boolean bl2 = this.station.isPlay();
        if (bl2) {
            GL11.glColor4f((float)(1.1833333f * 0.8028169f), (float)(0.75956047f * 0.9479167f), (float)(0.14558825f * 1.030303f), (float)1.0f);
        } else {
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        //boolean bl3 = CBClient.getInstance().lIllIlIlllIIlIIllIIlIIlII().IIIIllIIllIIIIllIllIIIlIl() == this.IIIllIllIlIlllllllIlIlIII;
        RenderUtil.lIIIIlIIllIIlIIlIIIlIIllI(bl2 ? this.startFilledIcon : this.starIcon, (float)5, this.width + (float)6, this.height + (float)5);
        ////CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII.IIIllIllIlIlllllllIlIlIII(), this.lIIIIlIIllIIlIIlIIIlIIllI + (float)24, this.lIIIIIIIIIlIllIIllIlIIlIl + 0.627451f * 2.390625f, bl3 ? -13369549 : -1);
        //CBClient.getInstance().lIIlIlIllIIlIIIlIIIlllIII.lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII.IIIIllIIllIIIIllIllIIIlIl(), this.lIIIIlIIllIIlIIlIIIlIIllI + (float)24, this.lIIIIIIIIIlIllIIllIlIIlIl + 2.375f * 4.0f, -1342177281);
    }

    private boolean isMouseInsideElement(float f, float f2) {
        return this.isMouseInside(f, f2) && f < this.x + (float)22;
    }

    @Override
    public boolean handleElementMouseClicked(float f, float f2, int n, boolean bl) {
        if (!bl) {
            return false;
        }
        if (this.isMouseInsideElement(f, f2) && bl) {
            this.station.setFavourite(!this.station.isFavourite());
            this.parent.lIIIIllIIlIlIllIIIlIllIlI();
            return true;
        }
        if (this.isMouseInside(f, f2) && bl) {
            //if (IIIllIIIlIIIlIlllllIIIlll.IlllIIIlIlllIllIlIIlllIlI()) {
              //  IIIllIIIlIIIlIlllllIIIlll.lIIIIIIIIIlIllIIllIlIIlIl();
            //}
            this.station.play = true;
            //CheatBreaker.getInstance().lIllIlIlllIIlIIllIIlIIlII().IlllIIIlIlllIllIlIIlllIlI().lIIIIlIIllIIlIIlIIIlIIllI(this.IIIllIllIlIlllllllIlIlIII);
            //CheatBreaker.getInstance().lIllIlIlllIIlIIllIIlIIlII().lIIIIIIIIIlIllIIllIlIIlIl(this.IIIllIllIlIlllllllIlIlIII);
        }
        return false;
    }

    public Station IllIIIIIIIlIlIllllIIllIII() {
        return this.station;
    }
}
