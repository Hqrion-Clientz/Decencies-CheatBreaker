package com.cheatbreaker.client.module.type;

import java.util.Collection;
import java.util.Iterator;

import com.cheatbreaker.client.config.Setting;
import com.cheatbreaker.client.event.type.GuiDrawEvent;
import com.cheatbreaker.client.module.AbstractModule;
import com.cheatbreaker.client.module.ModuleRule;
import com.cheatbreaker.client.ui.module.CBGuiAnchor;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.scoreboard.*;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.opengl.GL11;

public class ScoreboardModule extends AbstractModule {
    public Setting removeNumbers;
    public static ModuleRule specialModType = ModuleRule.SCOREBOARD;

    public ScoreboardModule() {
        super("Scoreboard");
        this.setDefaultAnchor(CBGuiAnchor.RIGHT_MIDDLE);
        this.removeNumbers = new Setting(this, "Remove Scoreboard numbers").setValue(true);
        this.addEvent(GuiDrawEvent.class, this::renderReal);
        this.addEvent(GuiDrawEvent.class, this::renderPreview);
        this.setDefaultState(true);
    }

    private void renderPreview(GuiDrawEvent lIllIlIlllIIlIIllIIlIIlII2) {
        if (!this.isRenderHud()) {
            return;
        }
        if (this.minecraft.theWorld.getScoreboard().func_96539_a(1) != null) {
            return;
        }
        GL11.glPushMatrix();
        this.scaleAndTranslate(lIllIlIlllIIlIIllIIlIIlII2.getResolution());
        GL11.glTranslatef(this.lIIIIlIIllIIlIIlIIIlIIllI() ? (float)-12 : 2.0f, this.height, 0.0f);
        Scoreboard ilIIIIllIlIlIIIlIIIllIIlI = new Scoreboard();
        ScoreObjective iIlIlIlIlIllIlIllIIllIIII = new ScoreObjective(ilIIIIllIlIlIIIlIIIllIIlI, "CheatBreaker", IScoreObjectiveCriteria.field_96641_b);
        iIlIlIlIlIllIlIllIIllIIII.setDisplayName(EnumChatFormatting.BOLD + "" + EnumChatFormatting.RED + "Cheat" + EnumChatFormatting.RESET + EnumChatFormatting.BOLD + "" + EnumChatFormatting.WHITE + "Breaker");
        ilIIIIllIlIlIIIlIIIllIIlI.func_96529_a("Steve", iIlIlIlIlIllIlIllIIllIIII);
        ilIIIIllIlIlIIIlIIIllIIlI.func_96529_a("Alex", iIlIlIlIlIllIlIllIIllIIII);
        this.lIIIIlIIllIIlIIlIIIlIIllI(iIlIlIlIlIllIlIllIIllIIII, lIllIlIlllIIlIIllIIlIIlII2.getResolution().getScaledHeight(), lIllIlIlllIIlIIllIIlIIlII2.getResolution().getScaledWidth(), this.minecraft.fontRenderer, (Float) this.scale.getValue());
        GL11.glPopMatrix();
    }

    private void renderReal(GuiDrawEvent llIlIIIllIIIIlllIlIIIIIlI2) {
        if (!this.isRenderHud()) {
            return;
        }
        GL11.glPushMatrix();
        this.scaleAndTranslate(llIlIIIllIIIIlllIlIIIIIlI2.getResolution());
        GL11.glTranslatef(this.lIIIIlIIllIIlIIlIIIlIIllI() ? (float)-12 : 2.0f, this.height, 0.0f);
        ScoreObjective iIlIlIlIlIllIlIllIIllIIII = this.minecraft.theWorld.getScoreboard().func_96539_a(1);
        if (iIlIlIlIlIllIlIllIIllIIII != null) {
            this.lIIIIlIIllIIlIIlIIIlIIllI(iIlIlIlIlIllIlIllIIllIIII, llIlIIIllIIIIlllIlIIIIIlI2.getResolution().getScaledHeight(), llIlIIIllIIIIlllIlIIIIIlI2.getResolution().getScaledWidth(), this.minecraft.fontRenderer, (Float) this.scale.getValue());
        }
        GL11.glPopMatrix();
    }

    private void lIIIIlIIllIIlIIlIIIlIIllI(ScoreObjective iIlIlIlIlIllIlIllIIllIIII, int n, int n2, FontRenderer fontRenderer, float f) {
        Scoreboard ilIIIIllIlIlIIIlIIIllIIlI = iIlIlIlIlIllIlIllIIllIIII.getScoreboard();
        Collection<Score> collection = ilIIIIllIlIlIIIlIIIllIIlI.func_96534_i(iIlIlIlIlIllIlIllIIllIIII);
        boolean bl = this.lIIIIlIIllIIlIIlIIIlIIllI();
        if (collection.size() <= 15) {
            int n3 = fontRenderer.getStringWidth(iIlIlIlIlIllIlIllIIllIIII.getDisplayName());
            int n4 = n3 + 16;
            for (Score lIlIlIIllIIIlIlllllIlIIlI2 : collection) {
                ScorePlayerTeam lIIllllIllIIllIlIlllIllIl2 = ilIIIIllIlIlIIIlIIIllIIlI.getPlayersTeam(lIlIlIIllIIIlIlllllIlIIlI2.getPlayerName());
                String string = ScorePlayerTeam.formatPlayerName(lIIllllIllIIllIlIlllIllIl2, lIlIlIIllIIIlIlllllIlIIlI2.getPlayerName()) + ": " + EnumChatFormatting.RED + lIlIlIIllIIIlIlllllIlIIlI2.getScorePoints();
                n3 = Math.max(n3, fontRenderer.getStringWidth(string));
            }
            int n5 = 0;
            int n6 = 3;
            int n7 = 0;
            int n8 = 0;
            Iterator<Score> iterator = collection.iterator();
            int n9 = 0;
            while (iterator.hasNext()) {
                Score lIlIlIIllIIIlIlllllIlIIlI3 = iterator.next();
                Team lIIllllIllIIllIlIlllIllIl3 = ilIIIIllIlIlIIIlIIIllIIlI.getPlayersTeam(lIlIlIIllIIIlIlllllIlIIlI3.getPlayerName());
                String string = ScorePlayerTeam.formatPlayerName(lIIllllIllIIllIlIlllIllIl3, lIlIlIIllIIIlIlllllIlIIlI3.getPlayerName());
                String string2 = (Object)((Object)EnumChatFormatting.RED) + "" + lIlIlIIllIIIlIlllllIlIIlI3.getScorePoints();
                int n10 = n5 - ++n8 * fontRenderer.FONT_HEIGHT;
                int n11 = n3 + n6 + 6;
                if (n11 < n4) {
                    n11 = n4;
                }
                Gui.drawRect(n7 - 2 + (bl ? 14 : 0), n10, n11, n10 + fontRenderer.FONT_HEIGHT, 0x50000000);
                n9 = n11 - (n7 - 2 + (bl ? 14 : 0));
                fontRenderer.drawString(string, n7 + (bl ? 16 : 0), n10, 0x20FFFFFF);
                if (!bl) {
                    fontRenderer.drawString(string2, n11 - fontRenderer.getStringWidth(string2) - 2, n10, 0x20FFFFFF);
                }
                if (n8 != collection.size()) continue;
                String string3 = iIlIlIlIlIllIlIllIIllIIII.getDisplayName();
                Gui.drawRect(n7 - 2 + (bl ? 14 : 0), n10 - fontRenderer.FONT_HEIGHT - 1, n11, n10 - 1, 0x60000000);
                Gui.drawRect(n7 - 2 + (bl ? 14 : 0), n10 - 1, n11, n10, 0x50000000);
                fontRenderer.drawString(string3, n7 + n3 / 2 - fontRenderer.getStringWidth(string3) / 2 + (bl ? 14 : 0), n10 - fontRenderer.FONT_HEIGHT, 0x20FFFFFF);
            }
            this.setDimensions(n9, collection.size() * fontRenderer.FONT_HEIGHT + 12);
        }
    }

    private boolean lIIIIlIIllIIlIIlIIIlIIllI() {
        return specialModType == ModuleRule.SCOREBOARD
                ? (Boolean)this.removeNumbers.getValue()
                : false;
    }
}
