package com.cheatbreaker.client.module;

public enum ModuleRule {
    MINIMAP_ALLOWED,
    SCOREBOARD,
    MINIMAP_NOT_ALLOWED;
}
