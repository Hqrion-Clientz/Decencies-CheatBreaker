package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.EventBus;

public class KeepAliveEvent extends EventBus.Event {
}
