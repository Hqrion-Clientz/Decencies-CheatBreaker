package com.cheatbreaker.client.event.type;

import com.cheatbreaker.client.event.EventBus;

public class TickEvent extends EventBus.Event {
}
