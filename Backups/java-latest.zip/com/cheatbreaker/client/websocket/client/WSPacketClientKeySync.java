package com.cheatbreaker.client.websocket.client;

import com.cheatbreaker.client.websocket.AssetsWebSocket;
import com.cheatbreaker.client.nethandler.ByteBufWrapper;
import com.cheatbreaker.client.websocket.WSPacket;

public class WSPacketClientKeySync extends WSPacket {
    @Override
    public void write(ByteBufWrapper buf) {
    }

    @Override
    public void read(ByteBufWrapper buf) {
    }

    @Override
    public void handle(AssetsWebSocket lIIlllIIlllIlIllIIlIIIIll2) {
    }
}

